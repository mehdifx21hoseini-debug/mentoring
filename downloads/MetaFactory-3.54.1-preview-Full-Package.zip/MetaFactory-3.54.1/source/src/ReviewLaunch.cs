using System;using System.IO;using System.Linq;using System.Text;using System.Drawing;using System.Collections.Generic;using System.Diagnostics;using System.Windows.Forms;
namespace MTManager
{
    public sealed class ReviewCopyPlan
    {
        public Instance Parent,Copy; public Account Account; public int Number;
    }
    public static class ReviewCopies
    {
        public const int MaxCopies=200;
        const string Marker="metafactory-review.txt";
        public static ReviewCopyPlan Plan(Instance parent,Account account,int number)
        {
            if(parent==null||string.IsNullOrWhiteSpace(parent.Name)||parent.Name=="."||parent.Name==".."||parent.Name.IndexOfAny(new[]{'/','\\','\r','\n'})>=0)throw new ArgumentException("Invalid source copy.");
            if(number<2||number>MaxCopies)throw new ArgumentOutOfRangeException("number");
            string dir=Path.Combine(Path.GetDirectoryName(Path.GetFullPath(parent.Dir)),"_MTManager","review",parent.Name,number.ToString("00"));
            return new ReviewCopyPlan{Parent=parent,Number=number,Account=account==null?null:account.Snapshot(),Copy=new Instance{Name=parent.Name+"~review-"+number.ToString("00"),Kind=parent.Kind,Dir=dir}};
        }
        static string Identity(Instance parent){return Convert.ToBase64String(Encoding.UTF8.GetBytes(Path.GetFullPath(parent.Dir)))+"\t"+parent.Kind;}
        public static bool Owned(ReviewCopyPlan plan){try{return Directory.Exists(plan.Copy.Dir)&&(File.GetAttributes(plan.Copy.Dir)&FileAttributes.ReparsePoint)==0&&File.ReadAllText(Path.Combine(plan.Copy.Dir,Marker))==Identity(plan.Parent);}catch{return false;}}
        public static IEnumerable<Instance> Existing(Instance parent)
        {
            var first=Plan(parent,null,2);string root=Path.GetDirectoryName(first.Copy.Dir);if(!Directory.Exists(root))return new Instance[0];var result=new List<Instance>();
            string[] dirs;try{dirs=Directory.GetDirectories(root);}catch(IOException){return result;}catch(UnauthorizedAccessException){return result;}
            foreach(string dir in dirs){int n;if(!int.TryParse(Path.GetFileName(dir),out n)||n<2||n>MaxCopies)continue;var plan=Plan(parent,null,n);if(Owned(plan)&&File.Exists(plan.Copy.Exe))result.Add(plan.Copy);}return result;
        }
        public static void Prepare(Settings settings,ReviewCopyPlan plan,Func<bool> cancelled)
        {
            if(cancelled())throw new OperationCanceledException();
            if(Directory.Exists(plan.Copy.Dir))
            {if(!Owned(plan))throw new IOException(Lang.T("پوشهٔ نسخهٔ بررسی شناخته نشد؛ فایل‌ها دست‌نخورده ماندند.","Review directory is not managed; existing files were preserved."));if(!File.Exists(plan.Copy.Exe))throw new IOException("Review terminal is incomplete.");return;}
            var provision=PlainSettings(settings);provision.BaseDir=Path.GetDirectoryName(Path.GetFullPath(plan.Parent.Dir));
            StudentDirectory.EnsureCopy(provision,plan.Parent,plan.Account,cancelled);
            StudentDirectory.Prepare(provision,plan.Parent.Dir,plan.Copy,cancelled);
            File.WriteAllText(Path.Combine(plan.Copy.Dir,Marker),Identity(plan.Parent),Encoding.UTF8);
        }
        public static Settings PlainSettings(Settings source)
        {
            var copy=new Settings();foreach(var f in typeof(Settings).GetFields(System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.Public))f.SetValue(copy,f.GetValue(source));copy.Folders=new List<string>(source.Folders);
            copy.ManualLiveReports=false;copy.Minimized=false;copy.Light=false;copy.StartCharts=ChartModes.All;copy.LightCharts=false;copy.AutoStart=false;return copy;
        }
        public static AccountStore Accounts(ReviewCopyPlan plan)
        {var store=new AccountStore();if(plan.Account!=null){var account=plan.Account.Snapshot();account.Instance=plan.Copy.Name;account.DeferredDir="";store.Set(account);}return store;}
    }
    sealed class LaunchRequestDialog : FormDialog
    {
        readonly Stepper count=new Stepper(1,ReviewCopies.MaxCopies);
        readonly Label estimate=Theme.Label("",460,Theme.Small,Theme.Muted);
        readonly int students;readonly bool live;
        public int CopiesPerStudent{get{return count.Value;}}
        internal LaunchRequestDialog(int students,bool live=true):base(Lang.T("اجرای متاتریدرها","Launch MetaTraders"),Fa.N(students)+Lang.T(" دانشجو در محدودهٔ اجرا"," students in this launch"))
        {
            this.students=students;this.live=live;count.Value=1;
            Row(Lang.T("تعداد نسخه برای هر دانشجو","Copies per student"),count);
            Wide(Theme.Label(live?Lang.T("✓ یک نسخه با گزارش زنده","✓ One live-report instance"):Lang.T("اجرای عادی بدون اکسپرت","Ordinary launch without report EA"),460,Theme.Bold,Theme.Accent));
            Wide(Theme.Label(Lang.T("پیش‌فرض فقط یک نسخه است. با انتخاب ۲ یا بیشتر، نسخه‌های اضافه بدون اکسپرت برای بررسی نمودار و معاملات باز می‌شوند. نسخه‌های باز دوباره اجرا نمی‌شوند؛ تغییر حالت نسخهٔ اصلی باز، پس از بستن و اجرای دوباره اعمال می‌شود.","Defaults to one instance. At 2 or more, extra instances have no report EA and are for chart/trade review. Already-running instances are not duplicated; changing the mode of a running primary takes effect after closing and reopening it."),460,Theme.Small,Theme.Muted));
            Wide(estimate);count.Changed+=(s,e)=>UpdateEstimate();UpdateEstimate();
            var run=AddButton(Lang.T("تأیید و اجرا","Confirm and run"),(s,e)=>Close(DialogResult.OK),true);var cancel=AddButton(Lang.T("انصراف","Cancel"),(s,e)=>Close(DialogResult.Cancel));Finish();AcceptButton=run;CancelButton=cancel;
        }
        void UpdateEstimate(){estimate.Text=Fa.N((long)students*count.Value)+Lang.T(" نسخه در مجموع؛ "," total instances; ")+Fa.N(students)+Lang.T(live?" نسخه گزارش زنده":" نسخه اصلی",live?" live-report":" primary")+" + "+Fa.N((long)students*(count.Value-1))+Lang.T(" نسخه بررسی. نسخهٔ بیشتر حافظهٔ بیشتری نیاز دارد."," review. More instances use more memory.");}
    }
    sealed partial class MainForm
    {
        readonly Dictionary<string,ReviewCopyPlan> reviewPlans=new Dictionary<string,ReviewCopyPlan>(StringComparer.OrdinalIgnoreCase);
        string reviewDiscoveryKey="";int reviewOpenCount;
        Func<ReviewCopyPlan,Settings,StartResult> startReviewTerminal;
        List<Instance> KnownReviewCopies()
        {
            string key=string.Join("|",copies.Select(i=>i.Dir));if(key!=reviewDiscoveryKey){reviewDiscoveryKey=key;foreach(var parent in copies)foreach(var extra in ReviewCopies.Existing(parent))if(!reviewPlans.ContainsKey(extra.Name))reviewPlans[extra.Name]=new ReviewCopyPlan{Parent=parent,Copy=extra};}
            return reviewPlans.Values.Where(p=>copies.Any(c=>c.Dir==p.Parent.Dir)).Select(p=>p.Copy).ToList();
        }
        bool ReviewSelected(Instance copy){ReviewCopyPlan plan;return chosen.Has(copy.Name)||(reviewPlans.TryGetValue(copy.Name,out plan)&&chosen.Has(plan.Parent.Name));}
        List<Instance> WithReviewCopies(IEnumerable<Instance> parents){var list=parents.ToList();var names=new HashSet<string>(list.Select(i=>i.Name),StringComparer.OrdinalIgnoreCase);return list.Concat(KnownReviewCopies().Where(i=>{ReviewCopyPlan plan;return reviewPlans.TryGetValue(i.Name,out plan)&&names.Contains(plan.Parent.Name);})).GroupBy(i=>i.Dir,StringComparer.OrdinalIgnoreCase).Select(g=>g.First()).ToList();}
        void RequestManualLaunch(List<Instance> targets,bool live=true)
        {
            var snapshot=targets.ToList();if(snapshot.Count==0)return;
            if(preparingCopy||startQueue.Count>0||busy||report!=null||scheduledBatch!=null){SetStatus(Lang.T("عملیات فعلی هنوز تمام نشده؛ پس از پایان دوباره اجرا کنید.","Wait for the current operation before starting a new batch."));return;}
            using(var dialog=new LaunchRequestDialog(snapshot.Count,live)){if(dialog.ShowDialog(this)!=DialogResult.OK)return;AcceptManualLaunch(snapshot,dialog.CopiesPerStudent,live);}
        }
        void AcceptManualLaunch(List<Instance> targets,int count,bool live)
        {
            if(count<1||count>ReviewCopies.MaxCopies)throw new ArgumentOutOfRangeException("count");
            var originals=targets.ToList();
            if(count>1&&originals.Any(parent=>{var a=accounts.Get(parent.Name);return a==null||!a.HasLogin;}))throw new UserMessage(Lang.T("برای نسخهٔ بررسی، ابتدا حساب دانشجو را ثبت کنید.","Save each student's account before opening review instances."));
            var requested=new List<Instance>(originals);
            foreach(var parent in originals)for(int n=2;n<=count;n++){var plan=ReviewCopies.Plan(parent,accounts.Get(parent.Name),n);reviewPlans[plan.Copy.Name]=plan;requested.Add(plan.Copy);}
            settings.ManualLiveReports=live;settings.Save();runButton.SetText(live?Lang.T("اجرا · زنده","Run · live"):Lang.T("اجرا · عادی","Run · ordinary"));
            Enqueue(requested);
        }
        bool TryStartReviewCopy()
        {
            ReviewCopyPlan plan;if(startQueue.Count==0||!reviewPlans.TryGetValue(startQueue.Peek().Name,out plan))return false;
            var copy=startQueue.Dequeue();if(plan.Account==null)plan.Account=accounts.Get(plan.Parent.Name);
            preparingCopy=true;lastStartAt=DateTime.Now;pacing=null;launchWork.Add(copy.Name);launchWork.Detail=copy.Name+Lang.T("؛ آماده‌سازی نسخه بررسی","; preparing review instance");RefreshLaunchProgress();LaunchComparison.Preparing(copy);
            var plain=ReviewCopies.PlainSettings(settings);var request=plan;
            System.Threading.Tasks.Task.Factory.StartNew(()=>{
                Func<bool> cancel=()=>appClosing||launchWork.Stopped||accounts.Get(request.Parent.Name)==null;
                ReviewCopies.Prepare(plain,request,cancel);if(cancel())throw new OperationCanceledException();
                return startReviewTerminal!=null?startReviewTerminal(request,plain):Launcher.StartReview(request.Copy,plain,ReviewCopies.Accounts(request));
            }).ContinueWith(task=>{
                var error=task.Exception==null?null:task.Exception.GetBaseException();var result=error==null?task.Result:null;
                if(appClosing||IsDisposed||!IsHandleCreated){CleanDetachedStart(copy,result);return;}
                try{BeginInvoke((Action)(()=>{preparingCopy=false;launchWork.SettleStop();if(error is OperationCanceledException&&launchWork.Stopped)launchWork.Skip(copy.Name);else if(error!=null)RecordLaunchFailure(copy,error);else CompleteManualStart(copy,result);RefreshLaunchProgress();if(startQueue.Count==0)startTimer.Stop();else startTimer.Start();}));}catch(InvalidOperationException){CleanDetachedStart(copy,result);}
            });return true;
        }
    }
}
