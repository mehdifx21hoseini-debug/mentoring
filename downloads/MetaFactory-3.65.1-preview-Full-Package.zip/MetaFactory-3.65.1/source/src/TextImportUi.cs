using System;using System.Collections.Generic;using System.ComponentModel;using System.Drawing;using System.Linq;using System.Windows.Forms;
namespace MTManager
{
    sealed class TextImportEntryDialog:Form
    {
        readonly TextBox input=new TextBox{Multiline=true,ScrollBars=ScrollBars.Vertical,Dock=DockStyle.Fill,AcceptsReturn=true,MaxLength=1024*1024};
        readonly CheckBox latin=new CheckBox{AutoSize=true,Checked=true,Text=Lang.T("نام انگلیسی پیشنهادی؛ اصل نام حفظ می‌شود","Suggest Latin names; keep original Persian names")};
        readonly CheckBox refresh=new CheckBox{AutoSize=true,Checked=true,Text=Lang.T("دریافت فهرست جدید سرورها در صورت نیاز","Refresh server catalogue when needed")};
        readonly Label status=new Label{AutoSize=true};readonly BackgroundWorker worker=new BackgroundWorker();readonly Button parse;
        volatile bool cancelled;public List<StudentImportRow> Rows;
        public TextImportEntryDialog(Settings settings,AccountStore accounts)
        {
            Text=Lang.T("ورود دانشجو از متن","Add students from text");Font=Theme.Font;BackColor=Theme.Surface;ForeColor=Theme.Text;RightToLeft=Theme.Dir;StartPosition=FormStartPosition.CenterParent;ShowIcon=false;MinimizeBox=false;MaximizeBox=false;
            var screen=Screen.FromPoint(Cursor.Position).WorkingArea;ClientSize=new Size(Math.Min(Theme.S(740),screen.Width-60),Math.Min(Theme.S(560),screen.Height-70));MinimumSize=new Size(500,380);Theme.Window(this);
            var layout=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=6,Padding=Theme.Pad(18)};layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));for(int n=2;n<6;n++)layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));Controls.Add(layout);
            layout.Controls.Add(Theme.Label(Lang.T("پیام چند دانشجو را یک‌جا اینجا بچسبانید؛ سپس پیش‌نمایش را بررسی و اصلاح کنید.","Paste several student messages here, then review and edit the preview."),680),0,0);layout.Controls.Add(input,0,1);layout.Controls.Add(latin,0,2);layout.Controls.Add(refresh,0,3);layout.Controls.Add(status,0,4);
            var buttons=new ButtonRow{Dock=DockStyle.Fill};parse=buttons.Add(new ModernButton(Lang.T("خواندن متن و پیش‌نمایش","Read text and preview"),null,ButtonKind.Primary));buttons.Add(new ModernButton(Lang.T("انصراف","Cancel"),(s,e)=>Close()));layout.Controls.Add(buttons,0,5);
            parse.Click+=(s,e)=>{
                if(worker.IsBusy||string.IsNullOrWhiteSpace(input.Text))return;string text=input.Text;bool convert=latin.Checked,online=refresh.Checked;var existing=accounts.All.Select(a=>StudentImport.Key(StudentDirectory.KindOf(a),a.Login,a.Server)).ToArray();
                parse.Enabled=input.Enabled=latin.Enabled=refresh.Enabled=false;status.Text=Lang.T("خواندن اطلاعات و فهرست سرورها…","Reading messages and server catalogue…");
                var local=new Dictionary<Kind,IEnumerable<string>>();foreach(Kind k in new[]{Kind.MT4,Kind.MT5})local[k]=ServerCatalog.Local(k,settings,accounts).Concat(ServerCatalog.Online(k)).ToArray();
                worker.RunWorkerAsync(new Func<List<StudentImportRow>>(()=>{if(online)foreach(Kind k in new[]{Kind.MT4,Kind.MT5}){if(cancelled)return null;try{if(!ServerCatalog.Fresh(k))ServerCatalog.Refresh(k,5000);}catch{}local[k]=local[k].Concat(ServerCatalog.Online(k)).ToArray();}if(cancelled)return null;return TextStudentImport.Parse(text,convert,existing,k=>local[k]);}));
            };
            worker.DoWork+=(s,e)=>e.Result=((Func<List<StudentImportRow>>)e.Argument)();
            worker.RunWorkerCompleted+=(s,e)=>{if(IsDisposed||cancelled)return;parse.Enabled=input.Enabled=latin.Enabled=refresh.Enabled=true;if(e.Error!=null){status.Text=Lang.T("متن خوانده نشد؛ قالب اطلاعات را بررسی کنید.","Could not read the input; check its structure.");Ui.Error(this,e.Error);return;}Rows=e.Result as List<StudentImportRow>;if(Rows==null)return;input.Clear();DialogResult=DialogResult.OK;Close();};
            FormClosed+=(s,e)=>{cancelled=true;input.Clear();};
        }
    }
    sealed class ImportRowEditDialog:FormDialog
    {
        public ImportRowEditDialog(StudentImportRow row):base(Lang.T("اصلاح اطلاعات پیش‌نمایش","Edit preview information"),Lang.T("تغییرات هنوز در حساب‌ها ثبت نمی‌شوند.","Changes are not registered until you add the ready rows."))
        {
            TextBox name=Box(row.Name),original=Box(row.OriginalName),login=Box(row.Login),server=Box(row.Server),folder=Box(row.Folder);var investor=new PasswordBox(310){Value=row.Investor};var master=new PasswordBox(310){Value=row.Master};
            var platform=new ComboBox{Width=Theme.S(310),DropDownStyle=ComboBoxStyle.DropDownList};platform.Items.AddRange(new object[]{"MT4","MT5"});platform.SelectedIndex=row.Platform=="MT4"?0:row.Platform=="MT5"?1:-1;
            var mode=new ComboBox{Width=Theme.S(310),DropDownStyle=ComboBoxStyle.DropDownList};mode.Items.AddRange(new object[]{"investor","master"});mode.SelectedIndex=row.Mode=="master"?1:0;
            var auto=new CheckBox{AutoSize=true,Checked=row.ImportServers.Length>0,Text=Lang.T("بررسی سرورهای پیشنهادی این بروکر","Check this broker's candidate servers")};auto.Enabled=row.ImportServers.Length>0;
            Row(Lang.T("نام انگلیسی","Name"),name);Row(Lang.T("نام اصلی","Original name"),original);Row(Lang.T("متاتریدر","Platform"),platform);Row(Lang.T("شماره حساب","Account"),login);Row(Lang.T("سرور","Server"),server);Row(Lang.T("اینوستور","Investor"),investor);Row(Lang.T("مستر (اختیاری)","Master (optional)"),master);Row(Lang.T("نوع ورود","Mode"),mode);Row(Lang.T("پوشه","Folder"),folder);Wide(auto);
            AddButton(Lang.T("ذخیره در پیش‌نمایش","Save preview"),(s,e)=>{bool unchanged=server.Text.Trim()==row.Server&&Convert.ToString(platform.SelectedItem)==row.Platform;row.Name=name.Text.Trim();row.OriginalName=original.Text.Trim();row.Platform=Convert.ToString(platform.SelectedItem);if(login.Text.Trim()!=row.Login)row.LoginNeedsCorrection=false;row.Login=login.Text.Trim();row.Server=server.Text.Trim();row.Investor=investor.Value;row.Master=master.Value;row.Mode=Convert.ToString(mode.SelectedItem);row.ModeExplicit=true;row.Folder=folder.Text.Trim();row.InputProblem="";if(!auto.Checked||!unchanged)row.ImportServers="";Close(DialogResult.OK);},true);AddButton(Lang.T("انصراف","Cancel"),(s,e)=>Close(DialogResult.Cancel));Finish();
        }
        static TextBox Box(string text){return new TextBox{Width=Theme.S(310),Text=text,RightToLeft=RightToLeft.No};}
    }
}
