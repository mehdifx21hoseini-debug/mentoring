using System;
using System.Collections.Generic;
using System.Globalization;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MTManager
{
    public interface IAccountVerifier : IDisposable
    {
        ImportConnection Verify(Account account, int milliseconds, Func<bool> cancel, Action<string> stage);
    }

    public interface IIdleAccountVerifier { void Idle(bool paused); }
    public static class VerificationReuse
    {
        public static bool CanReuse(Kind current, string currentServer, Kind next, string nextServer, bool ownedAlive)
        { return ownedAlive && current == Kind.MT5 && next == Kind.MT5 && string.Equals(currentServer, nextServer, StringComparison.OrdinalIgnoreCase); }
    }
    public static class VerificationParallel
    {
        public static int Auto(int processors, ulong totalMb, ulong freeMb)
        { return processors >= 2 && totalMb >= 6000 && freeMb >= 2500 ? 2 : 1; }
    }

    // Account metadata is the durable queue: no second credentials file and no plaintext password logs.
    public sealed class ImportCoordinator : IDisposable
    {
        readonly Settings settings;
        readonly AccountStore accounts;
        readonly FolderStore folders;
        readonly Func<int, IAccountVerifier> factory;
        readonly AutoResetEvent wake = new AutoResetEvent(false);
        readonly List<Task> workers = new List<Task>();
        readonly int capacity;
        volatile bool stopping, paused;
        int disposeStarted;
        public event Action Changed;
        public bool Paused { get { return paused; } }
        public ImportCoordinator(Settings settings, AccountStore accounts, FolderStore folders, Func<int, IAccountVerifier> factory = null, int capacity = 0)
        {
            this.settings = settings; this.accounts = accounts; this.folders = folders;
            this.factory = factory ?? (slot => new DirectAccountVerifier(settings, slot));
            this.capacity = capacity > 0 ? Math.Min(2, capacity) : VerificationParallel.Auto(Environment.ProcessorCount, Checks.TotalRamMb(), Checks.FreeRamMb());
            bool readable; AccountStore.Load(out readable); if (!readable) { paused = true; return; }
            // Recovery is explicit: an interrupted attempt cannot reuse a previous success token.
            lock (accounts.Sync)
            {
                bool dirty = false;
                foreach (Account a in accounts.All.Where(a => a.VerifyState == "checking"))
                { a.VerifyState = "queued"; a.VerifyToken = ""; a.VerifyPass = Math.Max(0, a.VerifyPass - 1); accounts.SetQueue(a); dirty = true; }
                if (dirty) accounts.Save();
            }
        }
        public void RecoverGroups()
        {
            lock(folders)
            {
                var pending=accounts.All.Where(a=>a.ImportGroup.Length>0).ToArray();if(pending.Length==0)return;
                bool foldersReadable;FolderStore.Load(out foldersReadable);if(!foldersReadable)throw new IOException("Folder data is unreadable; memberships and pending markers were preserved.");
                foreach(var a in pending)
                {
                    var current=accounts.Get(a.Instance);if(current==null||current.ImportGroup!=a.ImportGroup||StudentImport.Key(StudentDirectory.KindOf(current),current.Login,current.Server)!=StudentImport.Key(StudentDirectory.KindOf(a),a.Login,a.Server))continue;
                    foreach(string group in ImportFlow.PendingGroups(a.ImportGroup)){Folder f=folders.Find(group)??folders.Create(group);folders.Add(f.Id,new[]{a.Instance});}
                }
                if(Directory.Exists(FolderStore.FilePath))throw new IOException("A directory occupies the folder-data file; recovery intent was preserved.");
                folders.Save();
                bool savedReadable;var saved=FolderStore.Load(out savedReadable);
                if(!savedReadable||!File.Exists(FolderStore.FilePath))throw new IOException("Folder save could not be verified; recovery intent was preserved.");
                foreach(var a in pending)
                {
                    var current=accounts.Get(a.Instance);if(current==null||current.ImportGroup!=a.ImportGroup)continue;
                    foreach(string group in ImportFlow.PendingGroups(a.ImportGroup)){var target=saved.Find(group);if(target==null||!saved.Has(target.Id,a.Instance))throw new IOException("Folder membership was not durably saved; recovery intent was preserved.");}
                }
                lock(accounts.Sync)
                {
                    var changed=new List<Account>();
                    foreach(var a in pending){var current=accounts.Get(a.Instance);if(current!=null&&current.ImportGroup==a.ImportGroup){changed.Add(current.Snapshot());current.ImportGroup="";accounts.SetQueue(current);}}
                    try{if(changed.Count>0)accounts.Save();}catch{foreach(var old in changed)accounts.SetQueue(old);throw;}
                }
            }
        }
        public void Register(IEnumerable<StudentImportRow> rows, string defaultFolder, Func<bool> cancel, Action<StudentImportRow> progress, bool verified = false)
        {
            bool readable; AccountStore.Load(out readable);
            if (!readable) throw new IOException("The accounts file is unreadable; existing data was preserved.");
            var staged = new List<KeyValuePair<StudentImportRow, Account>>();
            lock (accounts.Sync)
            {
                var reserved = new HashSet<string>(StudentDirectory.All(settings, accounts).Select(c => c.Name).Concat(accounts.All.Select(a=>a.Instance)), StringComparer.OrdinalIgnoreCase);
                var indices = new Dictionary<Kind, int> { { Kind.MT4, CopyMaker.NextIndex(settings.AllFolders, "MT4") }, { Kind.MT5, CopyMaker.NextIndex(settings.AllFolders, "MT5") } };
                var seen = new HashSet<string>(accounts.All.Select(a => StudentImport.Key(StudentDirectory.KindOf(a), a.Login, a.Server)), StringComparer.OrdinalIgnoreCase);
                try
                {
                    foreach (StudentImportRow r in rows.Where(r => r.State == ImportState.Ready))
                    {
                        if (cancel()) { r.State = ImportState.Cancelled; progress(r); continue; }
                        if (!seen.Add(StudentImport.Key(r.Kind, r.Login, r.Server))) { r.State = ImportState.Duplicate; r.Reason = Lang.T("این شماره حساب قبلاً ثبت شده است.", "Account number already registered."); progress(r); continue; }
                        string group = r.Folder.Length>0?r.Folder:ImportFlow.RequestedGroups(r).FirstOrDefault()??defaultFolder??"";
                        string problem = group.Length == 0 || folders.Find(group) != null ? null : folders.NameProblem(group);
                    foreach(string additional in ImportFlow.RequestedGroups(r))if(folders.Find(additional)==null&&folders.NameProblem(additional)!=null)throw new UserMessage(folders.NameProblem(additional));
                        if (problem != null) { r.State = ImportState.Invalid; r.Reason = problem; progress(r); continue; }
                        string name;
                        do { name = r.Kind + "-" + (indices[r.Kind]++).ToString("00"); } while (!reserved.Add(name));
                        var a = new Account { Instance = name, Trader = r.Name, Login = r.Login, Server = r.Server, Mode = r.Mode, InvestorEnc = Secret.Protect(r.Investor), MasterEnc = Secret.Protect(r.Master),
                            OriginalTrader=r.OriginalName, ImportServers=r.ImportServers, Platform = r.Platform, DeferredDir = Path.Combine(settings.BaseDir, name), VerifyState = verified?"connected":"queued", VerifyUtc=verified?DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture):"", VerifyReason=verified?Lang.T("ورود قبل از ثبت تأیید شد.","Login verified before registration."):"", ImportGroup = ImportFlow.EncodeGroups(ImportFlow.RequestedGroups(r).Concat(string.IsNullOrWhiteSpace(group)?new string[0]:new[]{group})) };
                        accounts.SetQueue(a); staged.Add(new KeyValuePair<StudentImportRow, Account>(r, a));
                    }
                    if (staged.Count > 0) accounts.Save(); // One atomic commit for the entire batch.
                }
                catch { foreach (var pair in staged) accounts.Remove(pair.Value.Instance); throw; }
                foreach (var pair in staged)
                {
                    var r = pair.Key; r.Copy = pair.Value.Instance; r.Folder = ImportFlow.PendingGroups(pair.Value.ImportGroup).FirstOrDefault()??""; r.State = verified?ImportState.Connected:ImportState.Registered;
                    r.Reason = verified?Lang.T("ورود تأیید و حساب ثبت شد؛ سرور: ","Login verified and account added; server: ")+r.Server:Lang.T("ثبت شد؛ بررسی اتصال در پس‌زمینه انجام می‌شود.", "Registered; connection will be checked in the background."); progress(r);
                }
            }
            // Grouping errors never hide already committed accounts; marker is retained for recovery.
            try { RecoverGroups(); }
            catch (Exception e) { Log.Write("import grouping recovery required: " + e.GetType().Name); }
            Notify(); wake.Set();
        }
        public void VerifyAndRegister(IEnumerable<StudentImportRow> input,string defaultFolder,Func<bool> cancel,Action<StudentImportRow> progress)
        {
            var requestedCancel=cancel;cancel=()=>stopping||requestedCancel();
            IAccountVerifier verifier=null;string blockedReason=null;var all=input.ToArray();var list=all.Where(x=>x.State==ImportState.Ready).ToArray();string run=Guid.NewGuid().ToString("N");
            Log.Write("import run="+run+" ready="+list.Length+" unchanged="+all.Count(x=>x.State==ImportState.Unchanged));
            try
            {
                foreach(var r in list)
                {
                    Action report=()=>{try{progress(r);}catch(Exception error){Log.Write("import result notification failed: "+error.GetType().Name);}};
                    if(cancel()){r.State=ImportState.Cancelled;r.Reason="متوقف شد؛ قبلی حفظ شد.";report();continue;}
                    if(!r.MetadataOnly&&blockedReason!=null){r.State=ImportState.Blocked;r.Reason=blockedReason+(r.ExistingCopy.Length>0?" قبلی حفظ شد.":" حساب جدید ثبت نشد.");report();continue;}
                    if(r.ReplacementAccount==null&&accounts.All.Any(a=>StudentImport.Key(StudentDirectory.KindOf(a),a.Login,a.Server)==StudentImport.Key(r.Kind,r.Login,r.Server))){r.State=ImportState.Duplicate;r.Reason="این شماره حساب قبلاً ثبت شده است؛ قبلی حفظ شد.";report();continue;}
                    r.State=ImportState.Checking;r.Outcome=Login.Waiting;r.Reason=r.MetadataOnly?"ذخیرهٔ مشخصات؛ بدون بررسی اتصال…":"بررسی ورود پیش از ثبت…";report();
                    var rowClock=Stopwatch.StartNew();
                    try
                    {
                        if(r.ReplacementAccount!=null)ImportReplacement.ValidateApproval(r);
                        if(r.MetadataOnly)
                        {
                            ImportReplacement.CommitVerified(accounts,r,r.ReplacementAccount.Server,cancel);
                        }
                        else
                        {
                            if(verifier==null)verifier=factory(3);
                            var job=ImportFlow.Job(r);ImportConnection result=ImportServerPlan.Verify(job,verifier,30000,cancel,text=>{r.Reason=r.Redact(text);report();});
                            var recovering=verifier as IRecoveringAccountVerifier;
                            if(result!=null&&!result.Connected&&result.Retryable&&result.State!=Login.WrongLogin&&recovering!=null&&string.IsNullOrEmpty(job.ImportServers)&&!cancel())
                            {
                                r.Reason="بررسی تکمیلی اتصال؛ تلاش دوم و آخر…";report();recovering.Recover(cancel);
                                result=ImportServerPlan.Verify(job,verifier,45000,cancel,text=>{r.Reason=r.Redact(text);report();});
                            }
                            if(cancel())throw new OperationCanceledException();
                            string verifiedServer=result!=null&&ImportServerPlan.Safe(result.VerifiedServer)&&r.ImportServers.Split('|').Contains(result.VerifiedServer,StringComparer.OrdinalIgnoreCase)?result.VerifiedServer:r.Server;
                            if(result!=null&&result.Connected&&ImportFlow.OtherPasswordChanged(r))
                            {
                                var other=ImportFlow.Job(r,r.Mode=="investor"?"master":"investor");other.Server=verifiedServer;other.ImportServers="";
                                result=verifier.Verify(other,30000,cancel,text=>{r.Reason="بررسی رمز نوع دیگر ورود…";report();});
                                if(result!=null&&!result.Connected)result.Reason="رمز نوع دیگر ورود ("+other.Mode+") تأیید نشد. "+result.Reason;
                            }
                            if(cancel())throw new OperationCanceledException();
                            if(result==null||!result.Connected)
                            {
                                r.State=result!=null&&result.State==Login.WrongLogin?ImportState.Failed:ImportState.Unconfirmed;r.Outcome=result==null?Login.Waiting:result.State;
                                r.Reason=r.Redact(result==null?"پاسخ قطعی دریافت نشد.":result.Reason)+(r.ExistingCopy.Length>0?" قبلی حفظ شد؛ اطلاعات جدید ذخیره نشد.":" حساب جدید ثبت نشد.");report();continue;
                            }
                            if(r.ReplacementAccount!=null)ImportReplacement.CommitVerified(accounts,r,verifiedServer,cancel);
                            else{r.Server=verifiedServer;r.ImportServers="";r.State=ImportState.Ready;Register(new[]{r},defaultFolder,cancel,x=>report(),true);}
                            if(r.State==ImportState.Connected)ImportServerPlan.Remember(r.Kind,r.Server);
                        }
                        try{RecoverGroups();}catch(Exception error){r.Reason+=" عضویت پوشه‌ها در صف بازیابی است.";Log.Write("import grouping recovery required: "+error.GetType().Name);}
                        report();Notify();
                    }
                    catch(VerificationBusyException error)
                    {
                        blockedReason="ابزار بررسی آماده نیست؛ بررسی این ردیف انجام نشد. "+error.Message;
                        r.State=ImportState.Blocked;r.Reason=blockedReason+(r.ExistingCopy.Length>0?" قبلی حفظ شد.":" حساب جدید ثبت نشد.");report();
                    }
                    catch(OperationCanceledException){if(r.Saved){report();Notify();continue;}r.State=ImportState.Cancelled;r.Reason="متوقف شد؛ اطلاعات قبلی حفظ شد.";report();}
                    catch(Exception error){if(r.Saved){report();Notify();continue;}r.State=ImportState.Failed;string detail=r.Redact(TextUtil.OneLine(error.Message??""));if(detail.Length>400)detail=detail.Substring(0,400);r.Reason="بررسی یا ذخیره کامل نشد؛ "+(r.ExistingCopy.Length>0?"قبلی حفظ شد. ":"ثبت نشد. ")+"("+error.GetType().Name+": "+detail+")";report();}
                    finally{Log.Write("import run="+run+" row="+r.Line+" action="+ImportFlow.Action(r)+" state="+r.State+" saved="+r.Saved+" elapsed-ms="+rowClock.ElapsedMilliseconds);}
                }
            }
            finally{if(verifier!=null)verifier.Dispose();}
        }

        public void Start()
        {
            if (stopping || workers.Count > 0) return;
            for (int slot = 1; slot <= capacity; slot++)
            {
                int n = slot;
                workers.Add(Task.Factory.StartNew(() => Loop(n), CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default));
            }
        }
        Account Claim()
        {
            lock (accounts.Sync)
            {
                if (stopping || paused) return null;
                Account a = accounts.All.Where(x => (x.VerifyState == "queued" || x.VerifyState == "retry"))
                    .OrderBy(x => x.VerifyPass).ThenBy(x => x.Platform).ThenBy(x => x.Server).ThenBy(x => x.Instance).FirstOrDefault();
                if (a == null) return null;
                Account old = a.Snapshot();
                a.VerifyState = "checking"; a.VerifyToken = Guid.NewGuid().ToString("N"); a.VerifyPass++;
                a.VerifyReason = Lang.T("آماده‌سازی بررسی اتصال…", "Preparing connection check…"); accounts.SetQueue(a);
                try { accounts.Save(); } catch { accounts.SetQueue(old); throw; }
                return a;
            }
        }
        bool Cancelled(Account a)
        {
            if (paused || stopping) return true;
            Account current = accounts.Get(a.Instance);
            return current == null || current.VerifyToken != a.VerifyToken || current.CredentialKey != a.CredentialKey || current.VerifyState != "checking";
        }
        void Finish(Account job, ImportConnection result)
        {
            lock (accounts.Sync)
            {
                Account a = accounts.Get(job.Instance);
                if (a == null || a.VerifyToken != job.VerifyToken || a.CredentialKey != job.CredentialKey) return;
                a.VerifyToken = "";
                if (paused || stopping) { a.VerifyState = paused ? "paused" : "queued"; a.VerifyPass = Math.Max(0, a.VerifyPass - 1); }
                else
                {
                    a.VerifyState = result.Connected ? "connected" : result.State == Login.WrongLogin ? "rejected" : a.VerifyPass < 2 && result.Retryable ? "retry" : "unconfirmed";
                    a.VerifyReason = result.Reason ?? "";
                    foreach (string encrypted in new[] { a.InvestorEnc, a.MasterEnc })
                    {
                        string password = Secret.Unprotect(encrypted);
                        if (!string.IsNullOrEmpty(password)) a.VerifyReason = a.VerifyReason.Replace(password, "***");
                    }
                    a.VerifyUtc = a.VerifyState == "retry" ? "" : DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture);
                    if(result.Connected&&ImportServerPlan.Safe(result.VerifiedServer)&&job.ImportServers.Split('|').Contains(result.VerifiedServer,StringComparer.OrdinalIgnoreCase))
                    {a.Server=result.VerifiedServer;a.ImportServers="";}

                }
                Account previous = accounts.Get(a.Instance);
                accounts.SetQueue(a);
                try { accounts.Save(); } catch { accounts.SetQueue(previous); throw; }
            }
            if(result.Connected)ImportServerPlan.Remember(StudentDirectory.KindOf(job),result.VerifiedServer??job.Server);
            Notify();
        }
        void Loop(int slot)
        {
            IAccountVerifier verifier = null;
            try
            {
                while (!stopping)
                {
                    Account job;
                    try { job = Claim(); }
                    catch (Exception e) { paused = true; Log.Write("verification queue paused: " + e.GetType().Name); Notify(); continue; }
                    if (job == null)
                    {
                        var idle = verifier as IIdleAccountVerifier;
                        if (idle != null) { try { idle.Idle(paused); } catch (Exception e) { Log.Write("verification idle cleanup: " + e.GetType().Name); } }
                        wake.WaitOne(500); continue;
                    }
                    Notify();
                    ImportConnection result;
                    try
                    {
                        if (verifier == null) verifier = factory(slot);
                        result = ImportServerPlan.Verify(job, verifier, job.VerifyPass == 1 ? 15000 : 60000, () => Cancelled(job), text => {
                            lock (accounts.Sync)
                            {
                                Account current = accounts.Get(job.Instance);
                                if (current != null && current.VerifyToken == job.VerifyToken) { current.VerifyReason = text; accounts.SetQueue(current); }
                            }
                        });
                    }
                    catch(VerificationBusyException error)
                    {
                        Log.Write("verification infrastructure paused: slot="+slot+" "+error.GetType().Name);
                        Pause();lock(accounts.Sync){var current=accounts.Get(job.Instance);if(current!=null&&current.CredentialKey==job.CredentialKey){current.VerifyReason="ابزار بررسی آماده نیست؛ صف متوقف شد. اطلاعات حساب رد نشده است.";accounts.SetQueue(current);accounts.Save();}}
                        Notify();continue;
                    }
                    catch (OperationCanceledException) { result = new ImportConnection(); }
                    catch (Exception e) { Log.Write("verification row: " + e.GetType().Name); result = new ImportConnection { Reason = Lang.T("بررسی این حساب کامل نشد؛ مسیر نصب و دسترسی بروکر را بررسی کنید.", "This account could not be checked; check the terminal installation and broker access.") }; }
                    try { Finish(job, result); }
                    catch (Exception e) { paused = true; Log.Write("verification save failed: " + e.GetType().Name); try { Pause(); } catch { } Notify(); }
                }
            }
            finally { if (verifier != null) verifier.Dispose(); }
        }
        public void Pause()
        {
            paused = true;
            lock (accounts.Sync)
            {
                foreach (Account a in accounts.All.Where(x => x.VerifyState == "queued" || x.VerifyState == "retry" || x.VerifyState == "checking"))
                { if (a.VerifyState == "checking") a.VerifyPass = Math.Max(0, a.VerifyPass - 1); a.VerifyState = "paused"; a.VerifyToken = ""; accounts.SetQueue(a); }
                accounts.Save();
            }
            Notify();
        }
        public void Recheck(string instance) { RecheckMany(new[] { instance }); }
        public void RecheckMany(IEnumerable<string> instances)
        {
            lock (accounts.Sync)
            {
                foreach (string instance in instances.Distinct(StringComparer.OrdinalIgnoreCase))
                {
                    Account a = accounts.Get(instance);
                    if (a == null) continue;
                    a.VerifyState = "queued"; a.VerifyToken = ""; a.VerifyPass = 0; a.VerifyUtc = ""; accounts.SetQueue(a);
                }
                accounts.Save(); paused = false;
            }
            Notify(); wake.Set();
        }
        public void Resume(bool retryFailed)
        {
            lock (accounts.Sync)
            {
                foreach (Account a in accounts.All.Where(x => x.VerifyState == "paused" || (retryFailed && (x.VerifyState == "rejected" || x.VerifyState == "unconfirmed"))))
                { a.VerifyState = "queued"; a.VerifyToken = ""; a.VerifyPass = 0; accounts.SetQueue(a); }
                accounts.Save(); paused = false;
            }
            Notify(); wake.Set();
        }
        public static string Status(string value)
        {
            switch (value)
            {
                case "queued": return Lang.T("در صف بررسی", "Queued");
                case "checking": return Lang.T("در حال بررسی", "Checking");
                case "retry": return Lang.T("در صف بررسی تکمیلی", "Deferred check");
                case "connected": return Lang.T("اتصال تأیید شد", "Login verified");
                case "rejected": return Lang.T("حساب یا رمز رد شد", "Credentials rejected");
                case "paused": return Lang.T("متوقف", "Paused");
                default: return Lang.T("نیاز به بررسی", "Needs review");
            }
        }
        public void Export(string path)
        {
            var rows = new List<string[]> { new[] { "Name", "Platform", "Login", "Server", "Status", "Reason", "VerifiedUtc" } };
            rows.AddRange(accounts.All.Where(a => a.VerifyState.Length > 0).Select(a => new[] { a.Trader, a.Platform, a.Login, a.Server, Status(a.VerifyState), a.VerifyReason, a.VerifyUtc }));
            Spreadsheet.Write(path, rows);
        }
        void Notify() { var changed = Changed; if (changed != null) { try { changed(); } catch { } } }
        public void Dispose()
        {
            if(Interlocked.Exchange(ref disposeStarted,1)!=0)return;
            stopping = true; wake.Set();
            try { if (Task.WaitAll(workers.ToArray(), 8000)) wake.Dispose(); } catch { }
        }
    }
}
