using System;using System.Collections.Generic;using System.Linq;using System.Web.Script.Serialization;
namespace MTManager
{
    public enum ImportChange { Credentials, Metadata, None }
    public static class ImportFlow
    {
        const string GroupPrefix="@MF_GROUPS_V1:";
        public static string[] Groups(string value)
        {
            if(string.IsNullOrWhiteSpace(value))return new string[0];
            string[] values;
            if(value.StartsWith(GroupPrefix,StringComparison.Ordinal)||value.TrimStart().StartsWith("[",StringComparison.Ordinal))
            {
                try{string json=value.StartsWith(GroupPrefix,StringComparison.Ordinal)?value.Substring(GroupPrefix.Length):value;values=new JavaScriptSerializer{MaxJsonLength=16384}.Deserialize<string[]>(json);}
                catch{throw new UserMessage("فهرست پوشه‌ها خوانده نشد؛ اطلاعات قبلی حفظ شد.");}
            }
            else values=value.Split('|');
            values=(values??new string[0]).Select(s=>TextUtil.OneLine(s??"").Trim()).Where(s=>s.Length>0).Distinct(StringComparer.Ordinal).ToArray();
            if(values.Length>50||values.Any(s=>s.Length>FolderStore.MaxName))throw new UserMessage("نام یا تعداد پوشه‌های ورودی معتبر نیست.");
            return values;
        }
        public static string[] PendingGroups(string value)
        {return string.IsNullOrWhiteSpace(value)?new string[0]:value.StartsWith(GroupPrefix,StringComparison.Ordinal)?Groups(value):new[]{value};}
        public static string[] RequestedGroups(StudentImportRow row)
        {return Groups(row.AllFolders).Concat(string.IsNullOrWhiteSpace(row.Folder)?new string[0]:new[]{row.Folder.Trim()}).Distinct(StringComparer.Ordinal).ToArray();}
        public static string EncodeGroups(IEnumerable<string> groups)
        {var list=groups.Where(s=>!string.IsNullOrWhiteSpace(s)).Distinct(StringComparer.Ordinal).ToArray();return list.Length==0?"":GroupPrefix+new JavaScriptSerializer().Serialize(list);}
        public static string ExportGroups(IEnumerable<string> groups)
        {var list=groups.ToArray();return list.Any(g=>g.Contains("|")||g.TrimStart().StartsWith("["))?new JavaScriptSerializer().Serialize(list):string.Join(" | ",list);}
        static bool PasswordDiff(string incoming,string stored)
        {return !string.IsNullOrEmpty(incoming)&&!string.Equals(incoming,Secret.Unprotect(stored??""),StringComparison.Ordinal);}
        public static bool SameLogin(StudentImportRow row,Account old)
        {return StudentImport.Key(row.Kind,row.Login,row.Server)==StudentImport.Key(StudentDirectory.KindOf(old),old.Login,old.Server)&&row.Kind==StudentDirectory.KindOf(old)&&string.Equals(row.Server,old.Server,StringComparison.OrdinalIgnoreCase)&&row.Mode==old.Mode;}
        public static ImportChange Classify(StudentImportRow row,Account old,FolderStore folders)
        {
            if(!SameLogin(row,old)||PasswordDiff(row.Investor,old.InvestorEnc)||PasswordDiff(row.Master,old.MasterEnc)||row.ForceRecheck)return ImportChange.Credentials;
            bool groups=false;
            if(row.FoldersApproved&&folders!=null)lock(folders)
            {
                var requested=RequestedGroups(row);
                bool readable;FolderStore.Load(out readable);if(!readable&&requested.Length>0)throw new UserMessage("فایل پوشه‌ها خوانده نشد؛ عضویت‌های قبلی حفظ شد.");
                foreach(string group in requested)if(folders.Find(group)==null&&folders.NameProblem(group)!=null)throw new UserMessage(folders.NameProblem(group));
                groups=requested.Any(name=>{var f=folders.Find(name);return f==null||!folders.Has(f.Id,old.Instance);});
            }
            return row.Name!=old.Trader||row.OriginalName.Length>0&&row.OriginalName!=old.OriginalTrader||groups?ImportChange.Metadata:ImportChange.None;
        }
        public static void NormalizeExisting(StudentImportRow row,Account old)
        {
            if(!row.ModeExplicit&&row.SelectedPassword.Length==0)row.Mode=old.Mode;
            if(row.Kind!=StudentDirectory.KindOf(old))throw new UserMessage("پلتفرم متفاوت است؛ قبلی حفظ شد. MT4/MT5 را بررسی کنید.");
            if(!SameLogin(row,old)&&row.SelectedPassword.Length==0)throw new UserMessage("برای تغییر سرور یا نوع ورود، رمز همان نوع ورود لازم است؛ قبلی حفظ شد.");
        }
        public static Account Job(StudentImportRow row,string mode=null)
        {
            Account old=row.ReplacementAccount;
            var job=new Account{Instance="import-preview",Platform=row.Platform,Login=row.Login,Server=row.Server,ImportServers=row.ImportServers,Mode=mode??row.Mode,VerifyToken=Guid.NewGuid().ToString("N")};
            job.InvestorEnc=row.Investor.Length>0?Secret.Protect(row.Investor):old==null?"":old.InvestorEnc;
            job.MasterEnc=row.Master.Length>0?Secret.Protect(row.Master):old==null?"":old.MasterEnc;
            return job;
        }
        public static bool OtherPasswordChanged(StudentImportRow row)
        {var old=row.ReplacementAccount;return row.Mode=="investor"?old==null?row.Master.Length>0:PasswordDiff(row.Master,old.MasterEnc):old==null?row.Investor.Length>0:PasswordDiff(row.Investor,old.InvestorEnc);}
        public static Account Updated(StudentImportRow row,Account current,string verifiedServer,bool credentialsVerified)
        {
            var updated=current.Snapshot();updated.Trader=row.Name;updated.OriginalTrader=row.OriginalName.Length==0?current.OriginalTrader:row.OriginalName;
            if(credentialsVerified)
            {
                updated.Login=row.Login;updated.Server=verifiedServer;updated.Mode=row.Mode;updated.ImportServers="";
                if(PasswordDiff(row.Investor,current.InvestorEnc))updated.InvestorEnc=Secret.Protect(row.Investor);
                if(PasswordDiff(row.Master,current.MasterEnc))updated.MasterEnc=Secret.Protect(row.Master);
                updated.VerifyState="connected";updated.VerifyUtc=DateTime.UtcNow.ToString("o",System.Globalization.CultureInfo.InvariantCulture);updated.VerifyToken="";updated.VerifyPass=0;updated.VerifyReason="ورود با اطلاعات این ردیف تأیید شد.";
            }
            if(row.FoldersApproved)updated.ImportGroup=EncodeGroups(PendingGroups(current.ImportGroup).Concat(RequestedGroups(row)));
            return updated;
        }
        public static bool Retryable(StudentImportRow row)
        {return !row.Saved&&(row.State==ImportState.Unconfirmed||row.State==ImportState.Cancelled||row.State==ImportState.Blocked||row.State==ImportState.Failed&&row.Outcome!=Login.WrongLogin);}
        public static string Action(StudentImportRow row)
        {return row.Excluded?"Skipped":row.State==ImportState.Unchanged?"Unchanged":row.MetadataOnly?(row.Saved?"Metadata updated":"Metadata pending"):row.Replaced?row.ForceRecheck?"Rechecked":"Replaced":row.ExistingCopy.Length>0?"Existing retained":row.Saved?"Added":"Not added";}
    }
}
