// MT Manager 3.15: reading the students' trade history for the report.
// For each account a report copy of MetaTrader (the program's own, never a student's) logs in with the login password,
// runs the read-only report script once and writes the history to a file; the program keeps it on this computer and closes it.
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;

namespace MTManager
{
    public enum StepState { Waiting, Starting, Reading, Done, Failed, Skipped, Retrying }

    // ================================================================== how many at once

    /// <summary>How many report copies run at the same time: one, or two where the computer has room for them.</summary>
    public static class ReportParallel
    {
        public const int Max = 2;

        /// <summary>The setting: 0 automatic, 1 one at a time, 2 two at a time.</summary>
        public static int Clamp(int n) { return Math.Max(0, Math.Min(Max, n)); }

        /// <summary>Automatic: two only with four or more processor threads, about 8 GB of memory or more, and 2.5 GB free now;
        /// otherwise one; actual free memory is checked again before a cold start.</summary>
        public static int Auto(int processors, ulong totalMb, ulong freeMb)
        {
            return processors >= 4 && totalMb >= 7500 && freeMb >= 2500 ? 2 : 1;
        }

        public static int For(Settings s, int jobs)
        {
            int n = s.ReportAtOnce >= 1 ? Math.Min(Max, s.ReportAtOnce) : Auto(Environment.ProcessorCount, Checks.TotalRamMb(), Checks.FreeRamMb());
            return Math.Max(1, Math.Min(n, Math.Max(1, jobs)));
        }
    }

    // ================================================================== the script: built once with MetaEditor

    public static class ReportScript
    {
        static string Source(Kind k) { return ReportLaunch.Script + (k == Kind.MT5 ? ".mq5" : ".mq4"); }

        public static string Binary(Kind k) { return ReportLaunch.Script + (k == Kind.MT5 ? ".ex5" : ".ex4"); }

        /// <summary>Under the copies folder, next to the report copies: a plain path MetaEditor reads without trouble.</summary>
        public static string WorkDir(Settings s) { return Path.Combine(ReportLaunch.ReportRoot(s.BaseDir), "build"); }

        public static string Built(Settings s, Kind k) { return Path.Combine(WorkDir(s), Binary(k)); }

        /// <summary>The script's code, inside the program.</summary>
        public static string SourceText(Kind k)
        {
            using (Stream st = Assembly.GetExecutingAssembly().GetManifestResourceStream(Source(k)))
            {
                if (st == null) throw new UserMessage(Lang.T("کد اسکریپت گزارش داخل برنامه نیست.", "The report script's code is not inside the program."));
                using (var r = new StreamReader(st)) return r.ReadToEnd();
            }
        }

        public static string Stamp(string text)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(text))).Replace("-", "");
        }

        /// <summary>MetaEditor of an installed MetaTrader (the program's copies leave it out); for MT4 also the one MetaTrader
        /// downloaded for its own update.</summary>
        public static string FindEditor(Kind k, Settings s)
        {
            string[] names = k == Kind.MT5 ? new[] { "metaeditor64.exe", "MetaEditor64.exe" } : new[] { "metaeditor.exe", "MetaEditor.exe" };
            var dirs = new List<string>(Installs.Find(k, s));
            string cache = TerminalUpdate.CacheDir(k);
            if (cache != null) dirs.Add(cache);
            dirs.AddRange(Installs.Copies(s).Where(c => c.Kind == k).Select(c => c.Dir));
            foreach (string d in dirs)
                foreach (string n in names)
                {
                    string p = Path.Combine(d, n);
                    if (File.Exists(p)) return p;
                }
            return null;
        }

        public static bool Ready(Settings s, Kind k)
        {
            string stamp = Built(s, k) + ".stamp";
            try { return File.Exists(Built(s, k)) && File.Exists(stamp) && File.ReadAllText(stamp) == Stamp(SourceText(k)); }
            catch { return false; }
        }

        /// <summary>Legacy compilation-failure marker for diagnostics only; Build never executes an old binary as a fallback.</summary>
        public static bool OnOlder(Settings s, Kind k)
        {
            string failed = Built(s, k) + ".failed";
            try { return File.Exists(Built(s, k)) && File.Exists(failed) && File.ReadAllText(failed) == Stamp(SourceText(k)); }
            catch { return false; }
        }

        /// <summary>Builds the script once per version of it; throws with MetaEditor's own report when that fails.</summary>
        public static void Build(Settings s, Kind k, Func<bool> cancel = null)
        {
            if (Ready(s, k)) return;
            string editor = FindEditor(k, s);
            if (editor == null)
                throw new UserMessage(Lang.T("برای ساختن اسکریپت گزارش ", "To build the report script for ") + k + Lang.T("، MetaEditor لازم است ولی پیدا نشد. یک ", ", MetaEditor is needed but was not found. Install ") + k + Lang.T(" را به روش معمول نصب کنید (MetaEditor همراهش نصب می‌شود) و دوباره امتحان کنید.", " the usual way (MetaEditor comes with it) and try again."));
            string dir = WorkDir(s);
            Directory.CreateDirectory(dir);
            string text = SourceText(k);
            string src = Path.Combine(dir, Source(k)), bin = Built(s, k), log = Path.Combine(dir, ReportLaunch.Script + "-" + k + ".log");
            File.WriteAllText(src, text, Encoding.ASCII);
            // Preserve the previous binary for recovery; never execute it after a failed current build.
            string prev = bin + ".prev";
            try { if (File.Exists(bin)) { File.Copy(bin, prev, true); File.Delete(bin); } }
            catch (Exception e) { throw new UserMessage(Lang.T("فایل اسکریپت قدیمی آزاد نیست؛ نسخهٔ جدید اجرا نشد: ", "The old reporter binary is locked; the new version was not started: ") + e.Message); }
            try { if (File.Exists(log)) File.Delete(log); } catch { }
            Log.Write("building the report script for " + k + " with " + editor);
            var psi = new ProcessStartInfo(editor, "/compile:\"" + src + "\" /log:\"" + log + "\"")
            {
                UseShellExecute = false, CreateNoWindow = true, WorkingDirectory = Path.GetDirectoryName(editor),
            };
            using (Process p = Process.Start(psi))
            {
                var clock = Stopwatch.StartNew();
                try
                {
                    while (!p.WaitForExit(100))
                    {
                        if (cancel != null && cancel()) throw new OperationCanceledException();
                        if (clock.ElapsedMilliseconds >= 120000) throw new UserMessage(Lang.T("ساخت اسکریپت بیش از دو دقیقه طول کشید.", "Script compilation exceeded two minutes."));
                    }
                }
                finally { if (!p.HasExited) { try { p.Kill(); p.WaitForExit(1000); } catch { } } }
            }
            string report = TextFiles.ReadText(log) ?? "";
            Log.Write("report script build " + k + ": " + TextUtil.OneLine(report));
            if (!File.Exists(bin))
            {
                if (File.Exists(prev))
                {
                    File.WriteAllText(bin + ".failed", Stamp(text));
                    Log.Write("report script " + k + ": compilation failed; old script was preserved but will not be executed.");
                }
                throw new UserMessage(Lang.T("ساختن اسکریپت گزارش ", "Building the report script for ") + k + Lang.T(" نشد. گزارش MetaEditor:\n\n", " failed. MetaEditor's output:\n\n") + Tail(report, 1500) + Lang.T("\n\nاین متن را برای پشتیبانی بفرستید.", "\n\nSend this text to support."));
            }
            File.WriteAllText(bin + ".stamp", Stamp(text));
            try { if (File.Exists(bin + ".failed")) File.Delete(bin + ".failed"); } catch { }
        }

        static string Tail(string s, int max)
        {
            s = (s ?? "").Trim();
            return s.Length <= max ? s : "…" + s.Substring(s.Length - max);
        }

        public static string Target(Instance report) { return Path.Combine(report.Dir, Kinds.Mql(report.Kind), report.Kind == Kind.MT5 ? "Experts" : "Scripts", Binary(report.Kind)); }

        /// <summary>Puts the built script into a report copy (MQL5\Scripts or MQL4\Scripts) when it is missing or different.</summary>
        public static bool Deploy(Settings s, Instance report)
        {
            string bin = Built(s, report.Kind), dest = Target(report);
            if (!Ready(s, report.Kind)) return false;
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(dest));
                File.Copy(bin, dest, true);
                File.SetLastWriteTimeUtc(dest, File.GetLastWriteTimeUtc(bin));
                return true;
            }
            catch (Exception e)
            {
                Log.Write("report script into " + report.Name + ": " + e.Message);
                return false;
            }
        }
    }

    // ================================================================== the report copies

    /// <summary>The program's own MetaTraders for reading history, under the copies folder in _MTManager\report: one for each
    /// platform, server and place (one or two run at once). Each is made once from a student copy of the same server (so it knows
    /// that server), without its history, logs, saved logins and start file. A student's copy itself never gets the script.</summary>
    public static class ReportCopies
    {
        static bool Eq(string a, string b) { return string.Equals(a, b, StringComparison.OrdinalIgnoreCase); }

        /// <summary>A server name as a folder name: letters, digits, dot, dash and underscore.</summary>
        public static string Safe(string server)
        {
            var sb = new StringBuilder();
            foreach (char c in (server ?? "").Trim())
                sb.Append((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '.' || c == '-' || c == '_' ? c : '_');
            string s = sb.ToString().Trim('.', '_');
            if (s.Length > 40) s = s.Substring(0, 40);
            return s.Length == 0 ? "server" : s;
        }

        public static string Name(Kind k, string server, int slot) { return k + "-" + Safe(server) + "-" + slot; }

        public static Instance For(Settings s, Kind k, string server, int slot)
        {
            string name = Name(k, server, slot);
            return new Instance { Name = "report-" + name, Kind = k, Dir = Path.Combine(ReportLaunch.ReportRoot(s.BaseDir), name) };
        }

        /// <summary>What a report copy leaves out of the copy it is made from (path inside the copy, with \ or /): its bar and tick
        /// history (bases, history: the terminal fetches what it needs), logs, the tester, set-aside charts, the files and logs of
        /// its programs, saved logins (config\accounts.*), a start file, and the extra tools at the top (MetaEditor, uninstall, archives).</summary>
        public static bool Skip(string relative, bool isDir, Kind k)
        {
            string[] p = (relative ?? "").Split('\\', '/').Where(x => x.Length > 0).ToArray();
            if (p.Length == 0) return false;
            if (p.Length == 1)
            {
                // The private MT5 reporter deploys its own expert and empty chart profile.
                // Student indicators, libraries, EAs and profiles are neither needed nor executed.
                if (isDir && k == Kind.MT5 && new[] { "MQL5", "Profiles", "templates", "sounds" }.Any(x => Eq(x, p[0]))) return true;
                if (isDir) return new[] { "logs", "tester", "bases", "history", "MTManager-backup" }.Any(x => Eq(x, p[0]));
                return Lean.IsExtraFile(p[0]) || Eq(p[0], Launcher.StartFileName) || p[0].EndsWith(".mtm-new", StringComparison.OrdinalIgnoreCase);
            }
            if (p.Length == 2 && isDir && Eq(p[0], Kinds.Mql(k))) return Eq(p[1], "Files") || Eq(p[1], "Logs");
            if (p.Length == 2 && !isDir && Eq(p[0], "config")) return Eq(p[1], "accounts.dat") || Eq(p[1], "accounts.ini");
            return false;
        }

        /// <summary>Copies a student copy into a report copy (see Skip). A file the running terminal holds is left out and counted;
        /// throws when the terminal itself could not be copied.</summary>
        public static int CopyFrom(Instance source, string dest, Func<bool> cancel = null)
        {
            int locked = 0;
            Copy(source.Dir, dest, "", source.Kind, ref locked, cancel);
            if (!File.Exists(Path.Combine(dest, Kinds.Exe(source.Kind))))
                throw new UserMessage(Lang.T("فایل ", "File ") + Kinds.Exe(source.Kind) + Lang.T(" از ", " of ") + source.Name + Lang.T(" کپی نشد.", " was not copied."));
            PortableServers.Sync(source.Dir, dest, source.Kind);
            return locked;
        }

        static void Copy(string from, string to, string rel, Kind k, ref int locked, Func<bool> cancel)
        {
            if (cancel != null && cancel()) throw new OperationCanceledException();
            Directory.CreateDirectory(to);
            foreach (string f in Directory.GetFiles(from))
            {
                string name = Path.GetFileName(f);
                if (Skip(rel.Length == 0 ? name : rel + "\\" + name, false, k)) continue;
                try
                {
                    using (var input = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                    using (var output = File.Create(Path.Combine(to, name)))
                    {
                        var bytes = new byte[65536]; int n;
                        while ((n = input.Read(bytes, 0, bytes.Length)) > 0) { if (cancel != null && cancel()) throw new OperationCanceledException(); output.Write(bytes, 0, n); }
                    }
                }
                catch (IOException e)
                {
                    locked++;
                    Log.Write("report copy: left out " + (rel.Length == 0 ? name : rel + "\\" + name) + " (" + e.Message + ")");
                }
            }
            foreach (string d in Directory.GetDirectories(from))
            {
                string name = Path.GetFileName(d), r = rel.Length == 0 ? name : rel + "\\" + name;
                if (Skip(r, true, k)) continue;
                Copy(d, Path.Combine(to, name), r, k, ref locked, cancel);
            }
        }

        /// <summary>The copy to make a report copy from: one of the same platform whose account is on the same server, a closed one
        /// first (nothing in it is in use), the student's own first among equals.</summary>
        public static Instance PickSource(IEnumerable<Instance> copies, Func<string, Account> account, Kind k, string server, Instance own, Func<Instance, bool> running)
        {
            var same = copies.Where(c =>
            {
                if (c.Kind != k) return false;
                Account a = account(c.Name);
                return a != null && a.HasLogin && Eq((a.Server ?? "").Trim(), (server ?? "").Trim());
            }).ToList();
            if (own != null && !same.Any(c => Eq(c.Name, own.Name))) same.Add(own);
            return same.OrderBy(c => running(c) ? 1 : 0).ThenBy(c => own != null && Eq(c.Name, own.Name) ? 0 : 1).FirstOrDefault() ?? own;
        }

        /// <summary>The report copy for a platform, server and place: made the first time, and afterwards kept at the build of the
        /// student copies (its terminal and the files beside it), so it does not stop to update itself in the middle of a report.</summary>
        public static Instance Prepare(Settings s, Kind k, string server, int slot, Func<Instance> source, Func<bool> cancel = null)
        {
            Instance rc = For(s, k, server, slot);
            if (!File.Exists(rc.Exe))
            {
                Instance src = source();
                if (src == null) throw new UserMessage(Lang.T("نسخه‌ای از ", "No installation of ") + k + Lang.T(" برای ساختن متاتریدر گزارش پیدا نشد.", " was found to make the report MetaTrader."));
                Directory.CreateDirectory(ReportLaunch.ReportRoot(s.BaseDir));
                string stage = rc.Dir + ".prepare-" + Guid.NewGuid().ToString("N");
                int locked;
                try
                {
                    locked = CopyFrom(src, stage, cancel);
                    if (cancel != null && cancel()) throw new OperationCanceledException();
                    if (Directory.Exists(rc.Dir)) Directory.Move(rc.Dir, rc.Dir + ".incomplete-" + Guid.NewGuid().ToString("N"));
                    Directory.Move(stage, rc.Dir);
                }
                finally { try { if (Directory.Exists(stage)) Directory.Delete(stage, true); } catch { } }
                Log.Write("report copy " + rc.Name + " made from " + src.Name + (locked > 0 ? " (" + locked + " files in use left out)" : ""));
                return rc;
            }
            Instance from = null;
            try { from = source(); }
            catch (Exception e) { Log.Write("report copy " + rc.Name + ": " + e.Message); }
            if (from != null && TerminalUpdate.Newer(TerminalUpdate.FileVersion(from.Exe), TerminalUpdate.FileVersion(rc.Exe)))
            {
                int n = 0;
                foreach (string f in Directory.GetFiles(from.Dir))
                {
                    string name = Path.GetFileName(f);
                    if (Skip(name, false, k)) continue;
                    try { File.Copy(f, Path.Combine(rc.Dir, name), true); n++; }
                    catch (IOException e) { Log.Write("report copy update: " + name + " (" + e.Message + ")"); }
                }
                Log.Write("report copy " + rc.Name + " brought to the build of " + from.Name + " (" + n + " files)");
            }
            return rc;
        }

        /// <summary>Start files a report copy may still have when the program was closed in the middle of a report.</summary>
        public static void DeleteLeftovers(Settings s)
        {
            string root = ReportLaunch.ReportRoot(s.BaseDir);
            if (!Directory.Exists(root)) return;
            foreach (string d in Directory.GetDirectories(root)) Launcher.DeleteStartFile(Path.Combine(d, ReportLaunch.StartFileName));
        }
    }

    // ================================================================== one report run

    /// <summary>One student's read: the history, or why there is none.</summary>
    public sealed class ReportRow
    {
        public string Name = "", Login = "", Server = "", Platform = "", Folders = "", Copy = "";
        public AccountJournal Journal;
        public JournalSummary Summary;
        /// <summary>Why the history could not be read; null when it was.</summary>
        public string Error;
        public bool Cached, Cancelled, Retryable;
        public int Attempts = 1;
        public long ReadMs, TotalMs;
        public string Route = "script";
        /// <summary>When the history is the copy kept on this computer (a new read did not work): «از کش» and its time.</summary>
        public string Note;

        public static string CacheNote(DateTime exported) { return Lang.T("از کش (", "From cache (") + Gd.At(exported) + ")"; }
    }

    /// <summary>One student to read: the copy, its account, and the limits that hold for it.</summary>
    public sealed class ReportJob
    {
        public int Attempt = 1;
        public Stopwatch Clock;
        public int Index;
        public Instance Copy;
        public Account Account;
        public string Name = "", Folders = "";
        public TradeLimits Limits = new TradeLimits();
        /// <summary>3.21: the first server day to read for this student (the report's own first day when not set).</summary>
        public DateTime From;
    }

    /// <summary>Reads the students one after another (or two at a time) in report copies, on threads of its own.
    /// Changed tells each step (from those threads). Every MetaTrader it opens is recorded as opened here and closed by it.</summary>
    public sealed class ReportRunner
    {
        readonly Settings settings;
        readonly List<ReportJob> jobs;
        readonly List<Instance> copies;
        /// <summary>The accounts as they were when the report began (the window may change them meanwhile).</summary>
        readonly Func<string, Account> accountOf;
        readonly ReportRange range;
        public readonly int Parallel;
        public Action<int, StepState, string> Changed;
        public Action<int, ReportRow> ResultReady;
        /// <summary>A line about the whole run (the script being built the first time).</summary>
        public Action<string> Note;
        /// <summary>Why the script could not be built, per platform (MetaEditor's report): shown once at the end.</summary>
        public readonly Dictionary<Kind, string> ScriptProblems = new Dictionary<Kind, string>();
        volatile bool stop, ending;
        readonly List<Process> live = new List<Process>();
        static readonly object Mt4Gate = new object();
        /// <summary>3.19: report MetaTraders start 1.5 seconds apart at least, MT4 and MT5, one or two at a time.</summary>
        static readonly StartPacer Pacer = new StartPacer();
        /// <summary>3.19: the most memory each report MetaTrader held (MB), for the log at the end of the run.</summary>
        readonly List<long> peaks = new List<long>();
        ReportRow[] rows;
        readonly Func<ReportJob, int, ReportRow> readOverride;

        sealed class WarmTerminal { public Instance Copy; public Process Process; public ReportLoginSession Login; public string Server; }
        readonly ConcurrentDictionary<int, WarmTerminal> warm = new ConcurrentDictionary<int, WarmTerminal>();
        readonly ConcurrentDictionary<string, bool> noWarm = new ConcurrentDictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
        readonly ConcurrentDictionary<string, Lazy<string>> mt5Installs = new ConcurrentDictionary<string, Lazy<string>>(StringComparer.OrdinalIgnoreCase);

        // Cache discovery only for this report run, not across installs or user configuration changes.
        string Mt5Install(string server)
        {
            return mt5Installs.GetOrAdd(server.Trim(), key => new Lazy<string>(() =>
            {
                try { return StudentImportRuntime.FindWithDeadline(() => { bool exact; return ServerCatalog.InstallFor(Kind.MT5, key, settings, out exact); }, () => ending, 15000); }
                catch (TimeoutException) { Log.Write("MT5 installed-broker discovery exceeded 15s; using existing private configuration."); return null; }
            })).Value;
        }

        T Mt5Stage<T>(ReportJob job, string code, string label, Func<T> work)
        {
            if (job.Copy.Kind != Kind.MT5) return work();
            var clock = Stopwatch.StartNew(); var sync = new object(); bool finished = false;
            Action display = () => Say(job.Index, StepState.Starting, label + " — " + Fa.N((int)clock.Elapsed.TotalSeconds) + Lang.T(" ثانیه", " s"));
            Log.Write("MT5 prepare begin: " + job.Copy.Name + " " + code);
            display();
            using (var timer = new Timer(_ => { lock (sync) { if (!finished) display(); } }, null, 1000, 1000))
                try { if (ending) throw new OperationCanceledException(); return work(); }
                finally
                {
                    lock (sync) finished = true;
                    Log.Write("MT5 prepare end: " + job.Copy.Name + " " + code + " elapsed=" + clock.ElapsedMilliseconds + "ms");
                }
        }

        internal static bool Mt5HasCatalog(Instance copy)
        {
            try
            {
                string path = Path.Combine(PortableServers.Subdirectory(copy.Dir, "config"), "servers.dat");
                return File.Exists(path) && new FileInfo(path).Length > 0;
            }
            catch { return false; }
        }

        void Mt5RefreshCatalog(ReportJob job, Instance rc)
        {
            // This copy was just checked closed by EndLeftover. Prefer the student's broker
            // catalog; only discover installed terminals when missing, or on the deferred retry.
            if (Mt5HasCatalog(job.Copy)) PortableServers.Sync(job.Copy.Dir, rc.Dir, Kind.MT5, job.Account.Server, () => ending, _ => null);
            if (!Mt5HasCatalog(rc) || job.Attempt > 1)
            {
                string native = Mt5Install(job.Account.Server);
                if (native != null) PortableServers.Sync(native, rc.Dir, Kind.MT5, job.Account.Server, () => ending);
            }
        }

        internal static List<string> SelectMt5Symbols(Func<List<string>> student, Func<List<string>> report, Func<List<string>> installed, ICollection<string> tried)
        {
            var known = student();
            if (ReportLaunch.PickSymbol(null, known, tried) == null) known.AddRange(report());
            if (ReportLaunch.PickSymbol(null, known, tried) == null) known.AddRange(installed());
            return known.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        List<string> Mt5Symbols(ReportJob job, Instance rc, ICollection<string> tried)
        {
            // A known, untried broker symbol suffices. Consult other copies on a chart retry.
            return SelectMt5Symbols(() => ReportLaunch.KnownSymbols(job.Copy, job.Account.Server),
                () => ReportLaunch.KnownSymbols(rc, job.Account.Server), () =>
            {
                var known = new List<string>();
                string native = Mt5Install(job.Account.Server);
                if (native != null) foreach (string root in PortableServers.Roots(native))
                    known.AddRange(ReportLaunch.KnownSymbols(new Instance { Kind = Kind.MT5, Dir = root }, job.Account.Server));
                return known;
            }, tried);
        }
        string WarmKey(int slot, string server) { return slot + "|" + (server ?? ""); }
        bool CanWarm(int slot, Instance rc) { return rc.Kind == Kind.MT5 && Environment.OSVersion.Platform == PlatformID.Win32NT && Environment.Is64BitOperatingSystem && !noWarm.ContainsKey(WarmKey(slot, rc.Dir)); }
        void CloseWarm(int slot)
        {
            WarmTerminal previous; if (!warm.TryGetValue(slot, out previous)) return;
            warm.TryRemove(slot, out previous); if (previous == null) return; previous.Login.Dispose(); End(previous.Process, previous.Copy);
            lock (live) live.Remove(previous.Process);
            EndLeftover(previous.Copy); previous.Process.Dispose();
        }
        public static int[] Schedule(IList<ReportJob> jobs, IEnumerable<int> indices)
        {
            return indices.GroupBy(n => jobs[n].Copy.Kind + "|" + (jobs[n].Account.Server ?? "").Trim().ToUpperInvariant()).SelectMany(g => g).ToArray();
        }
        public ReportRunner(Settings settings, List<ReportJob> jobs, List<Instance> copies, Func<string, Account> accountOf, ReportRange range, int parallel, Func<ReportJob, int, ReportRow> read = null)
        {
            readOverride = read;
            this.settings = settings;
            this.jobs = jobs;
            this.copies = copies;
            this.accountOf = accountOf;
            this.range = range;
            Parallel = Math.Max(1, Math.Min(ReportParallel.Max, parallel));
        }

        /// <summary>Starts no one new; those being read are finished.</summary>
        public void Stop() { stop = true; }

        public bool Stopping { get { return stop; } }

        /// <summary>The program is closing: the report MetaTraders open now are ended at once.</summary>
        public void EndNow()
        {
            stop = true;
            ending = true;
            List<Process> now;
            lock (live) now = live.ToList();
            foreach (Process p in now)
            {
                try { if (!p.HasExited) p.Kill(); } catch { }
            }
        }

        void Say(int k, StepState state, string detail)
        {
            if (k >= 0 && k < jobs.Count && jobs[k].Clock != null) Log.Write("report stage: " + jobs[k].Copy.Name + " " + state + " at " + jobs[k].Clock.ElapsedMilliseconds + "ms");
            Action<int, StepState, string> c = Changed;
            if (c == null) return;
            try { c(k, state, detail); } catch { }
        }

        /// <summary>Reads every student; returns one row each, in the order given.</summary>
        public List<ReportRow> Run()
        {
            try { return RunCore(); }
            finally { foreach (int slot in warm.Keys.ToArray()) CloseWarm(slot); }
        }
        List<ReportRow> RunCore()
        {
            rows = new ReportRow[jobs.Count];
            foreach (Kind k in (readOverride == null ? jobs.Select(j => j.Copy.Kind).Distinct() : Enumerable.Empty<Kind>()))
            {
                if (!ReportScript.Ready(settings, k))
                {
                    Action<string> n = Note;
                    if (n != null) try { n(Lang.T("ساختن اسکریپت گزارش ", "Building the report script for ") + k + Lang.T(" با MetaEditor (فقط بار اول، تا دو دقیقه)…", " with MetaEditor (first time only, up to two minutes)…")); } catch { }
                }
                try { if (ending) break; ReportScript.Build(settings, k, () => ending); }
                catch (OperationCanceledException) { break; }
                catch (UserMessage e) { ScriptProblems[k] = e.Message; }
                catch (Exception e) { ScriptProblems[k] = Lang.T("ساختن اسکریپت گزارش ", "Building the report script for ") + k + Lang.T(" نشد: ", " failed: ") + e.Message; }
                if (ScriptProblems.ContainsKey(k)) Log.Write("report script " + k + ": " + TextUtil.OneLine(ScriptProblems[k]));
            }
            Log.Write("report: " + jobs.Count + " accounts, " + Parallel + " at a time, " + range.From.ToString("yyyy-MM-dd") + " to " + range.To.AddDays(-1).ToString("yyyy-MM-dd"));
            RunPass(Schedule(jobs, Enumerable.Range(0, jobs.Count)), 1);
            if (!stop)
                RunPass(Schedule(jobs, Enumerable.Range(0, jobs.Count).Where(k => rows[k] != null && rows[k].Retryable)), 2);
            for (int k = 0; k < rows.Length; k++)
            {
                if (rows[k] == null) rows[k] = new ReportRow { Name = jobs[k].Name, Copy = jobs[k].Copy.Name, Login = jobs[k].Account.Login, Server = jobs[k].Account.Server, Platform = jobs[k].Copy.Kind.ToString(), Cancelled = true, Attempts = 0, Error = Lang.T("پیش از شروع این حساب متوقف شد.", "Stopped before this account started.") };
                Publish(k, rows[k]);
            }
            lock (peaks)
                if (peaks.Count > 0)
                    Log.Write("report memory: " + peaks.Count + " MetaTrader runs, the most one held " + peaks.Max() + " MB, on average " + (long)peaks.Average() + " MB");
            return rows.ToList();
        }

        void Publish(int index, ReportRow row)
        {
            var ready = ResultReady; if (ready != null) try { ready(index, row); } catch { }
        }
        void RunPass(int[] indices, int pass)
        {
            int cursor = -1;
            var workers = Enumerable.Range(1, Parallel).Select(slot => new Thread(() => {
                while (!stop)
                {
                    int at = Interlocked.Increment(ref cursor); if (at >= indices.Length) return;
                    int k = indices[at]; ReportJob job = jobs[k]; job.Attempt = pass; job.Clock = Stopwatch.StartNew();
                    try { rows[k] = readOverride == null ? One(job, slot) : readOverride(job, slot); rows[k].Attempts = pass; }
                    catch (OperationCanceledException) { rows[k] = NewRow(job); rows[k].Cancelled = true; rows[k].Error = Lang.T("به درخواست شما متوقف شد.", "Stopped at your request."); }
                    catch (Exception e)
                    {
                        Log.Write("report failed: " + e.GetType().Name);
                        rows[k] = Failed(job, NewRow(job), Lang.T("خطا در خواندن", "Reading error"), Lang.T("خطا در خواندن: ", "Reading error: ") + e.GetType().Name);
                    }
                    rows[k].TotalMs = job.Clock.ElapsedMilliseconds;
                    Log.Write("report timing: " + job.Copy.Name + " attempt=" + pass + " route=" + rows[k].Route + " read=" + rows[k].ReadMs + "ms total=" + rows[k].TotalMs + "ms");
                    if (rows[k].Retryable && pass == 1 && !stop) Say(k, StepState.Retrying, Lang.T("در صف یک تلاش دوباره پس از سایر حساب‌ها…", "Queued for one retry after other accounts…"));
                    else Publish(k, rows[k]);
                }
            }) { IsBackground = true, Name = "report-" + slot }).ToList();
            foreach (Thread thread in workers) thread.Start(); foreach (Thread thread in workers) thread.Join();
        }

        static ReportRow NewRow(ReportJob job)
        {
            return new ReportRow
            {
                Attempts = job.Attempt, Name = job.Name, Login = job.Account.Login.Trim(), Server = job.Account.Server ?? "", Platform = job.Copy.Kind.ToString(),
                Folders = job.Folders, Copy = job.Copy.Name,
            };
        }

        ReportRow One(ReportJob job, int slot)
        {
            Account acc = job.Account;
            Kind k = job.Copy.Kind;
            ReportRow row = NewRow(job);
            string password = acc.PasswordForLogin();
            if (password == null)
                return Failed(job, row, Lang.T("رمز ورود خوانده نمی‌شود", "The login password cannot be read"), Lang.T("رمز ورود ذخیره‌شده روی این کاربر ویندوز خوانده نمی‌شود؛ از «حساب و رمز» دوباره واردش کنید.", "The login password saved for this Windows user cannot be read; enter it again from “Account and password”."));
            if (password.Length == 0)
                return Failed(job, row, Lang.T("رمز ورود ثبت نشده", "No login password saved"), Lang.T("رمز ورود این حساب ثبت نشده؛ از «حساب و رمز» واردش کنید (گزارش با نوع رمز انتخاب‌شده خوانده می‌شود).", "This account has no login password; enter it from “Account and password” (reports use the configured login mode)."));
            string problem = PasswordRule.Problem(password);
            if (problem != null) return Failed(job, row, Lang.T("رمز ورود نادرست ذخیره شده", "The login password is saved wrongly"), Lang.T("رمز ورود: ", "Investor password: ") + problem);
            if (ScriptProblems.ContainsKey(k))
                return Failed(job, row, Lang.T("اسکریپت گزارش ", "Report script ") + k + Lang.T(" ساخته نشد", " was not built"), Lang.T("اسکریپت گزارش ", "Report script ") + k + Lang.T(" ساخته نشد: ", " was not built: ") + ScriptProblems[k]);

            Say(job.Index, StepState.Starting, Lang.T("آماده‌سازی متاتریدر گزارش…", "Preparing the report MetaTrader…"));
            Instance rc;
            WarmTerminal ready; Instance expected = ReportCopies.For(settings, k, acc.Server, slot);
            bool existing = warm.TryGetValue(slot, out ready) && string.Equals(ready.Copy.Dir, expected.Dir, StringComparison.OrdinalIgnoreCase) && string.Equals(ready.Server, acc.Server.Trim(), StringComparison.OrdinalIgnoreCase) && !HasExited(ready.Process);
            if (!existing) CloseWarm(slot);
            try
            {
                rc = Mt5Stage(job, "copy", Lang.T("آماده‌سازی فایل‌های نسخهٔ خصوصی MT5", "Preparing private MT5 files"), () => {
                Dictionary<string, Process> running = existing ? null : Processes.Running();
                return existing ? ready.Copy : ReportCopies.Prepare(settings, k, acc.Server, slot,
                    () => {
                        Instance selected = ReportCopies.PickSource(copies.Where(c => File.Exists(c.Exe)), accountOf, k, acc.Server, File.Exists(job.Copy.Exe) ? job.Copy : null, c => Processes.IsRunning(running, c.Exe));
                        if (selected != null) return selected;
                        string dir = StudentDirectory.Source(settings, k, acc.Server, () => ending || stop);
                        return dir == null ? null : new Instance { Name = "installed-broker", Kind = k, Dir = dir };
                    }, () => ending);
                });
            }
            catch (OperationCanceledException) { throw; }
            catch (UserMessage e) { return Failed(job, row, Lang.T("متاتریدر گزارش ساخته نشد", "The report MetaTrader was not made"), e.Message); }
            catch (Exception e)
            {
                Log.Write("report copy for " + acc.Login + ": " + e);
                return Failed(job, row, Lang.T("متاتریدر گزارش ساخته نشد", "The report MetaTrader was not made"), Lang.T("ساختن متاتریدر گزارش نشد: ", "Making the report MetaTrader failed: ") + e.Message);
            }

            var tried = new List<string>();
            Action<Outcome> commit = outcome => Commit(job, row, outcome);
            Outcome o = TryWarm(job, rc, slot, row, commit);
            if (o == null) { row.Route = existing ? "script-fallback" : CanWarm(slot, rc) ? "MT5-resident-start" : "script"; o = Attempt(job, rc, password, tried, slot, commit); }
            bool updated = false;
            while (o.Journal == null && !ending)
            {
                // MetaTrader closed to update itself and started again without the script: once more, now up to date.
                if (o.Retry && !updated) { updated = true; o = Attempt(job, rc, password, tried, slot, commit); continue; }
                // MT5 kept the script waiting on a chart the broker does not have: again on another of its symbols (twice at most).
                if (o.WrongSymbol != null && tried.Count < 2)
                {
                    tried.Add(o.WrongSymbol);
                    Say(job.Index, StepState.Starting, Lang.T("نماد ", "Symbol ") + o.WrongSymbol + Lang.T(" نبود؛ با نماد دیگر…", " not available; trying another symbol…"));
                    o = Attempt(job, rc, password, tried, slot, commit);
                    continue;
                }
                break;
            }
            if (ending && o.Journal == null) { row.Cancelled = true; row.Error = Lang.T("به درخواست شما متوقف شد.", "Stopped at your request."); return row; }
            if (o.Journal == null) return Failed(job, row, o.Short, o.Long, o.Transient);

            if (row.Journal == null) Commit(job, row, o);
            return row;
        }
        internal void Commit(ReportJob job, ReportRow row, Outcome o)
        {
            if (row.Journal != null) return;
            row.Journal = o.Journal;
            if (o.Journal.HistoryChecked && !o.Journal.HistoryOk) row.Note = Lang.T("گزارش تازه دریافت شد؛ کامل‌بودن تاریخچه با بالانس تأیید نشد.", "Fresh report received; history completeness could not be reconciled with the balance.");
            row.Summary = JournalMath.Summarize(o.Journal, range.From, range.To, job.Limits);
            try { JournalCache.Save(o.Journal, job.Account.Server); }
            catch (Exception e) { Log.Write("journal cache " + job.Account.Login + ": " + e.Message); }
            Say(job.Index, StepState.Done, Lang.T("خوانده شد: ", "Read: ") + Fa.N(row.Summary.Trades) + Lang.T(" معامله", " trades"));
            Log.Write("report " + job.Account.Login + ": read, " + o.Journal.Trades.Count + " trades and " + o.Journal.Open.Count + " open since " + o.Journal.From.ToString("yyyy-MM-dd") +
                      (o.Journal.ScriptVersion.Length > 0 ? ", script " + o.Journal.ScriptVersion : ", an older script") +
                      (!o.Journal.HistoryChecked ? "" : o.Journal.HistoryOk ? ", the history adds up to the balance"
                       : ", the history does not add up to the balance (" + o.Journal.HistorySum.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture) + " against " +
                         o.Journal.HistoryBalance.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture) + ")"));
            row.ReadMs = job.Clock == null ? 0 : job.Clock.ElapsedMilliseconds;
            Publish(job.Index, row);
        }

        /// <summary>When reading did not work: the last complete read kept on this computer, if it covers the range
        /// (marked «از کش» with its time); otherwise the reason.</summary>
        ReportRow Failed(ReportJob job, ReportRow row, string shortWhy, string longWhy, bool retryable = false)
        {
            row.Retryable = retryable;
            bool deferred = retryable && job.Attempt < 2 && !stop;
            AccountJournal kept = null;
            try { kept = JournalCache.Load(job.Account.Login.Trim(), job.Account.Server ?? ""); }
            catch { }
            if (JournalCache.Covers(kept, range.From))
            {
                row.Journal = kept;
                row.Summary = JournalMath.Summarize(kept, range.From, range.To, job.Limits);
                row.Cached = true; row.Note = ReportRow.CacheNote(kept.Exported) + " · " + longWhy;
                row.Error = null;
                Say(job.Index, deferred ? StepState.Retrying : StepState.Skipped, Lang.T("از کش — ", "From cache — ") + shortWhy);
                Log.Write("report " + job.Account.Login + ": " + longWhy + " The read kept from " + kept.Exported.ToString("yyyy-MM-dd HH:mm") + " is used.");
                return row;
            }
            row.Error = longWhy;
            Say(job.Index, deferred ? StepState.Retrying : StepState.Failed, shortWhy);
            Log.Write("report " + job.Account.Login + ": " + longWhy);
            return row;
        }

        public sealed class Outcome
        {
            public AccountJournal Journal;
            public string Short = "", Long = "";
            public bool Retry;
            public bool Transient;
            /// <summary>MT5: the chart's symbol on which the script was kept waiting (the broker does not have it); null otherwise.</summary>
            public string WrongSymbol;
        }

        static Outcome TransientFail(string shortWhy, string longWhy) { return new Outcome { Short = shortWhy, Long = longWhy, Transient = true }; }
        static Outcome Fail(string shortWhy, string longWhy) { return new Outcome { Short = shortWhy, Long = longWhy }; }

        DateTime FromOf(ReportJob job) { return job.From > DateTime.MinValue ? job.From : range.From; }

        static void WriteRequest(Instance copy, ReportJob job, string token)
        {
            string path = Path.Combine(copy.Dir, "MQL5", "Files", "MTManagerReport", "request.txt");
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            string temp = path + "." + token + ".tmp";
            try
            {
                File.WriteAllLines(temp, new[] { token, job.Account.Login.Trim(), job.Account.Server.Trim(), job.From.ToString("yyyy.MM.dd", System.Globalization.CultureInfo.InvariantCulture) }, Encoding.Unicode);
                if (File.Exists(path)) File.Delete(path);
                File.Move(temp, path);
            }
            finally { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
        }
        Outcome TryWarm(ReportJob job, Instance rc, int slot, ReportRow row, Action<Outcome> commit)
        {
            WarmTerminal state;
            if (!warm.TryGetValue(slot, out state) || state.Copy.Dir != rc.Dir) return null;
            if (HasExited(state.Process)) { CloseWarm(slot); return null; }
            Say(job.Index, StepState.Starting, Lang.T("ورود تازه روی متاتریدر آماده…", "Fresh login on the ready report terminal…"));
            row.Route = "MT5-warm-login";
            var clock = Stopwatch.StartNew();
            ImportConnection login = state.Login.Login(rc, job.Account, () => ending || stop);
            Log.Write("report warm login: " + job.Copy.Name + " " + clock.ElapsedMilliseconds + "ms, confirmed=" + (login != null && login.Connected));
            if (login != null && login.State == Login.WrongLogin) return Fail(Lang.T("ورود رد شد", "Login rejected"), Lang.T("سرور شماره حساب یا رمز را رد کرد.", "The server rejected the account number or password."));
            if (login == null || !login.Connected) { noWarm.TryAdd(WarmKey(slot, rc.Dir), true); CloseWarm(slot); return null; }
            string token = Guid.NewGuid().ToString("N"), output = ReportLaunch.OutputPath(rc), stepPath = ReportLaunch.StepPath(rc);
            try
            {
                foreach (string path in new[] { output, output + ".part", stepPath }) if (File.Exists(path)) File.Delete(path);
                if (job.From <= DateTime.MinValue) job.From = FromOf(job);
                WriteRequest(rc, job, token);
            }
            catch (IOException) { noWarm.TryAdd(WarmKey(slot, rc.Dir), true); CloseWarm(slot); return null; }
            clock.Restart(); string last = null;
            while (clock.ElapsedMilliseconds < 120000)
            {
                if (ending || stop) throw new OperationCanceledException();
                Outcome found = ReadOutput(output, job.Account, FromOf(job), token);
                if (found != null)
                {
                    if (found.Journal != null) { row.Route = "MT5-warm-IPC+native"; commit(found); return found; }
                    break;
                }
                string step = TextFiles.ReadText(stepPath);
                if (!string.IsNullOrWhiteSpace(step) && step != last) { last = step; Say(job.Index, StepState.Reading, ReportLaunch.StepText(step) ?? step); }
                if (HasExited(state.Process) || (last == null || last.Trim() == "ready") && clock.ElapsedMilliseconds > 5000) break;
                Thread.Sleep(100);
            }
            // Some terminals stop startup scripts on account changes. Try the supported cold path once, not an endless warm loop.
            Log.Write("report warm reporter unavailable; cold fallback for " + job.Copy.Name);
            noWarm.TryAdd(WarmKey(slot, rc.Dir), true); CloseWarm(slot); return null;
        }

        Outcome Attempt(ReportJob job, Instance rc, string password, List<string> tried, int slot, Action<Outcome> commit)
        {
            Account acc = job.Account;
            string token = Guid.NewGuid().ToString("N"); bool serve = CanWarm(slot, rc), keep = false;
            if (!Mt5Stage(job, "close-previous", Lang.T("بستن گزارش‌خوان قبلی MT5", "Closing the previous MT5 reporter"), () => EndLeftover(rc)))
                return Fail(Lang.T("متاتریدر گزارش باز ماند", "The report MetaTrader stayed open"), Lang.T("متاتریدر گزارش (", "The report MetaTrader (") + rc.Dir + Lang.T(") باز بود و بسته نشد (شاید با دسترسی مدیر اجرا شده). آن را از Task Manager ببندید و «به‌روزرسانی» را دوباره بزنید.", ") was open and did not close (perhaps it runs as administrator). Close it from Task Manager and press “Refresh” again."));
            // A cold reporter must authenticate with this request's credentials, never a saved account book.
            if (!IsReportCopy(rc)) return Fail("Invalid report copy", "A private report copy is required.");
            try
            {
                string config = Path.Combine(rc.Dir, "config");
                if (Directory.Exists(config)) foreach (string file in Directory.GetFiles(config, "accounts.*")) File.Delete(file);
            }
            catch (IOException) { return TransientFail(Lang.T("ذخیرهٔ ورود قبلی آزاد نیست", "Previous login cache is locked"), Lang.T("نسخهٔ خصوصی برای ورود تازه آماده نشد؛ اطلاعات ورود قبلی پاک نشد.", "The private terminal could not reset its previous login cache for a fresh authentication.")); }
            if (rc.Kind == Kind.MT5)
                Mt5Stage(job, "broker-catalog", Lang.T("آماده‌سازی اطلاعات سرور MT5", "Preparing MT5 server information"), () => { Mt5RefreshCatalog(job, rc); return true; });
            else PortableServers.RefreshClosed(rc, settings, acc);
            if (rc.Kind == Kind.MT4) TerminalUpdate.BeforeStart(rc);
            try { OldMonitor.Remove(rc); } catch { }
            // 3.19: no chart of its own, only the script's (the charts the terminal saved there last time are dropped).
            try { ChartProfile.UseEmpty(rc, true); }
            catch (Exception e) { Log.Write("empty profile " + rc.Name + ": " + e.Message); }
            if (!ReportScript.Deploy(settings, rc)) return Fail(Lang.T("اسکریپت در متاتریدر گزارش قرار نگرفت", "The script was not placed in the report MetaTrader"), Lang.T("اسکریپت گزارش در ", "The report script was not placed in ") + rc.Dir + Lang.T(" قرار نگرفت.", "."));

            string output = ReportLaunch.OutputPath(rc), startFile = ReportLaunch.StartFile(rc), stepFile = ReportLaunch.StepPath(rc);
            Encoding enc = rc.Kind == Kind.MT5 ? Encoding.Unicode : Encoding.Default;
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(output));
                foreach (string f in new[] { output, output + ".part", stepFile }) if (File.Exists(f)) File.Delete(f);
                foreach (string preset in ReportLaunch.PresetPaths(rc))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(preset));
                    File.WriteAllLines(preset, ReportLaunch.Preset(FromOf(job), acc, token, serve), enc);
                }
            }
            catch (Exception e) { return Fail(Lang.T("پوشه‌ی متاتریدر گزارش نوشتنی نیست", "The report MetaTrader's folder is not writable"), Lang.T("در پوشه‌ی متاتریدر گزارش نمی‌شود نوشت: ", "Cannot write in the report MetaTrader's folder: ") + e.Message); }

            if (rc.Kind == Kind.MT5) { if (job.From <= DateTime.MinValue) job.From = FromOf(job); WriteRequest(rc, job, token); }
            Process p = null;
            DateTime started;
            string symbol = null;
            // MT4 keeps at most 32 open for one Windows user: one start at a time, and only with room for it.
            bool gate = rc.Kind == Kind.MT4;
            if (gate) Monitor.Enter(Mt4Gate);
            try
            {
                if (Environment.OSVersion.Platform == PlatformID.Win32NT && !LaunchMemoryPolicy.CanStart(Checks.TotalRamMb(), Checks.FreeRamMb(), rc.Kind, 0))
                    return TransientFail(Lang.T("حافظهٔ کافی برای گزارش‌خوان بعدی نیست", "Insufficient memory for another reporter"), Lang.T("برای جلوگیری از کمبود حافظه، اجرای این گزارش‌خوان به تلاش بعدی موکول شد.", "This reporter was deferred to avoid exhausting memory."));
                if (rc.Kind == Kind.MT4 && !WaitForMt4Room(job)) return Fail(Lang.T("جای خالی برای MT4 نبود", "No free place for MT4"), Lang.T("MT4 جای خالی نداشت (حداکثر ", "MT4 had no free place (at most ") + Fa.N(Mt4Limit.Clamp(settings.MaxMt4)) + Lang.T(" هم‌زمان)؛ چند MT4 را ببندید و دوباره امتحان کنید.", " at a time); close a few MT4s and try again."));
                // The script's chart must be on a symbol the broker has, or it does not open (MT4) or never starts (MT5).
                List<string> known;
                if (rc.Kind == Kind.MT5) known = Mt5Stage(job, "chart-symbol", Lang.T("انتخاب نماد چارت MT5", "Selecting the MT5 chart symbol"), () => Mt5Symbols(job, rc, tried));
                else
                {
                known = ReportLaunch.KnownSymbols(job.Copy, acc.Server).Concat(ReportLaunch.KnownSymbols(rc, acc.Server)).ToList();
                bool exact; string native = ServerCatalog.InstallFor(rc.Kind, acc.Server, settings, out exact);
                if (native != null)
                    foreach (string root in PortableServers.Roots(native)) known.AddRange(ReportLaunch.KnownSymbols(new Instance { Kind = rc.Kind, Dir = root }, acc.Server));
                }
                known = known.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                string wanted = SymbolOf(rc);
                if (rc.Kind == Kind.MT5 && wanted == null) wanted = "EURUSD";
                symbol = ReportLaunch.PickSymbol(wanted, known, tried);
                if (symbol == null && tried.Count > 0)
                    return Fail(Lang.T("نماد چارتی برای اسکریپت نماند", "No chart symbol left for the script"),
                                Lang.T("متاتریدر ۵ اسکریپت گزارش را روی چارت ", "MetaTrader 5 kept the report script on the chart of ") + string.Join(Lang.T("، ", ", "), tried) + Lang.T(" نگه داشت و اجرا نکرد (این نمادها در این بروکر آماده نشدند) و نماد دیگری از این بروکر پیدا نشد. ", " and did not run it (these symbols were not ready at this broker), and no other symbol of this broker was found. ") +
                                Lang.T("نسخه‌ی MT5 این دانشجو را یک بار باز کنید تا فهرست نمادها (Market Watch) پر شود و دوباره گزارش بگیرید.", "Open this student's MT5 copy once so its symbol list (Market Watch) fills, then read the report again."));
                Log.Write("report: " + rc.Name + " chart " + (symbol ?? "EURUSD") + " (" + known.Count + " symbols known from the copies" +
                          (known.Count > 0 ? ": " + string.Join(", ", known.Take(6)) + (known.Count > 6 ? ", …" : "") : "") + ")" +
                          (tried.Count > 0 ? ", after " + string.Join(", ", tried) : ""));
                File.WriteAllLines(startFile, ReportLaunch.StartLines(rc.Kind, acc, password, symbol), enc);
                int waited = Pacer.Turn();
                if (waited > 0) Log.Write("report: " + rc.Name + " waited " + waited + " ms after the last start");
                started = DateTime.Now;
                try
                {
                    p = Process.Start(new ProcessStartInfo(rc.Exe, Launcher.Arguments(rc.Kind, startFile))
                    {
                        WorkingDirectory = rc.Dir, UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden,
                    });
                }
                catch (Exception e)
                {
                    Launcher.DeleteStartFile(startFile);
                    return Fail(Lang.T("متاتریدر گزارش باز نشد", "The report MetaTrader did not open"), Lang.T("متاتریدر گزارش باز نشد: ", "The report MetaTrader did not open: ") + e.Message);
                }
                if (p == null) { Launcher.DeleteStartFile(startFile); return Fail(Lang.T("متاتریدر گزارش باز نشد", "The report MetaTrader did not open"), Lang.T("متاتریدر گزارش باز نشد.", "The report MetaTrader did not open.")); }
                Owned.Add(p, rc.Exe);
                lock (live) live.Add(p);
                if (ending) { try { p.Kill(); } catch { } }
                Native.HideWindowsOf(p.Id);
            }
            finally { if (gate) Monitor.Exit(Mt4Gate); }
            if (settings.LowPriority)
            {
                try { p.PriorityClass = ProcessPriorityClass.BelowNormal; } catch { }
            }
            Log.Write("report: started " + rc.Name + " for account " + acc.Login);

            var pending = new PendingStart { Path = startFile, Time = started, Process = p, Copy = rc };
            bool reading = false, updating = false, loaded = false, chartTimeout = false;
            long peak = 0;
            string lastProblem = null, step = null;
            DateTime lastLook = DateTime.MinValue, lastStep = started;
            DateTime lastStartupDisplay = DateTime.MinValue;
            DateTime? connectedAt = null;
            try
            {
                while (true)
                {
                    DateTime now = DateTime.Now;
                    if (pending != null && pending.Ready(now) != null)
                    {
                        Launcher.DeleteStartFile(startFile);
                        Log.Write("start file of " + rc.Name + " deleted after " + (now - started).TotalSeconds.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture) + " s");
                        pending = null;
                    }
                    Outcome read = ReadOutput(output, acc, FromOf(job), token);
                    if (read != null)
                    {
                        if (read.Journal != null)
                        {
                            commit(read);
                            if (serve && !HasExited(p)) { warm[slot] = new WarmTerminal { Copy = rc, Process = p, Login = new ReportLoginSession(settings), Server = acc.Server.Trim() }; keep = true; }
                        }
                        return read;
                    }
                    if (ending) return Fail(Lang.T("متوقف شد", "Stopped"), Lang.T("به درخواست شما متوقف شد.", "Stopped at your request."));
                    if (rc.Kind == Kind.MT5 && step == null && (now - lastStartupDisplay).TotalSeconds >= 1)
                    {
                        lastStartupDisplay = now;
                        Say(job.Index, StepState.Starting,
                            (connectedAt.HasValue ? Lang.T("MT5 متصل است؛ منتظر شروع گزارش‌خوان", "MT5 connected; waiting for the reporter") : Lang.T("MT5 اجرا شد؛ منتظر اتصال و شروع گزارش‌خوان", "MT5 launched; waiting for connection and reporter"))
                            + " — " + Fa.N((int)(now - started).TotalSeconds) + Lang.T(" ثانیه", " s"));
                    }
                    // Where the script is: shown in the progress window, and the wait goes on while it moves.
                    string now1 = TextFiles.ReadText(stepFile);
                    if (now1 != null && now1.Trim().Length > 0 && now1.Trim() != step)
                    {
                        step = now1.Trim();
                        Log.Write("report native step: " + job.Copy.Name + " " + step + " at " + (job.Clock == null ? 0 : job.Clock.ElapsedMilliseconds) + "ms");
                        lastStep = now;
                        reading = true;
                        string said = ReportLaunch.StepText(step);
                        if (said != null) Say(job.Index, StepState.Reading, said);
                    }
                    if (rc.Kind == Kind.MT5 && step != null && (now - lastStartupDisplay).TotalSeconds >= 1)
                    {
                        lastStartupDisplay = now;
                        string detail = ReportLaunch.StepText(step);
                        if (detail != null) Say(job.Index, StepState.Reading, detail + " — " + Fa.N((int)(now - lastStep).TotalSeconds) + Lang.T(" ثانیه", " s"));
                    }
                    bool exited = HasExited(p);
                    if ((now - lastLook).TotalSeconds >= 1.5 || exited)
                    {
                        lastLook = now;
                        if (!exited) { peak = Math.Max(peak, Native.PeakMb(p)); Native.HideWindowsOf(p.Id); }
                        List<string> lines = ConnectionCheck.JournalTail(rc, started);
                        if (SelfUpdate.InLines(lines)) updating = true;
                        LoginResult login = ConnectionCheck.FromJournal(lines, acc.Login.Trim());
                        if (login.State == Login.WrongLogin)
                            return Fail(Lang.T("ورود نشد: رمز ورود یا شماره حساب اشتباه", "Login failed: wrong login password or account number"), Lang.T("ورود نشد: شماره حساب یا رمز ورود اشتباه است.", "Login failed: the account number or login password is wrong."));
                        if (login.State == Login.NoServer)
                            return Fail(Lang.T("سرور پیدا نشد", "Server not found"), Lang.T("سرور «", "Server “") + acc.Server + Lang.T("» در متاتریدر گزارش پیدا نشد.", "” was not found in the report MetaTrader."));
                        if (login.State == Login.NoConnection) lastProblem = Lang.T("اتصال به سرور برقرار نشد", "Could not connect to the server");
                        if (login.State == Login.Connected) { lastProblem = null; if (connectedAt == null) connectedAt = now; }
                        if (login.State == Login.Connected && !reading)
                        {
                            reading = true;
                            Say(job.Index, StepState.Reading, null);
                        }
                        if (rc.Kind == Kind.MT5)
                        {
                            if (!loaded) loaded = lines.Any(ReportTrace.ScriptLoaded);
                            if (!chartTimeout) chartTimeout = lines.Any(ReportTrace.ChartTimeout);
                        }
                    }
                    if (exited)
                    {
                        // MT5 closes itself as soon as the script ends: the file may have come with the close.
                        read = ReadOutput(output, acc, FromOf(job), token);
                        if (read != null) { if (read.Journal != null) commit(read); return read; }
                        if (updating)
                        {
                            FollowRestart(rc);
                            return new Outcome { Retry = true, Short = Lang.T("متاتریدر گزارش برای به‌روزرسانی بسته شد", "The report MetaTrader closed to update itself"), Long = Lang.T("متاتریدر گزارش برای به‌روزرسانی خودش بسته شد؛ گزارش را دوباره بگیرید.", "The report MetaTrader closed to update itself; read the report again.") };
                        }
                        string why = ReportTrace.Explain(rc, started, symbol, step == null);
                        return TransientFail(Lang.T("متاتریدر گزارش زودتر بسته شد", "The report MetaTrader closed too early"), Lang.T("متاتریدر گزارش پیش از نوشتن تاریخچه بسته شد", "The report MetaTrader closed before writing the history") + (lastProblem != null ? " (" + lastProblem + ")" : "") + (why != null ? ". " + why : "") + ".");
                    }
                    // MT5 loads the script with its chart and starts it once the chart's symbol is ready. A symbol the broker does not
                    // have is never ready, and MT5 keeps the script waiting for minutes: try another of the broker's symbols instead.
                    if (ReportLaunch.HeldOnChart(rc.Kind, step, loaded, chartTimeout, connectedAt, now) || (step == null && connectedAt.HasValue && (now - connectedAt.Value).TotalSeconds >= (rc.Kind == Kind.MT4 ? 10 : 20)))
                    {
                        string why = ReportTrace.Explain(rc, started, symbol, true);
                        Log.Write("report: " + rc.Name + " kept the script waiting on its " + symbol + " chart" + (chartTimeout ? " (symbol synchronization timeout)" : "") +
                                  "; the broker may not have this symbol");
                        return new Outcome
                        {
                            WrongSymbol = symbol, Transient = true,
                            Short = Lang.T("نماد ", "Symbol ") + symbol + Lang.T(" در این بروکر نبود", " was not available at this broker"),
                            Long = Lang.T("متاتریدر ۵ اسکریپت گزارش را روی چارت ", "MetaTrader 5 kept the report script on the chart of ") + symbol + Lang.T(" نگه داشت و اجرا نکرد", " kept it and did not run it") + (why != null ? ": " + why : "") + ".",
                        };
                    }
                    if ((step == null || step == "start" || rc.Kind == Kind.MT5 && step == "ready") && lastProblem != null && (now - started).TotalSeconds >= 30)
                        return TransientFail(lastProblem, Lang.T("در مهلت بررسی اتصال سرور برقرار نشد؛ یک تلاش دوباره پس از سایر حساب‌ها انجام می‌شود.", "The server connection did not complete in the check budget; one deferred retry is allowed."));
                    if ((step == null || rc.Kind == Kind.MT5 && step == "ready") && (now - started).TotalSeconds >= ReportLaunch.StartSeconds)
                    {
                        string why = ReportTrace.Explain(rc, started, symbol, true);
                        return TransientFail(lastProblem ?? Lang.T("اسکریپت گزارش شروع نشد", "The report script did not start"),
                                    Lang.T("اسکریپت گزارش در ", "The report script was not placed in ") + Fa.N(ReportLaunch.StartSeconds) + Lang.T(" ثانیه شروع نشد", " seconds and did not start") + (lastProblem != null ? " (" + lastProblem + ")" : "") + (why != null ? ". " + why : "") + ".");
                    }
                    if (step != null && ((now - lastStep).TotalSeconds >= ReportLaunch.StallSeconds || (now - started).TotalSeconds >= ReportLaunch.MaxSeconds))
                    {
                        string why = ReportTrace.Explain(rc, started, symbol, false);
                        string at = ReportLaunch.StepText(step) ?? step;
                        return TransientFail(Lang.T("اسکریپت گزارش ماند: ", "The report script got stuck: ") + at.TrimEnd('…'),
                                    Lang.T("اسکریپت گزارش در این مرحله ماند و تمام نشد: ", "The report script stopped at this step and did not finish: ") + at.TrimEnd('…') + (why != null ? ". " + why : "") + ".");
                    }
                    Thread.Sleep(500);
                }
            }
            finally
            {
                Launcher.DeleteStartFile(startFile);
                peak = Math.Max(peak, Native.PeakMb(p));
                if (!keep) { End(p, rc); lock (live) live.Remove(p); if (p != null) p.Dispose(); }
                if (peak > 0)
                {
                    Log.Write("report: " + rc.Name + " held at most " + peak + " MB of memory");
                    lock (peaks) peaks.Add(peak);
                }
            }
        }

        /// <summary>The script's file, once it is there: the history, or why there is none. Null while it is not there yet.</summary>
        public static Outcome ReadOutput(string path, Account acc, DateTime from, string expectedToken = null)
        {
            if (!File.Exists(path)) return null;
            string text = TextFiles.ReadText(path);
            if (text == null) return null;
            if (expectedToken != null && !text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None).Contains("Q\t" + expectedToken)) return null;
            string err = JournalFile.ErrorOf(text);
            if (err != null)
                return err == "not connected" ? TransientFail(Lang.T("به حساب وصل نشد", "Did not connect to the account"), Lang.T("متاتریدر گزارش به حساب وصل نشد (اینترنت، سرور یا رمز ورود را بررسی کنید).", "The report MetaTrader did not connect to the account (check the internet, the server or the login password)."))
                                              : Fail(Lang.T("خطای اسکریپت", "Script error"), Lang.T("اسکریپت گزارش: ", "Report script: ") + err);
            AccountJournal j = JournalFile.Parse(text);
            if (j == null || !j.Complete) return Fail(Lang.T("فایل تاریخچه ناقص بود", "The history file was incomplete"), Lang.T("فایل تاریخچه‌ای که اسکریپت نوشت ناقص بود.", "The history file the script wrote was incomplete."));
            if (j.Login != acc.Login.Trim()) return Fail(Lang.T("حساب دیگری خوانده شد", "Another account was read"), Lang.T("متاتریدر گزارش حساب ", "The report MetaTrader read account ") + j.Login + Lang.T(" را خواند، نه ", ", not ") + acc.Login.Trim() + ".");
            if (expectedToken != null && (j.RequestToken != expectedToken || !string.Equals(j.Server.Trim(), acc.Server.Trim(), StringComparison.OrdinalIgnoreCase) || j.ScriptVersion != (j.Platform == "MT5" ? "1.23" : "1.22") || !j.FloatingDisabled || !j.HistoryChecked))
                return Fail(Lang.T("گزارش تازه تطبیق نداشت", "Fresh report did not match"), Lang.T("سرور یا نسخهٔ گزارش با درخواست مطابقت ندارد؛ گزارش ثبت نشد.", "The server or reporter version did not match the request; no report was accepted."));
            // Without its inputs the script reads the last seven days only: that must not pass for the whole range.
            if (j.From > from.AddHours(12))
                return Fail(Lang.T("تاریخ شروع به اسکریپت نرسید", "The start date did not reach the script"), Lang.T("متاتریدر گزارش تاریخ شروع بازه را از فایل پارامترهای اسکریپت (Presets) نخواند و تاریخچه از ", "The report MetaTrader did not read the range's start date from the script's parameter file (Presets) and read the history from ") + Gd.Date(j.From) + Lang.T(" خوانده شد؛ این را گزارش دهید.", "; please report this."));
            return new Outcome { Journal = j };
        }

        static bool HasExited(Process p)
        {
            try { p.Refresh(); return p.HasExited; } catch { return true; }
        }

        static bool WaitExit(Process p, int seconds)
        {
            try { return p.HasExited || (seconds > 0 && p.WaitForExit(seconds * 1000)); } catch { return true; }
        }

        /// <summary>Closes a report MetaTrader this run started (3.19): MT5 closes itself when the script ends; one still open has each
        /// of its windows asked to close for one second, and is then ended. Only a process in this run's own list.</summary>
        void End(Process p, Instance rc)
        {
            if (p == null || WaitExit(p, 0)) return;
            SafeClose.Result r = SafeClose.Close(new ProcessTarget(p), pid => { lock (live) return live.Any(x => { try { return x.Id == pid; } catch { return false; } }); },
                                                 1, Log.Write);
            Log.Write("report: " + rc.Name + (r == SafeClose.Result.Closed ? " closed" : r == SafeClose.Result.Ended ? " ended (it did not close in 1 s)" : " end: " + r));
        }

        /// <summary>3.21.2: a report copy is the program's own MetaTrader for reading (under _MTManager\report), never a student's copy
        /// or an installed MetaTrader.</summary>
        public static bool IsReportCopy(Instance rc)
        {
            if (rc == null || string.IsNullOrEmpty(rc.Dir)) return false;
            string sep = Path.DirectorySeparatorChar.ToString();
            string dir = rc.Dir.Replace('/', Path.DirectorySeparatorChar).Replace('\\', Path.DirectorySeparatorChar);
            return dir.IndexOf(sep + "_MTManager" + sep + "report" + sep, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        /// <summary>A report copy still open before a read is closed (its windows asked to close, SafeClose.GraceSeconds, then ended).
        /// 3.21.2: also when this program did not start it itself: MetaTrader restarts itself after its own update, and that run was
        /// left open and stopped every later read of the account ("متاتریدر گزارش باز است"). Only a report copy is ever closed this
        /// way. False when it is still open afterwards.</summary>
        static bool EndLeftover(Instance rc)
        {
            string key = rc.Exe.ToLowerInvariant();
            Dictionary<string, Process> running = Processes.Running();
            Process p;
            if (!running.TryGetValue(key, out p)) return true;
            if (!IsReportCopy(rc)) return false;
            bool ours = Owned.Mine(running).Contains(key);
            int id;
            try { id = p.Id; } catch { return true; }
            SafeClose.Result r = SafeClose.Close(new ProcessTarget(p), pid => pid == id, 1, Log.Write);
            Log.Write("report: " + rc.Name + ", left open " + (ours ? "by an earlier run" : "(not started by this program: MetaTrader's own update or by hand)") + ": " + r);
            for (int k = 0; k < 10; k++)
            {
                if (!Processes.Running().ContainsKey(key)) return true;
                Thread.Sleep(500);
            }
            return false;
        }

        /// <summary>After MetaTrader's own update it starts the terminal again, without the script: that run is ended too.</summary>
        static void FollowRestart(Instance rc)
        {
            string key = rc.Exe.ToLowerInvariant();
            for (int k = 0; k < 40; k++)
            {
                Dictionary<string, Process> running = Processes.Running();
                Process p;
                if (running.TryGetValue(key, out p))
                {
                    Thread.Sleep(5000);
                    running = Processes.Running();
                    // The run MetaTrader started after its update is not one this program started, but it is a report copy: closed too.
                    if (running.TryGetValue(key, out p) && IsReportCopy(rc))
                    {
                        int id = -1;
                        try { id = p.Id; } catch { }
                        SafeClose.Result r = SafeClose.Close(new ProcessTarget(p), pid => pid == id, 1, Log.Write);
                        Log.Write("report: " + rc.Name + " updated itself; its new run: " + r + ", starting it again");
                    }
                    return;
                }
                Thread.Sleep(1000);
            }
        }

        bool WaitForMt4Room(ReportJob job)
        {
            for (int k = 0; k < 120 && !ending; k++)
            {
                if (Mt4Limit.Room(Processes.Mt4InSession(), settings.MaxMt4)) return true;
                if (k == 0) Say(job.Index, StepState.Starting, Lang.T("در انتظار جای خالی MT4…", "Waiting for a free MT4 place…"));
                Thread.Sleep(1000);
            }
            return false;
        }

        /// <summary>The symbol of the report copy's chart (one the broker has), for the script's chart.</summary>
        static string SymbolOf(Instance rc)
        {
            try
            {
                string dir = ChartProfile.DefaultDir(rc);
                if (!Directory.Exists(dir)) return null;
                string chart = Directory.GetFiles(dir, "*.chr").OrderBy(f => f, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
                return chart == null ? null : ReportLaunch.ChartSymbol(TextFiles.ReadText(chart));
            }
            catch { return null; }
        }
    }

    // ================================================================== what the report copy's own logs tell

    /// <summary>The report copy's journal (logs) and its programs' log (MQL5\Logs, MQL4\Logs): the lines about the script, to say why
    /// a read did not work, and for «بررسی سیستم». They hold account numbers but never passwords; nothing is sent anywhere.</summary>
    public static class ReportTrace
    {
        public static string ProgramsLog(Instance rc, DateTime day)
        {
            return Path.Combine(rc.Dir, Kinds.Mql(rc.Kind), "Logs", day.ToString("yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture) + ".log");
        }

        static bool Relevant(string line)
        {
            string l = line.ToLowerInvariant();
            return l.Contains("mtmanagerreport") || l.Contains("script") || l.Contains("error") || l.Contains("failed") || l.Contains("cannot") ||
                   l.Contains("not found") || l.Contains("unknown symbol") || l.Contains("authoriz") || l.Contains("connection") || l.Contains("synchroniz");
        }

        static bool Ours(string l) { return l.IndexOf("MTManagerReport", StringComparison.OrdinalIgnoreCase) >= 0; }

        /// <summary>MT5 put the script on its chart ("script MTManagerReport (EURUSD,M1) loaded successfully"): it starts once the
        /// chart's symbol is ready.</summary>
        public static bool ScriptLoaded(string l) { return Ours(l) && l.IndexOf("loaded successfully", StringComparison.OrdinalIgnoreCase) >= 0; }

        /// <summary>MT5 gave up waiting for the chart's symbol ("symbol synchronization timeout").</summary>
        public static bool ChartTimeout(string l) { return l.IndexOf("synchronization timeout", StringComparison.OrdinalIgnoreCase) >= 0; }

        /// <summary>The lines about the script and the login since a time, newest last; at most max.</summary>
        public static List<string> Lines(Instance rc, DateTime since, int max = 24)
        {
            var all = new List<string>();
            try { all.AddRange(ConnectionCheck.JournalSince(rc, since).Where(Relevant).Select(l => "journal  " + l.Trim())); } catch { }
            for (DateTime day = since.Date; day <= DateTime.Now.Date; day = day.AddDays(1))
            {
                string text = TextFiles.ReadText(ProgramsLog(rc, day));
                if (text == null) continue;
                all.AddRange(ConnectionCheck.After(text.Split('\n'), day == since.Date ? since.TimeOfDay.Subtract(TimeSpan.FromSeconds(2)) : TimeSpan.Zero)
                    .Where(Relevant).Select(l => "programs " + l.Trim()));
            }
            return all.Count <= max ? all : all.Skip(all.Count - max).ToList();
        }

        /// <summary>What the lines say, in a few words; null when they say nothing useful. Every line is also written to the program's log.</summary>
        public static string Explain(Instance rc, DateTime since, string symbol, bool neverStarted)
        {
            List<string> lines = Lines(rc, since);
            foreach (string l in lines) Log.Write("report trace " + rc.Name + ": " + TextUtil.OneLine(l));
            return Explain(lines, symbol, neverStarted);
        }

        public static string Explain(List<string> lines, string symbol, bool neverStarted)
        {
            string chart = symbol ?? "EURUSD";
            if (lines.Any(ChartTimeout))
                return Lang.T("نماد چارت (", "The chart symbol (") + chart + Lang.T(") در این بروکر آماده نشد (symbol synchronization timeout)", ") was not ready at this broker (symbol synchronization timeout)");
            string bad = lines.LastOrDefault(l => Ours(l) && new[] { "cannot", "failed", "error", "removed", "not found", "invalid" }.Any(w => l.ToLowerInvariant().Contains(w)));
            if (bad != null) return Lang.T("متاتریدر گفت: ", "MetaTrader said: ") + Tail(bad);
            if (!string.IsNullOrEmpty(symbol) && lines.Any(l => l.IndexOf(symbol, StringComparison.OrdinalIgnoreCase) >= 0 && l.ToLowerInvariant().Contains("not found")))
                return Lang.T("نماد چارت (", "The chart symbol (") + symbol + Lang.T(") در این بروکر پیدا نشد", ") was not found at this broker");
            if (!neverStarted) return null;
            if (!lines.Any(Ours))
                return Lang.T("در گزارش متاتریدر هیچ نشانی از اجرای اسکریپت نیست (چارت ", "MetaTrader's log has no sign of the script running (the chart of ") + chart + Lang.T(" باز نشد یا اسکریپت در پوشه‌ی Scripts نبود)", " did not open or the script was not in the Scripts folder)");
            if (lines.Any(ScriptLoaded))
                return Lang.T("اسکریپت روی چارت ", "The script was placed on the chart of ") + chart + Lang.T(" قرار گرفت ولی متاتریدر منتظر آماده شدن این نماد ماند و اجرایش نکرد؛ احتمالاً بروکر نمادی با این اسم ندارد", " but MetaTrader waited for this symbol to be ready and did not run it; the broker probably has no symbol with this name");
            return Lang.T("آخرین پیام متاتریدر درباره‌ی اسکریپت: ", "MetaTrader's last message about the script: ") + Tail(lines.Last(Ours));
        }

        static string Tail(string line)
        {
            string t = TextUtil.OneLine(line);
            int k = t.IndexOf("MTManagerReport", StringComparison.OrdinalIgnoreCase);
            if (k > 0) t = t.Substring(k);
            return t.Length <= 140 ? t : t.Substring(0, 140) + "…";
        }

        /// <summary>For «بررسی سیستم»: each report copy, its script and the lines of today; the program's own report lines.</summary>
        public static string Summary(Settings s)
        {
            var sb = new StringBuilder();
            sb.AppendLine().AppendLine(Lang.T("— گزارش معاملات —", "— Trade report —"));
            foreach (Kind k in new[] { Kind.MT5, Kind.MT4 })
                sb.AppendLine(Lang.T("اسکریپت ", "Script ") + k + ": " + (File.Exists(ReportScript.Built(s, k)) ? (ReportScript.Ready(s, k) ? Lang.T("ساخته شده", "built") : Lang.T("ساخته شده ولی قدیمی", "built but old")) : Lang.T("هنوز ساخته نشده", "not built yet")));
            string root = ReportLaunch.ReportRoot(s.BaseDir);
            if (Directory.Exists(root))
                foreach (string d in Directory.GetDirectories(root))
                {
                    Kind? kind = Kinds.Detect(d);
                    if (kind == null) continue;
                    var rc = new Instance { Name = Path.GetFileName(d), Kind = kind.Value, Dir = d };
                    List<string> known = ReportLaunch.KnownSymbols(rc);
                    sb.AppendLine(rc.Name + ": " + (File.Exists(ReportScript.Target(rc)) ? Lang.T("اسکریپت در Scripts هست", "the script is in Scripts") : Lang.T("اسکریپت در Scripts نیست", "the script is not in Scripts")) +
                                  ", " + known.Count + Lang.T(" نماد شناخته‌شده", " known symbols") + (known.Count > 0 ? " (" + string.Join(", ", known.Take(6)) + (known.Count > 6 ? ", …" : "") + ")" : ""));
                    foreach (string l in Lines(rc, DateTime.Today, 15)) sb.AppendLine("  " + TextUtil.OneLine(l));
                }
            string log = TextFiles.ReadText(AppPaths.LogFile);
            if (log != null)
            {
                List<string> mine = log.Split('\n').Select(l => l.TrimEnd('\r')).Where(l => l.Contains("report")).ToList();
                sb.AppendLine(Lang.T("آخرین خط‌های گزارش در log برنامه:", "The last report lines in the program's log:"));
                foreach (string l in mine.Skip(Math.Max(0, mine.Count - 30))) sb.AppendLine("  " + l);
            }
            return sb.ToString();
        }
    }
}
