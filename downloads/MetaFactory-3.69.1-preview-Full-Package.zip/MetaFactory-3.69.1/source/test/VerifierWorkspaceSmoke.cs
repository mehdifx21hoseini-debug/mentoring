using System;using System.IO;using System.Linq;using System.Diagnostics;using System.Collections.Generic;using MTManager;
class VerifierWorkspaceSmoke
{
 static int checks,n;static string root;static readonly List<Process> processes=new List<Process>();
 static void Check(bool v,string why){if(!v)throw new Exception(why);checks++;Console.WriteLine("PASS "+why);}
 static Settings Setup(){string dir=Path.Combine(root,(++n).ToString());Directory.CreateDirectory(dir);AppPaths.DataDirOverride=Path.Combine(dir,"data");Directory.CreateDirectory(AppPaths.DataDir);return new Settings{BaseDir=Path.Combine(dir,"copies")};}
 static Process Sleep(string dir,string name="terminal"){Directory.CreateDirectory(dir);string exe=Path.Combine(dir,name);File.Copy("/bin/sleep",exe);var c=Process.Start(new ProcessStartInfo("chmod","+x "+exe){UseShellExecute=false});c.WaitForExit();c.Dispose();var p=Process.Start(new ProcessStartInfo(exe,"60"){UseShellExecute=false});processes.Add(p);System.Threading.Thread.Sleep(30);return p;}
 static int Main()
 {
  root=Path.Combine(Path.GetTempPath(),"verifier-pool-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
  try
  {
   var s=Setup();using(var a=VerifierWorkspace.Acquire(s,3,()=>false))using(var b=VerifierWorkspace.Acquire(s,3,()=>false))using(var c=VerifierWorkspace.Acquire(s,3,()=>false))
   {Check(a.Root!=b.Root&&b.Root!=c.Root,"simultaneous owners receive exclusive distinct bounded banks");bool blocked=false;try{using(var d=VerifierWorkspace.Acquire(s,3,()=>false)){} }catch(VerificationBusyException){blocked=true;}Check(blocked&&Directory.GetDirectories(Path.GetDirectoryName(a.Root)).Length==3,"all occupied banks stop with infrastructure status and never create a fourth bank");}
   using(var a=VerifierWorkspace.Acquire(s,3,()=>false))Check(a.Root.EndsWith("-0"),"released reservation can be reused without new workspace growth");
   s=Setup();Process owned;string bank;using(var a=VerifierWorkspace.Acquire(s,3,()=>false)){bank=a.Root;owned=Sleep(Path.Combine(bank,"MT4-a"));a.Track(owned,Processes.PathOf(owned));Check(a.IsOwned(owned)&&a.HasRunning(),"PID/start/path proof identifies an actual helper process");}
   using(var a=VerifierWorkspace.Acquire(s,3,()=>false)){owned.Refresh();Check(a.Root==bank&&owned.HasExited,"prior owned helper is safely recovered using persistent identity proof");}
   s=Setup();Process unknown;using(var a=VerifierWorkspace.Acquire(s,3,()=>false)){bank=a.Root;unknown=Sleep(Path.Combine(bank,"MT4-a"));Check(a.HasRunning(),"untracked terminal under reserved root is detected");}
   using(var a=VerifierWorkspace.Acquire(s,3,()=>false)){unknown.Refresh();Check(a.Root!=bank&&!unknown.HasExited,"unproven helper is quarantined, never killed or adopted by path alone");}
   s=Setup();var external=Sleep(Path.Combine(AppPaths.DataDir,"student"));using(var a=VerifierWorkspace.Acquire(s,3,()=>false))
   {File.WriteAllLines(Path.Combine(a.Root,"owned.txt"),Owned.Format(new[]{new Owned.Entry{Pid=external.Id,Start=Processes.StartOf(external.Id),Exe=Processes.PathOf(external)}}));bank=a.Root;}
   using(var a=VerifierWorkspace.Acquire(s,3,()=>false)){external.Refresh();Check(!external.HasExited,"outside/student process survives even if written into a reservation's record");}
   s=Setup();using(var a=VerifierWorkspace.Acquire(s,3,()=>false))
   {for(int k=0;k<4;k++){string d=Path.Combine(a.Root,"cache-"+k);Directory.CreateDirectory(d);File.WriteAllText(Path.Combine(d,"payload"),"ephemeral");a.MarkCache(d);Directory.SetLastWriteTimeUtc(d,DateTime.UtcNow.AddDays(-10+k));}string next=Path.Combine(a.Root,"cache-next");a.PrepareCache(next);Directory.CreateDirectory(next);a.MarkCache(next);Check(Directory.GetDirectories(a.Root).Length==VerifierWorkspace.MaximumCaches&&!Directory.Exists(Path.Combine(a.Root,"cache-0")),"closed managed cache count is bounded by evicting the oldest disposable cache");}
   s=Setup();using(var a=VerifierWorkspace.Acquire(s,3,()=>false))
   {for(int k=0;k<4;k++)Directory.CreateDirectory(Path.Combine(a.Root,"unknown-"+k));bool blocked=false;try{a.PrepareCache(Path.Combine(a.Root,"new"));}catch(VerificationBusyException){blocked=true;}Check(blocked&&Directory.GetDirectories(a.Root).Length==4,"unknown directories are preserved instead of deleted to make space");}
   s=Setup();using(var a=VerifierWorkspace.Acquire(s,3,()=>false))
   {string outside=Path.Combine(AppPaths.DataDir,"outside");Directory.CreateDirectory(outside);File.WriteAllText(Path.Combine(outside,"keep"),"protected");string cache=Path.Combine(a.Root,"cache-linked");Directory.CreateDirectory(cache);a.MarkCache(cache);var link=Process.Start(new ProcessStartInfo("ln","-s "+outside+" "+Path.Combine(cache,"link")){UseShellExecute=false});link.WaitForExit();link.Dispose();for(int k=0;k<3;k++){string d=Path.Combine(a.Root,"clean-"+k);Directory.CreateDirectory(d);a.MarkCache(d);}a.PrepareCache(Path.Combine(a.Root,"next"));Check(File.Exists(Path.Combine(outside,"keep"))&&Directory.Exists(cache),"a cache containing a linked outside tree is never recursively removed");}
   var shell=Process.Start(new ProcessStartInfo("/bin/sh","-c \"sleep 60 & echo $!; wait\""){UseShellExecute=false,RedirectStandardOutput=true});processes.Add(shell);int child=int.Parse(shell.StandardOutput.ReadLine());var childProcess=Process.GetProcessById(child);processes.Add(childProcess);Check(VerifierWorkspace.DescendantOf(child,shell.Id)&&!VerifierWorkspace.DescendantOf(shell.Id,child),"actual parent-chain proof distinguishes an updater/SDK child from an unrelated process");
   s=Setup();using(var one=VerifierWorkspace.Admit(s,()=>false,1)){int probes=0;bool waitingCancelled=false;try{using(var two=VerifierWorkspace.Admit(s,()=>++probes>2,1)){} }catch(OperationCanceledException){waitingCancelled=true;}Check(waitingCancelled,"resource admission respects one-active-check budget and remains cancellable");}using(var one=VerifierWorkspace.Admit(s,()=>false,2))using(var two=VerifierWorkspace.Admit(s,()=>false,2))Check(true,"two admitted checks are possible only under the explicit two-slot budget");
   s=Setup();using(var a=VerifierWorkspace.Acquire(s,3,()=>false)){string unknownCache=Path.Combine(a.Root,"MT4-existing");Directory.CreateDirectory(unknownCache);File.WriteAllText(Path.Combine(unknownCache,"keep"),"unknown");bool refused=false;try{a.PrepareCache(unknownCache);}catch(VerificationBusyException){refused=true;}Check(refused&&File.Exists(Path.Combine(unknownCache,"keep")),"an existing unmarked cache is not silently adopted or overwritten");}
   s=Setup();bool cancelled=false;try{using(var a=VerifierWorkspace.Acquire(s,3,()=>true)){} }catch(OperationCanceledException){cancelled=true;}Check(cancelled&&!Directory.Exists(Path.Combine(s.BaseDir,"_MTManager","verify-pool")),"cancelled allocation makes no workspace or process");
   Console.WriteLine("VERIFIER WORKSPACE PASS "+checks);return 0;
  }
  catch(Exception error){Console.Error.WriteLine(error);return 1;}
  finally{foreach(var p in processes){try{if(!p.HasExited){p.Kill();p.WaitForExit(2000);}p.Dispose();}catch{}}try{Directory.Delete(root,true);}catch{}}
 }
}
