using System;using System.Linq;using System.IO;using System.Reflection;using System.Collections;using System.Windows.Forms;using MTManager;
class AllLiveHistorySmoke {
static int n;static void Check(bool b,string s){if(!b)throw new Exception(s);n++;Console.WriteLine("PASS "+s);}
static JournalBalanceEvent E(long t,DateTime d,int type,double money){return new JournalBalanceEvent{Ticket=t,TimeMilliseconds=(long)(d-new DateTime(1970,1,1)).TotalMilliseconds,Type=type,Net=money};}
static AccountJournal J(DateTime start,DateTime now){return new AccountJournal{Platform="MT4",Login="synthetic-account",Server="Synthetic-Demo",Complete=true,From=start,TrustedFrom=start,Exported=now,HistoryChecked=true,HistoryOk=true,FullHistoryPresent=true,FullHistoryValid=true,FullHistoryReconciled=true,FullHistoryScanOk=true,FullHistoryRequested=true,FloatingBars=AccountJournal.TradesOnly};}
[STAThread] static int Main(){try{DateTime d=new DateTime(2026,11,26);var kept=J(ReportRange.AllFrom,d);kept.Trades.Add(new JournalTrade{Ticket=2,Open=d.AddDays(-5),Close=d.AddDays(-4),Profit=100});var live=J(d.AddDays(-2),d.AddHours(1));live.Trades.Add(new JournalTrade{Ticket=3,Open=d.AddDays(-1),Close=d,Profit=-50});live.FullHistory.AddRange(new[]{E(1,d.AddDays(-6),2,1000),E(2,d.AddDays(-4),0,100),E(3,d,0,-50)});live.FullHistoryCount=3;live.Balance=1050;
var merged=JournalCache.Merge(kept,live);var range=ServerDays.Range(PanelRange.All,d);var view=PanelMath.Build(merged,range,new TradeLimits());Check(view.RangeCovered&&view.Closed==2&&view.RangeProfitFactor==2,"All retains older closed trades and current live result");Check(view.RangeDdPct==view.AccountDdPct,"All merged DD equals current full ledger");Check(kept.Trades.Count==1&&live.Trades.Count==1,"merge leaves source snapshots unchanged");Check(merged.Exported==live.Exported&&merged.Balance==1050,"merged All uses latest live balance and timestamp");live.Login="different";Check(object.ReferenceEquals(JournalCache.Merge(kept,live),live),"different account history rejected");live.Login=kept.Login;kept.Exported=live.From.AddSeconds(-1);Check(object.ReferenceEquals(JournalCache.Merge(kept,live),live),"history gap rejected");view=PanelMath.Build(live,range,new TradeLimits());Check(!view.RangeCovered&&double.IsNaN(view.RangeProfitFactor),"uncovered live window cannot masquerade as All");
 string root=Path.Combine(Path.GetTempPath(),"mf-all-cache-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=root;
 try {
  Lang.En=true;var asm=typeof(Settings).Assembly;asm.GetType("MTManager.Theme").GetMethod("Init").Invoke(null,null);
  var settings=new Settings{BaseDir=Path.Combine(root,"copies"),Language="en"};Directory.CreateDirectory(settings.BaseDir);
  var flags=BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic;
  using(var main=(Form)Activator.CreateInstance(asm.GetType("MTManager.MainForm"),flags,null,new object[]{settings,new AccountStore()},null)) {
   var stType=main.GetType().GetNestedType("Student",BindingFlags.NonPublic);
   var manual=Activator.CreateInstance(stType,true);var student=Activator.CreateInstance(stType,true);
   var data=Activator.CreateInstance(asm.GetType("MTManager.LiveDashboardData"),true);
   data.GetType().GetField("Target",flags).SetValue(data,new LiveMonitorTarget{CopyName="MT4-01"});
   data.GetType().GetField("Journal",flags).SetValue(data,live);
   data.GetType().GetField("Today",flags).SetValue(data,PanelMath.Build(live,ServerDays.Range(PanelRange.Today,d),new TradeLimits()));
   data.GetType().GetField("HistoryKey",flags).SetValue(data,"same-live-revision");
   stType.GetField("LiveData",flags).SetValue(student,data);
   var states=(IDictionary)main.GetType().GetField("students",flags).GetValue(main);states["MT4-01"]=manual;
   var method=main.GetType().GetMethod("StudentPanel",flags);
   var before=(PanelView)method.Invoke(main,new object[]{student,range});Check(!before.RangeCovered,"initial All has incomplete live detail");
   kept.Exported=d;kept.Balance=1050;kept.FullHistory.AddRange(live.FullHistory);kept.FullHistoryCount=3;
   kept.FullHistorySum=kept.FullHistoryBalance=kept.HistorySum=kept.HistoryBalance=1050;
   Check(JournalCache.Save(kept),"full-detail report cache saved");
   var after=(PanelView)method.Invoke(main,new object[]{student,range});
   Check(after.RangeCovered&&after.Closed==2&&after.RangeProfitFactor==2,"new cache invalidates All projection without a changed live revision");
   Check(after.Balance==live.Balance&&after.ReadAt==live.Exported,"All cache refresh retains current live values");
   main.GetType().GetField("appClosing",flags).SetValue(main,true);
  }
 } finally {try{Directory.Delete(root,true);}catch{}}
 Console.WriteLine("ALL LIVE HISTORY PASS "+n);return 0;}catch(Exception e){Console.WriteLine(e);return 1;}}
}
