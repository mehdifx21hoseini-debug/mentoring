using System;using System.IO;using System.Linq;using System.Collections;using System.Collections.Generic;using System.Reflection;using System.Drawing;using System.Threading;using System.Windows.Forms;using MTManager;
class ImportFlowUiSmoke
{
 static readonly BindingFlags F=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static;static readonly Assembly A=typeof(Settings).Assembly;static readonly Type D=A.GetType("MTManager.StudentImportDialog");static int checks,sequence;static string root;
 static object Get(object o,string n){return o.GetType().GetField(n,F).GetValue(o);}static object Call(object o,string n,params object[] args){return o.GetType().GetMethods(F).Single(m=>m.Name==n&&m.GetParameters().Length==args.Length).Invoke(o,args);}static void Check(bool v,string why){if(!v)throw new Exception(why);checks++;Console.WriteLine("PASS "+why);}static void Pump(){for(int i=0;i<4;i++){Application.DoEvents();Thread.Sleep(15);}}
 static void Wait(Form f){var until=DateTime.UtcNow.AddSeconds(8);do{Pump();if(!(bool)Get(f,"running"))return;}while(DateTime.UtcNow<until);throw new Exception("worker did not finish");}
 static void Shot(Form f,string path){f.Location=Point.Empty;Pump();using(var b=new Bitmap(f.Width,f.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(f.Location,Point.Empty,f.Size);b.Save(path);}}
 sealed class Fake:IAccountVerifier {public int Calls;public Func<Account,ImportConnection> Reply=a=>new ImportConnection{Connected=true,Retryable=false};public void Dispose(){}public ImportConnection Verify(Account a,int ms,Func<bool> cancel,Action<string> stage){Calls++;return Reply(a);}}
 static Settings Setup(out AccountStore accounts,out FolderStore folders)
 {AppPaths.DataDirOverride=Path.Combine(root,(++sequence).ToString());Directory.CreateDirectory(AppPaths.DataDir);var s=new Settings{BaseDir=Path.Combine(AppPaths.DataDir,"copies")};Directory.CreateDirectory(s.BaseDir);accounts=new AccountStore();folders=new FolderStore();accounts.Save();folders.Save();return s;}
 static Account Seed(AccountStore accounts,string instance="MT4-01",string login="10001") {var a=new Account{Instance=instance,Platform="MT4",Login=login,Trader="Sample "+login,Server="Synthetic-Demo",Mode="investor",InvestorEnc=Secret.Protect("InvestorSynthetic9"),MasterEnc=Secret.Protect("MasterSynthetic9"),VerifyState="unconfirmed",VerifyReason="previous check"};accounts.SetQueue(a);accounts.Save();return a;}
 static StudentImportRow Row(Account a){return new StudentImportRow{Line=2,Name=a.Trader,Login=a.Login,Kind=Kind.MT4,Platform="MT4",Server=a.Server,Mode="investor",Investor="InvestorSynthetic9",State=ImportState.Duplicate};}
 static Form Dialog(Settings settings,AccountStore accounts,FolderStore folders,ImportCoordinator coordinator,List<StudentImportRow> rows)
 {var f=(Form)Activator.CreateInstance(D,F,null,new object[]{settings,accounts,folders,"",coordinator},null);f.Bounds=new Rectangle(0,0,1300,950);f.Show();Pump();Call(f,"LoadPreview",rows,"Synthetic existing-account import");Pump();return f;}
 [STAThread]static int Main(string[] args)
 {
  root=Path.Combine(Path.GetTempPath(),"import-ui-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);Directory.CreateDirectory(args[0]);
  try
  {
   Application.EnableVisualStyles();A.GetType("MTManager.Theme").GetMethod("Init",F).Invoke(null,null);
   foreach(bool en in new[]{true,false})
   {
    Lang.En=en;AccountStore accounts;FolderStore folders;var s=Setup(out accounts,out folders);var rows=new List<StudentImportRow>();for(int k=0;k<16;k++)rows.Add(Row(Seed(accounts,"MT4-"+(k+1).ToString("00"),(10001+k).ToString())));var bytes=File.ReadAllBytes(AppPaths.AccountsFile);int factories=0;var fake=new Fake();
    using(var coordinator=new ImportCoordinator(s,accounts,folders,i=>{factories++;return fake;},1))using(var form=Dialog(s,accounts,folders,coordinator,rows))
    {
     Check(rows.All(r=>r.State==ImportState.Unchanged),"preview classifies all sixteen identical accounts as unchanged "+en);var grid=(DataGridView)Get(form,"grid");Check(grid.Rows.Cast<DataGridViewRow>().All(r=>!string.IsNullOrEmpty(Convert.ToString(r.Cells[6].Value))),"existing-copy identity remains visible without claiming a new save "+en);Check(((Button)Get(form,"recheckExisting")).Enabled,"explicit recheck is available separately "+en);
     Call(form,"Begin",null,EventArgs.Empty);Pump();Check(factories==0&&!(bool)Get(form,"running")&&File.ReadAllBytes(AppPaths.AccountsFile).SequenceEqual(bytes),"Finish unchanged neither starts a worker nor changes durable accounts "+en);Check((bool)Get(form,"hasRun")&&File.Exists((string)Get(form,"automaticResultPath")),"unchanged run produces an automatic result workbook "+en);Shot(form,Path.Combine(args[0],"unchanged-"+en+".png"));
     grid.CurrentCell=grid.Rows[0].Cells[1];Call(form,"SkipSelectedRow");Check(rows[0].Excluded&&rows[0].State==ImportState.Duplicate,"skip affects preview only "+en);Call(form,"SkipSelectedRow");Check(!rows[0].Excluded&&rows[0].State==ImportState.Unchanged,"restore reclassifies preview without an account operation "+en);
     foreach(var r in rows.Skip(1))r.Excluded=true;Call(form,"RevalidatePreview");Call(form,"RecheckExisting",null,EventArgs.Empty);Wait(form);Check(factories==1&&fake.Calls==1&&rows[0].State==ImportState.Connected&&accounts.All.Count()==16,"explicit recheck verifies only the included existing account without duplicates "+en);form.Close();Pump();
    }
    s=Setup(out accounts,out folders);var old=Seed(accounts);var metadata=Row(old);metadata.Name="Edited sample";metadata.Folder="Realtime";rows=new List<StudentImportRow>{metadata};factories=0;
    using(var coordinator=new ImportCoordinator(s,accounts,folders,i=>{factories++;return new Fake();},1))using(var form=Dialog(s,accounts,folders,coordinator,rows))
    {Check(metadata.MetadataOnly&&metadata.State==ImportState.Ready,"metadata preview is ready without an authentication operation "+en);Call(form,"Begin",null,EventArgs.Empty);Wait(form);Check(metadata.State==ImportState.Updated&&factories==0&&accounts.Get(old.Instance).CredentialKey==old.CredentialKey&&folders.Of(old.Instance).Count==1,"actual metadata worker commits fields and folders with no verifier "+en);Shot(form,Path.Combine(args[0],"metadata-"+en+".png"));form.Close();Pump();}
    s=Setup(out accounts,out folders);old=Seed(accounts);var first=Row(old);var second=Row(old);second.Investor="ConflictSynthetic9";rows=new List<StudentImportRow>{first,second};using(var coordinator=new ImportCoordinator(s,accounts,folders,i=>new Fake(),1))using(var form=Dialog(s,accounts,folders,coordinator,rows))
    {Check(rows.All(r=>r.State==ImportState.Invalid),"conflicting duplicate rows are blocked before authentication "+en);var grid=(DataGridView)Get(form,"grid");grid.CurrentCell=grid.Rows[1].Cells[1];Call(form,"SkipSelectedRow");Check(first.State==ImportState.Unchanged&&second.Excluded,"skipping a conflicting row unlocks the correct row without editing stored credentials "+en);grid.CurrentCell=grid.Rows[0].Cells[1];Call(form,"SkipSelectedRow");Check(rows.All(r=>r.Excluded),"all rows can be excluded without a parsing exception "+en);form.Close();Pump();}
   }
   Console.WriteLine("IMPORT FLOW UI PASS "+checks);return 0;
  }
  catch(Exception error){Console.Error.WriteLine(error);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
