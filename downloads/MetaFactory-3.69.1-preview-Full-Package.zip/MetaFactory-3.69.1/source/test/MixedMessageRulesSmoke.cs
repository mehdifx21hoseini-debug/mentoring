using System;using System.IO;using System.Linq;using System.Collections.Generic;using MTManager;
class MixedMessageRulesSmoke
{
 static int checks;static void Check(bool ok,string label){if(!ok)throw new Exception(label);checks++;Console.WriteLine("PASS "+label);}
 static string[] Known(Kind k){return k==Kind.MT4?new[]{"WMMarkets-DEMO","WMMarkets-REAL"}:new[]{"WMMarkets-Demo","Alpari-mt5-demo","WingoGroupLtd-server"};}
 static List<StudentImportRow> Parse(string text){return TextStudentImport.Parse(text,true,new string[0],Known,"WMMarkets");}
 static void Main(){string root=Path.Combine(Path.GetTempPath(),"mixed-message-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=root;try{
 var rows=Parse(File.ReadAllText("test/fx/text-import-eight-synthetic.txt"));
 Check(rows.Count==8,"eight supplied message shapes produce eight accounts without prose/contact phantom rows");
 Check(rows.Select(r=>r.Login).SequenceEqual(Enumerable.Range(76001,8).Select(n=>n.ToString())),"all account identities and record boundaries remain in source order");
 string[] secrets={"SampleA123","Aa7@B@92!Cc4","Sample@trader5","Ab!e0xy9","Sample112233","x0SAMPLE","@Sample029920","Samplekh7007#"};
 for(int i=0;i<8;i++)Check(rows[i].Investor==secrets[i]&&rows[i].Master==""&&rows[i].Mode=="investor","password content and role preserved: "+i);
 Check(rows[0].OriginalName=="رضا تست"&&rows[0].Platform=="MT4","Arabic final ya in the Persian name label is recognized");
 Check(rows[1].Name=="No Name 1"&&rows[1].Platform=="MT5"&&rows[1].Server=="Alpari-mt5-demo","nameless Alpari stays separate from the next explicit named account");
 Check(rows[2].Name=="Hamed Sample"&&rows[2].Platform=="MT5"&&rows[2].Server=="WMMarkets-Demo","A.N and B.N recover account and broker rather than credentials");
 Check(rows[3].OriginalName=="رضا نمونه"&&rows[3].Server=="WingoGroupLtd-server"&&rows[3].Platform=="MT5","typed server heading consumes the next full Wingo server without changing its broker");
 Check(rows[4].OriginalName=="سجاد تست"&&rows[4].Server=="WMMarkets-DEMO","greeting and broker clarification do not become extra accounts or passwords");
 Check(rows[5].OriginalName=="محمدرضا تست"&&rows[5].Platform==""&&rows[5].State==ImportState.Invalid,"trailing owner name belongs to the same incomplete record, and missing platform is not guessed");
 Check(rows.Where((r,i)=>i!=5).All(r=>r.State==ImportState.Ready),"seven complete records ready; exactly the one genuinely missing platform needs correction");
 var r1=Parse("Name: One Sample\nA.N: 77001\nB.N: Wm\nInvestor Password:\nExactCase9!\nServer:\nWMMarkets-DEMO\nPlatform:\nMT4");Check(r1.Count==1&&r1[0].Investor=="ExactCase9!"&&r1[0].Server=="WMMarkets-DEMO"&&r1[0].Platform=="MT4"&&r1[0].State==ImportState.Ready,"standalone field headings consume only their own next values");
 r1=Parse("Name: Annotation Sample\nAccount: 77002\nInvestor: ExactCase9!(read only password)\nServer: WMMarkets-DEMO\nMT4");Check(r1[0].Investor=="ExactCase9!(read only password)","attached parentheses remain part of a literal password");
 r1=Parse("Name: Annotation Sample\nAccount: 77003\nInvestor: ExactCase9! (other words)\nServer: WMMarkets-DEMO\nMT4");Check(r1[0].Investor=="ExactCase9! (other words)","unrecognized annotations are not stripped from a password");
 r1=Parse("Name: Conflict Sample\nA.N: 77004\nB.N: WM\nBroker: Alpari\nInvestor: ExactCase9!\nServer: WMMarkets-DEMO\nMT4");Check(r1[0].State==ImportState.Invalid,"conflicting abbreviated and full broker fields remain invalid");
 r1=Parse("Name: Missing Platform\nAccount: 77005\nInvestor: Sample@trader5\nBroker: WM\nServer: Demo");Check(r1[0].Platform==""&&r1[0].State==ImportState.Invalid,"a platform-looking password never supplies a missing platform");
 r1=Parse("Name: Role Conflict\nAccount: 77006\nMaster: ExactCase9! (read only password)\nServer: WMMarkets-DEMO\nMT4");Check(r1[0].State==ImportState.Invalid&&r1[0].Master=="ExactCase9!"&&r1[0].Investor=="","explicit master versus read-only annotation is flagged without changing credential role");
 r1=Parse("Name: Type Conflict\nAccount: 77007\nInvestor: ExactCase9!\nServer Real:\nWMMarkets-DEMO\nMT4");Check(r1[0].State==ImportState.Invalid,"typed Real heading conflicting with a complete Demo server is invalid");
 Console.WriteLine("MIXED MESSAGE RULES PASS "+checks);
 }finally{Directory.Delete(root,true);}}
}
