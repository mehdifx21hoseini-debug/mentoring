using System;using System.IO;using System.Linq;using System.Reflection;using System.Collections.Generic;using System.Drawing;using System.Threading;using System.Windows.Forms;using MTManager;
class ImportReplacementUiSmoke
{
 static readonly BindingFlags F=BindingFlags.Instance|BindingFlags.Static|BindingFlags.NonPublic|BindingFlags.Public;static readonly Assembly A=typeof(Settings).Assembly;static int checks;
 static object Get(object o,string n){return o.GetType().GetField(n,F).GetValue(o);}static object Call(object o,string n,params object[] args){return o.GetType().GetMethods(F).Single(m=>m.Name==n&&m.GetParameters().Length==args.Length).Invoke(o,args);}
 static void Check(bool v,string why){if(!v)throw new Exception(why);checks++;Console.WriteLine("PASS "+why);}static void Pump(){Application.DoEvents();Thread.Sleep(20);}
 static IEnumerable<Control> All(Control root){foreach(Control c in root.Controls){yield return c;foreach(var d in All(c))yield return d;}}
 static void Shot(Form form,string file){form.Location=new Point(10,10);for(int j=0;j<4;j++)Pump();using(var b=new Bitmap(form.Width,form.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(form.Location,Point.Empty,form.Size);b.Save(file);}}
 sealed class Fake:IAccountVerifier
 {public ImportConnection Verify(Account a,int ms,Func<bool> cancel,Action<string> stage){return new ImportConnection{Connected=a.Login=="1001",State=a.Login=="1001"?Login.Waiting:Login.WrongLogin,Retryable=false,Reason="Account/password rejected or account disabled; MetaTrader did not distinguish the cause."};}public void Dispose(){}}
 [STAThread]static int Main(string[] args)
 {
  string root=Path.Combine(Path.GetTempPath(),"replace-ui-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);Directory.CreateDirectory(args[0]);
  try
  {
   Application.EnableVisualStyles();A.GetType("MTManager.Theme").GetMethod("Init",F).Invoke(null,null);
   foreach(bool en in new[]{true,false})
   {
    Lang.En=en;AppPaths.DataDirOverride=Path.Combine(root,en?"en":"fa");Directory.CreateDirectory(AppPaths.DataDir);var settings=new Settings{BaseDir=Path.Combine(AppPaths.DataDir,"copies")};Directory.CreateDirectory(settings.BaseDir);var accounts=new AccountStore();var folders=new FolderStore();
    for(int j=1;j<=2;j++)accounts.SetQueue(new Account{Instance="MT4-0"+j,Trader="Old student "+j,Login="100"+j,Platform="MT4",Server="Old-Demo",Mode="investor",InvestorEnc=Secret.Protect("PreviousPrivate9"),DeferredDir=Path.Combine(settings.BaseDir,"MT4-0"+j)});accounts.Save();folders.Save();var old1=accounts.Get("MT4-01");var old2=accounts.Get("MT4-02");
    var rows=new List<StudentImportRow>();for(int j=1;j<=2;j++)rows.Add(new StudentImportRow{Name="Incoming student "+j,Login="100"+j,Platform="MT4",Kind=Kind.MT4,Server="New-Demo",Investor="IncomingPrivate9",State=ImportState.Duplicate});
    using(var coordinator=new ImportCoordinator(settings,accounts,folders,slot=>new Fake(),1))
    using(var dialog=(Form)Activator.CreateInstance(A.GetType("MTManager.StudentImportDialog"),F,null,new object[]{settings,accounts,folders,"",coordinator},null))
    {
     dialog.Show();for(int j=0;j<5;j++)Pump();Call(dialog,"LoadPreview",rows,"Synthetic import.xlsx");var grid=(DataGridView)Get(dialog,"grid");var start=(Button)Get(dialog,"start");
     Check(start.Enabled,"duplicates-only preview still permits replacement choice "+en);Check((string)grid.Rows[0].Cells[8].Value=="شماره حساب تکراری است.","duplicate explanation is short without claiming connected/disconnected "+en);
     int prompts=0;string callbackError=null;bool responding=false;
     using(var timer=new System.Windows.Forms.Timer{Interval=50})
     {
      timer.Tick+=(s,e)=>{
       if(responding)return;responding=true;
       foreach(var popup in Application.OpenForms.Cast<Form>().Where(f=>f.GetType().Name=="ImportDuplicateDialog").ToList())
       {
        try
        {
         prompts++;Check(popup.Width<=800&&popup.Height<=650,"replacement confirmation stays compact "+en);
         string labels=string.Join(" ",All(popup).Select(c=>c.Text));Check(!labels.Contains("IncomingPrivate9")&&!labels.Contains("PreviousPrivate9"),"replacement dialog exposes no passwords "+en);
         Shot(popup,Path.Combine(args[0],"replace-confirm-"+en+".png"));((CheckBox)Get(popup,"applyAll")).Checked=true;
         ((Button)popup.AcceptButton).PerformClick();
        }
        catch(Exception error){callbackError=error.ToString();popup.DialogResult=DialogResult.Cancel;popup.Close();}
       }
       responding=false;
      };
      timer.Start();start.PerformClick();timer.Stop();
     }
     Check(callbackError==null,"replacement dialog interaction succeeds "+en);
     for(int j=0;j<400&&(bool)Get(dialog,"running");j++)Pump();Check(!(bool)Get(dialog,"running"),"replacement import completes "+en);
     Check(prompts==1,"apply-all asks once for unique existing matches "+en);
     Check(rows[0].Replaced&&rows[0].Copy==old1.Instance&&accounts.Get(old1.Instance).Server=="New-Demo"&&accounts.All.Count()==2,"successful UI replacement reuses existing student without duplicate "+en);
     Check(!rows[1].Saved&&accounts.Get(old2.Instance).CredentialKey==old2.CredentialKey,"failed UI replacement preserves existing student "+en);
     Check((string)grid.Rows[0].Cells[8].Value=="اطلاعات جایگزین شد."&&(string)grid.Rows[1].Cells[8].Value=="ورود جدید رد شد؛ قبلی حفظ شد.","visible replacement outcomes are concise and exact "+en);
     Check(grid.Rows[1].Cells[8].ToolTipText==Convert.ToString(grid.Rows[1].Cells[8].Value)&&grid.Rows[1].Height<100*1.5,"details tooltip and row height avoid long repeated instructions "+en);
     ((Button)Get(dialog,"copyIssues")).PerformClick();Check(Clipboard.GetText()=="Incoming student 2 · 1002","bulk copy retains name/account only after replacement failure "+en);
     Call(grid,"OnCellClick",new DataGridViewCellEventArgs(7,1));Check(Clipboard.GetText()=="Incoming student 2 · 1002","single-row issue copy remains unchanged "+en);
     Check(rows[1].Reason.Contains("did not distinguish"),"full verifier diagnostic retained behind short display "+en);
     Shot(dialog,Path.Combine(args[0],"replacement-results-"+en+".png"));dialog.Close();for(int j=0;j<4;j++)Pump();
    }
   }
   Console.WriteLine("IMPORT REPLACEMENT UI PASS "+checks);return 0;
  }
  catch(Exception error){Console.Error.WriteLine(error);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
