using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Text;using MTManager;
class ImportEndpointSourceSmoke
{
 static int checks;static void Check(bool ok,string label){if(!ok)throw new Exception(label);checks++;Console.WriteLine("PASS "+label);}
 static string Install(string root,string name,string server){string dir=Path.Combine(root,name);Directory.CreateDirectory(Path.Combine(dir,"config"));File.WriteAllText(Path.Combine(dir,Kinds.Exe(Kind.MT4)),"fixture");if(server!=null)File.WriteAllText(Path.Combine(dir,"config",server+".srv"),"synthetic endpoint metadata");return dir;}
 sealed class Verifier:IAccountVerifier{public readonly List<string> Seen=new List<string>();public Func<Account,ImportConnection> Next;public ImportConnection Verify(Account a,int ms,Func<bool> cancel,Action<string> stage){Seen.Add(a.Server);return Next(a);}public void Dispose(){}}
 static Account Job(){return new Account{Instance="import-preview",Platform="MT4",Login="71001",Server="WMMarkets-REAL6",ImportServers="WMMarkets-REAL6|WMMarkets-REAL2",Mode="investor",InvestorEnc=Secret.Protect("SyntheticOnlyCase9!"),VerifyToken=Guid.NewGuid().ToString("N")};}
 static void Main(){string root=Path.Combine(Path.GetTempPath(),"endpoint-source-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=root;try{
 string unrelated=Install(root,"First broker","Other-REAL"),old=Install(root,"Old WM","WMMarkets-REAL6"),current=Install(root,"Running WM","WMMarkets-REAL6");
 File.SetLastWriteTimeUtc(Path.Combine(old,"config","WMMarkets-REAL6.srv"),DateTime.UtcNow);File.SetLastWriteTimeUtc(Path.Combine(current,"config","WMMarkets-REAL6.srv"),DateTime.UtcNow.AddDays(-1));
 var all=new[]{unrelated,old,current};
 Check(ImportBrokerCatalog.ChooseMt4Source(all,"WMMarkets-REAL6",d=>null,d=>d==current)==current,"running native install with the exact endpoint wins over another stale installed copy");
 Check(ImportBrokerCatalog.ChooseMt4Source(all,"WMMarkets-REAL6",d=>null,d=>d==unrelated)==old,"a running unrelated broker cannot win; freshest exact metadata is next");
 Check(ImportBrokerCatalog.ChooseMt4Source(all,"Missing-REAL",d=>null,d=>true)==null,"unknown endpoint never falls back to an arbitrary terminal and spends a full timeout");
 string empty=Install(root,"Empty source","WMMarkets-REAL6");File.WriteAllText(Path.Combine(empty,"config","WMMarkets-REAL6.srv"),"");
 Check(ImportBrokerCatalog.ChooseMt4Source(new[]{empty},"WMMarkets-REAL6",d=>null,d=>true)==null,"empty endpoint metadata cannot authorize a source");
 string app=Install(root,"Generic installation",null),data=Path.Combine(root,"AppData");Directory.CreateDirectory(Path.Combine(data,"config"));File.WriteAllText(Path.Combine(data,"config","WMMarkets-REAL6.srv"),"synthetic endpoint");
 Check(ImportBrokerCatalog.ChooseMt4Source(new[]{unrelated,app},"WMMarkets-REAL6",d=>d==app?data:null,d=>false)==app,"normal install's AppData metadata is included");
 string modern=Install(root,"Modern catalogue",null);File.WriteAllBytes(Path.Combine(modern,"config","servers.dat"),Encoding.Unicode.GetBytes("\0WMMarkets-REAL6\0"));
 Check(ImportBrokerCatalog.ChooseMt4Source(new[]{unrelated,modern},"WMMarkets-REAL6",d=>null,d=>false)==modern,"modern binary endpoint metadata can select the matching source");
 Check(ImportBrokerCatalog.ChooseMt4Source(new[]{modern},"WMMarkets-REAL",d=>null,d=>false)==null,"catalogue substring does not match another complete server");
 var job=Job();using(var v=new Verifier{Next=a=>a.Server==job.Server?PrivateMt4Check.Exhausted(new ImportConnection{State=Login.NoConnection}):new ImportConnection{Connected=true,State=Login.Connected}}){var result=ImportServerPlan.Verify(job,v,30000,()=>false,s=>{});Check(result.Connected&&v.Seen.Count==2&&result.VerifiedServer=="WMMarkets-REAL2","exhausted first candidate skips same-server retry but still verifies the next candidate");}
 using(var v=new Verifier{Next=a=>new ImportConnection{Retryable=false,Reason="protocol failure"}}){var result=ImportServerPlan.Verify(Job(),v,30000,()=>false,s=>{});Check(!result.Connected&&v.Seen.Count==1,"non-budget fatal errors still stop the candidate loop");}
 using(var v=new Verifier{Next=a=>new ImportConnection{State=Login.NoServer,Reason="local endpoint unavailable"}}){var result=ImportServerPlan.Verify(Job(),v,30000,()=>false,s=>{});Check(!result.Connected&&v.Seen.Count==2&&result.Reason.Contains("s]"),"unsupported candidates finish without authentication and retain per-attempt duration");}
 var one=Job();one.ImportServers="";using(var v=new Verifier{Next=a=>PrivateMt4Check.Exhausted(new ImportConnection{State=Login.NoConnection})}){var result=ImportServerPlan.Verify(one,v,30000,()=>false,s=>{});Check(!result.Connected&&!result.Retryable&&v.Seen.Count==1,"single exhausted endpoint does not re-enable the coordinator's duplicate full minute");}
 Console.WriteLine("IMPORT ENDPOINT SOURCE PASS "+checks);
 }finally{Directory.Delete(root,true);}}
}
