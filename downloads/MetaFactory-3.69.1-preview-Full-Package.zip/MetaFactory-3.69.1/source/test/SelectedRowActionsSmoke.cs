using System;using System.IO;using System.Linq;using System.Reflection;using System.Collections.Generic;using System.Drawing;using System.Threading;using System.Windows.Forms;using MTManager;
class SelectedRowActionsSmoke
{
 static readonly BindingFlags F=BindingFlags.Instance|BindingFlags.Static|BindingFlags.NonPublic|BindingFlags.Public;static readonly Assembly A=typeof(Settings).Assembly;static int checks;
 static object Get(object o,string n){return o.GetType().GetField(n,F).GetValue(o);}static void Set(object o,string n,object v){o.GetType().GetField(n,F).SetValue(o,v);}static object Call(object o,string n,params object[] a){return o.GetType().GetMethods(F).Single(m=>m.Name==n&&m.GetParameters().Length==a.Length).Invoke(o,a);}
 static void Check(bool value,string why){if(!value)throw new Exception(why);checks++;Console.WriteLine("PASS "+why);}static void Pump(){for(int j=0;j<4;j++){Application.DoEvents();Thread.Sleep(15);}}
 static IEnumerable<Control> All(Control root){foreach(Control c in root.Controls){yield return c;foreach(var child in All(c))yield return child;}}
 static void Chosen(Form main,params string[] names){Call(main,"ClearChoice");foreach(string n in names)Call(Get(main,"chosen"),"Toggle",n);Call(main,"ShowChoice");}
 static object Row(DataGridView grid,string name){return grid.Rows.Cast<DataGridViewRow>().Select(r=>r.Tag).First(r=>r!=null&&(string)Get(r,"Name")==name);}
 static void Open(Form main,DataGridView grid,string name){Call(main,"ShowRowMenu",Row(grid,name),grid.PointToScreen(new Point(150,60)));Pump();}
 static string[] Targets(Form main){return ((List<Instance>)Call(main,"RowActionTargets")).Select(i=>i.Name).ToArray();}
 static void Dialogs(Action action,Func<Form,DialogResult> answer)
 {using(var timer=new System.Windows.Forms.Timer{Interval=30}){timer.Tick+=(s,e)=>{foreach(var d in Application.OpenForms.Cast<Form>().Where(f=>f.Modal).ToList()){var response=answer(d);if(!d.IsDisposed){d.DialogResult=response;d.Close();}}};timer.Start();action();timer.Stop();}}
 [STAThread]static int Main(string[] args)
 {
  string root=Path.Combine(Path.GetTempPath(),"selected-row-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);Directory.CreateDirectory(args[0]);
  try
  {
   Application.EnableVisualStyles();A.GetType("MTManager.Theme").GetMethod("Init",F).Invoke(null,null);
   foreach(bool en in new[]{true,false})
   {
    Lang.En=en;AppPaths.DataDirOverride=Path.Combine(root,en?"en":"fa");Directory.CreateDirectory(AppPaths.DataDir);
    var settings=new Settings{BaseDir=Path.Combine(AppPaths.DataDir,"copies"),Language=en?"en":"fa",LastBackup=DateTime.Now};Directory.CreateDirectory(settings.BaseDir);var accounts=new AccountStore();
    for(int j=1;j<=3;j++){string n="MT4-0"+j,d=Path.Combine(settings.BaseDir,n);Directory.CreateDirectory(d);File.WriteAllText(Path.Combine(d,"terminal.exe"),"Synthetic never launched");accounts.Set(new Account{Instance=n,Trader="Sample student "+j,Login="001000"+j,Server="Sample-Demo",Platform="MT4",Mode="investor",InvestorEnc=Secret.Protect("SyntheticPrivate9")});}accounts.Save();
    using(var main=(Form)Activator.CreateInstance(A.GetType("MTManager.MainForm"),F,null,new object[]{settings,accounts},null))
    {
     main.WindowState=FormWindowState.Normal;main.Bounds=new Rectangle(10,10,1300,900);main.Show();Pump();foreach(var field in main.GetType().GetFields(F))if(field.FieldType==typeof(System.Windows.Forms.Timer))((System.Windows.Forms.Timer)field.GetValue(main)).Stop();var grid=(DataGridView)Get(main,"grid");
     Chosen(main,"MT4-01","MT4-02");Open(main,grid,"MT4-01");var menu=(ContextMenuStrip)Get(main,"rowMenu");
     Check(Targets(main).SequenceEqual(new[]{"MT4-01","MT4-02"}),"selected row menu captures all checked students "+en);
     foreach(var field in new[]{"miCopyGroup","miStopGroup","miRowAddTo","miRowRemove","miEditStudent"})Check(((ToolStripMenuItem)Get(main,field)).Text.Contains(en?"2":"۲"),"group count visible on "+field+" "+en);
     var copy=(ToolStripMenuItem)Get(main,"miCopyGroup");menu.Close();copy.DropDownItems.OfType<ToolStripMenuItem>().First().PerformClick();
     Check(Clipboard.GetText()=="Sample student 1\r\nSample student 2","actual Copy name action copies both checked students only "+en);
     Chosen(main,"MT4-01","MT4-02");Open(main,grid,"MT4-01");menu.Close();Call(main,"ClearChoice");Call(main,"CopyRowValues","login");
     Check(Clipboard.GetText()=="0010001\r\n0010002","captured group survives checkbox clearing and preserves leading zeros "+en);
     Chosen(main,"MT4-01","MT4-02");Open(main,grid,"MT4-03");Check(Targets(main).SequenceEqual(new[]{"MT4-03"}),"unclicked check group does not hijack an unselected row "+en);menu.Close();Call(main,"CopyRowValues","name");Check(Clipboard.GetText()=="Sample student 3","unselected row keeps single-student copy "+en);
     var folders=(FolderStore)Get(main,"folders");var folder=folders.Create("Synthetic group");folders.Save();
     Chosen(main,"MT4-01","MT4-02");Open(main,grid,"MT4-02");menu.Close();var add=(ToolStripMenuItem)Get(main,"miRowAddTo");add.DropDownItems.OfType<ToolStripMenuItem>().Single(item=>item.Tag is Folder).PerformClick();Pump();
     Check(folders.Has(folder.Id,"MT4-01")&&folders.Has(folder.Id,"MT4-02")&&!folders.Has(folder.Id,"MT4-03"),"actual folder action applies to the group only "+en);
     Chosen(main,"MT4-01","MT4-02");Open(main,grid,"MT4-01");menu.Close();int edits=0;
     Dialogs(()=>((ToolStripMenuItem)Get(main,"miEditStudent")).PerformClick(),d=>{Check(d.GetType().Name=="AccountDialog","group edit uses existing individual account dialog "+en);edits++;((TextBox)Get(d,"trader")).Text="Edited student "+edits;Call(d,"Save",null,EventArgs.Empty);return DialogResult.OK;});
     Check(edits==2&&accounts.Get("MT4-01").Trader=="Edited student 1"&&accounts.Get("MT4-02").Trader=="Edited student 2"&&accounts.Get("MT4-03").Trader=="Sample student 3","individual editing visits entire captured group without overwriting peers "+en);
     Chosen(main,"MT4-01","MT4-02");Open(main,grid,"MT4-01");menu.Close();edits=0;Dialogs(()=>((ToolStripMenuItem)Get(main,"miEditStudent")).PerformClick(),d=>{edits++;return DialogResult.Cancel;});Check(edits==1,"Cancel stops remaining group edit dialogs "+en);
     Chosen(main,"MT4-01","MT4-02");Open(main,grid,"MT4-01");menu.Close();Call(main,"OpenStudent",Row(grid,"MT4-03"));Call(main,"ShowStudentManagement");Pump();
     Check(Targets(main).SequenceEqual(new[]{"MT4-03"}),"report-page Manage resets to that student's scope "+en);((ContextMenuStrip)Get(main,"studentManagementMenu")).Close();Call(main,"CloseStudent");Pump();
     Chosen(main,"MT4-01","MT4-02");Open(main,grid,"MT4-01");menu.Close();string confirm="";
     Dialogs(()=>((ToolStripMenuItem)Get(main,"miRowRemove")).PerformClick(),d=>{confirm=string.Join("\n",All(d).OfType<Label>().Select(c=>c.Text));return DialogResult.No;});
     Check(confirm.Contains("MT4-01")&&confirm.Contains("MT4-02")&&!confirm.Contains("MT4-03")&&accounts.All.Count()==3,"group delete confirmation names exact targets and Cancel preserves accounts "+en);
     // Delete only synthetic empty copy paths first, avoiding native recycle APIs in this Linux smoke test.
     Directory.Delete(Path.Combine(settings.BaseDir,"MT4-01"),true);Directory.Delete(Path.Combine(settings.BaseDir,"MT4-02"),true);
     Dialogs(()=>((ToolStripMenuItem)Get(main,"miRowRemove")).PerformClick(),d=>DialogResult.Yes);Pump();
     Check(accounts.Get("MT4-01")==null&&accounts.Get("MT4-02")==null&&accounts.Get("MT4-03")!=null,"confirmed row-menu deletion removes only the captured selected group "+en);
     Set(main,"appClosing",true);main.Close();Pump();
    }
   }
   var failed=new StudentImportRow{Name="Displayed Name",OriginalName="نام اصلی",Login="001234",Platform="MT5",Server="NeverCopied",Investor="001234",Reason="NeverCopiedExplanation",State=ImportState.Failed};
   Check(TextStudentImport.CorrectionText(new[]{failed})=="Displayed Name · 001234","issue clipboard is identity only even when password happens to match account number");
   failed.Login="";Check(TextStudentImport.CorrectionText(new[]{failed})=="Displayed Name","missing account is not invented or replaced with explanatory text");
   Console.WriteLine("SELECTED ROW ACTIONS PASS "+checks);return 0;
  }
  catch(Exception e){Console.Error.WriteLine(e);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
