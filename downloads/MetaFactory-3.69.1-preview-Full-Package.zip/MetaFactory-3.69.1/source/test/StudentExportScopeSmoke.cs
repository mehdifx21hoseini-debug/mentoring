using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Reflection;using System.Drawing;using System.Threading;using System.Windows.Forms;using MTManager;
class StudentExportScopeSmoke
{
 static readonly BindingFlags F=BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic;static readonly Assembly A=typeof(Settings).Assembly;static int checks;
 static object Get(object o,string n){return o.GetType().GetField(n,F).GetValue(o);}static object Prop(object o,string n){return o.GetType().GetProperty(n,F).GetValue(o,null);}static object Call(object o,string n,params object[] args){return o.GetType().GetMethods(F).Single(m=>m.Name==n&&m.GetParameters().Length==args.Length).Invoke(o,args);}static void Check(bool b,string s){if(!b)throw new Exception(s);checks++;Console.WriteLine("PASS "+s);}static void Pump(){for(int j=0;j<4;j++){Application.DoEvents();Thread.Sleep(15);}}
 static void Shot(Form f,string path){f.Location=new Point(10,10);Pump();using(var b=new Bitmap(f.Width,f.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(f.Location,Point.Empty,f.Size);b.Save(path);}}
 static Form Dialog(IEnumerable<Instance> copies,AccountStore accounts,FolderStore folders,string[] selected,string folder){return (Form)Activator.CreateInstance(A.GetType("MTManager.StudentExportDialog"),F,null,new object[]{copies,accounts,folders,selected,folder},null);}
 static void ChooseFolder(Form d,string id){var ids=(List<string>)Get(d,"folderIds");((ComboBox)Get(d,"folderChoice")).SelectedIndex=ids.IndexOf(id);}
 static string Ids(IEnumerable<string> names){return string.Join("|",names.OrderBy(n=>n,StringComparer.OrdinalIgnoreCase));}
 [STAThread]static int Main(string[] args)
 {
  string root=Path.Combine(Path.GetTempPath(),"export-scope-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);Directory.CreateDirectory(args[0]);
  try
  {
   Application.EnableVisualStyles();A.GetType("MTManager.Theme").GetMethod("Init",F).Invoke(null,null);AppPaths.DataDirOverride=Path.Combine(root,"data");Directory.CreateDirectory(AppPaths.DataDir);var accounts=new AccountStore();
   var copies=new List<Instance>();for(int j=1;j<=3;j++){string n=(j==3?"MT5":"MT4")+"-0"+j;var c=new Instance{Name=n,Kind=j==3?Kind.MT5:Kind.MT4,Dir=Path.Combine(root,n)};copies.Add(c);Directory.CreateDirectory(c.Dir);File.WriteAllText(c.Exe,"synthetic not executed");accounts.SetQueue(new Account{Instance=n,Trader="Student "+j,Login=j==2?"0001":"000"+j,Platform=c.Kind.ToString(),Server="Sample-Demo",Mode="investor",InvestorEnc=Secret.Protect("OnlySecret"+j),MasterEnc=Secret.Protect("OnlyMaster"+j),DeferredDir=c.Dir});}
   accounts.SetQueue(new Account{Instance="MT5-missing",Trader="Missing copy",Login="0009",Platform="MT5",Server="Sample-Demo",InvestorEnc=Secret.Protect("MissingSecret9")});accounts.Save();var folders=new FolderStore();var first=folders.Create("Group A");var second=folders.Create("Group B");var empty=folders.Create("Empty group");folders.Add(first.Id,new[]{"MT4-01","MT5-missing"});folders.Add(second.Id,new[]{"MT4-01","MT4-02"});folders.Save();var accountBytes=File.ReadAllBytes(AppPaths.AccountsFile);var folderBytes=File.ReadAllBytes(FolderStore.FilePath);
   var all=StudentExport.ScopeNames(copies,accounts,folders,StudentExportScope.All,null);Check(all.Count==4&&all.Contains("MT5-missing"),"all scope includes account-only students");
   var selected=StudentExport.ScopeNames(copies,accounts,folders,StudentExportScope.Selected,new[]{"mt4-01","MT4-01","deleted"});Check(Ids(selected)=="MT4-01","selected scope deduplicates instance IDs and never pulls in same-login peers");
   Check(StudentExport.ScopeNames(copies,accounts,folders,StudentExportScope.Selected,null).Count==0,"missing checked selection does not become all");
   var group=StudentExport.ScopeNames(copies,accounts,folders,StudentExportScope.Folder,null,first.Id);Check(Ids(group)=="MT4-01|MT5-missing","folder scope includes exact members including missing copy");
   Check(StudentExport.ScopeNames(copies,accounts,folders,StudentExportScope.Folder,null,second.Id).Count==2,"overlapping memberships export one row per student");
   Check(Ids(StudentExport.ScopeNames(copies,accounts,folders,StudentExportScope.Folder,null,StudentExport.UnfiledKey))=="MT5-03","No folder scope includes only unfiled students");
   Check(StudentExport.ScopeNames(copies,accounts,folders,StudentExportScope.Folder,null,"deleted-folder").Count==0&&StudentExport.ScopeNames(copies,accounts,folders,StudentExportScope.Folder,null,empty.Id).Count==0,"invalid and empty folders never fall back to all");
   Check(StudentExport.ScopeNames(copies,accounts,folders,(StudentExportScope)(-1),null).Count==0,"invalid scope does not become all");
   var legacy=StudentExport.Rows(copies,accounts,folders,true);var explicitAll=StudentExport.Rows(copies,accounts,folders,true,all);Check(legacy.Select(r=>string.Join("\t",r)).SequenceEqual(explicitAll.Select(r=>string.Join("\t",r))),"all mode preserves exact existing export schema and values");
   var rows=StudentExport.Rows(copies,accounts,folders,true,selected);Check(rows.Count==2&&rows[1][6]=="MT4-01"&&rows[1][2]=="0001"&&rows[1][4]=="OnlySecret1","subset contains only chosen record with original text IDs and password option");
   Check(rows[1][10]=="Group A | Group B","subset preserves exported student's other memberships");
   Check(StudentExport.Rows(copies,accounts,folders,true,new string[0]).Count==1&&StudentExport.Rows(copies,accounts,folders,true,(IEnumerable<string>)null).Count==1,"empty or missing explicit subset cannot export roster");
   var without=StudentExport.Rows(copies,accounts,folders,false,group);Check(without.Skip(1).All(r=>r[4]==""&&r[9]==""&&r[12]=="Excluded"),"password opt-out still excludes secrets in folder scope");
   string path=Path.Combine(root,"selected.xlsx");StudentExport.Write(path,rows,true,"Export scope: Selected students");var sheet=Spreadsheet.Read(path);Check(sheet.Count==2&&sheet[1].Cells[6]=="MT4-01"&&sheet[1].Cells[2]=="0001","real XLSX contains only selected student and preserves leading zeros");
   Check(StudentImport.Read(path,null).Single().State==ImportState.Ready,"scoped workbook remains import-compatible");
   string raw=string.Join("\n",sheet.SelectMany(r=>r.Cells.Values));Check(!raw.Contains("OnlySecret2")&&!raw.Contains("OnlyMaster2")&&!raw.Contains("Student 2")&&!raw.Contains("MissingSecret9"),"excluded students and their passwords absent from workbook");
   StudentExport.Write(path,without,false,"Export scope: Group A");sheet=Spreadsheet.Read(path);Check(sheet.Count==3&&sheet.Skip(1).All(r=>r.Cells[4]==""&&r.Cells[9]==""),"folder workbook contains exact scoped rows with excluded passwords");
   Check(File.ReadAllBytes(AppPaths.AccountsFile).SequenceEqual(accountBytes)&&File.ReadAllBytes(FolderStore.FilePath).SequenceEqual(folderBytes),"exports never mutate accounts or folder memberships");
   foreach(bool en in new[]{true,false})
   {
    Lang.En=en;
    using(var d=Dialog(copies,accounts,folders,new[]{"MT4-02","MT5-03"},first.Id))
    {
     d.Show();Pump();Check((StudentExportScope)Prop(d,"Scope")==StudentExportScope.Selected,"checked students take default priority over viewed folder "+en);Check(((Label)Get(d,"countLabel")).Text.Contains(en?"2":"۲"),"exact preview count visible "+en);
     Check(!((ComboBox)Get(d,"folderChoice")).Enabled&&((CheckBox)Get(d,"passwords")).Checked,"folder picker mode and existing password default retained "+en);
     var saveButton=(Button)Get(d,"save");Check(d.Width<1100&&d.Height<850&&d.ClientRectangle.Contains(new Rectangle(d.PointToClient(saveButton.PointToScreen(Point.Empty)),saveButton.Size)),"export dialog stays within screen "+en);
     Shot(d,Path.Combine(args[0],"selected-"+en+".png"));((Button)Get(d,"save")).PerformClick();Check(Ids((List<string>)Prop(d,"TargetNames"))=="MT4-02|MT5-03","save captures exact checked group "+en);
    }
    using(var d=Dialog(copies,accounts,folders,new string[0],first.Id))
    {
     d.Show();Pump();Check((StudentExportScope)Prop(d,"Scope")==StudentExportScope.Folder&&(string)Prop(d,"FolderId")==first.Id,"viewed folder becomes default without checked students "+en);
     ChooseFolder(d,second.Id);Check(((Label)Get(d,"countLabel")).Text.Contains(en?"2":"۲"),"changing folder updates preview count "+en);Check(((string)Prop(d,"SuggestedFileName")).Contains("Group B"),"folder-specific default file name "+en);
     ((CheckBox)Get(d,"passwords")).Checked=false;Check(!(bool)Prop(d,"IncludePasswords"),"existing password option remains editable "+en);Shot(d,Path.Combine(args[0],"folder-"+en+".png"));((Button)Get(d,"save")).PerformClick();Check(Ids((List<string>)Prop(d,"TargetNames"))=="MT4-01|MT4-02","folder save captures only that folder's members "+en);
    }
    using(var d=Dialog(copies,accounts,folders,new string[0],null))
    {
     d.Show();Pump();Check((StudentExportScope)Prop(d,"Scope")==StudentExportScope.All,"unfiltered default remains all students "+en);var combo=(ComboBox)Get(d,"scope");combo.SelectedIndex=1;Check(!((Button)Get(d,"save")).Enabled,"empty selection disables save "+en);Call(d,"AcceptScope");Check(Prop(d,"TargetNames")==null,"empty selection cannot bypass accept guard "+en);
     combo.SelectedIndex=2;ChooseFolder(d,empty.Id);Check(!((Button)Get(d,"save")).Enabled,"empty folder disables save "+en);ChooseFolder(d,StudentExport.UnfiledKey);Check(((Button)Get(d,"save")).Enabled,"No folder is a valid export choice "+en);combo.SelectedIndex=-1;Check(!((Button)Get(d,"save")).Enabled,"invalid UI scope disables save "+en);combo.SelectedIndex=0;((Button)Get(d,"save")).PerformClick();Check(((List<string>)Prop(d,"TargetNames")).Count==4,"explicit all can be chosen from a limited context "+en);
    }
    using(var d=Dialog(copies,accounts,folders,new string[0],"deleted-folder"))
    {Check((StudentExportScope)Prop(d,"Scope")==StudentExportScope.Folder&&!((Button)Get(d,"save")).Enabled,"deleted viewed folder never defaults silently to full export "+en);}
   }
   Lang.En=true;var settings=new Settings{BaseDir=root,AutoStart=false,LastBackup=DateTime.Now};
   using(var main=(Form)Activator.CreateInstance(A.GetType("MTManager.MainForm"),F,null,new object[]{settings,accounts},null))
   {
    main.WindowState=FormWindowState.Normal;main.Bounds=new Rectangle(10,10,1280,900);main.Show();Pump();foreach(var field in main.GetType().GetFields(F))if(field.FieldType==typeof(System.Windows.Forms.Timer))((System.Windows.Forms.Timer)field.GetValue(main)).Stop();
    var bar=Get(main,"folderBar");bar.GetType().GetProperty("Selected",F).SetValue(bar,"f:"+first.Id,null);Pump();var roster=StudentDirectory.All(settings,accounts);
    using(var options=(Form)Call(main,"CreateStudentExportDialog",roster))Check((StudentExportScope)Prop(options,"Scope")==StudentExportScope.Folder&&(string)Prop(options,"FolderId")==first.Id,"main export entry passes current folder independent of visible rows");
    Call(Get(main,"chosen"),"Toggle","MT4-02");Call(Get(main,"chosen"),"Toggle","MT5-03");
    using(var options=(Form)Call(main,"CreateStudentExportDialog",roster)){Check((StudentExportScope)Prop(options,"Scope")==StudentExportScope.Selected,"main export entry passes actual checked students instead of highlighted row");Call(options,"AcceptScope");Check(Ids((List<string>)Prop(options,"TargetNames"))=="MT4-02|MT5-03","main export selection retains checked students outside current folder filter");}
    Call(main,"ClearChoice");bar.GetType().GetProperty("Selected",F).SetValue(bar,"none",null);Pump();using(var options=(Form)Call(main,"CreateStudentExportDialog",roster))Check((StudentExportScope)Prop(options,"Scope")==StudentExportScope.Folder&&(string)Prop(options,"FolderId")==StudentExport.UnfiledKey,"main No folder view is translated to explicit export scope");
    main.GetType().GetField("appClosing",F).SetValue(main,true);main.Close();Pump();
   }
   Console.WriteLine("STUDENT EXPORT SCOPE PASS "+checks);return 0;
  }
  catch(Exception error){Console.Error.WriteLine(error);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
