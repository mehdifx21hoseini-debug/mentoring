using System;using System.IO;using System.Linq;using System.Collections.Generic;using MTManager;
class TextFieldRolesSmoke
{
 static int checks;static void Check(bool ok,string label){if(!ok)throw new Exception(label);checks++;Console.WriteLine("PASS "+label);}
 static List<StudentImportRow> Parse(string text){return TextStudentImport.Parse(text,true,new string[0],k=>k==Kind.MT5?new[]{"Alpari-MT5-Demo","WMMarkets-Demo"}:new[]{"WMMarkets-DEMO"},"WMMarkets");}
 static void Main(){string root=Path.Combine(Path.GetTempPath(),"text-roles-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=root;try{
 var a=Parse("74001\nSyntheticOnly!9@\nالپاری\nAlpari-mt5-demo");
 Check(a.Count==1&&a[0].Name=="No Name 1"&&a[0].OriginalName=="","account-first nameless record gets a placeholder rather than exposing a password as a name");
 Check(a[0].Investor=="SyntheticOnly!9@"&&a[0].Broker=="الپاری","bare Alpari broker is not assigned to investor password");
 Check(a[0].Platform=="MT5"&&a[0].Kind==Kind.MT5&&a[0].Server=="Alpari-mt5-demo"&&a[0].State==ImportState.Ready,"complete Alpari MT5 server supplies the missing platform and keeps the exact server");
 a=Parse("SyntheticOnly!9@\n74002\nآلپاری\nAlpari-MT5-Demo");Check(a.Count==1&&a[0].Name=="No Name 1"&&a[0].Login=="74002"&&a[0].Investor=="SyntheticOnly!9@"&&a[0].State==ImportState.Ready,"password-first nameless record also retains its independent login and password");
 a=Parse("74003\nSyntheticOnly!3@\nAlpari\nAlpari-MT5-Demo\n74004\nSyntheticOnly!4@\nالپاری\nAlpari-MT5-Demo");Check(a.Count==2&&a[0].Name=="No Name 1"&&a[1].Name=="No Name 2"&&a[0].Investor=="SyntheticOnly!3@"&&a[1].Investor=="SyntheticOnly!4@"&&a.All(r=>r.State==ImportState.Ready),"two adjacent unnamed accounts stay separate with sequential names and no credential mixing");
 a=Parse("74005\nSyntheticOnly!5@\nAlpari\nAlpari-MT5-Demo\nNamed Person\n74006\nSyntheticOnly!6@\nAlpari\nAlpari-MT5-Demo");Check(a.Count==2&&a[0].Name=="No Name 1"&&a[1].Name=="Named Person"&&a[1].Login=="74006"&&a.All(r=>r.State==ImportState.Ready),"following person's bare name does not become the previous unnamed owner's name");
 a=Parse("Name: Explicit Person\nAccount: 74007\nInvestor: ExactOnly!Case9@\nBroker: Alpari\nServer: Alpari-MT5-Demo");Check(a.Count==1&&a[0].Name=="Explicit Person"&&a[0].OriginalName=="Explicit Person"&&a[0].Investor=="ExactOnly!Case9@"&&a[0].Platform=="MT5","explicit names and password case/punctuation remain unchanged");
 a=Parse("Name: Conflict Person\nAccount: 74008\nInvestor: ExactOnly!Case9@\nServer: Alpari-MT5-Demo\nPlatform: MT4");Check(a.Count==1&&a[0].Platform=="MT4"&&a[0].State==ImportState.Invalid&&a[0].InputProblem.Contains("پلتفرم"),"explicit platform conflicting with the server is flagged rather than silently changed");
 a=Parse("Account: 74009\nInvestor: ExactOnly!Case9@\nServer: Other-Demo");Check(a.Count==1&&a[0].Platform==""&&a[0].State==ImportState.Invalid,"account numbers and generic server names do not invent MT4 or MT5");
 a=Parse("Account: 74010\nInvestor: ExactOnly!Case9@\nServer: Other-MT45-Demo");Check(a[0].Platform==""&&a[0].State==ImportState.Invalid,"MT45 substring does not imply MT4");
 a=Parse("Account: 74011\nInvestor: ExactOnly!Case9@\nServer: Other-MT4-MT5-Demo");Check(a[0].Platform==""&&a[0].State==ImportState.Invalid,"multiple conflicting platform tokens do not select an arbitrary platform");
 a=Parse("Name: Person 9\nAccount: 74012\nInvestor: ExactOnly!Case9@\nServer: Alpari-MT5-Demo");Check(a[0].Name=="Person 9"&&a[0].State==ImportState.Ready,"explicit name labels preserve names containing digits");
 a=Parse("74013\nAa7@B@92!Cc4\nالپاری\nدمو \nAlpari-mt5-demo");Check(a.Count==1&&a[0].Name=="No Name 1"&&a[0].Investor=="Aa7@B@92!Cc4"&&a[0].Broker=="الپاری"&&a[0].Platform=="MT5"&&a[0].Server=="Alpari-mt5-demo"&&a[0].State==ImportState.Ready,"supplied five-line Alpari message shape retains the exact password and endpoint after a Persian Demo line");
 var old=new Account{Instance="MT5-01",Platform="MT5",Login="74013",Server="Alpari-mt5-demo",Trader="Known Person",OriginalTrader="Known Original",Mode="investor",InvestorEnc=Secret.Protect("Aa7@B@92!Cc4")};ImportFlow.NormalizeExisting(a[0],old);Check(a[0].Name=="Known Person"&&a[0].OriginalName=="Known Original","generated placeholder cannot erase a known existing account owner name");
 a=Parse("74013\nAa7@B@92!Cc4\nالپاری\nدمو\nAlpari-mt5-demo");a[0].Name="Edited Person";ImportFlow.NormalizeExisting(a[0],old);Check(a[0].Name=="Edited Person","manual name edits remain explicit and are not replaced by the old name");
 a=Parse("Name: No Name 1\nAccount: 74014\nInvestor: Aa7@B@92!Cc4\nServer: Alpari-MT5-Demo\nSender:\n74015\nAa7@B@92!Cc4\nAlpari\nAlpari-MT5-Demo");Check(a.Count==2&&a[0].Name=="No Name 1"&&a[1].Name=="No Name 2","generated names avoid a name already explicitly supplied in the same batch");
 Console.WriteLine("TEXT FIELD ROLES PASS "+checks);
 }finally{Directory.Delete(root,true);}}
}
