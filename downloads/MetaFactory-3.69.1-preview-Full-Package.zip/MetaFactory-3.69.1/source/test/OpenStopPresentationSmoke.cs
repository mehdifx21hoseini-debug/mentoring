using System;using System.IO;using System.Linq;using System.Collections;using System.Collections.Generic;using System.Reflection;using System.Drawing;using System.Threading;using System.Windows.Forms;using MTManager;
class OpenStopPresentationSmoke
{
 static readonly BindingFlags F=BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic;static readonly Assembly A=typeof(Settings).Assembly;static readonly Type R=A.GetType("MTManager.CopyRow"),P=A.GetType("MTManager.AccountRowPresentation"),G=A.GetType("MTManager.CopyGrid");static int checks;
 static object Get(object o,string n){return o.GetType().GetField(n,F).GetValue(o);}static void Set(object o,string n,object v){o.GetType().GetField(n,F).SetValue(o,v);}static object Call(object o,string n,params object[] args){return o.GetType().GetMethods(F).Single(m=>m.Name==n&&m.GetParameters().Length==args.Length).Invoke(o,args);}static void Check(bool v,string why){if(!v)throw new Exception(why);checks++;Console.WriteLine("PASS "+why);}static void Pump(){for(int k=0;k<4;k++){Application.DoEvents();Thread.Sleep(15);}}
 static object Row(){return Activator.CreateInstance(R,true);}static void Stops(object row,Instance copy,Account account,AccountJournal journal,LiveFeedSnapshot feed=null,bool pending=false){P.GetMethod("ApplyOpenStops",F).Invoke(null,new object[]{row,copy,account,journal,feed,pending,DateTime.UtcNow});}
 static LiveFeedSnapshot Feed(string platform,double[] stops,DateTime? time=null,string server="Sample-Demo",AccountJournal history=null)
 {
  var frame=Activator.CreateInstance(A.GetType("MTManager.LiveFeedFrame"),true);Set(frame,"Run",new string('a',32));Set(frame,"Sequence",1L);Set(frame,"Heartbeat",time??DateTime.UtcNow);Set(frame,"Values",new[]{1100.0,1100.0,0.0,1100.0,0.0});Set(frame,"Currency","USD");Set(frame,"State","history-pending");
  var positions=(IList)Get(frame,"Positions");for(int k=0;k<stops.Length;k++)positions.Add(Activator.CreateInstance(typeof(LivePosition),F,null,new object[]{(long)(k+1),"EURUSD",true,.1,DateTime.UtcNow.AddMinutes(-5),new[]{1.1,stops[k],0.0,0.0,0.0,-1.0,1.1,0.0}},null));
  return (LiveFeedSnapshot)Activator.CreateInstance(typeof(LiveFeedSnapshot),F,null,new object[]{history==null?LiveFeedStatus.HistoryPending:LiveFeedStatus.Live,"",platform,"10001",server,frame,history},null);
 }
 static DateTime Seconds(DateTime value){return value.AddTicks(-(value.Ticks%TimeSpan.TicksPerSecond));}
 static AccountJournal Snapshot(string platform="MT4")
 {var j=new AccountJournal{Platform=platform,Login="10001",Server="Sample-Demo",Currency="USD",Complete=true,Exported=DateTime.UtcNow,GmtOffset=0,Balance=1000,Equity=1000};j.Open.Add(new JournalOpen{Ticket=1,Symbol="EURUSD",Volume=.1,Open=DateTime.UtcNow.AddHours(-1),OpenPrice=1.1,Sl=0,SlEntry=1.0,CurrentSlKnown=true});return j;}
 static void Model()
 {
  foreach(var kind in new[]{Kind.MT4,Kind.MT5})
  {
   var copy=new Instance{Name=kind+"-01",Kind=kind};var account=new Account{Instance=copy.Name,Login="10001",Server="Sample-Demo"};var j=Snapshot(kind.ToString());var row=Row();Stops(row,copy,account,j);
   Check((bool)Get(row,"TodayNoSl")&&(int?)Get(row,"TodayOpenNoSlCount")==1,"current zero stop is flagged even when entry stop existed "+kind);
   j.Open[0].Sl=1.05;j.Open[0].SlEntry=0;Stops(row,copy,account,j);Check(!(bool)Get(row,"TodayNoSl")&&(int?)Get(row,"TodayOpenNoSlCount")==0,"entry stop absence does not flag a currently protected trade "+kind);
   j.Open[0].CurrentSlKnown=null;j.Open[0].Sl=0;Stops(row,copy,account,j);Check(!(bool)Get(row,"TodayNoSl")&&(int?)Get(row,"TodayOpenSlUnknownCount")==1,"unproven model default zero remains unknown "+kind);
   j.Open[0].CurrentSlKnown=true;j.Open[0].Sl=-1;Stops(row,copy,account,j);Check(!(bool)Get(row,"TodayNoSl"),"negative current stop is unknown rather than absent "+kind);
   j.Open.Clear();j.Trades.Add(new JournalTrade{Ticket=3,SlEntry=0,SlFinal=0});Stops(row,copy,account,j);Check(!(bool)Get(row,"TodayNoSl"),"closed trades with no stop do not create open-trade badge "+kind);
   var live=Feed(kind.ToString(),new[]{0.0,1.05,-1.0});Stops(row,copy,account,null,live,true);Check((bool)Get(row,"TodayNoSl")&&(int?)Get(row,"TodayOpenNoSlCount")==1&&(int?)Get(row,"TodayOpenSlUnknownCount")==1,"fresh pending live positions support known and unknown current stops separately "+kind);
   string before=(string)row.GetType().GetProperty("Key",F).GetValue(row,null);Stops(row,copy,account,null,Feed(kind.ToString(),new[]{1.05,1.1,-1.0}),true);Check(!(bool)Get(row,"TodayNoSl")&&before!=(string)row.GetType().GetProperty("Key",F).GetValue(row,null),"adding a stop removes badge and invalidates row painting key "+kind);
   Stops(row,copy,account,j,Feed(kind.ToString(),new[]{0.0},DateTime.UtcNow.AddSeconds(-20)),true);Check(!(bool)Get(row,"TodayNoSl")&&Get(row,"TodayOpenNoSlCount")==null,"stale live source cannot create No SL or borrow manual fallback "+kind);
   Stops(row,copy,account,j,Feed(kind.ToString(),new[]{0.0},null,"Other-Demo"),true);Check(!(bool)Get(row,"TodayNoSl"),"wrong-account server feed cannot create No SL "+kind);
   j=Snapshot(kind.ToString());j.Complete=false;Stops(row,copy,account,j);Check(!(bool)Get(row,"TodayNoSl"),"incomplete report cannot create a stop warning "+kind);
   j=Snapshot(kind.ToString());j.Server="Other-Demo";Stops(row,copy,account,j);Check(!(bool)Get(row,"TodayNoSl"),"unbound journal cannot create a stop warning "+kind);
  }
  var journal=Snapshot();string raw=JournalFile.Write(journal);var valid=JournalFile.Parse(raw);Check(valid.Open[0].CurrentSlKnown==true&&valid.Open[0].Sl==0,"valid explicit zero retains stop provenance");
  foreach(string token in new[]{"","?","NaN","Infinity","-1"})
  {
   string damaged=string.Join("\n",raw.Split('\n').Select(line=>{if(!line.StartsWith("O\t"))return line;var f=line.Split('\t');f[7]=token;return string.Join("\t",f);}));var parsed=JournalFile.Parse(damaged);Check(parsed.Open[0].CurrentSlKnown==false,"invalid/missing current stop has unknown provenance "+token);
   double legacy=parsed.Open[0].Sl;var cached=JournalFile.Parse(JournalFile.Write(parsed));Check(cached.Open[0].CurrentSlKnown==false&&cached.Open[0].Sl==legacy,"cache round trip retains unknown provenance and unchanged numeric fallback "+token);
  }
 }
 static void Layout()
 {
  var scaleType=A.GetType("MTManager.Theme");int line=(int)scaleType.GetMethod("S",F,null,new[]{typeof(int)},null).Invoke(null,new object[]{18});
  using(var bitmap=new Bitmap(900,160))using(var graphics=Graphics.FromImage(bitmap))foreach(bool en in new[]{true,false})
  {
   Lang.En=en;
   foreach(int width in new[]{160,200,240,300})foreach(string open in new[]{"Open: 1","Open: 10000"})
   {
    string[] parts={"-$12,345.67","125 trades",open};object[] args={graphics,parts,new Rectangle(0,0,width,line),null};var rects=(Rectangle[])G.GetMethod("TodaySegments",F).Invoke(null,args);var font=(Font)args[3];int measured=TextRenderer.MeasureText(graphics,open,font,Size.Empty,TextFormatFlags.NoPadding|TextFormatFlags.NoPrefix|TextFormatFlags.SingleLine).Width;
    Check(rects[2].Width>=measured&&rects.All(rect=>rect.Left>=0&&rect.Right<=width),"Open count has full measured space with bounded segments "+en+" "+width+" "+open);
   }
   var row=Row();Set(row,"TodayNoSl",true);Set(row,"TodayOpenNoSlCount",2);var area=new Rectangle(0,0,220,line);var badge=(Rectangle)G.GetMethod("NoSlBadgeRect",F).Invoke(null,new object[]{row,area});Check(area.Contains(badge)&&badge.Width>0,"No SL badge fits its dedicated footer space "+en);
  }
 }
static JournalBalanceEvent E(long ticket,DateTime time,int type,double net){return new JournalBalanceEvent{Ticket=ticket,TimeMilliseconds=(long)(time-new DateTime(1970,1,1)).TotalMilliseconds,Type=type,Net=net};}
static AccountJournal Journal(string login){var now=Seconds(DateTime.UtcNow.AddHours(2));var first=now.Date.AddSeconds(Math.Floor((now-now.Date).TotalSeconds*.4));var last=now.Date.AddSeconds(Math.Floor((now-now.Date).TotalSeconds*.8));var dep=now.Date.AddDays(-3);var j=new AccountJournal{Platform="MT4",Login=login,Server="Sample-Demo",Currency="USD",Balance=1100,Equity=9999,Complete=true,GmtOffset=7200,Exported=now,From=now.Date.AddDays(-30),TrustedFrom=now.Date.AddDays(-30),ScriptVersion="1.23",HistoryChecked=true,HistoryOk=true,HistorySum=1100,HistoryBalance=1100,FullHistoryPresent=true,FullHistoryValid=true,FullHistoryReconciled=true,FullHistoryScanOk=true,FullHistoryRequested=true,FullHistoryCount=3,FullHistorySum=1100,FullHistoryBalance=1100,LastTrade=last};j.Cash.Add(new JournalCash{Time=dep,Amount=1000,Kind=2});j.FullHistory.AddRange(new[]{E(1,dep,2,1000),E(2,first,0,200),E(3,last,1,-100)});j.Trades.Add(new JournalTrade{Ticket=2,Symbol="EURUSD",Volume=.1,Open=first.AddSeconds(-1),Close=first,Profit=200});j.Trades.Add(new JournalTrade{Ticket=3,Symbol="EURUSD",Volume=.1,Open=last.AddSeconds(-1),Close=last,Profit=-100});j.Open.Add(new JournalOpen{Ticket=4,Symbol="EURUSD",Volume=.1,Open=first,Profit=100});return j;}
static PanelView View(AccountJournal j){return PanelMath.Build(j,ServerDays.Range(PanelRange.Today,j.Exported.Date,j.Exported.Date,j.Exported.Date.AddDays(1)),new TradeLimits());}
 static void Shot(Form f,string path){f.Location=new Point(10,10);Pump();using(var b=new Bitmap(f.Width,f.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(f.Location,Point.Empty,f.Size);b.Save(path);}}
 [STAThread]static int Main(string[] args)
 {
  string root=Path.Combine(Path.GetTempPath(),"open-stop-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);Directory.CreateDirectory(args[0]);AppPaths.DataDirOverride=Path.Combine(root,"model");Directory.CreateDirectory(AppPaths.DataDir);
  try
  {
   Application.EnableVisualStyles();A.GetType("MTManager.Theme").GetMethod("Init",F).Invoke(null,null);Model();Layout();
   foreach(bool en in new[]{true,false})
   {
    Lang.En=en;AppPaths.DataDirOverride=Path.Combine(root,en?"en":"fa");Directory.CreateDirectory(AppPaths.DataDir);var settings=new Settings{BaseDir=Path.Combine(AppPaths.DataDir,"copies"),AutoStart=false,LastBackup=DateTime.Now};var account=new Account{Instance="MT4-01",Trader="Sample student",Login="10001",Server="Sample-Demo",Platform="MT4",Mode="investor",InvestorEnc=Secret.Protect("SyntheticOnly9")};var accounts=new AccountStore();accounts.SetQueue(account);accounts.Save();var copy=new Instance{Name=account.Instance,Kind=Kind.MT4,Dir=Path.Combine(settings.BaseDir,account.Instance)};Directory.CreateDirectory(copy.Dir);File.WriteAllText(copy.Exe,"synthetic never executed");
    var j=Journal(account.Login);j.Open.Clear();j.Open.Add(new JournalOpen{Ticket=9,Symbol="EURUSD",Volume=.1,Open=j.Exported.AddMinutes(-5),OpenPrice=1.1,Sl=0,SlEntry=1.0,CurrentSlKnown=true});Check(JournalCache.Save(j),"bound synthetic report saved "+en);
    using(var main=(Form)Activator.CreateInstance(A.GetType("MTManager.MainForm"),F,null,new object[]{settings,accounts},null))
    {
     main.WindowState=FormWindowState.Normal;main.Bounds=new Rectangle(10,10,1300,900);main.Show();Pump();foreach(var field in main.GetType().GetFields(F))if(field.FieldType==typeof(System.Windows.Forms.Timer))((System.Windows.Forms.Timer)field.GetValue(main)).Stop();var grid=(DataGridView)Get(main,"grid");var row=grid.Rows[0].Tag;
     Check((bool)Get(row,"TodayNoSl")&&(int?)Get(row,"TodayOpenNoSlCount")==1&&((string)Get(row,"TodayText")).Contains(" · Open · "),"actual MainForm Today path keeps open stop warning and count "+en);
     Check(((string)Get(row,"TodayTip")).Contains(en?"Current stops":"حد ضرر فعلی"),"tooltip explains current open-stop basis "+en);
     var target=LiveMonitorTarget.Create(copy,account);var feed=Feed("MT4",new[]{0.0},null,account.Server,j);
     var projector=Activator.CreateInstance(A.GetType("MTManager.LiveDashboardProjectionCache"),true);var data=Call(projector,"Update",target,feed,new LiveReportSummary{HistoryReady=true,TodayKnown=true});
     Check(data!=null&&((AccountJournal)Get(data,"Journal")).Open[0].CurrentSlKnown==true,"live projection retains current-stop provenance "+en);
     var view=Activator.CreateInstance(A.GetType("MTManager.LiveMonitorView"),true);Set(view,"Target",target);Set(view,"Feed",feed);Set(view,"Dashboard",data);((IDictionary)Get(main,"dashboardRows"))[copy.Name]=view;Call(main,"RefreshGrid",false);row=grid.Rows[0].Tag;
     Check((bool)Get(row,"TodayLive")&&(bool)Get(row,"TodayNoSl"),"verified live row retains both green freshness and No SL "+en);
     Set(row,"Running",true);grid.Invalidate();Pump();
     var cell=grid.GetCellDisplayRectangle(grid.Columns["Action"].Index,0,false);object[] rectArgs={cell,row,Rectangle.Empty,Rectangle.Empty};G.GetMethod("ActionRects",F).Invoke(grid,rectArgs);var openRect=(Rectangle)rectArgs[2];var moreRect=(Rectangle)rectArgs[3];Check(cell.Contains(openRect)&&cell.Contains(moreRect)&&!openRect.IntersectsWith(moreRect),"narrow action column keeps Open and vertical menu targets separate and inside cell "+en);
     object[] hit={new Point(moreRect.X+moreRect.Width/2,moreRect.Y+moreRect.Height/2),0};var part=G.GetMethod("PartAt",F).Invoke(grid,hit);Check(part.ToString()=="More","vertical menu keeps existing menu click action "+en);
     Shot(main,Path.Combine(args[0],"open-no-sl-"+en+".png"));
     ((IDictionary)Get(main,"dashboardRows")).Clear();((IDictionary)Get(main,"dashboardLast")).Clear();
     var students=(IDictionary)Get(main,"students");var manual=students[copy.Name];var fresh=Journal(account.Login);fresh.Open.Clear();fresh.Open.Add(new JournalOpen{Ticket=9,Symbol="EURUSD",Volume=.1,Open=fresh.Exported.AddMinutes(-5),OpenPrice=1.1,Sl=1.05,SlEntry=0,CurrentSlKnown=true});fresh.Exported=j.Exported.AddSeconds(1);Check(JournalCache.Save(fresh),"updated current-stop report saved "+en);Set(manual,"Loaded",false);Call(main,"RefreshGrid",false);row=grid.Rows[0].Tag;Check(!(bool)Get(row,"TodayNoSl"),"actual Today update removes warning when a current stop exists "+en);
     Set(main,"appClosing",true);main.Close();Pump();
    }
   }
   Console.WriteLine("OPEN STOP PRESENTATION PASS "+checks);return 0;
  }
  catch(Exception error){Console.Error.WriteLine(error);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
