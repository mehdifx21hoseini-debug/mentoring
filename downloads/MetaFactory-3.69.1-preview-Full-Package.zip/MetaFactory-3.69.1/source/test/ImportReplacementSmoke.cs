using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Threading;using MTManager;
class ImportReplacementSmoke
{
 static int checks;static string root;static int scenario;
 static void Check(bool v,string why){if(!v)throw new Exception(why);checks++;Console.WriteLine("PASS "+why);}
 sealed class Verifier:IAccountVerifier
 {readonly Func<Account,ImportConnection> run;public Verifier(Func<Account,ImportConnection> run){this.run=run;}public ImportConnection Verify(Account a,int ms,Func<bool> cancel,Action<string> stage){return run(a);}public void Dispose(){}}
 static Settings Setup(out AccountStore accounts,out FolderStore folders)
 {
  AppPaths.DataDirOverride=Path.Combine(root,(++scenario).ToString());Directory.CreateDirectory(AppPaths.DataDir);var s=new Settings{BaseDir=Path.Combine(AppPaths.DataDir,"copies")};Directory.CreateDirectory(s.BaseDir);accounts=new AccountStore();folders=new FolderStore();accounts.Save();folders.Save();return s;
 }
 static Account Seed(AccountStore store,string instance,string login="1234",string platform="MT4")
 {var a=new Account{Instance=instance,Login=login,Platform=platform,Trader="Old student",OriginalTrader="نام قدیمی",Server="Old-Demo",Mode="investor",InvestorEnc=Secret.Protect("OldSynthetic9"),DeferredDir=Path.Combine(AppPaths.DataDir,"copies",instance),VerifyState="rejected",VerifyReason="old reason"};store.SetQueue(a);store.Save();return store.Get(instance);}
 static StudentImportRow Row(string login="001234",string platform="MT4")
 {return new StudentImportRow{Name="New student",OriginalName="نام جدید",Login=login,Platform=platform,Kind=platform=="MT4"?Kind.MT4:Kind.MT5,Server="New-Demo",Mode="investor",Investor="NewSynthetic9",State=ImportState.Duplicate};}
 static void Approve(AccountStore store,params StudentImportRow[] rows)
 {Check(ImportReplacement.Resolve(rows,store,(r,m)=>new ImportDuplicateDecision{Action=ImportDuplicateAction.Replace,Instance=m[0].Instance}),"replacement choice resolved");}
 static void Run(Settings settings,AccountStore store,FolderStore folders,StudentImportRow row,Func<Account,ImportConnection> verify,Func<bool> cancel=null)
 {using(var coordinator=new ImportCoordinator(settings,store,folders,i=>new Verifier(verify),1))coordinator.VerifyAndRegister(new[]{row},"Ignored incoming folder",cancel??(()=>false),r=>{});}
 static ImportConnection Connected(){return new ImportConnection{Connected=true,State=Login.Waiting,Retryable=false};}
 static int Main()
 {
  root=Path.Combine(Path.GetTempPath(),"replace-import-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);Lang.En=true;
  try
  {
   AccountStore accounts;FolderStore folders;var settings=Setup(out accounts,out folders);var old=Seed(accounts,"MT4-01");var row=Row();
   Check(ImportReplacement.Matches(accounts,row).Single().Instance==old.Instance,"duplicate identity ignores changed server and leading zeros");
   var arabic=Row("٠٠١٢٣٤");Check(ImportReplacement.Matches(accounts,arabic).Length==1,"duplicate identity normalizes Arabic digits");
   Directory.CreateDirectory(old.DeferredDir);string history=Path.Combine(old.DeferredDir,"saved-history.txt"),note=Path.Combine(AppPaths.DataDir,"student-notes.tsv");File.WriteAllText(history,"retained history");File.WriteAllText(note,"retained notes");
   var folder=folders.Create("Existing group");folders.Add(folder.Id,new[]{old.Instance});folders.Save();byte[] folderBytes=File.ReadAllBytes(FolderStore.FilePath),historyBytes=File.ReadAllBytes(history),noteBytes=File.ReadAllBytes(note);
   Approve(accounts,row);bool probed=false;Run(settings,accounts,folders,row,job=>{probed=true;Check(accounts.Get(old.Instance).CredentialKey==old.CredentialKey,"old credentials remain active while new credentials are checked");Check(job.Server=="New-Demo"&&job.PasswordForLogin()=="NewSynthetic9","private verifier receives incoming credentials");return Connected();});
   var updated=accounts.Get(old.Instance);Check(probed&&row.Replaced&&row.State==ImportState.Connected&&row.Copy==old.Instance,"verified replacement reuses exact existing instance");
   Check(accounts.All.Count()==1&&updated.Login=="001234"&&updated.Server=="New-Demo"&&updated.Trader=="New student"&&updated.OriginalTrader=="نام جدید","replacement updates incoming account details without a second student");
   Check(updated.DeferredDir==old.DeferredDir&&updated.Platform==old.Platform&&updated.VerifyState=="connected"&&updated.VerifyToken=="","path and platform retained; stale verification token invalidated");
   Check(File.ReadAllBytes(FolderStore.FilePath).SequenceEqual(folderBytes)&&File.ReadAllBytes(history).SequenceEqual(historyBytes)&&File.ReadAllBytes(note).SequenceEqual(noteBytes),"folder memberships, notes and history preserved byte for byte");
   Check(AccountStore.Load().Get(old.Instance).Server=="New-Demo","replacement persists atomically across store reload");
   Check(TextStudentImport.CorrectionText(new[]{row})=="","successful replacement not listed as a failed import");
   foreach(var outcome in new[]{Login.WrongLogin,Login.Waiting})
   {
    settings=Setup(out accounts,out folders);old=Seed(accounts,"MT4-01");row=Row();var bytes=File.ReadAllBytes(AppPaths.AccountsFile);Approve(accounts,row);
    Run(settings,accounts,folders,row,job=>new ImportConnection{Connected=false,State=outcome,Retryable=false,Reason="No login proof NewSynthetic9"});
    Check(!row.Saved&&!row.Replaced&&accounts.Get(old.Instance).CredentialKey==old.CredentialKey&&File.ReadAllBytes(AppPaths.AccountsFile).SequenceEqual(bytes),"rejected/timeout replacement preserves prior durable account "+outcome);
    Check(row.Reason.IndexOf("NewSynthetic9",StringComparison.Ordinal)<0&&ImportPreviewDetails.Short(row).Contains("قبلی حفظ شد"),"failed replacement reason redacted and concise "+outcome);
   }
   settings=Setup(out accounts,out folders);old=Seed(accounts,"MT4-01");row=Row();row.State=ImportState.Ready;int calls=0;
   Run(settings,accounts,folders,row,job=>{calls++;return Connected();});Check(calls==0&&row.State==ImportState.Duplicate&&accounts.Get(old.Instance).CredentialKey==old.CredentialKey,"unapproved duplicate cannot silently verify or overwrite");
   settings=Setup(out accounts,out folders);old=Seed(accounts,"MT4-01");row=Row();Approve(accounts,row);row.Investor="EditedAfterApproval9";calls=0;
   Run(settings,accounts,folders,row,job=>{calls++;return Connected();});Check(calls==0&&!row.Saved&&accounts.Get(old.Instance).CredentialKey==old.CredentialKey,"approval does not authorize edited credentials");
   settings=Setup(out accounts,out folders);old=Seed(accounts,"MT4-01");row=Row();Approve(accounts,row);bool stop=false;
   Run(settings,accounts,folders,row,job=>{stop=true;return Connected();},()=>stop);Check(row.State==ImportState.Cancelled&&accounts.Get(old.Instance).CredentialKey==old.CredentialKey,"cancellation after verification preserves old account");
   settings=Setup(out accounts,out folders);old=Seed(accounts,"MT4-01");row=Row();Approve(accounts,row);var concurrent=old.Snapshot();concurrent.InvestorEnc=Secret.Protect("ConcurrentNew9");
   Run(settings,accounts,folders,row,job=>{accounts.SetQueue(concurrent);accounts.Save();return Connected();});Check(!row.Replaced&&accounts.Get(old.Instance).CredentialKey==concurrent.CredentialKey,"concurrent credential change is not overwritten by stale approval");
   settings=Setup(out accounts,out folders);old=Seed(accounts,"MT4-01");row=Row();Approve(accounts,row);
   Run(settings,accounts,folders,row,job=>{accounts.Remove(old.Instance);accounts.Save();return Connected();});Check(!row.Replaced&&accounts.Get(old.Instance)==null,"deleted target is not resurrected");
   settings=Setup(out accounts,out folders);old=Seed(accounts,"MT4-01");row=Row();Approve(accounts,row);string backup=AppPaths.AccountsFile+".test-backup";var saved=File.ReadAllBytes(AppPaths.AccountsFile);
   Run(settings,accounts,folders,row,job=>{File.Move(AppPaths.AccountsFile,backup);Directory.CreateDirectory(AppPaths.AccountsFile);return Connected();});
   Check(!row.Replaced&&!row.Saved&&accounts.Get(old.Instance).CredentialKey==old.CredentialKey&&File.ReadAllBytes(backup).SequenceEqual(saved),"save failure rolls in-memory replacement back and preserves durable old bytes");Directory.Delete(AppPaths.AccountsFile);File.Move(backup,AppPaths.AccountsFile);
   settings=Setup(out accounts,out folders);old=Seed(accounts,"MT4-01");row=Row("1234","MT5");Approve(accounts,row);Check(row.State==ImportState.Invalid&&row.ReplacementAccount==null&&accounts.Get(old.Instance).CredentialKey==old.CredentialKey,"cross-platform duplicate detected but incompatible terminal folder never relabeled");
   settings=Setup(out accounts,out folders);Seed(accounts,"MT4-01","1234");Seed(accounts,"MT4-02","5678");StudentImportRow first=Row(),second=Row("5678"),repeat=Row();calls=0;
   ImportReplacement.Resolve(new[]{first,second,repeat},accounts,(r,m)=>{calls++;return new ImportDuplicateDecision{Action=ImportDuplicateAction.Replace,ApplyAll=true,Instance=m[0].Instance};});
   Check(calls==1&&first.State==ImportState.Ready&&second.State==ImportState.Ready&&repeat.State==ImportState.Duplicate,"apply-all replaces unique accounts and file repeats ask only once");
   settings=Setup(out accounts,out folders);Seed(accounts,"MT4-01");Seed(accounts,"MT4-02");row=Row();
   ImportReplacement.Resolve(new[]{row},accounts,(r,m)=>new ImportDuplicateDecision{Action=ImportDuplicateAction.Replace,Instance="MT4-02"});Run(settings,accounts,folders,row,job=>Connected());
   Check(row.Copy=="MT4-02"&&accounts.Get("MT4-01").Server=="Old-Demo"&&accounts.Get("MT4-02").Server=="New-Demo","multiple existing matches require and honor exact selected target");
   settings=Setup(out accounts,out folders);Seed(accounts,"MT4-01");row=Row();var before=File.ReadAllBytes(AppPaths.AccountsFile);
   Check(!ImportReplacement.Resolve(new[]{row},accounts,(r,m)=>new ImportDuplicateDecision{Action=ImportDuplicateAction.Cancel})&&File.ReadAllBytes(AppPaths.AccountsFile).SequenceEqual(before),"cancelling duplicate choice writes no account data");
   ImportReplacement.Resolve(new[]{row},accounts,(r,m)=>new ImportDuplicateDecision{Action=ImportDuplicateAction.Skip});Check(row.State==ImportState.Duplicate&&row.ReplacementAccount==null,"Skip leaves duplicate unmodified");
   row=Row();Approve(accounts,row);TextStudentImport.Revalidate(new[]{row},accounts.All.Select(a=>StudentImport.Key(StudentDirectory.KindOf(a),a.Login,a.Server)));Check(row.State==ImportState.Duplicate&&row.ReplacementAccount==null,"revalidation clears transient replacement approval");
   settings=Setup(out accounts,out folders);Seed(accounts,"MT4-01","1234");Seed(accounts,"MT4-02","5678");Seed(accounts,"MT4-03","5678");first=Row();second=Row("5678");calls=0;
   ImportReplacement.Resolve(new[]{first,second},accounts,(r,m)=>{calls++;return new ImportDuplicateDecision{Action=ImportDuplicateAction.Skip,ApplyAll=true};});
   Check(calls==1&&first.State==ImportState.Duplicate&&second.State==ImportState.Duplicate,"skip-all includes ambiguous existing matches without another prompt");
   row=Row("5678");ImportReplacement.Resolve(new[]{row},accounts,(r,m)=>new ImportDuplicateDecision{Action=ImportDuplicateAction.Replace});Check(row.State==ImportState.Invalid&&row.ReplacementAccount==null,"ambiguous matches never silently choose the first record");
   settings=Setup(out accounts,out folders);old=Seed(accounts,"MT4-01");row=Row();row.Server="New-Real1";row.ImportServers="New-Real1|New-Real2";Approve(accounts,row);
   Run(settings,accounts,folders,row,job=>new ImportConnection{Connected=job.Server=="New-Real2",State=job.Server=="New-Real2"?Login.Waiting:Login.WrongLogin,Retryable=true});
   Check(row.Replaced&&row.Server=="New-Real2"&&accounts.Get(old.Instance).Server=="New-Real2","verified server candidate can replace without invalidating prior input approval");
   settings=Setup(out accounts,out folders);old=Seed(accounts,"MT4-01");row=Row();row.OriginalName="";Approve(accounts,row);Run(settings,accounts,folders,row,job=>Connected());Check(accounts.Get(old.Instance).OriginalTrader==old.OriginalTrader,"unprovided original-name metadata is retained");
   var invalid=Row();invalid.State=ImportState.Invalid;invalid.Platform="";invalid.Login="";invalid.Server="";invalid.Reason="Additional ambiguous text; review this row. Platform must be MT4 or MT5; Server is empty";
   Check(ImportPreviewDetails.Short(invalid).Contains("MT4/MT5")&&ImportPreviewDetails.Short(invalid).Contains("سرور")&&!ImportPreviewDetails.Short(invalid).Contains("متن اضافه"),"short invalid details identify missing fields instead of generic boilerplate");
   foreach(bool cancelledNotice in new[]{false,true})
   {
    settings=Setup(out accounts,out folders);old=Seed(accounts,"MT4-01");row=Row();Approve(accounts,row);
    using(var coordinator=new ImportCoordinator(settings,accounts,folders,i=>new Verifier(job=>Connected()),1))
     coordinator.VerifyAndRegister(new[]{row},"",()=>false,r=>{if(r.Replaced){if(cancelledNotice)throw new OperationCanceledException();throw new InvalidOperationException("synthetic disposed view");}});
    Check(row.Replaced&&row.State==ImportState.Connected&&accounts.Get(old.Instance).Server=="New-Demo","post-commit display notification failure cannot misreport a saved replacement "+cancelledNotice);
   }
   var failed=Row();failed.State=ImportState.Failed;failed.Outcome=Login.WrongLogin;failed.Reason="Account/password rejected or account disabled; MetaTrader did not distinguish the cause. Not added. Check the account number, investor password and exact server.";
   Check(ImportPreviewDetails.Short(failed)=="ورود رد شد؛ حساب یا رمز بررسی شود."&&failed.Reason.Contains("did not distinguish"),"short visible reason preserves full diagnostic source and uncertainty");
   Check(TextStudentImport.CorrectionText(new[]{failed})=="New student · 001234","issue copy stays name/account only");
   Console.WriteLine("IMPORT REPLACEMENT PASS "+checks);return 0;
  }
  catch(Exception e){Console.Error.WriteLine(e);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
