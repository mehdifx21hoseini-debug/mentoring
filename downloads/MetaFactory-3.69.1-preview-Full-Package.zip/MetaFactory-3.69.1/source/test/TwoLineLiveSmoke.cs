using System;using System.IO;using System.Linq;using System.Collections;using System.Reflection;using System.Drawing;using System.Threading;using System.Windows.Forms;using MTManager;
class TwoLineLiveSmoke
{
 static readonly BindingFlags F=BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic;static readonly Assembly A=typeof(Settings).Assembly;static readonly Type R=A.GetType("MTManager.CopyRow"),M=A.GetType("MTManager.LiveRowMetrics"),P=A.GetType("MTManager.AccountRowPresentation");static int checks;
 static object Get(object o,string n){return o.GetType().GetField(n,F).GetValue(o);}static void Set(object o,string n,object v){o.GetType().GetField(n,F).SetValue(o,v);}static object Call(object o,string n,params object[] args){return o.GetType().GetMethods(F).Single(m=>m.Name==n&&m.GetParameters().Length==args.Length).Invoke(o,args);}static void Check(bool v,string why){if(!v)throw new Exception(why);checks++;Console.WriteLine("PASS "+why);}static void Pump(){for(int k=0;k<4;k++){Application.DoEvents();Thread.Sleep(15);}}
 static object Row(int? closed,int? open){var row=Activator.CreateInstance(R,true);Set(row,"TodayClosedCount",closed);Set(row,"TodayOpenCount",open);return row;}
 static LiveFeedSnapshot Feed(Kind kind,AccountJournal history,DateTime now,bool pending=false,string version="1.07",string server="Synthetic-Demo")
 {
  var frame=Activator.CreateInstance(A.GetType("MTManager.LiveFeedFrame"),true);Set(frame,"Run","synthetic-run");Set(frame,"Sequence",1L);Set(frame,"Revision",1L);Set(frame,"Heartbeat",now);Set(frame,"Values",new[]{history.Balance,history.Balance+.09,0.0,history.Balance+.09,0.0});Set(frame,"Currency","USD");Set(frame,"State",pending?"history-unconfirmed":"ready");Set(frame,"ObserverVersion",version);
  var positions=(IList)Get(frame,"Positions");foreach(var p in history.Open)positions.Add(Activator.CreateInstance(typeof(LivePosition),F,null,new object[]{p.Ticket,p.Symbol,p.Buy,p.Volume,p.Open,new[]{p.OpenPrice,p.Sl,p.Tp,p.Profit,p.Swap,p.SlEntry,p.Price,p.Commission}},null));
  return (LiveFeedSnapshot)Activator.CreateInstance(typeof(LiveFeedSnapshot),F,null,new object[]{pending?LiveFeedStatus.HistoryPending:LiveFeedStatus.Live,"test",kind.ToString(),history.Login,server,frame,pending?null:history},null);
 }
 static PanelView View(AccountJournal j,int closed=7,double net=222.12){return new PanelView{Range=new ReportRange{From=j.Exported.Date,To=j.Exported.Date.AddDays(1)},Currency="USD",Closed=closed,ClosedNet=net,Floating=j.Open.Sum(p=>p.Profit+p.Swap+p.Commission)};}
 static void Apply(object row,Instance copy,Account account,AccountJournal journal,PanelView view,LiveFeedSnapshot feed=null,bool pending=false,bool current=false,DateTime? utc=null)
 {P.GetMethod("ApplyOpenStops",F).Invoke(null,new object[]{row,copy,account,journal,feed,pending,utc??DateTime.UtcNow});M.GetMethod("Apply",F).Invoke(null,new object[]{row,copy,account,journal,view,feed,pending,current,utc??DateTime.UtcNow});}
 static AccountJournal Journal(Kind kind=Kind.MT4,bool open=true)
 {
  var now=DateTime.UtcNow.AddTicks(-(DateTime.UtcNow.Ticks%TimeSpan.TicksPerSecond));var j=new AccountJournal{Platform=kind.ToString(),Login="10001",Server="Synthetic-Demo",Currency="USD",Balance=1000,Complete=true,HistoryChecked=true,HistoryOk=true,Exported=now,From=now.Date.AddDays(-30),GmtOffset=0};
  for(int k=0;k<7;k++)j.Trades.Add(new JournalTrade{Ticket=k+1,Symbol="EURUSD",Open=now.Date,Close=now.Date.AddSeconds(k+1),SlFinal=k<3?0:1.05,FinalSlKnown=true,Profit=10});
  if(open){j.Open.Add(new JournalOpen{Ticket=20,Symbol="BTCUSD",Volume=.01,Open=now.AddMinutes(-5),OpenPrice=60000,Sl=0,CurrentSlKnown=true,Profit=-7.50});j.Open.Add(new JournalOpen{Ticket=21,Symbol="BTCUSD",Volume=.01,Open=now.AddMinutes(-4),OpenPrice=59000,Sl=58000,CurrentSlKnown=true,Profit=7.59});}
  if(kind==Kind.MT5)foreach(var t in j.Trades)j.Deals.Add(new JournalDeal{Ticket=t.Ticket+100,Position=t.Ticket,Time=t.Close,Type=0,Entry=1,Profit=t.Profit});
  return j;
 }
 static void Model()
 {
  foreach(var kind in new[]{Kind.MT4,Kind.MT5})foreach(bool en in new[]{true,false})
  {
   Lang.En=en;var copy=new Instance{Name=kind+"-01",Kind=kind};var account=new Account{Instance=copy.Name,Login="10001",Server="Synthetic-Demo"};var j=Journal(kind);var row=Row(7,2);Apply(row,copy,account,j,View(j));var text=(string)Get(row,"TodayText");
   Check(text=="+$0.09 · Open · 2 trades · No SL: 1","open amount is only two actual floating positions, not daily closed/combined total "+kind+" "+en);
   Check((double?)Get(row,"TodayNet")<.091&&(bool)Get(row,"TodayCompactMetrics"),"sorting/presentation value follows displayed floating amount "+kind+" "+en);
   j.Open.RemoveAt(0);row=Row(8,1);Apply(row,copy,account,j,View(j,8,214.62));Check(((string)Get(row,"TodayText"))=="+$7.59 · Open · 1 trade","one remaining position excludes closed P/L and removes current no-SL warning "+kind+" "+en);
   j=Journal(kind,false);row=Row(7,0);Apply(row,copy,account,j,View(j));Check((string)Get(row,"TodayText")=="+$222.12 · Close · 7 trades · No SL: 3","after all positions close show day amount and exact closed no-SL count "+kind+" "+en);
   Check((int?)Get(row,"TodayClosedNoSlCount")==3&&((string)Get(row,"TodayTip")).Contains("SL at close"),"closed warning count explicitly uses recorded stop at close "+kind+" "+en);
   j=Journal(kind,false);j.Trades[0].FinalSlKnown=false;row=Row(7,0);Apply(row,copy,account,j,View(j));Check(((string)Get(row,"TodayText")).EndsWith("No SL: ≥2"),"mixed known/unknown closed stops never claim exact missing count "+kind+" "+en);
   j=Journal(kind);var now=DateTime.UtcNow;var pending=Feed(kind,j,now,true);row=Row(null,null);Apply(row,copy,account,null,null,pending,true,false,now);Check(((string)Get(row,"TodayText"))=="+$0.09 · Open · 2 trades · No SL: 1"&&((string)Get(row,"TodayAgo")).Contains("History pending"),"pending baseline does not delay fresh floating display "+kind+" "+en);
   row=Row(7,2);Apply(row,copy,account,j,View(j),Feed(kind,j,now),false,true,now);Check((string)Get(row,"TodayAgo")=="Live · Just now","fresh live footer uses approved Just now label "+kind+" "+en);
   row=Row(7,2);Apply(row,copy,account,j,View(j),Feed(kind,j,now.AddSeconds(-9)),false,true,now);Check((string)Get(row,"TodayAgo")=="Live · Just now"&&((string)Get(row,"TodayTip")).Contains("9s ago"),"freshness window retains real heartbeat age in tooltip "+kind+" "+en);
   row=Row(7,2);Set(row,"TodayAgo","Report: 14 min ago");Apply(row,copy,account,j,View(j),Feed(kind,j,now.AddSeconds(-11)),false,false,now);Check((string)Get(row,"TodayAgo")=="Report: 14 min ago"&&!(bool)Get(row,"TodayLive"),"stale feed never becomes Just now "+kind+" "+en);
   var old=Feed(kind,j,now,true,null);row=Row(null,null);Apply(row,copy,account,null,null,old,true,false,now);Check(((string)Get(row,"TodayAgo")).Contains(kind==Kind.MT4?"Restart reporter":"History pending"),"legacy MT4 heartbeat explicitly identifies observer restart need "+kind+" "+en);
   foreach(var bad in new[]{Feed(kind,j,now.AddSeconds(-11),true),Feed(kind,j,now.AddSeconds(6),true),Feed(kind,j,now,true,"1.07","Other-Demo")}){row=Row(null,null);Apply(row,copy,account,null,null,bad,true,false,now);Check(!(bool)Get(row,"TodayCompactMetrics"),"stale/future/mismatched positions cannot override report "+kind+" "+en);}
   j=Journal(kind,false);now=DateTime.UtcNow;row=Row(null,null);Apply(row,copy,account,null,null,Feed(kind,j,now,true),true,false,now);Check((string)Get(row,"TodayText")=="— · Close · — trades"&&Get(row,"TodayNet")==null,"pending after final close keeps daily result unknown until verified "+kind+" "+en);
   row=Row(7,0);Set(row,"TodayBusy",true);Apply(row,copy,account,j,View(j));Check(!(bool)Get(row,"TodayCompactMetrics"),"busy/queued presentation remains unchanged "+kind+" "+en);
  }
  var mt5=Journal(Kind.MT5,false);mt5.Deals.Add(new JournalDeal{Ticket=999,Position=1,Time=mt5.Trades[0].Close,Type=1,Entry=1});var r=Row(8,0);Apply(r,new Instance{Name="MT5-01",Kind=Kind.MT5},new Account{Login="10001",Server="Synthetic-Demo"},mt5,View(mt5,8));Check(((string)Get(r,"TodayText")).EndsWith("No SL: —"),"MT5 multiple partial exits cannot inherit an aggregate position stop count");
  var j4=Journal();string raw=JournalFile.Write(j4);foreach(string token in new[]{"","?","NaN","Infinity","-1"})
  {string damaged=string.Join("\n",raw.Split('\n').Select(line=>{if(!line.StartsWith("T\t"))return line;var f=line.Split('\t');f[10]=token;return string.Join("\t",f);}));var parsed=JournalFile.Parse(damaged);Check(parsed.Trades.All(t=>t.FinalSlKnown==false),"invalid closed-stop source stays unknown "+token);var cached=JournalFile.Parse(JournalFile.Write(parsed));Check(cached.Trades.All(t=>t.FinalSlKnown==false)&&cached.Trades.Sum(t=>t.Net)==parsed.Trades.Sum(t=>t.Net),"cache preserves unknown provenance without altering numeric financial result "+token);}
  string template="MLIVE\t1\tMT4\nQ\t"+new string('a',32)+"\nR\ttest\t1\t1795790832\nA\t10001\tSynthetic-Demo\tUSD\nS\t1\tready\nV\t1000\t1000\t0\t1000\t0\nH\t1\t1\nEND\t0\n";var parser=A.GetType("MTManager.LiveFeedReader").GetMethod("Parse",F);Check(parser.Invoke(null,new object[]{template})!=null,"legacy snapshot remains accepted without observer metadata");var frame=parser.Invoke(null,new object[]{template.Replace("END\t0","E\t1.07\nEND\t0")});Check(frame!=null&&(string)Get(frame,"ObserverVersion")=="1.07","running MT4 observer version comes from the actual heartbeat");foreach(string e in new[]{"E\t1.07\nE\t1.07","E\tbogus","E\t1.07\textra"})Check(parser.Invoke(null,new object[]{template.Replace("END\t0",e+"\nEND\t0")})==null,"duplicate/malformed observer metadata is rejected");
  Check(LiveReporter.SourceText(Kind.MT4).Contains("Line(h,\"E\\t1.07\")")&&LiveReporter.SourceText(Kind.MT4).Contains("#property version \"1.07\""),"native heartbeat and expected reporter version agree");
 }
 static JournalBalanceEvent E(long ticket,DateTime time,int type,double net){return new JournalBalanceEvent{Ticket=ticket,TimeMilliseconds=(long)(time-new DateTime(1970,1,1)).TotalMilliseconds,Type=type,Net=net};}
 static AccountJournal Proven(bool open=true)
 {var j=Journal(Kind.MT4,open);j.Trades.Clear();j.FullHistory.Add(E(1,j.Exported.Date.AddDays(-3),2,1000));for(int k=0;k<7;k++){var time=j.Exported.Date.AddSeconds((int)((j.Exported-j.Exported.Date).TotalSeconds*(k+1)/10));j.Trades.Add(new JournalTrade{Ticket=k+2,Symbol="EURUSD",Volume=.01,Open=time.AddSeconds(-1),Close=time,SlFinal=k<3?0:1.05,FinalSlKnown=true,Profit=10});j.FullHistory.Add(E(k+2,time,0,10));}j.Cash.Add(new JournalCash{Time=j.Exported.Date.AddDays(-3),Amount=1000,Kind=2});j.Balance=1070;j.Equity=1070.09;j.HistorySum=j.HistoryBalance=1070;j.FullHistoryPresent=j.FullHistoryValid=j.FullHistoryReconciled=j.FullHistoryScanOk=j.FullHistoryRequested=true;j.FullHistoryCount=8;j.FullHistorySum=j.FullHistoryBalance=1070;j.TrustedFrom=j.From;return j;}
 static void Shot(Form f,string path){f.Location=new Point(10,10);Pump();using(var b=new Bitmap(f.Width,f.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(f.Location,Point.Empty,f.Size);b.Save(path);}}
 [STAThread]static int Main(string[] args)
 {
  string root=Path.Combine(Path.GetTempPath(),"two-line-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);Directory.CreateDirectory(args[0]);AppPaths.DataDirOverride=root;
  try
  {
   Application.EnableVisualStyles();A.GetType("MTManager.Theme").GetMethod("Init",F).Invoke(null,null);Model();
   foreach(bool en in new[]{true,false})
   {
    Lang.En=en;AppPaths.DataDirOverride=Path.Combine(root,en?"en":"fa");Directory.CreateDirectory(AppPaths.DataDir);var settings=new Settings{BaseDir=Path.Combine(AppPaths.DataDir,"copies"),AutoStart=false,LastBackup=DateTime.Now};var account=new Account{Instance="MT4-01",Trader="Sample student",Login="10001",Server="Synthetic-Demo",Platform="MT4",Mode="investor",InvestorEnc=Secret.Protect("SyntheticOnly9")};var accounts=new AccountStore();accounts.SetQueue(account);accounts.Save();var copy=new Instance{Name=account.Instance,Kind=Kind.MT4,Dir=Path.Combine(settings.BaseDir,account.Instance)};Directory.CreateDirectory(copy.Dir);File.WriteAllText(copy.Exe,"synthetic never executed");var j=Proven();Check(JournalCache.Save(j),"bound synthetic report saved "+en);
    using(var main=(Form)Activator.CreateInstance(A.GetType("MTManager.MainForm"),F,null,new object[]{settings,accounts},null))
    {
     main.WindowState=FormWindowState.Normal;main.Bounds=new Rectangle(10,10,1320,900);main.Show();Pump();foreach(var field in main.GetType().GetFields(F))if(field.FieldType==typeof(System.Windows.Forms.Timer))((System.Windows.Forms.Timer)field.GetValue(main)).Stop();var grid=(DataGridView)Get(main,"grid");var row=grid.Rows[0].Tag;
     Check((string)Get(row,"TodayText")=="+$0.09 · Open · 2 trades · No SL: 1","actual main snapshot excludes realized day result while positions exist "+en);
     var target=LiveMonitorTarget.Create(copy,account);var feed=Feed(Kind.MT4,j,DateTime.UtcNow);var projector=Activator.CreateInstance(A.GetType("MTManager.LiveDashboardProjectionCache"),true);var data=Call(projector,"Update",target,feed,new LiveReportSummary{HistoryReady=true,TodayKnown=true});Check(data!=null,"verified live projection built "+en);var view=Activator.CreateInstance(A.GetType("MTManager.LiveMonitorView"),true);Set(view,"Target",target);Set(view,"Feed",feed);Set(view,"Dashboard",data);((IDictionary)Get(main,"dashboardRows"))[copy.Name]=view;Call(main,"RefreshGrid",false);row=grid.Rows[0].Tag;
     Check((bool)Get(row,"TodayLive")&&(string)Get(row,"TodayText")=="+$0.09 · Open · 2 trades · No SL: 1","actual fresh live row matches MT4 two-position floating total "+en);Shot(main,Path.Combine(args[0],"open-"+en+".png"));
     var cell=grid.GetCellDisplayRectangle(grid.Columns["Today"].Index,0,false);using(var b=new Bitmap(600,100))using(var g=Graphics.FromImage(b)){var theme=A.GetType("MTManager.Theme");int pad=(int)theme.GetMethod("S",F,null,new[]{typeof(int)},null).Invoke(null,new object[]{16});object[] metric={g,((string)Get(row,"TodayText")).Split(new[]{" · "},StringSplitOptions.None),new Rectangle(0,0,cell.Width-pad,24),null};var rects=(Rectangle[])A.GetType("MTManager.CopyGrid").GetMethod("TodaySegments",F).Invoke(null,metric);var parts=(string[])metric[1];var font=(Font)metric[3];Check(rects.Select((rect,k)=>rect.Width>=TextRenderer.MeasureText(g,parts[k],font,Size.Empty,TextFormatFlags.NoPrefix|TextFormatFlags.NoPadding|TextFormatFlags.SingleLine).Width).All(x=>x),"all compact English metric fields fit the actual Today width "+en);}
     Set(view,"Feed",Feed(Kind.MT4,j,DateTime.UtcNow,true,null));Set(view,"Dashboard",null);Call(main,"RefreshGrid",false);row=grid.Rows[0].Tag;Check(((string)Get(row,"TodayAgo")).Contains("Restart reporter")&&((string)Get(row,"TodayText")).Contains("+$0.09"),"actual legacy pending observer is identified while floating stays fresh "+en);
     Set(view,"Feed",Feed(Kind.MT4,j,DateTime.UtcNow,true,"1.07"));Call(main,"RefreshGrid",false);row=grid.Rows[0].Tag;Check(((string)Get(row,"TodayAgo")).Contains("History pending")&&!((string)Get(row,"TodayAgo")).Contains("Restart reporter"),"actual new heartbeat removes legacy warning without faking history readiness "+en);
     ((IDictionary)Get(main,"dashboardRows")).Clear();((IDictionary)Get(main,"dashboardLast")).Clear();var closed=Proven(false);closed.Exported=j.Exported.AddSeconds(1);Check(JournalCache.Save(closed),"closed report saved "+en);var manual=((IDictionary)Get(main,"students"))[copy.Name];Set(manual,"Loaded",false);Call(main,"RefreshGrid",false);row=grid.Rows[0].Tag;Check((string)Get(row,"TodayText")=="+$70.00 · Close · 7 trades · No SL: 3","actual main row transitions to day result and closed stop count "+en);Shot(main,Path.Combine(args[0],"closed-"+en+".png"));
     Set(main,"appClosing",true);main.Close();Pump();
    }
   }
   Console.WriteLine("TWO LINE LIVE PASS "+checks);return 0;
  }
  catch(Exception error){Console.Error.WriteLine(error);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
