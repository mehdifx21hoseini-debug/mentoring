using System;using System.IO;using System.Text;using MTManager;
class PrivateMt4SpeedSmoke
{
 static int checks;static void Check(bool ok,string label){if(!ok)throw new Exception(label);checks++;Console.WriteLine("PASS "+label);}
 static void Main(){string root=Path.Combine(Path.GetTempPath(),"mt4-speed-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);try{
 Check(!PrivateMt4Check.FlushDue(11999,60000,Login.Waiting),"does not interrupt the first startup window");
 Check(PrivateMt4Check.FlushDue(12000,60000,Login.Waiting),"pending private MT4 gets an early journal flush instead of sixty seconds blind waiting");
 Check(PrivateMt4Check.FlushDue(12000,60000,Login.NoConnection),"buffered no-connection can be inspected without calling it a wrong password");
 Check(!PrivateMt4Check.FlushDue(56000,60000,Login.Waiting),"does not restart when the original deadline has insufficient time");
 foreach(Login state in new[]{Login.Connected,Login.WrongLogin,Login.NoServer})Check(!PrivateMt4Check.FlushDue(12000,60000,state),"decisive result finishes immediately: "+state);
 var copy=new Instance{Dir=root,Kind=Kind.MT4};var a=new Account{Login="70001",Server="WMMarkets-REAL6",VerifyToken=new string('a',32)};var since=DateTime.Now;string journal=ConnectionCheck.JournalFile(copy,since);Directory.CreateDirectory(Path.GetDirectoryName(journal));string marker=Path.Combine(root,"proof.txt");
 File.WriteAllText(journal,"12:00:00 '70001': login on WMMarkets-REAL6\r\n",Encoding.Unicode);var watch=new LoginWatch();watch.BeginSession(copy,a.Login,since);
 Check(!PrivateMt4Check.Closed(watch,copy,a,since,marker).Connected,"old cached successful login is excluded");
 File.AppendAllText(journal,"12:01:00 '70001': invalid password\r\n",Encoding.Unicode);var reject=PrivateMt4Check.Closed(watch,copy,a,since,marker);
 Check(reject.State==Login.WrongLogin&&PrivateMt4Check.Conclusive(reject),"new flushed rejection ends fast without a full-window restart");
 watch=new LoginWatch();watch.BeginSession(copy,a.Login,since);File.AppendAllText(journal,"12:02:00 '70001': login on WMMarkets-REAL6\r\n",Encoding.Unicode);
 Check(PrivateMt4Check.Closed(watch,copy,a,since,marker).Connected,"new flushed successful login is accepted without a chart marker");
 watch=new LoginWatch();watch.BeginSession(copy,a.Login,since);File.AppendAllText(journal,"12:03:00 '70001': no connection\r\n",Encoding.Unicode);var pending=PrivateMt4Check.Closed(watch,copy,a,since,marker);
 Check(!PrivateMt4Check.Conclusive(pending)&&pending.State!=Login.WrongLogin,"network failure keeps full verification opportunity and never rejects credentials");
 Check(!PrivateMt4Check.Exhausted(pending).Retryable,"exhausted full window avoids an automatic duplicate minute");
 File.WriteAllText(marker,"MTMLOGIN\t1\t"+new string('b',32)+"\t70001\tWMMarkets-REAL6\tconnected\r\n");
 Check(!PrivateMt4Check.Closed(watch,copy,a,since,marker).Connected,"old marker cannot prove the new request");
 File.WriteAllText(marker,"MTMLOGIN\t1\t"+a.VerifyToken+"\t70001\tWMMarkets-REAL6\tconnected\r\n");
 Check(PrivateMt4Check.Closed(watch,copy,a,since,marker).Connected,"final flushed exact-token marker is not lost during close");
 Console.WriteLine("PRIVATE MT4 SPEED PASS "+checks);
 }finally{Directory.Delete(root,true);}}
}
