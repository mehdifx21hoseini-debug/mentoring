using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Diagnostics;using System.Globalization;using MTManager;
class StorageRetentionSmoke {
static int checks;static DateTime now=new DateTime(2026,11,27,12,0,0,DateTimeKind.Utc);static string root;
static void Check(bool b,string s){if(!b)throw new Exception(s);checks++;Console.WriteLine("PASS "+s);}
static string FileAt(string p,int days,string text="keep"){Directory.CreateDirectory(Path.GetDirectoryName(p));File.WriteAllText(p,text);File.SetLastWriteTimeUtc(p,now.AddDays(-days));return p;}
static string Snap(string parent,int days){string p=Path.Combine(parent,now.AddDays(-days).ToString("yyyyMMdd-HHmmss",CultureInfo.InvariantCulture)+"-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(p);FileAt(Path.Combine(p,"chart01.chr"),days);Directory.SetLastWriteTimeUtc(p,now.AddDays(-days));return p;}
static List<StorageRetention.Item> Scan(Instance c,string[] active=null){return StorageRetention.Scan(new[]{c},now,active);}
static int Main(){root=Path.Combine(Path.GetTempPath(),"storage-retention-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);try{
var c=new Instance{Name="MT4-01",Kind=Kind.MT4,Dir=Path.Combine(root,"MT4-01")};Directory.CreateDirectory(c.Dir);
string oldLog=FileAt(Path.Combine(c.Dir,"logs",now.AddDays(-10).ToString("yyyyMMdd")+".log"),10);
string today=FileAt(Path.Combine(c.Dir,"logs",now.ToString("yyyyMMdd")+".log"),0);
string yesterday=FileAt(Path.Combine(c.Dir,"MQL4","Logs",now.AddDays(-1).ToString("yyyyMMdd")+".log"),1);
string recent=FileAt(Path.Combine(c.Dir,"logs",now.AddDays(-3).ToString("yyyyMMdd")+".log"),3);
string updated=FileAt(Path.Combine(c.Dir,"logs",now.AddDays(-20).ToString("yyyyMMdd")+".log"),0);
string unknown=FileAt(Path.Combine(c.Dir,"logs","personal.log"),100);
string account=FileAt(Path.Combine(c.Dir,"config","accounts.ini"),100);
string currentChart=FileAt(Path.Combine(c.Dir,"profiles","MetaFactoryLiveOnly","chart01.chr"),100);
string price=FileAt(Path.Combine(c.Dir,"history","broker","prices.hst"),100);
string report=FileAt(Path.Combine(c.Dir,"MQL4","Files","account-history.txt"),100);
Check(Scan(c).Any(i=>i.Path==oldLog&&i.Automatic),"expired daily log eligible");
foreach(string p in new[]{today,yesterday,recent,updated,unknown,account,currentChart,price,report})Check(!Scan(c).Any(i=>i.Path==p),"protected recent/personal/account/history path: "+Path.GetFileName(p));
string profileRoot=Path.Combine(c.Dir,"MTManager-backup","single-live-profile");string newest=Snap(profileRoot,10),second=Snap(profileRoot,11),old=Snap(profileRoot,12);
Check(Scan(c).Any(i=>i.Path==old&&i.Automatic)&&!Scan(c).Any(i=>i.Path==newest||i.Path==second),"latest two private-profile backups kept even beyond age window");
string freshBackup=Snap(profileRoot,1);Check(!Scan(c).Any(i=>i.Path==freshBackup),"new backup protected");
string editedBackup=Snap(profileRoot,20);File.SetLastWriteTimeUtc(Path.Combine(editedBackup,"chart01.chr"),now);Check(!Scan(c).Any(i=>i.Path==editedBackup),"recently edited old backup protected");
string arbitrary=FileAt(Path.Combine(profileRoot,"my-personal-backup","chart01.chr"),100);Check(!Scan(c).Any(i=>i.Path==Path.GetDirectoryName(arbitrary)),"unrecognized backup name protected");
string repairRoot=Path.Combine(root,"_MTManager","repair-backups",c.Name);Snap(repairRoot,8);Snap(repairRoot,9);string repair=Snap(repairRoot,10);
Check(Scan(c).Any(i=>i.Path==repair&&!i.Automatic&&i.Group=="storage-repair"),"old full terminal backup is manual only");
string liveRoot=Path.Combine(c.Dir,"MQL4","Files","MetaFactoryLive");string active=Path.Combine(liveRoot,new string('a',32)),inactive=Path.Combine(liveRoot,new string('b',32));
string activeHistory=FileAt(Path.Combine(active,"history-0.txt"),100),inactiveHistory=FileAt(Path.Combine(inactive,"history-1.txt"),100);
string part=FileAt(Path.Combine(active,"snapshot.txt.20261101-123.part"),5);
string newPart=FileAt(Path.Combine(active,"history-0.txt.123.part"),1);
string ownUnknown=FileAt(Path.Combine(inactive,"personal-annotations.txt"),100);
Check(Scan(c,new[]{active}).Any(i=>i.Path==part&&i.Automatic),"abandoned known live temporary file eligible");
Check(!Scan(c,new[]{active}).Any(i=>i.Path==activeHistory||i.Path==newPart||i.Path==ownUnknown),"active session, recent temp and unknown live files protected");
Check(Scan(c,new[]{active}).Any(i=>i.Path==inactiveHistory&&!i.Automatic),"inactive known live output manual only");
Check(!Scan(c,null).Any(i=>i.Group=="storage-sessions"),"unknown binding registry protects session output");
string huge=FileAt(Path.Combine(c.Dir,"logs",now.AddDays(-4).ToString("yyyyMMdd")+".log"),4);using(var f=new FileStream(huge,FileMode.Open,FileAccess.Write))f.SetLength(51L*1024*1024);File.SetLastWriteTimeUtc(huge,now.AddDays(-4));
Check(Scan(c).Any(i=>i.Path==huge),"50MB log budget also expires eligible files within seven days");
Check(!StorageRetention.Scan(new[]{c},now,new[]{active},true).Any(i=>!i.Automatic),"automatic scan excludes full-repair and inactive-history payloads");
var before=Scan(c,new[]{active});long expected=before.Where(i=>i.Automatic).Sum(i=>i.Bytes);var r=StorageRetention.RunAutomatic(new[]{c},now,new[]{active});
Check(r.Removed>0&&r.Bytes==expected,"automatic reclaimed-byte accounting matches removed candidates");
Check(!File.Exists(oldLog)&&!File.Exists(huge)&&!File.Exists(part),"automatic cleanup removes only eligible log/temp files");
Check(Directory.Exists(repair)&&File.Exists(inactiveHistory)&&File.Exists(activeHistory),"automatic cleanup never deletes manual-only backups/session histories");
foreach(string p in new[]{account,currentChart,price,report,today,yesterday,updated,unknown,ownUnknown})Check(File.Exists(p),"original data preserved: "+Path.GetFileName(p));
Check(!Scan(c,new[]{active}).Any(i=>i.Automatic),"automatic sweep idempotent");
string cancellation=FileAt(Path.Combine(c.Dir,"logs",now.AddDays(-30).ToString("yyyyMMdd")+".log"),30);r=StorageRetention.RunAutomatic(new[]{c},now,new[]{active},()=>true);Check(File.Exists(cancellation)&&r.Removed==0&&r.Cancelled,"cancellation leaves next item untouched");
string outside=Path.Combine(root,"outside");Directory.CreateDirectory(outside);string outsideFile=FileAt(Path.Combine(outside,"victim.txt"),100);
Check(!StorageRetention.Safe(outsideFile,c.Dir),"boundary rejects outside path");
if(Path.DirectorySeparatorChar=='/'){
string linked=Path.Combine(c.Dir,"MTManager-backup","mt5-live-profile");Directory.CreateDirectory(Path.GetDirectoryName(linked));var proc=Process.Start(new ProcessStartInfo("ln","-s '"+outside+"' '"+linked+"'"){UseShellExecute=false});proc.WaitForExit();Check(!StorageRetention.Safe(Path.Combine(linked,"victim.txt"),c.Dir),"linked ancestor rejected");StorageRetention.RunAutomatic(new[]{c},now,new[]{active});Check(File.Exists(outsideFile),"linked outside target preserved");Directory.Delete(linked);
string tree=Snap(profileRoot,40);string insideLink=Path.Combine(tree,"external");proc=Process.Start(new ProcessStartInfo("ln","-s '"+outside+"' '"+insideLink+"'"){UseShellExecute=false});proc.WaitForExit();Check(!Scan(c).Any(i=>i.Path==tree),"backup containing symlink rejected as a whole");Directory.Delete(insideLink);
}
string locked=FileAt(Path.Combine(c.Dir,"logs",now.AddDays(-31).ToString("yyyyMMdd")+".log"),31);
using(var hold=new FileStream(locked,FileMode.Open,FileAccess.ReadWrite,FileShare.None)){var lockedRun=StorageRetention.RunAutomatic(new[]{c},now,new[]{active});Check(File.Exists(locked)&&lockedRun.Skipped>0,"in-use old log is skipped rather than forced");}
string racing=FileAt(Path.Combine(c.Dir,"logs",now.AddDays(-32).ToString("yyyyMMdd")+".log"),32);bool changed=false;int raceCalls=0;
StorageRetention.RunAutomatic(new[]{c},now,new[]{active},()=>{if(++raceCalls==3){File.SetLastWriteTimeUtc(racing,now);changed=true;}return false;});Check(changed&&File.Exists(racing),"late write invalidates stale cleanup candidate");
var guard=new Instance{Name="MT5-02",Kind=Kind.MT5,Dir=Path.Combine(root,"MT5-02")};Directory.CreateDirectory(guard.Dir);string guardRoot=Path.Combine(guard.Dir,"MTManager-backup","mt5-live-profile");string g1=Snap(guardRoot,10),g2=Snap(guardRoot,11),g3=Snap(guardRoot,12);bool external=false;int guardCalls=0;
StorageRetention.RunAutomatic(new[]{guard},now,null,()=>{if(++guardCalls==3){Directory.Delete(g1,true);external=true;}return false;});Check(external&&Directory.Exists(g2)&&Directory.Exists(g3),"retention rechecks latest-two protection immediately before deletion");
var groups=StorageRetention.Groups(new[]{c},now,new[]{active});Check(groups.Count==6&&groups.Any(g=>g.Id=="storage-repair"&&g.Paths.Contains(repair)),"manual preview groups carry eligible paths and sizes");
string orphanRoot=Path.Combine(root,"_MTManager","repair-backups","Removed-copy");Snap(orphanRoot,10);Snap(orphanRoot,11);string orphan=Snap(orphanRoot,12);string stageRoot=Path.Combine(root,"_MTManager","repair-stage",Guid.NewGuid().ToString("N"));FileAt(Path.Combine(stageRoot,"terminal.exe"),4);Directory.SetLastWriteTimeUtc(stageRoot,now.AddDays(-4));
var orphanGroups=StorageRetention.Groups(new Instance[0],now,new string[0],new[]{root});Check(orphanGroups.Any(g=>g.Id=="storage-repair"&&g.Paths.Contains(orphan)),"manual cleanup can find old repair backups after roster removal");Check(orphanGroups.Any(g=>g.Id=="storage-stage"&&g.Paths.Contains(stageRoot)),"manual cleanup exposes abandoned staging without auto-deleting it");
Console.WriteLine("STORAGE RETENTION PASS "+checks);return 0;
}catch(Exception e){Console.WriteLine(e);return 1;}finally{try{Directory.Delete(root,true);}catch{}}}
}
