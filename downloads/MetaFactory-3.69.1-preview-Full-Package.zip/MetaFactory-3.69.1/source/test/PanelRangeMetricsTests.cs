using System;
using System.Linq;
namespace MTManager {
static partial class Tests {
static void PanelRangeMetricChecks() {
 DateTime first=new DateTime(2026,11,23), day=first.AddDays(1), now=first.AddDays(3);
 var j=new AccountJournal {Platform="MT4",Complete=true,From=ReportRange.AllFrom,TrustedFrom=ReportRange.AllFrom,Exported=now,FloatingBars=AccountJournal.TradesOnly};
 ProveDdCurve(j,DdEvent(1,first,2,1000),DdEvent(2,first.AddHours(1),0,-200),DdEvent(3,day.AddHours(1),0,100),DdEvent(4,day.AddHours(2),1,-50),DdEvent(5,day.AddDays(1).AddHours(1),0,500));
 j.Trades.Add(new JournalTrade{Ticket=2,Open=first,Close=first.AddHours(1),Profit=-200});
 j.Trades.Add(new JournalTrade{Ticket=3,Open=first,Close=day.AddHours(1),Profit=100});
 j.Trades.Add(new JournalTrade{Ticket=4,Open=day,Close=day.AddHours(2),Profit=-50});
 // Opened inside the selected day, closed after it: must not inflate that day's factor.
 j.Trades.Add(new JournalTrade{Ticket=5,Open=day.AddHours(3),Close=day.AddDays(1).AddHours(1),Profit=500});
 var r=new ReportRange{Kind=RangeKind.Custom,From=day,To=day.AddDays(1)};
 var v=PanelMath.Build(j,r,new TradeLimits());
 Check(Math.Abs(v.ProfitFactor-2.4)<1e-9 && v.RangeProfitFactor==2,"period PF independent of full account, close date membership");
 Check(v.AccountDdPct==20 && Math.Abs(v.RangeDdPct-50.0/900*100)<1e-9,"period DD resets peak at proven window-start balance; full DD unchanged");
 Check(v.FloatingDisabled && !double.IsNaN(v.RangeDdPct),"balance range DD available in trades-only reports");
 var all=ServerDays.Range(PanelRange.All,now);var av=PanelMath.Build(j,all,new TradeLimits());
 Check(all.Kind==RangeKind.AllHistory && all.From==ReportRange.AllFrom && all.To==now.Date.AddDays(1),"All uses existing full-history request contract");
 Check(av.RangeProfitFactor==av.ProfitFactor && av.RangeDdPct==av.AccountDdPct,"All range metrics equal whole account metrics");
 Check(av.Closed==4 && av.Days.Count==2,"All includes all closed trade days");
 Check((int)PanelRange.Custom==4 && (int)PanelRange.All==5,"adding All preserves existing range enum ordinals");
 Check(ReportPanel.RangeKinds.SequenceEqual(new[]{PanelRange.Today,PanelRange.Yesterday,PanelRange.Week,PanelRange.Month,PanelRange.All,PanelRange.Custom}),"All precedes custom Range visually without index casts");
 Check(ServerDays.ReadFrom(null,now,all.From)==ReportRange.AllFrom,"All requests full details when uncached");

 var funded=new AccountJournal{Platform="MT4",Complete=true,From=ReportRange.AllFrom,TrustedFrom=ReportRange.AllFrom,Exported=now,FloatingBars=AccountJournal.TradesOnly};
 ProveDdCurve(funded,DdEvent(1,first,2,1000),DdEvent(2,first.AddHours(1),0,-200),DdEvent(6,first.AddHours(2),2,1000),DdEvent(3,day.AddHours(1),0,100),DdEvent(7,day.AddHours(1).AddMinutes(1),2,5000),DdEvent(4,day.AddHours(2),1,-50));
 var fv=PanelMath.Build(funded,r,new TradeLimits());
 Check(Math.Abs(fv.RangeDdPct-50.0/1900*100)<1e-9 && fv.AccountDdPct==20,"period DD uses actual opening capital, excludes deposits inside range");
 var fa=PanelMath.Build(funded,all,new TradeLimits());Check(fa.RangeDdPct==fa.AccountDdPct,"All preserves existing funding-neutral full-account curve");
 j.TrustedFrom=day.AddDays(1);var missing=PanelMath.Build(j,r,new TradeLimits());
 Check(double.IsNaN(missing.RangeProfitFactor)&&double.IsNaN(missing.RangeDdPct)&&missing.ProfitFactor==v.ProfitFactor,"partial details never fabricate selected-range metrics");
 j.TrustedFrom=ReportRange.AllFrom;j.HistoryOk=false;missing=PanelMath.Build(j,r,new TradeLimits());
 Check(double.IsNaN(missing.RangeProfitFactor)&&double.IsNaN(missing.RangeDdPct),"unreconciled selected history remains unknown");j.HistoryOk=true;
 var empty=PanelMath.Build(j,new ReportRange{From=first.AddDays(-2),To=first.AddDays(-1)},new TradeLimits());
 Check(double.IsNaN(empty.RangeProfitFactor)&&empty.RangeDdPct==0,"no trades means undefined PF and proven zero balance DD");
 j.Platform="MT5";j.AccountPfPresent=j.AccountPfValid=true;j.AccountPfGain=600;j.AccountPfLoss=250;
 j.Open.Add(new JournalOpen{Ticket=6,Open=day,Profit=999});
 j.Trades.Add(new JournalTrade{Ticket=6,Open=day,Close=day.AddHours(3),Profit=-30});
 ProveDdCurve(j,j.FullHistory.Concat(new[]{DdEvent(6,day.AddHours(3),0,-30)}).ToArray());
 v=PanelMath.Build(j,r,new TradeLimits());
 Check(v.RangeProfitFactor==2 && Math.Abs(v.RangeDdPct-80.0/900*100)<1e-9,"MT5 partial realization affects balance DD but not fully-closed-position PF");
 av=PanelMath.Build(j,all,new TradeLimits());
 Check(av.ProfitFactor==av.RangeProfitFactor && av.AccountDdPct==av.RangeDdPct,"MT5 All parity with open partial position");
 j.Trades.Single(t=>t.Ticket==3).Commission=-10;j.AccountPfGain=590;
 v=PanelMath.Build(j,r,new TradeLimits());Check(v.RangeProfitFactor==1.8,"period PF includes trade fees");
 j.Open.Clear();j.Trades.Clear();j.Trades.Add(new JournalTrade{Ticket=7,Open=day,Close=day.AddHours(1),Profit=20});
 v=PanelMath.Build(j,r,new TradeLimits());Check(double.IsPositiveInfinity(v.RangeProfitFactor),"winning-only range has infinite factor");
 j.Trades[0].Profit=-20;v=PanelMath.Build(j,r,new TradeLimits());Check(v.RangeProfitFactor==0,"losing-only range has zero factor");
 j.FullHistoryScanOk=false;v=PanelMath.Build(j,r,new TradeLimits());Check(double.IsNaN(v.RangeProfitFactor)&&double.IsNaN(v.RangeDdPct),"missing native proof gives unknown metrics");
 Check(PanelMath.FactorValue(double.NaN)=="—"&&PanelMath.FactorValue(double.PositiveInfinity)=="∞","factor unknown/infinity formatting");
}
}}
