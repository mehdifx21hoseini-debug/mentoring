using System;using System.IO;using System.Linq;using System.Reflection;using System.ComponentModel;using System.Runtime.InteropServices;using System.Drawing;using System.Threading;using System.Windows.Forms;using MTManager;
class GuiResourceSmoke
{
 static BindingFlags F=BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic;
 static Assembly A=typeof(Settings).Assembly;static int checks;
 static object Get(object o,string n){return o.GetType().GetField(n,F).GetValue(o);}
 static void Set(object o,string n,object v){o.GetType().GetField(n,F).SetValue(o,v);}
 static object Call(object o,string n,params object[] args){return o.GetType().GetMethods(F).Single(m=>m.Name==n&&m.GetParameters().Length==args.Length).Invoke(o,args);}
 static void Check(bool value,string text){if(!value)throw new Exception(text);checks++;Console.WriteLine("PASS "+text);}
 static void Pump(){for(int j=0;j<4;j++){Application.DoEvents();Thread.Sleep(10);}}
 [STAThread]static int Main(string[] args)
 {
  string root=Path.Combine(Path.GetTempPath(),"mf-gui-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=Path.Combine(root,"data");Directory.CreateDirectory(AppPaths.DataDirOverride);
  try
  {
   Application.EnableVisualStyles();A.GetType("MTManager.Theme").GetMethod("Init",F).Invoke(null,null);Lang.En=true;
   var now=DateTime.UtcNow;var recovery=new LaunchResourceRecovery();
   Check(!recovery.Waiting(now),"healthy launches have no new delay");
   Check(!recovery.Record(new Win32Exception(5),now)&&!recovery.Waiting(now),"access denied does not trigger resource pacing");
   Check(!GuiResourceSafety.IsResourceError(new IOException("window file absent")),"ordinary file errors are not resource pressure");
   Check(GuiResourceSafety.IsResourceError(new Exception("wrapper",new Win32Exception(1450))),"inner native allocation failure recognized");
   Check(recovery.Record(new Win32Exception(1450),now)&&recovery.Waiting(now.AddSeconds(4)),"actual allocation error gives bounded recovery gap");
   Check(!recovery.Waiting(now.AddSeconds(5)),"recovery gap expires without terminal count or readiness gate");
   int attempts=0;Check(SafeClipboard.TryCopy("synthetic",s=>{if(++attempts<3)throw new ExternalException("busy");})&&attempts==3,"clipboard contention retries then succeeds");
   attempts=0;Check(!SafeClipboard.TryCopy("synthetic",s=>{attempts++;throw new ExternalException("busy");})&&attempts==3,"busy clipboard ends after three attempts without false success");
   attempts=0;try{SafeClipboard.TryCopy("synthetic",s=>{attempts++;throw new InvalidOperationException("wrong thread");});throw new Exception("lost exception");}catch(InvalidOperationException){}
   Check(attempts==1,"unrelated clipboard failures are not blindly retried");
   string path=GuiResourceSafety.SaveEmergency(new string('x',300000));Check(new FileInfo(path).Length<270000,"emergency export has bounded size");
   GuiResourceSafety.SaveEmergency("synthetic full system check");GuiResourceSafety.Record(new Win32Exception(1450));string diagnostic=File.ReadAllText(path);
   Check(diagnostic.Contains("native-code=1450")&&diagnostic.Contains("synthetic full system check")&&diagnostic.Contains("MetaFactory pid="),"resource failure retains system payload and actual native code");
   Check(Directory.GetFiles(AppPaths.DataDirOverride,"emergency-*.txt").Length==1,"emergency file overwritten rather than accumulating files");
   var progress=(Control)Activator.CreateInstance(A.GetType("MTManager.ReportProgressStrip"),true);
   using(progress)
   {
    int calls=0;Set(progress,"startOptionalTimer",(Action<System.Windows.Forms.Timer>)(timer=>{calls++;throw new Win32Exception(1450);}));
    var work=new LaunchWorkProgress();work.Add("MT5-01");Call(progress,"SetLaunch",work,true);
    Check(calls==1&&(bool)Get(progress,"timerUnavailable"),"animation allocation failure falls back to static progress");
    Call(progress,"SetLaunch",work,false);Check(calls==1,"failed optional timer is not recreated every launch tick");
    work.Complete("MT5-01",true);Call(progress,"SetLaunch",work,false);Check((bool)Get(progress,"compactDone")&&(double)Get(progress,"value")==1,"completion still renders success after timer allocation failure");
   }
   var settings=new Settings{BaseDir=Path.Combine(root,"copies"),AutoStart=false,LastBackup=DateTime.Now};Directory.CreateDirectory(settings.BaseDir);
   var accounts=new AccountStore();for(int i=1;i<=2;i++){string n="MT5-"+i.ToString("00"),d=Path.Combine(settings.BaseDir,n);Directory.CreateDirectory(d);File.WriteAllBytes(Path.Combine(d,"terminal64.exe"),new byte[0]);accounts.Set(new Account{Instance=n,Platform="MT5",Login=(900000+i).ToString(),Server="Synthetic-Demo",Trader="Sample "+i});}
   using(var main=(Form)Activator.CreateInstance(A.GetType("MTManager.MainForm"),F,null,new object[]{settings,accounts},null))
   {
    main.WindowState=FormWindowState.Normal;main.Bounds=new Rectangle(10,10,1366,738);main.Show();Pump();foreach(var field in main.GetType().GetFields(F))if(field.FieldType==typeof(System.Windows.Forms.Timer))((System.Windows.Forms.Timer)field.GetValue(main)).Stop();
    int baseline=Application.OpenForms.Count;
    for(int n=0;n<60;n++)
    {
     var menu=new ContextMenuStrip();var item=new ToolStripMenuItem("Synthetic action");bool clicked=false;item.Click+=(s,e)=>clicked=true;menu.Items.Add(item);
     Call(main,"ShowTransient",menu,main);item.PerformClick();menu.Close();Pump();
     Check(clicked&&menu.IsDisposed&&item.IsDisposed,"transient menu action and disposal cycle "+n);
    }
    Check(Application.OpenForms.Count==baseline,"menu cycles do not accumulate forms");
    var persistent=(ContextMenuStrip)Get(main,"toolsMenu");Check(!persistent.IsDisposed,"persistent Tools menu remains reusable");
    int formCount=Application.OpenForms.Count;Call(main,"SaveSystemCheckWithoutWindow");Check(Application.OpenForms.Count==formCount&&File.Exists(path),"diagnostic save opens no extra Form");
    var lp=Get(main,"launchProgress");Set(lp,"startOptionalTimer",(Action<System.Windows.Forms.Timer>)(timer=>{throw new Win32Exception(1450);}));
    var lw=(LaunchWorkProgress)Get(main,"launchWork");lw.Add("MT5-01");Call(main,"RefreshLaunchProgress",true);
    Check(!(bool)Call(Get(main,"resourceRecovery"),"Waiting",DateTime.UtcNow),"progress failure adds no launch delay");
    var activeMenu=new ContextMenuStrip();activeMenu.Items.Add("last menu");Call(main,"ShowTransient",activeMenu,main);
    Set(main,"appClosing",true);main.Close();Pump();Check(activeMenu.IsDisposed&&persistent.IsDisposed,"closing main window releases final transient and persistent menus");
   }
   Check(Launcher.StartLines(Kind.MT5,null,null,false,Launcher.LiveMt5ProfileName).Contains("MaxBars=5000"),"private MT5 report chart uses supported minimum even if general light mode is off");
   Check(Launcher.StartLines(Kind.MT5,null,null,false,Launcher.LiveMt5ProfileName).Contains("NewsEnable=0"),"private MT5 report profile disables unused news");
   Check(!Launcher.StartLines(Kind.MT5,null,null,false,"Personal").Any(line=>line.StartsWith("MaxBars=")),"personal chart profile and user light-mode choice remain unchanged");
   string native=LiveReporter.SourceText(Kind.MT5);
   Check(native.Contains("input bool LightweightDisplay = false")&&native.Contains("if(LightweightDisplay)")&&native.Contains("ChartSetInteger(0,CHART_SHOW,false)"),"MT5 rendering change is opt-in and limited to its own chart");
   Check(native.Contains("ChartSetInteger(0,CHART_SHOW,true)")&&native.Contains("EventSetTimer(1)"),"MT5 display restored on detach and one-second reporting retained");
   Console.WriteLine("GUI RESOURCE PASS "+checks);return 0;
  }
  catch(Exception e){Console.Error.WriteLine(e);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
