// MT Manager 3.15: reading the students' trade history for the report.
// For each account a report copy of MetaTrader (the program's own, never a student's) logs in with the login password,
// runs the read-only report script once and writes the history to a file; the program keeps it on this computer and closes it.
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;

namespace MTManager
{
    public enum StepState { Waiting, Starting, Reading, Done, Failed, Skipped, Retrying }

    // ================================================================== how many at once

    /// <summary>Up to four report copies, limited by current CPU and memory capacity.</summary>
    public static class ReportParallel
    {
        public const int Max = Settings.MaxReportAtOnce;

        /// <summary>The setting: 0 automatic, or an upper limit of one to four.</summary>
        public static int Clamp(int n) { return Math.Max(0, Math.Min(Max, n)); }

        /// <summary>Conservative automatic capacity; every cold start also reserves memory separately.</summary>
        public static int Auto(int processors, ulong totalMb, ulong freeMb)
        {
            if (processors >= 8 && totalMb >= 15000 && freeMb >= 5000) return 4;
            if (processors >= 6 && totalMb >= 11000 && freeMb >= 3750) return 3;
            return processors >= 4 && totalMb >= 7500 && freeMb >= 2500 ? 2 : 1;
        }

        public static int For(Settings s, int jobs)
        { return For(s, jobs, Environment.ProcessorCount, Checks.TotalRamMb(), Checks.FreeRamMb()); }

        public static int For(Settings s, int jobs, int processors, ulong totalMb, ulong freeMb)
        {
            int capacity = Auto(processors, totalMb, freeMb);
            int n = s.ReportAtOnce >= 1 ? Math.Min(Clamp(s.ReportAtOnce), capacity) : capacity;
            return Math.Max(1, Math.Min(n, Math.Max(1, jobs)));
        }
        public static bool CanPilotMt4(Settings s, int processors, ulong totalMb, ulong freeMb)
        {
            return s.ReportAtOnce != 1 && processors >= 4 && totalMb >= 7500
                && freeMb >= LaunchMemoryPolicy.Reserve(totalMb) + 768;
        }
        /// <summary>Worker ceiling. The additional low-memory MT4 worker is initially parked until measured successes permit it.</summary>
        public static int For(Settings s, IEnumerable<Kind> kinds)
        { return For(s, kinds, Environment.ProcessorCount, Checks.TotalRamMb(), Checks.FreeRamMb()); }
        public static int For(Settings s, IEnumerable<Kind> kinds, int processors, ulong totalMb, ulong freeMb)
        {
            Kind[] platforms = kinds.ToArray();
            int baseline = For(s, platforms.Length, processors, totalMb, freeMb);
            return baseline == 1 && platforms.Length > 1 && platforms.All(k => k == Kind.MT4) && CanPilotMt4(s, processors, totalMb, freeMb) ? 2 : baseline;
        }
    }

    public sealed class ReportResourceSnapshot
    {
        public int Processors;
        public ulong TotalMb, FreeMb, PendingGrowthMb;
        public double CpuPercent = -1;
        public long MonotonicMs;
    }

    /// <summary>Windows CPU pressure from monotonic processor counters; no performance-counter service or disk probe required.</summary>
    internal sealed class ReportResourceSampler
    {
        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
        [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
        static extern bool GetSystemTimes(out ulong idle, out ulong kernel, out ulong user);
        readonly object gate = new object();
        readonly Stopwatch clock = Stopwatch.StartNew();
        long sampledAt = -1000;
        ulong lastIdle, lastKernel, lastUser;
        bool primed;
        double percent = -1;
        internal static double CpuBusy(ulong idle, ulong kernel, ulong user, ulong priorIdle, ulong priorKernel, ulong priorUser)
        {
            if (idle < priorIdle || kernel < priorKernel || user < priorUser) return -1;
            ulong total = kernel - priorKernel + user - priorUser, rest = idle - priorIdle;
            return total == 0 || rest > total ? -1 : 100.0 * (total - rest) / total;
        }
        public ReportResourceSnapshot Read()
        {
            lock (gate)
            {
                long now = clock.ElapsedMilliseconds;
                if (now - sampledAt >= 500)
                {
                    sampledAt = now;
                    try
                    {
                        ulong idle, kernel, user;
                        if (GetSystemTimes(out idle, out kernel, out user))
                        {
                            percent = primed ? CpuBusy(idle, kernel, user, lastIdle, lastKernel, lastUser) : -1;
                            lastIdle = idle; lastKernel = kernel; lastUser = user; primed = true;
                        }
                        else { percent = -1; primed = false; }
                    }
                    catch { percent = -1; primed = false; }
                }
                return new ReportResourceSnapshot { Processors = Environment.ProcessorCount, TotalMb = Checks.TotalRamMb(), FreeMb = Checks.FreeRamMb(), CpuPercent = percent, MonotonicMs = now };
            }
        }
    }

    internal sealed class Mt4AdaptiveAdmission
    {
        readonly object gate = new object();
        int successes;
        ulong peak;
        long goodSince = -1;
        bool promoted;
        public void Record(bool fresh, ulong actualPeakMb)
        { if (!fresh || actualPeakMb == 0) return; lock (gate) { successes++; peak = Math.Max(peak, actualPeakMb); } }
        public bool AllowSecond(ReportResourceSnapshot resources)
        {
            lock (gate)
            {
                ulong needed = LaunchMemoryPolicy.Reserve(resources.TotalMb) + resources.PendingGrowthMb + LaunchMemoryPolicy.Required(Kind.MT4, peak) + 256;
                bool room = successes >= 2 && resources.Processors >= 4 && resources.TotalMb >= 7500 && resources.FreeMb >= needed && resources.CpuPercent >= 0;
                if (!room || resources.CpuPercent > 90) { promoted = false; goodSince = -1; return false; }
                if (promoted) return true;
                if (resources.CpuPercent > 75) { goodSince = -1; return false; }
                if (goodSince < 0) goodSince = resources.MonotonicMs;
                if (resources.MonotonicMs - goodSince >= 2000) promoted = true;
                return promoted;
            }
        }
    }

    internal static class ReportCapacityWait
    {
        // A resource pause is not an account failure and never consumes a retry.
        public static void Until(Func<bool> available, Func<bool> cancel, Action waiting = null, Action<int> sleep = null)
        {
            bool announced = false;
            while (true)
            {
                if (cancel()) throw new OperationCanceledException();
                if (available()) return;
                if (!announced) { announced = true; if (waiting != null) waiting(); }
                (sleep ?? (ms => Thread.Sleep(ms)))(250);
            }
        }
    }

    /// <summary>Reserves growth not yet reflected in free RAM for all concurrently starting reporters.
    /// A reservation stays after Process.Start and while an MT5 terminal is reused; an exited process releases it.</summary>
    public sealed class ReportStartBudget
    {
        readonly object gate = new object();
        readonly List<Reservation> active = new List<Reservation>();
        ulong PendingUnsafe()
        {
            ulong pending = 0;
            for (int i = active.Count - 1; i >= 0; i--)
            {
                ulong? used = active[i].Usage();
                if (!used.HasValue) { active.RemoveAt(i); continue; }
                if (used.Value < active[i].Required) pending += active[i].Required - used.Value;
            }
            return pending;
        }
        public ulong PendingGrowthMb { get { lock (gate) return PendingUnsafe(); } }
        public bool CanHonor(Func<ulong> total, Func<ulong> free, ulong marginMb = 0)
        { lock (gate) { ulong totalMb = total(); return totalMb > 0 && free() >= LaunchMemoryPolicy.Reserve(totalMb) + PendingUnsafe() + marginMb; } }
        public sealed class Reservation : IDisposable
        {
            readonly ReportStartBudget owner;
            internal readonly ulong Required;
            internal Func<ulong?> Usage = () => 0;
            internal Reservation(ReportStartBudget owner, ulong required) { this.owner = owner; Required = required; }
            public void Observe(Func<ulong?> currentUsage) { lock (owner.gate) Usage = currentUsage; }
            public void Attach(Process process)
            {
                int pid = process.Id; long start = Processes.StartOf(pid);
                Observe(() =>
                {
                    try
                    {
                        using (Process running = Process.GetProcessById(pid))
                        {
                            long currentStart = Processes.StartOf(pid);
                            if (running.HasExited || start != 0 && currentStart != 0 && currentStart != start) return null;
                            return (ulong)Math.Max(0, running.WorkingSet64 / (1024 * 1024));
                        }
                    }
                    catch (ArgumentException) { return null; }
                    catch (InvalidOperationException) { return null; }
                    catch { return 0; } // Cannot inspect: retain the reservation rather than assume room.
                });
            }
            // Only call on a failed launch. Attached reservations are retained until the process exits.
            public void Dispose() { lock (owner.gate) owner.active.Remove(this); }
        }
        public Reservation TryAcquire(Func<ulong> total, Func<ulong> free, Kind kind, ulong peakMb, ulong marginMb = 0)
        {
            lock (gate)
            {
                ulong pending = PendingUnsafe();
                ulong totalMb = total(), freeMb = free(), required = LaunchMemoryPolicy.Required(kind, peakMb);
                if (totalMb == 0 || freeMb < LaunchMemoryPolicy.Reserve(totalMb) + pending + required + marginMb) return null;
                var reservation = new Reservation(this, required); active.Add(reservation); return reservation;
            }
        }
    }

    // A transient account-switch or file-sharing problem must not disable terminal reuse
    // for every remaining account on that broker. Two successful cold reads provide a
    // bounded recovery interval. Only an explicitly unavailable IPC runtime stays disabled.
    internal sealed class Mt5WarmRecovery
    {
        readonly ConcurrentDictionary<string, int> states = new ConcurrentDictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        public bool CanReuse(string key) { int remaining; return !states.TryGetValue(key, out remaining) || remaining == 0; }
        public void TransientFailure(string key) { states.AddOrUpdate(key, 2, (_, remaining) => remaining < 0 ? -1 : 2); }
        public void Unavailable(string key) { states[key] = -1; }
        public bool ColdSuccess(string key) { return states.AddOrUpdate(key, 0, (_, remaining) => remaining < 0 ? -1 : Math.Max(0, remaining - 1)) == 0; }
        public const int HandshakeMilliseconds = 12000;
        public static bool HandshakeExpired(string step, long elapsed)
        { return (string.IsNullOrWhiteSpace(step) || step.Trim() == "ready") && elapsed >= HandshakeMilliseconds; }
    }

    // A request-bound heartbeat is progress evidence only. A fresh validated report remains
    // the sole success condition; an old account's heartbeat cannot extend this request.
    internal sealed class Mt5ReporterPulse
    {
        public string Stage, ActualLogin, ActualServer;
        public bool Connected;
        public long Timestamp, ElapsedMilliseconds;
        public static Mt5ReporterPulse TryParse(string text, string token, Account account)
        {
            if (string.IsNullOrEmpty(text) || string.IsNullOrEmpty(token) || token.Length != 32 || account == null) return null;
            string[] lines = text.TrimEnd('\r', '\n').Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            if (lines.Length != 7 || lines[0] != "MTP\t1" || lines[1] != "Q\t" + token || lines[6] != "END") return null;
            string[] identity = lines[2].Split('\t'), stage = lines[3].Split('\t'), time = lines[4].Split('\t'), current = lines[5].Split('\t');
            if (identity.Length != 3 || identity[0] != "A" || identity[1] != account.Login.Trim() || !string.Equals(identity[2], account.Server.Trim(), StringComparison.OrdinalIgnoreCase)
                || stage.Length != 2 || stage[0] != "S" || time.Length != 3 || time[0] != "T" || current.Length != 4 || current[0] != "C" || current[3] != "0" && current[3] != "1") return null;
            long timestamp, elapsed;
            if (!long.TryParse(time[1], out timestamp) || !long.TryParse(time[2], out elapsed) || timestamp < 0 || elapsed < 0) return null;
            string[] phases = { "init", "ready", "await-account", "start", "history-select", "history-selected", "history-scan", "history-stable-wait", "positions", "writing", "done", "failed", "timer-failed", "write-failed" };
            int reason;
            if (!phases.Contains(stage[1]) && !(stage[1].StartsWith("deinit ", StringComparison.Ordinal) && int.TryParse(stage[1].Substring(7), out reason))) return null;
            return new Mt5ReporterPulse { Stage = stage[1], ActualLogin = current[1], ActualServer = current[2], Timestamp = timestamp, ElapsedMilliseconds = elapsed,
                Connected = current[3] == "1" && current[1] == account.Login.Trim() && string.Equals(current[2], account.Server.Trim(), StringComparison.OrdinalIgnoreCase) };
        }
    }

    internal sealed class Mt5StartupWatch
    {
        readonly bool warm, retry;
        readonly HashSet<string> observed = new HashSet<string>(StringComparer.Ordinal);
        long lastProgress;
        public bool ReporterStarted { get; private set; }
        public Mt5StartupWatch(bool warm, bool retry) { this.warm = warm; this.retry = retry; }
        public void Progress(string milestone, long elapsed)
        { if (!string.IsNullOrEmpty(milestone) && observed.Add(milestone)) lastProgress = Math.Max(lastProgress, elapsed); }
        public void Pulse(Mt5ReporterPulse pulse, long elapsed)
        {
            if (pulse == null) return;
            Progress("pulse:" + pulse.Stage, elapsed);
            if (pulse.Stage.StartsWith("history-", StringComparison.Ordinal) || new[] { "start", "positions", "writing", "done", "failed", "write-failed" }.Contains(pulse.Stage)) ReporterStarted = true;
        }
        public bool Expired(long elapsed)
        {
            if (ReporterStarted) return false;
            // First pass moves past idle startup promptly; the last deferred cold retry
            // preserves the full original opportunity for a slow broker without flushed logs.
            long maximum = warm ? 30000 : 45000;
            long minimum = warm ? 12000 : retry ? 45000 : 22000;
            return elapsed >= maximum || elapsed >= minimum && elapsed - lastProgress >= 12000;
        }
    }

    internal sealed class Mt5ChartMemory
    {
        readonly ConcurrentDictionary<string, string[]> good = new ConcurrentDictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);
        public void Remember(string server, string symbol)
        {
            if (string.IsNullOrWhiteSpace(server) || string.IsNullOrWhiteSpace(symbol)) return;
            good.AddOrUpdate(server.Trim(), _ => new[] { symbol }, (_, old) => new[] { symbol }.Concat(old).Distinct(StringComparer.OrdinalIgnoreCase).Take(8).ToArray());
        }
        public string Choose(string server, string preferred, IList<string> known, ICollection<string> tried, string stalled = null)
        {
            string source;
            return Choose(server, preferred, known, tried, out source, stalled);
        }
        public string Choose(string server, string preferred, IList<string> known, ICollection<string> tried, out string source, string stalled = null)
        {
            var candidates = (known ?? new string[0]).ToList();
            string[] remembered;
            if (string.IsNullOrWhiteSpace(server) || !good.TryGetValue(server.Trim(), out remembered)) remembered = new string[0];
            Func<string, bool> untried = symbol => tried == null || !tried.Any(x => string.Equals(x, symbol, StringComparison.OrdinalIgnoreCase));
            Func<string, bool> alternative = symbol => untried(symbol) && !string.Equals(symbol, stalled, StringComparison.OrdinalIgnoreCase);
            // Disk history/ticks and symbols.dat are hints, not a live account symbol catalog.
            // Prefer the most recent chart that actually produced a validated report on this
            // exact server. A stalled chart is excluded for this account while alternatives exist.
            string proven = remembered.FirstOrDefault(alternative);
            if (proven != null) { source = "successful same-server chart"; return proven; }
            var remaining = candidates.Where(alternative).ToList();
            string disk = remaining.Count > 0 ? ReportLaunch.PickSymbol(string.IsNullOrEmpty(stalled) ? preferred : null, remaining) : null;
            if (disk != null) { source = "server disk symbol hints"; return disk; }
            // Do not invent a different symbol if this account has exhausted every alternative.
            proven = remembered.FirstOrDefault(untried);
            if (proven != null) { source = "successful same-server chart (no alternative)"; return proven; }
            string fallback = ReportLaunch.PickSymbol(preferred, candidates, tried);
            source = candidates.Any(x => string.Equals(x, fallback, StringComparison.OrdinalIgnoreCase)) ? "server disk symbol hints (no alternative)" : "configured/default chart";
            return fallback;
        }
    }

    // ================================================================== the script: built once with MetaEditor

    public static class ReportScript
    {
        static string Source(Kind k) { return ReportLaunch.Script + (k == Kind.MT5 ? ".mq5" : ".mq4"); }

        public static string Binary(Kind k) { return ReportLaunch.Script + (k == Kind.MT5 ? ".ex5" : ".ex4"); }

        /// <summary>Under the copies folder, next to the report copies: a plain path MetaEditor reads without trouble.</summary>
        public static string WorkDir(Settings s) { return Path.Combine(ReportLaunch.ReportRoot(s.BaseDir), "build"); }

        public static string Built(Settings s, Kind k) { return Path.Combine(WorkDir(s), Binary(k)); }

        /// <summary>The script's code, inside the program.</summary>
        public static string SourceText(Kind k)
        {
            using (Stream st = Assembly.GetExecutingAssembly().GetManifestResourceStream(Source(k)))
            {
                if (st == null) throw new UserMessage(Lang.T("کد اسکریپت گزارش داخل برنامه نیست.", "The report script's code is not inside the program."));
                using (var r = new StreamReader(st)) return r.ReadToEnd();
            }
        }

        public static string Stamp(string text)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(text))).Replace("-", "");
        }

        /// <summary>MetaEditor of an installed MetaTrader (the program's copies leave it out); for MT4 also the one MetaTrader
        /// downloaded for its own update.</summary>
        public static string FindEditor(Kind k, Settings s)
        {
            string[] names = k == Kind.MT5 ? new[] { "metaeditor64.exe", "MetaEditor64.exe" } : new[] { "metaeditor.exe", "MetaEditor.exe" };
            var dirs = new List<string>(Installs.Find(k, s));
            string cache = TerminalUpdate.CacheDir(k);
            if (cache != null) dirs.Add(cache);
            dirs.AddRange(Installs.Copies(s).Where(c => c.Kind == k).Select(c => c.Dir));
            foreach (string d in dirs)
                foreach (string n in names)
                {
                    string p = Path.Combine(d, n);
                    if (File.Exists(p)) return p;
                }
            return null;
        }

        public static bool Ready(Settings s, Kind k)
        {
            string stamp = Built(s, k) + ".stamp";
            try { return File.Exists(Built(s, k)) && File.Exists(stamp) && File.ReadAllText(stamp) == Stamp(SourceText(k)); }
            catch { return false; }
        }

        /// <summary>Legacy compilation-failure marker for diagnostics only; Build never executes an old binary as a fallback.</summary>
        public static bool OnOlder(Settings s, Kind k)
        {
            string failed = Built(s, k) + ".failed";
            try { return File.Exists(Built(s, k)) && File.Exists(failed) && File.ReadAllText(failed) == Stamp(SourceText(k)); }
            catch { return false; }
        }

        /// <summary>Builds the script once per version of it; throws with MetaEditor's own report when that fails.</summary>
        public static void Build(Settings s, Kind k, Func<bool> cancel = null)
        {
            if (Ready(s, k)) return;
            string editor = FindEditor(k, s);
            if (editor == null)
                throw new UserMessage(Lang.T("برای ساختن اسکریپت گزارش ", "To build the report script for ") + k + Lang.T("، MetaEditor لازم است ولی پیدا نشد. یک ", ", MetaEditor is needed but was not found. Install ") + k + Lang.T(" را به روش معمول نصب کنید (MetaEditor همراهش نصب می‌شود) و دوباره امتحان کنید.", " the usual way (MetaEditor comes with it) and try again."));
            string dir = WorkDir(s);
            Directory.CreateDirectory(dir);
            string text = SourceText(k);
            string src = Path.Combine(dir, Source(k)), bin = Built(s, k), log = Path.Combine(dir, ReportLaunch.Script + "-" + k + ".log");
            File.WriteAllText(src, text, Encoding.ASCII);
            // Preserve the previous binary for recovery; never execute it after a failed current build.
            string prev = bin + ".prev";
            try { if (File.Exists(bin)) { File.Copy(bin, prev, true); File.Delete(bin); } }
            catch (Exception e) { throw new UserMessage(Lang.T("فایل اسکریپت قدیمی آزاد نیست؛ نسخهٔ جدید اجرا نشد: ", "The old reporter binary is locked; the new version was not started: ") + e.Message); }
            try { if (File.Exists(log)) File.Delete(log); } catch { }
            Log.Write("building the report script for " + k + " with " + editor);
            var psi = new ProcessStartInfo(editor, "/compile:\"" + src + "\" /log:\"" + log + "\"")
            {
                UseShellExecute = false, CreateNoWindow = true, WorkingDirectory = Path.GetDirectoryName(editor),
            };
            using (Process p = Process.Start(TerminalProcessPolicy.Prepare(psi, s)))
            {
                var clock = Stopwatch.StartNew();
                try
                {
                    while (!p.WaitForExit(100))
                    {
                        if (cancel != null && cancel()) throw new OperationCanceledException();
                        if (clock.ElapsedMilliseconds >= 120000) throw new UserMessage(Lang.T("ساخت اسکریپت بیش از دو دقیقه طول کشید.", "Script compilation exceeded two minutes."));
                    }
                }
                finally { if (!p.HasExited) { try { TerminalCloseAudit.Record(p,Processes.PathOf(p),"report-helper-force");p.Kill(); p.WaitForExit(1000); } catch { } } }
            }
            string report = TextFiles.ReadText(log) ?? "";
            Log.Write("report script build " + k + ": " + TextUtil.OneLine(report));
            if (!File.Exists(bin))
            {
                if (File.Exists(prev))
                {
                    File.WriteAllText(bin + ".failed", Stamp(text));
                    Log.Write("report script " + k + ": compilation failed; old script was preserved but will not be executed.");
                }
                throw new UserMessage(Lang.T("ساختن اسکریپت گزارش ", "Building the report script for ") + k + Lang.T(" نشد. گزارش MetaEditor:\n\n", " failed. MetaEditor's output:\n\n") + Tail(report, 1500) + Lang.T("\n\nاین متن را برای پشتیبانی بفرستید.", "\n\nSend this text to support."));
            }
            File.WriteAllText(bin + ".stamp", Stamp(text));
            try { if (File.Exists(bin + ".failed")) File.Delete(bin + ".failed"); } catch { }
        }

        static string Tail(string s, int max)
        {
            s = (s ?? "").Trim();
            return s.Length <= max ? s : "…" + s.Substring(s.Length - max);
        }

        public static string Target(Instance report) { return Path.Combine(report.Dir, Kinds.Mql(report.Kind), report.Kind == Kind.MT5 ? "Experts" : "Scripts", Binary(report.Kind)); }

        /// <summary>Puts the built reporter into a private copy (MQL5\Experts or MQL4\Scripts).</summary>
        public static bool Deploy(Settings s, Instance report)
        {
            string bin = Built(s, report.Kind), dest = Target(report);
            if (!Ready(s, report.Kind)) return false;
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(dest));
                File.Copy(bin, dest, true);
                File.SetLastWriteTimeUtc(dest, File.GetLastWriteTimeUtc(bin));
                return true;
            }
            catch (Exception e)
            {
                Log.Write("report script into " + report.Name + ": " + e.Message);
                return false;
            }
        }
    }

    // ================================================================== the report copies

    /// <summary>The program's own MetaTraders for reading history, under the copies folder in _MTManager\report: one for each
    /// platform, server and place (up to four run at once). Each is made once from a student copy of the same server (so it knows
    /// that server), without its history, logs, saved logins and start file. A student's copy itself never gets the script.</summary>
    public static class ReportCopies
    {
        static bool Eq(string a, string b) { return string.Equals(a, b, StringComparison.OrdinalIgnoreCase); }

        /// <summary>A server name as a folder name: letters, digits, dot, dash and underscore.</summary>
        public static string Safe(string server)
        {
            var sb = new StringBuilder();
            foreach (char c in (server ?? "").Trim())
                sb.Append((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '.' || c == '-' || c == '_' ? c : '_');
            string s = sb.ToString().Trim('.', '_');
            if (s.Length > 40) s = s.Substring(0, 40);
            return s.Length == 0 ? "server" : s;
        }

        public static string Name(Kind k, string server, int slot) { return k + "-" + Safe(server) + "-" + slot; }

        public static Instance For(Settings s, Kind k, string server, int slot)
        {
            string name = Name(k, server, slot);
            return new Instance { Name = "report-" + name, Kind = k, Dir = Path.Combine(ReportLaunch.ReportRoot(s.BaseDir), name) };
        }

        /// <summary>What a report copy leaves out of the copy it is made from (path inside the copy, with \ or /): its bar and tick
        /// history (bases, history: the terminal fetches what it needs), logs, the tester, set-aside charts, the files and logs of
        /// its programs, saved logins (config\accounts.*), a start file, and the extra tools at the top (MetaEditor, uninstall, archives).</summary>
        public static bool Skip(string relative, bool isDir, Kind k)
        {
            string[] p = (relative ?? "").Split('\\', '/').Where(x => x.Length > 0).ToArray();
            if (p.Length == 0) return false;
            if (p.Length == 1)
            {
                // The private MT5 reporter deploys its own expert and empty chart profile.
                // Student indicators, libraries, EAs and profiles are neither needed nor executed.
                if (isDir && k == Kind.MT5 && new[] { "MQL5", "Profiles", "templates", "sounds" }.Any(x => Eq(x, p[0]))) return true;
                if (isDir) return new[] { "logs", "tester", "bases", "history", "MTManager-backup" }.Any(x => Eq(x, p[0]));
                return Lean.IsExtraFile(p[0]) || Eq(p[0], Launcher.StartFileName) || p[0].EndsWith(".mtm-new", StringComparison.OrdinalIgnoreCase);
            }
            if (p.Length == 2 && isDir && Eq(p[0], Kinds.Mql(k))) return Eq(p[1], "Files") || Eq(p[1], "Logs");
            if (p.Length == 2 && !isDir && Eq(p[0], "config")) return Eq(p[1], "accounts.dat") || Eq(p[1], "accounts.ini");
            return false;
        }

        /// <summary>Copies a student copy into a report copy (see Skip). A file the running terminal holds is left out and counted;
        /// throws when the terminal itself could not be copied.</summary>
        public static int CopyFrom(Instance source, string dest, Func<bool> cancel = null)
        {
            int locked = 0;
            Copy(source.Dir, dest, "", source.Kind, ref locked, cancel);
            if (!File.Exists(Path.Combine(dest, Kinds.Exe(source.Kind))))
                throw new UserMessage(Lang.T("فایل ", "File ") + Kinds.Exe(source.Kind) + Lang.T(" از ", " of ") + source.Name + Lang.T(" کپی نشد.", " was not copied."));
            PortableServers.Sync(source.Dir, dest, source.Kind);
            return locked;
        }

        static void Copy(string from, string to, string rel, Kind k, ref int locked, Func<bool> cancel)
        {
            if (cancel != null && cancel()) throw new OperationCanceledException();
            Directory.CreateDirectory(to);
            foreach (string f in Directory.GetFiles(from))
            {
                string name = Path.GetFileName(f);
                if (Skip(rel.Length == 0 ? name : rel + "\\" + name, false, k)) continue;
                try
                {
                    using (var input = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                    using (var output = File.Create(Path.Combine(to, name)))
                    {
                        var bytes = new byte[65536]; int n;
                        while ((n = input.Read(bytes, 0, bytes.Length)) > 0) { if (cancel != null && cancel()) throw new OperationCanceledException(); output.Write(bytes, 0, n); }
                    }
                }
                catch (IOException e)
                {
                    locked++;
                    Log.Write("report copy: left out " + (rel.Length == 0 ? name : rel + "\\" + name) + " (" + e.Message + ")");
                }
            }
            foreach (string d in Directory.GetDirectories(from))
            {
                string name = Path.GetFileName(d), r = rel.Length == 0 ? name : rel + "\\" + name;
                if (Skip(r, true, k)) continue;
                Copy(d, Path.Combine(to, name), r, k, ref locked, cancel);
            }
        }

        /// <summary>The copy to make a report copy from: one of the same platform whose account is on the same server, a closed one
        /// first (nothing in it is in use), the student's own first among equals.</summary>
        public static Instance PickSource(IEnumerable<Instance> copies, Func<string, Account> account, Kind k, string server, Instance own, Func<Instance, bool> running)
        {
            var same = copies.Where(c =>
            {
                if (c.Kind != k) return false;
                Account a = account(c.Name);
                return a != null && a.HasLogin && Eq((a.Server ?? "").Trim(), (server ?? "").Trim());
            }).ToList();
            if (own != null && !same.Any(c => Eq(c.Name, own.Name))) same.Add(own);
            return same.OrderBy(c => running(c) ? 1 : 0).ThenBy(c => own != null && Eq(c.Name, own.Name) ? 0 : 1).FirstOrDefault() ?? own;
        }

        /// <summary>The report copy for a platform, server and place: made the first time, and afterwards kept at the build of the
        /// student copies (its terminal and the files beside it), so it does not stop to update itself in the middle of a report.</summary>
        public static Instance Prepare(Settings s, Kind k, string server, int slot, Func<Instance> source, Func<bool> cancel = null)
        {
            Instance rc = For(s, k, server, slot);
            if (!File.Exists(rc.Exe))
            {
                Instance src = source();
                if (src == null) throw new UserMessage(Lang.T("نسخه‌ای از ", "No installation of ") + k + Lang.T(" برای ساختن متاتریدر گزارش پیدا نشد.", " was found to make the report MetaTrader."));
                Directory.CreateDirectory(ReportLaunch.ReportRoot(s.BaseDir));
                string stage = rc.Dir + ".prepare-" + Guid.NewGuid().ToString("N");
                int locked;
                try
                {
                    locked = CopyFrom(src, stage, cancel);
                    if (cancel != null && cancel()) throw new OperationCanceledException();
                    if (Directory.Exists(rc.Dir)) Directory.Move(rc.Dir, rc.Dir + ".incomplete-" + Guid.NewGuid().ToString("N"));
                    Directory.Move(stage, rc.Dir);
                }
                finally { try { if (Directory.Exists(stage)) Directory.Delete(stage, true); } catch { } }
                Log.Write("report copy " + rc.Name + " made from " + src.Name + (locked > 0 ? " (" + locked + " files in use left out)" : ""));
                return rc;
            }
            Instance from = null;
            try { from = source(); }
            catch (Exception e) { Log.Write("report copy " + rc.Name + ": " + e.Message); }
            if (from != null && TerminalUpdate.Newer(TerminalUpdate.FileVersion(from.Exe), TerminalUpdate.FileVersion(rc.Exe)))
            {
                int n = 0;
                foreach (string f in Directory.GetFiles(from.Dir))
                {
                    string name = Path.GetFileName(f);
                    if (Skip(name, false, k)) continue;
                    try { File.Copy(f, Path.Combine(rc.Dir, name), true); n++; }
                    catch (IOException e) { Log.Write("report copy update: " + name + " (" + e.Message + ")"); }
                }
                Log.Write("report copy " + rc.Name + " brought to the build of " + from.Name + " (" + n + " files)");
            }
            return rc;
        }

        /// <summary>Start files a report copy may still have when the program was closed in the middle of a report.</summary>
        public static void DeleteLeftovers(Settings s)
        {
            string root = ReportLaunch.ReportRoot(s.BaseDir);
            if (!Directory.Exists(root)) return;
            foreach (string d in Directory.GetDirectories(root)) Launcher.DeleteStartFile(Path.Combine(d, ReportLaunch.StartFileName));
        }
    }

    // ================================================================== one report run

    /// <summary>One student's read: the history, or why there is none.</summary>
    public sealed class ReportRow
    {
        public string Name = "", Login = "", Server = "", Platform = "", Folders = "", Copy = "";
        public AccountJournal Journal;
        public JournalSummary Summary;
        /// <summary>Why the history could not be read; null when it was.</summary>
        public string Error;
        public bool Cached, Cancelled, Retryable;
        public int Attempts = 1;
        public long ReadMs, TotalMs;
        public long PeakMb;
        public string Route = "script";
        public string FailureCode = "";
        /// <summary>When the history is the copy kept on this computer (a new read did not work): «از کش» and its time.</summary>
        public string Note;

        public static string CacheNote(DateTime exported) { return Lang.T("از کش (", "From cache (") + Gd.At(exported) + ")"; }
    }

    /// <summary>One student to read: the copy, its account, and the limits that hold for it.</summary>
    public sealed class ReportJob
    {
        public int Attempt = 1;
        public Stopwatch Clock;
        public long PeakMb;
        public int Index;
        public Instance Copy;
        public Account Account;
        public string Name = "", Folders = "";
        public TradeLimits Limits = new TradeLimits();
        /// <summary>3.21: the first server day to read for this student (the report's own first day when not set).</summary>
        public DateTime From;
    }

    /// <summary>Reads the students one after another (or up to four at a time) in report copies, on threads of its own.
    /// Changed tells each step (from those threads). Every MetaTrader it opens is recorded as opened here and closed by it.</summary>
    public sealed partial class ReportRunner
    {
        readonly Settings settings;
        readonly List<ReportJob> jobs;
        readonly List<Instance> copies;
        /// <summary>The accounts as they were when the report began (the window may change them meanwhile).</summary>
        readonly Func<string, Account> accountOf;
        readonly ReportRange range;
        public readonly int Parallel;
        public readonly int InitialParallel;
        public Action<int, StepState, string> Changed;
        public Action<int, ReportRow> ResultReady;
        /// <summary>A line about the whole run (the script being built the first time).</summary>
        public Action<string> Note;
        /// <summary>Why the script could not be built, per platform (MetaEditor's report): shown once at the end.</summary>
        public readonly Dictionary<Kind, string> ScriptProblems = new Dictionary<Kind, string>();
        volatile bool stop, ending;
        readonly List<Process> live = new List<Process>();
        static readonly object Mt4Gate = new object();
        /// <summary>3.19: report MetaTraders start 1.5 seconds apart at least, MT4 and MT5; the start interval is unchanged.</summary>
        static readonly StartPacer Pacer = new StartPacer();
        static readonly ReportStartBudget StartBudget = new ReportStartBudget();
        /// <summary>3.19: the most memory each report MetaTrader held (MB), for the log at the end of the run.</summary>
        readonly List<long> peaks = new List<long>();
        ReportRow[] rows;
        readonly Func<ReportJob, int, ReportRow> readOverride;
        readonly ReportDiagnostics diagnostics;
        readonly Func<ReportResourceSnapshot> resourceRead;
        readonly Mt4AdaptiveAdmission mt4Adaptive;

        sealed class WarmTerminal { public Instance Copy; public Process Process; public ReportLoginSession Login; public string Server; }
        readonly ConcurrentDictionary<int, WarmTerminal> warm = new ConcurrentDictionary<int, WarmTerminal>();
        readonly Mt5WarmRecovery warmRecovery = new Mt5WarmRecovery();
        readonly Mt5ChartMemory mt5Charts = new Mt5ChartMemory();
        readonly ConcurrentDictionary<string, string> mt5StalledCharts = new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        readonly ConcurrentDictionary<string, Lazy<string>> mt5Installs = new ConcurrentDictionary<string, Lazy<string>>(StringComparer.OrdinalIgnoreCase);

        // Cache discovery only for this report run, not across installs or user configuration changes.
        string Mt5Install(string server)
        {
            return mt5Installs.GetOrAdd(server.Trim(), key => new Lazy<string>(() =>
            {
                try { return StudentImportRuntime.FindWithDeadline(() => { bool exact; return ServerCatalog.InstallFor(Kind.MT5, key, settings, out exact); }, () => ending, 15000); }
                catch (TimeoutException) { Log.Write("MT5 installed-broker discovery exceeded 15s; using existing private configuration."); return null; }
            })).Value;
        }

        T Mt5Stage<T>(ReportJob job, string code, string label, Func<T> work)
        {
            if (job.Copy.Kind != Kind.MT5) return work();
            var clock = Stopwatch.StartNew(); var sync = new object(); bool finished = false;
            Action display = () => Say(job.Index, StepState.Starting, label + " — " + Fa.N((int)clock.Elapsed.TotalSeconds) + Lang.T(" ثانیه", " s"));
            Log.Write("MT5 prepare begin: " + job.Copy.Name + " " + code);
            display();
            using (var timer = new Timer(_ => { lock (sync) { if (!finished) display(); } }, null, 1000, 1000))
                try { if (ending) throw new OperationCanceledException(); return work(); }
                finally
                {
                    lock (sync) finished = true;
                    Log.Write("MT5 prepare end: " + job.Copy.Name + " " + code + " elapsed=" + clock.ElapsedMilliseconds + "ms");
                    if (diagnostics != null) diagnostics.Timing(job, code == "close-previous" ? "close" : "prepare", clock.ElapsedMilliseconds, code);
                }
        }

        internal static bool Mt5HasCatalog(Instance copy)
        {
            try
            {
                string path = Path.Combine(PortableServers.Subdirectory(copy.Dir, "config"), "servers.dat");
                return File.Exists(path) && new FileInfo(path).Length > 0;
            }
            catch { return false; }
        }

        void Mt5RefreshCatalog(ReportJob job, Instance rc)
        {
            // This copy was just checked closed by EndLeftover. Prefer the student's broker
            // catalog; only discover installed terminals when missing, or on the deferred retry.
            if (Mt5HasCatalog(job.Copy)) PortableServers.Sync(job.Copy.Dir, rc.Dir, Kind.MT5, job.Account.Server, () => ending, _ => null);
            if (!Mt5HasCatalog(rc) || job.Attempt > 1)
            {
                string native = Mt5Install(job.Account.Server);
                if (native != null) PortableServers.Sync(native, rc.Dir, Kind.MT5, job.Account.Server, () => ending);
            }
        }

        internal static List<string> SelectMt5Symbols(Func<List<string>> student, Func<List<string>> report, Func<List<string>> installed, ICollection<string> tried)
        {
            var known = student();
            if (ReportLaunch.PickSymbol(null, known, tried) == null) known.AddRange(report());
            if (ReportLaunch.PickSymbol(null, known, tried) == null) known.AddRange(installed());
            return known.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        List<string> Mt5Symbols(ReportJob job, Instance rc, ICollection<string> tried)
        {
            // A known, untried broker symbol suffices. Consult other copies on a chart retry.
            return SelectMt5Symbols(() => ReportLaunch.KnownSymbols(job.Copy, job.Account.Server),
                () => ReportLaunch.KnownSymbols(rc, job.Account.Server), () =>
            {
                var known = new List<string>();
                string native = Mt5Install(job.Account.Server);
                if (native != null) foreach (string root in PortableServers.Roots(native))
                    known.AddRange(ReportLaunch.KnownSymbols(new Instance { Kind = Kind.MT5, Dir = root }, job.Account.Server));
                return known;
            }, tried);
        }
        string WarmKey(int slot, string server) { return slot + "|" + (server ?? ""); }
        bool CanWarm(int slot, Instance rc) { return rc.Kind == Kind.MT5 && Environment.OSVersion.Platform == PlatformID.Win32NT && Environment.Is64BitOperatingSystem && warmRecovery.CanReuse(WarmKey(slot, rc.Dir)); }
        void CloseWarm(int slot)
        {
            WarmTerminal previous; if (!warm.TryGetValue(slot, out previous)) return;
            warm.TryRemove(slot, out previous); if (previous == null) return; previous.Login.Dispose(); End(previous.Process, previous.Copy);
            lock (live) live.Remove(previous.Process);
            EndLeftover(previous.Copy); previous.Process.Dispose();
        }
        public static int[] Schedule(IList<ReportJob> jobs, IEnumerable<int> indices)
        {
            return indices.GroupBy(n => jobs[n].Copy.Kind + "|" + (jobs[n].Account.Server ?? "").Trim().ToUpperInvariant()).SelectMany(g => g).ToArray();
        }

        /// <summary>Check before a report run: existing ordinary terminals can occupy the places reserved for
        /// native reporters. Explain this once without marking any account invalid or starting the report queue.</summary>
        public static string NativeAdmissionProblem(Settings settings, IEnumerable<Instance> selected)
        {
            bool hasMt4 = selected != null && selected.Any(copy => copy.Kind == Kind.MT4);
            if (!hasMt4 || !SandboxLaunch.IsEnabled(settings)) return null;
            return NativeAdmissionProblem(true, true, SandboxLaunch.AdmissionMt4Count(settings), SandboxLaunch.ReportLimit(settings));
        }

        internal static string NativeAdmissionProblem(bool overflowEnabled, bool hasMt4, int nativeCount, int limit)
        {
            if (!overflowEnabled || !hasMt4 || Mt4Limit.Room(nativeCount, limit)) return null;
            return NativeAdmissionMessage();
        }

        static string NativeAdmissionMessage()
        {
            return Lang.T("ظرفیت اجرای عادی MT4 برای گزارش‌خوان پر است. چند متاتریدر عادی را ببندید و از «اجرا» در MetaFactory دوباره باز کنید تا نسخه‌های اضافی در Sandboxie اجرا شوند؛ سپس گزارش بگیرید. حساب‌ها ناموفق نشده‌اند.",
                "Ordinary MT4 capacity is full. Close some ordinary MT4 terminals and reopen them using Run in MetaFactory so surplus copies launch in Sandboxie; then request reports again. No accounts have failed.");
        }

        public ReportRunner(Settings settings, List<ReportJob> jobs, List<Instance> copies, Func<string, Account> accountOf, ReportRange range, int parallel, Func<ReportJob, int, ReportRow> read = null, Func<ReportResourceSnapshot> resources = null)
        {
            readOverride = read;
            this.settings = settings;
            this.jobs = jobs;
            this.copies = copies;
            this.accountOf = accountOf;
            this.range = range;
            Parallel = Math.Max(1, Math.Min(ReportParallel.Max, parallel));
            var sampler = new ReportResourceSampler();
            resourceRead = resources ?? (() => { var sample = sampler.Read(); sample.PendingGrowthMb = StartBudget.PendingGrowthMb; return sample; });
            InitialParallel = Parallel;
            // Only MT4 uses the measured 3.37 pilot. MT5/mixed runs preserve the
            // caller-selected 3.36.2 worker count; each cold launch still reserves RAM.
            if (jobs.Count > 0 && jobs.All(j => j.Copy.Kind == Kind.MT4))
            {
                ReportResourceSnapshot initial = resourceRead();
                InitialParallel = Math.Min(Parallel, ReportParallel.For(settings, jobs.Count, initial.Processors, initial.TotalMb, initial.FreeMb));
                if ((readOverride == null || resources != null) && Parallel > InitialParallel)
                {
                    if (InitialParallel == 1 && jobs.Count > 1 && jobs.All(j => j.Copy.Kind == Kind.MT4)
                        && ReportParallel.CanPilotMt4(settings, initial.Processors, initial.TotalMb, initial.FreeMb))
                    {
                        // Resource pressure may have changed after the caller chose three/four workers.
                        // The pilot proves room for a second worker only, never for every parked slot.
                        Parallel = Math.Min(Parallel, 2); mt4Adaptive = new Mt4AdaptiveAdmission();
                    }
                    else Parallel = InitialParallel;
                }
            }
            if (readOverride == null) diagnostics = new ReportDiagnostics(jobs, Parallel);
        }

        /// <summary>Starts no one new; those being read are finished.</summary>
        public void Stop() { stop = true; }

        public bool Stopping { get { return stop; } }

        /// <summary>The program is closing: the report MetaTraders open now are ended at once.</summary>
        public void EndNow()
        {
            stop = true;
            ending = true;
            List<Process> now;
            lock (live) now = live.ToList();
            foreach (Process p in now)
            {
                try { if (!p.HasExited) { TerminalCloseAudit.Record(p,Processes.PathOf(p),"report-helper-force");p.Kill(); } } catch { }
            }
        }

        void Say(int k, StepState state, string detail)
        {
            if (k >= 0 && k < jobs.Count && jobs[k].Clock != null) Log.Write("report stage: " + jobs[k].Copy.Name + " " + state + " at " + jobs[k].Clock.ElapsedMilliseconds + "ms");
            if (diagnostics != null && k >= 0 && k < jobs.Count) diagnostics.Stage(jobs[k], state.ToString(), detail);
            Action<int, StepState, string> c = Changed;
            if (c == null) return;
            try { c(k, state, detail); } catch { }
        }

        /// <summary>Reads every student; returns one row each, in the order given.</summary>
        public List<ReportRow> Run()
        {
            try { return RunCore(); }
            finally
            {
                try { foreach (int slot in warm.Keys.ToArray()) CloseWarm(slot); }
                finally { if (diagnostics != null) diagnostics.Finish(); }
            }
        }
        List<ReportRow> RunCore()
        {
            rows = new ReportRow[jobs.Count];
            foreach (Kind k in (readOverride == null ? jobs.Select(j => j.Copy.Kind).Distinct() : Enumerable.Empty<Kind>()))
            {
                if (!ReportScript.Ready(settings, k))
                {
                    Action<string> n = Note;
                    if (n != null) try { n(Lang.T("ساختن اسکریپت گزارش ", "Building the report script for ") + k + Lang.T(" با MetaEditor (فقط بار اول، تا دو دقیقه)…", " with MetaEditor (first time only, up to two minutes)…")); } catch { }
                }
                try { if (ending) break; ReportScript.Build(settings, k, () => ending); }
                catch (OperationCanceledException) { break; }
                catch (UserMessage e) { ScriptProblems[k] = e.Message; }
                catch (Exception e) { ScriptProblems[k] = Lang.T("ساختن اسکریپت گزارش ", "Building the report script for ") + k + Lang.T(" نشد: ", " failed: ") + e.Message; }
                if (ScriptProblems.ContainsKey(k)) Log.Write("report script " + k + ": " + TextUtil.OneLine(ScriptProblems[k]));
            }
            Log.Write("report: " + jobs.Count + " accounts, " + Parallel + " at a time, " + range.From.ToString("yyyy-MM-dd") + " to " + range.To.AddDays(-1).ToString("yyyy-MM-dd"));
            RunPass(Schedule(jobs, Enumerable.Range(0, jobs.Count)), 1);
            if (!stop)
                RunPass(Schedule(jobs, Enumerable.Range(0, jobs.Count).Where(k => rows[k] != null && rows[k].Retryable)), 2);
            for (int k = 0; k < rows.Length; k++)
            {
                if (rows[k] == null) rows[k] = new ReportRow { Name = jobs[k].Name, Copy = jobs[k].Copy.Name, Login = jobs[k].Account.Login, Server = jobs[k].Account.Server, Platform = jobs[k].Copy.Kind.ToString(), Cancelled = true, Attempts = 0, Error = Lang.T("پیش از شروع این حساب متوقف شد.", "Stopped before this account started.") };
                if (diagnostics != null && rows[k].Attempts == 0) diagnostics.Result(jobs[k], rows[k], "not-attempted");
                Publish(k, rows[k]);
            }
            lock (peaks)
                if (peaks.Count > 0)
                    Log.Write("report memory: " + peaks.Count + " MetaTrader runs, the most one held " + peaks.Max() + " MB, on average " + (long)peaks.Average() + " MB");
            return rows.ToList();
        }

        void Publish(int index, ReportRow row)
        {
            var ready = ResultReady; if (ready != null) try { ready(index, row); } catch { }
        }
        void RunPass(int[] indices, int pass)
        {
            int cursor = -1;
            var workers = Enumerable.Range(1, Parallel).Select(slot => new Thread(() => {
                while (!stop)
                {
                    if (mt4Adaptive != null && slot > 1)
                    {
                        var capacityClock = Stopwatch.StartNew(); bool paused = false;
                        try
                        {
                            while (!stop && !ending && Volatile.Read(ref cursor) + 1 < indices.Length)
                            {
                                if (mt4Adaptive.AllowSecond(resourceRead())) break;
                                if (!paused)
                                {
                                    paused = true;
                                    if (diagnostics != null) diagnostics.RunStage("resource-wait", "MT4 worker " + slot + " parked before account claim; waiting for two fresh measured samples, RAM headroom and low CPU");
                                    Log.Write("MT4 adaptive worker " + slot + ": waiting for measured capacity; no account attempt consumed");
                                }
                                Thread.Sleep(250);
                            }
                        }
                        finally
                        {
                            if (paused && diagnostics != null) diagnostics.RunTiming("capacity-wait", capacityClock.ElapsedMilliseconds, "MT4 worker " + slot + " preclaim wait; may overlap another worker's useful report work");
                        }
                        if (stop || ending || Volatile.Read(ref cursor) + 1 >= indices.Length) return;
                    }
                    int at = Interlocked.Increment(ref cursor); if (at >= indices.Length) return;
                    int k = indices[at]; ReportJob job = jobs[k]; job.Attempt = pass; job.Clock = Stopwatch.StartNew(); job.PeakMb = 0;
                    if (diagnostics != null) diagnostics.BeginAttempt(job);
                    if (diagnostics != null && mt4Adaptive != null) diagnostics.Stage(job, "capacity-admitted", "MT4 worker=" + slot + "; worker ceiling=" + Parallel);
                    try { rows[k] = readOverride == null ? One(job, slot) : readOverride(job, slot); rows[k].Attempts = pass; }
                    catch (OperationCanceledException) { rows[k] = NewRow(job); rows[k].Cancelled = true; rows[k].Error = Lang.T("به درخواست شما متوقف شد.", "Stopped at your request."); }
                    catch (Exception e)
                    {
                        Log.Write("report failed: " + e.GetType().Name);
                        rows[k] = Failed(job, NewRow(job), Lang.T("خطا در خواندن", "Reading error"), Lang.T("خطا در خواندن: ", "Reading error: ") + e.GetType().Name);
                    }
                    rows[k].TotalMs = job.Clock.ElapsedMilliseconds;
                    rows[k].PeakMb = Math.Max(rows[k].PeakMb, job.PeakMb);
                    if (mt4Adaptive != null)
                    {
                        mt4Adaptive.Record(rows[k].Journal != null && !rows[k].Cached && !rows[k].Cancelled && rows[k].Error == null, (ulong)Math.Max(0, rows[k].PeakMb));
                        if (diagnostics != null)
                        {
                            ReportResourceSnapshot measured = resourceRead();
                            diagnostics.Stage(job, "capacity-sample", "peak_mb=" + rows[k].PeakMb + "; free_mb=" + measured.FreeMb
                                + "; pending_growth_mb=" + measured.PendingGrowthMb + "; cpu_percent=" + measured.CpuPercent.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture)
                                + "; initial_workers=" + InitialParallel + "; worker_ceiling=" + Parallel);
                        }
                    }
                    if (diagnostics != null) diagnostics.Result(job, rows[k], rows[k].FailureCode);
                    Log.Write("report timing: " + job.Copy.Name + " attempt=" + pass + " route=" + rows[k].Route + " read=" + rows[k].ReadMs + "ms total=" + rows[k].TotalMs + "ms");
                    if (rows[k].Retryable && pass == 1 && !stop) Say(k, StepState.Retrying, Lang.T("در صف یک تلاش دوباره پس از سایر حساب‌ها…", "Queued for one retry after other accounts…"));
                    else Publish(k, rows[k]);
                }
            }) { IsBackground = true, Name = "report-" + slot }).ToList();
            foreach (Thread thread in workers) thread.Start(); foreach (Thread thread in workers) thread.Join();
        }

        static ReportRow NewRow(ReportJob job)
        {
            return new ReportRow
            {
                Attempts = job.Attempt, Name = job.Name, Login = job.Account.Login.Trim(), Server = job.Account.Server ?? "", Platform = job.Copy.Kind.ToString(),
                Folders = job.Folders, Copy = job.Copy.Name,
            };
        }

        ReportRow One(ReportJob job, int slot)
        {
            Account acc = job.Account;
            Kind k = job.Copy.Kind;
            ReportRow row = NewRow(job);
            string password = acc.PasswordForLogin();
            if (password == null)
                return Failed(job, row, Lang.T("رمز ورود خوانده نمی‌شود", "The login password cannot be read"), Lang.T("رمز ورود ذخیره‌شده روی این کاربر ویندوز خوانده نمی‌شود؛ از «حساب و رمز» دوباره واردش کنید.", "The login password saved for this Windows user cannot be read; enter it again from “Account and password”."));
            if (password.Length == 0)
                return Failed(job, row, Lang.T("رمز ورود ثبت نشده", "No login password saved"), Lang.T("رمز ورود این حساب ثبت نشده؛ از «حساب و رمز» واردش کنید (گزارش با نوع رمز انتخاب‌شده خوانده می‌شود).", "This account has no login password; enter it from “Account and password” (reports use the configured login mode)."));
            string problem = PasswordRule.Problem(password);
            if (problem != null) return Failed(job, row, Lang.T("رمز ورود نادرست ذخیره شده", "The login password is saved wrongly"), Lang.T("رمز ورود: ", "Investor password: ") + problem);
            if (ScriptProblems.ContainsKey(k))
                return Failed(job, row, Lang.T("اسکریپت گزارش ", "Report script ") + k + Lang.T(" ساخته نشد", " was not built"), Lang.T("اسکریپت گزارش ", "Report script ") + k + Lang.T(" ساخته نشد: ", " was not built: ") + ScriptProblems[k]);

            Say(job.Index, StepState.Starting, Lang.T("آماده‌سازی متاتریدر گزارش…", "Preparing the report MetaTrader…"));
            Instance rc;
            WarmTerminal ready; Instance expected = ReportCopies.For(settings, k, acc.Server, slot);
            bool existing = warm.TryGetValue(slot, out ready) && string.Equals(ready.Copy.Dir, expected.Dir, StringComparison.OrdinalIgnoreCase) && string.Equals(ready.Server, acc.Server.Trim(), StringComparison.OrdinalIgnoreCase) && !HasExited(ready.Process);
            if (!existing) CloseWarm(slot);
            try
            {
                rc = Mt5Stage(job, "copy", Lang.T("آماده‌سازی فایل‌های نسخهٔ خصوصی MT5", "Preparing private MT5 files"), () => {
                Dictionary<string, Process> running = existing ? null : Processes.Running();
                try
                {
                return existing ? ready.Copy : ReportCopies.Prepare(settings, k, acc.Server, slot,
                    () => {
                        Instance selected = ReportCopies.PickSource(copies.Where(c => File.Exists(c.Exe)), accountOf, k, acc.Server, File.Exists(job.Copy.Exe) ? job.Copy : null, c => Processes.IsRunning(running, c.Exe));
                        if (selected != null) return selected;
                        string dir = StudentDirectory.Source(settings, k, acc.Server, () => ending || stop);
                        return dir == null ? null : new Instance { Name = "installed-broker", Kind = k, Dir = dir };
                    }, () => ending);
                }finally{if(running!=null)foreach(var process in running.Values)process.Dispose();}
                });
            }
            catch (OperationCanceledException) { throw; }
            catch (UserMessage e) { return Failed(job, row, Lang.T("متاتریدر گزارش ساخته نشد", "The report MetaTrader was not made"), e.Message); }
            catch (Exception e)
            {
                Log.Write("report copy for " + acc.Login + ": " + e);
                return Failed(job, row, Lang.T("متاتریدر گزارش ساخته نشد", "The report MetaTrader was not made"), Lang.T("ساختن متاتریدر گزارش نشد: ", "Making the report MetaTrader failed: ") + e.Message);
            }

            var tried = new List<string>();
            Action<Outcome> commit = outcome => Commit(job, row, outcome);
            Outcome o = ObserveOutcome(job, TryWarm(job, rc, slot, row, commit));
            if (o == null) { row.Route = existing ? "script-fallback" : CanWarm(slot, rc) ? "MT5-resident-start" : "script"; o = ObserveOutcome(job, Attempt(job, rc, password, tried, slot, commit)); }
            bool updated = false;
            while (o.Journal == null && !ending)
            {
                // MetaTrader closed to update itself and started again without the script: once more, now up to date.
                if (o.Retry && !updated) { updated = true; o = ObserveOutcome(job, Attempt(job, rc, password, tried, slot, commit)); continue; }
                // MT5 kept the script waiting on a chart the broker does not have: again on another of its symbols (twice at most).
                if (o.WrongSymbol != null && tried.Count < 2)
                {
                    tried.Add(o.WrongSymbol);
                    Say(job.Index, StepState.Starting, Lang.T("نماد ", "Symbol ") + o.WrongSymbol + Lang.T(" نبود؛ با نماد دیگر…", " not available; trying another symbol…"));
                    o = ObserveOutcome(job, Attempt(job, rc, password, tried, slot, commit));
                    continue;
                }
                break;
            }
            if (ending && o.Journal == null) { row.Cancelled = true; row.Error = Lang.T("به درخواست شما متوقف شد.", "Stopped at your request."); return row; }
            if (o.Journal == null) { row.FailureCode = o.Code; return Failed(job, row, o.Short, o.Long, o.Transient); }

            if (row.Journal == null) Commit(job, row, o);
            return row;
        }
        Outcome ObserveOutcome(ReportJob job, Outcome outcome)
        {
            if (diagnostics != null && outcome != null)
                diagnostics.Stage(job, outcome.Journal != null ? "fresh-result" : string.IsNullOrWhiteSpace(outcome.Code) ? "attempt-failed" : outcome.Code, outcome.Long);
            return outcome;
        }
        internal void Commit(ReportJob job, ReportRow row, Outcome o)
        {
            if (row.Journal != null) return;
            row.Journal = o.Journal;
            if (o.Journal.HistoryChecked && !o.Journal.HistoryOk) row.Note = Lang.T("گزارش تازه دریافت شد؛ کامل‌بودن تاریخچه با بالانس تأیید نشد.", "Fresh report received; history completeness could not be reconciled with the balance.");
            row.Summary = JournalMath.Summarize(o.Journal, range.From, range.To, job.Limits);
            try { JournalCache.Save(o.Journal, job.Account.Server); }
            catch (Exception e) { Log.Write("journal cache " + job.Account.Login + ": " + e.Message); }
            Say(job.Index, StepState.Done, Lang.T("خوانده شد: ", "Read: ") + Fa.N(row.Summary.Trades) + Lang.T(" معامله", " trades"));
            Log.Write("report " + job.Account.Login + ": read, " + o.Journal.Trades.Count + " trades and " + o.Journal.Open.Count + " open since " + o.Journal.From.ToString("yyyy-MM-dd") +
                      (o.Journal.ScriptVersion.Length > 0 ? ", script " + o.Journal.ScriptVersion : ", an older script") +
                      (!o.Journal.HistoryChecked ? "" : o.Journal.HistoryOk ? ", the history adds up to the balance"
                       : ", the history does not add up to the balance (" + o.Journal.HistorySum.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture) + " against " +
                         o.Journal.HistoryBalance.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture) + ")"));
            row.ReadMs = job.Clock == null ? 0 : job.Clock.ElapsedMilliseconds;
            Publish(job.Index, row);
        }

        /// <summary>When reading did not work: the last complete read kept on this computer, if it covers the range
        /// (marked «از کش» with its time); otherwise the reason.</summary>
        ReportRow Failed(ReportJob job, ReportRow row, string shortWhy, string longWhy, bool retryable = false)
        {
            row.Retryable = retryable;
            bool deferred = retryable && job.Attempt < 2 && !stop;
            AccountJournal kept = null;
            try { kept = JournalCache.Load(job.Account.Login.Trim(), job.Account.Server ?? ""); }
            catch { }
            if (JournalCache.Covers(kept, range.From))
            {
                row.Journal = kept;
                row.Summary = JournalMath.Summarize(kept, range.From, range.To, job.Limits);
                row.Cached = true; row.Note = ReportRow.CacheNote(kept.Exported) + " · " + longWhy;
                row.Error = null;
                Say(job.Index, deferred ? StepState.Retrying : StepState.Skipped, Lang.T("از کش — ", "From cache — ") + shortWhy);
                Log.Write("report " + job.Account.Login + ": " + longWhy + " The read kept from " + kept.Exported.ToString("yyyy-MM-dd HH:mm") + " is used.");
                return row;
            }
            row.Error = longWhy;
            Say(job.Index, deferred ? StepState.Retrying : StepState.Failed, shortWhy);
            Log.Write("report " + job.Account.Login + ": " + longWhy);
            return row;
        }

        public sealed class Outcome
        {
            public AccountJournal Journal;
            public string Code = "";
            public string Short = "", Long = "";
            public bool Retry;
            public bool Transient;
            /// <summary>MT5: the chart's symbol on which the script was kept waiting (the broker does not have it); null otherwise.</summary>
            public string WrongSymbol;
        }

        static Outcome TransientFail(string shortWhy, string longWhy) { return new Outcome { Short = shortWhy, Long = longWhy, Transient = true }; }
        static Outcome Fail(string shortWhy, string longWhy) { return new Outcome { Short = shortWhy, Long = longWhy }; }

        internal static Outcome Mt5StartupFailure(bool ready, bool chartTimeout, string symbol, bool connected, int seconds, string why = null)
        {
            string shortWhy = chartTimeout ? Lang.T("همگام‌سازی چارت MT5 تمام نشد", "MT5 chart synchronization timed out")
                : ready ? Lang.T("گزارش‌خوان آماده شد؛ درخواست اجرا نشد", "Reporter ready; request did not start")
                : Lang.T("شروع گزارش‌خوان MT5 تأیید نشد", "MT5 reporter startup was not confirmed");
            string detail = (connected ? Lang.T("ورود حساب تأیید شد، اما ", "Account login was confirmed, but ") : "")
                + shortWhy + Lang.T(" در مهلت ", " within ") + Fa.N(seconds) + Lang.T(" ثانیه.", " seconds.")
                + Lang.T(" این خطا به‌تنهایی به معنی رمز اشتباه یا خراب‌بودن حساب نیست.", " This alone does not establish an invalid password or account.")
                + (string.IsNullOrWhiteSpace(why) ? "" : " " + why);
            return new Outcome { Code = chartTimeout ? "mt5-chart-sync-timeout" : ready ? "mt5-request-not-started" : "mt5-reporter-start-timeout",
                Short = shortWhy, Long = detail, Transient = true, WrongSymbol = chartTimeout ? symbol : null };
        }

        DateTime FromOf(ReportJob job) { return job.From > DateTime.MinValue ? job.From : range.From; }

        static void WriteRequest(Instance copy, ReportJob job, string token)
        {
            string path = Path.Combine(copy.Dir, "MQL5", "Files", "MTManagerReport", "request.txt");
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            string temp = path + "." + token + ".tmp";
            try
            {
                File.WriteAllLines(temp, new[] { token, job.Account.Login.Trim(), job.Account.Server.Trim(), job.From.ToString("yyyy.MM.dd", System.Globalization.CultureInfo.InvariantCulture) }, Encoding.Unicode);
                if (File.Exists(path)) File.Delete(path);
                File.Move(temp, path);
            }
            finally { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
        }
        Outcome TryWarm(ReportJob job, Instance rc, int slot, ReportRow row, Action<Outcome> commit)
        {
            WarmTerminal state;
            if (!warm.TryGetValue(slot, out state) || state.Copy.Dir != rc.Dir) return null;
            if (HasExited(state.Process)) { CloseWarm(slot); return null; }
            DateTime nativeStarted = DateTime.Now;
            string token = null;
            try
            {
            Say(job.Index, StepState.Starting, Lang.T("ورود تازه روی متاتریدر آماده…", "Fresh login on the ready report terminal…"));
            row.Route = "MT5-warm-login";
            var clock = Stopwatch.StartNew();
            ImportConnection login;
            using (diagnostics == null ? null : diagnostics.Measure(job, "login"))
                login = state.Login.Login(rc, job.Account, () => ending || stop);
            if (diagnostics != null) diagnostics.Stage(job, login != null && login.Connected ? "warm-login-confirmed" : "warm-login-unconfirmed", login == null ? "No IPC result" : login.Reason);
            Log.Write("report warm login: " + job.Copy.Name + " " + clock.ElapsedMilliseconds + "ms, confirmed=" + (login != null && login.Connected));
            if (login != null && login.State == Login.WrongLogin) return Fail(Lang.T("ورود رد شد", "Login rejected"), Lang.T("سرور شماره حساب یا رمز را رد کرد.", "The server rejected the account number or password."));
            if (login == null || !login.Connected)
            {
                if (login != null && !login.Retryable) warmRecovery.Unavailable(WarmKey(slot, rc.Dir));
                else warmRecovery.TransientFailure(WarmKey(slot, rc.Dir));
                CloseWarm(slot); return null;
            }
            token = Guid.NewGuid().ToString("N");
            string output = ReportLaunch.OutputPath(rc), stepPath = ReportLaunch.StepPath(rc), pulsePath = output + ".pulse";
            try
            {
                foreach (string path in new[] { output, output + ".part", stepPath, pulsePath, pulsePath + ".part" }) if (File.Exists(path)) File.Delete(path);
                if (job.From <= DateTime.MinValue) job.From = FromOf(job);
                WriteRequest(rc, job, token);
            }
            catch (IOException) { warmRecovery.TransientFailure(WarmKey(slot, rc.Dir)); CloseWarm(slot); return null; }
            clock.Restart(); string last = null;
            var startup = new Mt5StartupWatch(true, job.Attempt > 1);
            long lastJournal = -1500, reporterStartedAt = -1;
            while (clock.ElapsedMilliseconds < 120000)
            {
                if (ending || stop) throw new OperationCanceledException();
                Outcome found = ReadOutput(output, job.Account, FromOf(job), token);
                if (found != null)
                {
                    if (found.Journal != null)
                    {
                        if (diagnostics != null) diagnostics.Timing(job, reporterStartedAt < 0 ? "reporter-start" : "history", clock.ElapsedMilliseconds - Math.Max(0, reporterStartedAt), "warm result received; valid request-matched report");
                        row.Route = "MT5-warm-IPC+native"; commit(found); return found;
                    }
                    // Native history failure proves the reporter started. Restarting it immediately
                    // repeats the same broker request; keep it available for the next account instead.
                    if (found.Code.StartsWith("mt5-history-", StringComparison.Ordinal))
                    {
                        if (diagnostics != null) diagnostics.Timing(job, "history", clock.ElapsedMilliseconds - Math.Max(0, reporterStartedAt), found.Code);
                        return found;
                    }
                    ObserveOutcome(job, found);
                    break;
                }
                string step = TextFiles.ReadText(stepPath);
                if (!string.IsNullOrWhiteSpace(step) && step != last) { last = step; Say(job.Index, StepState.Reading, ReportLaunch.StepText(step) ?? step); }
                startup.Pulse(Mt5ReporterPulse.TryParse(TextFiles.ReadText(pulsePath), token, job.Account), clock.ElapsedMilliseconds);
                if (!startup.ReporterStarted && clock.ElapsedMilliseconds - lastJournal >= 1500)
                {
                    lastJournal = clock.ElapsedMilliseconds;
                    ObserveMt5Network(startup, ConnectionCheck.JournalTail(rc, nativeStarted), job.Account, clock.ElapsedMilliseconds);
                }
                if (startup.ReporterStarted && reporterStartedAt < 0)
                {
                    reporterStartedAt = clock.ElapsedMilliseconds;
                    if (diagnostics != null) diagnostics.Timing(job, "reporter-start", reporterStartedAt, "warm native reporter acknowledged current request");
                }
                if (HasExited(state.Process) || startup.Expired(clock.ElapsedMilliseconds)) break;
                Thread.Sleep(100);
            }
            // Some terminals stop startup scripts on account changes. Try the supported cold path once, not an endless warm loop.
            Log.Write("report warm reporter unavailable; cold fallback for " + job.Copy.Name);
            if (diagnostics != null) diagnostics.Timing(job, reporterStartedAt < 0 ? "reporter-start" : "history", clock.ElapsedMilliseconds - Math.Max(0, reporterStartedAt), "warm reporter recovery required");
            if (diagnostics != null) diagnostics.Stage(job, "warm-cold-fallback", "No usable fresh result; last native step=" + (last ?? "none") + "; elapsed=" + clock.ElapsedMilliseconds + "ms");
            warmRecovery.TransientFailure(WarmKey(slot, rc.Dir)); CloseWarm(slot); return null;
            }
            finally { if (diagnostics != null) diagnostics.Capture(job, rc, nativeStarted, "warm", token); }
        }

        static void ObserveMt5Network(Mt5StartupWatch watch, IEnumerable<string> lines, Account account, long elapsed)
        {
            foreach (string line in lines)
            {
                if (ReportTrace.ScriptLoaded(line)) watch.Progress("loaded:" + line, elapsed);
                LoginResult login = ConnectionCheck.FromJournal(new[] { line }, account.Login.Trim());
                string lower = line.ToLowerInvariant();
                bool owns = line.Contains("'" + account.Login.Trim() + "':") || line.Contains("\"" + account.Login.Trim() + "\":");
                if (login.State == Login.Connected || owns && (lower.Contains("scanning network") || lower.Contains("auto connecting") || lower.Contains("terminal synchronized") || lower.Contains("connection") && lower.Contains("lost")))
                    watch.Progress("network:" + line, elapsed);
            }
        }

        Outcome Attempt(ReportJob job, Instance rc, string password, List<string> tried, int slot, Action<Outcome> commit)
        {
            if (rc.Kind == Kind.MT5) return AttemptMt5(job, rc, password, tried, slot, commit);
            Account acc = job.Account;
            string token = Guid.NewGuid().ToString("N"); bool serve = CanWarm(slot, rc), keep = false;
            if (!Mt5Stage(job, "close-previous", Lang.T("بستن گزارش‌خوان قبلی MT5", "Closing the previous MT5 reporter"), () => EndLeftover(rc)))
                return Fail(Lang.T("متاتریدر گزارش باز ماند", "The report MetaTrader stayed open"), Lang.T("متاتریدر گزارش (", "The report MetaTrader (") + rc.Dir + Lang.T(") باز بود و بسته نشد (شاید با دسترسی مدیر اجرا شده). آن را از Task Manager ببندید و «به‌روزرسانی» را دوباره بزنید.", ") was open and did not close (perhaps it runs as administrator). Close it from Task Manager and press “Refresh” again."));
            // A cold reporter must authenticate with this request's credentials, never a saved account book.
            if (!IsReportCopy(rc)) return Fail("Invalid report copy", "A private report copy is required.");
            try
            {
                string config = Path.Combine(rc.Dir, "config");
                if (Directory.Exists(config)) foreach (string file in Directory.GetFiles(config, "accounts.*")) File.Delete(file);
            }
            catch (IOException) { return TransientFail(Lang.T("ذخیرهٔ ورود قبلی آزاد نیست", "Previous login cache is locked"), Lang.T("نسخهٔ خصوصی برای ورود تازه آماده نشد؛ اطلاعات ورود قبلی پاک نشد.", "The private terminal could not reset its previous login cache for a fresh authentication.")); }
            if (rc.Kind == Kind.MT5)
                Mt5Stage(job, "broker-catalog", Lang.T("آماده‌سازی اطلاعات سرور MT5", "Preparing MT5 server information"), () => { Mt5RefreshCatalog(job, rc); return true; });
            else PortableServers.RefreshClosed(rc, settings, acc);
            if (rc.Kind == Kind.MT4) TerminalUpdate.BeforeStart(rc);
            try { OldMonitor.Remove(rc); } catch { }
            // 3.19: no chart of its own, only the script's (the charts the terminal saved there last time are dropped).
            try { ChartProfile.UseEmpty(rc, true); }
            catch (Exception e) { Log.Write("empty profile " + rc.Name + ": " + e.Message); }
            if (!ReportScript.Deploy(settings, rc)) return Fail(Lang.T("اسکریپت در متاتریدر گزارش قرار نگرفت", "The script was not placed in the report MetaTrader"), Lang.T("اسکریپت گزارش در ", "The report script was not placed in ") + rc.Dir + Lang.T(" قرار نگرفت.", "."));

            string output = ReportLaunch.OutputPath(rc), startFile = ReportLaunch.StartFile(rc), stepFile = ReportLaunch.StepPath(rc);
            Encoding enc = rc.Kind == Kind.MT5 ? Encoding.Unicode : Encoding.Default;
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(output));
                if (rc.Kind == Kind.MT4) Mt4ReportState.ClearRequestFiles(rc);
                foreach (string f in rc.Kind == Kind.MT5 ? new[] { output, output + ".part", stepFile, output + ".pulse", output + ".pulse.part" } : new[] { output, output + ".part", stepFile }) if (File.Exists(f)) File.Delete(f);
                foreach (string preset in ReportLaunch.PresetPaths(rc))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(preset));
                    File.WriteAllLines(preset, ReportLaunch.Preset(FromOf(job), acc, token, serve), enc);
                }
            }
            catch (Exception e) { return Fail(Lang.T("پوشه‌ی متاتریدر گزارش نوشتنی نیست", "The report MetaTrader's folder is not writable"), Lang.T("در پوشه‌ی متاتریدر گزارش نمی‌شود نوشت: ", "Cannot write in the report MetaTrader's folder: ") + e.Message); }

            if (rc.Kind == Kind.MT5) { if (job.From <= DateTime.MinValue) job.From = FromOf(job); WriteRequest(rc, job, token); }
            Process p = null;
            ReportStartBudget.Reservation reservation = null;
            DateTime started;
            string symbol = null;
            // Only final admission/start holds the MT4 gate. Resource waits never hold it.
            bool gate = false;
            try
            {
                // The script's chart must be on a symbol the broker has, or it does not open (MT4) or never starts (MT5).
                List<string> known;
                if (rc.Kind == Kind.MT5) known = Mt5Stage(job, "chart-symbol", Lang.T("انتخاب نماد چارت MT5", "Selecting the MT5 chart symbol"), () => Mt5Symbols(job, rc, tried));
                else
                {
                known = ReportLaunch.KnownSymbols(job.Copy, acc.Server).Concat(ReportLaunch.KnownSymbols(rc, acc.Server)).ToList();
                bool exact; string native = ServerCatalog.InstallFor(rc.Kind, acc.Server, settings, out exact);
                if (native != null)
                    foreach (string root in PortableServers.Roots(native)) known.AddRange(ReportLaunch.KnownSymbols(new Instance { Kind = rc.Kind, Dir = root }, acc.Server));
                }
                known = known.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                string wanted = SymbolOf(rc);
                if (rc.Kind == Kind.MT5 && wanted == null) wanted = "EURUSD";
                if (rc.Kind == Kind.MT5)
                {
                    string stalled; mt5StalledCharts.TryGetValue(job.Copy.Name, out stalled);
                    string chartSource;
                    symbol = mt5Charts.Choose(acc.Server, wanted, known, tried, out chartSource, job.Attempt > 1 ? stalled : null);
                    if (diagnostics != null) diagnostics.Stage(job, "chart-selected", "symbol=" + (symbol ?? "none") + "; source=" + chartSource
                        + (job.Attempt > 1 && !string.IsNullOrEmpty(stalled) ? "; previous stalled chart=" + stalled : ""));
                }
                else symbol = ReportLaunch.PickSymbol(wanted, known, tried);
                if (symbol == null && tried.Count > 0)
                    return Fail(Lang.T("نماد چارتی برای اسکریپت نماند", "No chart symbol left for the script"),
                                Lang.T("متاتریدر ۵ اسکریپت گزارش را روی چارت ", "MetaTrader 5 kept the report script on the chart of ") + string.Join(Lang.T("، ", ", "), tried) + Lang.T(" نگه داشت و اجرا نکرد (این نمادها در این بروکر آماده نشدند) و نماد دیگری از این بروکر پیدا نشد. ", " and did not run it (these symbols were not ready at this broker), and no other symbol of this broker was found. ") +
                                Lang.T("نسخه‌ی MT5 این دانشجو را یک بار باز کنید تا فهرست نمادها (Market Watch) پر شود و دوباره گزارش بگیرید.", "Open this student's MT5 copy once so its symbol list (Market Watch) fills, then read the report again."));
                Log.Write("report: " + rc.Name + " chart " + (symbol ?? "EURUSD") + " (" + known.Count + " symbols known from the copies" +
                          (known.Count > 0 ? ": " + string.Join(", ", known.Take(6)) + (known.Count > 6 ? ", …" : "") : "") + ")" +
                          (tried.Count > 0 ? ", after " + string.Join(", ", tried) : ""));
                File.WriteAllLines(startFile, ReportLaunch.StartLines(rc.Kind, acc, password, symbol), enc);
                var capacityClock = Stopwatch.StartNew(); bool resourcePaused = false, nativeCapacityShown = false;
                Action<string> pause = reason =>
                {
                    if (reservation != null) { reservation.Dispose(); reservation = null; }
                    if (gate) { Monitor.Exit(Mt4Gate); gate = false; }
                    if (!resourcePaused)
                    {
                        resourcePaused = true;
                        Say(job.Index, StepState.Waiting, Lang.T("در انتظار آزادشدن منابع سیستم؛ حساب ناموفق نشده است…", "Waiting for system resources; the account has not failed…"));
                        if (diagnostics != null) diagnostics.Stage(job, "resource-wait", reason);
                    }
                    Thread.Sleep(250);
                };
                try
                {
                    while (true)
                    {
                        if (ending || stop) throw new OperationCanceledException();
                        bool windows = Environment.OSVersion.Platform == PlatformID.Win32NT;
                        if (windows && rc.Kind == Kind.MT4 && resourceRead().CpuPercent > 90) { pause("MT4 startup paused for high system CPU pressure"); continue; }
                        if (rc.Kind == Kind.MT4)
                        {
                            if (!Monitor.TryEnter(Mt4Gate, 100)) { pause("another MT4 start is being admitted"); continue; }
                            gate = true;
                            if (!Mt4Limit.Room(SandboxLaunch.AdmissionMt4Count(settings), SandboxLaunch.ReportLimit(settings)))
                            {
                                pause("Native MT4 capacity currently full; sandboxed terminals are excluded");
                                if (!nativeCapacityShown && SandboxLaunch.IsEnabled(settings))
                                {
                                    nativeCapacityShown = true;
                                    Say(job.Index, StepState.Waiting, NativeAdmissionMessage());
                                }
                                continue;
                            }
                        }
                        ulong margin = mt4Adaptive != null ? 256UL : 0UL;
                        if (windows)
                        {
                            ulong observedPeak; lock (peaks) observedPeak = peaks.Count == 0 ? 0 : (ulong)peaks.Max();
                            reservation = StartBudget.TryAcquire(Checks.TotalRamMb, Checks.FreeRamMb, rc.Kind, observedPeak, margin);
                            if (reservation == null)
                            {
                                // MT5/mixed batches may retain warm terminals in other worker slots. Preserve their
                                // bounded retry path instead of waiting for those slots to close here.
                                if (jobs.Any(j => j.Copy.Kind == Kind.MT5))
                                    return TransientFail(Lang.T("حافظهٔ کافی برای گزارش‌خوان بعدی نیست", "Insufficient memory for another reporter"), Lang.T("حافظهٔ لازم برای گزارش‌خوان‌های در حال اجرا رزرو شده است؛ این حساب بعد از سایر حساب‌ها دوباره بررسی می‌شود.", "Memory is reserved for reporters already starting or running; this account will be retried after the others."));
                                pause("RAM reserved for active reporters; waiting without consuming a retry"); continue;
                            }
                        }
                        int waited = Pacer.Turn();
                        if (waited > 0) Log.Write("report: " + rc.Name + " waited " + waited + " ms after the last start");
                        if (windows && rc.Kind == Kind.MT4 && !StartBudget.CanHonor(Checks.TotalRamMb, Checks.FreeRamMb, margin)) { pause("free RAM changed during startup pacing"); continue; }
                        if (ending || stop) throw new OperationCanceledException();
                        break;
                    }
                }
                finally { if (resourcePaused && diagnostics != null) diagnostics.Timing(job, "capacity-wait", capacityClock.ElapsedMilliseconds, "native launch admission pause including final pacing; account retry not consumed"); }
                if (resourcePaused) Say(job.Index, StepState.Starting, Lang.T("منابع آماده شد؛ باز کردن گزارش‌خوان…", "Resources available; opening the reporter…"));
                started = DateTime.Now;
                try
                {
                    p = Process.Start(TerminalProcessPolicy.Prepare(new ProcessStartInfo(rc.Exe, Launcher.Arguments(rc.Kind, startFile))
                    {
                        WorkingDirectory = rc.Dir, UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden,
                    }, settings));
                    if (p != null && reservation != null) reservation.Attach(p);
                }
                catch (Exception e)
                {
                    if (reservation != null) reservation.Dispose();
                    Launcher.DeleteStartFile(startFile);
                    return Fail(Lang.T("متاتریدر گزارش باز نشد", "The report MetaTrader did not open"), Lang.T("متاتریدر گزارش باز نشد: ", "The report MetaTrader did not open: ") + e.Message);
                }
                if (p == null) { if (reservation != null) reservation.Dispose(); Launcher.DeleteStartFile(startFile); return Fail(Lang.T("متاتریدر گزارش باز نشد", "The report MetaTrader did not open"), Lang.T("متاتریدر گزارش باز نشد.", "The report MetaTrader did not open.")); }
                Owned.Add(p, rc.Exe);
                lock (live) live.Add(p);
                if (ending) { try { TerminalCloseAudit.Record(p,Processes.PathOf(p),"report-helper-force");p.Kill(); } catch { } }
                Native.HideWindowsOf(p.Id);
            }
            finally
            {
                if (gate) Monitor.Exit(Mt4Gate);
                if (p == null) { if (reservation != null) reservation.Dispose(); Launcher.DeleteStartFile(startFile); }
            }
            if (settings.LowPriority)
            {
                try { p.PriorityClass = ProcessPriorityClass.BelowNormal; } catch { }
            }
            Log.Write("report: started " + rc.Name + " for account " + acc.Login);

            var pending = new PendingStart { Path = startFile, Time = started, Process = p, Copy = rc };
            bool reading = false, updating = false, loaded = false, chartTimeout = false;
            long peak = 0;
            string lastProblem = null, step = null;
            DateTime lastLook = DateTime.MinValue, lastStep = started;
            DateTime lastStartupDisplay = DateTime.MinValue;
            DateTime? connectedAt = null;
            var mt5Startup = new Mt5StartupWatch(false, job.Attempt > 1);
            var mt4Wait = new Mt4ReportWaitPolicy(job.Attempt == 1);
            string lastMt4Phase = null; long mt4ConnectedAt = -1;
            var nativeClock = Stopwatch.StartNew(); long reporterStartedAt = -1; string lastPulsePhase = null;
            bool nativeTimingRecorded = false;
            try
            {
                while (true)
                {
                    DateTime now = DateTime.Now;
                    if (pending != null && pending.Ready(now) != null)
                    {
                        Launcher.DeleteStartFile(startFile);
                        Log.Write("start file of " + rc.Name + " deleted after " + (now - started).TotalSeconds.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture) + " s");
                        pending = null;
                    }
                    Outcome read = ReadOutput(output, acc, FromOf(job), token);
                    if (read != null)
                    {
                        if (read.Journal != null)
                        {
                            if (rc.Kind == Kind.MT5)
                            {
                                mt5Charts.Remember(acc.Server, symbol);
                                string ignored; mt5StalledCharts.TryRemove(job.Copy.Name, out ignored);
                                if (diagnostics != null) diagnostics.Timing(job, reporterStartedAt < 0 ? "reporter-start" : "history", nativeClock.ElapsedMilliseconds - Math.Max(0, reporterStartedAt), "cold result received; valid request-matched report");
                                nativeTimingRecorded = true;
                            }
                            commit(read);
                            // MT5's native expert serves durable requests regardless of the preset's
                            // ServeMode flag. A successful recovery may keep this very process warm.
                            if (rc.Kind == Kind.MT5 && warmRecovery.ColdSuccess(WarmKey(slot, rc.Dir)) && CanWarm(slot, rc) && !HasExited(p))
                            { warm[slot] = new WarmTerminal { Copy = rc, Process = p, Login = new ReportLoginSession(settings), Server = acc.Server.Trim() }; keep = true; }
                        }
                        return read;
                    }
                    if (ending) return Fail(Lang.T("متوقف شد", "Stopped"), Lang.T("به درخواست شما متوقف شد.", "Stopped at your request."));
                    if (rc.Kind == Kind.MT5 && step == null && (now - lastStartupDisplay).TotalSeconds >= 1)
                    {
                        lastStartupDisplay = now;
                        Say(job.Index, StepState.Starting,
                            (connectedAt.HasValue ? Lang.T("MT5 متصل است؛ منتظر شروع گزارش‌خوان", "MT5 connected; waiting for the reporter") : Lang.T("MT5 اجرا شد؛ منتظر اتصال و شروع گزارش‌خوان", "MT5 launched; waiting for connection and reporter"))
                            + " — " + Fa.N((int)(now - started).TotalSeconds) + Lang.T(" ثانیه", " s"));
                    }
                    // Where the script is: shown in the progress window, and the wait goes on while it moves.
                    string now1 = TextFiles.ReadText(stepFile);
                    if (now1 != null && now1.Trim().Length > 0 && now1.Trim() != step)
                    {
                        step = now1.Trim();
                        Log.Write("report native step: " + job.Copy.Name + " " + step + " at " + (job.Clock == null ? 0 : job.Clock.ElapsedMilliseconds) + "ms");
                        lastStep = now;
                        reading = true;
                        string said = ReportLaunch.StepText(step);
                        if (said != null) Say(job.Index, StepState.Reading, said);
                    }
                    if (rc.Kind == Kind.MT5 && step != null && (now - lastStartupDisplay).TotalSeconds >= 1)
                    {
                        lastStartupDisplay = now;
                        string detail = ReportLaunch.StepText(step);
                        if (detail != null) Say(job.Index, StepState.Reading, detail + " — " + Fa.N((int)(now - lastStep).TotalSeconds) + Lang.T(" ثانیه", " s"));
                    }
                    if (rc.Kind == Kind.MT5)
                    {
                        Mt5ReporterPulse pulse = Mt5ReporterPulse.TryParse(TextFiles.ReadText(output + ".pulse"), token, acc);
                        mt5Startup.Pulse(pulse, nativeClock.ElapsedMilliseconds);
                        if (pulse != null && pulse.Stage != lastPulsePhase) { lastPulsePhase = pulse.Stage; if (mt5Startup.ReporterStarted) lastStep = now; }
                        if (mt5Startup.ReporterStarted && reporterStartedAt < 0)
                        {
                            reporterStartedAt = nativeClock.ElapsedMilliseconds;
                            if (diagnostics != null) diagnostics.Timing(job, "reporter-start", reporterStartedAt, "cold native reporter acknowledged current request");
                        }
                    }
                    if (rc.Kind == Kind.MT4)
                    {
                        Mt4ReportState state = Mt4ReportState.Read(rc, token, acc);
                        mt4Wait.Observe(state, nativeClock.ElapsedMilliseconds);
                        if (state != null && state.Stage != lastMt4Phase)
                        {
                            lastMt4Phase = state.Stage;
                            if (diagnostics != null) diagnostics.Stage(job, "mt4-state", "phase=" + state.Stage + "; connected=" + state.Connected
                                + "; actualLogin=" + state.ActualLogin + "; actualServer=" + state.ActualServer);
                            if (state.HistoryStarted) lastStep = now;
                        }
                        if (mt4Wait.HistoryObserved && mt4ConnectedAt < 0)
                        {
                            mt4ConnectedAt = nativeClock.ElapsedMilliseconds;
                            if (diagnostics != null) diagnostics.Timing(job, "mt4-connection", mt4ConnectedAt, "current request reached connected/history state");
                        }
                        if (mt4Wait.ShouldRequestDeferral(nativeClock.ElapsedMilliseconds))
                        {
                            // Native code rechecks the connection before acknowledging this request.
                            // The observation alone never permits killing history work or accepting a report.
                            try
                            {
                                Mt4ReportState.WriteDeferralRequest(rc, token, acc);
                                mt4Wait.DeferralRequested();
                                if (diagnostics != null) diagnostics.Stage(job, "mt4-defer-requested", "first-pass connection wait; awaiting native acknowledgement");
                            }
                            catch (IOException e) { Log.Write("MT4 defer marker: " + e.Message); }
                            catch (UnauthorizedAccessException e) { Log.Write("MT4 defer marker: " + e.Message); }
                        }
                    }
                    bool exited = HasExited(p);
                    if ((now - lastLook).TotalSeconds >= 1.5 || exited)
                    {
                        lastLook = now;
                        if (!exited) { peak = Math.Max(peak, Native.PeakMb(p)); Native.HideWindowsOf(p.Id); }
                        List<string> lines = ConnectionCheck.JournalTail(rc, started);
                        if (SelfUpdate.InLines(lines)) updating = true;
                        LoginResult login = ConnectionCheck.FromJournal(lines, acc.Login.Trim());
                        if (login.State == Login.WrongLogin)
                            return Fail(Lang.T("ورود نشد: رمز ورود یا شماره حساب اشتباه", "Login failed: wrong login password or account number"), Lang.T("ورود نشد: شماره حساب یا رمز ورود اشتباه است.", "Login failed: the account number or login password is wrong."));
                        if (login.State == Login.NoServer)
                            return Fail(Lang.T("سرور پیدا نشد", "Server not found"), Lang.T("سرور «", "Server “") + acc.Server + Lang.T("» در متاتریدر گزارش پیدا نشد.", "” was not found in the report MetaTrader."));
                        if (login.State == Login.NoConnection) lastProblem = Lang.T("اتصال به سرور برقرار نشد", "Could not connect to the server");
                        if (login.State == Login.Connected) { lastProblem = null; if (connectedAt == null) connectedAt = now; }
                        if (login.State == Login.Connected && !reading)
                        {
                            reading = true;
                            Say(job.Index, StepState.Reading, null);
                        }
                        if (rc.Kind == Kind.MT5)
                        {
                            if (!mt5Startup.ReporterStarted) ObserveMt5Network(mt5Startup, lines, acc, nativeClock.ElapsedMilliseconds);
                            if (!loaded) loaded = lines.Any(ReportTrace.ScriptLoaded);
                            if (!chartTimeout) chartTimeout = lines.Any(ReportTrace.ChartTimeout);
                        }
                    }
                    if (exited)
                    {
                        // MT5 closes itself as soon as the script ends: the file may have come with the close.
                        read = ReadOutput(output, acc, FromOf(job), token);
                        if (read != null) { if (read.Journal != null) commit(read); return read; }
                        if (updating)
                        {
                            FollowRestart(rc);
                            return new Outcome { Retry = true, Short = Lang.T("متاتریدر گزارش برای به‌روزرسانی بسته شد", "The report MetaTrader closed to update itself"), Long = Lang.T("متاتریدر گزارش برای به‌روزرسانی خودش بسته شد؛ گزارش را دوباره بگیرید.", "The report MetaTrader closed to update itself; read the report again.") };
                        }
                        string why = ReportTrace.Explain(rc, started, symbol, step == null);
                        return TransientFail(Lang.T("متاتریدر گزارش زودتر بسته شد", "The report MetaTrader closed too early"), Lang.T("متاتریدر گزارش پیش از نوشتن تاریخچه بسته شد", "The report MetaTrader closed before writing the history") + (lastProblem != null ? " (" + lastProblem + ")" : "") + (why != null ? ". " + why : "") + ".");
                    }
                    // MT5 loads the script with its chart and starts it once the chart's symbol is ready. A symbol the broker does not
                    // have is never ready, and MT5 keeps the script waiting for minutes: try another of the broker's symbols instead.
                    if (rc.Kind == Kind.MT5 && !mt5Startup.ReporterStarted && (loaded && chartTimeout || mt5Startup.Expired(nativeClock.ElapsedMilliseconds)))
                    {
                        if (loaded && step == null && !string.IsNullOrEmpty(symbol)) mt5StalledCharts[job.Copy.Name] = symbol;
                        if (diagnostics != null) diagnostics.Timing(job, "reporter-start", nativeClock.ElapsedMilliseconds, "bounded startup wait exhausted; no fresh report accepted");
                        nativeTimingRecorded = true;
                        string why = ReportTrace.Explain(rc, started, symbol, true);
                        return Mt5StartupFailure(step == "ready", chartTimeout, symbol, connectedAt.HasValue, (int)(nativeClock.ElapsedMilliseconds / 1000), why);
                    }
                    if (rc.Kind == Kind.MT4 && lastMt4Phase == null && (ReportLaunch.HeldOnChart(rc.Kind, step, loaded, chartTimeout, connectedAt, now) || (step == null && connectedAt.HasValue && (now - connectedAt.Value).TotalSeconds >= 10)))
                    {
                        string why = ReportTrace.Explain(rc, started, symbol, true);
                        // No startup acknowledgement does not prove that a broker lacks the symbol.
                        // Rotate charts only with an explicit native synchronization-timeout record.
                        if (rc.Kind == Kind.MT5) return Mt5StartupFailure(false, chartTimeout, symbol, connectedAt.HasValue, (int)(now - started).TotalSeconds, why);
                        Log.Write("report: " + rc.Name + " kept the script waiting on its " + symbol + " chart" + (chartTimeout ? " (symbol synchronization timeout)" : "") +
                                  "; the broker may not have this symbol");
                        return new Outcome
                        {
                            WrongSymbol = symbol, Transient = true,
                            Short = Lang.T("نماد ", "Symbol ") + symbol + Lang.T(" در این بروکر نبود", " was not available at this broker"),
                            Long = Lang.T("متاتریدر ۵ اسکریپت گزارش را روی چارت ", "MetaTrader 5 kept the report script on the chart of ") + symbol + Lang.T(" نگه داشت و اجرا نکرد", " kept it and did not run it") + (why != null ? ": " + why : "") + ".",
                        };
                    }
                    if (rc.Kind == Kind.MT4 && lastMt4Phase == null && step == null && (now - started).TotalSeconds >= ReportLaunch.StartSeconds)
                    {
                        string why = ReportTrace.Explain(rc, started, symbol, true);
                        return TransientFail(lastProblem ?? Lang.T("اسکریپت گزارش شروع نشد", "The report script did not start"),
                                    Lang.T("اسکریپت گزارش در ", "The report script was not placed in ") + Fa.N(ReportLaunch.StartSeconds) + Lang.T(" ثانیه شروع نشد", " seconds and did not start") + (lastProblem != null ? " (" + lastProblem + ")" : "") + (why != null ? ". " + why : "") + ".");
                    }
                    if ((step != null || rc.Kind == Kind.MT4 && lastMt4Phase != null || rc.Kind == Kind.MT5 && mt5Startup.ReporterStarted) && ((now - lastStep).TotalSeconds >= ReportLaunch.StallSeconds || (now - started).TotalSeconds >= ReportLaunch.MaxSeconds))
                    {
                        string why = ReportTrace.Explain(rc, started, symbol, false);
                        string at = ReportLaunch.StepText(step) ?? step ?? lastPulsePhase ?? lastMt4Phase ?? Lang.T("دریافت نتیجه", "Receiving result");
                        return TransientFail(Lang.T("اسکریپت گزارش ماند: ", "The report script got stuck: ") + at.TrimEnd('…'),
                                    Lang.T("اسکریپت گزارش در این مرحله ماند و تمام نشد: ", "The report script stopped at this step and did not finish: ") + at.TrimEnd('…') + (why != null ? ". " + why : "") + ".");
                    }
                    Thread.Sleep(500);
                }
            }
            finally
            {
                if (rc.Kind == Kind.MT4 && diagnostics != null)
                    diagnostics.Timing(job, mt4ConnectedAt < 0 ? "mt4-connection" : "mt4-history", nativeClock.ElapsedMilliseconds - Math.Max(0, mt4ConnectedAt), "native MT4 observation ended");
                if (rc.Kind == Kind.MT5 && !nativeTimingRecorded && diagnostics != null)
                    diagnostics.Timing(job, reporterStartedAt < 0 ? "reporter-start" : "history", nativeClock.ElapsedMilliseconds - Math.Max(0, reporterStartedAt), "cold native observation ended");
                if (diagnostics != null) diagnostics.Capture(job, rc, started, keep ? "resident-live" : "cold-before-close", token);
                Launcher.DeleteStartFile(startFile);
                peak = Math.Max(peak, Native.PeakMb(p));
                job.PeakMb = Math.Max(job.PeakMb, peak);
                if (!keep)
                {
                    using (diagnostics == null ? null : diagnostics.Measure(job, "close")) End(p, rc);
                    if (diagnostics != null) diagnostics.Capture(job, rc, started, "cold-after-close", token);
                    lock (live) live.Remove(p); if (p != null) p.Dispose();
                }
                if (peak > 0)
                {
                    Log.Write("report: " + rc.Name + " held at most " + peak + " MB of memory");
                    lock (peaks) peaks.Add(peak);
                }
            }
        }

        static bool CurrentFullHistoryReporter(AccountJournal journal)
        {
            return journal != null && (journal.Platform == "MT4" && journal.ScriptVersion == "1.23"
                || journal.Platform == "MT5" && (journal.ScriptVersion == "1.25" || journal.ScriptVersion == "1.26"));
        }
        static Outcome FullHistoryNotConfirmed()
        {
            return new Outcome { Code = "history-full-unconfirmed", Transient = true,
                Short = Lang.T("تاریخچهٔ کامل حساب تأیید نشد", "Full account history was not confirmed"),
                Long = Lang.T("گزارش تازه پذیرفته نشد؛ تاریخچهٔ کامل تغییرات بالانس ناقص است یا با بالانس فعلی تطبیق ندارد. این مورد قابل تلاش دوباره است؛ مقدار ناقص به‌عنوان گزارش تازه ثبت نمی‌شود.",
                    "No fresh report was accepted: the full balance history is missing, incomplete or does not reconcile with the current balance. This can be retried; incomplete values are never recorded as a fresh report.") };
        }

        /// <summary>The script's file, once it is there: the history, or why there is none. Null while it is not there yet.</summary>
        public static Outcome ReadOutput(string path, Account acc, DateTime from, string expectedToken = null)
        {
            if (!File.Exists(path)) return null;
            string text = TextFiles.ReadText(path);
            if (text == null) return null;
            if (expectedToken != null && !text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None).Contains("Q\t" + expectedToken)) return null;
            string err = JournalFile.ErrorOf(text);
            if (err == "mt4 connection deferred")
                return new Outcome { Code = "mt4-connection-deferred", Transient = true,
                    Short = Lang.T("اتصال MT4 به نوبت بازیابی موکول شد", "MT4 connection deferred to recovery"),
                    Long = Lang.T("گزارش‌خوان تأیید کرد که هنوز منتظر اتصال است؛ پس از سایر حساب‌ها یک بار با مهلت کامل تلاش می‌شود.", "The native reporter confirmed it was still waiting for connection; one full-budget retry follows the other accounts.") };
            if (err == "mt4 connection not confirmed" || err == "mt4 account not matched" || err == "mt4 server not matched")
                return new Outcome { Code = err == "mt4 account not matched" ? "mt4-account-mismatch" : err == "mt4 server not matched" ? "mt4-server-mismatch" : "mt4-connection-unconfirmed", Transient = true,
                    Short = Lang.T("اتصال به حساب درخواستی MT4 تأیید نشد", "Requested MT4 account connection was not confirmed"),
                    Long = err == "mt4 account not matched" ? Lang.T("شمارهٔ حساب داخل متاتریدر با حساب درخواستی مطابقت ندارد؛ گزارش تازه ثبت نشد.", "The terminal's actual account does not match the requested account; no fresh report was accepted.")
                        : err == "mt4 server not matched" ? Lang.T("سرور داخل متاتریدر با سرور درخواستی مطابقت ندارد؛ گزارش تازه ثبت نشد.", "The terminal's actual server does not match the requested server; no fresh report was accepted.")
                        : Lang.T("متاتریدر در مهلت اتصال، ورود به حساب درخواستی را تأیید نکرد. این پیام به‌تنهایی به معنای اشتباه بودن رمز نیست.", "MetaTrader did not confirm the requested login within the connection budget. This alone does not identify an incorrect password.") };
            if (err != null && (err.StartsWith("history read failed ", StringComparison.Ordinal) || err == "history not stable" || err == "history connection lost"))
                return new Outcome { Code = err == "history not stable" ? "mt5-history-not-stable" : err == "history connection lost" ? "mt5-history-connection-lost" : "mt5-history-read-failed", Transient = true,
                    Short = Lang.T("دریافت تاریخچهٔ حساب کامل نشد", "Account history retrieval did not complete"),
                    Long = Lang.T("گزارش تازه ثبت نشد؛ متاتریدر نتوانست تاریخچهٔ معتبر و پایدار تحویل دهد: ", "No fresh report was accepted; MetaTrader could not provide a valid, stable history: ") + err };
            if (err != null)
                return err == "not connected" ? TransientFail(Lang.T("به حساب وصل نشد", "Did not connect to the account"), Lang.T("متاتریدر گزارش به حساب وصل نشد (اینترنت، سرور یا رمز ورود را بررسی کنید).", "The report MetaTrader did not connect to the account (check the internet, the server or the login password)."))
                                              : Fail(Lang.T("خطای اسکریپت", "Script error"), Lang.T("اسکریپت گزارش: ", "Report script: ") + err);
            AccountJournal j = JournalFile.Parse(text);
            if (j == null || !j.Complete)
            {
                if (expectedToken != null && CurrentFullHistoryReporter(j) && j.FullHistoryPresent) return FullHistoryNotConfirmed();
                return Fail(Lang.T("فایل تاریخچه ناقص بود", "The history file was incomplete"), Lang.T("فایل تاریخچه‌ای که اسکریپت نوشت ناقص بود.", "The history file the script wrote was incomplete."));
            }
            if (j.Login != acc.Login.Trim()) return Fail(Lang.T("حساب دیگری خوانده شد", "Another account was read"), Lang.T("متاتریدر گزارش حساب ", "The report MetaTrader read account ") + j.Login + Lang.T(" را خواند، نه ", ", not ") + acc.Login.Trim() + ".");
            if (expectedToken != null && (j.RequestToken != expectedToken || !string.Equals(j.Server.Trim(), acc.Server.Trim(), StringComparison.OrdinalIgnoreCase) || !CurrentFullHistoryReporter(j) || ((acc.Platform == "MT4" || acc.Platform == "MT5") && j.Platform != acc.Platform) || !j.FloatingDisabled))
                return Fail(Lang.T("گزارش تازه تطبیق نداشت", "Fresh report did not match"), Lang.T("سرور یا نسخهٔ گزارش با درخواست مطابقت ندارد؛ گزارش ثبت نشد.", "The server or reporter version did not match the request; no report was accepted."));
            if (expectedToken != null && (!j.FullHistoryPresent || !j.FullHistoryValid)) return FullHistoryNotConfirmed();
            // Without its inputs the script reads the last seven days only: that must not pass for the whole range.
            if (j.From > from.AddHours(12))
                return Fail(Lang.T("تاریخ شروع به اسکریپت نرسید", "The start date did not reach the script"), Lang.T("متاتریدر گزارش تاریخ شروع بازه را از فایل پارامترهای اسکریپت (Presets) نخواند و تاریخچه از ", "The report MetaTrader did not read the range's start date from the script's parameter file (Presets) and read the history from ") + Gd.Date(j.From) + Lang.T(" خوانده شد؛ این را گزارش دهید.", "; please report this."));
            return new Outcome { Journal = j };
        }

        static bool HasExited(Process p)
        {
            try { p.Refresh(); return p.HasExited; } catch { return true; }
        }

        static bool WaitExit(Process p, int seconds)
        {
            try { return p.HasExited || (seconds > 0 && p.WaitForExit(seconds * 1000)); } catch { return true; }
        }

        /// <summary>Closes a report MetaTrader this run started (3.19): MT5 closes itself when the script ends; one still open has each
        /// of its windows asked to close for one second, and is then ended. Only a process in this run's own list.</summary>
        void End(Process p, Instance rc)
        {
            if (p == null || WaitExit(p, 0)) return;
            SafeClose.Result r = SafeClose.Close(new ProcessTarget(p), pid => { lock (live) return live.Any(x => { try { return x.Id == pid; } catch { return false; } }); },
                                                 1, Log.Write);
            Log.Write("report: " + rc.Name + (r == SafeClose.Result.Closed ? " closed" : r == SafeClose.Result.Ended ? " ended (it did not close in 1 s)" : " end: " + r));
        }

        /// <summary>3.21.2: a report copy is the program's own MetaTrader for reading (under _MTManager\report), never a student's copy
        /// or an installed MetaTrader.</summary>
        public static bool IsReportCopy(Instance rc)
        {
            if (rc == null || string.IsNullOrEmpty(rc.Dir)) return false;
            string sep = Path.DirectorySeparatorChar.ToString();
            string dir = rc.Dir.Replace('/', Path.DirectorySeparatorChar).Replace('\\', Path.DirectorySeparatorChar);
            return dir.IndexOf(sep + "_MTManager" + sep + "report" + sep, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        /// <summary>A report copy still open before a read is closed (its windows asked to close, SafeClose.GraceSeconds, then ended).
        /// 3.21.2: also when this program did not start it itself: MetaTrader restarts itself after its own update, and that run was
        /// left open and stopped every later read of the account ("متاتریدر گزارش باز است"). Only a report copy is ever closed this
        /// way. False when it is still open afterwards.</summary>
        static bool EndLeftover(Instance rc)
        {
            string key = rc.Exe.ToLowerInvariant();
            Dictionary<string, Process> running = Processes.Running();
                try
                {
            Process p;
            if (!running.TryGetValue(key, out p)) return true;
            if (!IsReportCopy(rc)) return false;
            bool ours = Owned.Mine(running).Contains(key);
            int id;
            try { id = p.Id; } catch { return true; }
            SafeClose.Result r = SafeClose.Close(new ProcessTarget(p), pid => pid == id, 1, Log.Write);
            Log.Write("report: " + rc.Name + ", left open " + (ours ? "by an earlier run" : "(not started by this program: MetaTrader's own update or by hand)") + ": " + r);
            for (int k = 0; k < 10; k++)
            {
                if (!Processes.IsRunningNow(rc.Exe)) return true;
                Thread.Sleep(500);
            }
            return false;
                }finally{foreach(var process in running.Values)process.Dispose();}
        }

        /// <summary>After MetaTrader's own update it starts the terminal again, without the script: that run is ended too.</summary>
        static void FollowRestart(Instance rc)
        {
            string key = rc.Exe.ToLowerInvariant();
            for (int k = 0; k < 40; k++)
            {
                Dictionary<string, Process> running = Processes.Running();
                try
                {
                Process p;
                if (running.TryGetValue(key, out p))
                {
                    Thread.Sleep(5000);
                    foreach(var old in running.Values)old.Dispose();
                    running = Processes.Running();
                    // The run MetaTrader started after its update is not one this program started, but it is a report copy: closed too.
                    if (running.TryGetValue(key, out p) && IsReportCopy(rc))
                    {
                        int id = -1;
                        try { id = p.Id; } catch { }
                        SafeClose.Result r = SafeClose.Close(new ProcessTarget(p), pid => pid == id, 1, Log.Write);
                        Log.Write("report: " + rc.Name + " updated itself; its new run: " + r + ", starting it again");
                    }
                    return;
                }
                }finally{foreach(var process in running.Values)process.Dispose();}
                Thread.Sleep(1000);
            }
        }

        bool WaitForMt4Room(ReportJob job)
        {
            for (int k = 0; k < 120 && !ending; k++)
            {
                if (Mt4Limit.Room(SandboxLaunch.AdmissionMt4Count(settings), SandboxLaunch.ReportLimit(settings))) return true;
                if (k == 0) Say(job.Index, StepState.Starting, Lang.T("در انتظار جای خالی MT4…", "Waiting for a free MT4 place…"));
                Thread.Sleep(1000);
            }
            return false;
        }

        /// <summary>The symbol of the report copy's chart (one the broker has), for the script's chart.</summary>
        static string SymbolOf(Instance rc)
        {
            try
            {
                string dir = ChartProfile.DefaultDir(rc);
                if (!Directory.Exists(dir)) return null;
                string chart = Directory.GetFiles(dir, "*.chr").OrderBy(f => f, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
                return chart == null ? null : ReportLaunch.ChartSymbol(TextFiles.ReadText(chart));
            }
            catch { return null; }
        }
    }

    // ================================================================== what the report copy's own logs tell

    /// <summary>The report copy's journal (logs) and its programs' log (MQL5\Logs, MQL4\Logs): the lines about the script, to say why
    /// a read did not work, and for «بررسی سیستم». They hold account numbers but never passwords; nothing is sent anywhere.</summary>
    public static class ReportTrace
    {
        public static string ProgramsLog(Instance rc, DateTime day)
        {
            return Path.Combine(rc.Dir, Kinds.Mql(rc.Kind), "Logs", day.ToString("yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture) + ".log");
        }

        static bool Relevant(string line)
        {
            string l = line.ToLowerInvariant();
            return l.Contains("mtmanagerreport") || l.Contains("script") || l.Contains("error") || l.Contains("failed") || l.Contains("cannot") ||
                   l.Contains("not found") || l.Contains("unknown symbol") || l.Contains("authoriz") || l.Contains("connection") || l.Contains("synchroniz");
        }

        static bool Ours(string l) { return l.IndexOf("MTManagerReport", StringComparison.OrdinalIgnoreCase) >= 0; }

        /// <summary>MT5 put the script on its chart ("script MTManagerReport (EURUSD,M1) loaded successfully"): it starts once the
        /// chart's symbol is ready.</summary>
        public static bool ScriptLoaded(string l) { return Ours(l) && l.IndexOf("loaded successfully", StringComparison.OrdinalIgnoreCase) >= 0; }

        /// <summary>MT5 gave up waiting for the chart's symbol ("symbol synchronization timeout").</summary>
        public static bool ChartTimeout(string l) { return l.IndexOf("synchronization timeout", StringComparison.OrdinalIgnoreCase) >= 0; }

        /// <summary>The lines about the script and the login since a time, newest last; at most max.</summary>
        public static List<string> Lines(Instance rc, DateTime since, int max = 24)
        {
            var all = new List<string>();
            if (rc.Kind != Kind.MT5)
                try { all.AddRange(ConnectionCheck.JournalSince(rc, since).Where(Relevant).Select(l => "journal  " + l.Trim())); } catch { }
            for (DateTime day = since.Date; day <= DateTime.Now.Date; day = day.AddDays(1))
            {
                if (rc.Kind == Kind.MT5)
                {
                    all.AddRange(ReportDiagnostics.Tail(ConnectionCheck.JournalFile(rc, day), day, since).Where(Relevant).Select(l => "journal  " + l.Trim()));
                    all.AddRange(ReportDiagnostics.Tail(ProgramsLog(rc, day), day, since).Where(Relevant).Select(l => "programs " + l.Trim()));
                    continue;
                }
                string text = TextFiles.ReadText(ProgramsLog(rc, day));
                if (text == null) continue;
                all.AddRange(ConnectionCheck.After(text.Split('\n'), day == since.Date ? since.TimeOfDay.Subtract(TimeSpan.FromSeconds(2)) : TimeSpan.Zero)
                    .Where(Relevant).Select(l => "programs " + l.Trim()));
            }
            return all.Count <= max ? all : all.Skip(all.Count - max).ToList();
        }

        /// <summary>What the lines say, in a few words; null when they say nothing useful. Every line is also written to the program's log.</summary>
        public static string Explain(Instance rc, DateTime since, string symbol, bool neverStarted)
        {
            List<string> lines = Lines(rc, since);
            foreach (string l in lines) Log.Write("report trace " + rc.Name + ": " + TextUtil.OneLine(l));
            return Explain(lines, symbol, neverStarted);
        }

        public static string Explain(List<string> lines, string symbol, bool neverStarted)
        {
            string chart = symbol ?? "EURUSD";
            if (lines.Any(ChartTimeout))
                return Lang.T("نماد چارت (", "The chart symbol (") + chart + Lang.T(") در این بروکر آماده نشد (symbol synchronization timeout)", ") was not ready at this broker (symbol synchronization timeout)");
            string bad = lines.LastOrDefault(l => Ours(l) && new[] { "cannot", "failed", "error", "removed", "not found", "invalid" }.Any(w => l.ToLowerInvariant().Contains(w)));
            if (bad != null) return Lang.T("متاتریدر گفت: ", "MetaTrader said: ") + Tail(bad);
            if (!string.IsNullOrEmpty(symbol) && lines.Any(l => l.IndexOf(symbol, StringComparison.OrdinalIgnoreCase) >= 0 && l.ToLowerInvariant().Contains("not found")))
                return Lang.T("نماد چارت (", "The chart symbol (") + symbol + Lang.T(") در این بروکر پیدا نشد", ") was not found at this broker");
            if (!neverStarted) return null;
            if (!lines.Any(Ours))
                return Lang.T("در بخش بررسی‌شدهٔ ژورنال هیچ نشانی از شروع گزارش‌خوان نیست؛ چارت: ", "The inspected journal excerpt has no evidence that the reporter started; chart: ") + chart;
            if (lines.Any(ScriptLoaded))
                return Lang.T("گزارش‌خوان روی چارت ", "The reporter was loaded on chart ") + chart + Lang.T(" بارگذاری شد، اما شروع اجرای آن تأیید نشده است؛ علت از این پیام مشخص نیست.", ", but execution was not confirmed; this message does not identify the cause.");
            return Lang.T("آخرین پیام متاتریدر درباره‌ی اسکریپت: ", "MetaTrader's last message about the script: ") + Tail(lines.Last(Ours));
        }

        static string Tail(string line)
        {
            string t = TextUtil.OneLine(line);
            int k = t.IndexOf("MTManagerReport", StringComparison.OrdinalIgnoreCase);
            if (k > 0) t = t.Substring(k);
            return t.Length <= 140 ? t : t.Substring(0, 140) + "…";
        }

        /// <summary>For «بررسی سیستم»: each report copy, its script and the lines of today; the program's own report lines.</summary>
        public static string Summary(Settings s)
        {
            var sb = new StringBuilder();
            sb.AppendLine().AppendLine(Lang.T("— گزارش معاملات —", "— Trade report —"));
            foreach (Kind k in new[] { Kind.MT5, Kind.MT4 })
                sb.AppendLine(Lang.T("اسکریپت ", "Script ") + k + ": " + (File.Exists(ReportScript.Built(s, k)) ? (ReportScript.Ready(s, k) ? Lang.T("ساخته شده", "built") : Lang.T("ساخته شده ولی قدیمی", "built but old")) : Lang.T("هنوز ساخته نشده", "not built yet")));
            string root = ReportLaunch.ReportRoot(s.BaseDir);
            if (Directory.Exists(root))
                foreach (string d in Directory.GetDirectories(root))
                {
                    Kind? kind = Kinds.Detect(d);
                    if (kind == null) continue;
                    var rc = new Instance { Name = Path.GetFileName(d), Kind = kind.Value, Dir = d };
                    List<string> known = ReportLaunch.KnownSymbols(rc);
                    sb.AppendLine(rc.Name + ": " + (File.Exists(ReportScript.Target(rc)) ? Lang.T("فایل گزارش‌خوان موجود است: ", "reporter binary exists: ") : Lang.T("فایل گزارش‌خوان موجود نیست: ", "reporter binary is missing: ")) + ReportScript.Target(rc) +
                                  ", " + known.Count + Lang.T(" نماد شناخته‌شده", " known symbols") + (known.Count > 0 ? " (" + string.Join(", ", known.Take(6)) + (known.Count > 6 ? ", …" : "") + ")" : ""));
                    foreach (string l in Lines(rc, DateTime.Today, 15)) sb.AppendLine("  " + TextUtil.OneLine(l));
                }
            string log = TextFiles.ReadText(AppPaths.LogFile);
            if (log != null)
            {
                List<string> mine = log.Split('\n').Select(l => l.TrimEnd('\r')).Where(l => l.Contains("report")).ToList();
                sb.AppendLine(Lang.T("آخرین خط‌های گزارش در log برنامه:", "The last report lines in the program's log:"));
                foreach (string l in mine.Skip(Math.Max(0, mine.Count - 30))) sb.AppendLine("  " + l);
            }
            return sb.ToString();
        }
    }
}
