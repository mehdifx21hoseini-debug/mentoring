using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace MTManager
{
    // No admission limit and no polling on the launch path. These are observations, not global USER quotas.
    public static class GuiResourceSafety
    {
        static DateTime nextSample, nextNotice, nextRecord;
        static readonly object gate = new object();
        public static string EmergencyPath { get { return Path.Combine(AppPaths.DataDir, "emergency-system-check.txt"); } }
        [DllImport("user32.dll", SetLastError=true)] static extern uint GetGuiResources(IntPtr process, uint flags);
        public static bool IsResourceError(Exception error)
        {
            for (var e=error;e!=null;e=e.InnerException)
            {
                if(e is OutOfMemoryException)return true;
                var win=e as Win32Exception;
                if(win!=null && (win.NativeErrorCode==8 || win.NativeErrorCode==14 || win.NativeErrorCode==1450 ||
                    win.NativeErrorCode==1453 || win.NativeErrorCode==1455 || win.NativeErrorCode==1816 ||
                    (win.Message??"").IndexOf("creating window handle",StringComparison.OrdinalIgnoreCase)>=0))return true;
            }
            return false;
        }
        public static string Counters()
        {
            try
            {
                using(var p=Process.GetCurrentProcess())
                {
                    string gui="USER/GDI unavailable on this platform";
                    if(Environment.OSVersion.Platform==PlatformID.Win32NT)
                        gui="user="+GetGuiResources(p.Handle,1)+" gdi="+GetGuiResources(p.Handle,0);
                    return "MetaFactory pid="+p.Id+" handles="+p.HandleCount+" "+gui+" private-bytes="+p.PrivateMemorySize64;
                }
            }
            catch(Exception e){return "MetaFactory counters unavailable: "+e.GetType().Name;}
        }
        public static string ErrorCodes(Exception error)
        {
            string text="";
            for(var e=error;e!=null;e=e.InnerException)
            {
                var win=e as Win32Exception;
                text+=e.GetType().FullName+" hresult=0x"+e.HResult.ToString("X8",CultureInfo.InvariantCulture)+
                    (win==null?"":" native-code="+win.NativeErrorCode)+"\r\n";
            }
            return text;
        }
        public static void Observe()
        {
            if(DateTime.UtcNow<nextSample)return;
            nextSample=DateTime.UtcNow.AddSeconds(30);
            Log.Write("GUI resource sample: "+Counters());
        }
        // One bounded, overwritten file: no new Form, clipboard, process launch or background report terminal.
        public static string SaveEmergency(string text)
        {
            lock(gate)
            {
                Directory.CreateDirectory(AppPaths.DataDir);
                string body="MetaFactory "+AppInfo.Version+" · "+DateTime.UtcNow.ToString("u")+"\r\n"+Counters()+"\r\n"+(text??"");
                if(body.Length>131072)body=body.Substring(0,131072)+"\r\n[truncated]";
                File.WriteAllText(EmergencyPath,body,System.Text.Encoding.UTF8);
                return EmergencyPath;
            }
        }
        public static void Record(Exception error)
        {
            lock(gate)
            {
                if(DateTime.UtcNow<nextRecord)return;nextRecord=DateTime.UtcNow.AddSeconds(5);
                try
                {
                    string evidence=ErrorCodes(error)+Counters()+"\r\n"+error.StackTrace;
                    Log.Write("GUI resource failure: "+evidence);
                    string previous="";
                    if(File.Exists(EmergencyPath) && new FileInfo(EmergencyPath).Length<=262144 && DateTime.UtcNow-File.GetLastWriteTimeUtc(EmergencyPath)<TimeSpan.FromMinutes(2))previous=File.ReadAllText(EmergencyPath);
                    SaveEmergency(evidence+"\r\n"+previous);
                }
                catch(Exception e){Log.Write("emergency diagnostics unavailable: "+e.GetType().Name);}
            }
        }
        public static bool AllowNotice()
        {
            lock(gate){if(DateTime.UtcNow<nextNotice)return false;nextNotice=DateTime.UtcNow.AddSeconds(30);return true;}
        }
    }

    public static class SafeClipboard
    {
        // Bounded retries for another app temporarily holding the clipboard; never log its contents.
        public static bool TryCopy(string text, Action<string> write)
        {
            for(int attempt=0;attempt<3;attempt++)
            {
                try{write(text);return true;}
                catch(ExternalException){if(attempt<2)Thread.Sleep(50);}
            }
            return false;
        }
        public static void Copy(string text)
        {
            if(!TryCopy(text, value=>Clipboard.SetDataObject(value,true)))
                throw new UserMessage(Lang.T("حافظهٔ کپی مشغول است؛ دوباره کپی را بزنید.","The clipboard is busy; please try Copy again."));
        }
    }
}
