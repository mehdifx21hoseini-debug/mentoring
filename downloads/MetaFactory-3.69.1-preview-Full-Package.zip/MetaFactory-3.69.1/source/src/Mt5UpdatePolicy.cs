using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Diagnostics;
using System.Collections.Generic;
using System.Security.Cryptography;
namespace MTManager
{
    // Reversible current-user cache barrier. No elevation, executable patching, UAC or network policy changes.
    public static class Mt5UpdatePolicy
    {
        const string Magic="MetaFactory-MT5-Update-Pause-1\n";
        const string Magic2="MetaFactory-MT5-Update-Pause-2\n",BackupName="liveupdate.MetaFactory-backup",PendingPrefix="liveupdate.MetaFactory-pending-";
        sealed class Record {public string Backup;public string Text;}
        static readonly object gate=new object();
        static readonly Dictionary<string,FileStream> held=new Dictionary<string,FileStream>(StringComparer.OrdinalIgnoreCase);
        public static string CacheKey(string fullDirectory)
        {
            string canonical=fullDirectory.TrimEnd('\\','/').ToUpperInvariant();
            using(var hash=MD5.Create())return BitConverter.ToString(hash.ComputeHash(Encoding.Unicode.GetBytes(canonical))).Replace("-","");
        }
        static string Folder(string root,string key)
        {
            if(!System.Text.RegularExpressions.Regex.IsMatch(key??"",@"\A[0-9A-F]{32}\z"))throw new ArgumentException("Invalid cache identity.");
            string folder=Path.Combine(Path.GetFullPath(root),key);
            if(Directory.Exists(root) && (File.GetAttributes(root)&FileAttributes.ReparsePoint)!=0)throw new IOException("Cache root is a link.");
            if(Directory.Exists(folder) && (File.GetAttributes(folder)&FileAttributes.ReparsePoint)!=0)throw new IOException("Cache folder is a link.");
            return folder;
        }
        static bool Linked(string path){return (File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0;}
        static bool BackupSafe(string name)
        {return name==BackupName||System.Text.RegularExpressions.Regex.IsMatch(name??"",@"\Aliveupdate\.MetaFactory-backup-[0-9a-f]{32}\z");}
        static Record ReadRecord(string path,string key)
        {
            if(!File.Exists(path)||Linked(path)||new FileInfo(path).Length>256)return null;
            string text;using(var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite))using(var reader=new StreamReader(stream,Encoding.ASCII))text=reader.ReadToEnd();
            if(text==Magic+key+"\n")return new Record{Backup=BackupName,Text=text};
            string prefix=Magic2+key+"\n";if(!text.StartsWith(prefix,StringComparison.Ordinal)||!text.EndsWith("\n",StringComparison.Ordinal))return null;
            string name=text.Substring(prefix.Length,text.Length-prefix.Length-1);
            return BackupSafe(name)?new Record{Backup=name,Text=text}:null;
        }
        static string BackupPath(string folder,Record record)
        {
            string path=Path.Combine(folder,record.Backup);
            if(File.Exists(path)||Directory.Exists(path)){if(Linked(path)||!Directory.Exists(path))throw new IOException("Preserved update cache is not an ordinary directory; nothing changed.");}
            return path;
        }
        // The flushed temporary marker is also a bounded, key-bound move journal. Publishing it is atomic.
        static void RecoverPending(string folder,string marker,string key)
        {
            var pending=Directory.EnumerateFileSystemEntries(folder,PendingPrefix+"*").Take(17).ToArray();
            if(pending.Length==0)return;
            if(pending.Length!=1)throw new IOException("Multiple pending update-cache moves require review; nothing changed.");
            string path=pending[0];
            if(!System.Text.RegularExpressions.Regex.IsMatch(Path.GetFileName(path),@"\Aliveupdate\.MetaFactory-pending-[0-9a-f]{32}\z"))throw new IOException("Unknown pending update-cache file; nothing changed.");
            var record=ReadRecord(path,key);if(record==null)throw new IOException("Pending update-cache move is not owned by MetaFactory; nothing changed.");
            string backup=BackupPath(folder,record);bool live=File.Exists(marker)||Directory.Exists(marker),saved=Directory.Exists(backup);
            if(!live&&saved){File.Move(path,marker);return;} // Move finished; publish its already-flushed marker.
            if(Directory.Exists(marker)&&!Linked(marker)&&!saved){File.Delete(path);return;} // Move never occurred.
            throw new IOException("Pending update-cache state is ambiguous; all files preserved.");
        }
        public static void HoldAt(string root,string key)
        {
            lock(gate)
            {
                string folder=Folder(root,key),marker=Path.Combine(folder,"liveupdate");
                if(held.ContainsKey(marker))return;
                Directory.CreateDirectory(folder);RecoverPending(folder,marker,key);
                FileStream stream=null;string backup=null,pending=null,content=null;bool moved=false,published=false;
                try
                {
                    if(Directory.Exists(marker))
                    {
                        if(Linked(marker))throw new IOException("Update directory is a link.");
                        string name=BackupName;
                        // Preserve a pre-existing backup in place. Only the current updater directory is moved.
                        if(Directory.Exists(Path.Combine(folder,name))||File.Exists(Path.Combine(folder,name)))name=BackupName+"-"+Guid.NewGuid().ToString("N");
                        backup=Path.Combine(folder,name);if(Directory.Exists(backup)||File.Exists(backup))throw new IOException("Unique update-cache destination already exists; nothing changed.");
                        content=name==BackupName?Magic+key+"\n":Magic2+key+"\n"+name+"\n";
                        pending=Path.Combine(folder,PendingPrefix+Guid.NewGuid().ToString("N"));
                        using(var journal=new FileStream(pending,FileMode.CreateNew,FileAccess.Write,FileShare.None)){byte[] bytes=Encoding.ASCII.GetBytes(content);journal.Write(bytes,0,bytes.Length);journal.Flush(true);}
                        Directory.Move(marker,backup);moved=true;
                        File.Move(pending,marker);published=true;pending=null;
                    }
                    if(File.Exists(marker))
                    {
                        if(ReadRecord(marker,key)==null)throw new IOException("Existing liveupdate file is not owned by MetaFactory.");
                        stream=new FileStream(marker,FileMode.Open,FileAccess.Read,FileShare.Read);
                    }
                    else
                    {
                        stream=new FileStream(marker,FileMode.CreateNew,FileAccess.ReadWrite,FileShare.Read);published=true;content=Magic+key+"\n";
                        byte[] bytes=Encoding.ASCII.GetBytes(content);stream.Write(bytes,0,bytes.Length);stream.Flush(true);
                    }
                    held.Add(marker,stream);stream=null;
                }
                catch
                {
                    if(stream!=null)stream.Dispose();
                    if(published)try{var record=ReadRecord(marker,key);if(record!=null&&record.Text==content)File.Delete(marker);}catch{}
                    if(moved&&!File.Exists(marker)&&!Directory.Exists(marker))try{Directory.Move(backup,marker);moved=false;}catch{}
                    if(pending!=null&&!moved)try{var record=ReadRecord(pending,key);if(record!=null&&record.Text==content)File.Delete(pending);}catch{}
                    throw;
                }
            }
        }
        public static bool RestoreAt(string root,string key)
        {
            lock(gate)
            {
                string folder=Folder(root,key),marker=Path.Combine(folder,"liveupdate");
                FileStream stream;if(held.TryGetValue(marker,out stream)){held.Remove(marker);stream.Dispose();}
                if(Directory.Exists(folder))RecoverPending(folder,marker,key);
                var record=ReadRecord(marker,key);if(record==null)return false;
                string backup=BackupPath(folder,record);
                if(record.Backup!=BackupName&&!Directory.Exists(backup))throw new IOException("Current preserved update cache is missing; owned marker retained.");
                if(!Directory.Exists(backup)){File.Delete(marker);return true;}
                string pending=Path.Combine(folder,PendingPrefix+Guid.NewGuid().ToString("N"));
                File.Move(marker,pending); // Retain the owned record until restoration has completed.
                try
                {
                    Directory.Move(backup,marker);
                    var journal=ReadRecord(pending,key);if(journal!=null&&journal.Text==record.Text)File.Delete(pending);
                    return true;
                }
                catch
                {
                    if(!File.Exists(marker)&&!Directory.Exists(marker))try{File.Move(pending,marker);}catch{}
                    throw;
                }
            }
        }
        public static void ReleaseHandles()
        {
            lock(gate){foreach(var stream in held.Values)stream.Dispose();held.Clear();}
        }
        public static void RestoreAll()
        {
            string[] markers;lock(gate)markers=held.Keys.ToArray();
            foreach(string marker in markers)try{var directory=Directory.GetParent(marker);RestoreAt(directory.Parent.FullName,directory.Name);}catch(Exception e){Log.Write("MT5 update pause restore: "+e.GetType().Name);}
        }
        public static string Summary(){lock(gate)return "update-cache barriers held="+held.Count+"; per-copy current-user cache only; no UAC approval or global update disable";}
        public static void Apply(Instance copy,Settings settings)
        {
            if(copy.Kind!=Kind.MT5 || !System.Text.RegularExpressions.Regex.IsMatch(copy.Name??"",@"\AMT5-[0-9]+\z") || Environment.OSVersion.Platform!=PlatformID.Win32NT)return;
            string root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"MetaQuotes","Terminal"),key=CacheKey(Path.GetFullPath(copy.Dir));
            if(!settings.PauseMt5Updates){RestoreAt(root,key);return;}
            // Do not invalidate an already pending consent/update. Existing installed copies are checked closed by Launcher.
            var consent=Process.GetProcessesByName("consent");bool pending=consent.Length>0;foreach(var process in consent)process.Dispose();
            if(pending)throw new UserMessage(Lang.T("ابتدا پنجرهٔ تأیید ویندوز را ببندید و دوباره اجرا کنید؛ فایل به‌روزرسانیِ در حال تأیید تغییر نکرد.","Close the pending Windows consent dialog, then Run again; the pending updater was not changed."));
            try
            {
                HoldAt(root,key);
                Log.Write("MT5 automatic updates paused for "+copy.Name+"; own cache="+key+"; original update directory preserved; no UAC or executable changes");
            }
            catch(Exception error)
            {
                Log.Write("MT5 update pause failed for "+copy.Name+": "+error.GetType().Name+" "+error.Message);
                throw new UserMessage(Lang.T("توقف به‌روزرسانی این نسخه ممکن نشد. در تنظیمات، «اجرای MT5 بدون به‌روزرسانی خودکار» را خاموش کنید تا با رفتار قبلی اجرا شود. ","Cannot pause updates for this copy. Disable 'Run MT5 without automatic updates' in Settings to use the previous launch behavior. ")+error.GetType().Name);
            }
        }
    }
}
