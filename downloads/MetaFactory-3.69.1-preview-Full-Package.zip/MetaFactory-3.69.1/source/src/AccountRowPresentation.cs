using System;using System.Globalization;using System.Linq;
namespace MTManager
{
    internal static class AccountRowPresentation
    {
        static bool Finite(double n){return !double.IsNaN(n)&&!double.IsInfinity(n);}
        static string Number(double n){return double.IsNaN(n)||n<0?"—":double.IsPositiveInfinity(n)?"∞":Finite(n)?n.ToString("0.00",CultureInfo.InvariantCulture):"—";}
        internal static bool Bound(Instance copy,Account account,AccountJournal journal)
        {return copy!=null&&account!=null&&account.HasLogin&&journal!=null&&journal.Complete&&journal.Platform==copy.Kind.ToString()&&journal.Login==(account.Login??"").Trim()&&string.Equals(journal.Server,(account.Server??"").Trim(),StringComparison.OrdinalIgnoreCase);}
        internal static DateTime UtcTrade(DateTime trade,AccountJournal journal)
        {if(trade==DateTime.MinValue||!journal.GmtOffset.HasValue||Math.Abs((long)journal.GmtOffset.Value)>18*3600)return DateTime.MinValue;try{return DateTime.SpecifyKind(trade.AddSeconds(-journal.GmtOffset.Value),DateTimeKind.Utc);}catch(ArgumentOutOfRangeException){return DateTime.MinValue;}}
        internal static void Apply(CopyRow row,Instance copy,Account account,AccountJournal journal,PanelView view,DateTime readAt)
        {
            row.AccountBalance="Balance —";row.AccountDrawdown="Maximum DD —";row.AccountInfoTip=Lang.T("گزارش معتبر در دسترس نیست.","No verified report available.");row.TradeOpen=false;row.LastTradeUtc=DateTime.MinValue;
            if(!Bound(copy,account,journal))return;
            if(Finite(journal.Balance))row.AccountBalance="Balance "+PanelMath.Amount(journal.Balance,journal.Currency);
            bool full=Finite(journal.Balance)&&journal.HistoryChecked&&journal.HistoryOk&&journal.FullHistoryPresent&&journal.FullHistoryValid&&journal.FullHistoryReconciled&&journal.FullHistoryScanOk&&view!=null&&view.ReadAt==journal.Exported;
            double dd=full&&view!=null&&view.AccountDdComplete&&Finite(view.AccountDdPct)&&view.AccountDdPct>=0?view.AccountDdPct:double.NaN;
            if(!double.IsNaN(dd))row.AccountDrawdown="Maximum DD "+dd.ToString("0.00",CultureInfo.InvariantCulture)+"%";
            string factor=full&&(copy.Kind==Kind.MT4||journal.AccountPfPresent&&journal.AccountPfValid)?Number(view.ProfitFactor):"—";
            bool history=journal.HistoryChecked&&journal.HistoryOk;
            if(history)
            {
                row.TradeOpen=journal.Open.Count>0;
                DateTime recent=journal.Trades.Select(t=>t.Close).Where(t=>t<=journal.Exported).DefaultIfEmpty(DateTime.MinValue).Max();
                if(journal.LastTrade<=journal.Exported&&journal.LastTrade>recent)recent=journal.LastTrade;
                if(row.TradeOpen){var opened=journal.Open.Select(t=>t.Open).Where(t=>t<=journal.Exported).DefaultIfEmpty(DateTime.MinValue).Max();if(opened>recent)recent=opened;}
                row.LastTradeUtc=UtcTrade(recent,journal);
            }
            row.AccountInfoTip=Lang.T("بالانس: ","Balance: ")+(Finite(journal.Balance)?PanelMath.Amount(journal.Balance,journal.Currency):"—")+"\r\n"+Lang.T("حداکثر دراودان حساب: ","Maximum account DD: ")+(double.IsNaN(dd)?"—":dd.ToString("0.00",CultureInfo.InvariantCulture)+"%")+"\r\n"+Lang.T("پروفیت فاکتور کل: ","Overall profit factor: ")+factor+"\r\n"+Lang.T("معاملات باز در گزارش: ","Open positions in report: ")+(history?Fa.N(journal.Open.Count):"—")+"\r\n"+Lang.T("زمان گزارش: ","Report time: ")+(readAt==DateTime.MinValue?"—":readAt.ToString("yyyy-MM-dd HH:mm",CultureInfo.InvariantCulture));
            if(!double.IsNaN(dd))row.AccountInfoTip+="\r\n"+Lang.T("افت نسبی بالانس؛ کل تاریخچهٔ تأییدشده","Relative balance drawdown; verified whole history");
        }
        // A fresh position heartbeat is independent of the full-history proof.
        // Never invent closed results or reuse old history as current while this proof is pending.
        internal static bool ApplyPendingLive(CopyRow row,Instance copy,Account account,LiveFeedSnapshot feed,DateTime utc)
        {
            if(copy==null||account==null||feed==null||!feed.IsLive||feed.Platform!=copy.Kind.ToString()||feed.Login!=(account.Login??"").Trim()||
                !string.Equals(feed.Server,(account.Server??"").Trim(),StringComparison.OrdinalIgnoreCase)||utc<feed.HeartbeatUtc.AddSeconds(-5)||utc>feed.HeartbeatUtc.AddSeconds(LiveFeedReader.StaleSeconds))return false;
            row.TodayLive=true;row.TodayClosedCount=null;row.TodayOpenCount=feed.Positions.Count;row.TradeOpen=feed.Positions.Count>0;
            double floating=feed.Positions.Sum(p=>p.Profit+p.Swap+(feed.Platform=="MT4"?p.Commission:0));
            row.TodayText=DailySummary(floating,feed.Currency,null,row.TodayOpenCount);row.TodayNone=false;row.TodayHasTrades=feed.Positions.Count>0;
            row.TodayNet=null; // The complete daily total remains unknown.
            row.TodayAgo=Lang.T("زنده · همگام‌سازی · ","Live · syncing · ")+Fa.N(Math.Max(0,(int)(utc-feed.HeartbeatUtc).TotalSeconds))+Lang.T("ث","s");
            row.TodayTip=Lang.T("دریافت زنده فعال است. عدد بالا فقط سود/زیان شناور معاملات باز است؛ نتیجه و تعداد کل معاملات امروز تا تأیید تاریخچه نامشخص می‌ماند.",
                "Live reception is active. The amount above is only floating P/L of open positions; today's complete result and trade count remain unknown until history is verified.")
                +"\r\n"+Lang.T("آخرین دریافت: ","Last received: ")+feed.HeartbeatUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss",CultureInfo.InvariantCulture)
                +"\r\n"+Lang.T("وضعیت تاریخچه: ","History status: ")+feed.NativeState+" · "+feed.Reason;
            if(Finite(feed.Balance))row.AccountBalance="Balance "+PanelMath.Amount(feed.Balance,feed.Currency);
            row.AccountInfoTip=Lang.T("بالانس زنده: ","Live balance: ")+PanelMath.Amount(feed.Balance,feed.Currency)+"\r\n"+
                Lang.T("دراودان زیر، در صورت وجود، مربوط به آخرین تاریخچهٔ تأییدشده است؛ هنوز با دادهٔ زنده تطبیق داده نشده است.",
                    "Drawdown below, if available, belongs to the last verified history; it has not yet been reconciled with the live snapshot.")+"\r\n"+row.AccountInfoTip;
            return true;
        }
        internal static void ApplyOpenStops(CopyRow row,Instance copy,Account account,AccountJournal journal,LiveFeedSnapshot feed,bool pendingLive,DateTime utc)
        {
            row.TodayNoSl=false;row.TodayOpenNoSlCount=null;row.TodayOpenSlUnknownCount=null;
            double[] stops;
            if(pendingLive)
            {
                if(copy==null||account==null||feed==null||!feed.IsLive||feed.Platform!=copy.Kind.ToString()||feed.Login!=(account.Login??"").Trim()||
                    !string.Equals(feed.Server,(account.Server??"").Trim(),StringComparison.OrdinalIgnoreCase)||utc<feed.HeartbeatUtc.AddSeconds(-5)||utc>feed.HeartbeatUtc.AddSeconds(LiveFeedReader.StaleSeconds))return;
                stops=feed.Positions.Select(p=>p.Sl).ToArray();
            }
            else
            {
                if(!Bound(copy,account,journal)||journal.Exported==DateTime.MinValue)return;
                stops=journal.Open.Select(p=>p.CurrentSlKnown==true?p.Sl:double.NaN).ToArray();
            }
            int unknown=stops.Count(sl=>!Finite(sl)||sl<0),missing=stops.Count(sl=>Finite(sl)&&sl==0);
            row.TodayOpenSlUnknownCount=unknown;row.TodayOpenNoSlCount=missing>0||unknown==0?(int?)missing:null;
            row.TodayNoSl=missing>0;
        }
        internal static string OpenStopTip(CopyRow row)
        {
            if(!row.TodayOpenNoSlCount.HasValue&&!row.TodayOpenSlUnknownCount.HasValue)return "";
            return Lang.T("حد ضرر فعلی معاملات باز در همین داده: ","Current stops of open positions in this data: ")+
                Lang.T("بدون SL: ","No SL: ")+(row.TodayOpenNoSlCount.HasValue?Fa.N(row.TodayOpenNoSlCount.Value):"—")+
                (row.TodayOpenSlUnknownCount.GetValueOrDefault()>0?" · "+Lang.T("نامشخص: ","Unknown: ")+Fa.N(row.TodayOpenSlUnknownCount.Value):"")+"\r\n"+
                Lang.T("بر اساس زمان دادهٔ نمایش‌داده‌شده؛ حد ضرر زمان ورود یا معاملات بسته‌شده ملاک نیست.","As of the displayed data time; entry stops and closed trades are not used.");
        }
        internal static string TradeCounts(int? closed,int? open)
        {return Lang.T("بسته: ","Closed: ")+(closed.HasValue?Fa.N(closed.Value):"—")+" · "+Lang.T("باز: ","Open: ")+(open.HasValue?Fa.N(open.Value):"—");}
        internal static string DailySummary(double? net,string currency,int? closed,int? open)
        {
            string money=net.HasValue&&Finite(net.Value)?PanelMath.Money(net.Value,currency):"—";
            string count=closed.HasValue&&open.HasValue?Fa.N(closed.Value+open.Value):"—";
            string text=money+" · "+count+Lang.T(" معامله"," trades");
            if(open.GetValueOrDefault()>0)text+=" · Open: "+Fa.N(open.Value);
            return text;
        }
        internal static string ClosedToday(PanelView view)
        {if(view==null||!Finite(view.ClosedNet))return "—";return view.Closed==0?Lang.T("بدون معاملهٔ بسته","No closed trades"):PanelMath.Money(view.ClosedNet,view.Currency)+" · "+Fa.N(view.Closed)+Lang.T(" معامله"," trades");}
    }
}
