using System;using System.Collections.Generic;using System.Diagnostics;using System.IO;using System.Linq;using System.Runtime.InteropServices;using System.Text;using System.Threading;
namespace MTManager
{
    public sealed class VerificationBusyException:IOException {public VerificationBusyException(string message):base(message){}}
    public interface IRecoveringAccountVerifier {void Recover(Func<bool> cancel);}
    // Exclusive, bounded disposable workspaces. Never opens, adopts or closes a student copy.
    public sealed class VerifierWorkspace:IDisposable
    {
        public const int Banks=3,MaximumCaches=4;
        readonly FileStream reservation;readonly object gate=new object();
        public readonly string Root,Run=Guid.NewGuid().ToString("N");
        readonly List<Owned.Entry> owned=new List<Owned.Entry>();
        VerifierWorkspace(string root,FileStream lease){Root=root;reservation=lease;ReadOwned();}
        static bool Inside(string root,string path)
        {try{return Path.GetFullPath(path).StartsWith(Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase);}catch{return false;}}
        static void NoLinks(string path)
        {
            for(string p=Path.GetFullPath(path);!string.IsNullOrEmpty(p);p=Path.GetDirectoryName(p))
                if((Directory.Exists(p)||File.Exists(p))&&(File.GetAttributes(p)&FileAttributes.ReparsePoint)!=0)throw new VerificationBusyException("مسیر ابزار بررسی پیوند دارد؛ برای حفظ فایل‌ها استفاده نشد.");
        }
        public static IDisposable Admit(Settings settings,Func<bool> cancel,int limit=0)
        {
            int count=limit>0?Math.Min(2,limit):VerificationParallel.Auto(Environment.ProcessorCount,Checks.TotalRamMb(),Checks.FreeRamMb());
            string root=Path.Combine(settings.BaseDir,"_MTManager","verify-pool");NoLinks(root);Directory.CreateDirectory(root);NoLinks(root);var clock=Stopwatch.StartNew();
            while(clock.ElapsedMilliseconds<10000)
            {
                if(cancel())throw new OperationCanceledException();
                for(int index=0;index<count;index++)try{string path=Path.Combine(root,"active-"+index+".lock");NoLinks(path);return new FileStream(path,FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);}catch(IOException){}
                Thread.Sleep(100);
            }
            throw new VerificationBusyException("بررسی دیگری در حال استفاده از منابع محدود است؛ دوباره تلاش کنید.");
        }
        public static VerifierWorkspace Acquire(Settings settings,int slot,Func<bool> cancel)
        {
            if(slot<1||slot>1000)throw new ArgumentOutOfRangeException("slot");
            for(int bank=0;bank<Banks;bank++)
            {
                if(cancel())throw new OperationCanceledException();
                string root=Path.Combine(settings.BaseDir,"_MTManager","verify-pool","slot-"+slot+"-"+bank);NoLinks(root);Directory.CreateDirectory(root);NoLinks(root);
                FileStream lease=null;VerifierWorkspace workspace=null;
                try
                {
                    NoLinks(Path.Combine(root,"lease.lock"));
                    lease=new FileStream(Path.Combine(root,"lease.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
                    workspace=new VerifierWorkspace(root,lease);lease=null;
                    workspace.CloseRecorded();
                    if(workspace.HasRunning())continue;
                    Log.Write("verify workspace acquired: slot="+slot+" bank="+bank+" run="+workspace.Run);var acquired=workspace;workspace=null;return acquired;
                }
                catch(IOException){}
                finally{if(workspace!=null)workspace.Dispose();if(lease!=null)lease.Dispose();}
            }
            throw new VerificationBusyException("جایگاه‌های محدود بررسی هنوز مشغول‌اند؛ پس از پایان بررسی دوباره تلاش کنید. متاتریدر دانشجو بسته نشد.");
        }
        void ReadOwned()
        {
            string file=Path.Combine(Root,"owned.txt");
            NoLinks(file);if(!File.Exists(file))return;
            if(new FileInfo(file).Length>16384)return;
            try{owned.AddRange(Owned.Parse(File.ReadAllLines(file)).Where(e=>Inside(Root,e.Exe)).Take(16));}catch(IOException){}
        }
        void SaveOwned()
        {NoLinks(Path.Combine(Root,"owned.txt"));TextUtil.WriteLinesAtomically(Path.Combine(Root,"owned.txt"),Owned.Format(owned));}
        public void Track(Process process,string path)
        {
            NoLinks(Root);NoLinks(path);
            if(!Inside(Root,path)||!string.Equals(Path.GetFullPath(Processes.PathOf(process)??""),Path.GetFullPath(path),StringComparison.OrdinalIgnoreCase))throw new VerificationBusyException("مالکیت فرایند بررسی تأیید نشد.");
            long start=Processes.StartOf(process.Id);if(start<=0)throw new VerificationBusyException("زمان شروع فرایند بررسی خوانده نشد.");
            lock(gate){owned.RemoveAll(e=>e.Pid==process.Id||Processes.StartOf(e.Pid)!=e.Start);if(owned.Count>=16)throw new VerificationBusyException("پاک‌سازی فرایندهای قبلی بررسی کامل نشده است.");owned.Add(new Owned.Entry{Pid=process.Id,Start=start,Exe=path});SaveOwned();}
        }
        public bool IsOwned(Process process)
        {
            try{long start=Processes.StartOf(process.Id);string path=Processes.PathOf(process);lock(gate)return owned.Any(e=>e.Pid==process.Id&&e.Start==start&&start>0&&Inside(Root,e.Exe)&&string.Equals(e.Exe,path,StringComparison.OrdinalIgnoreCase));}catch{return false;}
        }
        public bool CloseRecorded()
        {
            bool success=true;
            lock(gate)
            foreach(var entry in owned.ToArray())
            {
                try
                {
                    using(var process=Process.GetProcessById(entry.Pid))
                    {
                        if(process.HasExited||Processes.StartOf(entry.Pid)!=entry.Start||!string.Equals(Processes.PathOf(process),entry.Exe,StringComparison.OrdinalIgnoreCase)){owned.Remove(entry);continue;}
                        if(!Inside(Root,entry.Exe)){success=false;continue;}NoLinks(entry.Exe);
                        SafeClose.Close(new ProcessTarget(process,true),pid=>pid==entry.Pid&&IsOwned(process),1,Log.Write);
                        process.Refresh();if(process.HasExited)owned.Remove(entry);else success=false;
                    }
                }
                catch(ArgumentException){owned.Remove(entry);}catch(InvalidOperationException){owned.Remove(entry);}catch{success=false;}
            }
            try{lock(gate)SaveOwned();}catch(IOException){success=false;}
            return success;
        }
        public bool HasRunning()
        {
            var processes=Processes.Running();try{return processes.Values.Any(p=>Inside(Root,Processes.PathOf(p)??""));}finally{foreach(var process in processes.Values)process.Dispose();}
        }
        static bool Managed(string directory)
        {try{string marker=Path.Combine(directory,".mf-verify-cache");NoLinks(marker);return File.Exists(marker)&&new FileInfo(marker).Length<=64&&File.ReadAllText(marker)=="MFVERIFY1\n";}catch{return false;}}
        public void PrepareCache(string path)
        {
            NoLinks(path);if(!Inside(Root,path))throw new VerificationBusyException("مسیر بررسی خارج از جایگاه رزروشده است.");
            if(Directory.Exists(path)&&!Managed(path))throw new VerificationBusyException("پوشهٔ بررسیِ موجود مدرک مدیریت ندارد؛ فایل‌هایش حفظ شد.");
            // Bound source/server caches. Only our complete, closed, nonlinked caches are disposable.
            var directories=Directory.GetDirectories(Root).OrderBy(Directory.GetLastWriteTimeUtc).ToList();
            foreach(var directory in directories.Where(d=>!string.Equals(d,path,StringComparison.OrdinalIgnoreCase)).ToArray())
            {
                if(directories.Count<MaximumCaches)break;
                if(!Managed(directory))continue;
                if(HasRunning())throw new VerificationBusyException("نسخهٔ خصوصی هنوز در حال خروج است؛ جایگاه دیگری استفاده می‌شود.");
                try{NoLinks(directory);if(TreeLinked(directory))continue;Directory.Delete(directory,true);directories.Remove(directory);}catch(IOException){}catch(UnauthorizedAccessException){}
            }
            if(!Directory.Exists(path)&&directories.Count>=MaximumCaches)throw new VerificationBusyException("حافظهٔ نهان بررسی به سقف محدود خود رسیده؛ جایگاه آماده نیست.");
        }
        static bool TreeLinked(string directory)
        {
            foreach(string item in Directory.EnumerateFileSystemEntries(directory))
            {var attr=File.GetAttributes(item);if((attr&FileAttributes.ReparsePoint)!=0)return true;if((attr&FileAttributes.Directory)!=0&&TreeLinked(item))return true;}
            return false;
        }
        public void MarkCache(string path){NoLinks(path);if(!Inside(Root,path))throw new InvalidOperationException();NoLinks(Path.Combine(path,".mf-verify-cache"));File.WriteAllText(Path.Combine(path,".mf-verify-cache"),"MFVERIFY1\n");}
        public static bool DescendantOf(int pid,int parent)
        {
            if(pid<=0||parent<=0||pid==parent)return false;
            var map=Parents();var seen=new HashSet<int>();
            while(pid>0&&seen.Count<32&&seen.Add(pid)){int next;if(!map.TryGetValue(pid,out next))return false;if(next==parent)return true;pid=next;}return false;
        }
        static Dictionary<int,int> Parents()
        {
            var result=new Dictionary<int,int>();
            if(Environment.OSVersion.Platform!=PlatformID.Win32NT)
            {
                try{foreach(string dir in Directory.GetDirectories("/proc")){int pid;if(!int.TryParse(Path.GetFileName(dir),out pid))continue;try{string stat=File.ReadAllText(Path.Combine(dir,"stat"));var parts=stat.Substring(stat.LastIndexOf(')')+2).Split(' ');int parent;if(parts.Length>1&&int.TryParse(parts[1],out parent))result[pid]=parent;}catch{}}}catch{}return result;
            }
            IntPtr snapshot=CreateToolhelp32Snapshot(2,0);if(snapshot==new IntPtr(-1))return result;
            try{var entry=new ProcessEntry{Size=(uint)Marshal.SizeOf(typeof(ProcessEntry))};if(Process32FirstW(snapshot,ref entry))do{result[(int)entry.Pid]=(int)entry.Parent;}while(Process32NextW(snapshot,ref entry));}finally{CloseHandle(snapshot);}return result;
        }
        [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)]struct ProcessEntry{public uint Size,Usage,Pid;public UIntPtr Heap;public uint Module,Threads,Parent;public int Priority;public uint Flags;[MarshalAs(UnmanagedType.ByValTStr,SizeConst=260)]public string Exe;}
        [DllImport("kernel32.dll",SetLastError=true)]static extern IntPtr CreateToolhelp32Snapshot(uint flags,uint pid);
        [DllImport("kernel32.dll",CharSet=CharSet.Unicode,ExactSpelling=true)]static extern bool Process32FirstW(IntPtr snapshot,ref ProcessEntry entry);
        [DllImport("kernel32.dll",CharSet=CharSet.Unicode,ExactSpelling=true)]static extern bool Process32NextW(IntPtr snapshot,ref ProcessEntry entry);
        [DllImport("kernel32.dll")]static extern bool CloseHandle(IntPtr handle);
        public void Dispose(){reservation.Dispose();}
    }
}
