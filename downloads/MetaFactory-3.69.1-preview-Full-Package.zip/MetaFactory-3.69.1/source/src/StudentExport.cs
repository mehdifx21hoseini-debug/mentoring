using System;
using System.Collections.Generic;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MTManager
{
    public enum StudentExportScope { All, Selected, Folder }
    /// <summary>Export fields retain their existing format; scope is an explicit instance-name set.</summary>
    public static class StudentExport
    {
        public const string UnfiledKey="@unfiled";
        public static List<string> ScopeNames(IEnumerable<Instance> copies,AccountStore accounts,FolderStore folders,StudentExportScope scope,IEnumerable<string> selected,string folderId=null)
        {
            var all=accounts.All.Select(a=>a.Instance).Concat(copies.Select(c=>c.Name)).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(n=>n,StringComparer.OrdinalIgnoreCase);
            if(scope==StudentExportScope.All)return all.ToList();
            if(scope==StudentExportScope.Selected)
            {var allowed=new HashSet<string>(selected??new string[0],StringComparer.OrdinalIgnoreCase);return all.Where(allowed.Contains).ToList();}
            if(scope!=StudentExportScope.Folder||folderId==null)return new List<string>();
            if(folderId==UnfiledKey)return all.Where(folders.Unfiled).ToList();
            if(!folders.All.Any(f=>f.Id==folderId))return new List<string>();
            return all.Where(n=>folders.Has(folderId,n)).ToList();
        }
        public static List<string[]> Rows(IEnumerable<Instance> copies, AccountStore accounts, FolderStore folders, bool passwords)
        {return RowData(copies,accounts,folders,passwords,null);}
        public static List<string[]> Rows(IEnumerable<Instance> copies,AccountStore accounts,FolderStore folders,bool passwords,IEnumerable<string> scopeNames)
        {return RowData(copies,accounts,folders,passwords,scopeNames??new string[0]);}
        static List<string[]> RowData(IEnumerable<Instance> copies,AccountStore accounts,FolderStore folders,bool passwords,IEnumerable<string> scopeNames)
        {
            var allowed=scopeNames==null?null:new HashSet<string>(scopeNames,StringComparer.OrdinalIgnoreCase);
            var instances = copies.ToDictionary(c => c.Name, StringComparer.OrdinalIgnoreCase);
            var names = accounts.All.Select(a => a.Instance).Concat(instances.Keys).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x, StringComparer.OrdinalIgnoreCase);
            var result = new List<string[]> { new[] { "Name", "Platform", "Login", "Server", "Investor", "Folder", "Copy", "Path", "Mode", "Master", "AllFolders", "CopyAvailable", "PasswordStatus", "OriginalName" } };
            foreach (string name in names.Where(name=>allowed==null||allowed.Contains(name)))
            {
                Account a = accounts.Get(name); Instance copy;
                instances.TryGetValue(name, out copy);
                var groups = folders.All.Where(f => folders.Has(f.Id, name)).Select(f => f.Name).ToList();
                string investor = "", master = "", status = passwords ? "Not stored" : "Excluded";
                if (passwords && a != null)
                {
                    investor = Secret.Unprotect(a.InvestorEnc ?? ""); master = Secret.Unprotect(a.MasterEnc ?? "");
                    status = investor == null || master == null ? "Some passwords could not be decrypted on this Windows user" : "Included";
                }
                result.Add(new[] { a == null ? "" : a.Trader, copy != null ? copy.Kind.ToString() : name.StartsWith("MT4", StringComparison.OrdinalIgnoreCase) ? "MT4" : name.StartsWith("MT5", StringComparison.OrdinalIgnoreCase) ? "MT5" : "", a == null ? "" : a.Login, a == null ? "" : a.Server,
                    investor ?? "", groups.FirstOrDefault() ?? "", name, copy == null ? "" : copy.Dir, a == null ? "" : a.Mode, master ?? "", ImportFlow.ExportGroups(groups), copy == null || !File.Exists(copy.Exe) ? "No" : "Yes", status, a==null?"":a.OriginalTrader });
            }
            return result;
        }

        public static void Write(string path, IList<string[]> rows, bool passwords)
        {Write(path,rows,passwords,null);}
        public static void Write(string path,IList<string[]> rows,bool passwords,string scopeDescription)
        {
            Spreadsheet.Write(path, rows, new[] {
                "MetaFactory — Student directory / فهرست دانشجوها",
                scopeDescription??"This workbook contains the explicitly exported student rows. / این فایل فقط شامل دانشجوهای خروجی انتخاب‌شده است.",
                "Name, Platform, Login, Server, Investor and Folder are compatible with bulk import. AllFolders and PasswordStatus are also supported when reimporting.",
                "Folder is the first membership; AllFolders contains all memberships. Reimport merges memberships without removing old folders. Identical existing rows need no login check; changed credentials are verified before replacement.",
                "CopyAvailable means the terminal copy was found on disk. It does not mean the account was connected or the password verified.",
                "PasswordStatus identifies passwords that cannot be decrypted for this Windows user; their cells are left empty.",
                passwords ? "Passwords are readable in this workbook. Store it privately. / رمزها در این فایل خوانا هستند؛ در محل امن نگهداری کنید." : "Passwords were excluded. / رمزها در این فایل نیستند."
            });
        }
    }

    sealed class StudentExportDialog : FormDialog
    {
        readonly CheckBox passwords = new CheckBox { AutoSize = true, Checked = true, Text = Lang.T("رمزهای ذخیره‌شده هم در فایل قرار بگیرند", "Include saved passwords") };
        readonly ComboBox scope=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList};
        readonly ComboBox folderChoice=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList};
        readonly Label countLabel;
        readonly Button save;
        readonly List<Instance> copies;
        readonly AccountStore accounts;
        readonly FolderStore folders;
        readonly string[] selected;
        readonly List<string> folderIds=new List<string>();
        public bool IncludePasswords { get { return passwords.Checked; } }
        public StudentExportScope Scope {get{return (StudentExportScope)scope.SelectedIndex;}}
        public string FolderId {get{return folderChoice.SelectedIndex>=0?folderIds[folderChoice.SelectedIndex]:null;}}
        public List<string> TargetNames {get;private set;}
        public string ScopeDescription {get{return Lang.T("دامنهٔ خروجی: ","Export scope: ")+(Scope==StudentExportScope.Folder?Convert.ToString(folderChoice.SelectedItem):Convert.ToString(scope.SelectedItem));}}
        public string SuggestedFileName
        {
            get
            {
                string tag=Scope==StudentExportScope.All?"all":Scope==StudentExportScope.Selected?"selected":"folder-"+(FolderId==StudentExport.UnfiledKey?"no-folder":Convert.ToString(folderChoice.SelectedItem));
                var bad=new HashSet<char>(Path.GetInvalidFileNameChars().Concat(new[]{'\\','/',':','*','?','"','<','>','|'}));
                tag=new string(tag.Select(c=>bad.Contains(c)||char.IsControl(c)?'_':c).ToArray()).Trim(' ','.');
                if(tag.Length>70)tag=tag.Substring(0,70);
                return "MetaFactory-students-"+tag+"-"+DateTime.Now.ToString("yyyy-MM-dd")+".xlsx";
            }
        }
        public StudentExportDialog(IEnumerable<Instance> copies,AccountStore accounts,FolderStore folders,IEnumerable<string> selected,string initialFolder)
            : base(Lang.T("خروجی اکسل", "Export to Excel"), Lang.T("دانشجوهای موردنظر را برای خروجی انتخاب کنید.","Choose which students to export."))
        {
            this.copies=copies.ToList();this.accounts=accounts;this.folders=folders;this.selected=(selected??new string[0]).ToArray();
            scope.Width=folderChoice.Width=Theme.S(380);
            scope.Items.AddRange(new object[]{Lang.T("همهٔ دانشجوها","All students"),Lang.T("انتخاب‌شده‌ها","Selected students"),Lang.T("پوشهٔ دلخواه","Specific folder")});
            folderIds.Add(StudentExport.UnfiledKey);folderChoice.Items.Add(Lang.T("بدون پوشه","No folder"));
            foreach(var folder in folders.All){folderIds.Add(folder.Id);folderChoice.Items.Add(folder.Name);}
            Row(Lang.T("دامنهٔ خروجی","Export"),scope);Row(Lang.T("پوشه","Folder"),folderChoice);
            countLabel=Theme.Label("",460,Theme.Small,Theme.Muted);Wide(countLabel);
            Wide(passwords);
            Wide(Theme.Label(Lang.T("با فعال بودن این گزینه، رمزها در اکسل خوانا هستند؛ فایل را در محل امن نگه دارید.", "When enabled, passwords are readable in Excel; store the file privately."),460,Theme.Small,Theme.Muted));
            save=AddButton(Lang.T("انتخاب محل و ذخیره","Choose location and save"),(sender,e)=>AcceptScope(),true);
            var cancel=AddButton(Lang.T("انصراف","Cancel"),(sender,e)=>Close(DialogResult.Cancel));
            folderChoice.SelectedIndex=initialFolder==null?0:folderIds.IndexOf(initialFolder);
            scope.SelectedIndex=this.selected.Length>0?1:initialFolder!=null?2:0;
            scope.SelectedIndexChanged+=(sender,e)=>UpdateScope();folderChoice.SelectedIndexChanged+=(sender,e)=>UpdateScope();
            UpdateScope();Finish();AcceptButton=save;CancelButton=cancel;
        }
        void UpdateScope()
        {
            folderChoice.Enabled=Scope==StudentExportScope.Folder;
            int count=StudentExport.ScopeNames(copies,accounts,folders,Scope,selected,FolderId).Count;
            countLabel.Text=Fa.N(count)+Lang.T(" دانشجو در این خروجی"," students in this export");save.Enabled=count>0;
        }
        void AcceptScope()
        {
            var names=StudentExport.ScopeNames(copies,accounts,folders,Scope,selected,FolderId);
            if(names.Count==0){UpdateScope();return;}
            TargetNames=names;Close(DialogResult.OK);
        }
    }
}
