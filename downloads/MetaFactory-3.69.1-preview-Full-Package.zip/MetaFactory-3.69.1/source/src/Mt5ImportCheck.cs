using System;using System.Collections.Generic;using System.Globalization;using System.Linq;using System.Web.Script.Serialization;
namespace MTManager
{
    // Only the import verifier uses this protocol; report/symbol IPC keeps its existing contract.
    public sealed class Mt5ImportBudget
    {
        public readonly int Initialize,Login,Overall;
        public const int Startup=30000,Verify=10000,Shutdown=10000,Grace=2000;
        public Mt5ImportBudget(int requested,bool warm){Initialize=warm?30000:60000;Login=Math.Max(30000,Math.Min(60000,requested));Overall=Initialize+Login+60000;}
        public int PhaseMilliseconds(string phase){switch(phase){case "initialize":return Initialize;case "login":return Login;case "verify":return Verify;case "shutdown":return Shutdown;default:return Startup;}}
        public static int MaximumMilliseconds(int requested){return new Mt5ImportBudget(requested,false).Overall;}
    }
    public sealed class Mt5ImportSession
    {
        static readonly string[] phases={"startup","initialize","login","verify","shutdown"};
        readonly Account account;public readonly Mt5ImportBudget Budget;long changedAt;int packets;
        public string Phase{get;private set;}public string ResultPhase{get;private set;}public int? LastCode{get;private set;}
        public Mt5ImportSession(Account proof,int requested,bool warm){account=proof.Snapshot();Budget=new Mt5ImportBudget(requested,warm);Phase="startup";}
        static Dictionary<string,object> Read(string text)
        {if(text==null||text.Length>4096)return null;try{return new JavaScriptSerializer{MaxJsonLength=4096}.Deserialize<Dictionary<string,object>>(text);}catch{return null;}}
        static string String(Dictionary<string,object> fields,string key){object v;return fields.TryGetValue(key,out v)&&v is string?(string)v:"";}
        static int? Number(Dictionary<string,object> fields,string key){object v;int n;return fields.TryGetValue(key,out v)&&v!=null&&!(v is bool)&&int.TryParse(Convert.ToString(v,CultureInfo.InvariantCulture),NumberStyles.Integer,CultureInfo.InvariantCulture,out n)&&n>=-1000000&&n<=1000000?(int?)n:null;}
        static bool True(Dictionary<string,object> fields,string key){object v;return fields.TryGetValue(key,out v)&&v is bool&&(bool)v;}
        bool Header(Dictionary<string,object> fields){return fields!=null&&Number(fields,"protocol")==1&&account.VerifyToken.Length==32&&String(fields,"token")==account.VerifyToken;}
        public bool IsProgress(string text){var fields=Read(text);return fields!=null&&String(fields,"type")=="import-progress";}
        public bool Progress(string text,long elapsed)
        {
            var fields=Read(text);if(++packets>16||!Header(fields)||String(fields,"type")!="import-progress")return false;
            string next=String(fields,"phase");int index=Array.IndexOf(phases,next);if(index<1||index<Array.IndexOf(phases,Phase))return false;
            if(next!=Phase){Phase=next;changedAt=elapsed;}return true;
        }
        public bool Expired(long elapsed){return elapsed>Budget.Overall||elapsed-changedAt>Budget.PhaseMilliseconds(Phase)+Mt5ImportBudget.Grace;}
        public ImportConnection Result(string text)
        {
            var fields=Read(text);if(++packets>16||!Header(fields)||String(fields,"type")!="import-result")return null;
            var verified=DirectProbe.PythonReply(text,account);if(verified==null)return null;
            string state=String(fields,"state"),phase=String(fields,"phase");int? code=Number(fields,"error_code");LastCode=code;ResultPhase=phases.Contains(phase)?phase:"protocol";
            if(state=="connected")return True(fields,"acknowledged")&&True(fields,"identity_matched")&&phase=="verify"?verified:Failure("protocol",null,false);
            if(state=="rejected")return code==-6&&(phase=="initialize"||phase=="login")?new ImportConnection{State=Login.WrongLogin,Reason="MT5: سرور اطلاعات ورود را رد کرد؛ مرحلهٔ "+Label(phase)+" (کد -6)."}:Failure("protocol",code,false);
            if(state=="unavailable")return new ImportConnection{Retryable=false,Reason="MT5: رابط بررسی بارگذاری نشد؛ ویندوز ۶۴ بیتی و نصب رابط را بررسی کنید."};
            if(state!="unconfirmed"||!phases.Contains(phase))return null;
            var failure=Failure(phase,code,false);
            string actual=String(fields,"actual_server").Trim();
            if(phase=="verify"&&True(fields,"acknowledged")&&True(fields,"terminal_connected")&&
                StudentImport.Key(Kind.MT5,String(fields,"actual_login"),actual)==StudentImport.Key(Kind.MT5,account.Login,account.Server)&&
                String(fields,"actual_login").Length>0&&ImportServerPlan.LinkedEndpoint(account.Server,actual))
            {
                failure.ObservedServer=actual;failure.ObservedToken=account.VerifyToken;
                failure.Reason="MT5: نام نهایی سرور "+actual+" است؛ تأیید تازه روی همین نام لازم است.";
            }
            return failure;
        }
        public static string Label(string phase){switch(phase){case "startup":return "بارگذاری رابط";case "initialize":return "راه‌اندازی و اتصال اولیه";case "login":return "تأیید ورود";case "verify":return "تطبیق حساب و سرور";case "shutdown":return "پایان ارتباط بررسی";default:return "پاسخ رابط";}}
        public static ImportConnection Failure(string phase,int? code,bool timedOut)
        {return new ImportConnection{Reason="MT5: مرحلهٔ "+Label(phase)+(timedOut?" به پایان مهلت رسید":" کامل نشد")+(code.HasValue?" (کد "+code.Value.ToString(CultureInfo.InvariantCulture)+")":"")+"؛ اشتباه‌بودن رمز تأیید نشده است."};}
    }
}
