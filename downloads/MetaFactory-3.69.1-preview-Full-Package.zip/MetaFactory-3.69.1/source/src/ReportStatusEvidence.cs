using System;using System.Globalization;
namespace MTManager {
    public static class ReportStatusEvidence {
        public static bool Trusted(Instance copy,Account account,AccountJournal journal) {
            return AccountRowPresentation.Bound(copy,account,journal)&&journal.FullHistoryPresent&&journal.FullHistoryValid&&journal.FullHistoryReconciled&&journal.FullHistoryScanOk&&journal.HistoryChecked&&journal.HistoryOk&&journal.GmtOffset.HasValue;
        }
        public static DateTime ExportedUtc(AccountJournal journal) {
            if(journal==null||!journal.GmtOffset.HasValue||journal.Exported==DateTime.MinValue)return DateTime.MinValue;
            try{return DateTime.SpecifyKind(ServerClock.Of(journal).ToGmt(journal.Exported),DateTimeKind.Utc);}catch{return DateTime.MinValue;}
        }
        public static bool SupersedesUnconfirmed(Instance copy,Account account,AccountJournal journal) {
            // A timeout is not a credential rejection. Never hide active checks or changed-credential invalidation.
            if(account==null||account.VerifyState!="unconfirmed"||!Trusted(copy,account,journal))return false;
            DateTime failed;
            if(!DateTime.TryParse(account.VerifyUtc,CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out failed))return false;
            DateTime exported=ExportedUtc(journal);
            return exported>=failed.ToUniversalTime()&&exported<=DateTime.UtcNow.AddSeconds(30);
        }
        public static bool SupersedesFailure(Instance copy,Account account,AccountJournal journal,DateTime receivedUtc,DateTime failureUtc,string failureCredentials,DateTime from,bool transientFailure=false) {
            if(!transientFailure||failureUtc==DateTime.MinValue||account==null||failureCredentials!=account.CredentialKey||!Trusted(copy,account,journal))return false;
            if(from>DateTime.MinValue&&!JournalCache.CoversTrusted(journal,from))return false;
            DateTime exported=ExportedUtc(journal);
            return receivedUtc>=failureUtc&&exported>=failureUtc.AddSeconds(1)&&exported<=DateTime.UtcNow.AddSeconds(30);
        }
        public static bool LiveCanResolve(string code) {
            return code=="history-full-unconfirmed"||code=="mt4-connection-deferred"||code=="mt4-connection-unconfirmed"||code=="mt5-history-not-stable"||code=="mt5-history-connection-lost";
        }
        public static bool AcceptFresh(AccountStore store,Instance copy,Account requested,AccountJournal journal) {
            if(store==null||requested==null||!Trusted(copy,requested,journal))return false;
            DateTime exported=ExportedUtc(journal);
            if(exported<DateTime.UtcNow.AddMinutes(-5)||exported>DateTime.UtcNow.AddSeconds(30))return false;
            lock(store.Sync) {
                var current=store.Get(copy.Name);
                if(current==null||current.CredentialKey!=requested.CredentialKey||current.VerifyState==""||current.VerifyState=="connected")return false;
                var old=current.Snapshot();current.VerifyState="connected";current.VerifyToken="";current.VerifyUtc=exported.ToString("o",CultureInfo.InvariantCulture);
                current.VerifyReason=Lang.T("ورود با گزارش تازهٔ معتبر تأیید شد.","Login confirmed by a fresh verified report.");
                store.SetQueue(current);
                try{store.Save();return true;}catch(Exception e){store.SetQueue(old);Log.Write("report verification save: "+e.GetType().Name);return false;}
            }
        }
        public static string Detail(string text,Account account) {
            string result=text??"";
            if(account!=null)foreach(string encrypted in new[]{account.MasterEnc,account.InvestorEnc}){string password=Secret.Unprotect(encrypted);if(!string.IsNullOrEmpty(password))result=result.Replace(password,"***");}
            result=TextUtil.OneLine(result);return result.Length>1200?result.Substring(0,1200)+"…":result;
        }
    }
}
