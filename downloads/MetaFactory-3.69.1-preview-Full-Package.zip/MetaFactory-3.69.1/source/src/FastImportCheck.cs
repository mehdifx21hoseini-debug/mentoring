using System;using System.IO;using System.ComponentModel;using System.Collections.Generic;using System.Globalization;using System.Linq;
namespace MTManager
{
    // Foreground-only diagnostics. Never creates authentication proof or owns the underlying checker.
    public sealed class FastImportCheck:IAccountVerifier
    {
        readonly IAccountVerifier inner;readonly List<Login> outcomes=new List<Login>();
        public string LastStage="آماده‌سازی بررسی",LastServer="",LastMode="",RejectedServer="";
        public ImportConnection LastReply;
        public bool AllRejected{get{return outcomes.Count>0&&outcomes.All(s=>s==Login.WrongLogin);}}
        public FastImportCheck(IAccountVerifier inner){this.inner=inner;}
        public ImportConnection Verify(Account account,int milliseconds,Func<bool> cancel,Action<string> stage)
        {
            LastServer=account.Server;LastMode=account.Mode;LastReply=null;LastStage="آماده‌سازی بررسی";
            if(cancel())throw new OperationCanceledException();
            ImportConnection result;
            try{result=inner.Verify(account,milliseconds,cancel,text=>{LastStage=Clip(text);stage(text);});}
            catch(VerificationBusyException){throw;}
            catch(UserMessage error){result=new ImportConnection{Retryable=false,Reason=Clip(error.Message)};}
            catch(UnauthorizedAccessException){result=new ImportConnection{Retryable=false,Reason="دسترسی به فایل یا پوشهٔ نسخهٔ بررسی ممکن نیست؛ مجوز مسیر بررسی شود."};}
            catch(IOException){result=new ImportConnection{Retryable=false,Reason="خواندن یا نوشتن فایل‌های بررسی ناموفق بود؛ مسیر و فضای دیسک بررسی شود."};}
            catch(Win32Exception error){result=new ImportConnection{Retryable=false,Reason="ویندوز نتوانست ابزار بررسی را اجرا کند؛ کد "+error.NativeErrorCode.ToString(CultureInfo.InvariantCulture)+"."};}
            LastReply=result;if(result!=null){outcomes.Add(result.State);if(result.State==Login.WrongLogin)RejectedServer=account.Server;}
            return result;
        }
        static string Clip(string value){value=TextUtil.OneLine(value??"");return value.Length>240?value.Substring(0,240):value;}
        public static string TimeoutReason(FastImportCheck check,int milliseconds)
        {
            string result="بررسی سریع: مهلت "+(milliseconds/1000.0).ToString("0.#",CultureInfo.InvariantCulture)+" ثانیه تمام شد؛ بررسی ورود کامل نشد.";
            if(check!=null){result+=" مرحله: "+Clip(check.LastStage)+"؛ سرور: "+Clip(check.LastServer)+"؛ نوع ورود: "+Clip(check.LastMode)+".";if(check.RejectedServer.Length>0)result+=" ورود روی "+Clip(check.RejectedServer)+" رد شد؛ نتیجهٔ سایر سرورها قطعی نیست.";}
            return result;
        }
        public void Dispose(){} // The coordinator retains disposal/ownership responsibility.
    }
}
