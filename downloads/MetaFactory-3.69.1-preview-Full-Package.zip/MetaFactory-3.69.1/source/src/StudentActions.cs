using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
namespace MTManager
{
    sealed partial class MainForm
    {
        readonly ContextMenuStrip studentManagementMenu;
        ToolStripMenuItem miEditStudent,rowCloseReview,rowCloseLive,rowCloseBoth,miRowRemove;
        List<string> rowTargetNames;
        List<Instance> RowActionTargets()
        {
            if(rowTargetNames==null){var copy=RowCommandCopy();return copy==null?new List<Instance>():new List<Instance>{copy};}
            return rowTargetNames.Select(name=>copies.FirstOrDefault(copy=>copy.Name==name)).Where(copy=>copy!=null).ToList();
        }
        void EditRowTargets()
        {
            // Each student keeps their own credentials; Cancel stops the remaining individual dialogs.
            foreach(var copy in RowActionTargets())if(!EditAccountOf(copy))break;
        }
        void CopyRowValues(string which)
        {
            var targets=RowActionTargets();if(targets.Count==0)return;
            if(targets.Any(copy=>accounts.Get(copy.Name)==null||!accounts.Get(copy.Name).HasLogin))
            {Ui.Message(this,Lang.T("برای این نسخه حسابی ثبت نشده.","No account is saved for this copy."));return;}
            string text=string.Join(which=="info"?"\r\n\r\n":"\r\n",targets.Select(copy=>StudentCopyText(accounts.Get(copy.Name),which,copy.Name)));
            if(string.IsNullOrEmpty(text))return;
            SafeClipboard.Copy(text);clipboardSecret=null;clipTimer.Stop();ClearChoice();
            SetStatus(Lang.T("اطلاعات کپی شد.","Information copied."));
        }
        void SetRowCloseState(bool live,bool review)
        {rowCloseReview.Enabled=review;rowCloseLive.Enabled=live;rowCloseBoth.Enabled=live||review;miStopGroup.Enabled=live||review;}
        void CloseRowCopy(CloseCopyKind kind)
        {var targets=RowActionTargets();if(targets.Count>0)CloseCopies(targets,kind);}
        internal static string StudentCopyText(Account account,string kind,string fallback)
        {
            string name=string.IsNullOrWhiteSpace(account.Trader)?fallback:account.Trader;
            if(kind=="name")return name;if(kind=="login")return account.Login;if(kind=="server")return account.Server;
            if(kind!="info")throw new ArgumentException("Unknown account information field.");
            // General information never includes a password; existing password copy stays in Manage.
            return Lang.T("نام: ","Name: ")+name+"\r\n"+Lang.T("شماره حساب: ","Account: ")+account.Login+"\r\n"+Lang.T("سرور: ","Server: ")+account.Server;
        }
        ContextMenuStrip BuildStudentManagementMenu()
        {
            var menu=Theme.Menu();menu.ShowImageMargin=true;menu.ImageScalingSize=Theme.Sz(16,16);
            IconItem(menu.Items,Lang.T("ویرایش اطلاعات…","Edit information…"),Glyph.NoteEdit,()=>{var copy=RowCommandCopy();if(copy!=null)EditAccountOf(copy);});
            miOpen=IconItem(menu.Items,Lang.T("باز کردن متاتریدر","Open MetaTrader"),Glyph.Play,()=>{var copy=RowCommandCopy();if(copy!=null)OpenOrShow(copy);});
            miShowReview=IconItem(menu.Items,Lang.T("نمایش نسخهٔ بررسی","Show chart review"),Glyph.Window,()=>{var copy=RowCommandCopy();if(copy!=null)ShowReview(copy);});
            miReport=IconItem(menu.Items,Lang.T("به‌روزرسانی گزارش","Refresh report"),Glyph.Refresh,()=>{var copy=RowCommandCopy();if(copy!=null)ReadThese(new List<Instance>{copy},Lang.T("دانشجو","Student"));});
            miAddTo=IconItem(menu.Items,Lang.T("افزودن به پوشه","Add to folder"),Glyph.Folder,null);StyleDrop(miAddTo);
            IconItem(menu.Items,Lang.T("باز کردن پوشهٔ نسخه","Open copy folder"),Glyph.Folder,()=>{var copy=RowCommandCopy();if(copy!=null)Ui.OpenUrl(copy.Dir);});
            var passwords=IconItem(menu.Items,Lang.T("کپی رمزها","Copy passwords"),Glyph.Key,null);StyleDrop(passwords);
            miCopyInvestor=IconItem(passwords.DropDownItems,Lang.T("رمز اینوستور","Investor password"),Glyph.Key,()=>CopyValue("investor"));
            miCopyMaster=IconItem(passwords.DropDownItems,Lang.T("رمز اصلی","Master password"),Glyph.Key,()=>CopyValue("master"));
            Theme.Separator(menu);
            IconItem(menu.Items,Lang.T("بازسازی نسخهٔ گزارش…","Rebuild report copy…"),Glyph.Restore,RebuildReportCopy);
            miForce=IconItem(menu.Items,Lang.T("بستن اجباری…","Force close…"),Glyph.Stop,()=>{var copy=RowCommandCopy();if(copy!=null)Stop(new List<Instance>{copy},true);});
            miRemove=IconItem(menu.Items,Lang.T("حذف دانشجو و نسخه…","Delete student and copy…"),Glyph.Trash,()=>{var copy=RowCommandCopy();if(copy!=null)RemoveCopies(new List<Instance>{copy});},"danger");
            return menu;
        }
        void ShowStudentManagement()
        {
            var copy=copies.FirstOrDefault(i=>string.Equals(i.Name,pageName,StringComparison.OrdinalIgnoreCase));if(copy==null)return;
            rowMenu.Close();rowCommandName=copy.Name;rowTargetNames=null;
            var running=Processes.Running();bool live,review;
            try{live=Processes.IsRunning(running,copy.Exe);review=CopiesToClose(new[]{copy},CloseCopyKind.Review).Any(i=>Processes.IsRunning(running,i.Exe));}
            finally{foreach(var process in running.Values)process.Dispose();}
            miOpen.Text=live?Lang.T("نمایش متاتریدر","Show MetaTrader"):Lang.T("باز کردن متاتریدر","Open MetaTrader");
            miShowReview.Visible=review;miForce.Enabled=live||review;
            var account=accounts.Get(copy.Name);miReport.Enabled=account!=null&&account.HasLogin;
            miCopyInvestor.Enabled=account!=null&&!string.IsNullOrEmpty(Secret.Unprotect(account.InvestorEnc));
            miCopyMaster.Enabled=account!=null&&!account.IsInvestor&&!string.IsNullOrEmpty(Secret.Unprotect(account.MasterEnc));
            FillFolderItems(miAddTo,new List<Instance>{copy},false);
            ShowUnder(studentManagementMenu,pageHeader.ManagementButton);
        }
    }
}
