using System;using System.Collections.Generic;using System.Globalization;using System.IO;using System.Linq;using System.Text;using System.Text.RegularExpressions;using System.Diagnostics;
namespace MTManager
{
    public static class StudentNameLatin
    {
        static readonly Dictionary<string,string> Names=new Dictionary<string,string>(StringComparer.Ordinal){
            {"علی","Ali"},{"رضا","Reza"},{"محمد","Mohammad"},{"حسین","Hossein"},{"حسن","Hasan"},{"مهدی","Mehdi"},{"سارا","Sara"},{"زهرا","Zahra"},{"نازیلا","Nazila"},{"بردیا","Bardia"},{"ملینا","Melina"},{"شیخ","Sheikh"},{"زاده","Zadeh"},{"معالی","Maali"},{"مجلسی","Majlesi"},{"رضایی","Rezaei"},{"عبدالهی","Abdollahi"},{"عبداللهی","Abdollahi"},{"مبینا","Mobina"},{"دشتی","Dashti"},{"جاویدشریفی","Javidsharifi"},{"امیر","Amir"},{"فاطمه","Fatemeh"},{"احمد","Ahmad"},{"رنجبر","Ranjbar"},{"فرهاد","Farhad"},{"طاهره","Tahereh"},{"عزت","Ezzat"}};
        public static bool Persian(string s){return Regex.IsMatch(s??"","[\u0600-\u06ff]");}
        public static string Convert(string text)
        {
            text=TextUtil.OneLine(text??"").Replace('ي','ی').Replace('ك','ک').Replace('\u200c',' ');
            var words=new List<string>();foreach(string word in text.Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries))
            {
                string known;if(Names.TryGetValue(word,out known)){words.Add(known);continue;}if(!Persian(word)){words.Add(word);continue;}
                var b=new StringBuilder();foreach(char c in word){switch(c){case 'ا':case 'آ':b.Append("a");break;case 'ب':b.Append("b");break;case 'پ':b.Append("p");break;case 'ت':case 'ط':b.Append("t");break;case 'ث':case 'س':case 'ص':b.Append("s");break;case 'ج':b.Append("j");break;case 'چ':b.Append("ch");break;case 'ح':case 'ه':case 'ة':b.Append("h");break;case 'خ':b.Append("kh");break;case 'د':b.Append("d");break;case 'ذ':case 'ز':case 'ض':case 'ظ':b.Append("z");break;case 'ر':b.Append("r");break;case 'ژ':b.Append("zh");break;case 'ش':b.Append("sh");break;case 'ع':case 'ء':case 'ئ':case 'أ':case 'إ':b.Append("a");break;case 'غ':case 'ق':b.Append("gh");break;case 'ف':b.Append("f");break;case 'ک':b.Append("k");break;case 'گ':b.Append("g");break;case 'ل':b.Append("l");break;case 'م':b.Append("m");break;case 'ن':b.Append("n");break;case 'و':case 'ؤ':b.Append("o");break;case 'ی':case 'ى':b.Append("i");break;default:if(c<128)b.Append(c);break;}}
                string value=b.ToString();words.Add(value.Length==0?word:char.ToUpperInvariant(value[0])+value.Substring(1));
            }return string.Join(" ",words);
        }
    }
    public static class ImportServerPlan
    {
        public const int MaximumCandidates=16;
        public static string LabelText(string text){return (text??"").Replace('ي','ی').Replace('ك','ک').Replace('\u200c',' ');}
        public static string BrokerAlias(string text)
        {
            string n=ServerCatalog.Norm(LabelText(text));
            return new[]{"wm","wmmarkets","wmmarket","wmarket","wmarkets","windsor","windsore","windsorbrokers","windsorbroker","windزور","وینزور","ویندزور","ویندزوربروکر","ویندزوربروکرز","ویندزورمارکت","معتمد","محتمد","معتبر","بروکرمعتبر","بروکرمعتمد","بروکرمحتمد","بروکرمعتمدwm","بروکرمعتبرwm","بروکرمعتمدwmmarkets"}.Contains(n)?"WMMarkets":(text??"").Trim();
        }
        public static string Platform(string value)
        {string n=ServerCatalog.Norm(LabelText(value));return new[]{"4","mt4","meta4","metatrader4","متاتریدر4"}.Contains(n)?"MT4":new[]{"5","mt5","meta5","metatrader5","متاتریدر5"}.Contains(n)?"MT5":"";}
        public static string AccountType(string value)
        {string n=ServerCatalog.Norm(LabelText(value));return Regex.IsMatch(n,@"^(demo|دمو|آزمایشی)\d*$")?"demo":Regex.IsMatch(n,@"^(real|live|ریل|ریال|واقعی)\d*$")?"real":"";}
        public static bool Ambiguous(string server){return AccountType(server).Length>0||Regex.IsMatch(server??"",@"(?i)-(real|live)$");}
        public static List<string> Candidates(Kind kind,string broker,string type,IEnumerable<string> known,IEnumerable<string> preferred=null)
        {
            string key=ServerCatalog.Norm(BrokerAlias(broker));bool demo=type=="demo";
            Func<string,bool> match=s=>ServerCatalog.Norm(BrokerAlias(ServerCatalog.Broker(s)))==key&&(demo?Regex.IsMatch(s,@"(?i)-demo\s*\d*$"):Regex.IsMatch(s,@"(?i)-(real|live)\s*\d*$"));
            var available=(known??new string[0]).Where(Safe).Where(match).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(s=>{var m=Regex.Match(s,@"\d+$");int n;return m.Success&&int.TryParse(m.Value,out n)?n:0;}).ThenBy(s=>s,StringComparer.OrdinalIgnoreCase).ToList();
            // Only platform-specific defaults when no catalogue exists; never fabricate numbered alternatives.
            if(key=="wmmarkets"&&available.Count==0)available.Add(demo?(kind==Kind.MT4?"WMMarkets-DEMO":"WMMarkets-Demo"):(kind==Kind.MT4?"WMMarkets-REAL":"WMMarkets-Real1"));
            return (preferred??new string[0]).Where(s=>available.Contains(s,StringComparer.OrdinalIgnoreCase)).Concat(available).Distinct(StringComparer.OrdinalIgnoreCase).Take(MaximumCandidates).ToList();
        }
        public static void Resolve(StudentImportRow row,string broker,string type,IEnumerable<string> known,string defaultBroker="")
        {
            if(row.Platform!="MT4"&&row.Platform!="MT5")return;
            var kind=row.Platform=="MT4"?Kind.MT4:Kind.MT5;string raw=(row.Server??"").Trim();
            if(raw.Length>0&&BrokerAlias(raw)=="WMMarkets"){broker="WMMarkets";raw="";row.Server="";}
            string rawType=AccountType(raw),suffix="";var number=Regex.Match(TextUtil.LatinDigits(raw),@"\d+\s*$");
            if(rawType.Length>0){type=rawType;if(number.Success)suffix=number.Value.Trim();}
            else if(raw.Length>0)return; // A supplied complete server remains exact, including WMMarkets-REAL.
            if(raw.Length==0&&type.Length==0){if(broker.Length>0)row.InputProblem=JoinProblem(row.InputProblem,"نوع حساب Demo/Real مشخص نیست.");return;}
            if(string.IsNullOrWhiteSpace(broker))broker=defaultBroker;
            broker=BrokerAlias(broker);type=AccountType(type);
            if(string.IsNullOrWhiteSpace(broker)||type.Length==0){row.Server="";row.InputProblem=JoinProblem(row.InputProblem,"نام بروکر یا نوع حساب مشخص نیست؛ پیش‌فرض بروکر را انتخاب کنید.");return;}
            var options=Candidates(kind,broker,type,known,Remembered(kind));
            if(suffix.Length>0)
            {
                string supplied=broker+"-"+(type=="demo"?"Demo":"Real")+suffix;
                string exact=options.FirstOrDefault(s=>ServerCatalog.Norm(s)==ServerCatalog.Norm(supplied))??supplied;
                options=new[]{exact}.Concat(options).Distinct(StringComparer.OrdinalIgnoreCase).Take(MaximumCandidates).ToList();
            }
            if(options.Count==0){row.Server="";row.InputProblem=JoinProblem(row.InputProblem,"سرور کامل این بروکر پیدا نشد؛ فهرست سرورها را تازه کنید.");return;}
            row.Broker=broker;row.AccountType=type;row.Server=options[0];row.ImportServers=options.Count>1?string.Join("|",options):"";
        }
        static string JoinProblem(string a,string b){return string.IsNullOrWhiteSpace(a)?b:a+"؛ "+b;}
        public static bool Safe(string value){return !string.IsNullOrWhiteSpace(value)&&value.Length<=120&&!value.Any(c=>char.IsControl(c)||c=='|'||c=='/'||c=='\\'||c=='=');}
        static readonly object Gate=new object();
        static string HintFile{get{return Path.Combine(AppPaths.DataDir,"import-server-hints.txt");}}
        public static List<string> Remembered(Kind kind){lock(Gate){try{return File.ReadAllLines(HintFile).Where(s=>s.StartsWith(kind+"\t",StringComparison.Ordinal)).Select(s=>s.Substring(4)).Where(Safe).Take(100).ToList();}catch{return new List<string>();}}}
        public static void Remember(Kind kind,string server){if(!Safe(server))return;lock(Gate){try{var all=File.Exists(HintFile)?File.ReadAllLines(HintFile).Take(199).ToList():new List<string>();string value=kind+"\t"+server;all.RemoveAll(s=>string.Equals(s,value,StringComparison.OrdinalIgnoreCase));all.Insert(0,value);TextUtil.WriteLinesAtomically(HintFile,all);}catch{Log.Write("import server preference could not be saved");}}}
        public static ImportConnection Verify(Account job,IAccountVerifier verifier,int milliseconds,Func<bool> cancel,Action<string> stage)
        {
            var options=(job.ImportServers??"").Split('|').Where(Safe).Distinct(StringComparer.OrdinalIgnoreCase).Take(MaximumCandidates).ToList();
            if(options.Count==0)return verifier.Verify(job,milliseconds,cancel,stage);
            int perServer=Math.Max(30000,Math.Min(45000,milliseconds)),budget=Math.Min(300000,Math.Max(90000,options.Count*perServer));
            var watch=Stopwatch.StartNew();var attempts=new List<string>();
            foreach(string server in options)
            {
                if(cancel())throw new OperationCanceledException();if(watch.ElapsedMilliseconds>=budget)break;
                Account attempt=job.Snapshot();attempt.Server=server;attempt.ImportServers="";
                stage(Lang.T("بررسی سرور ","Checking server ")+server+" ("+(attempts.Count+1)+"/"+options.Count+")");ImportConnection result;
                try{result=verifier.Verify(attempt,Math.Min(perServer,(int)(budget-watch.ElapsedMilliseconds)),()=>cancel()||watch.ElapsedMilliseconds>=budget,s=>stage(server+": "+s));}
                catch(OperationCanceledException){if(cancel())throw;break;}
                catch(VerificationBusyException){throw;}
                catch(Exception error){result=new ImportConnection{Reason="بررسی این سرور کامل نشد: "+error.GetType().Name};}
                if(cancel())throw new OperationCanceledException();
                if(result!=null&&result.Connected){result.VerifiedServer=server;result.Reason=Lang.T("ورود تأیید شد؛ سرور: ","Login verified; server: ")+server;return result;}
                string detail=result==null?"":TextUtil.OneLine(result.Reason??"");if(detail.Length>240)detail=detail.Substring(0,240);
                attempts.Add(server+": "+(result!=null&&result.State==Login.WrongLogin?"ورود رد شد":"تأیید نشد")+(detail.Length>0?" ("+detail+")":""));
                if(result!=null&&!result.Retryable&&result.State!=Login.WrongLogin)break;
            }
            return new ImportConnection{Retryable=false,Reason="اتصال روی سرورهای بررسی‌شده تأیید نشد؛ اشتباه بودن رمز قطعی نیست. "+attempts.Count+"/"+options.Count+" سرور بررسی شد. "+string.Join("; ",attempts)};
        }
    }
    public static class TextStudentImport
    {
        sealed class Draft {public StudentImportRow Row=new StudentImportRow();public string Broker="",Type="",Problem="";public bool Any{get{return Row.Name.Length+Row.Login.Length+Row.Investor.Length+Row.Master.Length+Broker.Length+Row.Server.Length+Row.Platform.Length>0;}}}
        static readonly string KeyPattern=@"نام\s*بروکر|Investor\s*(?:Password|pass?\.?|پسورد)?|Read[ -]?only(?:\s*Password)?|رمز\s*عبور\s*سرمایه\s*گذار|رمز\s*اینوستور|اینوستور|Master\s*Password|Master(?=\s*[:：=])|رمز\s*مستر|مستر|Password|پسورد|رمز\s*عبور|رمز|Account\s*Type|نوع\s*حساب|Account\s*(?:Number|No\.?|Login)|Acc\.?\s*(?:Number|No\.?)|Log\s*in|Account|akant|شماره\s*(?:حساب|اکانت)|نام\s*(?:و\s*)?نام\s*خانوادگی|نام\s*و\s*نام\s*خانوادگی|نام\s*خانوادگی|Name|Full\s*Name|نام|بنده|Server(?:\s*Name)?|سرور|Broker(?:\s*Name)?|نام\s*بروکر|بروکر|Platform|پلاتفرم|پلتفرم|متاتریدر|Folder|پوشه";
        static readonly Regex Field=new Regex(@"^(?<key>"+KeyPattern+@")\s*(?:\([^:：=👉\r\n]*\)?\s*)?(?:[:：=]|👉|\s)\s*(?<value>.+)$",RegexOptions.IgnoreCase,TimeSpan.FromSeconds(1));
        static readonly Regex InlineField=new Regex(@"(?:^|[\s✅☑✔✓])(?<key>"+KeyPattern+@")\s*(?:\([^:：=👉\r\n]*\)?\s*)?(?:[:：=]|👉)\s*",RegexOptions.IgnoreCase,TimeSpan.FromSeconds(1));
        static string Digits(string s){return Regex.Replace(TextUtil.LatinDigits(s??""),@"[\s,٬]","");}
        static string Clean(string line){return Regex.Replace(line.Trim(),@"^(?:(?:[✅☑✔✓🔹🔸•])+\s*|[-*]\s+)","");}
        static bool NameLike(string text){return text.Length>0&&Regex.IsMatch(text,@"^[\p{L}\p{M} .‌'-]+$")&&!Regex.IsMatch(text,@"[0-9۰-۹٠-٩]");}
        static IEnumerable<string> Pieces(string raw)
        {
            string normal=ImportServerPlan.LabelText(raw);var fields=InlineField.Matches(normal);
            if(fields.Count<=1&&!(fields.Count==1&&fields[0].Index>0))return new[]{raw};
            var pieces=new List<string>();int first=fields[0].Index;
            if(first>0)pieces.AddRange(Regex.Split(raw.Substring(0,first),@"[\s\u00a0]{3,}").Where(s=>!string.IsNullOrWhiteSpace(s)));
            for(int i=0;i<fields.Count;i++){int start=fields[i].Groups["key"].Index,end=i+1<fields.Count?fields[i+1].Index:raw.Length;pieces.Add(raw.Substring(start,end-start));}
            return pieces;
        }
        public static List<StudentImportRow> Parse(string text,bool latin,IEnumerable<string> existing,Func<Kind,IEnumerable<string>> known=null)
        {return Parse(text,latin,existing,known,"");}
        public static List<StudentImportRow> Parse(string text,bool latin,IEnumerable<string> existing,Func<Kind,IEnumerable<string>> known,string defaultBroker)
        {
            if((text??"").Length>1024*1024)throw new UserMessage("Text input is too large (maximum 1 MB).");
            var drafts=new List<Draft>();var d=new Draft();int lineNo=0;
            Action flush=()=>{if(d.Any)drafts.Add(d);d=new Draft();if(drafts.Count>1000)throw new UserMessage("At most 1000 accounts per import.");};
            Action<string> problem=message=>{if(d.Problem.Length==0)d.Problem=message;};
            foreach(string raw in (text??"").Replace("\r","").Split('\n'))
            {
                lineNo++;
                foreach(string piece in Pieces(raw))
                {
                    string line=Clean(piece);if(line.Length==0)continue;string normalized=ImportServerPlan.LabelText(line);var field=Field.Match(normalized);
                    if(field.Success)
                    {
                        string key=ServerCatalog.Norm(field.Groups["key"].Value),v=line.Substring(field.Groups["value"].Index).Trim();
                        bool login=key=="account"||key=="login"||key=="akant"||key.StartsWith("accountnumber")||key=="accountno"||key=="accountlogin"||key=="accnumber"||key=="accno"||key=="شمارهحساب"||key=="شمارهاکانت";
                        bool name=key=="name"||key=="fullname"||key.StartsWith("نام")&&key!="نامبروکر"||key=="بنده";
                        if(login&&d.Row.Login.Length>0&&d.Row.Login!=Digits(v)||name&&d.Row.Name.Length>0)flush();
                        if(d.Row.Line==0)d.Row.Line=lineNo;
                        if(login)d.Row.Login=Digits(v);
                        else if(name){if(d.Row.Login.Length>0&&(d.Row.Investor.Length>0||d.Row.Master.Length>0)&&d.Row.Platform.Length>0)problem("نام پس از اطلاعات کامل آمده؛ ارتباط نام و حساب را بررسی کنید.");d.Row.Name=v;}
                        else if(key.StartsWith("investor")||key.StartsWith("readonly")||key.Contains("اینوستور")||key.Contains("سرمایهگذار")){if(d.Row.Investor.Length>0&&d.Row.Investor!=v)problem("رمزهای متفاوت در یک پیام؛ ردیف را بررسی کنید.");else d.Row.Investor=v;}
                        else if(key.StartsWith("master")||key.Contains("مستر")){if(d.Row.Master.Length>0&&d.Row.Master!=v)problem("رمزهای متفاوت در یک پیام؛ ردیف را بررسی کنید.");else d.Row.Master=v;}
                        else if(key=="password"||key=="رمز"||key=="پسورد"||key=="رمزعبور"){if(d.Row.Investor.Length>0&&d.Row.Investor!=v)problem("رمزهای متفاوت در یک پیام؛ ردیف را بررسی کنید.");else d.Row.Investor=v;}
                        else if(key.StartsWith("server")||key=="سرور"){if(d.Row.Server.Length>0&&!d.Row.Server.Equals(v,StringComparison.OrdinalIgnoreCase))problem("سرورهای متفاوت در یک پیام؛ ردیف را بررسی کنید.");else d.Row.Server=v;}
                        else if(key.StartsWith("broker")||key=="بروکر"||key=="نامبروکر"){if(d.Broker.Length>0&&!ImportServerPlan.BrokerAlias(d.Broker).Equals(ImportServerPlan.BrokerAlias(v),StringComparison.OrdinalIgnoreCase))problem("بروکرهای متفاوت در یک پیام؛ ردیف را بررسی کنید.");else d.Broker=v;}
                        else if(key=="accounttype"||key=="نوعحساب")d.Type=ImportServerPlan.AccountType(v);
                        else if(key=="folder"||key=="پوشه")d.Row.Folder=v;
                        else {string next=ImportServerPlan.Platform(v);if(d.Row.Platform.Length>0&&d.Row.Platform!=next)problem("پلتفرم‌های متفاوت در یک پیام؛ ردیف را بررسی کنید.");else d.Row.Platform=next;}
                        continue;
                    }
                    if(normalized.EndsWith(":",StringComparison.Ordinal)||normalized.Contains("منتورینگ")||normalized.Contains("آکادمی")||normalized.Contains("آكادمى")||Regex.IsMatch(normalized,@"^\[?\d{1,2}[:/]\d{2}.*\]:")){flush();continue;}
                    if(normalized=="اطلاعات حساب"){flush();continue;}
                    if(Regex.IsMatch(normalized,@"^(سلام|با سلام|درود|توجه\s*[:：]|نکته\s*[:：])"))continue;
                    string platform=ImportServerPlan.Platform(line);if(platform.Length>0){if(d.Row.Platform.Length>0&&d.Row.Platform!=platform)problem("پلتفرم‌های متفاوت در یک پیام؛ ردیف را بررسی کنید.");else d.Row.Platform=platform;continue;}
                    string type=ImportServerPlan.AccountType(line);if(type.Length>0){d.Type=type;d.Row.Server=line;continue;}
                    if(line.IndexOf('-')>0&&Regex.IsMatch(line,@"(?i)-(demo|real|live)\s*\d*$")){d.Row.Server=line;continue;}
                    if(ImportServerPlan.BrokerAlias(line)=="WMMarkets"||Regex.IsMatch(line,@"(?i)\b(markets?|brokers?)\b")){d.Broker=line;continue;}
                    if(d.Row.Name.Length>0&&(d.Row.Investor.Length>0||d.Row.Master.Length>0||d.Row.Platform.Length>0&&d.Row.Login.Length>0)&&NameLike(line)){flush();d.Row.Name=line;d.Row.Line=lineNo;continue;}
                    string number=Digits(line);
                    if(Regex.IsMatch(number,@"^\d{1,20}$")&&d.Row.Login.Length==0&&d.Row.Investor.Length==0){d.Row.Login=number;if(d.Row.Line==0)d.Row.Line=lineNo;continue;}
                    if(d.Row.Name.Length==0){d.Row.Name=line;if(d.Row.Line==0)d.Row.Line=lineNo;continue;}
                    if(d.Row.Investor.Length==0&&d.Row.Master.Length==0){d.Row.Investor=line;continue;}
                    problem("متن اضافه یا مبهم در این پیام؛ ردیف را بررسی کنید.");
                }
            }
            flush();if(drafts.Count==0)throw new UserMessage(Lang.T("اطلاعات حسابی در متن پیدا نشد.","No account information found in the text."));
            foreach(var item in drafts)
            {
                var r=item.Row;r.OriginalName=r.Name;if(latin&&StudentNameLatin.Persian(r.Name))r.Name=StudentNameLatin.Convert(r.Name);
                r.Mode=r.Investor.Length>0?"investor":r.Master.Length>0?"master":"investor";r.InputProblem=item.Problem;
                r.Broker=item.Broker;r.AccountType=item.Type;
                ImportServerPlan.Resolve(r,item.Broker,item.Type,known==null?ServerCatalog.Online(r.Platform=="MT4"?Kind.MT4:Kind.MT5):known(r.Platform=="MT4"?Kind.MT4:Kind.MT5),defaultBroker);
            }
            return Revalidate(drafts.Select(x=>x.Row),existing);
        }
        public static List<StudentImportRow> Revalidate(IEnumerable<StudentImportRow> input,IEnumerable<string> existing)
        {
            var list=input.ToList();var sheet=new List<SheetRow>();var h=new SheetRow();for(int c=0;c<StudentImport.Headers.Length;c++)h.Cells[c]=StudentImport.Headers[c];h.Cells[8]="NeedsLoginCorrection";h.Cells[9]="Broker";h.Cells[10]="AccountType";sheet.Add(h);
            foreach(var r in list){var row=new SheetRow{Number=r.Line,Problem=r.InputProblem};string[] values={r.Name,r.Platform,r.Login,r.Server,r.Investor,r.Folder,r.Mode,r.Master};for(int c=0;c<values.Length;c++)row.Cells[c]=values[c];row.Cells[8]=r.LoginNeedsCorrection?"1":"";row.Cells[9]=r.Broker;row.Cells[10]=r.AccountType;sheet.Add(row);}
            var validated=StudentImport.Plan(sheet,existing);
            for(int i=0;i<list.Count;i++){var a=list[i];var b=validated[i];ImportReplacement.Reset(a);a.Name=b.Name;a.Login=b.Login;a.Server=b.Server;a.Platform=b.Platform;a.Kind=b.Kind;a.Mode=b.Mode;a.Broker=b.Broker;a.AccountType=b.AccountType;a.ImportServers=b.ImportServers.Length>0?b.ImportServers:a.ImportServers;a.State=b.State;a.Reason=b.Reason;if(a.State==ImportState.Ready&&a.ImportServers.Length>0)a.Reason=Lang.T("سرور پیشنهادی؛ تأیید اتصال لازم است (", "Suggested server; login verification required (")+a.ImportServers.Split('|').Length+")";}
            // Conflicting credentials for the same number must not silently choose a winner.
            foreach(var group in list.Where(r=>r.Login.Length>0).GroupBy(r=>StudentImport.Key(r.Kind,r.Login,r.Server)).Where(g=>g.Count()>1))
            {if(group.Select(r=>r.Server+"\t"+r.Platform+"\t"+r.Mode+"\t"+r.Investor+"\t"+r.Master).Distinct(StringComparer.Ordinal).Count()>1)foreach(var r in group){r.State=ImportState.Invalid;r.Reason=Lang.T("اطلاعات متناقض برای یک شماره حساب؛ اصلاح کنید.","Conflicting details for one account number; edit before adding.");}}
            return list;
        }
        public static string CorrectionText(IEnumerable<StudentImportRow> rows)
        {
            var output=new List<string>();foreach(var r in rows.Where(x=>x.State==ImportState.Invalid||x.State==ImportState.Failed||x.State==ImportState.Unconfirmed||x.State==ImportState.Cancelled||x.State==ImportState.Blocked))
            {
                output.Add(string.Join(" · ",new[]{TextUtil.OneLine(r.Name),TextUtil.OneLine(r.Login)}.Where(value=>!string.IsNullOrWhiteSpace(value))));
            }return string.Join("\r\n",output);
        }
    }
}
