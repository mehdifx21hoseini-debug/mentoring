using System;
using System.Drawing;
using System.Windows.Forms;

namespace MTManager
{
    sealed partial class MainForm
    {
        Panel workspaceHost;
        Form workspaceForm;
        readonly ModernButton[] workspaceTabs = new ModernButton[4];
        void InitializeWorkspace()
        {
            workspaceHost=new Panel { Dock=DockStyle.None, Anchor=AnchorStyles.Top|AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right, BackColor=Theme.Page, Visible=false };
            body.Controls.Add(workspaceHost);workspaceHost.Bounds=body.ClientRectangle;body.SizeChanged+=(s,e)=>workspaceHost.Bounds=body.ClientRectangle;
            var navigation=new FlowLayoutPanel { Dock=DockStyle.Top, Height=Theme.S(44), Padding=Theme.Pad(20,5), WrapContents=false, FlowDirection=Lang.En?FlowDirection.LeftToRight:FlowDirection.RightToLeft, RightToLeft=RightToLeft.No, BackColor=Theme.Surface };
            var titles=new[]{Lang.T("حساب‌ها","Accounts"),Lang.T("تنظیمات","Settings"),Lang.T("ارسال","Delivery"),Lang.T("پشتیبانی","Support")};
            for(int i=0;i<titles.Length;i++)
            {
                int index=i;
                var button=new ModernButton(titles[i],i==0?ButtonKind.Primary:ButtonKind.Subtle,Glyph.None){Width=Theme.S(112),Height=Theme.S(32),Margin=Theme.Pad(3,0)};
                button.Click+=(s,e)=>Guard(()=>{if(index==0)CloseWorkspace();else if(index==1)EditSettings();else if(index==2)EditSchedule();else OpenSupportWorkspace();});
                workspaceTabs[i]=button;navigation.Controls.Add(button);
            }
            Controls.Add(navigation);navigation.BringToFront();
            // The existing band stays above the page navigation; footer never moves.
            Controls.SetChildIndex(navigation,Controls.GetChildIndex(body)+1);
        }
        void SetWorkspaceTab(int selected)
        {
            for(int i=0;i<workspaceTabs.Length;i++) {workspaceTabs[i].Kind=i==selected?ButtonKind.Primary:ButtonKind.Subtle;workspaceTabs[i].Invalidate();}
        }
        bool ConfirmWorkspaceExit()
        {
            return true; // Navigating away has the same effect as Cancel; never saves implicitly.
        }
        void CloseWorkspace()
        {
            if(workspaceForm==null)return;
            if(!ConfirmWorkspaceExit())return;
            workspaceForm.DialogResult=DialogResult.Cancel;workspaceForm.Close();
        }
        void OpenWorkspace(Form page,string title,int tab,Action completed)
        {
            if(workspaceForm!=null)
            {
                if(workspaceForm.GetType()==page.GetType() && workspaceForm.Text==page.Text){page.Dispose();return;}
                if(!ConfirmWorkspaceExit()){page.Dispose();return;}
                workspaceForm.DialogResult=DialogResult.Cancel;workspaceForm.Close();
            }
            var root=new TableLayoutPanel { Dock=DockStyle.Fill,ColumnCount=1,RowCount=2,Margin=Padding.Empty,Padding=Padding.Empty,RightToLeft=RightToLeft.No,BackColor=Theme.Page };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));root.RowStyles.Add(new RowStyle(SizeType.Absolute,Theme.S(44)));root.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            var heading=new Panel{Dock=DockStyle.Fill,Margin=Padding.Empty,BackColor=Theme.Page};
            var label=Theme.Label(title,0,Theme.Bold,Theme.Text);label.AutoSize=true;label.Anchor=AnchorStyles.Top|AnchorStyles.Right;
            var back=new ModernButton(Lang.T("بازگشت به حساب‌ها","Back to accounts"),ButtonKind.Subtle,Glyph.None){Width=Theme.S(170),Height=Theme.S(32)};
            back.Click+=(s,e)=>CloseWorkspace();heading.Controls.Add(label);heading.Controls.Add(back);
            heading.Layout+=(s,e)=>{label.Location=new Point(Lang.En?Theme.S(16):heading.Width-label.Width-Theme.S(16),Theme.S(12));back.Location=new Point(Lang.En?heading.Width-back.Width-Theme.S(8):Theme.S(8),Theme.S(5));};
            root.Controls.Add(heading,0,0);
            if(tab==2){var more=new ModernButton(Lang.T("عملیات ارسال ▾","Delivery actions ▾"),ButtonKind.Secondary,Glyph.None){Width=Theme.S(170),Height=Theme.S(32)};
                var menu=Theme.Menu();Item(menu,Lang.T("گزارش تازه و ارسال اکنون","Read fresh reports and send now"),RunScheduledNow);Item(menu,Lang.T("آخرین گزارش و وضعیت ارسال","Last report and delivery status"),ShowScheduledReport);
                more.Click+=(s,e)=>ShowUnder(menu,more);heading.Controls.Add(more);heading.Layout+=(s,e)=>more.Location=new Point(Math.Max(Theme.S(180),(heading.Width-more.Width)/2),Theme.S(5));page.Disposed+=(s,e)=>menu.Dispose();}
            var content=new Panel{Dock=DockStyle.Fill,Margin=Padding.Empty,BackColor=Theme.Page};root.Controls.Add(content,0,1);
            page.AutoSize=false;page.TopLevel=false;page.FormBorderStyle=FormBorderStyle.None;page.MinimumSize=Size.Empty;page.MaximumSize=Size.Empty;page.Dock=DockStyle.None;page.Margin=Padding.Empty;
            content.Controls.Add(page);
            content.Layout+=(s,e)=>{page.Bounds=new Rectangle(Math.Max(0,(content.Width-Math.Min(content.Width,Theme.S(760)))/2),0,Math.Min(content.Width,Theme.S(760)),content.Height);};
            workspaceForm=page;workspaceHost.Bounds=body.ClientRectangle;workspaceHost.Controls.Add(root);workspaceHost.Visible=true;workspaceHost.BringToFront();SetWorkspaceTab(tab);
            page.FormClosed+=(s,e)=>{if(workspaceForm!=page)return;workspaceForm=null;workspaceHost.Visible=false;workspaceHost.Controls.Remove(root);root.Dispose();SetWorkspaceTab(0);if(completed!=null)Guard(completed);};
            page.Show();content.PerformLayout();
        }
        void OpenSupportWorkspace()
        {
            var page=new Form {Text=Lang.T("پشتیبانی","Support"),BackColor=Theme.Page};
            var actions=new FlowLayoutPanel{Dock=DockStyle.Fill,FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoScroll=true,Padding=Theme.Pad(16,12),RightToLeft=RightToLeft.No};
            var menu=BuildSupportMenu();
            foreach(ToolStripItem item in menu.Items)
            {
                var action=item;
                var button=new ModernButton(item.Text,ButtonKind.Secondary,Glyph.None){Width=Theme.S(340),Height=Theme.S(40),Margin=Theme.Pad(0,4)};
                button.Click+=(s,e)=>action.PerformClick();actions.Controls.Add(button);
            }
            page.Controls.Add(actions);page.Disposed+=(s,e)=>menu.Dispose();
            OpenWorkspace(page,page.Text,3,null);
        }
    }
}
