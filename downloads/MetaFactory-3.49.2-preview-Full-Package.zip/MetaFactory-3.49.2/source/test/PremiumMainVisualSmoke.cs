using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Drawing;using System.Reflection;using System.Threading;using System.Windows.Forms;
namespace MTManager{static class PremiumMainVisualSmoke{
const BindingFlags F=BindingFlags.NonPublic|BindingFlags.Public|BindingFlags.Instance;
static object Get(object v,string name){return v.GetType().GetField(name,F).GetValue(v);}static void Set(object v,string name,object x){v.GetType().GetField(name,F).SetValue(v,x);}static void Call(object v,string name,params object[] x){v.GetType().GetMethod(name,F).Invoke(v,x);}
static object CallResult(object v,string name,params object[] x){return v.GetType().GetMethod(name,F).Invoke(v,x);}
static void Pump(){for(int i=0;i<4;i++){Application.DoEvents();Thread.Sleep(20);}}
static void Shot(Form f,string p){Pump();using(var b=new Bitmap(f.Width,f.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(f.Location,Point.Empty,f.Size);b.Save(p);}}
static void Check(bool x,string m){if(!x)throw new Exception(m);Console.WriteLine("PASS "+m);}
[STAThread]static int Main(string[] args){Application.EnableVisualStyles();Theme.Init();Lang.En=args.Contains("en");float requested;if(float.TryParse(Environment.GetEnvironmentVariable("MTM_SCALE"),System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out requested)){float actual=Theme.Scale;Theme.Scale=requested;typeof(Theme).GetField("fontScale",BindingFlags.Static|BindingFlags.NonPublic).SetValue(null,requested/actual);Theme.Fonts();Check(Math.Abs(Theme.Scale-requested)<.001,"actual simulated DPI scale "+requested);}string root=Path.Combine(Path.GetTempPath(),"premium-main-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=Path.Combine(root,"data");Directory.CreateDirectory(AppPaths.DataDirOverride);
try{var settings=new Settings{BaseDir=Path.Combine(root,"copies"),Language=Lang.En?"en":"fa",AutoStart=false,LastBackup=DateTime.Now.AddMinutes(-15)};Directory.CreateDirectory(settings.BaseDir);var store=new AccountStore();
for(int i=1;i<=6;i++){string name="MT5-"+i.ToString("00"),dir=Path.Combine(settings.BaseDir,name);Directory.CreateDirectory(dir);File.WriteAllBytes(Path.Combine(dir,"terminal64.exe"),new byte[0]);store.Set(new Account{Instance=name,Platform="MT5",Login=(100000+i).ToString(),Server="Synthetic-Demo",Trader=Lang.En?"Sample student "+i:new[]{"علی رضایی","سارا احمدی","رضا مرادی","مریم کریمی","امیر حسینی","نیما محمدی"}[i-1]});}
using(var main=new MainForm(settings,store)){main.WindowState=FormWindowState.Normal;main.Bounds=new Rectangle(0,0,1366,738);main.Show();Pump();foreach(string name in new[]{"refreshTimer","watchTimer","scheduleTimer","pendingTimer","importTimer"})((System.Windows.Forms.Timer)Get(main,name)).Stop();
var grid=(CopyGrid)Get(main,"grid");grid.Rows.Clear();for(int i=0;i<6;i++){int at=grid.Rows.Add();grid.SetRow(at,new CopyRow{Name="MT5-"+(i+1).ToString("00"),Kind="MT5",Trader=store.Get("MT5-"+(i+1).ToString("00")).Trader,Login=(100001+i).ToString(),Server="Synthetic-Demo",HasAccount=true,Running=i<3,State=i<3?RowState.Open:RowState.Off,Status=i<3?Lang.T("باز است","Open"):Lang.T("بسته است","Closed"),TodayText=i<3?(i==1?"-38.20":"+125.40"):"—",TodayAgo=i<3?Lang.T("زنده · همین الان","Live · just now"):Lang.T("آخرین گزارش · ۱۰ دقیقه پیش","Last report · 10 minutes ago")});}
var band=(Control)Get(main,"band");band.PerformLayout();Pump();foreach(string name in new[]{"toolsButton","settingsButton","supportButton","deliveryButton","newButton","refreshButton"}){var c=(Control)Get(main,name);Check(c.Visible && c.Left>=0 && c.Right<=band.ClientSize.Width && c.Bottom<=band.ClientSize.Height,"main command reachable "+name);}
var top=new[]{"toolsButton","settingsButton","supportButton"}.Select(n=>(Control)Get(main,n)).ToArray();for(int i=0;i<top.Length;i++)for(int j=i+1;j<top.Length;j++)Check(!top[i].Bounds.IntersectsWith(top[j].Bounds),"header buttons do not overlap");
Directory.CreateDirectory(args[0]);Shot(main,Path.Combine(args[0],Lang.En?"main-en.png":"main-fa.png"));
var tools=(ContextMenuStrip)Get(main,"toolsMenu");
Check(tools.Items.OfType<ToolStripMenuItem>().Count()==4,"Tools has exactly four concise roots");
var roots=tools.Items.OfType<ToolStripMenuItem>().ToArray();
Check(roots[2].DropDownItems.OfType<ToolStripMenuItem>().Count()==2 && roots[3].DropDownItems.OfType<ToolStripMenuItem>().Count()==2,"backup and advanced commands remain in two compact submenus");
Check(!tools.Items.OfType<ToolStripMenuItem>().Any(x=>x.Text==Lang.T("تنظیمات…","Settings…")),"Settings is not duplicated in Tools");
using(var support=(ContextMenuStrip)CallResult(main,"BuildSupportMenu"))Check(support.Items.OfType<ToolStripMenuItem>().Count()==4,"Support has exactly diagnostics help and About");
using(var delivery=(ContextMenuStrip)CallResult(main,"BuildDeliveryMenu"))Check(delivery.Items.OfType<ToolStripMenuItem>().Count()==3,"Delivery retains its three existing commands in one place");
Call(main,"ShowRefreshMenu");var refresh=(ContextMenuStrip)Get(main,"refreshMenu");Check(!refresh.Items.OfType<ToolStripMenuItem>().Any(x=>x.Text.Contains(Lang.T("پایش","Live monitoring"))),"Live monitor is not duplicated in refresh menu");refresh.Close();
Check(((Control)Get(main,"liveButton")).Visible,"Live monitor remains reachable directly");
var chosen=Get(main,"chosen");Call(chosen,"Toggle","MT5-01");Call(chosen,"Toggle","MT5-02");Call(main,"ShowChoice");Pump();
Check(((Control)Get(main,"toolsButton")).Visible && ((Control)Get(main,"supportButton")).Visible,"header commands remain accessible during selection");
Shot(main,Path.Combine(args[0],Lang.En?"main-selected-en.png":"main-selected-fa.png"));
main.Width=940;Call(main,"ShowChoice");Pump();foreach(Control c in band.Controls)if(c.Visible)Check(c.Left>=0 && c.Right<=band.Width,"narrow main bounds "+c.GetType().Name);
Shot(main,Path.Combine(args[0],Lang.En?"main-narrow-en.png":"main-narrow-fa.png"));main.Hide();}
Console.WriteLine("PREMIUM MAIN VISUAL PASS "+(Lang.En?"en":"fa"));return 0;}catch(Exception ex){Console.Error.WriteLine(ex);return 1;}finally{try{Directory.Delete(root,true);}catch{}}}
}}
