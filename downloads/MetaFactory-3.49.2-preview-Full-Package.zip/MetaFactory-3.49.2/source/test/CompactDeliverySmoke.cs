using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using MTManager;
class CompactDeliverySmoke {
 static int checks;
 static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);Console.WriteLine("PASS "+message);}
 static T Field<T>(object o,string name){return (T)o.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(o);}
 static void Select(ScheduleDialog dialog,string name){dialog.GetType().GetMethod("SelectChannel",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(dialog,new object[]{name});}
 static void Pump(){for(int i=0;i<12;i++){Application.DoEvents();Thread.Sleep(35);}}
 static void Shot(Form form,string path){Pump();using(var b=new Bitmap(form.Width,form.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(form.Location,Point.Empty,form.Size);b.Save(path);}}
 [STAThread]static int Main(string[] args){
  try{
   Application.EnableVisualStyles();typeof(Account).Assembly.GetType("MTManager.Theme").GetMethod("Init").Invoke(null,null);
   var theme=typeof(Account).Assembly.GetType("MTManager.Theme");float requested;
   if(float.TryParse(Environment.GetEnvironmentVariable("MTM_SCALE"),System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out requested)){
    float actual=(float)theme.GetField("Scale",BindingFlags.Static|BindingFlags.Public).GetValue(null);
    theme.GetField("Scale",BindingFlags.Static|BindingFlags.Public).SetValue(null,requested);
    theme.GetField("fontScale",BindingFlags.Static|BindingFlags.NonPublic).SetValue(null,requested/actual);
    theme.GetMethod("Fonts",BindingFlags.Static|BindingFlags.Public).Invoke(null,null);
    Check(Math.Abs((float)theme.GetField("Scale",BindingFlags.Static|BindingFlags.Public).GetValue(null)-requested)<0.001,"actual simulated DPI scale "+requested);
   }
   string output=args[0];Directory.CreateDirectory(output);
   foreach(bool english in new[]{false,true}){
    Lang.En=english;
    var options=new ScheduleOptions{Enabled=false,TelegramEnabled=true,BaleEnabled=true,EmailEnabled=true,Time="22:00",Platform="All",TelegramTokenEnc=Secret.Protect("123456:"+new string('a',35)),TelegramChatId="-100123456789",BaleTokenEnc=Secret.Protect("123456:"+new string('b',35)),BaleChatId="12345",SmtpHost="smtp.example.com",SmtpPort=587,SmtpSsl=true,SmtpUser="reports@example.com",SmtpPasswordEnc=Secret.Protect("synthetic-password"),EmailFrom="reports@example.com",EmailTo="mentor@example.com"};
    using(var dialog=new ScheduleDialog(options,"")){
     dialog.Show();Pump();
     foreach(string channel in new[]{"telegram","bale","email"}){
      int priorBottom=dialog.Bottom;
      Select(dialog,channel);Pump();
      float scale=(float)typeof(Account).Assembly.GetType("MTManager.Theme").GetField("Scale",BindingFlags.Static|BindingFlags.Public).GetValue(null);
      Check(dialog.ClientSize.Width<=640*scale+2,"compact channel width "+channel);
      Check(dialog.ClientSize.Height<=(channel=="email"?530:400)*scale+2,"compact channel height "+channel);
      var screen=Screen.FromControl(dialog).WorkingArea;
      Check(priorBottom-dialog.Height<screen.Top?screen.Contains(dialog.Bounds):Math.Abs(dialog.Bottom-priorBottom)<=2,"channel switch anchors footer or clamps to screen "+channel);
      Shot(dialog,Path.Combine(output,"delivery-"+(english?"en":"fa")+"-"+channel+".png"));
      Check(Field<CheckBox>(dialog,"telegramEnabled").Checked && Field<CheckBox>(dialog,"baleEnabled").Checked && Field<CheckBox>(dialog,"emailEnabled").Checked,"channel navigation preserves all enabled destinations "+(english?"en":"fa")+" "+channel);
     }
     Select(dialog,"telegram");Pump();
     Check(Field<Panel>(dialog,"channelDetails").Height<150*(float)typeof(Account).Assembly.GetType("MTManager.Theme").GetField("Scale",BindingFlags.Static|BindingFlags.Public).GetValue(null),"switching back from email removes expanded whitespace");
     Select(dialog,"email");Pump();
     foreach(string fieldName in new[]{"smtpHost","smtpPort","smtpSsl","smtpUser","smtpPassword","emailFrom","emailTo"}){
      var field=(Control)dialog.GetType().GetField(fieldName,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(dialog);
      var viewport=Field<Panel>(dialog,"scroll");Point point=viewport.PointToClient(field.PointToScreen(Point.Empty));
      viewport.AutoScrollPosition=new Point(0,Math.Max(0,-viewport.AutoScrollPosition.Y+point.Y-10));Pump();
      var box=field.RectangleToScreen(field.ClientRectangle);var view=viewport.RectangleToScreen(viewport.ClientRectangle);
      Check(box.Left>=view.Left&&box.Right<=view.Right,"email input horizontal bounds "+fieldName);
      Check(box.Bottom<=Field<Button>(dialog,"saveButton").RectangleToScreen(Field<Button>(dialog,"saveButton").ClientRectangle).Top,"email input reachable above footer "+fieldName);
     }
     foreach(string name in new[]{"telegramToken","telegramChat","baleToken","baleChat","smtpHost","smtpUser","smtpPassword","emailFrom","emailTo","time"})Check(Field<TextBox>(dialog,name).RightToLeft==RightToLeft.No,"LTR input "+name);
     Check(Field<TextBox>(dialog,"telegramToken").UseSystemPasswordChar && Field<TextBox>(dialog,"baleToken").UseSystemPasswordChar && Field<TextBox>(dialog,"smtpPassword").UseSystemPasswordChar,"secrets masked");
     var toggle=Field<CheckBox>(dialog,"telegramEnabled");bool previous=toggle.Checked;
     toggle.GetType().GetMethod("OnClick",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(toggle,new object[]{EventArgs.Empty});
     Check(toggle.Checked!=previous&&Field<CheckBox>(dialog,"baleEnabled").Checked&&Field<CheckBox>(dialog,"emailEnabled").Checked,"switch click changes only its own destination");
     toggle.GetType().GetMethod("OnClick",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(toggle,new object[]{EventArgs.Empty});
     var save=Field<Button>(dialog,"saveButton");var cancel=Field<Button>(dialog,"cancelButton");
     Check(save.Visible&&cancel.Visible&&save.Bottom<=save.Parent.ClientSize.Height,"fixed footer remains visible");
     Field<CheckBox>(dialog,"dailyEnabled").Checked=true;Field<TextBox>(dialog,"time").Text="99:99";save.PerformClick();Pump();
     Check(dialog.DialogResult!=DialogResult.OK&&Field<Label>(dialog,"error").Visible,"invalid save displays existing validation locally");
     Check(!options.Enabled&&options.Time=="22:00","editing leaves source model intact");
     Field<TextBox>(dialog,"time").Text="۲۲:۳۰";Field<ComboBox>(dialog,"platform").SelectedIndex=2;save.PerformClick();Pump();
     Check(dialog.DialogResult==DialogResult.OK&&dialog.Options.Time=="22:30"&&dialog.Options.Platform=="MT5","existing save normalization and scope preserved");
     Check(dialog.Options.TelegramEnabled&&dialog.Options.BaleEnabled&&dialog.Options.EmailEnabled,"all channels saved together");
     Check(dialog.Options.TelegramTokenEnc==options.TelegramTokenEnc&&dialog.Options.BaleTokenEnc==options.BaleTokenEnc&&dialog.Options.SmtpPasswordEnc==options.SmtpPasswordEnc,"unchanged secret ciphertext preserved");
    }
    using(var dialog=new ScheduleDialog(options,"")){
     dialog.ClientSize=new Size(720,450);dialog.Show();Pump();Select(dialog,"email");Shot(dialog,Path.Combine(output,"delivery-"+(english?"en":"fa")+"-small.png"));
     var viewport=Field<Panel>(dialog,"scroll");
     var destination=Field<TextBox>(dialog,"emailTo");viewport.ScrollControlIntoView(destination);Pump();
     Check(destination.Visible&&Field<Button>(dialog,"saveButton").Visible,"compact email fields and fixed footer remain available");
     Field<TextBox>(dialog,"time").Text="10:00";Field<Button>(dialog,"cancelButton").PerformClick();Pump();
     Check(dialog.DialogResult==DialogResult.Cancel&&dialog.Options.Time=="22:00","Cancel discards edit");
    }
   }
   Console.WriteLine("COMPACT DELIVERY PASS "+checks);return 0;
  }catch(Exception e){Console.Error.WriteLine(e);return 1;}
 }
}
