using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
class Settings3491Smoke
{
 const BindingFlags Instance=BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public;
 const BindingFlags Static=BindingFlags.Static|BindingFlags.NonPublic|BindingFlags.Public;
 static int checks;
 static void Check(bool value,string name){if(!value)throw new Exception(name);checks++;Console.WriteLine("PASS "+name);}
 static void Pump(){for(int i=0;i<8;i++){Application.DoEvents();Thread.Sleep(25);}}
 static object Field(object o,string name){return o.GetType().GetField(name,Instance).GetValue(o);}
 static void Put(object o,string name,object value){o.GetType().GetField(name,Instance).SetValue(o,value);}
 static Dictionary<string,string> State(object o){return o.GetType().GetFields(Instance).Where(f=>!f.IsStatic).ToDictionary(f=>f.Name,f=>Convert.ToString(f.GetValue(o)));}
 [STAThread] static int Main(string[] args)
 {
  Application.EnableVisualStyles();
  var app=Assembly.LoadFile(Path.GetFullPath(args[0]));
  var lang=app.GetType("MTManager.Lang");var theme=app.GetType("MTManager.Theme");
  theme.GetMethod("Init",Static).Invoke(null,null);
  float requested;
  if(float.TryParse(Environment.GetEnvironmentVariable("MTM_SCALE"),System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out requested)){
   float actual=(float)theme.GetField("Scale",Static).GetValue(null);
   theme.GetField("Scale",Static).SetValue(null,requested);theme.GetField("fontScale",Static).SetValue(null,requested/actual);theme.GetMethod("Fonts",Static).Invoke(null,null);
   Check(Math.Abs((float)theme.GetField("Scale",Static).GetValue(null)-requested)<0.001,"actual simulated DPI scale "+requested);
  }
  Directory.CreateDirectory(args[1]);
  string[][] names={new[]{"folder","language"},new[]{"delay","normalRights","sandboxOverflow","minimized"},new[]{"reportAtOnce"},new[]{"startCharts","light","lowPriority","trimMemory"},new[]{"autostart"}};
  foreach(bool english in new[]{false,true})
  {
   lang.GetField("En",Static).SetValue(null,english);theme.GetMethod("Fonts",Static).Invoke(null,null);
   var settings=Activator.CreateInstance(app.GetType("MTManager.Settings"));
   Put(settings,"BaseDir",@"E:\MetaTrader");Put(settings,"Language",english?"en":"fa");
   Put(settings,"DelaySeconds",7);Put(settings,"ReportAtOnce",3);Put(settings,"Minimized",false);
   Put(settings,"NormalTerminalRights",false);Put(settings,"SandboxieOverflow",false);Put(settings,"Light",false);Put(settings,"LowPriority",false);Put(settings,"TrimMemory",false);
   Put(settings,"StartCharts","all");
   var before=State(settings);
   using(var form=(Form)Activator.CreateInstance(app.GetType("MTManager.SettingsDialog"),new[]{settings}))
   {
    form.Show();Pump();
    var pages=(IList)Field(form,"settingsPages");var nav=(IList)Field(form,"settingsNav");
    Check(pages.Count==5 && nav.Count==5,"five actual settings pages "+english);
    Check(form.Bounds.Bottom<=Screen.PrimaryScreen.WorkingArea.Bottom,"dialog fits desktop height "+english);
    Check(form.Bounds.Right<=Screen.PrimaryScreen.WorkingArea.Right,"dialog fits desktop width "+english);
    Check((int)Field(form,"delay").GetType().GetProperty("Value").GetValue(Field(form,"delay"),null)==7,"existing delay loaded "+english);
    Check(Convert.ToInt32(Field(form,"reportAtOnce").GetType().GetProperty("SelectedIndex").GetValue(Field(form,"reportAtOnce"),null))==3,"existing report concurrency loaded "+english);
    Check(!((CheckBox)Field(form,"minimized")).Checked && !((CheckBox)Field(form,"normalRights")).Checked && !((CheckBox)Field(form,"sandboxOverflow")).Checked && !((CheckBox)Field(form,"light")).Checked && !((CheckBox)Field(form,"lowPriority")).Checked && !((CheckBox)Field(form,"trimMemory")).Checked,"all existing unchecked options retained "+english);
    var cancel=(Button)form.CancelButton;var save=(Button)form.AcceptButton;
    for(int page=0;page<5;page++)
    {
     ((Button)nav[page]).PerformClick();Pump();
     Check(((Control)pages[page]).Visible,"category navigation displays page "+page+" "+english);
     for(int other=0;other<5;other++)if(other!=page)Check(!((Control)pages[other]).Visible,"inactive category hidden "+other+" "+english);
     foreach(string name in names[page])
     {
      var field=(Control)Field(form,name);Check(!field.IsDisposed,"existing control not disposed "+name+" "+english);
      var viewport=(Panel)pages[page];
      if(field is CheckBox){viewport.AutoScrollPosition=Point.Empty;Pump();field.Focus();Pump();}
      else{Point location=viewport.PointToClient(field.PointToScreen(Point.Empty));int wanted=Math.Max(0,location.Y-viewport.AutoScrollPosition.Y-12);viewport.AutoScrollPosition=new Point(0,wanted);Pump();}
      var box=field.RectangleToScreen(field.ClientRectangle);
      Console.WriteLine("BOUNDS "+name+"="+box+" footer="+save.RectangleToScreen(save.ClientRectangle)+" page="+((Panel)pages[page]).ClientRectangle+" scroll="+((Panel)pages[page]).AutoScrollPosition+" display="+((Panel)pages[page]).DisplayRectangle);
      if(box.Bottom>save.RectangleToScreen(save.ClientRectangle).Top){using(var image=new Bitmap(form.Width,form.Height)){using(var graphics=Graphics.FromImage(image)){graphics.CopyFromScreen(form.Location,Point.Empty,image.Size);}image.Save(Path.Combine(args[1],"settings-debug-"+(english?"en":"fa")+"-"+page+".png"));}}
      Check(box.Bottom<=save.RectangleToScreen(save.ClientRectangle).Top,"field accessible above fixed footer "+name+" "+english);
     }
     ((Panel)pages[page]).AutoScrollPosition=Point.Empty;form.Refresh();Pump();
     Check(save.Visible && cancel.Visible,"fixed save/cancel visible on page "+page+" "+english);
     using(var image=new Bitmap(form.Width,form.Height)){using(var graphics=Graphics.FromImage(image)){graphics.CopyFromScreen(form.Location,Point.Empty,image.Size);}image.Save(Path.Combine(args[1],"settings-"+(english?"en":"fa")+"-"+page+".png"));}
    }
    cancel.PerformClick();Pump();Check(form.DialogResult==DialogResult.Cancel,"cancel action preserved "+english);
   }
   var after=State(settings);Check(before.Count==after.Count && before.All(x=>after[x.Key]==x.Value),"opening, navigating and cancelling does not mutate settings "+english);
  }
  Console.WriteLine("COMPACT SETTINGS PASS "+checks);return 0;
 }
}
