﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MTManager
{
    /// <summary>A folder box with the folders already used for copies, and a button to pick any other folder.</summary>
    sealed class FolderField : FlowLayoutPanel
    {
        public readonly DropBox Box;

        public FolderField(Settings settings, int width)
        {
            AutoSize = true;
            WrapContents = false;
            Margin = Padding.Empty;
            Box = new DropBox(width) { Margin = Padding.Empty };
            Box.SetItems(settings.AllFolders);
            Box.Value = settings.BaseDir;
            Controls.Add(Box);
            var browse = new ModernButton(Lang.T("انتخاب پوشه…", "Choose folder…"), ButtonKind.Secondary, Glyph.Folder, Glyph.None, true) { Margin = Theme.Pad(8, 3, 0, 0) };
            browse.Click += (s, e) =>
            {
                using (var fbd = new FolderBrowserDialog { Description = Lang.T("پوشه‌ای که متاتریدرهای تازه در آن ساخته شوند (نه داخل Program Files)", "The folder where new MetaTraders are made (not inside Program Files)"), ShowNewFolderButton = true })
                {
                    if (Directory.Exists(Box.Value)) fbd.SelectedPath = Box.Value;
                    if (fbd.ShowDialog(FindForm()) == DialogResult.OK) Box.Value = fbd.SelectedPath;
                }
            };
            Controls.Add(browse);
        }

        public string Value { get { return Box.Value; } }
    }

    sealed class CreateDialog : FormDialog
    {
        readonly Choice mt5 = new Choice("MetaTrader 5", "terminal64.exe", 200) { Checked = true };
        readonly Choice mt4 = new Choice("MetaTrader 4", "terminal.exe", 200);
        readonly DropBox source = new DropBox(360) { Margin = Padding.Empty };
        readonly FolderField folder;
        readonly NumericUpDown count = new NumericUpDown { Minimum = 1, Maximum = 200, Value = 10, Width = Theme.S(90), TextAlign = HorizontalAlignment.Center };
        readonly TextBox prefix = new TextBox { Width = Theme.S(140), RightToLeft = RightToLeft.No };
        readonly CheckBox copyData = new CheckBox { Text = Lang.T("اکسپرت‌ها، اندیکاتورها و قالب‌های متاتریدر مبدأ هم کپی شوند", "Also copy the source MetaTrader's experts, indicators and templates"), AutoSize = true, Checked = true };
        readonly Label hint = Theme.Label("", 520, Theme.Small, Theme.Muted);
        readonly Settings settings;
        public CreateRequest Request;

        public CreateDialog(Settings settings)
            : base(Lang.T("ساخت نسخه‌های تازه", "Make new copies"), Lang.T("از MT4 یا MT5ی که یک بار نصب شده، هر تعداد نسخه‌ی مستقل ساخته می‌شود. خود متاتریدر دست نمی‌خورد.", "Any number of independent copies are made from an MT4 or MT5 installed once. MetaTrader itself is not touched."))
        {
            this.settings = settings;
            folder = new FolderField(settings, 360);
            var kinds = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = Padding.Empty };
            kinds.Controls.Add(mt5);
            kinds.Controls.Add(mt4);
            var src = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = Padding.Empty };
            src.Controls.Add(source);
            var browse = new ModernButton(Lang.T("انتخاب پوشه…", "Choose folder…"), ButtonKind.Secondary, Glyph.Folder, Glyph.None, true) { Margin = Theme.Pad(8, 3, 0, 0) };
            browse.Click += Browse;
            src.Controls.Add(browse);
            LinkLabel install = Art.Link(Lang.T("متاتریدر روی این ویندوز نصب نیست؟", "MetaTrader is not installed on this Windows?"));
            install.LinkClicked += (s, e) => Ui.Message(this,
                Lang.T("یک بار متاتریدر را به روش معمول نصب کنید؛ بهتر است از سایت بروکر خودتان، تا سرورهای بروکر داخلش باشد.\n", "Install MetaTrader once the usual way; best from your own broker's website, so the broker's servers are in it.\n") +
                Lang.T("نسخه‌ی رسمی MetaQuotes:\nMT5: https://www.metatrader5.com/en/download\nMT4: https://www.metatrader4.com/en/download\n\n", "MetaQuotes' official version:\nMT5: https://www.metatrader5.com/en/download\nMT4: https://www.metatrader4.com/en/download\n\n") +
                Lang.T("بعد از نصب، این پنجره را دوباره باز کنید تا خودش پیدایش کند. ساختن ده‌ها نسخه از روی همان یک نصب کار این برنامه است.", "After installing, open this window again and it finds it by itself. Making dozens of copies from that one installation is this program's job."));

            Row(Lang.T("نوع متاتریدر", "MetaTrader type"), kinds);
            Row(Lang.T("نصب مبدأ", "Source installation"), src);
            Row("", install);
            Row(Lang.T("پوشه‌ی ساخت", "Copies folder"), folder);
            Row(Lang.T("تعداد نسخه‌ها", "Number of copies"), count);
            Row(Lang.T("پیشوند نام", "Name prefix"), prefix);
            Row("", copyData);
            Wide(hint);
            Button ok = AddButton(Lang.T("ساختن نسخه‌ها", "Make copies"), Ok, true);
            Button cancel = AddButton(Lang.T("انصراف", "Cancel"), (s, e) => Close(DialogResult.Cancel));
            Finish();
            AcceptButton = ok;
            CancelButton = cancel;

            mt4.CheckedChanged += (s, e) => { if (mt4.Checked) Fill(); };
            mt5.CheckedChanged += (s, e) => { if (mt5.Checked) Fill(); };
            folder.Box.Changed += (s, e) => Hint();
            Fill();
        }

        Kind SelectedKind { get { return mt4.Checked ? Kind.MT4 : Kind.MT5; } }

        void Fill()
        {
            Kind kind = SelectedKind;
            List<string> found = Installs.Find(kind, settings);
            source.SetItems(found);
            source.Value = found.Count > 0 ? found[0] : "";
            if (prefix.Text.Length == 0 || prefix.Text == "MT4" || prefix.Text == "MT5") prefix.Text = kind.ToString();
            Hint();
        }

        void Hint()
        {
            Kind kind = SelectedKind;
            bool none = source.Count == 0;
            hint.ForeColor = none ? Theme.Warn : Theme.Muted;
            hint.Text = none
                ? Lang.T("نصبی از ", "No installation of ") + kind + Lang.T(" پیدا نشد. اگر نصب است، با «انتخاب پوشه…» پوشه‌اش را بدهید (پوشه‌ای که ", " was found. If it is installed, give its folder with “Choose folder…” (the folder where ") + Kinds.Exe(kind) + Lang.T(" در آن است).", " is).")
                : Lang.T("نسخه‌ها در ", "The copies are made in ") + (folder.Value.Length > 0 ? folder.Value : settings.BaseDir) + Lang.T(" ساخته می‌شوند. متاتریدر مبدأ باید بسته باشد؛ خودش هیچ تغییری نمی‌کند. ", ". The source MetaTrader must be closed; it does not change at all. ") +
                  Lang.T("فقط فایل‌های لازم کپی می‌شوند (بدون MetaEditor، تست استراتژی و uninstall).", "Only the needed files are copied (no MetaEditor, strategy tester or uninstall).");
        }

        void Browse(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog { Description = Lang.T("پوشه‌ی نصب متاتریدر (جایی که ", "MetaTrader's installation folder (where ") + Kinds.Exe(SelectedKind) + Lang.T(" است)", " is)") })
            {
                if (fbd.ShowDialog(this) == DialogResult.OK) source.Value = fbd.SelectedPath;
            }
        }

        void Ok(object sender, EventArgs e)
        {
            var r = new CreateRequest
            {
                Kind = SelectedKind, Source = source.Value.Trim('"'), Count = (int)count.Value,
                Prefix = prefix.Text, CopyData = copyData.Checked,
            };
            try
            {
                r.Folder = CopyMaker.CheckFolder(folder.Value);
                CopyMaker.Check(r, settings);
            }
            catch (Exception ex) { Ui.Error(this, ex); return; }
            Request = r;
            Close(DialogResult.OK);
        }
    }

    sealed class AccountDialog : FormDialog
    {
        // 3.26 (CHANGE-010, approved): «ورود با» as a two-way choice under a small «ورود» heading; the password it needs comes first and
        // the other is marked «اختیاری»; an eye in each password box; «حذف حساب» apart from «ذخیره» and «انصراف».
        readonly Instance inst;
        readonly AccountStore store;
        readonly TextBox trader = new TextBox { Width = Theme.S(420) };
        readonly TextBox login = new TextBox { Width = Theme.S(420), RightToLeft = RightToLeft.No };
        readonly ServerPicker server;
        readonly PasswordBox master = new PasswordBox(420);
        readonly PasswordBox investor = new PasswordBox(420);
        readonly Segmented mode = new Segmented(Lang.T("اینوستور · فقط مشاهده", "Investor · view only"), Lang.T("رمز اصلی · امکان معامله", "Master password · can trade"));
        readonly NoteBox note = new NoteBox(Lang.T("رمزها با رمزگذاری ویندوز و فقط برای همین کاربر ذخیره می‌شوند. اگر این نسخه باز است، برای حساب تازه آن را ببندید و دوباره اجرا کنید.", "Passwords are saved with Windows encryption, only for this user. If this copy is open, close and run it again for the new account."), 560)
            { Margin = Theme.Pad(0, 8, 0, 0) };
        int firstRow;
        Label firstLabel, secondLabel;

        bool InvestorMode { get { return mode.Selected == 0; } }

        public AccountDialog(Instance inst, AccountStore store, Settings settings)
            : base(Lang.T("حساب نسخه‌ی ", "Account of copy ") + inst.Name, (inst.Kind == Kind.MT5 ? "MetaTrader 5" : "MetaTrader 4") + Lang.T(" · شماره حساب، سرور و رمزهای معامله‌گر", " · account number, server and the trader's passwords"))
        {
            this.inst = inst;
            this.store = store;
            server = new ServerPicker(settings, store, 420);
            server.Load(inst.Kind);
            mode.Selected = 1;

            Account acc = store.Get(inst.Name);
            if (acc != null && acc.HasLogin)
            {
                trader.Text = acc.Trader;
                login.Text = acc.Login;
                server.Server = acc.Server;
                string m = Secret.Unprotect(acc.MasterEnc), v = Secret.Unprotect(acc.InvestorEnc);
                if (m == null || v == null)
                {
                    note.Text = Lang.T("رمزهای قبلی روی این کاربر ویندوز خوانده نشد (احتمالاً روی کامپیوتر دیگری ذخیره شده‌اند). دوباره واردشان کنید.", "The earlier passwords could not be read for this Windows user (probably saved on another computer). Enter them again.");
                    note.Color = Theme.Bad;
                }
                master.Value = m ?? "";
                investor.Value = v ?? "";
                mode.Selected = acc.IsInvestor ? 0 : 1;
            }

            Row(Lang.T("نام معامله‌گر", "Trader name"), trader);
            Row(Lang.T("شماره حساب", "Account"), login);
            Row(Lang.T("سرور", "Server"), server);
            Wide(new SectionHead(Lang.T("ورود", "Sign-in")) { Margin = Theme.Pad(0, 8, 0, 2) });
            mode.Margin = Theme.Pad(0, 3, 0, 0);
            Row(Lang.T("ورود با", "Sign in with"), mode);
            firstRow = Body.RowCount;
            Row(Lang.T("رمز اینوستور", "Investor password"), investor);
            Row(Lang.T("رمز اصلی", "Master password"), master);
            firstLabel = (Label)Body.GetControlFromPosition(0, firstRow);
            secondLabel = (Label)Body.GetControlFromPosition(0, firstRow + 1);
            mode.Changed += (s, e) => Order();
            Order();
            Wide(note);
            Button save = AddButton(Lang.T("ذخیره", "Save"), Save, true);
            Button cancel = AddButton(Lang.T("انصراف", "Cancel"), (s, e) => Close(DialogResult.Cancel));
            if (acc != null) Buttons.AddApart(new ModernButton(Lang.T("حذف حساب", "Delete account"), Remove, ButtonKind.Secondary) { MinimumSize = new Size(Theme.S(96), 0) }).ForeColor = Theme.Bad;
            Finish();
            AcceptButton = save;
            CancelButton = cancel;
        }

        /// <summary>The password «ورود با» needs first; the other marked «اختیاری».</summary>
        void Order()
        {
            PasswordBox need = InvestorMode ? investor : master, other = InvestorMode ? master : investor;
            Body.SuspendLayout();
            Body.SetCellPosition(need, new TableLayoutPanelCellPosition(1, firstRow));
            Body.SetCellPosition(other, new TableLayoutPanelCellPosition(1, firstRow + 1));
            firstLabel.Text = InvestorMode ? Lang.T("رمز اینوستور", "Investor password") : Lang.T("رمز اصلی", "Master password");
            secondLabel.Text = InvestorMode ? Lang.T("رمز اصلی", "Master password") : Lang.T("رمز اینوستور", "Investor password");
            Body.ResumeLayout();
            need.Cue = "";
            other.Cue = Lang.T("اختیاری", "Optional");
        }

        void Save(object sender, EventArgs e)
        {
            string number = TextUtil.LatinDigits(login.Text.Trim());
            if (!Regex.IsMatch(number, @"^[0-9]{1,20}$")) { Ui.Message(this, Lang.T("شماره حساب باید فقط عدد باشد.", "The account number must be digits only."), MessageBoxIcon.Warning); return; }
            string srv = server.Server;
            if (srv.Length == 0) { Ui.Message(this, Lang.T("نام سرور را وارد کنید؛ همان نامی که در پنجره‌ی ورود متاتریدر انتخاب می‌کنید.", "Enter the server name; the same name you choose in MetaTrader's login window."), MessageBoxIcon.Warning); return; }
            bool investorMode = InvestorMode;
            if ((investorMode ? investor.Value : master.Value).Length == 0)
            {
                Ui.Message(this, Lang.T("برای «ورود با» انتخاب‌شده، ", "For the chosen “Sign in with”, enter the ") + (investorMode ? "رمز اینوستور" : "رمز اصلی") + Lang.T(" را وارد کنید.", "."), MessageBoxIcon.Warning);
                return;
            }
            string problem = PasswordRule.Check(new KeyValuePair<string, string>(Lang.T("رمز اصلی", "Master password"), master.Value), new KeyValuePair<string, string>(Lang.T("رمز اینوستور", "Investor password"), investor.Value));
            if (problem != null) { Ui.Message(this, problem, MessageBoxIcon.Warning); return; }
            store.Set(new Account
            {
                Instance = inst.Name, Trader = TextUtil.OneLine(trader.Text), Login = number, Server = TextUtil.OneLine(srv),
                Mode = investorMode ? "investor" : "master",
                MasterEnc = Secret.Protect(master.Value), InvestorEnc = Secret.Protect(investor.Value),
            });
            store.Save();
            Log.Write("account saved for " + inst.Name + " (" + number + ", " + (investorMode ? "investor" : "master") + ")");
            Close(DialogResult.OK);
        }

        void Remove(object sender, EventArgs e)
        {
            if (!Ui.Confirm(this, Lang.T("حساب ذخیره‌شده‌ی ", "Delete the saved account of ") + inst.Name + Lang.T(" از این برنامه پاک شود؟ خود نسخه دست نمی‌خورد.", " from this program? The copy itself is not touched."))) return;
            store.Remove(inst.Name);
            store.Save();
            Log.Write("account removed for " + inst.Name);
            Close(DialogResult.OK);
        }
    }

    sealed class SettingsDialog : FormDialog
    {
        // 3.26 (CHANGE-011, approved): four small groups (نسخه‌ها، اجرا، سبک‌سازی، ویندوز), numbers as «− ۵ +» with their note beside
        // them, and the program's own drop-down lists. Every setting and what it saves is the same.
        readonly Settings settings;
        readonly TextBox folder = new TextBox { Width = Theme.S(320), RightToLeft = RightToLeft.No };
        readonly Stepper delay = new Stepper(0, 120);
        readonly DropBox reportAtOnce = new DropBox(330) { PickOnly = true, Margin = Padding.Empty };
        readonly CheckBox normalRights = new CheckBox { Text = Lang.T("اجرای عادی متاتریدر، بدون درخواست دسترسی مدیر", "Run MetaTrader at current privilege level"), AutoSize = true };
        readonly CheckBox pauseMt5Updates = new CheckBox { Text = Lang.T("اجرای MT5 بدون به‌روزرسانی خودکار", "Run MT5 without automatic updates"), AutoSize = true };
        readonly CheckBox sandboxOverflow = new CheckBox { Text = Lang.T("اجرای MT4های اضافی با Sandboxie نصب‌شده", "Use installed Sandboxie for additional MT4 copies"), AutoSize = true };
        readonly CheckBox minimized = new CheckBox { Text = Lang.T("نسخه‌ها کوچک‌شده باز شوند", "Start the copies minimized"), AutoSize = true };
        readonly CheckBox light = new CheckBox { Text = Lang.T("حالت سبک: اخبار خاموش؛ چارت‌های MT5 حداکثر ۵۰۰ کندل", "Light mode: news off; MT5 charts limited to 500 candles"), AutoSize = true };
        readonly CheckBox autostart = new CheckBox { Text = Lang.T("بعد از روشن شدن ویندوز، همه‌ی نسخه‌ها خودشان باز شوند (برای VPS)", "When Windows starts, all copies open by themselves (for a VPS)"), AutoSize = true };
        readonly DropBox startCharts = new DropBox(330) { PickOnly = true, Margin = Padding.Empty };
        // 3.27 (CHANGE-019): the program's language; the window is made again when it changes.
        readonly DropBox language = new DropBox(330) { PickOnly = true, Margin = Padding.Empty };
        static readonly string[] ChartModeList = { ChartModes.Empty, ChartModes.One, ChartModes.All };
        readonly CheckBox lowPriority = new CheckBox { Text = Lang.T("متاتریدرهای پشت صحنه با اولویت پایین‌تر اجرا شوند", "Run background MetaTraders at a lower priority"), AutoSize = true };
        readonly CheckBox trimMemory = new CheckBox { Text = Lang.T("حافظهٔ متاتریدرهای کوچک‌شدهٔ بدون پایش زنده به ویندوز برگردد", "Return memory of minimized MetaTraders without live monitoring to Windows"), AutoSize = true };

        static FlowLayoutPanel WithNote(Control field, string note)
        {
            var f = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = Padding.Empty };
            f.Controls.Add(field);
            Label l = Theme.Label(note, 0, Theme.Small, Theme.Muted);
            l.Margin = Theme.Pad(12, 11, 0, 0);
            f.Controls.Add(l);
            return f;
        }

        void Group(string title, bool first = false)
        {
            Wide(new SectionHead(title) { Height = Theme.S(22), Margin = Theme.Pad(0, first ? 0 : 2, 0, 0) });
        }

        /// <summary>A field row a little closer than the usual.</summary>
        void Field(string label, Control c)
        {
            Row(label, c);
            c.Margin = Theme.Pad(14, 2, 0, 2);
        }

        /// <summary>A tick under its group: closer rows than a field's, so the window fits a 768-pixel-high screen.</summary>
        void Tick(CheckBox c)
        {
            Row("", c);
            c.Margin = Theme.Pad(14, 0, 0, 0);
        }

        public SettingsDialog(Settings settings) : base(Lang.T("تنظیمات", "Settings"))
        {
            this.settings = settings;
            folder.Text = settings.BaseDir;
            delay.Value = Math.Max(0, Math.Min(120, settings.DelaySeconds));
            minimized.Checked = settings.Minimized;
            normalRights.Checked = settings.NormalTerminalRights;
            sandboxOverflow.Checked = settings.SandboxieOverflow;
            pauseMt5Updates.Checked = settings.PauseMt5Updates;
            startCharts.SetItems(new[] { Lang.T("بدون چارت (سبک‌ترین)", "No charts (lightest)"), Lang.T("یک چارت", "One chart"), Lang.T("همه‌ی چارت‌ها", "All charts") });
            startCharts.SelectedIndex = Math.Max(0, Array.IndexOf(ChartModeList, settings.StartCharts));
            lowPriority.Checked = settings.LowPriority;
            trimMemory.Checked = settings.TrimMemory;
            light.Checked = settings.Light;
            autostart.Checked = settings.AutoStart;
            var f = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = Padding.Empty };
            folder.Margin = Theme.Pad(0, 4, 0, 0);
            f.Controls.Add(folder);
            var browse = new ModernButton(Lang.T("انتخاب…", "Choose…"), ButtonKind.Secondary, Glyph.Folder, Glyph.None, true) { Margin = Theme.Pad(8, 0, 0, 0) };
            browse.Click += Browse;
            f.Controls.Add(browse);
            language.SetItems(new[] { "فارسی (راست‌چین)", "English (left to right)" });
            language.SelectedIndex = settings.Language == "en" ? 1 : 0;
            Group(Lang.T("نسخه‌ها", "Copies"), true);
            Field(Lang.T("پوشه‌ی پیش‌فرض ساخت", "Default copies folder"), f);
            Group(Lang.T("اجرا", "Running"));
            Field(Lang.T("فاصله‌ی اجرا", "Start interval"), WithNote(delay, Lang.T("ثانیه · اگر نسخه‌ی قبلی زودتر بالا بیاید، بعدی زودتر باز می‌شود", "seconds · if the previous copy is up sooner, the next opens sooner")));
            Field(Lang.T("بازکردن MT4 / MT5", "Opening MT4 / MT5"), Theme.Label(Lang.T("بدون سقف تعداد؛ هشدار حافظه مانع ادامه نمی‌شود", "No count limit; memory warnings do not stop opening"), 0, Theme.Small, Theme.Muted));
            int auto = ReportParallel.Auto(Environment.ProcessorCount, Checks.TotalRamMb(), Checks.FreeRamMb());
            reportAtOnce.SetItems(new[]
            {
                Lang.T("خودکار (ظرفیت فعلی: ", "Automatic (current capacity: ") + Fa.N(auto) + Lang.T(" هم‌زمان)", " at a time)"),
                Lang.T("یکی‌یکی", "one by one"),
                Lang.T("حداکثر ۲ هم‌زمان", "Up to 2 at a time"),
                Lang.T("حداکثر ۳ هم‌زمان", "Up to 3 at a time"),
                Lang.T("حداکثر ۴ هم‌زمان", "Up to 4 at a time"),
            });
            reportAtOnce.SelectedIndex = ReportParallel.Clamp(settings.ReportAtOnce);
            Field(Lang.T("خواندن گزارش", "Reading reports"), WithNote(reportAtOnce, Lang.T("تعداد واقعی با پردازنده و حافظهٔ آزاد محدود می‌شود", "Actual concurrency is limited by CPU and available memory")));
            Tick(normalRights);
            Tick(sandboxOverflow);
            Tick(pauseMt5Updates);
            Group(Lang.T("سبک‌سازی (برای کامپیوتر ضعیف)", "Lighter running (for a weak computer)"));
            Field(Lang.T("چارت نسخه‌های اینوستور", "Charts of investor copies"), startCharts);
            Tick(minimized);
            Tick(light);
            Tick(lowPriority);
            Tick(trimMemory);
            // The language last, with Windows: one row more (the window stays within a 768-pixel-high screen).
            Group(Lang.T("ویندوز و زبان", "Windows and language"));
            Tick(autostart);
            Field("زبان / Language", language);
            Button ok = AddButton(Lang.T("ذخیره", "Save"), Save, true);
            Button cancel = AddButton(Lang.T("انصراف", "Cancel"), (s, e) => Close(DialogResult.Cancel));
            Finish();
            AcceptButton = ok;
            CancelButton = cancel;
        }

        void Browse(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog { Description = Lang.T("پوشه‌ای برای نسخه‌ها (نه داخل Program Files)", "A folder for the copies (not inside Program Files)") })
            {
                if (Directory.Exists(folder.Text)) fbd.SelectedPath = folder.Text;
                if (fbd.ShowDialog(this) == DialogResult.OK) folder.Text = fbd.SelectedPath;
            }
        }

        void Save(object sender, EventArgs e)
        {
            string dir = folder.Text.Trim().Trim('"').TrimEnd('\\');
            if (dir.Length == 0) { Ui.Message(this, Lang.T("یک پوشه انتخاب کنید.", "Choose a folder."), MessageBoxIcon.Warning); return; }
            if (dir.IndexOf("Program Files", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                Ui.Message(this, Lang.T("داخل Program Files نه: نسخه‌ها باید بتوانند در پوشه‌ی خودشان بنویسند.", "Not inside Program Files: the copies must be able to write in their own folder."), MessageBoxIcon.Warning);
                return;
            }
            if (dir.Length <= 2) dir += @"\MetaTrader";  // a drive root gets its own folder
            if (!Checks.CanWrite(dir)) { Ui.Message(this, Lang.T("در این پوشه نمی‌شود نوشت. پوشه‌ی دیگری انتخاب کنید.", "Cannot write in this folder. Choose another folder."), MessageBoxIcon.Warning); return; }
            try { AutoStart.Set(autostart.Checked, Application.ExecutablePath); }
            catch (Exception ex) { Ui.Error(this, ex); return; }
            settings.UseFolder(dir);  // the folder used before stays listed, with its copies
            settings.Language = language.SelectedIndex == 1 ? "en" : "fa";
            settings.DelaySeconds = delay.Value;
            settings.ReportAtOnce = Math.Max(0, reportAtOnce.SelectedIndex);
            settings.Minimized = minimized.Checked;
            settings.NormalTerminalRights = normalRights.Checked;
            settings.SandboxieOverflow = sandboxOverflow.Checked;
            settings.PauseMt5Updates = pauseMt5Updates.Checked;
            if(!settings.PauseMt5Updates)Mt5UpdatePolicy.RestoreAll();
            settings.Light = light.Checked;
            settings.AutoStart = autostart.Checked;
            settings.StartCharts = ChartModeList[Math.Max(0, startCharts.SelectedIndex)];
            settings.LightCharts = settings.StartCharts != ChartModes.All;
            settings.LowPriority = lowPriority.Checked;
            settings.TrimMemory = trimMemory.Checked;
            settings.Save();
            Close(DialogResult.OK);
        }
    }

    /// <summary>A name for a new folder, or a new name for one; with ticked students, they can go into the new folder at once.</summary>
    sealed class FolderDialog : FormDialog
    {
        readonly FolderStore store;
        readonly Folder folder;
        readonly TextBox name = new TextBox { Width = Theme.S(300), MaxLength = FolderStore.MaxName };
        readonly CheckBox addChosen = new CheckBox { AutoSize = true, Checked = true };
        public string FolderName;
        public bool AddChosen;
        public FolderDialog(FolderStore store, Folder folder, int chosen)
            : base(folder == null ? Lang.T("پوشه‌ی جدید", "New folder") : Lang.T("ویرایش پوشه", "Edit folder"),
                   folder == null ? Lang.T("یک دانشجو می‌تواند هم‌زمان در چند پوشه باشد.", "A student can be in several folders at once.") : Lang.T("دانشجوهای این پوشه همان‌طور در آن می‌مانند.", "The students of this folder stay in it."))
        {
            this.store = store;
            this.folder = folder;
            if (folder != null) name.Text = folder.Name;
            Row(Lang.T("نام پوشه", "Folder name"), name);
            if (folder == null && chosen > 0)
            {
                addChosen.Text = Fa.N(chosen) + Lang.T(" دانشجوی انتخاب‌شده به این پوشه اضافه شوند", " selected students are added to this folder");
                Row("", addChosen);
            }
            Wide(Theme.Label(Lang.T("مثلاً «جذب سرمایه»، «چالش مرحله ۱» یا «دوره‌ی پاییز ۱۴۰۵». حداکثر ", "For example “Funded”, “Challenge 1” or “Autumn course”. At most ") + TextUtil.PersianDigits(FolderStore.MaxName.ToString()) + Lang.T(" حرف.", " characters."), 420, Theme.Small, Theme.Muted));
            Button ok = AddButton(folder == null ? Lang.T("ساختن پوشه", "Make folder") : Lang.T("ذخیره", "Save"), Save, true);
            Button cancel = AddButton(Lang.T("انصراف", "Cancel"), (s, e) => Close(DialogResult.Cancel));
            Finish();
            AcceptButton = ok;
            CancelButton = cancel;
            Shown += (s, e) => { name.Focus(); name.SelectAll(); };
        }

        void Save(object sender, EventArgs e)
        {
            string problem = store.NameProblem(name.Text, folder != null ? folder.Id : null);
            if (problem != null) { Ui.Message(this, problem, MessageBoxIcon.Warning); name.Focus(); return; }
            FolderName = TextUtil.OneLine(name.Text);
            AddChosen = addChosen.Checked && addChosen.Parent != null;
            Close(DialogResult.OK);
        }

#if SNAPSHOT
        public void Preview(string text) { name.Text = text; }
#endif
    }

    sealed class HeapDialog : FormDialog
    {
        public HeapDialog(int? current)
            : base(Lang.T("تنظیم حافظهٔ پنجره‌های ویندوز", "Windows desktop heap setting"))
        {
            Wide(Theme.Label(Lang.T("راهنمای مایکروسافت توصیه می‌کند مقدار دوم SharedSection از 20480 KB بیشتر نباشد. گزینه‌های 40960 و 65536 نسخه‌های قبلی حذف شده‌اند. تغییر این مقدار تضمین نمی‌کند سقف تعداد متاتریدر برطرف شود.", "Microsoft advises against an interactive SharedSection value above 20480 KB. Earlier 40960 and 65536 options have been removed. Changing this value is not a guaranteed fix for a terminal-count boundary."), 520, Theme.Font, Theme.Text));
            Wide(Theme.Label(Lang.T("مقدار ثبت‌شده در رجیستری: ", "Configured registry value: ") + (current.HasValue ? current.Value + " KB" : Lang.T("خوانده نشد", "Unknown")), 520, Theme.SmallBold, Theme.LabelColor));
            Wide(Theme.Label(Lang.T("مقدار پیشنهادی برای اصلاح تنظیم بیش‌ازحد: 20480 KB. مقدار واقعیِ دسکتاپ و خطای خروج را از «بررسی سیستم» ببینید.", "Correction for an oversized setting: 20480 KB. See System check for effective desktop size and process exit evidence."), 520, Theme.Font, Theme.Text));
            Wide(Theme.Label(Lang.T("با اعمال، مقدار قبلی پشتیبان‌گیری می‌شود. این تغییر اجازهٔ مدیر ویندوز و سپس ری‌استارت می‌خواهد؛ برنامه خودش ویندوز را ری‌استارت نمی‌کند.", "Apply backs up the previous value. Windows administrator consent and a subsequent restart are required; this program does not restart Windows automatically."), 520, Theme.Small, Theme.Muted));
            Button ok = AddButton(Lang.T("اعمال 20480 KB", "Apply 20480 KB"), (s, e) => Close(DialogResult.OK), true);
            Button cancel = AddButton(Lang.T("انصراف", "Cancel"), (s, e) => Close(DialogResult.Cancel));
            Finish(); AcceptButton = ok; CancelButton = cancel;
        }
        public int Kb { get { return Heap.Recommended; } }
    }

    /// <summary>What can go from the copies, by kind, with sizes; the user picks.</summary>
    sealed class CleanupDialog : FormDialog
    {
        readonly List<CleanupGroup> groups;
        readonly List<CheckBox> boxes = new List<CheckBox>();
        readonly Label total = Theme.Label("", 480, Theme.Bold, Theme.Text);
        readonly Button go;

        public CleanupDialog(List<CleanupGroup> groups, List<string> open)
            : base(Lang.T("پاکسازی فایل‌های غیرلازم", "Clean up unneeded files"), Lang.T("فقط چیزهایی برداشته می‌شود که برای اجرای نسخه‌ها و دیدن حساب لازم نیستند. همه به سطل بازیافت می‌روند و قابل برگرداندن‌اند.", "Only what is not needed to run the copies and view the account is removed. Everything goes to the Recycle Bin and can be brought back."))
        {
            this.groups = groups;
            foreach (CleanupGroup g in groups)
            {
                bool any = g.Paths.Count > 0;
                var box = new CheckBox
                {
                    Text = g.Title + "   |   " + (any ? TextUtil.Size(g.Size) : Lang.T("چیزی پیدا نشد", "Nothing found")),
                    AutoSize = true, Checked = any, Enabled = any, Margin = Theme.Pad(0, 8, 0, 0), UseMnemonic = false,
                };
                box.CheckedChanged += (s, e) => UpdateTotal();
                boxes.Add(box);
                Wide(box);
                Label note = Theme.Label(g.Note, 470, Theme.Small, Theme.Muted);
                note.Margin = Theme.Pad(24, 0, 0, 2);
                Wide(note);
            }
            if (open.Count > 0)
                Wide(Theme.Label(Lang.T("این نسخه‌ها باز هستند و بررسی نشدند؛ برای پاکسازی آن‌ها اول ببندیدشان: ", "These copies are open and were not checked; close them first to clean them: ") + string.Join(Lang.T("، ", ", "), open), 480, Theme.Small, Theme.Warn));
            total.Margin = Theme.Pad(0, 14, 0, 0);
            Wide(total);
            go = AddButton(Lang.T("انتقال به سطل بازیافت", "Move to Recycle Bin"), (s, e) => Close(DialogResult.OK), true);
            Button cancel = AddButton(Lang.T("انصراف", "Cancel"), (s, e) => Close(DialogResult.Cancel));
            Finish();
            AcceptButton = go;
            CancelButton = cancel;
            UpdateTotal();
        }

        public List<CleanupGroup> Chosen
        {
            get { return groups.Where((g, k) => boxes[k].Checked && g.Paths.Count > 0).ToList(); }
        }

        void UpdateTotal()
        {
            long sum = Chosen.Sum(g => g.Size);
            total.Text = sum > 0 ? Lang.T("جمعاً ", "Total ") + TextUtil.Size(sum) : Lang.T("چیزی انتخاب نشده.", "Nothing selected.");
            go.Enabled = sum > 0;
        }
    }

    /// <summary>3.22.1: a student's day as text (approved mockup): the text, «کپی» and «بستن». Laid out like the help window (a fixed
    /// layout, resizable), so the text has its full width on every Windows.</summary>
    sealed class DayTextDialog : Form
    {
        static string Copied { get { return Lang.T("✓ کپی شد. در تلگرام یا واتس‌اپ Ctrl+V بزنید.", "✓ Copied. Press Ctrl+V in Telegram or WhatsApp."); } }
        readonly string text;
        string note = "";
        readonly Panel foot;

        public DayTextDialog(string who, string day, string text) : this(who, day, text, false) { }

        /// <summary>3.27.2 (CHANGE-022): several days are «متن گزارش».</summary>
        public DayTextDialog(string who, string day, string text, bool range)
        {
            this.text = text;
            string title = (range ? Lang.T("متن گزارش — ", "Report text — ") : Lang.T("متن روز — ", "Day text — ")) + who, sub = day + Lang.T(" · «کپی» متن را برای فرستادن در تلگرام یا واتس‌اپ آماده می‌کند.", " · “Copy” readies the text for sending in Telegram or WhatsApp.");
            Text = title;
            Font = Theme.Font;
            BackColor = Theme.Surface;
            ForeColor = Theme.Text;
            RightToLeft = Theme.Dir;
            RightToLeftLayout = false;
            ShowInTaskbar = false;
            ShowIcon = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = Theme.Sz(640, 600);
            MinimumSize = Theme.Sz(480, 400);
            Theme.Window(this);

            var head = new Panel { Dock = DockStyle.Top, Height = Theme.S(80), BackColor = Theme.Surface };
            head.Paint += (s, e) =>
            {
                Theme.Line(e.Graphics, title, Theme.Heading, new Rectangle(Theme.S(24), Theme.S(16), head.Width - Theme.S(48), Theme.S(32)), Theme.Text);
                Theme.Line(e.Graphics, sub, Theme.Small, new Rectangle(Theme.S(24), Theme.S(48), head.Width - Theme.S(48), Theme.S(22)), Theme.Muted);
            };
            var box = new TextBox
            {
                Multiline = true, ReadOnly = true, WordWrap = false, ScrollBars = ScrollBars.Both, RightToLeft = RightToLeft.No, TextAlign = HorizontalAlignment.Left,
                Dock = DockStyle.Fill, Font = Mono(), Text = text, BackColor = Theme.Alt, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle,
            };
            Theme.DarkParts(box);
            foot = new Panel { Dock = DockStyle.Bottom, Height = Theme.S(30), BackColor = Theme.Surface };
            foot.Paint += (s, e) => Theme.Line(e.Graphics, note, Theme.SmallBold, new Rectangle(0, Theme.S(6), foot.Width, Theme.S(22)), Theme.Ok);
            var holder = new Panel { Dock = DockStyle.Fill, Padding = Theme.Pad(24, 0, 24, 4), BackColor = Theme.Surface };
            holder.Controls.Add(box);
            holder.Controls.Add(foot);
            var buttons = new ButtonRow { Dock = DockStyle.Bottom };
            Button copy = buttons.Add(new ModernButton(Lang.T("کپی", "Copy"), ButtonKind.Primary) { MinimumSize = new Size(Theme.S(96), 0) });
            copy.Click += Copy;
            Button close = buttons.Add(new ModernButton(Lang.T("بستن", "Close"), ButtonKind.Secondary) { MinimumSize = new Size(Theme.S(96), 0) });
            close.Click += (s, e) => Close();
            buttons.AutoSize = false;
            buttons.Height = buttons.GetPreferredSize(Size.Empty).Height;
            Controls.Add(holder);
            Controls.Add(head);
            Controls.Add(buttons);
            AcceptButton = copy;
            CancelButton = close;
            Shown += (s, e) => { box.SelectionStart = 0; box.SelectionLength = 0; copy.Focus(); };
        }

        /// <summary>A font with letters of one width, so the lines of the text stay in line (Consolas on every Windows since Vista).</summary>
        internal static Font Mono()
        {
            foreach (string name in new[] { "Consolas", "DejaVu Sans Mono" })
                try
                {
                    var f = new Font(name, Theme.Font.SizeInPoints, FontStyle.Regular, GraphicsUnit.Point);
                    if (string.Equals(f.Name, name, StringComparison.OrdinalIgnoreCase)) return f;
                    f.Dispose();
                }
                catch { }
            return Theme.Font;
        }

        void Copy(object sender, EventArgs e)
        {
            try { Clipboard.SetDataObject(text, true, 5, 100); }
            catch (Exception ex)
            {
                Log.Write("day text copy: " + ex.Message);
                Ui.Message(this, Lang.T("کلیپ‌بورد ویندوز دست برنامه‌ی دیگری است. چند لحظه بعد دوباره «کپی» را بزنید.", "The Windows clipboard is held by another program. Press “Copy” again in a moment."), MessageBoxIcon.Warning);
                return;
            }
            note = Copied;
            foot.Invalidate();
        }

#if SNAPSHOT
        public void PreviewCopied() { note = Copied; foot.Invalidate(); }
#endif
    }

    /// <summary>A resizable window with read-only text (help, system check) and buttons under it.</summary>
    sealed class TextDialog : Form
    {
        public TextDialog(string title, string text, bool report)
        {
            Text = title;
            Font = Theme.Font;
            BackColor = Theme.Surface;
            ForeColor = Theme.Text;
            RightToLeft = Theme.Dir;
            RightToLeftLayout = false;  // the window frame stays as in every Windows program: buttons at the top right
            ShowInTaskbar = false;
            ShowIcon = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = Theme.Sz(720, 520);
            MinimumSize = Theme.Sz(460, 340);
            Theme.Window(this);

            var head = new Panel { Dock = DockStyle.Top, Height = Theme.S(64), BackColor = Theme.Surface };
            head.Paint += (s, e) => Theme.Line(e.Graphics, title, Theme.Heading, new Rectangle(Theme.S(28), Theme.S(18), head.Width - Theme.S(56), Theme.S(34)), Theme.Text);
            var box = new TextBox
            {
                Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill, Font = Theme.Font, ForeColor = Theme.Text,
                Text = text.Replace("\r\n", "\n").Replace("\n", "\r\n"), BackColor = Theme.Surface, BorderStyle = BorderStyle.None,
            };
            Theme.DarkParts(box);
            var holder = new Panel { Dock = DockStyle.Fill, Padding = Theme.Pad(28, 0, 20, 12), BackColor = Theme.Surface };
            holder.Controls.Add(box);
            var buttons = new ButtonRow { Dock = DockStyle.Bottom };
            Button close = buttons.Add(new ModernButton(Lang.T("بستن", "Close"), ButtonKind.Primary) { MinimumSize = new Size(Theme.S(96), 0) });
            close.Click += (s, e) => Close();
            if (report)
            {
                buttons.Add(new ModernButton(Lang.T("کپی متن", "Copy text"), (s, e) => { Clipboard.SetText(text); Ui.Message(this, Lang.T("متن کپی شد. آن را برای پشتیبانی بفرستید.", "The text was copied. Send it to support.")); }));
                buttons.Add(new ModernButton(Lang.T("باز کردن فایل گزارش", "Open log file"), (s, e) => Ui.OpenUrl(AppPaths.LogFile)));
            }
            buttons.AutoSize = false;
            buttons.Height = buttons.GetPreferredSize(Size.Empty).Height;
            Controls.Add(holder);
            Controls.Add(head);
            Controls.Add(buttons);
            AcceptButton = close;
            CancelButton = close;
            Shown += (s, e) => { box.SelectionStart = 0; box.SelectionLength = 0; close.Focus(); };
        }
    }

    // ================================================================= main window parts

    /// <summary>What to do when there is no copy yet.</summary>
    sealed class EmptyState : Panel
    {
        static string[] Steps { get { return new[]
        {
            Lang.T("یک بار متاتریدرِ بروکر (مثلاً WM Markets) را از سایت خودش نصب کنید.", "Install the broker's MetaTrader (e.g. WM Markets) once from its website."),
            Lang.T("«دانشجوی جدید» را بزنید: شماره حساب، رمز اینوستور و سرور.", "Press “New student”: account number, investor password and server."),
            Lang.T("روی «باز کردن» کنار نامش بزنید؛ با همان حساب باز می‌شود.", "Press “Open” next to the name; it opens with that account."),
        }; } }

        public readonly ModernButton Go, Restore;
        /// <summary>3.24: under the buttons, what «بازگردانی از فایل پشتیبان» brings back.</summary>
        static string RestoreNote { get { return Lang.T("اگر از کامپیوتر قبلی فایل پشتیبان دارید، همه‌ی دانشجوها، پوشه‌ها و گزارش‌ها با آن برمی‌گردند.", "If you have a backup file from the previous computer, all students, folders and reports come back with it."); } }

        public EmptyState(EventHandler addStudent, EventHandler restore)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Surface;
            Go = new ModernButton(Lang.T("دانشجوی جدید", "New student"), addStudent, ButtonKind.Primary, Glyph.UserAdd);
            Restore = new ModernButton(Lang.T("بازگردانی از فایل پشتیبان", "Restore from backup file"), restore, ButtonKind.Secondary);
            Controls.Add(Go);
            Controls.Add(Restore);
        }

        int StepsWidth { get { return Steps.Max(s => Theme.Measure(s, Theme.Font).Width) + Theme.S(40); } }
        int NoteHeight { get { return Theme.S(30); } }
        int Logo { get { return Height >= Theme.S(64 + 18 + 30 + 14 + 18 + 24) + Steps.Length * Theme.S(36) + Go.Height + NoteHeight ? Theme.S(64) : 0; } }
        int BlockHeight { get { return (Logo > 0 ? Logo + Theme.S(18) : 0) + Theme.S(30 + 14) + Steps.Length * Theme.S(36) + Theme.S(18) + Go.Height + NoteHeight; } }
        int Top0 { get { return Math.Max(Theme.S(8), (Height - BlockHeight) / 2); } }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            // The two side by side in the middle: «دانشجوی جدید» first (at the right), the restore beside it.
            int gap = Theme.S(16), total = Go.Width + gap + Restore.Width, y = Top0 + BlockHeight - NoteHeight - Go.Height;
            int x = (Width - total) / 2;
            Restore.Location = new Point(x, y + (Go.Height - Restore.Height) / 2);
            Go.Location = new Point(x + Restore.Width + gap, y);
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(BackColor);
            bool rtl = RightToLeft == RightToLeft.Yes;
            int y = Top0, logo = Logo;
            if (logo > 0)
            {
                Glyphs.Draw(g, Glyph.Logo, new RectangleF((Width - logo) / 2f, y, logo, logo), Theme.Accent);
                y += logo + Theme.S(18);
            }
            Theme.Line(g, Lang.T("هنوز نسخه‌ای ساخته نشده", "No copies made yet"), Theme.Heading, new Rectangle(0, y, Width, Theme.S(30)), Theme.Text, true);
            y += Theme.S(30 + 14);
            int w = Math.Min(StepsWidth, Width - Theme.S(32));
            int x0 = (Width - w) / 2, num = Theme.S(24);
            for (int k = 0; k < Steps.Length; k++)
            {
                int rowY = y + k * Theme.S(36);
                var circle = new RectangleF(rtl ? x0 + w - num : x0, rowY + (Theme.S(36) - num) / 2f, num, num);
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using (var b = new SolidBrush(Theme.AccentSoft)) g.FillEllipse(b, circle);
                Theme.Line(g, TextUtil.PersianDigits((k + 1).ToString(CultureInfo.InvariantCulture)), Theme.SmallBold, Rectangle.Round(circle), Theme.AccentText, true);
                var textRect = new Rectangle(rtl ? x0 : x0 + num + Theme.S(12), rowY, w - num - Theme.S(12), Theme.S(36));
                Theme.Line(g, Steps[k], Theme.Font, textRect, Theme.LabelColor);
            }
            Theme.Line(g, RestoreNote, Theme.Small, new Rectangle(Theme.S(16), Top0 + BlockHeight - NoteHeight + Theme.S(8), Width - Theme.S(32), Theme.S(22)), Theme.Muted, true);
        }
    }

    /// <summary>The main window: a dark band with the title, search and commands; under it the list of copies,
    /// each with its state, its total result and a button that opens (or shows) its MetaTrader.</summary>
    sealed partial class MainForm : Form
    {
        ImportCoordinator imports;
        readonly ReportRunSummary reportResults = new ReportRunSummary();
        bool isolateManualReports;
        readonly Dictionary<Kind, ulong> launchPeaks = new Dictionary<Kind, ulong>();
        int launchOpened, launchFailed;
        string launchMemoryWarning = "";
        readonly Dictionary<string, string> launchErrors = new Dictionary<string, string>();
        // Dependencies are replaceable by the queue integration checks; production uses the real OS/launcher.
        Func<Instance, StartResult> startTerminal;
        Func<ulong> launchTotalRam = Checks.TotalRamMb, launchFreeRam = Checks.FreeRamMb;
        Instance lastLaunched;
        void StopReports()
        {
            if (reportResults.Total == 0 || reportResults.Finished) return;
            reportResults.StopPending(); reportWork.Cancel();
            foreach (string name in readQueue) { Student student; if (students.TryGetValue(name, out student)) student.Queued = false; }
            readQueue.Clear();
            if (report != null) report.EndNow();
            else FinishReportResults();
            reportProgress.Set(reportWork, reportResults); SetStatus(Lang.T("در حال توقف گزارش‌گیری…", "Stopping report reading…"));
        }
        void FinishReportResults()
        {
            isolateManualReports = false;
            reportResults.End(); reportProgress.Set(reportWork, reportResults);
            try
            {
                string dir = Path.Combine(AppPaths.DataDir, "report-runs"); Directory.CreateDirectory(dir);
                reportResults.SavedPath = Path.Combine(dir, "reports-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 6) + ".xlsx");
                reportResults.Export(reportResults.SavedPath);
            }
            catch (Exception e) { Log.Write("report summary export: " + e.GetType().Name); }
            SetStatus(reportResults.Counts());
            CompleteScheduledReport();
        }
        void ReadResult(ReportRunner runner, ReportJob job, ReportRow row)
        {
            if (report != runner || appClosing) return;
            foreach (string encrypted in new[] { job.Account.MasterEnc, job.Account.InvestorEnc })
            {
                string password = Secret.Unprotect(encrypted);
                if (string.IsNullOrEmpty(password)) continue;
                if (row.Error != null) row.Error = row.Error.Replace(password, "***");
                if (row.Note != null) row.Note = row.Note.Replace(password, "***");
            }
            if (!reportResults.Record(job.Copy.Name, row)) return;
            CaptureScheduledJournal(job, row);
            Student student;
            if (students.TryGetValue(job.Copy.Name, out student))
            {
                student.Busy = student.Queued = false; student.Loaded = false;
                student.Error = row.Cached ? row.Note : row.Cancelled ? Lang.T("گزارش متوقف شد.", "Report stopped.") : row.Error;
            }
            if (!row.Cancelled) reportWork.Update(job.Copy.Name, row.Error == null && !row.Cached ? StepState.Done : row.Cached ? StepState.Skipped : StepState.Failed);
            reportProgress.Set(reportWork, reportResults); RefreshGrid(false);
        }
        readonly ReportWorkProgress reportWork = new ReportWorkProgress();
        readonly ReportProgressStrip reportProgress = new ReportProgressStrip { Dock = DockStyle.Bottom, Visible = false };
        bool preparingCopy;
        Func<bool> sandboxAvailable = () => SandboxLaunch.Available;
        volatile bool importChanged;
        readonly System.Windows.Forms.Timer importTimer = new System.Windows.Forms.Timer { Interval = 1000 };
        void ShowImportQueue()
        {
            if (imports == null) return;
            using (var d = new VerificationQueueDialog(accounts, imports)) d.ShowDialog(this);
        }
        sealed class Launch
        {
            public int Pid;
            public DateTime Time;
            public bool ClosedEarly;
            public bool NoWindow;
            /// <summary>When a terminal started by this program was found closed without being closed from here.</summary>
            public DateTime? ClosedAt;
            /// <summary>The journal is read for MetaTrader's own update from here on: the start, then the end of each update handled.</summary>
            public DateTime JournalFrom;
            /// <summary>Where MetaTrader's own update has got to (see FollowUpdate), and since when.</summary>
            public UpdateStep Update;
            public DateTime UpdateAt;
            /// <summary>When it was first found closed: its journal is read again for a few seconds, as it may be written just after.</summary>
            public DateTime? GoneAt;
            /// <summary>3.22.4: why it closed right after starting, from its own journal.</summary>
            public EarlyReason Early;
            /// <summary>3.27.3: the start file put back while MetaTrader updates itself (it starts again with the same /config), and when.</summary>
            public string LiveStartFile;
            public List<string> LiveStartupLines;
            public string UpdateFile;
            public DateTime UpdateFileAt;
        }

        enum UpdateStep
        {
            None,
            /// <summary>Closed to put a new build in place; MetaTrader starts it again by itself.</summary>
            Waiting,
            /// <summary>Started again by MetaTrader after its update (it logs in with the account it saved).</summary>
            Back,
            /// <summary>In the program's start queue.</summary>
            Queued,
        }

        // Copies to open again after MetaTrader updated itself (gathered while the list is described, started after),
        // and when each was last opened again that way: once in ten minutes at most, so it can never go round in circles.
        readonly List<Instance> reopenNow = new List<Instance>();
        readonly Dictionary<string, DateTime> reopenedAt = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

        Settings settings;
        readonly AccountStore accounts;
        List<Instance> copies = new List<Instance>();
        /// <summary>The copies the list shows now (after the view tab and the search).</summary>
        List<Instance> shown = new List<Instance>();
        readonly Dictionary<string, Launch> launches = new Dictionary<string, Launch>(StringComparer.OrdinalIgnoreCase);
        readonly Queue<Instance> startQueue = new Queue<Instance>();
        // Shared by the window and any window that replaces it, so no start file is forgotten.
        static List<PendingStart> pending = new List<PendingStart>();
        // Every second while a start file waits: it goes as soon as its terminal has read it (see Launcher.StartFileDone).
        readonly Timer pendingTimer = new Timer { Interval = 1000 };
        // Each running copy's journal is followed to tell whether its account logged in.
        readonly Dictionary<string, LoginWatch> watches = new Dictionary<string, LoginWatch>(StringComparer.OrdinalIgnoreCase);
        // A failed login stays visible after the terminal closes, until the copy is started again or its account edited.
        readonly Dictionary<string, LoginResult> lastFailure = new Dictionary<string, LoginResult>(StringComparer.OrdinalIgnoreCase);
        readonly SearchBox search = new SearchBox(Lang.T("جستجوی نام، شماره حساب یا سرور", "Search name, account or server"), 300, true);
        readonly Band band;
        readonly InfoBars infos = new InfoBars { Dock = DockStyle.Top };
        readonly Pivot pivot = new Pivot { Dock = DockStyle.Fill };
        /// <summary>3.23: «مرتب‌سازی» and «همه | MT4 | MT5», at the left of the tabs.</summary>
        readonly ListTools listTools = new ListTools { Dock = Lang.En ? DockStyle.Right : DockStyle.Left };
        readonly ListCard card = new ListCard { Dock = DockStyle.Fill };
        readonly CopyGrid grid = new CopyGrid { Dock = DockStyle.Fill };
        readonly EmptyState empty;
        readonly ContextMenuStrip rowMenu, toolsMenu;
        ToolStripMenuItem miOpen, miCheck, miCopyInvestor, miCopyMaster, miStartSelected, miStop, miForce, miRemove;
        // The copies ticked in the list's first column: "run" and "close" act on them alone when there are any.
        readonly Ticked chosen = new Ticked();
        BandButton runButton, stopButton, clearButton, folderButton;
        /// <summary>3.25 (approved mockup): the everyday commands, and those for the ticked students (with «N دانشجو انتخاب شده»).</summary>
        BandButton newButton, refreshButton, closeAllButton, readChosenButton, textButton, exportButton, toolsButton;
        BandPill choicePill;
        ContextMenuStrip newMenu, refreshMenu;
        readonly ToolTip tips = new ToolTip { InitialDelay = 500, ReshowDelay = 200, AutoPopDelay = 8000 };
        // The user's folders (a copy can be in several) and the row that chooses one to view.
        readonly FolderStore folders;
        readonly bool foldersReadable;
        readonly FolderBar folderBar = new FolderBar { Dock = DockStyle.Top };
        string folderKey;
        ToolStripMenuItem miAddTo, miReport;
        Panel body;
        readonly List<Control> lockWhileBusy = new List<Control>();
        readonly Timer refreshTimer = new Timer { Interval = 3000 };
        // 3.27.2 (CHANGE-023): every second, only which MetaTraders run (their process ids); a change redraws the list at once.
        readonly Timer watchTimer = new Timer { Interval = 1000 };
        string runningKey = "";
        readonly Timer startTimer = new Timer();
        readonly Timer clipTimer = new Timer { Interval = 30000 };
        string gridKey, bannerKey, clipboardSecret;
        DateTime statusUntil;
        int ticks, activeCount, openCount, inactiveCount, frontPid;
        // The terminal started last, watched until it is up so the next one can start (StartPace).
        Process pacing;
        DateTime pacingAt, lastStartAt;
        TimeSpan pacingCpu;
        bool busy;
#if SNAPSHOT
        readonly HashSet<string> fakeOn = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
#endif


        public MainForm(Settings settings, AccountStore accounts)
        {
            Launcher.PrepareLiveManual = LiveAutoStart.Prepare;
            startTerminal = i => Launcher.StartManual(i, settings, accounts);
            this.settings = settings;
            this.accounts = accounts;
            bool ok;
            folders = FolderStore.Load(out ok);
            foldersReadable = ok;
            Text = Ui.Title;
            Font = Theme.Font;
            ForeColor = Theme.Text;
            BackColor = Theme.Page;
            RightToLeft = Theme.Dir;
            RightToLeftLayout = false;  // the window frame stays as in every Windows program: buttons at the top right
            StartPosition = FormStartPosition.CenterScreen;
            KeyPreview = true;
            Icon = Art.AppIcon();
            Theme.Window(this, true);
            Rectangle area = Screen.PrimaryScreen.WorkingArea;
            ClientSize = new Size(Math.Min(Theme.S(1240), area.Width * 94 / 100), Math.Min(Theme.S(760), area.Height * 92 / 100));
            MinimumSize = new Size(Math.Min(Theme.S(900), area.Width * 9 / 10), Math.Min(Theme.S(560), area.Height * 9 / 10));
            if (area.Width <= Theme.S(1400)) WindowState = FormWindowState.Maximized;

            band = new Band(search) { Dock = DockStyle.Top, Title = Ui.Title };
            // 3.25 (approved mockup): with no one ticked, the everyday commands; with students ticked, the commands for them alone.
            newButton = Command(Lang.T("دانشجوی جدید", "New student"), Glyph.UserAdd, Theme.BandPrimaryText, AddStudent, true);
            newButton.Split = true;
            newMenu = BuildNewMenu();
            newButton.DropClicked += (s, e) => Guard(() => ShowUnder(newMenu, newButton));
            choicePill = band.Add(new BandPill { Visible = false });
            // 3.26 (CHANGE-017, approved): «انتخاب همه‌ی N» ticks every student of the list in view.
            choicePill.LinkClicked += (s, e) => Guard(() =>
            {
                if (chosen.State(shown.Select(c => c.Name)) != 2) chosen.ToggleAll(shown.Select(c => c.Name));
                RefreshGrid(false);
            });
            band.Separator();
            // 3.21: the report is inside the program: this reads the students of the list again.
            refreshButton = Command(Lang.T("به‌روزرسانی گزارش‌ها", "Refresh reports"), Glyph.Refresh, Color.FromArgb(0x9C, 0xC9, 0xF5), RefreshReports);
            refreshButton.Split = true;
            refreshButton.DropClicked += (s, e) => Guard(ShowRefreshMenu);
            runButton = Command(Lang.T("اجرا", "Run"), Glyph.Play, Color.FromArgb(0x6C, 0xCB, 0x5F), RunChosen);
            runButton.SetText(settings.ManualLiveReports?Lang.T("اجرا · زنده","Run · live"):Lang.T("اجرا · عادی","Run · ordinary"));
            runButton.Split=true;runButton.DropClicked+=(s,e)=>Guard(ShowLaunchModes);
            readChosenButton = Command(Lang.T("به‌روزرسانی گزارش", "Refresh report"), Glyph.Refresh, Color.FromArgb(0x9C, 0xC9, 0xF5), RefreshReports);
            textButton = Command(Lang.T("متن گزارش", "Report text"), Glyph.CopyText, Color.FromArgb(0x9C, 0xC9, 0xF5), ShowReportText);
            exportButton = Command(Lang.T("خروجی اکسل", "Export to Excel"), Glyph.Doc, Color.FromArgb(0x9C, 0xC9, 0xF5), ExportStudents);
            folderButton = Command(Lang.T("پوشه", "Folder"), Glyph.Folder, Color.FromArgb(0xE8, 0xC2, 0x5A), null);
            folderButton.Caret = true;
            folderButton.Click += (s, e) => Guard(ShowFolderCommands);
            closeAllButton = Command(Lang.T("بستن همه‌ی بازها", "Close all open"), Glyph.Stop, Color.FromArgb(0xC8, 0xC8, 0xC8), CloseAllOpen);
            band.Separator();
            // 3.26 (CHANGE-017, approved): «بستن» beside «لغو انتخاب», away from «اجرا», so it is not hit by mistake.
            stopButton = Command(Lang.T("بستن", "Close"), Glyph.Stop, Color.FromArgb(0xC8, 0xC8, 0xC8), StopChosen);
            clearButton = Command(Lang.T("لغو انتخاب", "Clear selection"), Glyph.Check, Theme.BandText, ClearChoice);
            clearButton.Note = "Esc";
            toolsButton = Command(Lang.T("ابزارها", "Tools"), Glyph.More, Theme.BandText, null, false, false);
            toolsMenu = BuildToolsMenu();
            toolsButton.Click += (s, e) => ShowUnder(toolsMenu, toolsButton);
            foreach (BandButton b in new[] { runButton, stopButton, readChosenButton, folderButton, closeAllButton, clearButton }) b.Visible = false;
            tips.SetToolTip(newButton, Lang.T("دانشجوی جدید؛ فلش کنارش: ساخت نسخه‌ها", "New student; the arrow: make copies"));
            tips.SetToolTip(refreshButton, Lang.T("خواندن دوباره‌ی گزارش همین فهرست؛ فلش کنارش: همه‌ی دانشجوها", "Read the reports of this list again; the arrow: all students"));
            tips.SetToolTip(closeAllButton, Lang.T("بستن همه‌ی متاتریدرهایی که این برنامه باز کرده", "Close every MetaTrader this program opened"));
            tips.SetToolTip(toolsButton, Lang.T("پشتیبان‌گیری، تنظیمات، راهنما و ابزارهای دیگر", "Backup, settings, help and other tools"));
            tips.SetToolTip(runButton, Lang.T("اجرا با حالت نوشته‌شده روی دکمه؛ فلش کنار آن: با گزارش زنده یا عادی بدون گزارش‌خوان", "Run in the mode shown on the button; arrow: live report EA or ordinary without report EA"));
            tips.SetToolTip(stopButton, Lang.T("بستن متاتریدرِ دانشجوهای انتخاب‌شده", "Close the MetaTrader of the selected students"));
            tips.SetToolTip(readChosenButton, Lang.T("خواندن دوباره‌ی گزارش دانشجوهای انتخاب‌شده", "Read the reports of the selected students again"));
            tips.SetToolTip(textButton, Lang.T("متن گزارش دانشجوهای انتخاب‌شده، برای تلگرام یا واتس‌اپ", "Report text of the selected students, for Telegram or WhatsApp"));
            tips.SetToolTip(exportButton, Lang.T("ذخیره‌ی اطلاعات همه‌ی دانشجوها در یک فایل Excel", "Save every student’s details in one Excel workbook"));
            tips.SetToolTip(folderButton, Lang.T("افزودن یا انتقال انتخاب‌شده‌ها به پوشه", "Add or move the selected students to a folder"));
            tips.SetToolTip(clearButton, Lang.T("برداشتن تیک همه (Esc)", "Untick all (Esc)"));
            search.Box.TextChanged += (s, e) => RefreshGrid(true);

            // 3.21: «فعال» and «غیرفعال» are about trading (a trade within 14 trading days); «باز» is MetaTrader open now.
            pivot.Add("all", Lang.T("همه", "All"));
            pivot.Add("on", Lang.T("فعال", "Active"));
            pivot.Add("off", Lang.T("غیرفعال · ۱۴ روز", "Inactive · 14d"));
            pivot.Add("open", Lang.T("باز", "Open"));
            pivot.Changed += key => RefreshGrid(true);

            rowMenu = BuildRowMenu();
            grid.OpenClicked += r => Guard(() => { Instance i = Find(r); if (i != null) OpenOrShow(i); });
            grid.CheckClicked += r => Guard(() => { chosen.Toggle(r.Name); RefreshGrid(false); });
            grid.CheckAllClicked += () => Guard(() => { chosen.ToggleAll(shown.Select(c => c.Name)); RefreshGrid(false); });
            grid.MenuWanted += (r, at) => Guard(() => ShowRowMenu(r, at));
            grid.RowClicked += r => Guard(() => OpenStudent(r));
            // 3.21.1: a student's report is a page of its own, with «بازگشت به فهرست».
            panel.PageMode = true;
            panel.BackColor = Theme.Page;
            panel.Dock = DockStyle.Fill;
            panel.Visible = true;
            panel.RangeWanted += k => Guard(() => PanelRangeWanted(k));
            panel.CustomWanted += (a, b) => Guard(() => PanelCustom(a, b));
            panel.RefreshWanted += () => Guard(PanelRefresh);
            panel.CopyWanted += () => Guard(CopyDayText);
            panel.HeightChanged += () => Guard(UpdatePanel);
            pageHeader.BackWanted += () => Guard(CloseStudent);
            pageHeader.PrevWanted += () => Guard(() => StepStudent(-1));
            pageHeader.NextWanted += () => Guard(() => StepStudent(1));
            studentPage.Controls.Add(panel);
            studentPage.Controls.Add(pageHeader);
            lockWhileBusy.Add(grid);

            empty = new EmptyState((s, e) => Guard(AddStudent), (s, e) => Guard(RestoreBackup)) { Dock = DockStyle.Fill, Visible = false };
            lockWhileBusy.Add(empty);
            card.Controls.Add(grid);
            card.Controls.Add(empty);
            body = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Page, Padding = new Padding(Theme.S(24), Theme.S(16), Theme.S(24), Theme.S(18)) };
            // Docking goes from the last one added: warnings on top, then the tabs, and the list fills the rest.
            body.Controls.Add(card);
            // Under the view tabs: the folders (with "+ پوشه‌ی جدید").
            body.Controls.Add(folderBar);
            folderBar.Changed += key => Guard(() => RefreshGrid(true));
            folderBar.AddWanted += () => Guard(() => NewFolder(null, false));
            folderBar.FolderMenuWanted += (key, at) => Guard(() => ShowFolderMenu(key, at));
            folderBar.MoreWanted += (keys, at) => Guard(() => ShowMoreFolders(keys, at));
            folderBar.AutoWanted += at => Guard(() => ChooseAuto(at));
            lockWhileBusy.Add(folderBar);
            // The view tabs.
            filters = new Panel { Dock = DockStyle.Top, Height = pivot.Height, BackColor = Theme.Page };
            filters.Controls.Add(pivot);
            listTools.Height = pivot.Height;
            listTools.Width = listTools.PreferredWidth;
            listTools.Platform = settings.Platform;
            listTools.PlatformChanged += p => Guard(() =>
            {
                settings.Platform = p;
                try { settings.Save(); } catch (Exception e) { Log.Write("settings: " + e.Message); }
                RefreshGrid(true);
            });
            listTools.SortWanted += at => Guard(() => ShowSortMenu(at));
            filters.Controls.Add(listTools);
            lockWhileBusy.Add(listTools);
            body.Controls.Add(filters);
            body.Controls.Add(infos);
            body.Controls.Add(studentPage);
            Controls.Add(body);
            Controls.Add(reportProgress);
            reportProgress.StopRequested += () => Guard(StopReports);
            grid.HeaderSortClicked += column => Guard(() => RefreshGrid(true));
            // Docked before the list: the counts along the bottom of the window.
            statusLine = new StatusLine { Dock = DockStyle.Bottom, Version = Lang.T("نسخه‌ی ", "Version ") + AppInfo.Version };
            Controls.Add(statusLine);
            Controls.Add(band);
            refreshTimer.Tick += (s, e) => Guard(Tick);
            watchTimer.Tick += (s, e) => Guard(WatchTick);
            startTimer.Tick += (s, e) => Guard(PaceTick);
            clipTimer.Tick += (s, e) => ClearSecret();
            pendingTimer.Tick += (s, e) => Guard(() => DeleteOldStartFiles(false));
            Shown += (s, e) => Guard(() =>
            {
                if (foldersReadable)
                {
                    bool readable; AccountStore.Load(out readable);
                    if (readable)
                    {
                        imports = new ImportCoordinator(settings, accounts, folders);
                        imports.Changed += () => importChanged = true;
                        try { imports.RecoverGroups(); } catch (Exception ex) { Log.Write("group recovery: " + ex.GetType().Name); }
                        imports.Start();
                        importTimer.Tick += (s1, e1) => { if (importChanged && !busy && !appClosing) { importChanged = false; RefreshGrid(false); } };
                        importTimer.Start();
                    }
                }
                // Opened from the setup or a shortcut, the window can land behind others: bring it forward.
                TopMost = true;
                TopMost = false;
                Activate();
                Log.Write("window shown (scale " + Theme.Scale.ToString("0.##", CultureInfo.InvariantCulture) + ", font " + Theme.Family + ")");
                if (pending.Count == 0) Launcher.DeleteLeftovers(Installs.Copies(settings));
                try { ReportCopies.DeleteLeftovers(settings); } catch (Exception ex) { Log.Write("report leftovers: " + ex.Message); }
                try { Owned.AdoptFromLog(Installs.Copies(settings), Processes.Running()); }
                catch (Exception ex) { Log.Write("opened list: " + ex.Message); }
                RefreshAll(true);
                refreshTimer.Start();
                watchTimer.Start();
                InitializeSchedule();
                grid.Focus();
            });
            KeyDown += (s, e) =>
            {
                if (e.Control && e.KeyCode == Keys.N) { Guard(AddStudent); e.Handled = true; }
                else if (e.Control && e.KeyCode == Keys.F) { search.Box.Focus(); e.Handled = true; }
                else if (e.KeyCode == Keys.F1) { ShowHelp(); e.Handled = true; }
                else if (e.KeyCode == Keys.F5) { Guard(() => RefreshAll(true)); e.Handled = true; }
                else if (e.KeyCode == Keys.Delete && grid.Focused) { Guard(RemoveCopies); e.Handled = true; }
                else if (e.Control && e.KeyCode == Keys.A && grid.Focused) { Guard(() => { chosen.ToggleAll(shown.Select(c => c.Name)); RefreshGrid(false); }); e.Handled = true; }
                else if ((e.KeyCode == Keys.Escape || e.KeyCode == Keys.BrowserBack || (e.Alt && e.KeyCode == Keys.Left)) && pageName != null) { Guard(CloseStudent); e.Handled = true; }
                else if (e.KeyCode == Keys.Escape && chosen.Count > 0 && !search.Box.Focused) { Guard(ClearChoice); e.Handled = true; }
            };
            FormClosing += OnClosing;
        }

        // ------------------------------------------------------------- layout

        BandButton Command(string text, Glyph icon, Color iconColor, Action action, bool primary = false, bool lockBusy = true)
        {
            var b = new BandButton(text, icon, iconColor, primary);
            if (action != null) b.Click += (s, e) => Guard(action);
            band.Add(b);
            if (lockBusy) lockWhileBusy.Add(b);
            return b;
        }

        ToolStripMenuItem Item(ContextMenuStrip menu, string text, Action action, bool danger = false)
        {
            // An item that only opens a submenu has no action of its own.
            ToolStripMenuItem i = Theme.Item(menu, text, (s, e) => { if (action != null) Guard(action); });
            if (danger) i.Tag = "danger";
            return i;
        }

        ContextMenuStrip BuildToolsMenu()
        {
            ContextMenuStrip m = Theme.Menu();
            Item(m, Lang.T("پایش زندهٔ حساب‌های باز…", "Live monitoring of open accounts…"), ShowLiveMonitoring);
            Theme.Separator(m);
            Item(m, Lang.T("زمان‌بندی و ارسال گزارش…", "Schedule and delivery…"), EditSchedule);
            Item(m, Lang.T("گزارش تازه و ارسال به مقصدها اکنون", "Read fresh reports and send now"), RunScheduledNow);
            Item(m, Lang.T("آخرین گزارش و وضعیت ارسال…", "Last automated report and delivery…"), ShowScheduledReport);
            Theme.Separator(m);
            Item(m, Lang.T("بررسی اتصال دانشجوها…", "Student connection checks…"), ShowImportQueue);
            Theme.Separator(m);
            // 3.24 (approved): backup and restore, on top.
            Item(m, Lang.T("پشتیبان‌گیری…", "Backup…"), MakeBackup);
            Item(m, Lang.T("بازگردانی از پشتیبان…", "Restore from backup…"), RestoreBackup);
            Theme.Separator(m);
            Item(m, Lang.T("باز کردن پوشه‌ی نسخه‌ها", "Open the copies folder"), OpenFolder);
            Theme.Separator(m);
            Item(m, Lang.T("تنظیم حافظهٔ پنجره‌های ویندوز…", "Windows desktop heap setting…"), FixHeap);
            Item(m, Lang.T("پاکسازی فایل‌های غیرلازم نسخه‌ها…", "Clean up unneeded files of the copies…"), CleanupCopies);
            Item(m, Lang.T("بررسی سیستم و عیب‌یابی", "System check and troubleshooting"), ShowReport);
            Item(m, Lang.T("خروجی عیب‌یابی گزارش‌ها…", "Export report diagnostics…"), ExportReportDiagnostics);
            Theme.Separator(m);
            Item(m, Lang.T("تنظیمات…", "Settings…"), EditSettings);
            Item(m, Lang.T("راهنما (F1)", "Help (F1)"), ShowHelp);
            Item(m, Lang.T("درباره‌ی برنامه", "About"), () => Ui.Message(this, Ui.Title + Lang.T("\nنسخه‌ی ", "\nVersion ") + AppInfo.Version + Lang.T("\n\nفونت: وزیرمتن (Vazirmatn، مجوز SIL Open Font License)", "\n\nFont: Vazirmatn (SIL Open Font License)")));
            return m;
        }

        /// <summary>A band command's menu, under it, its right edge on the command's.</summary>
        static void ShowUnder(ContextMenuStrip m, Control c)
        {
            m.Show(c, new Point(c.Width, c.Height + Theme.S(4)), ToolStripDropDownDirection.BelowLeft);
        }

        /// <summary>3.25: the «▾» of «دانشجوی جدید».</summary>
        ContextMenuStrip BuildNewMenu()
        {
            ContextMenuStrip m = Theme.Menu();
            ToolStripMenuItem add = Item(m, Lang.T("دانشجوی جدید…", "New student…"), AddStudent);
            add.ShortcutKeyDisplayString = "Ctrl+N";
            Item(m, Lang.T("افزودن گروهی از Excel…", "Add students from Excel…"), ImportStudents);
            Item(m, Lang.T("ساخت نسخه‌ها (بدون حساب)…", "Make copies (no account)…"), CreateCopies);
            return m;
        }

        /// <summary>3.25: the «▾» of «به‌روزرسانی گزارش‌ها»: this list (as the button), or every student; and when they were read last.</summary>
        void ShowRefreshMenu()
        {
            if (refreshMenu != null) refreshMenu.Dispose();
            ContextMenuStrip m = refreshMenu = Theme.Menu();
            Func<IEnumerable<Instance>, int> people = list => list.Count(c => { Account a = accounts.Get(c.Name); return a != null && a.HasLogin; });
            Item(m, Lang.T("همین فهرست (", "This list (") + Fa.N(people(shown)) + Lang.T(" نفر)", " students)"), RefreshReports);
            Item(m, Lang.T("همه‌ی دانشجوها (", "All students (") + Fa.N(people(copies)) + Lang.T(" نفر)", " students)"), () => ReadMany(copies.ToList(), Lang.T("همه‌ی دانشجوها", "All students")));
            Theme.Separator(m);
            Item(m, Lang.T("پایش زندهٔ حساب‌های باز…", "Live monitoring of open accounts…"), ShowLiveMonitoring);
            DateTime last = LastRead(copies);
            if (last != DateTime.MinValue)
            {
                Theme.Separator(m);
                ToolStripMenuItem when = Item(m, Lang.T("آخرین خواندن: ", "Last read: ") + When(last), null);
                when.Enabled = false;
            }
            ShowUnder(m, refreshButton);
        }

        /// <summary>The latest read of any of these students (this computer's clock); MinValue when none was read.</summary>
        DateTime LastRead(IEnumerable<Instance> list)
        {
            DateTime last = DateTime.MinValue;
            foreach (Instance c in list)
            {
                Student st;
                if (students.TryGetValue(c.Name, out st) && st.FileTime > last) last = st.FileTime;
            }
            return last;
        }

        /// <summary>«امروز ۱۰:۰۲»، «دیروز ۱۸:۲۰»، or the date.</summary>
        static string When(DateTime t)
        {
            string hm = TextUtil.PersianDigits(t.ToString("HH:mm", CultureInfo.InvariantCulture));
            if (t.Date == DateTime.Today) return Lang.T("امروز ", "Today ") + hm;
            if (t.Date == DateTime.Today.AddDays(-1)) return Lang.T("دیروز ", "Yesterday ") + hm;
            return Gd.Date(t) + " " + hm;
        }

        /// <summary>3.25: «بستن همه‌ی بازها (N)»: every MetaTrader this program opened closes (and the start queue empties); one opened any
        /// other way stays open, and the user is told.</summary>
        void CloseAllOpen()
        {
            Dictionary<string, Process> running = Processes.Running();
            List<Instance> open = copies.Where(i => Processes.IsRunning(running, i.Exe)).ToList();
            if (open.Count == 0 && startQueue.Count == 0) { SetStatus(Lang.T("هیچ متاتریدری باز نیست.", "No MetaTrader is open.")); return; }
            if (open.Count > 0 && !Ui.Confirm(this, Lang.T("همه‌ی متاتریدرهای باز (", "Close all open MetaTraders (") + Fa.N(open.Count) + Lang.T(") بسته شوند؟\n\nهر کدام اول چارت‌ها و تنظیماتش را ذخیره می‌کند. متاتریدری که خودتان یا برنامه‌ی دیگری باز کرده باز می‌ماند.", ")?\n\nEach first saves its charts and settings. A MetaTrader opened by you or another program stays open.")))
                return;
            startQueue.Clear();
            startTimer.Stop();
            bannerKey = null;
            if (open.Count == 0) { SetStatus(Lang.T("صف اجرا خالی شد.", "The start queue is empty.")); RefreshGrid(false); return; }
            Stop(open, false);
        }

        ToolStripMenuItem miCopyGroup, miStopGroup;

        /// <summary>3.26 (CHANGE-006B, approved): a menu item with its small icon at the right.</summary>
        ToolStripMenuItem IconItem(ToolStripItemCollection items, string text, Glyph glyph, Action action, string tag = null)
        {
            var i = new FluentMenuItem(text) { Padding = Theme.Pad(8, 2), ForeColor = Theme.Text, ImageScaling = ToolStripItemImageScaling.None };
            if (glyph != Glyph.None)
                i.Image = Theme.MenuIcon(glyph, tag == "danger" ? Theme.Bad : glyph == Glyph.Folder || glyph == Glyph.FolderMove ? Color.FromArgb(0xC2, 0x8A, 0x0E) : Theme.Muted);
            if (tag != null) i.Tag = tag;
            if (action != null) i.Click += (s, e) => Guard(action);
            items.Add(i);
            return i;
        }

        static void StyleDrop(ToolStripMenuItem parent)
        {
            var drop = (ToolStripDropDownMenu)parent.DropDown;
            drop.ShowCheckMargin = false;
            drop.ShowImageMargin = true;
            drop.ImageScalingSize = new Size(Theme.S(16), Theme.S(16));
            drop.RightToLeft = Theme.Dir;
            drop.Font = Theme.Font;
            drop.Renderer = new FluentRenderer();
            drop.BackColor = Theme.Surface;
            drop.Padding = Theme.Pad(4, 4);
        }

        /// <summary>3.26 (CHANGE-006B, approved): ten items in groups with icons; the three copies, the folder commands and the two ways to
        /// close each in a submenu. Every command does what it did.</summary>
        ContextMenuStrip BuildRowMenu()
        {
            ContextMenuStrip m = Theme.Menu();
            m.ShowImageMargin = true;
            m.ImageScalingSize = new Size(Theme.S(16), Theme.S(16));
            ToolStripItemCollection items = m.Items;
            miOpen = IconItem(items, Lang.T("باز کردن متاتریدر", "Open MetaTrader"), Glyph.Play, () => { Instance i = OneSelected(); if (i != null) OpenOrShow(i); });
            miStartSelected = IconItem(items, Lang.T("باز کردن متاتریدرِ انتخاب‌شده‌ها", "Open the MetaTrader of the selected"), Glyph.Play, () => Enqueue(Selected()));
            miCheck = IconItem(items, Lang.T("بررسی اتصال", "Check connection"), Glyph.Plug, () => { Instance i = OneSelected(); if (i != null) CheckConnection(i, false); });
            IconItem(items, Lang.T("حساب و رمز…", "Account and password…"), Glyph.Key, EditAccount);
            Theme.Separator(m);
            miReport = IconItem(items, Lang.T("به‌روزرسانی گزارش", "Refresh report"), Glyph.Refresh, () => ReadThese(Selected(), Lang.T("انتخاب‌شده", "Selected")));
            miAddTo = IconItem(items, Lang.T("افزودن به پوشه", "Add to folder"), Glyph.Folder, null);
            StyleDrop(miAddTo);
            miCopyGroup = IconItem(items, Lang.T("کپی", "Copy"), Glyph.Copies, null);
            StyleDrop(miCopyGroup);
            IconItem(miCopyGroup.DropDownItems, Lang.T("کپی شماره حساب", "Copy account number"), Glyph.Copies, () => CopyValue("login"));
            miCopyInvestor = IconItem(miCopyGroup.DropDownItems, Lang.T("کپی رمز اینوستور", "Copy investor password"), Glyph.Copies, () => CopyValue("investor"));
            miCopyMaster = IconItem(miCopyGroup.DropDownItems, Lang.T("کپی رمز اصلی", "Copy master password"), Glyph.Copies, () => CopyValue("master"));
            IconItem(items, Lang.T("باز کردن پوشه‌ی نسخه", "Open copy folder"), Glyph.Folder, () => { Instance i = OneSelected(); if (i != null) Ui.OpenUrl(i.Dir); });
            Theme.Separator(m);
            miStopGroup = IconItem(items, Lang.T("بستن", "Close"), Glyph.Stop, null);
            StyleDrop(miStopGroup);
            miStop = IconItem(miStopGroup.DropDownItems, Lang.T("بستن متاتریدر", "Close MetaTrader"), Glyph.Stop, () => Stop(Selected(), false));
            miForce = IconItem(miStopGroup.DropDownItems, Lang.T("بستن اجباری", "Force close"), Glyph.Stop, () => Stop(Selected(), true));
            miRemove = IconItem(items, Lang.T("حذف نسخه…", "Delete copy…"), Glyph.Trash, RemoveCopies, "danger");
            return m;
        }

        void ShowRowMenu(CopyRow r, Point screen)
        {
            // The menu is for the row it was opened on; on a ticked row, the group-wide items act on all the ticked ones.
            if (!grid.SelectedCopies.Any(x => x.Name == r.Name))
            {
                grid.ClearSelection();
                foreach (DataGridViewRow row in grid.Rows)
                    if (row.Tag is CopyRow && ((CopyRow)row.Tag).Name == r.Name) { row.Selected = true; break; }
            }
            int count = Selected().Count;
            Account a = accounts.Get(r.Name);
            string many = " (" + Fa.N(count) + Lang.T(" انتخاب‌شده)", " selected)");
            miOpen.Text = r.Running ? Lang.T("نمایش متاتریدر", "Show MetaTrader") : Lang.T("باز کردن متاتریدر", "Open MetaTrader");
            if (miOpen.Image != null) miOpen.Image.Dispose();
            miOpen.Image = Theme.MenuIcon(r.Running ? Glyph.Window : Glyph.Play, Theme.Muted);
            miOpen.Visible = count <= 1;
            miStartSelected.Text = Lang.T("باز کردن متاتریدرِ انتخاب‌شده‌ها", "Open the MetaTrader of the selected") + many;
            miStartSelected.Visible = count > 1;
            miStop.Text = count > 1 ? Lang.T("بستن متاتریدرِ انتخاب‌شده‌ها", "Close the MetaTrader of the selected") + many : Lang.T("بستن متاتریدر", "Close MetaTrader");
            miForce.Text = count > 1 ? Lang.T("بستن اجباریِ انتخاب‌شده‌ها", "Force close the selected") + many : Lang.T("بستن اجباری", "Force close");
            miRemove.Text = count > 1 ? Lang.T("حذف نسخه‌های انتخاب‌شده", "Delete the selected copies") + many + "…" : Lang.T("حذف نسخه…", "Delete copy…");
            miReport.Text = count > 1 ? Lang.T("به‌روزرسانی گزارش انتخاب‌شده‌ها", "Refresh the report of the selected") + many : Lang.T("به‌روزرسانی گزارش", "Refresh report");
            miReport.Visible = count > 1 || (a != null && a.HasLogin);
            List<Instance> targets = Selected();
            FillFolderItems(miAddTo, targets, false);
            // For the row the menu was opened on, also when it is one of several ticked.
            miCheck.Visible = a != null && a.HasLogin;
            miCopyInvestor.Visible = a != null && a.HasLogin && Secret.Unprotect(a.InvestorEnc) != null && a.InvestorEnc.Length > 0;
            miCopyMaster.Visible = a != null && a.HasLogin && !a.IsInvestor && a.MasterEnc.Length > 0;
            miStopGroup.Text = count > 1 ? Lang.T("بستن", "Close") + many : Lang.T("بستن", "Close");
            Point local = grid.PointToClient(screen);
            rowMenu.Show(grid, local, local.X < grid.Width / 3 ? ToolStripDropDownDirection.BelowRight : ToolStripDropDownDirection.BelowLeft);
        }

        // ------------------------------------------------------------- refresh

        void Guard(Action action)
        {
            try { action(); }
            catch (Exception e) { Ui.Error(this, e); }
        }

        /// <summary>A message under the title for a few seconds; then the counts come back.</summary>
        void SetStatus(string text)
        {
            statusUntil = DateTime.Now.AddSeconds(8);
            band.Sub = text;
        }

        StatusLine statusLine;

        /// <summary>The counts in the line at the bottom (3.17); under the title only messages, for a few seconds.</summary>
        void ShowCounts()
        {
            if (statusLine != null)
                statusLine.Line = Lang.T("تعداد کل دانشجویان: ", "Students: ") + Fa.N(copies.Count) + Lang.T("  |  باز: ", "  |  Open: ") + Fa.N(openCount) + Lang.T("  |  فعال: ", "  |  Active: ") + Fa.N(activeCount) +
                    Lang.T("  |  غیرفعال: ", "  |  Inactive: ") + Fa.N(inactiveCount) + Lang.T("  |  انتخاب‌شده: ", "  |  Selected: ") + Fa.N(chosen.Count) +
                    (startQueue.Count > 0 ? Lang.T("  |  در صف اجرا: ", "  |  In start queue: ") + Fa.N(startQueue.Count) : "") +
                    (reading.Count + readQueue.Count > 0 ? Lang.T("  |  خواندن گزارش: ", "  |  Reading reports: ") + Fa.N(reading.Count + readQueue.Count) + Lang.T(" نفر", " students") : "") + AutoLine();
            if (statusLine != null)
            {
                Color dot;
                string backup = BackupLine(out dot);
                statusLine.SetLeft(backup, dot);
            }
            if (DateTime.Now < statusUntil) return;
            band.Sub = copies.Count == 0 ? Lang.T("هنوز نسخه‌ای ساخته نشده", "No copies made yet") : "";
        }

        /// <summary>3.25 (approved): «آخرین پشتیبان: امروز ۹:۳۰» at the start of the bottom line; green, or orange when there is none or the
        /// last is more than three days old. A daily check that found nothing changed counts: the file held the list as it was then.</summary>
        string BackupLine(out Color dot)
        {
            DateTime last = settings.LastBackup;
            if (settings.BackupAuto && settings.BackupChecked > last) last = settings.BackupChecked;
            if (last == DateTime.MinValue) { dot = Theme.Warn; return Lang.T("پشتیبان: هنوز گرفته نشده", "Backup: none yet"); }
            dot = (DateTime.Now - last).TotalDays > 3 ? Theme.Warn : Theme.Ok;
            return Lang.T("آخرین پشتیبان: ", "Last backup: ") + When(last);
        }

        /// <summary>3.27.2 (CHANGE-023): which MetaTraders run, as their process ids: cheap (no paths, no files). When it changes, the
        /// list is drawn again now instead of at the next three-second look, so «باز است» shows as soon as a MetaTrader opens.</summary>
        void WatchTick()
        {
            bool liveChanged=DashboardTick();
            string key = Processes.RunningKey();
            if (key == runningKey && !liveChanged) return;
            runningKey = key;
            RefreshGrid(false);
            UpdatePanel();
        }

        void Tick()
        {
            try
            {
                ticks++;
                FollowClosing();
                DeleteOldStartFiles(false);
                RefreshGrid(false);
                UpdatePanel();
                if (ticks % 10 == 0) { UpdateBanner(); AutoRefreshTick(); }
                if (ticks % 5 == 0) AutoCleanup();
                if (ticks % 20 == 0) DailyBackupTick();
                if (settings.TrimMemory && ticks % 40 == 0) TrimMinimized();
            }
            catch (Exception e) { Log.Write("refresh: " + e.Message); }
        }

        /// <summary>Every two minutes: the memory of the minimized MetaTraders this program opened goes back to Windows.
        /// A terminal takes back what it needs when it is used again; nothing is lost.</summary>
        void TrimMinimized()
        {
            Dictionary<string, Process> running = Processes.Running();
            try
            {
            HashSet<string> mine = Owned.Mine(running);
            var livePaths=new HashSet<string>(copies.Where(c=>LiveChartPolicy.HasPreservedCharts(c)).Select(c=>c.Exe.ToLowerInvariant()),StringComparer.OrdinalIgnoreCase);
            int n = 0;
            foreach (KeyValuePair<string, Process> p in running)
                if (mine.Contains(p.Key) && !livePaths.Contains(p.Key) && Native.TrimIfMinimized(p.Value)) n++;
            if (n > 0 && ticks % 400 == 0) Log.Write("memory of " + n + " minimized terminals handed back to Windows");
            }
            finally { foreach (Process process in running.Values) process.Dispose(); }
        }

        void RefreshAll(bool rebuild)
        {
            RefreshGrid(rebuild);
            UpdateBanner();
        }

        Instance Find(CopyRow r) { return r == null ? null : copies.FirstOrDefault(c => c.Name == r.Name); }

        /// <summary>The state of one copy and its account: nothing more.</summary>
        CopyRow Describe(Instance i, Dictionary<string, Process> running, DateTime now)
        {
            var r = new CopyRow { Name = i.Name, Kind = i.Kind.ToString() };
            Account a = accounts.Get(i.Name);
            bool has = a != null && a.HasLogin;
            r.HasAccount = has; r.MasterLogin = has && !a.IsInvestor;
            r.Trader = has ? (a.Trader.Length > 0 ? a.Trader : a.Login) : Lang.T("بدون حساب", "No account");
            r.Login = has ? a.Login : "";
            r.Server = has ? a.Server : "";
            Process p;
            bool on = running.TryGetValue(i.Exe.ToLowerInvariant(), out p);
#if SNAPSHOT
            if (fakeOn.Contains(i.Name)) on = true;
#endif
            r.Running = on;
            r.Checked = chosen.Has(i.Name);
            r.Folders = folders.Of(i.Name).Select(f => f.Name).ToArray();
            Launch l;
            launches.TryGetValue(i.Name, out l);
            if (l != null) FollowUpdate(i, l, on, p, now);
            bool updating = l != null && l.Update != UpdateStep.None;
            if (on)
            {
                if (l != null && l.ClosedAt.HasValue) l.ClosedAt = null;  // open again (e.g. after updating itself)
                // A terminal still without a window after two minutes needs investigation; count alone is not a cause.
                // Under a heavy start (or while it updates itself) a window can come later: then the mark goes away.
                if (p != null && l != null && !updating && (now - l.Time).TotalSeconds > 120)
                {
                    try
                    {
                        bool none = p.MainWindowHandle == IntPtr.Zero;
                        if (none && !l.NoWindow)
                        {
                            l.NoWindow = true;
                            Log.Write(i.Name + " runs without a window");
                            bannerKey = null;
                        }
                        else if (!none && l.NoWindow)
                        {
                            l.NoWindow = false;
                            Log.Write(i.Name + " has its window now");
                            bannerKey = null;
                        }
                    }
                    catch { }
                }
                if (closing != null && closing.Any(c => c.Name == i.Name)) Set(r, RowState.Pending, Lang.T("در حال بستن…", "Closing…"));
                else if (updating) Set(r, RowState.Pending, Lang.T("در حال به‌روزرسانی…", "Updating…"));
                else if (has && StudentOf(i).LiveCurrent) Set(r, RowState.Open, Lang.T("باز است", "Open"));
                else if (l != null && l.NoWindow) Set(r, RowState.Bad, Lang.T("پنجره باز نشد", "Window did not open"));
                else if (!has) Set(r, RowState.Open, Lang.T("باز است", "Open"));
                else Show(r, LoginState(i, a, l, now));
                if (has) r.Activity = StudentOf(i).Activity;
            }
            else
            {
                watches.Remove(i.Name);
                if (l != null && !updating && !l.ClosedEarly && (now - l.Time).TotalSeconds < 60 && (now - l.Time).TotalSeconds > 4)
                {
                    // Started by us a moment ago and already gone.
                    l.ClosedEarly = true;
                    l.GoneAt = now;
                    // 3.22.4: why, from its own journal (it may still be written for a few seconds: read again below).
                    l.Early = Explained(i, a, l);
                    Log.Write(i.Name + " closed right after starting: " + l.Early.En);
                    bannerKey = null;
                }
                else if (l != null && l.ClosedEarly && l.GoneAt.HasValue && (now - l.GoneAt.Value).TotalSeconds <= 15 &&
                         (l.Early == null || l.Early.Kind == EarlyKind.Unknown))
                {
                    EarlyReason again = Explained(i, a, l);
                    if (again.Kind != EarlyKind.Unknown)
                    {
                        l.Early = again;
                        Log.Write(i.Name + ": the reason it closed, written just after: " + again.En);
                        bannerKey = null;
                    }
                }
                else if (l != null && !updating && !l.ClosedEarly && !l.ClosedAt.HasValue && (now - l.Time).TotalSeconds >= 60)
                {
                    // It ran, and now it is closed although nothing here closed it (its own window or an error).
                    l.ClosedAt = now;
                    l.GoneAt = now;
                    l.NoWindow = false;
                    Log.Write(i.Name + " closed (not from this program)");
                }
                LoginResult failed;
                if (updating) Set(r, RowState.Pending, Lang.T("در حال به‌روزرسانی…", "Updating…"));
                else if (launchErrors.ContainsKey(i.Name)) Set(r, RowState.Bad, Lang.T("اجرا نشد: ", "Launch failed: ") + launchErrors[i.Name]);
                else if (l != null && l.ClosedEarly) Set(r, l.Early != null && l.Early.Kind == EarlyKind.LoggedIn ? RowState.Warn : RowState.Bad, l.Early != null ? l.Early.Short : Lang.T("باز نشد", "Did not open"));
                else if (lastFailure.TryGetValue(i.Name, out failed)) Show(r, failed);
                else if (l != null && l.ClosedAt.HasValue)
                    Set(r, RowState.Warn, Lang.T("بسته شد ", "Closed ") + (l.ClosedAt.Value.Date == now.Date
                        ? TextUtil.PersianDigits(l.ClosedAt.Value.ToString("HH:mm", CultureInfo.InvariantCulture)) : Fa.At(l.ClosedAt.Value)));
                else if (!has) Set(r, RowState.Off, "—");
                else
                {
                    // 3.21: closed, the status is the student's trading: inactive after 14 trading days without a trade.
                    Activity act = StudentOf(i).Activity;
                    r.Activity = act;
                    if (act == Activity.Inactive) Set(r, RowState.Inactive, Lang.T("غیرفعال · ۱۴ روز", "Inactive · 14d"));
                    else if (act == Activity.Active) Set(r, RowState.Active, Lang.T("فعال", "Active"));
                    else if (StudentOf(i).Journal != null) Set(r, RowState.Warn, Lang.T("فعالیت نامشخص", "Activity unknown"));
                    else Set(r, RowState.Off, Lang.T("خوانده نشده", "Not read"));
                }
            }
            if (has) Today(i, r, now);
            if (!on && a != null && a.VerifyState.Length > 0 && l == null)
            {
                // Once history establishes activity, the normal active/inactive badge takes precedence over a past login ACK.
                if (a.VerifyState != "connected" || r.Activity == Activity.Unknown)
                    Set(r, a.VerifyState == "connected" ? RowState.Active : a.VerifyState == "rejected" ? RowState.Bad : RowState.Pending, ImportCoordinator.Status(a.VerifyState));
            }
            if (has)
            {
                Student state = StudentOf(i);
                if (state.Busy || state.Queued) Set(r, RowState.Pending, Lang.T("در حال گزارش‌گیری", "Reading report"));
                else if (state.Error != null && !(on && state.LiveCurrent)) Set(r, RowState.Warn, Lang.T("نیاز به بررسی", "Needs review"));
            }
            return r;
        }

        /// <summary>3.21: the «امروز» cell of a student's row.</summary>
        void Today(Instance i, CopyRow r, DateTime now)
        {
            Student st = StudentOf(i);
            if (st.Busy) { r.TodayBusy = true; r.TodayAgo = st.Step ?? Lang.T("در حال خواندن…", "Reading…"); return; }
            if (st.Queued) { r.TodayBusy = true; r.TodayAgo = Lang.T("در صف خواندن…", "Waiting to read…"); return; }
            if(st.LivePending)
            {
                var current=st.LiveFeed;
                r.TodayNone=current==null || current.Positions.Count==0;
                r.TodayHasTrades=current!=null && current.Positions.Count>0;
                if(r.TodayHasTrades)
                {
                    double floating=current.Positions.Sum(p=>p.Profit+p.Swap+(current.Platform=="MT4"?p.Commission:0));
                    r.TodayText="O/"+(floating>0?"+":"")+floating.ToString("0.##",CultureInfo.InvariantCulture)+"/"+(current.Positions.Any(p=>p.Sl<=0)?"No SL":"SL")+"/DD?";
                    r.TodayTone=floating>0?1:floating<0?-1:0;r.TodayNoSl=current.Positions.Any(p=>p.Sl<=0);
                }
                else r.TodayText=Lang.T("معاملهٔ بازی نیست؛ تاریخچه هنوز تأیید نشده", "No open positions; history not verified yet");
                r.TodayAgo=Lang.T("زنده · تاریخچه در حال همگام‌سازی", "Live · history synchronizing");
                r.TodayTip=st.LiveNotice+"\r\n"+Lang.T("فقط اطلاعات معاملات باز تازه است؛ نتیجهٔ معاملات بسته و دراودان هنوز تأیید نشده‌اند.","Only open-position data is current; closed results and drawdown are not verified yet.");return;
            }
            string ago = st.FileTime != DateTime.MinValue ? PanelMath.Ago(st.FileTime, now) : "";
            if(st.LiveCurrent)ago=Lang.T("زنده · ","Live · ")+ago;
            else if(!string.IsNullOrEmpty(st.LiveNotice))ago=Lang.T("آخرین گزارش · ","Last report · ")+ago;

            if (st.Today == null || st.Journal.Exported < st.TodayFor)
            {
                // Not read, or read before the server's day began: nothing is known of today yet.
                r.TodayNone = true;
                r.TodayFailed = st.Error != null;
                r.TodayText = st.Error != null ? ShortError(st.Error) : st.Today == null ? Lang.T("خوانده نشده", "Not read") : Lang.T("امروز هنوز خوانده نشده", "Not read today yet");
                r.TodayTip = st.Error != null ? Lang.T("خوانده نشد: ", "Not read: ") + st.Error : st.LiveNotice ?? "";
                r.TodayAgo = !st.LiveCurrent && !string.IsNullOrEmpty(st.LiveNotice) ? st.LiveNotice : ago;
                return;
            }
            r.TodayText = PanelMath.Short(st.Today);
            r.TodayNone = st.Today.TradeCount == 0;
            r.TodayHasTrades = st.Today.Closed > 0 || st.Today.Open > 0;
            double net = Math.Round(st.Today.Net, 2); r.TodayNet = net;
            r.TodayTone = net > 0 ? 1 : net < 0 ? -1 : 0;
            r.TodayNoSl = st.Today.NoSl > 0;
            r.TodayFailed = st.Error != null;
            r.TodayAgo = st.Error != null ? Lang.T("خوانده نشد (", "Not read (") + ago + ")" : ago;
            r.TodayTip = (st.LiveNotice ?? "")+"\r\n"+r.TodayText + "\r\n" + PanelMath.SummaryDetail(st.Today)
                + (st.Error != null ? "\r\n" + Lang.T("خوانده نشد: ", "Not read: ") + st.Error : "");
        }

        /// <summary>3.26 (CHANGE-003): the «امروز» cell's short words for a reading that failed; the whole message is in its tip.
        /// Only what is shown changes, not the error itself.</summary>
        internal static string ShortError(string error)
        {
            // 3.27: the message may have been written in either language.
            if (error.StartsWith("ورود نشد", StringComparison.Ordinal) || error.StartsWith("Login failed", StringComparison.Ordinal)) return Lang.T("ورود نشد: رمز یا حساب اشتباه", "Login failed: wrong password or account");
            return Lang.T("خوانده نشد: ", "Not read: ") + error;
        }

        static void Set(CopyRow r, RowState state, string text)
        {
            r.State = state;
            r.Status = text;
        }

        static void Show(CopyRow r, LoginResult login)
        {
            switch (login.State)
            {
                case Login.Connected:
                    // 3.21: open is «باز است» (logged in: green and bold); «فعال» is about trading.
                    if (login.Detail == "assumed") Set(r, RowState.Open, Lang.T("باز است", "Open"));
                    else Set(r, RowState.On, Lang.T("باز است", "Open"));
                    break;
                case Login.WrongLogin: Set(r, RowState.Bad, Lang.T("رمز یا حساب اشتباه", "Wrong login")); break;
                case Login.NoServer: Set(r, RowState.Bad, Lang.T("سرور پیدا نشد", "Server not found")); break;
                case Login.NoConnection: Set(r, RowState.Warn, Lang.T("بدون اتصال", "No connection")); break;
                default: Set(r, RowState.Pending, Lang.T("در حال اتصال…", "Connecting…")); break;
            }
        }

        /// <summary>Did the account of a running copy log in? Told by the terminal's journal.</summary>
        LoginResult LoginState(Instance i, Account a, Launch l, DateTime now)
        {
#if SNAPSHOT
            if (fakeOn.Contains(i.Name)) return new LoginResult { State = Login.Connected };
#endif
            LoginWatch w;
            if (!watches.TryGetValue(i.Name, out w)) watches[i.Name] = w = new LoginWatch();
            LoginResult j = w.Update(i, a.Login, l != null ? l.Time : now.Date, now);
            if (j.State == Login.WrongLogin || j.State == Login.NoServer)
            {
                lastFailure[i.Name] = j;
                return j;
            }
            if (j.State != Login.Waiting) return j;
            // 3.27.2 (CHANGE-023): nothing decisive in the journal yet: its MetaTrader runs, so it is open at once (no «در حال اتصال…»
            // for up to two minutes). A wrong password or server, once the journal says so, still turns it red.
            return new LoginResult { State = Login.Connected, Detail = "assumed" };
        }

        bool Matches(Instance i, string query)
        {
            if (query.Length == 0) return true;
            Account a = accounts.Get(i.Name);
            bool has = a != null && a.HasLogin;
            return ServerCatalog.Norm(i.Name + " " + (has ? a.Trader + " " + a.Login + " " + a.Server : "")).Contains(query);
        }

        void RefreshGrid(bool rebuild)
        {
            // 3.21: in the order set by dragging the rows (new copies after, by name).
            copies = ListOrder.Apply(StudentDirectory.All(settings, accounts), c => c.Name, order);
            chosen.Keep(copies.Select(c => c.Name));
            Dictionary<string, Process> running = Processes.Running();
            DateTime now = DateTime.Now;
            var rows = new Dictionary<string, CopyRow>(StringComparer.OrdinalIgnoreCase);
            try { foreach (Instance i in copies) rows[i.Name] = Describe(i, running, now); }
            finally { foreach (Process process in running.Values) process.Dispose(); }
            if (reopenNow.Count > 0)
            {
                var again = reopenNow.ToList();
                reopenNow.Clear();
                StartAgain(again);
            }
            // 3.21: open: its MetaTrader runs; active: a student who traded within 14 trading days (or not read yet); inactive: no trade for longer.
            Func<CopyRow, bool> open = r => r.Running;
            Func<CopyRow, bool> active = r => r.HasAccount && r.Activity == Activity.Active && !r.TodayFailed;
            Func<CopyRow, bool> inactive = r => r.HasAccount && r.Activity == Activity.Inactive && !r.TodayFailed;
            openCount = rows.Values.Count(open);
            activeCount = rows.Values.Count(active);
            inactiveCount = rows.Values.Count(inactive);

            string view = pivot.Selected ?? "all";
            string query = ServerCatalog.Norm(search.Box.Text);
            Func<CopyRow, bool> inView = r => view == "all" || (view == "open" ? open(r) : view == "on" ? active(r) : inactive(r));
            ShowFolders();
            Func<Instance, bool> inFolder = InFolder(folderBar.Selected);
            // 3.23: «همه | MT4 | MT5».
            string platform = listTools.Platform;
            Func<Instance, bool> onPlatform = i => platform == "all" || string.Equals(i.Kind.ToString(), platform, StringComparison.OrdinalIgnoreCase);
            shown = copies.Where(i => inFolder(i) && onPlatform(i) && inView(rows[i.Name]) && Matches(i, query)).ToList();
            var sortedRows = DashboardSort.Apply(shown.Select(i => rows[i.Name]), grid.HeaderSortColumn, grid.HeaderSortDirection);
            var byName = shown.ToDictionary(i => i.Name, StringComparer.OrdinalIgnoreCase);
            shown = sortedRows.Select(r => byName[r.Name]).ToList();
            string key = view + "|" + folderBar.Selected + "|" + platform + "|" + query + "|" + string.Join("|", shown.Select(c => c.Name));
            if (rebuild || key != gridKey)
            {
                var keep = new HashSet<string>(grid.SelectedCopies.Select(r => r.Name), StringComparer.OrdinalIgnoreCase);
                CopyRow focused = grid.CurrentRow == null ? null : grid.CurrentRow.Tag as CopyRow;
                int firstVisible = Math.Max(0, grid.FirstDisplayedScrollingRowIndex);
                grid.Rows.Clear();
                foreach (Instance i in shown) grid.SetRow(grid.Rows.Add(), rows[i.Name]);
                if (focused != null)
                {
                    DataGridViewRow focusedRow = grid.Rows.Cast<DataGridViewRow>().FirstOrDefault(row => ((CopyRow)row.Tag).Name == focused.Name);
                    if (focusedRow != null) grid.CurrentCell = focusedRow.Cells["Trader"];
                }
                if (grid.Rows.Count > 0) grid.FirstDisplayedScrollingRowIndex = Math.Min(firstVisible, grid.Rows.Count - 1);
                grid.ClearSelection();
                foreach (DataGridViewRow r in grid.Rows) if (keep.Contains(((CopyRow)r.Tag).Name)) r.Selected = true;
                gridKey = key;
            }
            for (int n = 0; n < shown.Count && n < grid.Rows.Count; n++) grid.SetRow(n, rows[shown[n].Name]);
            empty.Visible = copies.Count == 0;
            grid.Visible = copies.Count > 0;
            bool folderEmpty = folderBar.Selected != FolderBar.AllKey && !copies.Any(inFolder);
            grid.EmptyText = query.Length > 0 ? Lang.T("چیزی با این جستجو پیدا نشد.", "Nothing matches this search.")
                           : platform != "all" && !copies.Any(i => inFolder(i) && onPlatform(i)) ? Lang.T("در این فهرست نسخه‌ی ", "There is no ") + platform + Lang.T(" نیست. «همه» را بزنید تا همه دیده شوند.", " copy in this list. Press “All” to see all of them.")
                           : folderEmpty && folderBar.Selected == FolderBar.NoneKey ? Lang.T("همه در پوشه‌ای هستند.", "Everyone is in a folder.")
                           : folderEmpty ? Lang.T("این پوشه هنوز خالی است. دانشجوها را تیک بزنید و از «پوشه‌ها» یا منوی «⋯» به آن اضافه کنید.", "This folder is still empty. Tick students and add them from “Folders” or the “⋯” menu.")
                           : view == "open" ? Lang.T("الان هیچ متاتریدری باز نیست.", "No MetaTrader is open right now.")
                           : view == "on" ? Lang.T("دانشجوی فعالی در این فهرست نیست.", "No active student in this list.") : Lang.T("دانشجوی غیرفعالی نیست (همه در ۱۴ روز معاملاتی گذشته ترید داشته‌اند).", "No inactive student (all traded in the past 14 trading days).");
            // The view tabs count within the folder being viewed (and the platform shown).
            List<CopyRow> inThis = copies.Where(i => inFolder(i) && onPlatform(i)).Select(i => rows[i.Name]).ToList();
            pivot.Count("all", inThis.Count);
            pivot.Count("on", inThis.Count(active));
            pivot.Count("off", inThis.Count(inactive));
            pivot.Count("open", inThis.Count(open));
            // The folder viewed: its reading again by itself, at the far left of the folder row.
            Folder viewedFolder = ViewedFolder();
            string autoText = viewedFolder == null ? null : Lang.T("به‌روزرسانی خودکار: ", "Auto refresh: ") + AutoRefresh.Text(AutoRefresh.Of(viewedFolder)) + "  ▾";
            bool autoOn = viewedFolder != null && AutoRefresh.Of(viewedFolder) > 0;
            if (autoText != folderBar.AutoText || autoOn != folderBar.AutoOn) { folderBar.AutoText = autoText; folderBar.AutoOn = autoOn; folderBar.Invalidate(); }
            ShowChoice();
            ShowCounts();
            if (bannerKey == null) UpdateBanner();
        }

        void UpdateBanner()
        {
            int? heap = Heap.Current();
            bool installs = copies.Count > 0 || Installs.Find(Kind.MT5, settings).Count > 0 || Installs.Find(Kind.MT4, settings).Count > 0;
            List<Issue> list = Checks.Quick(settings, copies, accounts, heap, installs);
            int early = launches.Values.Count(l => l.ClosedEarly);
            int noWindow = launches.Values.Count(l => l.NoWindow);
            // 3.22.4: one copy, with a reason found in its journal: the reason itself in the banner.
            KeyValuePair<string, Launch>? one = null;
            if (early == 1)
            {
                KeyValuePair<string, Launch> e = launches.First(x => x.Value.ClosedEarly);
                if (e.Value.Early != null && e.Value.Early.Kind != EarlyKind.Unknown) one = e;
            }
            if (early + noWindow > 0)
            {
                // A reason read from the journal is the reason: no guess about the window limit beside it.
                list.Insert(0, new Issue
                {
                    Text = (early == 1 && one != null ? Lang.T("متاتریدرِ «", "The MetaTrader of “") + WhoIs(one.Value.Key) + Lang.T("» بلافاصله بعد از اجرا بسته شد. ", "” closed right after it started. ") + one.Value.Value.Early.Text + " " :
                            early > 0 ? Fa.N(early) + Lang.T(" نسخه بلافاصله بعد از اجرا بسته شد. ", " copies closed right after they started. ") : "") + (noWindow > 0 ? Fa.N(noWindow) + Lang.T(" نسخه بدون پنجره اجرا شد. ", " copies ran without a window. ") : "") +
                           (one != null && noWindow == 0 ? "" : Lang.T("جزئیات در «بررسی سیستم» است.", "Details are in “System check”.")),
                    Fix = Fix.Report,
                    FixText = Lang.T("بررسی سیستم", "System check"),
                });
            }
            if (!string.IsNullOrEmpty(launchMemoryWarning))
                list.Insert(0, new Issue { Text = launchMemoryWarning, Fix = Fix.Report, FixText = Lang.T("جزئیات", "Details") });
            string key = string.Join("\n", list.Select(x => x.Text));
            if (key == bannerKey) return;
            bannerKey = key;
            infos.Show(list, fix => Guard(() => RunFix(fix)));
        }

        void RunFix(Fix fix)
        {
            switch (fix)
            {
                case Fix.Create: CreateCopies(); break;
                case Fix.Heap: FixHeap(); break;
                case Fix.Settings: EditSettings(); break;
                case Fix.Report: ShowReport(); break;
                case Fix.Cleanup: CleanupCopies(); break;
            }
        }

        // ------------------------------------------------------------- selection

        /// <summary>The ticked copies, in the list's order.</summary>
        List<Instance> Chosen() { return copies.Where(c => chosen.Has(c.Name)).ToList(); }

        /// <summary>What a row action acts on: all the ticked copies when the marked row is one of them (or no row is marked),
        /// otherwise the marked row alone.</summary>
        List<Instance> Selected()
        {
            CopyRow current = grid.SelectedCopies.FirstOrDefault();
            if (chosen.Count > 0 && (current == null || chosen.Has(current.Name))) return Chosen();
            return current == null ? new List<Instance>() : copies.Where(c => c.Name == current.Name).ToList();
        }

        /// <summary>The marked row, for actions on one copy (account, password, folder).</summary>
        Instance OneSelected()
        {
            CopyRow current = grid.SelectedCopies.FirstOrDefault();
            List<Instance> sel = current == null ? new List<Instance>() : copies.Where(c => c.Name == current.Name).ToList();
            if (sel.Count == 0)
            {
                Ui.Message(this, copies.Count == 0 ? Lang.T("هنوز نسخه‌ای ساخته نشده. اول «دانشجوی جدید» یا «ساخت نسخه‌ها» را بزنید.", "No copies made yet. First press “New student” or “Make copies”.") : Lang.T("اول یک ردیف را در فهرست انتخاب کنید.", "First select a row in the list."));
                return null;
            }
            return sel[0];
        }

        // ------------------------------------------------------------- actions

        /// <summary>The row's main button: opens the copy's MetaTrader with its account, or brings it forward when it is open.</summary>
        void OpenOrShow(Instance i)
        {
            Process p;
            Dictionary<string, Process> running = Processes.Running();
            if (running.TryGetValue(i.Exe.ToLowerInvariant(), out p))
            {
                if (!TerminalWindow.Bring(p)) SetStatus(Lang.T("متاتریدرِ ", "The MetaTrader of ") + i.Name + Lang.T(" هنوز پنجره‌اش را باز نکرده؛ چند ثانیه بعد دوباره بزنید.", " has not opened its window yet; press again in a few seconds."));
                // Only a MetaTrader this program opened (and lowered) has its priority changed.
                else if (settings.LowPriority && Owned.Mine(running).Contains(i.Exe.ToLowerInvariant())) Front(p);
                return;
            }
            if (Updating(i)) { SetStatus(Lang.T("متاتریدرِ ", "The MetaTrader of ") + i.Name + Lang.T(" در حال به‌روزرسانی خودش است و چند ثانیه‌ی دیگر خودش باز می‌شود.", " is updating itself and opens by itself in a few seconds.")); return; }
            Enqueue(new List<Instance> { i });
        }

        /// <summary>The MetaTrader brought to front runs at normal priority; the one in front before goes back to below normal.</summary>
        void Front(Process p)
        {
            try { p.PriorityClass = ProcessPriorityClass.Normal; } catch { }
            if (frontPid != 0 && frontPid != p.Id)
                try { Process.GetProcessById(frontPid).PriorityClass = ProcessPriorityClass.BelowNormal; } catch { }
            frontPid = p.Id;
        }

        /// <summary>Opens the copy when it is closed and shows whether the login worked; offers to fix the account and try again.</summary>
        void CheckConnection(Instance i, bool justAdded)
        {
            Account acc = accounts.Get(i.Name);
            if (acc == null || !acc.HasLogin) { Ui.Message(this, Lang.T("برای این نسخه هنوز حسابی ثبت نشده.", "No account is saved for this copy yet.")); return; }
            if (imports != null && acc.VerifyState.Length > 0)
            { imports.Recheck(i.Name); ShowImportQueue(); return; }
            while (true)
            {
                DateTime since = DateTime.Now;
                if (!Processes.IsRunning(Processes.Running(), i.Exe)) Enqueue(new List<Instance> { i });
                else since = DateTime.Now.AddHours(-1);
                ConnectionDialog d;
                using (d = new ConnectionDialog(i, acc, since)) d.ShowDialog(this);
                if (d.WantsShow) { OpenOrShow(i); return; }
                if (!d.WantsEdit) return;
                // Fix the account, then close this copy and try again.
                using (var e = new AccountDialog(i, accounts, settings)) if (e.ShowDialog(this) != DialogResult.OK) return;
                acc = accounts.Get(i.Name);
                lastFailure.Remove(i.Name);
                if (Processes.IsRunning(Processes.Running(), i.Exe))
                {
                    Launcher.CloseReport r = Launcher.Close(new[] { i }, false);
                    if (r.NotOurs.Count > 0)
                    {
                        Ui.Message(this, Lang.T("حساب ذخیره شد.\n\nمتاتریدرِ ", "Account saved.\n\nThe MetaTrader of ") + i.Name + Lang.T(" را این برنامه باز نکرده، پس از این‌جا بسته نمی‌شود. خودتان ببندیدش و دوباره «بررسی اتصال» را بزنید تا با حساب تازه باز شود.", " was not opened by this program, so it is not closed from here. Close it yourself and press “Check connection” again so it opens with the new account."));
                        return;
                    }
                    SetStatus(Lang.T("در حال بستن ", "Closing ") + i.Name + Lang.T(" تا با حساب تازه باز شود…", " so it opens with the new account…"));
                    DateTime asked = DateTime.Now;
                    while ((DateTime.Now - asked).TotalSeconds < Launcher.CloseWaitSeconds && Processes.IsRunning(Processes.Running(), i.Exe))
                    {
                        Application.DoEvents();
                        System.Threading.Thread.Sleep(250);
                    }
                    if (Processes.IsRunning(Processes.Running(), i.Exe)) Launcher.Close(new[] { i }, true);
                }
                Launch gone;
                if (launches.TryGetValue(i.Name, out gone)) DropUpdateFile(gone);
                launches.Remove(i.Name);
            }
        }

        void ImportStudents()
        {
            if (busy) return;
            if (imports == null) { Ui.Message(this, Lang.T("صف بررسی آماده نیست؛ فایل‌های داده را بررسی کنید.", "The verification queue is not ready; check the data files.")); return; }
            if (!foldersReadable) { Ui.Message(this, Lang.T("فایل پوشه‌ها خوانده نشد؛ پیش از ورود گروهی مشکل فایل داده را برطرف کنید.", "The folders file could not be read; resolve the data-file problem before importing."), MessageBoxIcon.Warning); return; }
            bool readable;
            AccountStore.Load(out readable);
            if (!readable) { Ui.Message(this, Lang.T("فایل حساب‌ها خوانده نشد؛ پیش از ورود گروهی مشکل فایل داده را برطرف کنید.", "The accounts file could not be read; resolve the data-file problem before importing."), MessageBoxIcon.Warning); return; }
            if (backupRunning || report != null || startQueue.Count > 0 || pending.Count > 0)
            {
                Ui.Message(this, Lang.T("صبر کنید عملیات فعلی برنامه تمام شود، سپس ورود گروهی را باز کنید.", "Wait for the current operation to finish, then open bulk import."));
                return;
            }
            // The modal worker owns the stores during import; timers must not enumerate or save them concurrently.
            refreshTimer.Stop(); watchTimer.Stop(); startTimer.Stop();
            SetBusy(true);
            try
            {
                Folder viewed = ViewedFolder();
                using (var d = new StudentImportDialog(settings, accounts, folders, viewed == null ? "" : viewed.Name, imports))
                {
                    d.ShowDialog(this);
                    foreach (StudentImportRow row in d.Results.Where(r => r.Saved))
                    {
                        if (row.State == ImportState.Failed)
                            lastFailure[row.Copy] = new LoginResult { State = row.Outcome == Login.Waiting ? Login.NoConnection : row.Outcome, Detail = row.Reason };
                        else if (row.State == ImportState.Connected) lastFailure.Remove(row.Copy);
                    }
                }
            }
            finally
            {
                SetBusy(false);
                refreshTimer.Start(); watchTimer.Start(); startTimer.Start();
                RefreshAll(true);
            }
        }

        void ExportStudents()
        {
            if (busy) return;
            var all = StudentDirectory.All(settings, accounts);
            int count = accounts.All.Select(a => a.Instance).Concat(all.Select(c => c.Name)).Distinct(StringComparer.OrdinalIgnoreCase).Count();
            if (count == 0) { Ui.Message(this, Lang.T("هنوز دانشجویی برای خروجی وجود ندارد.", "There are no students to export yet.")); return; }
            using (var options = new StudentExportDialog(count))
            {
                if (options.ShowDialog(this) != DialogResult.OK) return;
                using (var save = new SaveFileDialog { Filter = "Excel Workbook (*.xlsx)|*.xlsx", FileName = "MetaFactory-students-" + DateTime.Now.ToString("yyyy-MM-dd") + ".xlsx", DefaultExt = "xlsx" })
                {
                    if (save.ShowDialog(this) != DialogResult.OK) return;
                    var data = StudentExport.Rows(all, accounts, folders, options.IncludePasswords);
                    try { StudentExport.Write(save.FileName, data, options.IncludePasswords); }
                    finally { foreach (var row in data.Skip(1)) { row[4] = ""; row[9] = ""; } }
                    SetStatus(Fa.N(count) + Lang.T(" دانشجو در Excel ذخیره شد.", " students saved to Excel."));
                }
            }
        }

        void ExportReportDiagnostics()
        {
            if (!ReportDiagnostics.HasLatest)
            {
                Ui.Message(this, Lang.T("هنوز گزارش عیب‌یابی ثبت نشده است؛ یک نوبت گزارش‌گیری اجرا کنید.", "No report diagnostics have been recorded yet; run a report first."));
                return;
            }
            using (var save = new SaveFileDialog { Filter = "Diagnostics ZIP (*.zip)|*.zip", DefaultExt = "zip", FileName = "MetaFactory-report-diagnostics-" + DateTime.Now.ToString("yyyy-MM-dd-HHmm") + ".zip" })
            {
                if (save.ShowDialog(this) != DialogResult.OK) return;
                ReportDiagnostics.ExportLatest(save.FileName);
                SetStatus(Lang.T("گزارش عیب‌یابی ذخیره شد؛ این فایل را برای بررسی ارسال کنید.", "Report diagnostics saved; share this file for investigation."));
            }
        }

        void AddStudent()
        {
            if (busy) return;
            StudentDialog d;
            using (d = new StudentDialog(accounts, settings))
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
            }
            bool sure;
            string source = ServerCatalog.InstallFor(d.Kind, d.Server, settings, out sure);
            if (source == null)
            {
                Ui.Message(this, d.Kind + Lang.T(" روی این ویندوز نصب نیست. یک بار ", " is not installed on this Windows. Install the ") + d.Kind + Lang.T("ِ بروکر این دانشجو را از سایت خود بروکر نصب کنید و دوباره امتحان کنید.", " of this student's broker once from the broker's own website and try again."), MessageBoxIcon.Warning);
                return;
            }
            Log.Write("student " + d.Login + " on " + d.Server + ": copy from " + source + (sure ? " (the broker's own install)" : " (no install of this broker found)"));
            List<string> made;
            SetStatus(Lang.T("در حال ساختن نسخه برای ", "Making a copy for ") + d.StudentName + "…");
            band.Refresh();
            Cursor = Cursors.WaitCursor;
            settings.UseFolder(d.Folder);
            settings.Save();
            try { made = CopyMaker.Create(new CreateRequest { Kind = d.Kind, Source = source, Count = 1, Prefix = d.Kind.ToString(), CopyData = false, Folder = d.Folder }, settings, null); }
            finally { Cursor = Cursors.Default; }
            string name = made[0];
            accounts.Set(new Account
            {
                Instance = name, Trader = d.StudentName, Login = d.Login, Server = d.Server, Mode = d.Mode,
                MasterEnc = Secret.Protect(d.Master), InvestorEnc = Secret.Protect(d.Investor),
            });
            accounts.Save();
            Log.Write("student added: " + name + " (" + d.Login + ")");
            // Added while a folder is viewed: the new student goes into it.
            Folder into = ViewedFolder();
            if (into != null)
            {
                folders.Add(into.Id, new[] { name });
                SaveFolders();
            }
            RefreshAll(true);
            SetStatus(d.StudentName + Lang.T(" اضافه شد (نسخه‌ی ", " added (copy ") + name + ")" + (into != null ? Lang.T("، در پوشه‌ی «", ", in folder “") + into.Name + "»." : "."));
            Instance inst = copies.FirstOrDefault(c => c.Name == name);
            if (inst != null) CheckConnection(inst, true);
        }

        // ------------------------------------------------------------- 3.24: backup and restore (approved mockup)

        readonly DateTime openedAt = DateTime.Now;
        bool backupRunning;
        DateTime lastBackupTry = DateTime.MinValue;

        BackupData GatherBackup(bool journals = true) { return BackupStore.Gather(settings, accounts, folders, copies.Select(c => c.Name).ToList(), copies, journals); }

        /// <summary>Written beside its name first, so a write cut off never leaves half a backup under the real name.</summary>
        static long WriteBackup(string dir, string name, byte[] data)
        {
            Directory.CreateDirectory(dir);
            string path = Path.Combine(dir, name), part = path + ".part";
            File.WriteAllBytes(part, data);
            if (File.Exists(path)) File.Delete(path);
            File.Move(part, path);
            return data.LongLength;
        }

        void MakeBackup()
        {
            if (busy) return;
            BackupData d = GatherBackup();
            if (d.Students.Count == 0) { Ui.Message(this, Lang.T("هنوز دانشجویی نیست که پشتیبان بخواهد.", "There are no students yet to back up.")); return; }
            string password, dir;
            bool auto;
            using (var dlg = new BackupDialog(d, settings))
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                password = dlg.Password;
                dir = dlg.Folder;
                auto = dlg.Auto;
            }
            string name = AutoBackup.HandName(DateTime.Now, n => File.Exists(Path.Combine(dir, n)));
            long size;
            Cursor = Cursors.WaitCursor;
            try { size = WriteBackup(dir, name, BackupFormat.Make(d, password)); }
            catch (Exception e)
            {
                Log.Write("backup: " + e.Message);
                Ui.Message(this, Lang.T("فایل پشتیبان ساخته نشد: ", "The backup file was not made: ") + e.Message, MessageBoxIcon.Warning);
                return;
            }
            finally { Cursor = Cursors.Default; }
            settings.BackupDir = dir;
            settings.BackupAuto = auto;
            settings.BackupPasswordEnc = Secret.Protect(password);
            settings.LastBackup = DateTime.Now;
            // The daily file is looked at again soon (a new folder or password: it is written there with it).
            settings.BackupChecked = DateTime.MinValue;
            settings.BackupFingerprint = "";
            lastBackupTry = DateTime.MinValue;
            settings.Save();
            string path = Path.Combine(dir, name);
            Log.Write("backup made: " + path + " (" + d.Students.Count + " students, " + size + " bytes)" + (auto ? ", daily backup on" : ""));
            SetStatus(Lang.T("فایل پشتیبان ساخته شد: ", "Backup file made: ") + path);
            Ui.Message(this, Lang.T("فایل پشتیبان ساخته شد:\n", "Backup file made:\n") + path + "\n(" + TextUtil.Size(size) + Lang.T("، ", ", ") + Fa.N(d.Students.Count) + Lang.T(" دانشجو)\n\n", " students)\n\n") +
                (auto ? Lang.T("پشتیبان خودکار هم روشن است: هر روز اگر چیزی عوض شده باشد، فایل ", "Automatic backup is on too: every day, if something changed, the file ") + AutoBackup.MainName + Lang.T(" در همین پوشه به‌روز می‌شود.\n\n", " in this folder is updated.\n\n") : "") +
                Lang.T("رمز فایل را فراموش نکنید؛ بدون آن، فایل باز نمی‌شود.", "Do not forget the file password; without it the file cannot be opened."));
        }

        sealed class DailyResult
        {
            public bool Written;
            public string Fingerprint;
            public long Size;
        }

        /// <summary>3.24.1: once a day, a few minutes after the program opened, in the background: whether anything changed since the daily
        /// backup was written; only then is it written again (the one before kept as the previous one). A folder that is not there
        /// (a flash drive not plugged in) is tried again an hour later.</summary>
        void DailyBackupTick()
        {
            if (backupRunning || busy || (DateTime.Now - openedAt).TotalMinutes < 3 || (DateTime.Now - lastBackupTry).TotalMinutes < 60) return;
            string password = Secret.Unprotect(settings.BackupPasswordEnc ?? "");
            if (!AutoBackup.Due(settings.BackupAuto, settings.BackupDir, !string.IsNullOrEmpty(password), settings.BackupChecked, DateTime.Now)) return;
            lastBackupTry = DateTime.Now;
            BackupData d;
            try { d = GatherBackup(false); }
            catch (Exception e) { Log.Write("daily backup: " + e.Message); return; }
            string dir = settings.BackupDir, known = settings.BackupFingerprint ?? "";
            backupRunning = true;
            var worker = new BackgroundWorker();
            worker.DoWork += (s, e) =>
            {
                string root = Path.GetPathRoot(Path.GetFullPath(dir));
                if (!string.IsNullOrEmpty(root) && !Directory.Exists(root)) throw new IOException("the drive is not there (" + root + ")");
                BackupStore.AddJournals(d);
                var r = new DailyResult { Fingerprint = AutoBackup.Fingerprint(d) };
                string main = Path.Combine(dir, AutoBackup.MainName);
                if (r.Fingerprint == known && File.Exists(main)) { e.Result = r; return; }
                byte[] data = BackupFormat.Make(d, password);
                Directory.CreateDirectory(dir);
                if (File.Exists(main)) File.Copy(main, Path.Combine(dir, AutoBackup.PreviousName), true);
                r.Size = WriteBackup(dir, AutoBackup.MainName, data);
                r.Written = true;
                e.Result = r;
            };
            worker.RunWorkerCompleted += (s, e) =>
            {
                backupRunning = false;
                if (e.Error != null)
                {
                    Log.Write("daily backup not made: " + e.Error.Message);
                    SetStatus(Lang.T("پشتیبان خودکار به‌روز نشد: پوشه‌ی ", "The automatic backup was not updated: folder ") + dir + Lang.T(" در دسترس نیست (مثلاً فلش وصل نیست). یک ساعت دیگر دوباره امتحان می‌شود.", " is not available (e.g. the USB stick is not connected). It is tried again in an hour."));
                    return;
                }
                var r = (DailyResult)e.Result;
                settings.BackupChecked = DateTime.Now;
                settings.BackupFingerprint = r.Fingerprint;
                if (r.Written) settings.LastBackup = DateTime.Now;
                try { settings.Save(); } catch (Exception ex) { Log.Write("settings: " + ex.Message); }
                Log.Write(r.Written ? "daily backup written: " + Path.Combine(dir, AutoBackup.MainName) + " (" + d.Students.Count + " students, " + r.Size + " bytes)"
                                    : "daily backup: nothing changed since " + settings.LastBackup.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture));
            };
            worker.RunWorkerAsync();
        }

        void RestoreBackup()
        {
            if (busy) return;
            BackupData d;
            RestorePlan plan;
            string password, folder;
            using (var dlg = new RestoreDialog(settings, accounts))
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                d = dlg.Data;
                plan = dlg.Plan;
                password = dlg.Password;
                folder = CopyMaker.CheckFolder(dlg.Folder);
            }
            RunRestore(d, plan, password, folder);
        }

        /// <summary>Copies are made for the students to add (in the background, one by one, from the MetaTrader of their broker when it is
        /// installed); then their accounts, the folders, the order, the report history and, on a computer without students, the settings.
        /// Nothing here is removed; what is here is first kept in a backup of its own (DataDir\backup\before-restore).</summary>
        void RunRestore(BackupData d, RestorePlan plan, string password, string folder)
        {
            bool fresh = !accounts.All.Any(a => a.HasLogin);
            if (!fresh)
            {
                try
                {
                    string dir = Path.Combine(DataSchema.BackupRoot, "before-restore");
                    string name = "MetaFactory-before-restore-" + DateTime.Now.ToString("yyyy-MM-dd-HHmmss", CultureInfo.InvariantCulture) + AutoBackup.Extension;
                    WriteBackup(dir, name, BackupFormat.Make(GatherBackup(), password));
                    Log.Write("before restore, kept: " + Path.Combine(dir, name));
                }
                catch (Exception e)
                {
                    Log.Write("before restore: " + e.Message);
                    if (!Ui.Confirm(this, Lang.T("از فهرست فعلی پشتیبان گرفته نشد (", "The current list was not backed up (") + e.Message + Lang.T(").\n\nبازگردانی بدون آن ادامه پیدا کند؟ چیزی از فهرست فعلی پاک نمی‌شود.", ").\n\nContinue the restore without it? Nothing of the current list is deleted."))) return;
                }
            }
            settings.UseFolder(folder);
            settings.Save();
            List<BackupStudent> jobs = plan.Add.ToList();
            var made = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var failed = new List<KeyValuePair<BackupStudent, string>>();
            Log.Write("restore: " + jobs.Count + " to add, " + plan.Update.Count + " to update, " + plan.Skip.Count + " already here, copies in " + folder);
            SetBusy(true);
            SetStatus(Lang.T("بازگردانی از پشتیبان…", "Restore from backup…"));
            var worker = new BackgroundWorker { WorkerReportsProgress = true };
            worker.DoWork += (s, e) =>
            {
                for (int k = 0; k < jobs.Count; k++)
                {
                    BackupStudent b = jobs[k];
                    worker.ReportProgress(k * 100 / Math.Max(1, jobs.Count), (b.Trader.Trim().Length > 0 ? b.Trader.Trim() : b.Login) + " (" + Fa.N(k + 1) + Lang.T(" از ", " of ") + Fa.N(jobs.Count) + ")");
                    Kind kind = string.Equals(b.Kind, "MT4", StringComparison.OrdinalIgnoreCase) ? Kind.MT4 : Kind.MT5;
                    bool sure;
                    string source = ServerCatalog.InstallFor(kind, b.Server, settings, out sure);
                    if (source == null) { failed.Add(new KeyValuePair<BackupStudent, string>(b, kind + Lang.T(" روی این کامپیوتر نصب نیست", " is not installed on this computer"))); continue; }
                    try
                    {
                        List<string> names = CopyMaker.Create(new CreateRequest { Kind = kind, Source = source, Count = 1, Prefix = kind.ToString(), CopyData = false, Folder = folder }, settings, null);
                        made[b.Copy] = names[0];
                    }
                    catch (Exception ex) { failed.Add(new KeyValuePair<BackupStudent, string>(b, ex.Message)); }
                }
            };
            worker.ProgressChanged += (s, e) =>
            {
                band.Progress = e.ProgressPercentage;
                SetStatus(Lang.T("بازگردانی: ساختن نسخه برای ", "Restore: making a copy for ") + e.UserState + "…");
            };
            worker.RunWorkerCompleted += (s, e) =>
            {
                SetBusy(false);
                try { FinishRestore(d, plan, fresh, folder, made, failed, e.Error); }
                catch (Exception ex) { Ui.Error(this, ex); }
                RefreshAll(true);
                Native.TrimSelf("the restore");
            };
            worker.RunWorkerAsync();
        }

        void FinishRestore(BackupData d, RestorePlan plan, bool fresh, string folder, Dictionary<string, string> made,
                           List<KeyValuePair<BackupStudent, string>> failed, Exception error)
        {
            var copyNow = new Dictionary<string, string>(made, StringComparer.OrdinalIgnoreCase);
            foreach (BackupStudent b in plan.Add)
            {
                string c;
                if (made.TryGetValue(b.Copy, out c)) accounts.Set(BackupStore.AccountOf(b, c));
            }
            foreach (KeyValuePair<BackupStudent, string> u in plan.Update)
            {
                Account a = accounts.Get(u.Value);
                if (a == null) continue;
                if (u.Key.Trader.Trim().Length > 0) a.Trader = u.Key.Trader;
                if (!u.Key.NoPassword)
                {
                    a.Mode = string.IsNullOrEmpty(u.Key.Mode) ? a.Mode : u.Key.Mode;
                    a.InvestorEnc = Secret.Protect(u.Key.Investor);
                    a.MasterEnc = Secret.Protect(u.Key.Master);
                }
                copyNow[u.Key.Copy] = u.Value;
                students.Remove(u.Value);
            }
            accounts.Save();
            BackupStore.ApplyFolders(d, folders, copyNow);
            SaveFolders();
            order = Restore.Order(copies.Select(c => c.Name).ToList(), d, made);
            try { ListOrder.Save(order); } catch (Exception ex) { Log.Write("order: " + ex.Message); }
            int reports = BackupStore.ApplyJournals(d);
            bool lookChanged = false;
            if (fresh)
            {
                string look = settings.Look;
                BackupStore.ApplySettings(d, settings);
                lookChanged = !string.Equals(look, settings.Look, StringComparison.OrdinalIgnoreCase);
                listTools.Platform = settings.Platform;
            }
            settings.Save();
            Log.Write("restore done: " + made.Count + " added, " + plan.Update.Count + " updated, " + plan.Skip.Count + " already here, " + failed.Count + " not added, " +
                      reports + " report files" + (error != null ? "; stopped: " + error.Message : ""));
            foreach (KeyValuePair<BackupStudent, string> f in failed) Log.Write("restore: " + f.Key.Login + " on " + f.Key.Server + " not added: " + f.Value);
            var lines = new List<string>();
            if (made.Count > 0) lines.Add("✓  " + Fa.N(made.Count) + Lang.T(" دانشجو اضافه شد (نسخه‌هایشان در ", " students added (their copies were made in ") + folder + Lang.T(" ساخته شد).", ")."));
            if (plan.Update.Count > 0) lines.Add("✓  " + Fa.N(plan.Update.Count) + Lang.T(" دانشجو از روی فایل به‌روز شد.", " students updated from the file."));
            if (plan.Skip.Count > 0) lines.Add("·  " + Fa.N(plan.Skip.Count) + Lang.T(" دانشجو از قبل این‌جا بودند و همان‌طور ماندند.", " students were here already and stayed as they were."));
            if (d.Folders.Count > 0) lines.Add(Lang.T("✓  پوشه‌ها و ترتیب فهرست برگشت.", "✓  Folders and list order restored."));
            if (reports > 0) lines.Add(Lang.T("✓  تاریخچه‌ی گزارش‌ها برگشت.", "✓  Report history restored."));
            if (failed.Count > 0)
            {
                lines.Add("");
                lines.Add("✗  " + Fa.N(failed.Count) + Lang.T(" دانشجو اضافه نشدند:", " students were not added:"));
                foreach (KeyValuePair<BackupStudent, string> f in failed.Take(8))
                    lines.Add("   " + (f.Key.Trader.Trim().Length > 0 ? f.Key.Trader.Trim() : f.Key.Login) + ": " + f.Value);
                if (failed.Count > 8) lines.Add("   …");
                lines.Add(Lang.T("بعد از رفع مشکل (مثلاً نصب متاتریدرِ بروکر)، «بازگردانی از پشتیبان» را دوباره بزنید؛ کسانی که اضافه شده‌اند دوباره اضافه نمی‌شوند.", "After fixing the problem (e.g. installing the broker's MetaTrader), press “Restore from backup” again; those already added are not added twice."));
            }
            if (error != null) lines.Add(Lang.T("\nبازگردانی کامل نشد: ", "\nThe restore was not complete: ") + error.Message);
            if (lookChanged) lines.Add(Lang.T("\nظاهر انتخابی (رنگ‌ها) از دفعه‌ی بعد که برنامه باز شود دیده می‌شود.", "\nThe chosen look (colors) shows the next time the program opens."));
            SetStatus(made.Count > 0 || plan.Update.Count > 0 ? Lang.T("بازگردانی از پشتیبان انجام شد.", "Restored from backup.") : Lang.T("بازگردانی: دانشجوی تازه‌ای اضافه نشد.", "Restore: no new student was added."));
            Ui.Message(this, Lang.T("بازگردانی از پشتیبان\n\n", "Restore from backup\n\n") + string.Join("\n", lines), failed.Count > 0 || error != null ? MessageBoxIcon.Warning : MessageBoxIcon.Information);
        }

        void RestoreCharts()
        {
            Dictionary<string, Process> running = Processes.Running();
            int n = 0, open = 0;
            foreach (Instance i in copies)
            {
                if (!Directory.Exists(ChartProfile.BackupDir(i))) continue;
                if (Processes.IsRunning(running, i.Exe)) { open++; continue; }
                n += ChartProfile.Restore(i);
            }
            Ui.Message(this, n == 0 && open == 0 ? Lang.T("چارتی کنار گذاشته نشده بود.", "No charts were set aside.") :
                Fa.N(n) + Lang.T(" چارت برگشت.", " charts brought back.") + (open > 0 ? "\n" + Fa.N(open) + Lang.T(" نسخه باز بود؛ برای برگرداندن چارت‌هایش اول ببندیدش.", " copies were open; close them first to bring back their charts.") : "") +
                (settings.StartCharts == ChartModes.One ? Lang.T("\n\nتا وقتی «چارت نسخه‌های اینوستور» در تنظیمات روی «یک چارت» است، حساب‌های اینوستور دوباره با یک چارت باز می‌شوند.", "\n\nAs long as “Charts of investor copies” is “One chart” in Settings, investor accounts open with one chart again.") : ""));
        }

        void CreateCopies()
        {
            if (busy) return;
            CreateRequest req;
            using (var d = new CreateDialog(settings))
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
                req = d.Request;
            }
            // The chosen folder is the default from now on; the folders used before stay in the list with their copies.
            settings.UseFolder(req.Folder);
            settings.Save();
            SetBusy(true);
            var worker = new BackgroundWorker { WorkerReportsProgress = true };
            worker.DoWork += (s, e) => e.Result = CopyMaker.Create(req, settings, (n, total, name) => worker.ReportProgress(n * 100 / total, name + " (" + Fa.N(n) + Lang.T(" از ", " of ") + Fa.N(total) + ")"));
            worker.ProgressChanged += (s, e) =>
            {
                band.Progress = e.ProgressPercentage;
                SetStatus(Lang.T("در حال ساخت ", "Making ") + e.UserState + "…");
            };
            worker.RunWorkerCompleted += (s, e) =>
            {
                SetBusy(false);
                if (e.Error != null) { Ui.Error(this, e.Error); SetStatus(Lang.T("ساخت نسخه‌ها کامل نشد.", "Making the copies did not finish.")); }
                else SetStatus(Fa.N(((List<string>)e.Result).Count) + Lang.T(" نسخه‌ی ", " copies of ") + req.Kind + Lang.T(" ساخته شد. حالا حساب هر نسخه را وارد کنید («⋯» کنار ردیف و «حساب و رمز»).", " made. Now enter each copy's account (“⋯” next to the row, then “Account and password”)."));
                RefreshAll(true);
                Native.TrimSelf("making copies");
            };
            worker.RunWorkerAsync();
        }

        void SetBusy(bool on)
        {
            busy = on;
            foreach (Control c in lockWhileBusy) c.Enabled = !on;
            band.Progress = on ? 0 : -1;
            Cursor = on ? Cursors.WaitCursor : Cursors.Default;
        }

        void Enqueue(List<Instance> list)
        {
            if (copies.Count == 0) { Ui.Message(this, Lang.T("هنوز نسخه‌ای ساخته نشده. اول «ساخت نسخه‌ها» را بزنید.", "No copies made yet. First press “Make copies”.")); return; }
            if (list.Count == 0) { Ui.Message(this, Lang.T("اول نسخه‌ها را در جدول انتخاب کنید.", "First select copies in the list.")); return; }
            Dictionary<string, Process> running = Processes.Running();
            bool newBatch=startQueue.Count==0 && !preparingCopy;
            int otherRunning=copies.Count(c=>Processes.IsRunning(running,c.Exe));
            if (startQueue.Count == 0 && !preparingCopy) { launchOpened = 0; launchFailed = 0; launchMemoryWarning = ""; }
            int added = 0, updating = 0;
            try
            {
            foreach (Instance i in list)
            {
                if (Processes.IsRunning(running, i.Exe) || startQueue.Any(q => q.Name == i.Name)) continue;
                if (Updating(i)) { updating++; continue; }
                startQueue.Enqueue(i);
                added++;
            }
            }
            finally { foreach (Process process in running.Values) process.Dispose(); }
            if (added == 0)
            {
                SetStatus(updating > 0 ? Lang.T("نسخه‌های انتخاب‌شده در حال اجرا یا به‌روزرسانی خودشان هستند؛ آن‌هایی که به‌روز می‌شوند خودشان باز می‌شوند.", "The selected copies are running or updating themselves; those updating open by themselves.")
                        : Lang.T("نسخه‌های انتخاب‌شده همه در حال اجرا هستند.", "The selected copies are all running."));
                return;
            }
            if(newBatch)LaunchComparison.Begin(settings.ManualLiveReports,startQueue.ToList(),settings,accounts,otherRunning);
            RunQueue();
            RefreshGrid(false);
        }

        void RunQueue()
        {
            if (!startTimer.Enabled)
            {
                // One at a time, so the computer and the broker's servers are not hit all at once;
                // the next one opens as soon as the one before is up (see StartPace), at the latest after the set delay.
                startTimer.Interval = 1000;
                StartNext();
                if (startQueue.Count > 0) startTimer.Start();
            }
        }

        /// <summary>Closed in the middle of MetaTrader's own update (it starts itself again, or the program does), or waiting to be opened again after it.</summary>
        bool Updating(Instance i)
        {
            Launch l;
            return launches.TryGetValue(i.Name, out l) && (l.Update == UpdateStep.Waiting || l.Update == UpdateStep.Queued);
        }

        /// <summary>Copies opened again by the program after MetaTrader updated itself (see FollowUpdate).</summary>
        void StartAgain(List<Instance> list)
        {
            Dictionary<string, Process> running = Processes.Running();
            foreach (Instance i in list)
                if (!Processes.IsRunning(running, i.Exe) && !startQueue.Any(q => q.Name == i.Name)) startQueue.Enqueue(i);
            if (startQueue.Count > 0) RunQueue();
        }

        /// <summary>MetaTrader closes itself to put a new build in place, then starts again by itself (with the account it saved).
        /// Followed here from its journal:
        /// - while it updates, the list says so (not "did not open");
        /// - when it does not come back within 40 seconds, the program opens it again;
        /// - when it comes back on its own, it is left open, and it stays one opened by this program (so it can be closed from here).
        /// A copy is opened again this way at most once in ten minutes, so this never goes round in circles.</summary>
        void FollowUpdate(Instance i, Launch l, bool on, Process p, DateTime now)
        {
            TidyUpdateFile(i, l, on, p, now);
            double since = (now - l.UpdateAt).TotalSeconds;
            switch (l.Update)
            {
                case UpdateStep.None:
                    if (on && p != null && l.Pid != 0 && p.Id != l.Pid)
                    {
                        // Another process runs from this copy's folder: MetaTrader started it again after updating itself, or it was opened by hand.
                        l.Pid = p.Id;
                        if (SelfUpdate.Since(i, l.JournalFrom)) Back(i, l, p, now, "closed to update itself and MetaTrader started it again");
                    }
                    // Read when it is first found closed, and again for 15 seconds (the journal may be written just after).
                    else if (!on && (now - l.Time).TotalSeconds > 4 &&
                             (l.GoneAt.HasValue ? (now - l.GoneAt.Value).TotalSeconds <= 15 : !l.ClosedEarly && !l.ClosedAt.HasValue) &&
                             SelfUpdate.Since(i, l.JournalFrom))
                    {
                        l.Update = UpdateStep.Waiting;
                        l.UpdateAt = now;
                        l.ClosedEarly = false;
                        l.ClosedAt = null;
                        l.NoWindow = false;
                        bannerKey = null;
                        Log.Write(i.Name + " closed to update itself (MetaTrader's LiveUpdate)");
                        PutStartFileBack(i, l, now);
                    }
                    break;
                case UpdateStep.Waiting:
                    if (on)
                    {
                        if (p != null) l.Pid = p.Id;
                        Back(i, l, p, now, "started again by MetaTrader after its update");
                    }
                    // 3.27.3: three minutes (was 40 seconds): Windows first asks whether the update may run, and that waits for the user.
                    else if (since > Launcher.SelfUpdateWaitSeconds(i.Kind)) Reopen(i, l, now, "did not come back after updating itself");
                    break;
                case UpdateStep.Back:
                    if (!on) { l.Update = UpdateStep.Waiting; l.UpdateAt = now; }  // closed again: one more step of the update
                    else { l.Update = UpdateStep.None; Log.Write(i.Name + " is open again after its update"); }
                    break;
                case UpdateStep.Queued:
                    if (on) l.Update = UpdateStep.None;  // opened meanwhile
                    break;
            }
        }

        /// <summary>3.27.3: how long a copy that closed to update itself is waited for before the program opens it again.</summary>
        const int UpdateWaitSeconds = 180;

        /// <summary>3.27.3: MetaTrader starts again after its update with the same "/config:...mtm-start.ini", which the program has
        /// already deleted (it holds the password): without it MetaTrader asks for the password. So it is written again now and deleted
        /// as soon as MetaTrader is back (its window, or 10 seconds after), or at the latest after UpdateWaitSeconds.</summary>
        void PutStartFileBack(Instance i, Launch l, DateTime now)
        {
            try
            {
                if(i.Kind==Kind.MT5 && l.LiveStartupLines!=null && l.LiveStartFile!=null)
                {
                    if(!File.Exists(l.LiveStartFile))Launcher.RestoreMt5LiveStart(i,settings,accounts,l.LiveStartFile,l.LiveStartupLines);
                    pending.RemoveAll(item=>string.Equals(item.Path,l.LiveStartFile,StringComparison.OrdinalIgnoreCase));
                    pending.Add(new PendingStart{Path=l.LiveStartFile,Copy=i,Time=now,WaitForConfigRead=true,KeepForRestart=true,MaxWaitSeconds=PendingStart.ProtectedSeconds});
                    pendingTimer.Start();
                    Log.Write(i.Name+": exact live startup configuration retained for self-update restart");
                    return;
                }
                StartResult r = Launcher.WriteStartFile(i, settings, accounts);
                if (r.StartFile == null) return;
                l.UpdateFile = r.StartFile;
                l.UpdateFileAt = now;
                Log.Write(i.Name + ": start file put back for MetaTrader's restart after its update");
            }
            catch (Exception e) { Log.Write("start file after update " + i.Name + ": " + e.Message); }
        }

        void TidyUpdateFile(Instance i, Launch l, bool on, Process p, DateTime now)
        {
            if (l.UpdateFile == null) return;
            string why = null;
            if ((now - l.UpdateFileAt).TotalSeconds >= UpdateWaitSeconds) why = "time";
            else if (on && l.Update != UpdateStep.Waiting)
            {
                bool window = false;
                try { window = p != null && p.MainWindowHandle != IntPtr.Zero; } catch { }
                if (window) why = "window";
                else if ((now - l.UpdateAt).TotalSeconds >= 10) why = "back 10 s";
            }
            if (why == null) return;
            DropUpdateFile(l);
            Log.Write(i.Name + ": start file of the restart after its update deleted (" + why + ")");
        }

        static void DropUpdateFile(Launch l)
        {
            if (l == null || l.UpdateFile == null) return;
            Launcher.DeleteStartFile(l.UpdateFile);
            l.UpdateFile = null;
        }

        void DropUpdateFiles() { foreach (Launch l in launches.Values) DropUpdateFile(l); }

        void Back(Instance i, Launch l, Process p, DateTime now, string what)
        {
            l.Update = UpdateStep.Back;
            l.UpdateAt = now;
            // Lines of this update are not read again (a later close by hand is not taken for another update).
            l.JournalFrom = now;
            // MetaTrader started it again in place of the one opened here: it is still one of the program's own.
            if (p != null) Owned.Add(p, i.Exe);
            UpdateMt5StartupProcess(i,p);
            l.ClosedEarly = false;
            l.ClosedAt = null;
            l.NoWindow = false;
            bannerKey = null;
            Log.Write(i.Name + " " + what);
        }

        void Reopen(Instance i, Launch l, DateTime now, string why)
        {
            if (why != null && RecentlyReopened(i, now))
            {
                // Already opened again once a moment ago: shown as not opened, as before; the user decides.
                l.Update = UpdateStep.None;
                l.ClosedEarly = true;
                l.GoneAt = now;
                bannerKey = null;
                Log.Write(i.Name + " " + why + "; not opened again (already once in the last minutes)");
                return;
            }
            l.Update = UpdateStep.Queued;
            l.UpdateAt = now;
            reopenedAt[i.Name] = now;
            reopenNow.Add(i);
            Log.Write(i.Name + " " + (why != null ? why + "; " : "") + "opening it again");
        }

        bool RecentlyReopened(Instance i, DateTime now)
        {
            DateTime t;
            return reopenedAt.TryGetValue(i.Name, out t) && (now - t).TotalMinutes < 10;
        }

        /// <summary>Every second while copies wait: is the one started last up and settled?</summary>
        void PaceTick()
        {
            if (startQueue.Count == 0) { startTimer.Stop(); return; }
            DateTime now = DateTime.Now;
            bool exited = true, window = false;
            double cpu = 1;
            if (pacing != null)
            {
                try
                {
                    pacing.Refresh();
                    exited = pacing.HasExited;
                    if (!exited)
                    {
                        window = pacing.MainWindowHandle != IntPtr.Zero;
                        TimeSpan used = pacing.TotalProcessorTime;
                        double wall = (now - pacingAt).TotalSeconds;
                        cpu = wall > 0.2 ? (used - pacingCpu).TotalSeconds / wall : 1;
                        pacingCpu = used;
                        pacingAt = now;
                    }
                }
                catch { exited = true; }
            }
            if (pacing != null && lastLaunched != null && !exited)
            {
                try { ulong measured = (ulong)Math.Max(0, pacing.PeakWorkingSet64 / (1024 * 1024)); ulong old; launchPeaks.TryGetValue(lastLaunched.Kind, out old); launchPeaks[lastLaunched.Kind] = Math.Max(old, measured); } catch { }
            }
            // Honor the configured start interval even if the previous window is still loading.
            // Nothing here closes the previous process or waits for a terminal-count slot.
            if (!StartPace.Ready((now - lastStartAt).TotalSeconds, settings.DelaySeconds, exited, window, cpu)) return;
            if (pacing != null && !exited && !window)
                Log.Write("launch window still loading: " + (lastLaunched != null ? lastLaunched.Name : "unknown") + "; continuing at configured interval; process left running");
            StartNext();
        }

        void WarnLaunchMemory(Instance next)
        {
            ulong total = launchTotalRam(), free = launchFreeRam(), peak;
            launchPeaks.TryGetValue(next.Kind, out peak);
            string warning = LaunchMemoryPolicy.CanStart(total, free, next.Kind, peak) ? "" :
                total == 0 ? Lang.T("میزان حافظه قابل خواندن نیست؛ بازکردن نسخه‌ها ادامه دارد.", "Memory could not be measured; opening continues.") :
                Lang.T("حافظهٔ آزاد کم است: ", "Low free memory: ") + Fa.N((long)free) + " MB" +
                Lang.T("؛ بازکردن ادامه دارد و ممکن است ویندوز کند شود.", "; opening continues and Windows may slow down.");
            if (warning == launchMemoryWarning) return;
            launchMemoryWarning = warning;
            Log.Write("manual launch memory advisory: total=" + total + " MB; free=" + free + " MB; warn=" + (warning.Length > 0) + "; no admission limit");
            UpdateBanner();
        }

        void RecordLaunchFailure(Instance copy, Exception error)
        {
            LaunchComparison.Failure(copy.Name,error);
            LaunchCapacityDiagnostics.Failure(copy.Name, error);
            launchFailed++;
            launchErrors[copy.Name] = error.Message;
            Log.Write("manual launch " + copy.Name + " failed; remaining queue continues: " + error);
            launches[copy.Name] = new Launch { Time = DateTime.Now, JournalFrom = DateTime.Now, ClosedEarly = true, GoneAt = DateTime.Now };
            SetStatus(copy.Name + Lang.T(" اجرا نشد؛ ادامهٔ صف. ", " did not start; continuing queue. ") + error.Message);
            bannerKey = null;
        }

        void StartNext()
        {
            if (preparingCopy || appClosing) return;
            if(startQueue.Count>0 && WaitForStartupSlot(startQueue.Peek())){startTimer.Start();return;}
            if (startQueue.Count > 0) WarnLaunchMemory(startQueue.Peek());
            if (startQueue.Count > 0 && !File.Exists(startQueue.Peek().Exe))
            {
                Instance requested = startQueue.Peek(); Account snapshot = accounts.Get(requested.Name);
                preparingCopy = true;
                SetStatus(Lang.T("آماده‌سازی اولین اجرای ", "Preparing first launch: ") + requested.Name);
                System.Threading.Tasks.Task.Factory.StartNew(() => StudentDirectory.EnsureCopy(settings, requested, snapshot, () => appClosing || accounts.Get(requested.Name) == null)).ContinueWith(task => {
                    Exception failure = task.Exception;
                    if (appClosing || IsDisposed || !IsHandleCreated) return;
                    try { BeginInvoke((Action)(() => {
                        preparingCopy = false;
                        if (failure != null)
                        {
                            if (startQueue.Count > 0 && startQueue.Peek().Name == requested.Name) startQueue.Dequeue();
                            RecordLaunchFailure(requested, failure.GetBaseException());
                        }
                        if (!appClosing) StartNext();
                    })); } catch (InvalidOperationException) { }
                });
                return;
            }
            if (startQueue.Count == 0) { startTimer.Stop(); return; }
            Instance i = startQueue.Dequeue();
            LaunchComparison.Preparing(i);
            lastStartAt = DateTime.Now;
            pacing = null;
            lastFailure.Remove(i.Name);
            watches.Remove(i.Name);
            launchErrors.Remove(i.Name);
            if (Launcher.PrepareLiveManual != null || (i.Kind == Kind.MT4 && settings.SandboxieOverflow && sandboxAvailable()))
            {
                preparingCopy = true;
                SetStatus(i.Name + (settings.ManualLiveReports?Lang.T("؛ آماده‌سازی گزارش زنده و اجرا…", "; preparing live reporter and launch…"):Lang.T("؛ اجرای عادی بدون گزارش‌خوان…", "; ordinary launch without report EA…")));
                // Sandboxie's first file migration and PID discovery must not block the UI thread.
                System.Threading.Tasks.Task.Factory.StartNew(() => startTerminal(i)).ContinueWith(task =>
                {
                    Exception failure = task.Exception == null ? null : task.Exception.GetBaseException();
                    StartResult result = failure == null ? task.Result : null;
                    if (appClosing || IsDisposed || !IsHandleCreated) { CleanDetachedStart(i, result); return; }
                    try
                    {
                        BeginInvoke((Action)(() =>
                        {
                            preparingCopy = false;
                            if (appClosing || IsDisposed) { CleanDetachedStart(i, result); return; }
                            if (failure != null) RecordLaunchFailure(i, failure);
                            else CompleteManualStart(i, result);
                            if (startQueue.Count == 0) startTimer.Stop();
                            else startTimer.Start();
                        }));
                    }
                    catch (InvalidOperationException) { CleanDetachedStart(i, result); }
                });
                return;
            }
            try { CompleteManualStart(i, startTerminal(i)); }
            catch (Exception e) { RecordLaunchFailure(i, e); }
            if (startQueue.Count == 0) startTimer.Stop();
        }

        static PendingStart PendingManual(Instance copy, StartResult result)
        {
            return new PendingStart { Path = result.StartFile, Time = DateTime.Now, Process = result.Process, Copy = copy,
                KeepForRestart = copy.Kind==Kind.MT5 && result.WaitForConfigRead, WaitForConfigRead = result.WaitForConfigRead, MaxWaitSeconds = result.WaitForConfigRead ? PendingStart.ProtectedSeconds : result.Sandboxed ? 120 : Launcher.StartFileSeconds };
        }

        static void CleanDetachedStart(Instance copy, StartResult result)
        {
            if (result == null || result.StartFile == null) return;
            // The application may close while a launch is being discovered. Keep its terminal running,
            // but still remove the temporary credential file after it is read or the bounded deadline.
            System.Threading.Tasks.Task.Factory.StartNew(() =>
            {
                var files = new List<PendingStart> { PendingManual(copy, result) };
                while (files.Count > 0)
                {
                    files = Launcher.CleanStartFiles(files, DateTime.Now, false);
                    if (files.Count > 0) System.Threading.Thread.Sleep(250);
                }
            });
        }

        void CompleteManualStart(Instance i, StartResult r)
        {
            if (r.StartFile != null)
            {
                pending.Add(PendingManual(i, r));
                pendingTimer.Start();
            }
            DateTime at = DateTime.Now;
            launches[i.Name] = new Launch { Pid = r.Process != null ? r.Process.Id : 0, Time = at, JournalFrom = at, LiveStartFile = i.Kind==Kind.MT5 ? r.StartFile : null, LiveStartupLines = r.StartupLines };
            TrackMt5Startup(i,r);
            pacing = r.Process; lastLaunched = i; if (r.Process != null) launchOpened++;
            lastStartAt = pacingAt = DateTime.Now;
            try { if (pacing != null) pacingCpu = pacing.TotalProcessorTime; } catch { pacing = null; }
            if (r.Warning != null) SetStatus(r.Warning);
            else SetStatus(i.Name + (r.Sandboxed ? Lang.T(" در Sandboxie اجرا شد", " started in Sandboxie") : Lang.T(" باز شد", " opened")) +
                (startQueue.Count > 0 ? Lang.T("؛ ", "; ") + Fa.N(startQueue.Count) + Lang.T(" نسخه‌ی دیگر در صف", " more copies in the queue") :
                Lang.T(". صف اجرا پایان یافت؛ شروع‌شده: ", ". Launch queue finished; started: ") + Fa.N(launchOpened) + Lang.T("؛ خطای اجرا: ", "; launch errors: ") + Fa.N(launchFailed)));
        }

        /// <summary>Start files hold a password: each goes as soon as its terminal has read it, at the latest after 10 seconds.</summary>
        void DeleteOldStartFiles(bool all)
        {
            if (pending.Count > 0) pending = Launcher.CleanStartFiles(pending, DateTime.Now, all);
            if (pending.Count == 0) pendingTimer.Stop();
        }

        void Stop(List<Instance> list, bool force)
        {
            if (list.Count == 0) { Ui.Message(this, Lang.T("اول نسخه‌ها را در جدول انتخاب کنید.", "First select copies in the list.")); return; }
            if (force && !Ui.Confirm(this, Lang.T("بستن اجباری: تغییرهای ذخیره‌نشده‌ی این نسخه‌ها از بین می‌رود. ادامه می‌دهید؟", "Force close: unsaved changes of these copies are lost. Continue?"))) return;
            foreach (Instance i in list) { Launch gone; if (launches.TryGetValue(i.Name, out gone)) DropUpdateFile(gone); launches.Remove(i.Name); launchErrors.Remove(i.Name); }
            CloseAndFollow(list, force);
        }

        public static string NothingTicked { get { return Lang.T("ابتدا حداقل یک مورد را انتخاب کنید.", "First select at least one."); } }

        /// <summary>The band's run and close act on the ticked copies only; with none ticked, nothing happens but a clear message.</summary>
        bool AnyTicked()
        {
            if (copies.Count == 0) { Ui.Message(this, Lang.T("هنوز نسخه‌ای ساخته نشده. اول «دانشجوی جدید» یا «ساخت نسخه‌ها» را بزنید.", "No copies made yet. First press “New student” or “Make copies”.")); return false; }
            if (chosen.Count > 0) return true;
            Ui.Message(this, NothingTicked + Lang.T("\n\nمربع کنار نام هر دانشجو را بزنید. مربع بالای ستون (یا Ctrl+A) همه‌ی ردیف‌هایی را که الان دیده می‌شوند انتخاب می‌کند.", "\n\nTick the box next to each student's name. The box at the top of the column (or Ctrl+A) selects every row shown now."),
                       MessageBoxIcon.Warning);
            return false;
        }

        /// <summary>"اجرای انتخاب‌شده‌ها": only the ticked copies open.</summary>
        ContextMenuStrip launchModesMenu;
        void ShowLaunchModes()
        {
            if(launchModesMenu==null)Disposed+=(s,e)=>{if(launchModesMenu!=null)launchModesMenu.Dispose();};else launchModesMenu.Dispose();
            var menu=launchModesMenu=Theme.Menu();
            var live=Item(menu,Lang.T("اجرا با اکسپرت گزارش زنده","Run with live report EA"),()=>RunInMode(true));live.Checked=settings.ManualLiveReports;
            var plain=Item(menu,Lang.T("اجرای عادی بدون اکسپرت گزارش‌خوان","Run without report EA"),()=>RunInMode(false));plain.Checked=!settings.ManualLiveReports;
            Item(menu,Lang.T("مقایسهٔ اجراها در عیب‌یابی…","Launch comparison diagnostics…"),ShowReport);
            ShowUnder(menu,runButton);
        }
        void RunInMode(bool live)
        {
            if(!AnyTicked())return;
            if(preparingCopy || startQueue.Count>0 || busy || report!=null || scheduledBatch!=null)
            {SetStatus(Lang.T("اجرای فعلی یا گزارش‌گیری هنوز تمام نشده؛ پس از پایان، حالت را تغییر دهید.","Wait for the current launch/report batch before changing mode."));return;}
            settings.ManualLiveReports=live;settings.Save();runButton.SetText(live?Lang.T("اجرا · زنده","Run · live"):Lang.T("اجرا · عادی","Run · ordinary"));band.PerformLayout();RunChosen();
        }

        void RunChosen()
        {
            if (!AnyTicked()) return;
            SetStatus(settings.ManualLiveReports?Lang.T("حالت اجرا: گزارش زنده","Launch mode: live report EA"):Lang.T("حالت اجرا: عادی، بدون اکسپرت گزارش‌خوان","Launch mode: ordinary, no report EA"));
            Enqueue(Chosen());
        }

        /// <summary>"بستن انتخاب‌شده‌ها": only the ticked copies close (and leave the start queue).</summary>
        void StopChosen()
        {
            if (!AnyTicked()) return;
            List<Instance> list = Chosen();
            List<Instance> rest = startQueue.Where(q => !chosen.Has(q.Name)).ToList();
            if (rest.Count != startQueue.Count)
            {
                startQueue.Clear();
                foreach (Instance q in rest) startQueue.Enqueue(q);
                if (startQueue.Count == 0) startTimer.Stop();
            }
            bannerKey = null;
            Stop(list, false);
        }

        // ------------------------------------------------------------- folders

        /// <summary>The folder being viewed in the folder row; null for "همه‌ی پوشه‌ها" and "بدون پوشه".</summary>
        Folder ViewedFolder()
        {
            string key = folderBar.Selected;
            return key != null && key.StartsWith("f:") ? folders.Get(key.Substring(2)) : null;
        }

        Func<Instance, bool> InFolder(string key)
        {
            if (key == FolderBar.NoneKey) return i => folders.Unfiled(i.Name);
            if (key != null && key.StartsWith("f:"))
            {
                string id = key.Substring(2);
                return i => folders.Has(id, i.Name);
            }
            return i => true;
        }

        /// <summary>The folder row follows the folders and how many are in each (only redrawn when that changes).</summary>
        void ShowFolders()
        {
            List<string> names = copies.Select(c => c.Name).ToList();
            string key = string.Join("|", folders.All.Select(f => f.Id + ":" + f.Name + ":" + folders.Count(f.Id, names))) + "|" + names.Count + "|" + names.Count(folders.Unfiled);
            if (key == folderKey) return;
            folderKey = key;
            folderBar.SetFolders(folders.All.Select(f => new KeyValuePair<string, string>("f:" + f.Id, f.Name)),
                                 k => folders.Count(k.Substring(2), names), names.Count, names.Count(folders.Unfiled));
        }

        bool SaveFolders()
        {
            if (!foldersReadable)
            {
                Ui.Message(this, Lang.T("فایل پوشه‌ها (folders.txt) موقع باز شدن برنامه خوانده نشد. برای اینکه چیزی از دست نرود، تغییر پوشه‌ها ذخیره نمی‌شود. برنامه را ببندید و دوباره باز کنید.", "The folders file (folders.txt) could not be read when the program opened. So that nothing is lost, folder changes are not saved. Close the program and open it again."), MessageBoxIcon.Warning);
                return false;
            }
            folders.Save();
            folderKey = null;
            return true;
        }

        /// <summary>A folder submenu: "افزودن به پوشه" with a check mark on the folders all of them are in (a dash: some are),
        /// a click adds them all or, when all are in already, takes them out; "انتقال به پوشه" moves them, out of the folder viewed
        /// (or, when all folders are viewed, out of every other folder).</summary>
        void FillFolderItems(ToolStripMenuItem parent, List<Instance> targets, bool move)
        {
            foreach (ToolStripItem old in parent.DropDownItems.Cast<ToolStripItem>().ToList())
                if (old.Image != null) { old.Image.Dispose(); old.Image = null; }
            parent.DropDownItems.Clear();
            var drop = (ToolStripDropDownMenu)parent.DropDown;
            drop.ShowCheckMargin = false;
            // 3.22.4: the tick boxes of «افزودن به پوشه» are the items' images, so Windows itself makes room for the box and the whole
            // name (an item that drew its own box was given less width than it drew in, and the box was cut off at the edge).
            drop.ShowImageMargin = !move;
            drop.ImageScalingSize = new Size(Theme.S(16), Theme.S(16));
            drop.RightToLeft = Theme.Dir;
            drop.Font = Theme.Font;
            drop.Renderer = new FluentRenderer();
            drop.BackColor = Theme.Surface;
            List<string> names = targets.Select(t => t.Name).ToList();
            Folder viewed = ViewedFolder();
            // 3.26 (CHANGE-007): a small heading over «افزودن به پوشه»: who the ticks are about.
            if (!move)
                parent.DropDownItems.Add(new ToolStripMenuItem(names.Count == 1 ? Who(targets) : Fa.N(names.Count) + Lang.T(" دانشجوی انتخاب‌شده", " selected students"))
                    { Enabled = false, Tag = "head", Padding = Theme.Pad(10, 2) });
            if (move)
            {
                var head = new ToolStripMenuItem(viewed != null ? Lang.T("از «", "From “") + viewed.Name + Lang.T("» به:", "” to:") : Lang.T("از همه‌ی پوشه‌هایشان به:", "From all their folders to:")) { Enabled = false, Padding = Theme.Pad(10, 4) };
                parent.DropDownItems.Add(head);
            }
            bool any = false;
            foreach (Folder f in folders.All)
            {
                if (move && viewed != null && f.Id == viewed.Id) continue;
                Folder folder = f;
                var item = new FluentMenuItem(f.Name) { Padding = Theme.Pad(10, 6), ForeColor = Theme.Text, Tag = folder, KeepOpenOnClick = !move };
                if (!move)
                {
                    item.Image = TickImage(folders.State(f.Id, names));
                    item.ImageScaling = ToolStripItemImageScaling.None;
                    // 3.26 (CHANGE-007): «۲ از ۳» at the item's end: how many of them are in it.
                    if (names.Count > 1)
                    {
                        item.ShortcutKeyDisplayString = Fa.N(names.Count(n => folders.Has(f.Id, n))) + Lang.T(" از ", " of ") + Fa.N(names.Count);
                        item.ShowShortcutKeys = true;
                    }
                }
                item.Click += (s, e) => Guard(() => {
                    if (move) MoveTo(targets, folder);
                    else
                    {
                        ToggleIn(targets, folder);
                        foreach (ToolStripMenuItem check in parent.DropDownItems.OfType<ToolStripMenuItem>())
                        {
                            Folder member = check.Tag as Folder; if (member == null) continue;
                            Image old = check.Image; check.Image = TickImage(folders.State(member.Id, names)); if (old != null) old.Dispose();
                            if (names.Count > 1) check.ShortcutKeyDisplayString = Fa.N(names.Count(n => folders.Has(member.Id, n))) + Lang.T(" از ", " of ") + Fa.N(names.Count);
                        }
                    }
                });
                parent.DropDownItems.Add(item);
                any = true;
            }
            if (!any) parent.DropDownItems.Add(new ToolStripMenuItem(folders.All.Count == 0 ? Lang.T("هنوز پوشه‌ای نیست", "No folders yet") : Lang.T("پوشه‌ی دیگری نیست", "No other folder")) { Enabled = false, Padding = Theme.Pad(10, 6) });
            parent.DropDownItems.Add(new ToolStripSeparator { Margin = Theme.Pad(0, 3) });
            var create = new ToolStripMenuItem(Lang.T("پوشه‌ی جدید…", "New folder…")) { Padding = Theme.Pad(10, 6), ForeColor = Theme.AccentText, Tag = "accent", ImageScaling = ToolStripItemImageScaling.None };
            if (!move) create.Image = Theme.MenuIcon(Glyph.Plus, Theme.AccentText);
            create.Click += (s, e) => Guard(() => NewFolder(targets, move));
            parent.DropDownItems.Add(create);
            parent.Enabled = targets.Count > 0;
        }

        /// <summary>The tick box of a folder in «افزودن به پوشه» (0 empty, 1 some: a dash, 2 all: ticked), as the item's image.</summary>
        static Bitmap TickImage(int state)
        {
            int size = Theme.S(16);
            var bmp = new Bitmap(size, size);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.Transparent);
                Theme.TickBox(g, new Rectangle(0, 0, size - 1, size - 1), state, false);
            }
            return bmp;
        }

        void ToggleIn(List<Instance> targets, Folder f)
        {
            List<string> names = targets.Select(t => t.Name).ToList();
            bool allIn = folders.State(f.Id, names) == 2;
            if (allIn) folders.Remove(f.Id, names); else folders.Add(f.Id, names);
            if (!SaveFolders()) return;
            RefreshGrid(true);
            SetStatus(Who(targets) + (allIn ? Lang.T(" از پوشه‌ی «", " removed from folder “") + f.Name + Lang.T("» برداشته شد.", "”.") : Lang.T(" به پوشه‌ی «", " added to folder “") + f.Name + Lang.T("» اضافه شد.", "”.")));
        }

        void MoveTo(List<Instance> targets, Folder f)
        {
            Folder from = ViewedFolder();
            folders.Move(targets.Select(t => t.Name), f.Id, from != null ? from.Id : null);
            if (!SaveFolders()) return;
            RefreshGrid(true);
            SetStatus(Who(targets) + Lang.T(" به پوشه‌ی «", " added to folder “") + f.Name + Lang.T("» منتقل شد.", "”."));
        }

        void OutOfFolder(List<Instance> targets)
        {
            Folder f = ViewedFolder();
            if (f == null || targets.Count == 0) return;
            folders.Remove(f.Id, targets.Select(t => t.Name));
            if (!SaveFolders()) return;
            RefreshGrid(true);
            SetStatus(Who(targets) + Lang.T(" از پوشه‌ی «", " removed from folder “") + f.Name + Lang.T("» برداشته شد. خود دانشجو و نسخه‌اش دست نخورد.", "”. The student and their copy were not touched."));
        }

        string Who(List<Instance> targets)
        {
            if (targets.Count != 1) return Fa.N(targets.Count) + Lang.T(" دانشجو", " students");
            Account a = accounts.Get(targets[0].Name);
            return a != null && a.HasLogin && a.Trader.Length > 0 ? a.Trader : targets[0].Name;
        }

        /// <summary>"+ پوشه‌ی جدید" (and the same item in the folder menus): a name; the ticked students (or the menu's) can go in at once.</summary>
        void NewFolder(List<Instance> targets, bool move)
        {
            if (targets == null) targets = Chosen();
            FolderDialog d;
            using (d = new FolderDialog(folders, null, targets.Count))
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
            }
            Folder f = folders.Create(d.FolderName);
            if (d.AddChosen && targets.Count > 0)
            {
                if (move) folders.Move(targets.Select(t => t.Name), f.Id, ViewedFolder() != null ? ViewedFolder().Id : null);
                else folders.Add(f.Id, targets.Select(t => t.Name));
            }
            if (!SaveFolders()) return;
            Log.Write("folder created: " + f.Id + (d.AddChosen ? " with " + targets.Count : ""));
            RefreshGrid(true);
            folderBar.Selected = "f:" + f.Id;
            SetStatus(Lang.T("پوشه‌ی «", "Folder “") + f.Name + Lang.T("» ساخته شد", "” made") + (d.AddChosen && targets.Count > 0 ? Lang.T(" و ", " and ") + Who(targets) + Lang.T(" در آن است.", " are in it.") : "."));
        }

        /// <summary>A folder's own menu (right-click on it in the folder row).</summary>
        void ShowFolderMenu(string key, Point at)
        {
            Folder f = folders.Get(key.Substring(2));
            if (f == null) return;
            ContextMenuStrip m = Theme.Menu();
            int count = folders.Count(f.Id, copies.Select(c => c.Name));
            Item(m, Lang.T("تیک زدن دانشجوهای این پوشه (", "Tick the students of this folder (") + Fa.N(count) + ")", () =>
            {
                foreach (Instance c in copies) if (folders.Has(f.Id, c.Name) && !chosen.Has(c.Name)) chosen.Toggle(c.Name);
                RefreshGrid(false);
            });
            Item(m, Lang.T("تغییر نام پوشه…", "Rename folder…"), () => RenameFolder(f));
            Theme.Separator(m);
            Item(m, Lang.T("حذف پوشه…", "Delete folder…"), () => DeleteFolder(f), true);
            Pop(m).Show(at, ToolStripDropDownDirection.BelowLeft);
        }

        // The folder menus are made when asked for; the one shown before is let go then.
        ContextMenuStrip folderMenu;

        ContextMenuStrip Pop(ContextMenuStrip m)
        {
            if (folderMenu != null && folderMenu != m) folderMenu.Dispose();
            folderMenu = m;
            return m;
        }

        void RenameFolder(Folder f)
        {
            using (var d = new FolderDialog(folders, f, 0))
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
                string old = f.Name;
                folders.Rename(f.Id, d.FolderName);
                if (!SaveFolders()) { f.Name = old; return; }
            }
            RefreshGrid(true);
            SetStatus(Lang.T("نام پوشه عوض شد: «", "Folder renamed: “") + f.Name + "».");
        }

        void DeleteFolder(Folder f)
        {
            int count = folders.Count(f.Id, copies.Select(c => c.Name));
            if (!Ui.Confirm(this, DeleteQuestion(f.Name, count))) return;
            folders.Delete(f.Id);
            if (!SaveFolders()) return;
            Log.Write("folder deleted: " + f.Id);
            folderBar.Selected = FolderBar.AllKey;
            RefreshGrid(true);
            SetStatus(Lang.T("پوشه‌ی «", "Folder “") + f.Name + Lang.T("» حذف شد.", "” deleted."));
        }

        static string DeleteQuestion(string name, int count)
        {
            return Lang.T("پوشه‌ی «", "Folder “") + name + Lang.T("» حذف شود؟\n\n", "” be deleted?\n\n") +
                   (count > 0 ? Fa.N(count) + Lang.T(" دانشجو در این پوشه است. خود دانشجوها، حساب‌ها و نسخه‌هایشان دست نمی‌خورند؛ فقط از این پوشه بیرون می‌آیند ", " students are in this folder. The students, accounts and copies are not touched; they only leave this folder ") +
                                Lang.T("(در پوشه‌های دیگرشان می‌مانند، و اگر پوشه‌ی دیگری نداشته باشند به «بدون پوشه» می‌روند).", "(they stay in their other folders, and go to “No folder” if they have no other).")
                              : Lang.T("این پوشه خالی است.", "This folder is empty."));
        }

        /// <summary>The folders that did not fit in the row, to choose from.</summary>
        void ShowMoreFolders(List<string> keys, Point at)
        {
            ContextMenuStrip m = Theme.Menu();
            foreach (string k in keys)
            {
                string key = k;
                Item(m, folderBar.TitleOf(key) + "  " + Fa.N(folders.Count(key.Substring(2), copies.Select(c => c.Name))), () => folderBar.Selected = key);
            }
            Pop(m).Show(at, ToolStripDropDownDirection.BelowLeft);
        }

        /// <summary>The band's "پوشه‌ها": the same folder commands, for the ticked students.</summary>
        void ShowFolderCommands()
        {
            if (!AnyTicked()) return;
            List<Instance> targets = Chosen();
            ContextMenuStrip m = Theme.Menu();
            ToolStripMenuItem add = Item(m, Lang.T("افزودن انتخاب‌شده‌ها به پوشه (", "Add the selected to a folder (") + Fa.N(targets.Count) + ")", null);
            FillFolderItems(add, targets, false);
            Folder viewed = ViewedFolder();
            if (viewed != null && targets.Any(t => folders.Has(viewed.Id, t.Name)))
                Item(m, Lang.T("برداشتن انتخاب‌شده‌ها از «", "Remove the selected from “") + viewed.Name + "»", () => OutOfFolder(targets));
            Pop(m).Show(folderButton, new Point(folderButton.Width, folderButton.Height + Theme.S(4)), ToolStripDropDownDirection.BelowLeft);
        }

        // ------------------------------------------------------------- 3.21: the report inside the program

        /// <summary>What the program knows of one student's trading: the history kept on this computer and how its read went.</summary>
        sealed class Student
        {
            public LiveDashboardData LiveData;
            public LiveFeedSnapshot LiveFeed;
            public bool LiveCurrent, LivePending;
            public string LiveNotice;
            public Student Snapshot() {return (Student)MemberwiseClone();}
            public string Key = "";
            public AccountJournal Journal;
            /// <summary>When the kept history was written (this computer's clock): when the student was last read.</summary>
            public DateTime FileTime = DateTime.MinValue;
            public bool Loaded;
            /// <summary>Why the last read did not work; null when it did.</summary>
            public string Error;
            public bool Busy, Queued;
            /// <summary>Where the read is now ("وصل شد، در حال گرفتن تاریخچه…").</summary>
            public string Step;
            /// <summary>Today's numbers for the list, for the server day TodayFor.</summary>
            public PanelView Today;
            public DateTime TodayFor = DateTime.MinValue;
            public Activity Activity;
            /// <summary>An earlier first day asked for (a range further back than a refresh reads).</summary>
            public DateTime? Wanted;
        }

        readonly Dictionary<string, Student> students = new Dictionary<string, Student>(StringComparer.OrdinalIgnoreCase);
        // The reads waiting, in order, and those being read now.
        readonly List<string> readQueue = new List<string>();
        List<string> reading = new List<string>();
        ReportRunner report;
        bool appClosing, scriptProblemShown;
        // Each folder's reading again by itself: when its last round began and ended, and who is in the round going on.
        readonly Dictionary<string, DateTime> autoStart = new Dictionary<string, DateTime>(), autoEnd = new Dictionary<string, DateTime>();
        readonly Dictionary<string, List<string>> autoRound = new Dictionary<string, List<string>>();
        readonly DateTime startedAt = DateTime.Now;
        DateTime lastCleanup = DateTime.MinValue;
        bool cleaning;
        // 3.21.1: a student's report, on a page of its own in place of the list.
        readonly ReportPanel panel = new ReportPanel();
        readonly StudentHeader pageHeader = new StudentHeader { Dock = DockStyle.Top };
        readonly Panel studentPage = new Panel { Dock = DockStyle.Fill, Visible = false, BackColor = Theme.Page };
        Panel filters;
        string pageName;
        PanelRange panelRange = PanelRange.Today;
        DateTime customFrom = DateTime.Today.AddDays(-1), customTo = DateTime.Today;
        string panelKey;
#if SNAPSHOT
        readonly Dictionary<string, AccountJournal> fakeJournals = new Dictionary<string, AccountJournal>(StringComparer.OrdinalIgnoreCase);
        readonly Dictionary<string, DateTime> fakeTimes = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
#endif

        static readonly TradeLimits Limits = new TradeLimits();

        static DateTime ServerToday(AccountJournal j) { return ServerDays.Now(j, DateTime.UtcNow).Date; }

        Student StudentOf(Instance i)
        {
            Student s;
            if (!students.TryGetValue(i.Name, out s)) students[i.Name] = s = new Student();
            Account a = accounts.Get(i.Name);
            if (a == null || !a.HasLogin)
            {
                s.Journal = null; s.Today = null; s.Loaded = true; s.Key = "";
                return s;
            }
            string login = a.Login.Trim(), server = (a.Server ?? "").Trim(), key = login + "@" + server;
            Student liveStudent=DashboardStudent(i,a,s);
            if(liveStudent!=null && liveStudent.LiveData!=null)return liveStudent;
            DateTime t = DateTime.MinValue;
#if SNAPSHOT
            AccountJournal fake;
            if (fakeJournals.TryGetValue(i.Name, out fake))
            {
                if (!s.Loaded || s.Key != key) { s.Journal = fake; s.FileTime = fakeTimes[i.Name]; s.Loaded = true; s.Key = key; s.TodayFor = DateTime.MinValue; }
                t = s.FileTime;
            }
            else
#endif
            {
                string file = JournalCache.FileFor(login, server);
                try { if (File.Exists(file)) t = File.GetLastWriteTime(file); } catch { }
                if (!s.Loaded || s.Key != key || t != s.FileTime)
                {
                    s.Loaded = true;
                    s.Key = key;
                    s.FileTime = t;
                    s.Journal = null;
                    if (t != DateTime.MinValue)
                        try { s.Journal = JournalCache.Load(login, server); if(s.Journal!=null && s.Journal.Platform!=i.Kind.ToString())s.Journal=null; }
                        catch (Exception e) { Log.Write("kept history " + i.Name + ": " + e.Message); }
                    s.TodayFor = DateTime.MinValue;
                }
            }
            DateTime today = ServerToday(s.Journal);
            if (s.TodayFor != today)
            {
                s.TodayFor = today;
                s.Activity = ActivityRule.Of(s.Journal, today);
                s.Today = null;
                if (s.Journal != null)
                    try { s.Today = PanelMath.Build(s.Journal, ServerDays.Range(PanelRange.Today, today), Limits); }
                    catch (Exception e) { Log.Write("today " + i.Name + ": " + e.Message); }
            }
            return DashboardStudent(i,a,s) ?? s;
        }

        /// <summary>«به‌روزرسانی گزارش‌ها»: the ticked students, or (none ticked) every student the list shows now.</summary>
        void RefreshReports()
        {
            if (copies.Count == 0) { Ui.Message(this, Lang.T("هنوز نسخه‌ای ساخته نشده.", "No copies made yet.")); return; }
            ReadMany(chosen.Count > 0 ? Chosen() : shown.ToList(), chosen.Count > 0 ? Lang.T("انتخاب‌شده‌ها", "the selected") : Lang.T("دانشجوهای این فهرست", "the students of this list"));
        }

        /// <summary>One confirmation chooses MT4, MT5 or all within the current list/selection.</summary>
        void ReadMany(List<Instance> list, string who)
        {
            if (scheduledBatch != null) { SetStatus(Lang.T("گزارش خودکار یا ارسال آن در جریان است.", "Automated reporting or delivery is active.")); return; }
            if (report != null || readQueue.Count > 0)
            {
                SetStatus(Lang.T("گزارش‌گیری قبلی هنوز در حال اجراست؛ برای آزمون جداگانه ابتدا «توقف گزارش‌گیری» را بزنید.", "A report run is already active; stop it before starting a separate platform test.")); return;
            }
            if (copies.Count == 0) { Ui.Message(this, Lang.T("هنوز نسخه‌ای ساخته نشده.", "No copies made yet.")); return; }
            var eligible = list.Where(t => { Account a = accounts.Get(t.Name); return a != null && a.HasLogin; }).ToList();
            if (eligible.Count == 0) { ReadThese(eligible, who); return; }
            isolateManualReports = true;
            try
            {
                using (var choice = new ReportScopeDialog(eligible.Count(i => i.Kind == Kind.MT4), eligible.Count(i => i.Kind == Kind.MT5), who))
                {
                    if (choice.ShowDialog(this) != DialogResult.OK) return;
                    ReadThese(ReportScopes.Select(eligible, choice.Platform), who);
                }
            }
            finally { if (report == null && readQueue.Count == 0) isolateManualReports = false; }
        }

        void ReadThese(List<Instance> list, string who)
        {
            List<Instance> people = list.Where(t => { Account a = accounts.Get(t.Name); return a != null && a.HasLogin; }).ToList();
            if (people.Count == 0) { Ui.Message(this, Lang.T("برای این نسخه‌ها حسابی ثبت نشده؛ گزارش برای حساب‌هاست.", "These copies have no account; reports are for accounts."), MessageBoxIcon.Warning); return; }
            Read(people.Select(p => p.Name), null);
            if ((report == null && readQueue.Count == 0) || reportResults.Stopping) return;
            SetStatus(Lang.T("گزارش ", "The report of ") + Fa.N(people.Count) + Lang.T(" دانشجو (", " students (") + who + Lang.T(") خوانده می‌شود؛ هر ردیف همان لحظه که خوانده شد پر می‌شود.", ") are read; each row fills as soon as it is read."));
        }

        /// <summary>Puts students in the queue of reads (once each) and starts it when nothing is being read.</summary>
        void Read(IEnumerable<string> names, DateTime? wanted)
        {
            if (scheduledBatch != null && !scheduleStarting) { SetStatus(Lang.T("گزارش خودکار در جریان است؛ پس از پایان دوباره بزنید.", "An automated report is active; try again after it finishes.")); return; }
            if (report != null && reportResults.Stopping) { SetStatus(Lang.T("توقف قبلی در حال پایان است؛ چند لحظه بعد دوباره بزنید.", "The previous stop is finishing; retry in a moment.")); return; }
            names = names.ToList();
            if (report == null)
            {
                var selectedNames = new HashSet<string>(names, StringComparer.OrdinalIgnoreCase);
                string admission;
                try { admission = ReportRunner.NativeAdmissionProblem(settings, copies.Where(c => selectedNames.Contains(c.Name))); }
                catch (Exception e) { if (scheduleStarting) throw; SetStatus(e.Message); Ui.Error(this, e); return; }
                if (admission != null) { SetStatus(admission); if (!scheduleStarting) Ui.Message(this, admission, MessageBoxIcon.Information); return; }
            }
            bool newWork = report == null && readQueue.Count == 0;
            if (newWork) { reportWork.Begin(); reportResults.Begin(); }
            foreach (string n in names)
            {
                Student st;
                if (!students.TryGetValue(n, out st)) students[n] = st = new Student();
                if (wanted.HasValue && (!st.Wanted.HasValue || wanted.Value < st.Wanted.Value)) st.Wanted = wanted;
                if (readQueue.Contains(n, StringComparer.OrdinalIgnoreCase) || reading.Contains(n, StringComparer.OrdinalIgnoreCase)) continue;
                Account candidate = accounts.Get(n);
                if (candidate == null || !candidate.HasLogin || !copies.Any(c => c.Name.Equals(n, StringComparison.OrdinalIgnoreCase))) continue;
                readQueue.Add(n); reportWork.Add(n); reportResults.Add(n, candidate, copies.First(c => c.Name.Equals(n, StringComparison.OrdinalIgnoreCase)).Kind);
                st.Queued = true;
            }
            reportProgress.Set(reportWork, reportResults, newWork);
            StartReads();
            RefreshGrid(false);
            UpdatePanel();
        }

        void StartReads()
        {
            if (report != null || readQueue.Count == 0 || appClosing) return;
            List<string> batch = readQueue.ToList();
            readQueue.Clear();
            // The accounts as they are now: they can be edited in the window while it reads.
            var snapshot = new Dictionary<string, Account>(StringComparer.OrdinalIgnoreCase);
            foreach (Instance c in copies) snapshot[c.Name] = accounts.Get(c.Name);
            var jobs = new List<ReportJob>();
            foreach (string name in batch)
            {
                Student st = students[name];
                st.Queued = false;
                Instance c = copies.FirstOrDefault(x => string.Equals(x.Name, name, StringComparison.OrdinalIgnoreCase));
                Account a = accounts.Get(name);
                if (c == null || a == null || !a.HasLogin) continue;
                Student observed=StudentOf(c);
                DateTime from = ServerDays.ReadFrom(observed.Journal, ServerToday(observed.Journal), st.Wanted);
                st.Busy = true;
                st.Step = Lang.T("در انتظار نوبت…", "Waiting for its turn…");
                jobs.Add(new ReportJob
                {
                    Index = jobs.Count, Copy = c, Account = a, From = from, Limits = Limits,
                    Name = string.IsNullOrWhiteSpace(a.Trader) ? c.Name : a.Trader.Trim(),
                    Folders = string.Join(Lang.T("؛ ", "; "), folders.Of(c.Name).Select(f => f.Name)),
                });
            }
            reading = jobs.Select(j => j.Copy.Name).ToList();
            if (jobs.Count == 0) return;
            var range = new ReportRange { Kind = RangeKind.Custom, From = jobs.Min(j => j.From), To = DateTime.Today.AddDays(2) };
            int atOnce = ReportParallel.For(settings, jobs.Select(j => j.Copy.Kind));
            var runner = new ReportRunner(settings, jobs, copies.ToList(), name => { Account a; return snapshot.TryGetValue(name, out a) ? a : null; }, range, atOnce);
            foreach (ReportJob job in jobs.Take(runner.InitialParallel)) reportWork.Update(job.Copy.Name, StepState.Starting);
            reportProgress.Set(reportWork, reportResults);
            runner.Changed = (k, state, detail) =>
            {
                try { BeginInvoke((Action)(() => { if (report == runner) ReadStep(jobs[k].Copy.Name, state, detail); })); } catch { }
            };
            runner.Note = text => { try { BeginInvoke((Action)(() => SetStatus(text))); } catch { } };
            runner.ResultReady = (k, row) => { try { BeginInvoke((Action)(() => ReadResult(runner, jobs[k], row))); } catch { } };
            report = runner;
            Log.Write("reading " + jobs.Count + " students (" + atOnce + " at a time)");
            var thread = new System.Threading.Thread(() =>
            {
                List<ReportRow> rows = null;
                Exception error = null;
                try { rows = runner.Run(); }
                catch (Exception e) { error = e; }
                try { BeginInvoke((Action)(() => ReadsDone(runner, jobs, rows, error))); }
                catch { }
            }) { IsBackground = true, Name = "report" };
            thread.Start();
        }

        void ReadStep(string name, StepState state, string detail)
        {
            if (appClosing) return;
            Student st;
            if (!students.TryGetValue(name, out st)) return;
            reportResults.Stage(name, state, detail);
            if (state == StepState.Skipped && report != null && report.Stopping) reportWork.Cancel();
            else reportWork.Update(name, state);
            reportProgress.Set(reportWork, reportResults);
            switch (state)
            {
                case StepState.Waiting:
                case StepState.Retrying:
                    st.Busy = true; st.Step = detail; break;
                case StepState.Starting:
                case StepState.Reading:
                    st.Busy = true;
                    st.Step = detail ?? (state == StepState.Starting ? Lang.T("در حال باز کردن متاتریدر گزارش…", "Opening the report MetaTrader…") : Lang.T("در حال خواندن…", "Reading…"));
                    break;
                case StepState.Done:
                    st.Busy = false; st.Step = null; st.Error = null; st.Wanted = null;
                    st.Loaded = false;  // the history kept was just written: read it again
                    break;
                case StepState.Failed:
                case StepState.Skipped:
                    st.Busy = false; st.Step = null;
                    st.Error = (detail ?? Lang.T("خوانده نشد", "Not read")).Replace(Lang.T("از کش — ", "From cache — "), "");
                    break;
            }
            panelKey = null;
            RefreshGrid(false);
            UpdatePanel();
        }

        void ReadsDone(ReportRunner runner, List<ReportJob> jobs, List<ReportRow> rows, Exception error)
        {
            if (rows == null && error != null)
                foreach (ReportJob job in jobs) ReadResult(runner, job, new ReportRow { Error = error.GetType().Name + ": " + error.Message, Cancelled = runner.Stopping });
            if (rows != null)
                for (int index = 0; index < Math.Min(jobs.Count, rows.Count); index++) ReadResult(runner, jobs[index], rows[index]);
            if (report == runner) report = null;
            foreach (ReportJob j in jobs)
            {
                Student st;
                if (!students.TryGetValue(j.Copy.Name, out st)) continue;
                if (st.Busy) { st.Busy = false; st.Step = null; if (error != null) st.Error = Lang.T("خطا: ", "Error: ") + error.Message; }
                st.Loaded = false;
            }
            if (runner.Stopping) reportWork.Cancel();
            else foreach (ReportJob job in jobs)
            {
                Student state;
                bool failed = error != null || students.TryGetValue(job.Copy.Name, out state) && state.Error != null;
                reportWork.Update(job.Copy.Name, failed ? StepState.Failed : StepState.Done);
            }
            reportProgress.Set(reportWork, reportResults);
            reading.Clear();
            if (appClosing) return;
            if (error != null) Log.Write("reading: " + error);
            // A folder's round is over when none of its students is waiting or being read.
            foreach (string id in autoRound.Keys.ToList())
                if (!autoRound[id].Any(n => readQueue.Contains(n, StringComparer.OrdinalIgnoreCase)))
                {
                    autoEnd[id] = DateTime.Now;
                    autoRound.Remove(id);
                }
            if (runner.ScriptProblems.Count > 0 && !scriptProblemShown)
            {
                scriptProblemShown = true;
                Log.Write("report compiler details are included in each result");
            }
            int ok = jobs.Count(j => students.ContainsKey(j.Copy.Name) && students[j.Copy.Name].Error == null);
            SetStatus(Lang.T("گزارش خوانده شد: ", "Reports read: ") + Fa.N(ok) + Lang.T(" از ", " of ") + Fa.N(jobs.Count) + (ok < jobs.Count ? Lang.T(" (بقیه: دلیلش زیر «امروز» همان ردیف است)", " (the rest: the reason is under “Today” in its row)") : ""));
            Native.TrimSelf("reading reports");
            panelKey = null;
            StartReads();
            if (report == null && readQueue.Count == 0) FinishReportResults();
            RefreshGrid(false);
            UpdatePanel();
        }

        // ------------------------------------------------------------- the report under a row

        /// <summary>A student's row was clicked: their report on its own page (the list's place), with the way back.</summary>
        void OpenStudent(CopyRow r)
        {
            Instance i = Find(r);
            // A copy without an account has no report: its row only marks.
            if (i == null || r == null || !r.HasAccount) return;
            ShowStudent(i.Name);
        }

        void ShowStudent(string name)
        {
            // 3.25: drawn once, whole: no piece of the list or of a warning shows under the page while it is put together.
            using (Native.Freeze(body))
            {
                if (pageName == null || !string.Equals(pageName, name, StringComparison.OrdinalIgnoreCase)) panel.ResetDays();
                pageName = name;
                panelKey = null;
                card.Visible = false;
                folderBar.Visible = false;
                filters.Visible = false;
                infos.Visible = false;
                studentPage.Visible = true;
                studentPage.BringToFront();
                UpdatePanel();
            }
            panel.Focus();
        }

        /// <summary>«بازگشت به فهرست» (or Esc): the list as it was, with this student's row marked.</summary>
        void CloseStudent()
        {
            string name = pageName;
            pageName = null;
            using (Native.Freeze(body))
            {
                studentPage.Visible = false;
                card.Visible = true;
                folderBar.Visible = true;
                filters.Visible = true;
                infos.Visible = true;
                RefreshGrid(false);
            }
            if (name != null)
                for (int k = 0; k < grid.Rows.Count; k++)
                {
                    var cr = grid.Rows[k].Tag as CopyRow;
                    if (cr == null || !string.Equals(cr.Name, name, StringComparison.OrdinalIgnoreCase)) continue;
                    grid.ClearSelection();
                    grid.Rows[k].Selected = true;
                    try { if (!grid.Rows[k].Displayed) grid.FirstDisplayedScrollingRowIndex = k; } catch { }
                    break;
                }
            grid.Focus();
        }

        /// <summary>The students of the list as it is shown (folder, tab, search), in its order.</summary>
        List<string> PageOrder()
        {
            return shown.Where(c => { Account a = accounts.Get(c.Name); return a != null && a.HasLogin; }).Select(c => c.Name).ToList();
        }

        void StepStudent(int d)
        {
            List<string> list = PageOrder();
            int k = list.FindIndex(n => string.Equals(n, pageName, StringComparison.OrdinalIgnoreCase));
            if (k < 0 || k + d < 0 || k + d >= list.Count) return;
            ShowStudent(list[k + d]);
        }

        static string[] WeekDays { get { return new[] { Lang.T("یکشنبه", "Sunday"), Lang.T("دوشنبه", "Monday"), Lang.T("سه‌شنبه", "Tuesday"), Lang.T("چهارشنبه", "Wednesday"), Lang.T("پنجشنبه", "Thursday"), Lang.T("جمعه", "Friday"), Lang.T("شنبه", "Saturday") }; } }

        /// <summary>The range in words, at the top of the report.</summary>
        static string RangeWords(PanelRange kind, ReportRange r, DateTime today, AccountJournal j)
        {
            string day = WeekDays[(int)r.From.DayOfWeek] + " " + r.From.ToString("yyyy.MM.dd", CultureInfo.InvariantCulture);
            switch (kind)
            {
                case PanelRange.Today:
                    // The broker's day starts at 00:00 on its server; in Tehran (GMT+3:30) that is:
                    DateTime tehran = ServerClock.Of(j).ToGmt(r.From).AddHours(3.5);
                    return day + Lang.T(" · از شروع روز کارگزار (00:00 سرور = ", " · from the broker's day start (00:00 server = ") + tehran.ToString("HH:mm", CultureInfo.InvariantCulture) + Lang.T(" تهران) تا الان", " Tehran) to now");
                case PanelRange.Yesterday: return day + Lang.T(" · روز معاملاتی قبل", " · the previous trading day");
                case PanelRange.Week: return Lang.T("این هفته: از ", "This week: from ") + day + Lang.T(" تا الان", " to now");
                case PanelRange.Month: return Lang.T("این ماه: از ", "This month: from ") + r.From.ToString("yyyy.MM.dd", CultureInfo.InvariantCulture) + Lang.T(" تا الان", " to now");
                default: return "";
            }
        }

        /// <summary>Puts the student's page together (again when anything changed).</summary>
        void UpdatePanel()
        {
            string name = pageName;
            if (name == null) return;
            Instance i = copies.FirstOrDefault(c => string.Equals(c.Name, name, StringComparison.OrdinalIgnoreCase));
            Account a = i == null ? null : accounts.Get(i.Name);
            if (i == null || a == null || !a.HasLogin) { CloseStudent(); return; }
            Student st = StudentOf(i);
            AccountJournal j = st.Journal;
            DateTime today = ServerToday(j);
            ReportRange range = ServerDays.Range(panelRange, today, customFrom, customTo);
            string key = i.Name + "|" + panelRange + "|" + range.From.Ticks + "|" + range.To.Ticks + "|" + st.FileTime.Ticks + "|" + st.Busy + "|" + st.Queued + "|" + st.Step + "|" + st.Error + "|" + st.LiveCurrent + "|" + st.LivePending + "|" + st.LiveNotice;
            if (key != panelKey)
            {
                panelKey = key;
                panel.HasAccount = true;
                panel.Range = panelRange;
                panel.View = null;
                if (j != null)
                    try { panel.View = StudentPanel(st,range); }
                    catch (Exception e) { Log.Write("report page " + i.Name + ": " + e); }
                // The history kept does not reach back to the range's first day, or was read before the range began.
                panel.NotCovered = j != null && (!JournalCache.Covers(j, range.From) || j.Exported < range.From);
                panel.Busy = st.Busy || st.Queued;
                panel.BusyText = st.Busy ? st.Step : Lang.T("در صف خواندن…", "Waiting to read…");
                panel.Error = st.Error ?? (!st.LiveCurrent ? st.LiveNotice : null);
                panel.ReadLocal = st.FileTime != DateTime.MinValue ? (DateTime?)st.FileTime : null;
                panel.RangeText = RangeWords(panelRange, range, today, j);
            }
            // The page's top: the name, the account, and where it is in the list.
            CopyRow row = grid.Rows.Cast<DataGridViewRow>().Select(x => x.Tag as CopyRow).FirstOrDefault(x => x != null && x.Name == i.Name) ?? new CopyRow();
            pageHeader.Title = string.IsNullOrWhiteSpace(a.Trader) ? i.Name : a.Trader.Trim();
            string[] inFolders = folders.Of(i.Name).Select(f => f.Name).ToArray();
            // Each part after a Persian word, so the line keeps its order right to left around the Latin names and numbers.
            pageHeader.Meta = Lang.T("حساب ", "Account ") + a.Login.Trim() + Lang.T("  ·  سرور ", "  ·  Server ") + (a.Server ?? "").Trim() + Lang.T("  ·  نسخه‌ی ", "  ·  Copy ") + i.Kind + " " + i.Name +
                              (inFolders.Length > 0 ? Lang.T("  ·  پوشه: ", "  ·  Folder: ") + string.Join(Lang.T("، ", ", "), inFolders) : "");
            pageHeader.Status = row.Status.Length > 0 ? Lang.T("وضعیت: ", "Status: ") + row.Status : "";
            List<string> list = PageOrder();
            int at = list.FindIndex(n => string.Equals(n, i.Name, StringComparison.OrdinalIgnoreCase));
            pageHeader.CanPrev = at > 0;
            pageHeader.CanNext = at >= 0 && at < list.Count - 1;
            pageHeader.Invalidate();
            panel.Invalidate();
        }

        void PanelRangeWanted(PanelRange kind)
        {
            panelRange = kind;
            if (kind == PanelRange.Custom) panel.SetCustom(customFrom, customTo);
            panel.ResetDays();
            panelKey = null;
            UpdatePanel();
        }

        void PanelCustom(DateTime from, DateTime to)
        {
            customFrom = from;
            customTo = to;
            panel.ResetDays();
            panelKey = null;
            UpdatePanel();
        }

        /// <summary>«به‌روزرسانی» in the report: this student, reading back to the range's first day when it is further back.</summary>
        void PanelRefresh()
        {
            Instance i = pageName == null ? null : copies.FirstOrDefault(c => string.Equals(c.Name, pageName, StringComparison.OrdinalIgnoreCase));
            if (i == null) return;
            Student st = StudentOf(i);
            ReportRange range = ServerDays.Range(panelRange, ServerToday(st.Journal), customFrom, customTo);
            Read(new[] { i.Name }, range.From);
        }

        /// <summary>3.25 (approved mockup): «متن گزارش»: the ticked students in one text, for any range, with only the parts the coach ticks.
        /// Numbered as in the list shown (or the whole list for one not in it), as «کپی متن روز» is.</summary>
        void ShowReportText()
        {
            Func<Instance, bool> has = c => { Account a = accounts.Get(c.Name); return a != null && a.HasLogin; };
            List<Instance> list;
            if (chosen.Count == 0)
            {
                // 3.26 (CHANGE-016, approved): no one ticked: the text of everyone in the list in view, after asking.
                list = shown.Where(has).ToList();
                if (list.Count == 0) { Ui.Message(this, Lang.T("در این فهرست دانشجویی با حساب ثبت‌شده نیست؛ متن گزارش برای حساب‌هاست.", "No student in this list has an account; report text is for accounts."), MessageBoxIcon.Warning); return; }
                string n = Fa.N(list.Count);
                using (var ask = new AskDialog(Lang.T("کسی تیک نخورده", "Nobody is ticked"), Lang.T("متن گزارش همه‌ی ", "Make the report text of all ") + n + Lang.T(" نفرِ همین فهرست ساخته شود؟", " students in this list?"),
                                               Lang.T("برای چند نفر خاص، اول کنار اسمشان تیک بزنید.", "For a few students, tick them first."), Lang.T("متن همه‌ی ", "Text of all ") + n + Lang.T(" نفر", " students"), Lang.T("انصراف", "Cancel")))
                    if (ask.ShowDialog(this) != DialogResult.Yes) return;
            }
            else list = Chosen().Where(has).ToList();
            if (list.Count == 0) { Ui.Message(this, Lang.T("برای دانشجوهای انتخاب‌شده حسابی ثبت نشده؛ متن گزارش برای حساب‌هاست.", "The selected students have no account; report text is for accounts."), MessageBoxIcon.Warning); return; }
            Log.Write("report text: " + list.Count + " students");
            using (var d = new ReportTextDialog(ReportSource(list), settings, customFrom, customTo)) d.ShowDialog(this);
        }

        ReportTextSource ReportSource(List<Instance> list)
        {
            Func<Instance, bool> has = c => { Account a = accounts.Get(c.Name); return a != null && a.HasLogin; };
            List<string> order = PageOrder(), all = copies.Where(has).Select(c => c.Name).ToList();
            Func<Instance, int> number = c =>
            {
                int k = order.FindIndex(n => string.Equals(n, c.Name, StringComparison.OrdinalIgnoreCase));
                if (k < 0) k = all.FindIndex(n => string.Equals(n, c.Name, StringComparison.OrdinalIgnoreCase));
                return k + 1;
            };
            Func<Instance, string> who = c => { Account a = accounts.Get(c.Name); return string.IsNullOrWhiteSpace(a.Trader) ? c.Name : a.Trader.Trim(); };
            // 3.25.1 (approved): read more than an hour ago (or never): the window says so and offers to read again.
            Func<Instance, bool> stale = c => { Student st = StudentOf(c); return st.Journal == null || (!st.LiveCurrent && !string.IsNullOrEmpty(st.LiveNotice)) || DateTime.Now - st.FileTime > TimeSpan.FromHours(1); };
            var src = new ReportTextSource
            {
                Names = list.Select(who).ToList(),
                RangeOf = (kind, from, to) => ServerDays.Range(kind, ServerToday(StudentOf(list[0]).Journal), from, to),
                Entries = (kind, from, to) => list.Select(c =>
                {
                    Student st = StudentOf(c);
                    PanelView v = null;
                    if (st.Journal != null)
                        try { v = StudentPanel(st,ServerDays.Range(kind, ServerToday(st.Journal), from, to)); }
                        catch (Exception e) { Log.Write("report text " + c.Name + ": " + e.Message); }
                    return new TextEntry { Number = number(c), Name = who(c), Login = accounts.Get(c.Name).Login, View = v };
                }).ToList(),
                NotReadToday = () => list.Where(stale).Select(who).ToList(),
                // 3.26 (CHANGE-018): the orange label beside an old one in the window's list.
                StaleNotes = () => list.Select(c => { Student st=StudentOf(c); return st.LiveCurrent ? "" : !string.IsNullOrEmpty(st.LiveNotice) ? st.LiveNotice : !stale(c) ? "" : st.Journal == null ? Lang.T("خوانده نشده", "Not read") : When(st.FileTime); }).ToList(),
                StaleSince = () =>
                {
                    List<Instance> old = list.Where(stale).ToList();
                    if (old.Count == 0 || old.Any(c => StudentOf(c).Journal == null)) return null;
                    return old.Min(c => StudentOf(c).FileTime);
                },
                Reading = () => list.Count(c => { Student st; return students.TryGetValue(c.Name, out st) && (st.Busy || st.Queued); }),
                ReadNow = (kind, from, to) =>
                {
                    List<Instance> old = list.Where(stale).ToList();
                    if (old.Count == 0) return;
                    Read(old.Select(c => c.Name), ServerDays.Range(kind, ServerToday(StudentOf(old[0]).Journal), from, to).From);
                },
                Fingerprint = () => string.Join("|", list.Select(c => { Student st=StudentOf(c); return st.FileTime.Ticks+":"+st.LiveCurrent+":"+st.LivePending+":"+st.LiveNotice; })),
            };
            return src;
        }

        /// <summary>3.22.1: «کپی متن روز»: the day shown, in the coach's message format, in a window with «کپی».</summary>
        void CopyDayText()
        {
            UpdatePanel();
            Instance i = pageName == null ? null : copies.FirstOrDefault(c => string.Equals(c.Name, pageName, StringComparison.OrdinalIgnoreCase));
            Account a = i == null ? null : accounts.Get(i.Name);
            PanelView v = panel.View;
            if (i == null || a == null || !a.HasLogin || v == null) return;
            int at = PageOrder().FindIndex(n => string.Equals(n, i.Name, StringComparison.OrdinalIgnoreCase));
            string who = string.IsNullOrWhiteSpace(a.Trader) ? i.Name : a.Trader.Trim();
            if (!v.SingleDay)
            {
                // 3.27.2 (CHANGE-022): several days: as «متن گزارش» writes them, with the parts ticked there.
                string range = RangeText(v, at >= 0 ? at + 1 : 1, who, a.Login);
                using (var r = new DayTextDialog(who, panel.RangeText, range, true)) r.ShowDialog(this);
                return;
            }
            string text = DayText.Make(at >= 0 ? at + 1 : 1, who, a.Login, v);
            DateTime day = v.Range.From;
            using (var d = new DayTextDialog(who, WeekDays[(int)day.DayOfWeek] + " " + day.ToString("yyyy.MM.dd", CultureInfo.InvariantCulture), text)) d.ShowDialog(this);
        }

        /// <summary>3.27.2 (CHANGE-022): one student's text for the range shown, with the parts ticked in «متن گزارش».</summary>
        string RangeText(PanelView v, int number, string who, string login)
        {
            var e = new TextEntry { Number = number, Name = who, Login = login, View = v };
            return ReportText.Make(v.Range, new[] { e }, ReportText.Parse(settings.ReportParts));
        }

        // ------------------------------------------------------------- the list's order

        static string[] SortTitles { get { return new[] { Lang.T("اول MT4، بعد MT5", "MT4 first, then MT5"), Lang.T("اول MT5، بعد MT4", "MT5 first, then MT4"), Lang.T("نام دانشجو (الف تا ی)", "Student name (A to Z)"), Lang.T("شماره حساب", "Account") }; } }

        /// <summary>3.23: «مرتب‌سازی»: the list arranged once in one of four ways; the rows can still be dragged after it.</summary>
        ContextMenuStrip sortMenu;

        void ShowSortMenu(Point at)
        {
            if (sortMenu != null) sortMenu.Dispose();
            ContextMenuStrip m = sortMenu = Theme.Menu();
            for (int k = 0; k < SortTitles.Length; k++)
            {
                ListSort how = (ListSort)k;
                var item = new ToolStripMenuItem(SortTitles[k]) { Padding = Theme.Pad(10, 6) };
                item.Click += (s, e) => Guard(() => ArrangeList(how));
                m.Items.Add(item);
            }
            m.Show(at, ToolStripDropDownDirection.BelowRight);
        }

        void ArrangeList(ListSort how)
        {
            string title = SortTitles[(int)how];
            if (!Ui.Confirm(this, Lang.T("ترتیب فهرست بر اساس «", "Arrange the list by “") + title + Lang.T("» چیده شود؟\n\nترتیب فعلی فهرست جایش را می‌گیرد.", "”?\n\nIt replaces the current order of the list.")))
                return;
            List<Instance> all = ListOrder.Apply(StudentDirectory.All(settings, accounts), c => c.Name, order);
            var entries = all.Select(i =>
            {
                Account a = accounts.Get(i.Name);
                bool has = a != null && a.HasLogin;
                return new ListEntry { Name = i.Name, Kind = i.Kind.ToString(), Student = has ? a.Trader ?? "" : "", Login = has ? a.Login ?? "" : "" };
            }).ToList();
            List<string> arranged = ListOrder.Arrange(entries, how);
            try
            {
                // The order it had stays beside it (one step back), in case it is wanted again.
                if (File.Exists(ListOrder.FilePath)) File.Copy(ListOrder.FilePath, ListOrder.FilePath + ".before-sort", true);
                ListOrder.Save(arranged);
            }
            catch (Exception e) { Log.Write("order: " + e.Message); }
            grid.HeaderSortColumn = ""; grid.HeaderSortDirection = 0;
            order = arranged;
            Log.Write("list arranged: " + how);
            RefreshGrid(true);
            SetStatus(Lang.T("فهرست بر اساس «", "The list was arranged by “") + title + Lang.T("» چیده شد.", "”."));
        }

        List<string> order = ListOrder.Load();

        // ------------------------------------------------------------- reading again by itself

        void ChooseAuto(Point at)
        {
            Folder f = ViewedFolder();
            if (f == null) return;
            int now = AutoRefresh.Of(f);
            ContextMenuStrip m = Theme.Menu();
            foreach (int minutes in AutoRefresh.Choices)
            {
                int choice = minutes;
                ToolStripMenuItem item = Item(m, (minutes == now ? "✓  " : "     ") + AutoRefresh.Text(minutes), () =>
                {
                    AutoRefresh.Set(f, choice);
                    if (!SaveFolders()) return;
                    autoStart.Remove(f.Id);
                    autoEnd.Remove(f.Id);
                    Log.Write("folder " + f.Name + ": read again by itself " + (choice == 0 ? "off" : "every " + choice + " minutes"));
                    SetStatus(choice == 0 ? Lang.T("به‌روزرسانی خودکار «", "Auto refresh of “") + f.Name + Lang.T("» خاموش شد.", "” turned off.") :
                              Lang.T("دانشجوهای «", "The students of “") + f.Name + Lang.T("» هر ", "” are read one by one every ") + Fa.N(choice) + Lang.T(" دقیقه یک‌به‌یک خوانده می‌شوند (فقط وقتی برنامه باز است).", " minutes (only while the program is open)."));
                    RefreshGrid(false);
                });
            }
            Pop(m).Show(at);
        }

        /// <summary>Every half minute: a folder whose time has come is read again (not in the first two minutes after the program opens,
        /// and not while the computer is short of memory).</summary>
        void AutoRefreshTick()
        {
            if (isolateManualReports || scheduledBatch != null) return;
            if (appClosing || (DateTime.Now - startedAt).TotalMinutes < 2) return;
            foreach (Folder f in folders.All)
            {
                int m = AutoRefresh.Of(f);
                if (m == 0 || autoRound.ContainsKey(f.Id)) continue;
                DateTime began, ended;
                bool before = autoStart.TryGetValue(f.Id, out began);
                autoEnd.TryGetValue(f.Id, out ended);
                if (before && DateTime.Now < AutoRefresh.Next(began, ended, m)) continue;
                ulong free = Checks.FreeRamMb();
                if (free > 0 && free < AutoRefresh.MinFreeMb)
                {
                    if (ticks % 200 == 0) Log.Write("auto refresh of " + f.Name + " waits: " + free + " MB free");
                    continue;
                }
                // Those read within the interval already (by hand, or by another folder) are left for next time.
                List<string> names = copies.Where(c => folders.Has(f.Id, c.Name))
                    .Where(c => { Account a = accounts.Get(c.Name); return a != null && a.HasLogin; })
                    .Where(c => { Student st = StudentOf(c); return st.FileTime == DateTime.MinValue || (DateTime.Now - st.FileTime).TotalMinutes >= m - 1; })
                    .Select(c => c.Name).ToList();
                autoStart[f.Id] = DateTime.Now;
                if (names.Count == 0) { autoEnd[f.Id] = DateTime.Now; continue; }
                autoRound[f.Id] = names;
                Log.Write("auto refresh of folder " + f.Name + ": " + names.Count + " students");
                Read(names, null);
            }
        }

        string AutoLine()
        {
            Folder f = ViewedFolder();
            int m = AutoRefresh.Of(f);
            if (f == null || m == 0) return "";
            if (autoRound.ContainsKey(f.Id)) return Lang.T("  |  خودکار «", "  |  Auto “") + f.Name + Lang.T("»: در حال خواندن", "”: reading");
            DateTime began, ended;
            if (!autoStart.TryGetValue(f.Id, out began)) return Lang.T("  |  خودکار «", "  |  Auto “") + f.Name + Lang.T("»: به‌زودی", "”: soon");
            autoEnd.TryGetValue(f.Id, out ended);
            int left = (int)Math.Ceiling((AutoRefresh.Next(began, ended, m) - DateTime.Now).TotalMinutes);
            return Lang.T("  |  خودکار «", "  |  Auto “") + f.Name + Lang.T("»: بعدی ", "”: next ") + (left <= 0 ? Lang.T("به‌زودی", "soon") : Fa.N(left) + Lang.T(" دقیقه دیگر", " min from now"));
        }

        // ------------------------------------------------------------- unneeded files, removed by themselves

        /// <summary>3.21: what copies do not need (MetaEditor, the strategy tester and its data, uninstall) is deleted by itself, from
        /// closed copies only, a few seconds after the program opens and every two hours. MetaTrader's own update puts them back.
        /// The main install of MetaTrader is never touched, nor anything of an account. MetaEditor stays while the report script
        /// still needs it to be built and no installed MetaTrader has one.</summary>
        void AutoCleanup()
        {
            if (cleaning || appClosing || copies.Count == 0) return;
            if ((DateTime.Now - startedAt).TotalSeconds < 20 || (DateTime.Now - lastCleanup).TotalHours < 2) return;
            lastCleanup = DateTime.Now;
            Dictionary<string, Process> running = Processes.Running();
            List<Instance> closed = copies.Where(i => !Processes.IsRunning(running, i.Exe)).ToList();
            if (closed.Count == 0) return;
            var keepEditor = new HashSet<Kind>();
            foreach (Kind k in closed.Select(c => c.Kind).Distinct())
            {
                bool built = ReportScript.Ready(settings, k) || ReportScript.OnOlder(settings, k);
                bool installed = Installs.Find(k, settings).Any(d => File.Exists(Path.Combine(d, k == Kind.MT5 ? "metaeditor64.exe" : "metaeditor.exe")));
                if (!built && !installed) keepEditor.Add(k);
            }
            cleaning = true;
            var thread = new System.Threading.Thread(() =>
            {
                long freed = 0;
                int removed = 0, kept = 0;
                try
                {
                    foreach (CleanupGroup g in Cleanup.Scan(closed, DateTime.Now).Where(x => x.Id == "tools" || x.Id == "tester"))
                        foreach (string p in g.Paths)
                        {
                            Instance owner = closed.FirstOrDefault(c => p.StartsWith(c.Dir.TrimEnd('\\', '/') + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase));
                            if (owner == null) continue;
                            if (keepEditor.Contains(owner.Kind) && Path.GetFileName(p).StartsWith("metaeditor", StringComparison.OrdinalIgnoreCase)) { kept++; continue; }
                            try
                            {
                                long size = File.Exists(p) ? new FileInfo(p).Length : Directory.Exists(p) ? CopyMaker.FolderSize(p) : 0;
                                if (File.Exists(p)) File.Delete(p);
                                else if (Directory.Exists(p)) Directory.Delete(p, true);
                                freed += size;
                                removed++;
                            }
                            catch (Exception e) { Log.Write("auto cleanup " + p + ": " + e.Message); }
                        }
                }
                catch (Exception e) { Log.Write("auto cleanup: " + e.Message); }
                if (removed > 0 || kept > 0) Log.Write("auto cleanup: " + removed + " items deleted from closed copies (" + freed + " bytes)" + (kept > 0 ? ", MetaEditor kept in " + kept + " (the report script is not built yet)" : ""));
                try
                {
                    BeginInvoke((Action)(() =>
                    {
                        cleaning = false;
                        if (freed > 1024L * 1024) SetStatus(Lang.T("پاکسازی خودکار: ", "Auto cleanup: ") + TextUtil.Size(freed) + Lang.T(" فایل غیرلازم از نسخه‌های بسته پاک شد.", " unneeded files removed from closed copies."));
                        bannerKey = null;
                    }));
                }
                catch { cleaning = false; }
            }) { IsBackground = true, Name = "cleanup" };
            thread.Start();
        }

        void ClearChoice()
        {
            chosen.Clear();
            RefreshGrid(false);
        }

        /// <summary>The band's labels follow the ticked copies.</summary>
        void ShowChoice()
        {
            int n = chosen.Count;
            ShowCounts();
            bool any = n > 0;
            if (any) choicePill.SetText(Fa.N(n) + Lang.T(" دانشجو انتخاب شده", " students selected"));
            choicePill.Link = any && shown.Count > 1 && chosen.State(shown.Select(c => c.Name)) != 2 ? Lang.T("انتخاب همه‌ی ", "Select all ") + Fa.N(shown.Count) : "";
            closeAllButton.SetText(Lang.T("بستن همه‌ی بازها (", "Close all open (") + Fa.N(openCount) + ")");
            int readingNow = reading.Count + readQueue.Count;
            DateTime last = LastRead(shown);
            refreshButton.Note = readingNow > 0 ? Lang.T("در حال خواندن ", "Reading ") + Fa.N(readingNow) + Lang.T(" نفر", " students") : last == DateTime.MinValue ? "" : PanelMath.Ago(last, DateTime.Now);
            bool changed = false;
            Action<Control, bool> show = (c, v) => { if (c.Visible != v) { c.Visible = v; changed = true; } };
            show(newButton, !any);
            show(refreshButton, !any);
            show(closeAllButton, !any && openCount > 0);
            show(toolsButton, !any);
            show(exportButton, !any);
            show(choicePill, any);
            foreach (Control c in new Control[] { runButton, stopButton, readChosenButton, folderButton, clearButton }) show(c, any);
            // 3.25.1: «متن گزارش» in both; with no one ticked it says to tick first.
            show(textButton, true);
            if (changed)
            {
                band.PerformLayout();
                band.Invalidate();
            }
            grid.HeaderCheck = chosen.State(shown.Select(c => c.Name));
        }

        // Copies being closed, followed until they are all gone (see FollowClosing).
        List<Instance> closing;
        DateTime closingSince;
        int closingTotal;
        // Ended already (asked for at once, or after the wait).
        bool closingForced;

        /// <summary>Closes the MetaTraders this program opened, then follows: progress under the title, and after half a minute
        /// an offer to end those still open. A MetaTrader opened any other way is left open, and the user is told.</summary>
        void CloseAndFollow(List<Instance> list, bool force)
        {
            Dictionary<string, Process> running = Processes.Running();
            List<Instance> open = list.Where(i => Processes.IsRunning(running, i.Exe)).ToList();
            if (open.Count == 0) { SetStatus(Lang.T("هیچ‌کدام باز نبود.", "None of them was open.")); return; }
            Launcher.CloseReport r = Launcher.Close(open, force);
            var left = new HashSet<string>(r.NotOurs.Concat(r.Denied), StringComparer.OrdinalIgnoreCase);
            List<Instance> ours = open.Where(i => !left.Contains(i.Name)).ToList();
            if (ours.Count > 0)
            {
                closing = ours;
                closingSince = DateTime.Now;
                closingTotal = ours.Count;
                closingForced = force;
                SetStatus(Lang.T("در حال بستن ", "Closing ") + Fa.N(ours.Count) + Lang.T(" متاتریدر… هر کدام اول چارت‌ها و تنظیماتش را ذخیره می‌کند.", " MetaTraders… each first saves its charts and settings."));
            }
            else SetStatus(Lang.T("هیچ متاتریدری بسته نشد.", "No MetaTrader was closed."));
            if (r.Denied.Count > 0) TellDenied(r.Denied);
            if (r.NotOurs.Count > 0) TellNotOurs(r.NotOurs);
        }

        void FollowClosing()
        {
            if (closing == null) return;
            Dictionary<string, Process> running = Processes.Running();
            List<Instance> still = closing.Where(i => Processes.IsRunning(running, i.Exe)).ToList();
            if (still.Count == 0)
            {
                SetStatus(closingTotal == 1 ? Lang.T("بسته شد.", "Closed.") : Lang.T("همه بسته شدند (", "All closed (") + Fa.N(closingTotal) + Lang.T(" متاتریدر).", " MetaTraders)."));
                if (closingTotal > 1) Native.TrimSelf("closing " + closingTotal + " MetaTraders");
                closing = null;
                return;
            }
            SetStatus(Lang.T("در حال بستن… ", "Closing… ") + Fa.N(closingTotal - still.Count) + Lang.T(" از ", " of ") + Fa.N(closingTotal) + Lang.T(" بسته شد.", " closed."));
            if (!Launcher.ForceDue(closingSince, DateTime.Now, closingForced)) return;
            // Half a minute to save charts and settings; whatever is still open then (stuck, or blank) is ended, without a question.
            closingForced = true;
            Log.Write(still.Count + " terminals still open " + Launcher.CloseWaitSeconds + " s after being asked to close: ended (" + string.Join(", ", still.Select(c => c.Name)) + ")");
            Launcher.CloseReport r = Launcher.Close(still, true);
            SetStatus(Fa.N(r.Ended.Count) + Lang.T(" متاتریدر بعد از ", " MetaTraders did not close after ") + Fa.N(Launcher.CloseWaitSeconds) + Lang.T(" ثانیه بسته نشد و به‌اجبار بسته شد.", " seconds and were forced to close."));
            if (r.Denied.Count > 0) TellDenied(r.Denied);
        }

        void TellNotOurs(List<string> names)
        {
            Ui.Message(this, (names.Count == 1 ? Lang.T("این متاتریدر را", "This MetaTrader was") : Lang.T("این ", "These ") + Fa.N(names.Count) + Lang.T(" متاتریدر را", " MetaTraders were")) +
                             Lang.T(" این برنامه باز نکرده (دستی یا با برنامه‌ی دیگری باز شده)، پس دست نخورد و باز ماند:\n", " not opened by this program (opened by hand or by another program), so it was not touched and stays open:\n") +
                             string.Join(Lang.T("، ", ", "), names.Take(12)) + (names.Count > 12 ? Lang.T("، …", ", …") : "") +
                             Lang.T("\n\nبرنامه فقط متاتریدرهایی را می‌بندد که خودش باز کرده است. این‌ها را با ضربدر خودشان ببندید.", "\n\nThe program only closes the MetaTraders it opened itself. Close these with their own × button."));
        }

        void TellDenied(List<string> names)
        {
            Ui.Message(this, Lang.T("ویندوز اجازه نداد این‌ها بسته شوند، چون با دسترسی مدیر باز شده‌اند (همان «Yes» در سؤال ویندوز):\n", "Windows did not allow these to close, because they were opened as administrator (the “Yes” in the Windows question):\n") +
                             string.Join(Lang.T("، ", ", "), names.Take(12)) + (names.Count > 12 ? Lang.T("، …", ", …") : "") + Lang.T("\n\nآن‌ها را با ضربدر خودشان ببندید.", "\n\nClose them with their own × button."), MessageBoxIcon.Warning);
        }

        void EditAccount()
        {
            Instance i = OneSelected();
            if (i != null) EditAccountOf(i);
        }

        void EditAccountOf(Instance i)
        {
            using (var d = new AccountDialog(i, accounts, settings))
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
            }
            lastFailure.Remove(i.Name);
            watches.Remove(i.Name);
            RefreshAll(false);
        }

        void CopyValue(string which)
        {
            Instance i = OneSelected();
            if (i == null) return;
            Account acc = accounts.Get(i.Name);
            if (acc == null || !acc.HasLogin) { Ui.Message(this, Lang.T("برای این نسخه حسابی ثبت نشده.", "No account is saved for this copy.")); return; }
            if (which == "login")
            {
                Clipboard.SetText(acc.Login);
                SetStatus(Lang.T("شماره حساب کپی شد.", "Account number copied."));
                return;
            }
            string value = Secret.Unprotect(which == "master" ? acc.MasterEnc : acc.InvestorEnc);
            if (string.IsNullOrEmpty(value)) { Ui.Message(this, Lang.T("این رمز ثبت نشده، یا روی این کاربر ویندوز خوانده نمی‌شود.", "This password is not saved, or cannot be read for this Windows user."), MessageBoxIcon.Warning); return; }
            Clipboard.SetText(value);
            clipboardSecret = value;
            clipTimer.Stop();
            clipTimer.Start();
            SetStatus(Lang.T("رمز کپی شد؛ ۳۰ ثانیه‌ی دیگر از حافظه‌ی کپی پاک می‌شود.", "Password copied; it is removed from the clipboard in 30 seconds."));
        }

        void ClearSecret()
        {
            clipTimer.Stop();
            if (clipboardSecret == null) return;
            try { if (Clipboard.ContainsText() && Clipboard.GetText() == clipboardSecret) Clipboard.Clear(); } catch { }
            clipboardSecret = null;
        }

        void RemoveCopies()
        {
            List<Instance> sel = Selected();
            if (sel.Count == 0) { Ui.Message(this, Lang.T("اول نسخه‌ها را در جدول انتخاب کنید.", "First select copies in the list.")); return; }
            Dictionary<string, Process> running = Processes.Running();
            List<Instance> open = sel.Where(i => Processes.IsRunning(running, i.Exe)).ToList();
            if (open.Count > 0) { Ui.Message(this, Lang.T("اول این نسخه‌ها را ببندید: ", "Close these copies first:") + string.Join(Lang.T("، ", ", "), open.Select(i => i.Name)), MessageBoxIcon.Warning); return; }
            if (!Ui.Confirm(this, Lang.T("این نسخه‌ها به سطل بازیافت می‌روند و حساب ذخیره‌شده‌شان در این برنامه هم پاک می‌شود:\n", "These copies go to the Recycle Bin and their saved account is removed from this program too:\n") + string.Join(Lang.T("، ", ", "), sel.Select(i => i.Name)) + Lang.T("\n\nادامه می‌دهید؟", "\n\nContinue?"))) return;
            foreach (Instance i in sel)
            {
                bool gone = !Directory.Exists(i.Dir) || Native.ToRecycleBin(i.Dir);
                if (!gone)
                {
                    if (!Ui.Confirm(this, i.Name + Lang.T(" به سطل بازیافت نرفت (شاید خیلی بزرگ است). برای همیشه پاک شود؟", " did not go to the Recycle Bin (maybe it is very large). Delete it for good?"))) continue;
                    Directory.Delete(i.Dir, true);
                }
                accounts.Remove(i.Name);
                Launch was;
                if (launches.TryGetValue(i.Name, out was)) DropUpdateFile(was);
                launches.Remove(i.Name);
                folders.Forget(new[] { i.Name });
                Log.Write("removed copy " + i.Name);
            }
            accounts.Save();
            if (folders.All.Count > 0) SaveFolders();
            RefreshAll(true);
        }

        void FixHeap()
        {
            int? current = Heap.Current();
            int kb;
            using (var d = new HeapDialog(current))
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
                kb = d.Kb;
            }
            if (current.HasValue && current.Value == kb) { Ui.Message(this, Lang.T("همین مقدار تنظیم است.", "This value is already set.")); return; }
            if (Ui.IsAdmin()) Heap.Set(kb);
            else
            {
                try
                {
                    var p = Process.Start(new ProcessStartInfo(Application.ExecutablePath, "--heap " + kb) { Verb = "runas", UseShellExecute = true });
                    if (p != null) p.WaitForExit();
                }
                catch (Win32Exception)
                {
                    Ui.Message(this, Lang.T("اجازه‌ی مدیر سیستم داده نشد؛ چیزی تغییر نکرد.", "Administrator permission was not given; nothing changed."), MessageBoxIcon.Warning);
                    return;
                }
            }
            int? after = Heap.Current();
            if (after.HasValue && after.Value == kb) Ui.Message(this, Lang.T("انجام شد. ویندوز را یک بار ری‌استارت کنید تا اعمال شود.", "Done. Restart Windows once for it to apply."));
            else Ui.Message(this, Lang.T("تغییر انجام نشد.", "The change was not made."), MessageBoxIcon.Warning);
            bannerKey = null;
            UpdateBanner();
        }

        /// <summary>The student's name for a copy (the copy's own name without one).</summary>
        string WhoIs(string copy)
        {
            Account a = accounts.Get(copy);
            return a != null && a.HasLogin && a.Trader.Trim().Length > 0 ? a.Trader.Trim() : copy;
        }

        /// <summary>3.22.4: why a copy closed right after this program started it, from its journal since that start.</summary>
        static EarlyReason Explained(Instance i, Account a, Launch l)
        {
            try { return EarlyClose.Of(i, a, l.Time); }
            catch (Exception e) { Log.Write("early close " + i.Name + ": " + e.Message); return new EarlyReason(); }
        }

        /// <summary>For «بررسی سیستم»: each copy that closed right after starting, why, and the last lines of its journal.</summary>
        string EarlySummary()
        {
            var sb = new StringBuilder();
            foreach (KeyValuePair<string, Launch> e in launches.Where(x => x.Value.ClosedEarly).OrderBy(x => x.Key, StringComparer.OrdinalIgnoreCase))
            {
                Launch l = e.Value;
                if (sb.Length == 0) sb.AppendLine().AppendLine(Lang.T("— متاتریدرهایی که بلافاصله بعد از اجرا بسته شدند —", "— MetaTraders that closed right after they started —"));
                Account a = accounts.Get(e.Key);
                sb.AppendLine(e.Key + (a != null && a.HasLogin ? " (" + (a.Server ?? "").Trim() + ")" : "") + Lang.T("، اجرا ", ", started ") + l.Time.ToString("HH:mm:ss", CultureInfo.InvariantCulture) + ": " +
                              (launchErrors.ContainsKey(e.Key) ? launchErrors[e.Key] : l.Early != null ? l.Early.Text : Lang.T("دلیلش خوانده نشد.", "The reason could not be read.")));
                if (l.Early != null)
                {
                    if (l.Early.Tail.Count == 0) sb.AppendLine(Lang.T("  (ژورنال متاتریدر از این اجرا چیزی ندارد)", "  (MetaTrader's journal has nothing from this run)"));
                    foreach (string line in l.Early.Tail) sb.AppendLine("  " + line);
                }
            }
            return sb.ToString();
        }

        void ShowReport()
        {
            string text = Checks.Report(settings, copies, accounts) + EarlySummary() + StartupQueueSummary() + DashboardReadinessSummary();
            try { text += LiveAutoStart.Diagnostics(Installs.Copies(settings)); } catch (Exception e) { text += "\r\nLive diagnostics: " + e.Message; }
            try { text += ReportTrace.Summary(settings); } catch (Exception e) { text += Lang.T("\r\nگزارش معاملات: ", "\r\nTrade report: ") + e.Message; }
            Log.Write("system check\r\n" + text);
            using (var d = new TextDialog(Lang.T("بررسی سیستم و عیب‌یابی", "System check and troubleshooting"), text, true)) d.ShowDialog(this);
        }

        public static string HelpText()
        {
            return
                Lang.T("دانشجوی جدید\r\n", "New student\r\n") +
                Lang.T("۱. یک بار متاتریدرِ بروکر (مثلاً MT5 بروکر WM Markets) را از سایت خودش نصب کنید.\r\n", "1. Install the broker's MetaTrader once (e.g. the MT5 of WM Markets) from its own website.\r\n") +
                Lang.T("۲. «دانشجوی جدید» (Ctrl+N): نام، MT5 یا MT4، شماره حساب، نوع ورود اینوستور یا مستر، رمز، سرور و پوشهٔ ساخت.\r\n", "2. “New student” (Ctrl+N): name, MT5 or MT4, account number, investor/master mode, password, server and copies folder.\r\n") +
                Lang.T("   برای سرور، نام بروکر را بنویسید (مثلاً WM Markets) و سرور حساب را از فهرست بزنید. فهرست از MetaQuotes گرفته می‌شود؛ هیچ اطلاعاتی از شما فرستاده نمی‌شود.\r\n", "   For the server, type the broker's name (e.g. WM Markets) and pick the account's server from the list. The list comes from MetaQuotes; nothing of yours is sent.\r\n") +
                Lang.T("۳. «افزودن و اتصال»: یک نسخه‌ی سبک از متاتریدرِ همان بروکر ساخته و باز می‌شود و برنامه می‌گوید ورود موفق بود یا نه.\r\n", "3. “Add and connect”: a light copy of that broker's MetaTrader is made and opened, and the program says whether the login worked.\r\n") +
                Lang.T("۴. اگر تنظیم حافظهٔ پنجره‌های ویندوز بیش از 20480 KB است، از «ابزارها > تنظیم حافظهٔ پنجره‌های ویندوز» آن را بررسی کنید. اصلاح نیازمند ری‌استارت است و تضمین تعداد اجرا نیست.\r\n\r\n", "4. If the configured desktop heap exceeds 20480 KB, review Tools > Windows desktop heap setting. Correction requires a restart and does not guarantee a terminal count.\r\n\r\n") +
                Lang.T("فهرست\r\n", "The list\r\n") +
                Lang.T("هر ردیف یک متاتریدر است. «باز کردن» آن را با همان حساب باز می‌کند؛ اگر باز است، «نمایش» پنجره‌اش را جلو می‌آورد.\r\n", "Each row is one MetaTrader. “Open” opens it with that account; if it is open, “Show” brings its window forward.\r\n") +
                Lang.T("ترتیب ردیف‌ها: «مرتب‌سازی» کنار زبانه‌ها فهرست را یک بار می‌چیند و ترتیب ذخیره می‌شود.\r\n", "Row order: “Sort” next to the tabs arranges the list once, and the order is saved.\r\n") +
                Lang.T("«⋯» کنار هر ردیف (یا کلیک راست): حساب و رمز، کپی شماره حساب، پوشه، بررسی اتصال، بستن و حذف.\r\n", "“⋯” next to each row (or right-click): account & password, copy account number, folder, check connection, close and delete.\r\n") +
                Lang.T("انتخاب چند نفر: مربع کنار نام هر نفر را بزنید (یا Space). مربع بالای ستون (یا Ctrl+A) همه‌ی ردیف‌هایی را که الان دیده می‌شوند انتخاب می‌کند؛ Esc انتخاب را برمی‌دارد.\r\n", "Selecting several: tick the box next to each name (or Space). The box at the top of the column (or Ctrl+A) selects every row shown now; Esc clears the selection.\r\n") +
                Lang.T("نوار بالا (۳٫۲۵): وقتی کسی تیک نخورده، «دانشجوی جدید ▾» (در ▾: ساخت نسخه‌ها)، «به‌روزرسانی گزارش‌ها» با زمان آخرین خواندن (در ▾: همه‌ی دانشجوها)، «بستن همه‌ی بازها» و «ابزارها». وقتی چند نفر تیک خورده‌اند، نوار «N دانشجو انتخاب شده» را می‌گوید و «اجرا»، «بستن»، «به‌روزرسانی گزارش»، «متن گزارش» و «پوشه ▾» فقط روی همان‌ها کار می‌کنند؛ «لغو انتخاب» یا Esc برمی‌گرداند.\r\n", "The top bar: with nobody ticked, “New student ▾” (in ▾: make copies), “Refresh reports” with the last read time (in ▾: all students), “Close all open” and “Tools”. With students ticked, the bar says “N students selected” and “Run”, “Close”, “Refresh report”, “Report text” and “Folder ▾” act on them only; “Clear selection” or Esc goes back.\r\n") +
                Lang.T("پایین پنجره، سمت چپ: «آخرین پشتیبان»؛ اگر سه روز گذشته باشد یا هنوز پشتیبانی نباشد، نقطه‌اش نارنجی است.\r\n", "At the bottom of the window: “Last backup”; its dot is orange when three days have passed or there is no backup yet.\r\n") +
                Lang.T("وضعیت: «باز است» یعنی متاتریدرش باز است؛ وقتی بسته است، «فعال» یعنی در ۱۴ روز معاملاتی گذشته ترید داشته و «غیرفعال» یعنی بیش از ۱۴ روز معاملاتی ترید نداشته.\r\n", "Status: “Open” means its MetaTrader is open; when closed, “Active” means it traded in the past 14 trading days and “Inactive” means no trade for more than 14 trading days.\r\n") +
                Lang.T("بالای فهرست: «همه»، «فعال»، «غیرفعال» و «باز»؛ و جستجوی نام، شماره حساب یا سرور (Ctrl+F).\r\n\r\n", "Above the list: “All”, “Active”, “Inactive” and “Open”; and search by name, account number or server (Ctrl+F).\r\n\r\n") +
                Lang.T("گزارش\r\n", "Reports\r\n") +
                Lang.T("ستون «امروز» خلاصه‌ی امروز هر دانشجو و زمان خواندنش است. کلیک روی نام دانشجو (یا Enter) گزارشش را در صفحه‌ی جداگانه‌اش باز می‌کند («بازگشت به فهرست» یا Esc برمی‌گرداند؛ «نفر قبلی/بعدی» بین دانشجوهای همان فهرست می‌رود): امروز، دیروز، این هفته، این ماه یا بازه‌ی دلخواه؛ بالانس حساب، تعداد معامله، Net، ریسک هر معامله، حد ضرر و Daily DD، هشدارها و جدول معامله‌ها.\r\n", "The “Today” column is each student's day so far and when it was read. A click on the student's name (or Enter) opens their report on its own page (“Back to list” or Esc goes back; “Previous/Next” moves between the students of the same list): today, yesterday, this week, this month or a custom range; account balance, trade count, Net, risk per trade, stop loss and Daily DD, warnings and the trades table.\r\n") +
                Lang.T("«متن گزارش» (چند نفر را تیک بزنید): متن همه‌ی آن‌ها پشت سر هم، برای تلگرام یا واتس‌اپ. بازه را انتخاب کنید و هر چه در متن لازم است تیک بزنید (یادش می‌ماند). اگر کسی امروز خوانده نشده، پنجره می‌گوید و «اول خوانده شوند» او را می‌خواند. «کپی همه» همه را یک‌جا کپی می‌کند.\r\n", "“Report text” (tick several students): all their texts one after another, for Telegram or WhatsApp. Choose the range and tick what the text needs (it is remembered). If someone was not read recently, the window says so and “Refresh” reads them. “Copy all” copies everything at once.\r\n") +
                Lang.T("«به‌روزرسانی» در گزارش همان نفر را دوباره می‌خواند (حدود یک دقیقه، در پس‌زمینه). «به‌روزرسانی گزارش‌ها» در نوار بالا انتخاب‌شده‌ها را، یا اگر کسی انتخاب نشده همه‌ی ردیف‌های دیده‌شده را می‌خواند.\r\n", "“Refresh” on the report reads that student again (about a minute, in the background). “Refresh reports” in the top bar reads the selected students, or every row shown when nobody is selected.\r\n") +
                Lang.T("«امروز» از ۰۰:۰۰ سرور کارگزار است (WM Markets: ۰۱:۳۰ تهران در زمستان، ۰۰:۳۰ در تابستان) تا لحظه‌ی خواندن.\r\n", "“Today” is from 00:00 of the broker's server (WM Markets: 01:30 Tehran in winter, 00:30 in summer) to the moment of reading.\r\n") +
                Lang.T("برای یک پوشه، «به‌روزرسانی خودکار» (سمت چپ ردیف پوشه‌ها) دانشجوهایش را هر ۱۵، ۳۰ یا ۶۰ دقیقه یکی‌یکی می‌خواند؛ فقط وقتی برنامه باز است.\r\n\r\n", "For a folder, “Auto refresh” (at the end of the folders row) reads its students one by one every 15, 30 or 60 minutes; only while the program is open.\r\n\r\n") +
                Lang.T("پوشه‌ها\r\n", "Folders\r\n") +
                Lang.T("هر دانشجو می‌تواند هم‌زمان در چند پوشه باشد. ردیف پوشه‌ها زیر زبانه‌هاست؛ «+ پوشه‌ی جدید» پوشه می‌سازد و کلیک راست روی هر پوشه: تیک زدن اعضا، تغییر نام و حذف (دانشجوها دست نمی‌خورند).\r\n", "A student can be in several folders at once. The folders row is under the tabs; “+ New folder” makes a folder, and a right-click on a folder: tick its members, rename and delete (the students are not touched).\r\n") +
                Lang.T("برای گذاشتن در پوشه: تیک بزنید و «پوشه ▾» در نوار بالا، یا منوی «⋯». «افزودن» پوشه‌های دیگر را نگه می‌دارد؛ «انتقال» از پوشه‌ی دیده‌شده (یا در «همه‌ی پوشه‌ها» از همه) به مقصد می‌برد.\r\n\r\n", "To put students in a folder: tick them and “Folder ▾” in the top bar, or the “⋯” menu. “Add” keeps the other folders; “Move” takes them from the folder shown (or, in “All folders”, from all of them) to the target.\r\n\r\n") +
                Lang.T("پشتیبان‌گیری\r\n", "Backup\r\n") +
                Lang.T("«ابزارها > پشتیبان‌گیری» همه‌ی دانشجوها (با رمزها)، پوشه‌ها، ترتیب، گزارش‌ها و تنظیمات را در یک فایل با رمز خودتان می‌گذارد؛ «پشتیبان خودکار» هر روز نگاه می‌کند چیزی عوض شده یا نه و فقط آن وقت فایل MetaFactory-auto.mfbak را در همان پوشه به‌روز می‌کند (یکی قبلی هم کنارش می‌ماند).\r\n", "“Tools > Backup” puts all students (with passwords), folders, order, reports and settings in one file with your own password; “Automatic backup” checks every day whether something changed and only then updates the file MetaFactory-auto.mfbak in the same folder (the one before stays next to it).\r\n") +
                Lang.T("روی کامپیوتر دیگر: MetaFactory و متاتریدرِ بروکرها را نصب کنید، «بازگردانی از فایل پشتیبان» را بزنید، فایل و رمزش را بدهید؛ نسخه‌ها خودشان ساخته می‌شوند. بدون رمز فایل باز نمی‌شود.\r\n\r\n", "On another computer: install MetaFactory and the brokers' MetaTraders, press “Restore from backup file”, give the file and its password; the copies are made by themselves. Without the password the file does not open.\r\n\r\n") +
                Lang.T("نسخه‌های معامله‌گر (رمز اصلی)\r\n", "Trading copies (master password)\r\n") +
                Lang.T("«دانشجوی جدید ▾ > ساخت نسخه‌ها»، بعد «⋯ > حساب و رمز».\r\n", "“New student ▾ > Make copies”, then “⋯ > Account and password”.\r\n") +
                Lang.T("اگر ویندوز برای «Client Terminal» (ناشر MetaQuotes) اجازه خواست، «No» بزنید: به‌روزرسانی خود متاتریدر است و بدون آن هم انجام می‌شود؛ با «Yes» این برنامه دیگر نمی‌تواند آن متاتریدر را ببندد.\r\n", "If Windows asks permission for “Client Terminal” (publisher MetaQuotes), press “No”: it is MetaTrader's own update and happens without it too; with “Yes” this program can no longer close that MetaTrader.\r\n") +
                Lang.T("«بسته شد ۱۰:۵۲» در ستون وضعیت یعنی متاتریدری که برنامه باز کرده بود، بدون دستور برنامه بسته شد (از پنجره‌ی خودش، با خطا یا برای به‌روزرسانی).\r\n", "“Closed 10:52” in the status column means a MetaTrader the program opened closed without the program's command (from its own window, with an error or to update).\r\n") +
                Lang.T("بستن فقط برای متاتریدرهایی است که خود این برنامه باز کرده: متاتریدری که دستی یا با برنامه‌ی دیگری باز شده (و نصب اصلی بروکر) هیچ‌وقت از این‌جا بسته نمی‌شود و برنامه می‌گوید کدام‌ها باز ماندند.\r\n", "Closing is only for MetaTraders this program opened: a MetaTrader opened by hand or by another program (and the broker's main installation) is never closed from here, and the program says which stayed open.\r\n") +
                Lang.T("بستن: هر متاتریدر اول چارت‌ها و تنظیماتش را ذخیره می‌کند؛ پیشرفتش زیر عنوان دیده می‌شود. آن‌هایی که پنجره ندارند فوراً بسته می‌شوند، و هر کدام که بعد از ۳۰ ثانیه هنوز باز بود، خودکار و بدون سؤال به‌اجبار بسته می‌شود.\r\n", "Closing: each MetaTrader first saves its charts and settings; the progress shows under the title. Those with no window close at once, and any still open after 30 seconds is closed by force, automatically and without asking.\r\n") +
                Lang.T("اگر نسخه‌ای خودش وارد نشد: بازش کنید، یک بار از File > Login to Trade Account دستی وارد شوید و «Save password» را بزنید.\r\n\r\n", "If a copy did not sign in by itself: open it, sign in once by hand from File > Login to Trade Account and tick “Save password”.\r\n\r\n") +
                Lang.T("سرعت\r\n", "Speed\r\n") +
                Lang.T("«اجرا» نسخه‌ی بعدی را به‌محض بالا آمدنِ قبلی باز می‌کند (دیرتر از «فاصله‌ی اجرا» نه). متاتریدرهای پشت صحنه با اولویت پایین‌تر اجرا می‌شوند و حافظه‌ی آن‌هایی که کوچک شده‌اند هر دو دقیقه به ویندوز برمی‌گردد؛ هر دو در تنظیمات قابل خاموش کردن‌اند.\r\n", "“Run” opens the next copy as soon as the one before is up (never later than the “Start interval”). Background MetaTraders run at a lower priority and the memory of minimized ones goes back to Windows every two minutes; both can be turned off in Settings.\r\n") +
                Lang.T("پوشه‌ی نسخه‌ها را به استثناهای Windows Defender اضافه کنید تا باز شدن نسخه‌ها سریع‌تر شود.\r\n\r\n", "Add the copies folder to the Windows Defender exclusions so the copies open faster.\r\n\r\n") +
                Lang.T("سیستم ضعیف\r\n", "Weak computer\r\n") +
                Lang.T("در «ابزارها > تنظیمات» اجرای کوچک‌شده و حالت سبک را روشن بگذارید و فاصله‌ی اجرا را ۱۰ تا ۱۵ ثانیه کنید. MT4 خیلی سبک‌تر از MT5 است.\r\n\r\n", "In “Tools > Settings” keep minimized start and light mode on, and set the start interval to 10 to 15 seconds. MT4 is much lighter than MT5.\r\n\r\n") +
                Lang.T("مشکل؟\r\n", "Problems?\r\n") +
                Lang.T("کادرهای زرد بالای فهرست مشکل‌هایی را که برنامه می‌بیند با راه رفعشان نشان می‌دهند. «ابزارها > بررسی سیستم و عیب‌یابی» گزارش کامل می‌دهد؛ متنش را کپی کنید و بفرستید.", "The yellow boxes above the list show the problems the program sees, with how to fix them. “Tools > System check and troubleshooting” gives a full report; copy its text and send it.");
        }

        void ShowHelp()
        {
            using (var d = new TextDialog(Lang.T("راهنما", "Help"), HelpText(), false)) d.ShowDialog(this);
        }

        void CleanupCopies()
        {
            if (copies.Count == 0) { Ui.Message(this, Lang.T("هنوز نسخه‌ای ساخته نشده.", "No copies made yet.")); return; }
            Dictionary<string, Process> running = Processes.Running();
            List<Instance> closed = copies.Where(i => !Processes.IsRunning(running, i.Exe)).ToList();
            List<string> open = copies.Where(i => Processes.IsRunning(running, i.Exe)).Select(i => i.Name).ToList();
            List<CleanupGroup> groups;
            Cursor = Cursors.WaitCursor;
            try { groups = Cleanup.Scan(closed, DateTime.Now, settings.AllFolders.Select(OldMonitor.WorkDir)); }
            finally { Cursor = Cursors.Default; }
            List<CleanupGroup> chosen;
            using (var d = new CleanupDialog(groups, open))
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
                chosen = d.Chosen;
            }
            List<string> paths = chosen.SelectMany(g => g.Paths).ToList();
            if (paths.Count == 0) return;
            long size = chosen.Sum(g => g.Size);
            SetStatus(Lang.T("در حال انتقال به سطل بازیافت…", "Moving to the Recycle Bin…"));
            band.Refresh();
            List<string> gone;
            Cursor = Cursors.WaitCursor;
            try { gone = Native.ToRecycleBin(paths, Handle); }
            finally { Cursor = Cursors.Default; }
            Log.Write("cleanup: " + gone.Count + " of " + paths.Count + " items to the recycle bin (" + string.Join(", ", chosen.Select(g => g.Id)) + ", " + size + " bytes)");
            if (gone.Count == paths.Count)
                Ui.Message(this, Lang.T("انجام شد: حدود ", "Done: about ") + TextUtil.Size(size) + Lang.T(" به سطل بازیافت رفت.\n\nفضای دیسک وقتی واقعاً آزاد می‌شود که سطل بازیافت را خالی کنید. تا آن موقع می‌شود هر چیزی را از آنجا برگرداند.", " went to the Recycle Bin.\n\nThe disk space is really freed when you empty the Recycle Bin. Until then anything can be brought back from there."));
            else
                Ui.Message(this, (paths.Count - gone.Count) + Lang.T(" مورد از ", " of ") + paths.Count + Lang.T(" مورد منتقل نشد (شاید در حال استفاده بود). بقیه به سطل بازیافت رفت.", " items were not moved (perhaps in use). The rest went to the Recycle Bin."), MessageBoxIcon.Warning);
            SetStatus(Lang.T("پاکسازی انجام شد.", "Cleanup done."));
            bannerKey = null;
            RefreshAll(false);
        }

        void OpenFolder()
        {
            Directory.CreateDirectory(settings.BaseDir);
            Ui.OpenUrl(settings.BaseDir);
        }

        void EditSettings()
        {
            string language = settings.Language;
            using (var d = new SettingsDialog(settings))
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
            }
            if (settings.Language != language)
            {
                // 3.27 (CHANGE-019): the window is made again in the new language; open MetaTraders stay as they are.
                if (busy || report != null || startQueue.Count > 0 || preparingCopy)
                {
                    Ui.Message(this, settings.Language == "en"
                        ? "The language changes when the program is opened next time (copies are being made, reports read or MetaTraders started right now)."
                        : "زبان دفعه‌ی بعد که برنامه باز شود عوض می‌شود (الان نسخه ساخته، گزارش خوانده یا متاتریدر اجرا می‌شود).");
                    return;
                }
                Program.Rebuild = true;
                Close();
                return;
            }
            SetStatus(Lang.T("تنظیمات ذخیره شد.", "Settings saved."));
            bannerKey = null;
            RefreshAll(true);
        }

        void OnClosing(object sender, FormClosingEventArgs e)
        {
            if (scheduledBatch != null && report == null && e.CloseReason != CloseReason.WindowsShutDown
                && !Ui.Confirm(this, Lang.T("ارسال گزارش در جریان است. با بستن برنامه ممکن است نتیجهٔ ارسال نامشخص بماند. بسته شود؟", "Report delivery is in progress. Closing may leave delivery uncertain. Close?"))) { e.Cancel = true; return; }
            if (e.CloseReason == CloseReason.WindowsShutDown)
            {
                appClosing = true; ShutdownLiveMonitoring(); scheduleCancel = true; scheduleTimer.Stop(); LaunchCapacityDiagnostics.StopWatching(); LaunchComparison.ReleaseObservedProcesses(); importTimer.Stop(); if (imports != null) imports.Dispose();
                // Windows is shutting down: no questions and no waiting, just remove the files that may hold a password.
                if (report != null) report.EndNow();
                refreshTimer.Stop();
                watchTimer.Stop();
                startTimer.Stop();
                pendingTimer.Stop();
                DeleteOldStartFiles(true);
                DropUpdateFiles();
                return;
            }
            if (preparingCopy)
            {
                e.Cancel = true;
                SetStatus(Lang.T("آغاز اجرای فعلی هنوز تمام نشده؛ پس از پایان آن برنامه را ببندید.", "The current launch is still being prepared; close the app after it finishes."));
                return;
            }
            if (busy && !Ui.Confirm(this, Lang.T("ساخت نسخه‌ها هنوز تمام نشده. برنامه بسته شود؟", "Making the copies is not finished yet. Close the program?")))
            {
                e.Cancel = true;
                return;
            }
            if (report != null)
            {
                if (!Ui.Confirm(this, Lang.T("گزارش دانشجوها هنوز در حال خواندن است. با بستن برنامه خواندن متوقف می‌شود و متاتریدرهای گزارش بسته می‌شوند. بسته شود؟", "The students' reports are still being read. Closing the program stops the reading and closes the report MetaTraders. Close?")))
                {
                    e.Cancel = true;
                    return;
                }
                appClosing = true;
                readQueue.Clear();
                report.EndNow();
                ReportCopies.DeleteLeftovers(settings);
            }
            appClosing = true; ShutdownLiveMonitoring(); scheduleCancel = true; scheduleTimer.Stop(); LaunchCapacityDiagnostics.StopWatching(); LaunchComparison.ReleaseObservedProcesses(); importTimer.Stop(); if (imports != null) imports.Dispose();
            refreshTimer.Stop();
            watchTimer.Stop();
            startTimer.Stop();
            startQueue.Clear();
            ClearSecret();
            DropUpdateFiles();
            // Terminals started a moment ago may not have read their start file yet: wait for them (10 seconds at most), then delete.
            pendingTimer.Stop();
            while (pending.Count > 0)
            {
                DeleteOldStartFiles(false);
                if (pending.Count == 0) break;
                SetStatus(Lang.T("در حال پاک کردن فایل‌های موقت ورود… چند ثانیه صبر کنید.", "Removing the temporary login files… please wait a few seconds."));
                band.Refresh();
                Application.DoEvents();
                System.Threading.Thread.Sleep(250);
            }
        }

#if SNAPSHOT
        public void Snapshot(string outDir)
        {
            // 3.25: the backup line at the bottom (a backup made this morning).
            settings.LastBackup = DateTime.Now.AddMinutes(-75);
            Func<string, Instance> copy = name => Installs.Copies(settings).FirstOrDefault(c => c.Name == name);
            var people = new[]
            {
                new { c = "MT5-01", t = "علی رضایی", l = "51234567", s = "WMMarkets-Real1", on = true },
                new { c = "MT5-02", t = "مریم احمدی", l = "51234568", s = "WMMarkets-Real1", on = true },
                new { c = "MT5-03", t = "رضا کریمی", l = "51234571", s = "WMMarkets-Demo", on = false },
                new { c = "MT5-04", t = "سارا محمدی", l = "51234590", s = "WMMarkets-Real1", on = false },
                new { c = "MT5-05", t = "حسین نوری", l = "51234602", s = "WMMarkets-Real1", on = false },
                new { c = "MT4-01", t = "نگار امینی", l = "2201450", s = "WMMarkets-Real2", on = false },
                new { c = "MT4-02", t = "امیر حسینی", l = "2201488", s = "WMMarkets-Real2", on = true },
                new { c = "MT4-03", t = "کاوه شریفی", l = "2201499", s = "WMMarkets-Real2", on = true },
            };
            foreach (var x in people)
            {
                accounts.Set(new Account { Instance = x.c, Trader = x.t, Login = x.l, Server = x.s, Mode = "investor", MasterEnc = "", InvestorEnc = Secret.Protect("b") });
                if (x.on) fakeOn.Add(x.c);
            }
            // Folders (made-up): a student can be in several at once.
            Folder fInvest = folders.Create("جذب سرمایه"), fStage = folders.Create("چالش مرحله ۱"), fAutumn = folders.Create("دوره‌ی پاییز ۱۴۰۵");
            folders.Add(fInvest.Id, new[] { "MT5-01", "MT5-02", "MT4-01" });
            folders.Add(fStage.Id, new[] { "MT5-01", "MT5-03", "MT4-02" });
            folders.Add(fAutumn.Id, new[] { "MT5-04", "MT5-05", "MT4-01" });
            lastFailure["MT5-05"] = new LoginResult { State = Login.WrongLogin };
            fakeOn.Add("MT5-06");  // open without an account
            launches["MT5-04"] = new Launch { Time = DateTime.Now.AddMinutes(-20) };  // ran, then closed outside the program
            Directory.CreateDirectory(outDir);
            Show();
            RefreshAll(true);
            if (grid.Rows.Count > 2) { grid.ClearSelection(); grid.Rows[1].Selected = true; }
            Shots.Draw(this, Path.Combine(outDir, "main.png"), false);
            // 3.23: «مرتب‌سازی» open, and the list with MT4 only.
            ShowSortMenu(listTools.PointToScreen(new Point(Theme.S(4), listTools.Height - Theme.S(4))));
            Shots.Draw(this, Path.Combine(outDir, "sort-menu.png"), false);
            sortMenu.Close();
            listTools.Platform = "MT4";
            RefreshAll(true);
            Shots.Draw(this, Path.Combine(outDir, "platform-mt4.png"), false);
            listTools.Platform = "all";
            RefreshAll(true);
            // 3.22.4: a copy that closed right after starting, with the reason read from its journal (made-up lines), on its row,
            // in the banner and in «بررسی سیستم».
            {
                Instance m4 = copies.FirstOrDefault(c => c.Name == "MT4-01");
                Account a4 = m4 == null ? null : accounts.Get(m4.Name);
                if (a4 != null)
                {
                    DateTime t0 = DateTime.Now.AddSeconds(-40);
                    launches["MT4-01"] = new Launch
                    {
                        Time = t0, JournalFrom = t0, ClosedEarly = true, GoneAt = DateTime.Now.AddSeconds(-14),
                        Early = EarlyClose.Explain(new[]
                        {
                            "0\t" + t0.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture) + "\tWM Markets MT4 build 1492 started (WM Markets Ltd)",
                            "0\t" + t0.AddSeconds(1).ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture) + "\tStarted with configuration file 'mtm-start.ini'",
                            "0\t" + t0.AddSeconds(9).ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture) + "\t'" + a4.Login + "': authorization on " + a4.Server + " failed (Invalid account)",
                            "0\t" + t0.AddSeconds(26).ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture) + "\tWM Markets MT4 build 1492 stopped",
                        }, a4.Login),
                    };
                    bannerKey = null;
                    RefreshAll(true);
                    Shots.Draw(this, Path.Combine(outDir, "early-close.png"), false);
                    using (var d = new TextDialog(Lang.T("بررسی سیستم و عیب‌یابی", "System check and troubleshooting"), EarlySummary().Trim(), true)) Shots.Draw(d, Path.Combine(outDir, "early-close-check.png"));
                    launches.Remove("MT4-01");
                    bannerKey = null;
                    RefreshAll(true);
                }
            }
            // The row menu and the tools menu, open over the window.
            if (grid.Rows.Count > 2)
            {
                Rectangle cell = grid.GetCellDisplayRectangle(grid.Columns["Action"].Index, 2, false);
                ShowRowMenu((CopyRow)grid.Rows[2].Tag, grid.PointToScreen(new Point(cell.Left + Theme.S(10), cell.Bottom - Theme.S(5))));
                Shots.Draw(this, Path.Combine(outDir, "row-menu.png"), false);
                miCopyGroup.ShowDropDown();
                Shots.Draw(this, Path.Combine(outDir, "row-menu-copy.png"), false);
                rowMenu.Close();
            }
            ShowUnder(toolsMenu, toolsButton);
            Shots.Draw(this, Path.Combine(outDir, "tools-menu.png"), false);
            toolsMenu.Close();
            // 3.25: the «▾» menus of the band.
            ShowUnder(newMenu, newButton);
            Shots.Draw(this, Path.Combine(outDir, "new-menu.png"), false);
            newMenu.Close();
            ShowRefreshMenu();
            Shots.Draw(this, Path.Combine(outDir, "refresh-menu.png"), false);
            refreshMenu.Close();
            // Three people ticked: the band's commands act on them alone.
            foreach (string n in new[] { "MT5-03", "MT5-04", "MT4-02" }) chosen.Toggle(n);
            RefreshGrid(false);
            Shots.Draw(this, Path.Combine(outDir, "chosen.png"), false);
            for (int k = 0; k < grid.Rows.Count; k++)
            {
                var cr = (CopyRow)grid.Rows[k].Tag;
                if (cr.Name != "MT5-04") continue;
                Rectangle cell = grid.GetCellDisplayRectangle(grid.Columns["Action"].Index, k, false);
                ShowRowMenu(cr, grid.PointToScreen(new Point(cell.Left + Theme.S(10), cell.Bottom - Theme.S(5))));
                Shots.Draw(this, Path.Combine(outDir, "chosen-menu.png"), false);
                rowMenu.Close();
                break;
            }
            // Folders: the row menu on a ticked row, "افزودن به پوشه" open (check: all of them are in it; dash: some are).
            for (int k = 0; k < grid.Rows.Count; k++)
            {
                var cr = (CopyRow)grid.Rows[k].Tag;
                if (cr.Name != "MT5-04") continue;
                Rectangle cell = grid.GetCellDisplayRectangle(grid.Columns["Action"].Index, k, false);
                ShowRowMenu(cr, grid.PointToScreen(new Point(cell.Left + Theme.S(10), cell.Top - Theme.S(150))));
                miAddTo.ShowDropDown();
                Shots.Draw(this, Path.Combine(outDir, "folders-add-menu.png"), false);
                rowMenu.Close();
                break;
            }
            // The band's "پوشه‌ها" for the ticked ones.
            ShowFolderCommands();
            Shots.Draw(this, Path.Combine(outDir, "folders-band-menu.png"), false);
            if (folderMenu != null) folderMenu.Close();
            chosen.Clear();
            RefreshGrid(false);
            // One folder viewed, with the "فعال" tab: the tabs count within the folder.
            folderBar.Selected = "f:" + fStage.Id;
            Shots.Draw(this, Path.Combine(outDir, "folders-view.png"), false);
            pivot.Selected = "on";
            Shots.Draw(this, Path.Combine(outDir, "folders-view-active.png"), false);
            pivot.Selected = "all";
            // A folder's own menu (right-click on it).
            folderBar.ShowMenuOf("f:" + fStage.Id);
            Shots.Draw(this, Path.Combine(outDir, "folders-chip-menu.png"), false);
            if (folderMenu != null) folderMenu.Close();
            folderBar.Selected = FolderBar.AllKey;
            using (var d = new FolderDialog(folders, null, 3))
            {
                d.Preview("دوره‌ی زمستان ۱۴۰۵");
                Shots.Draw(d, Path.Combine(outDir, "folders-new.png"));
            }
            using (var d = new MessageDialog(DeleteQuestion(fStage.Name, 3), MessageBoxIcon.Question, MessageBoxButtons.YesNo)) Shots.Draw(d, Path.Combine(outDir, "folders-delete.png"));
            // 3.24: the backup and restore windows (the made-up students of these screenshots; the file is written in the screenshots' own folder).
            {
                BackupData backupSample = GatherBackup();
                using (var d = new BackupDialog(backupSample, settings))
                {
                    d.Preview("sample-pass-1", @"D:\MetaFactory Backup");
                    Shots.Draw(d, Path.Combine(outDir, "backup.png"));
                }
                string[] more = { "سپیده کریمی", "بهرام صالحی", "یاسمین نوری" };
                string file = Path.Combine(AppPaths.DataDir, "sample" + AutoBackup.Extension);
                // A made-up MT4 of the broker, found the way a real one is (MetaQuotes' origin.txt), removed after the screenshots.
                string fakeMt4 = Path.Combine(AppPaths.DataDir, "sample-install", "WMMarkets MT4 Terminal");
                string fakeOrigin = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MetaQuotes", "Terminal", "SNAPSHOT-SAMPLE");
                Directory.CreateDirectory(fakeMt4);
                File.WriteAllText(Path.Combine(fakeMt4, Kinds.Exe(Kind.MT4)), "");
                Directory.CreateDirectory(fakeOrigin);
                File.WriteAllText(Path.Combine(fakeOrigin, "origin.txt"), fakeMt4);
                // restore.png: three new students whose MetaTrader is on this computer; restore-missing.png: one that is not.
                for (int k = 0; k < more.Length; k++)
                    backupSample.Students.Add(new BackupStudent { Copy = "MT4-9" + k, Kind = "MT4", Trader = more[k], Login = "5123900" + k, Server = "WMMarkets-Demo", Investor = "x" });
                for (int shot = 0; shot < 2; shot++)
                {
                    if (shot == 1) backupSample.Students.Add(new BackupStudent { Copy = "MT5-93", Kind = "MT5", Trader = "کاوه رستمی", Login = "51239003", Server = "OtherBroker-Live", Investor = "x" });
                    File.WriteAllBytes(file, BackupFormat.Make(backupSample, "sample-pass-1"));
                    using (var d = new RestoreDialog(settings, accounts))
                    {
                        d.Preview(file, "sample-pass-1", @"D:\MetaFactory Backup\" + AutoBackup.MainName, @"C:\MetaTrader Copies");
                        Shots.Draw(d, Path.Combine(outDir, shot == 0 ? "restore.png" : "restore-missing.png"));
                    }
                }
                File.Delete(file);
                Directory.Delete(fakeOrigin, true);
                Directory.Delete(Path.GetDirectoryName(fakeMt4), true);
            }
            // 3.21: the report inside the program (made-up histories; nothing is read from this computer).
            DateTime day = ServerDays.Now(null, DateTime.UtcNow).Date;
            if (ServerDays.Weekend(day)) day = ServerDays.PreviousTradingDay(day.AddDays(1));
            var sample = new Dictionary<string, AccountJournal>
            {
                { "MT5-01", SampleJournals.Make("51234567", "MT5", 5000, day, 1, 1, false) },
                { "MT5-02", SampleJournals.Make("51234568", "MT5", 3000, day, 2, 2, false) },
                { "MT5-03", SampleJournals.Make("51234571", "MT5", 10000, day, 3, 0, true) },
                { "MT5-05", SampleJournals.Make("51234602", "MT5", 2500, ServerDays.PreviousTradingDay(day), 5, 1, false) },
                { "MT4-01", SampleJournals.Make("2201450", "MT4", 1000, day, 6, 0, false) },
            };
            foreach (KeyValuePair<string, AccountJournal> x in sample)
            {
                fakeJournals[x.Key] = x.Value;
                fakeTimes[x.Key] = DateTime.Now.AddMinutes(x.Key == "MT4-01" ? -130 : x.Key == "MT5-05" ? -26 * 60 : -7);
                students.Remove(x.Key);
            }
            Func<string, Student> st = n => { Student v; if (!students.TryGetValue(n, out v)) students[n] = v = new Student(); return v; };
            st("MT5-05").Error = Lang.T("ورود نشد: رمز اینوستور یا شماره حساب اشتباه", "Login failed: wrong investor password or account number");
            st("MT4-02").Busy = true;
            st("MT4-02").Step = Lang.T("وصل شد، در حال گرفتن تاریخچه (۱۵۲ ردیف)…", "Connected, getting history (152 rows)…");
            st("MT4-03").Queued = true;
            folderBar.Selected = FolderBar.AllKey;
            pivot.Selected = "all";
            RefreshAll(true);
            grid.PreviewNameHover(-1);
            Shots.Draw(this, Path.Combine(outDir, "report-list.png"), false);
            // 3.26 (CHANGE-005): the compact look, then back to the usual one.
            Func<string, CopyRow> rowOf = n => grid.Rows.Cast<DataGridViewRow>().Select(x => (CopyRow)x.Tag).FirstOrDefault(x => x.Name == n);
            OpenStudent(rowOf("MT5-02"));
            Shots.Draw(this, Path.Combine(outDir, "report-today.png"), false);
            // 3.22.1: «کپی متن روز» and its window (the same made-up day).
            {
                Instance ci = copies.First(c => c.Name == "MT5-02");
                Account ca = accounts.Get(ci.Name);
                int cat = PageOrder().IndexOf(ci.Name);
                string who = string.IsNullOrWhiteSpace(ca.Trader) ? ci.Name : ca.Trader.Trim();
                using (var d = new DayTextDialog(who, WeekDays[(int)panel.View.Range.From.DayOfWeek] + " " + panel.View.Range.From.ToString("yyyy.MM.dd", CultureInfo.InvariantCulture),
                                                 DayText.Make(cat + 1, who, ca.Login, panel.View)))
                {
                    Shots.Draw(d, Path.Combine(outDir, "day-text.png"));
                    d.PreviewCopied();
                    Shots.Draw(d, Path.Combine(outDir, "day-text-copied.png"));
                }
            }
            PanelRangeWanted(PanelRange.Week);
            Shots.Draw(this, Path.Combine(outDir, "report-week.png"), false);
            // 3.27.2 (CHANGE-022): «کپی متن گزارش» for the week.
            {
                Instance ci = copies.First(c => c.Name == "MT5-02");
                Account ca = accounts.Get(ci.Name);
                string who = string.IsNullOrWhiteSpace(ca.Trader) ? ci.Name : ca.Trader.Trim();
                using (var d = new DayTextDialog(who, panel.RangeText, RangeText(panel.View, PageOrder().IndexOf(ci.Name) + 1, who, ca.Login), true))
                    Shots.Draw(d, Path.Combine(outDir, "report-week-text.png"));
            }
            // A day opened on its trades (3.21.1: this drew a column that was not there and stopped the page).
            if (panel.View != null && panel.View.Days.Count > 0) panel.OpenDay(panel.View.Days[panel.View.Days.Count - 1].Day);
            Shots.Draw(this, Path.Combine(outDir, "report-week-day.png"), false);
            Console.WriteLine("report page painted: " + (panel.PaintError ?? "ok"));
            PanelRangeWanted(PanelRange.Custom);
            PanelCustom(day.AddDays(-1), day);
            panel.SetCustom(day.AddDays(-1), day);
            Shots.Draw(this, Path.Combine(outDir, "report-custom.png"), false);
            PanelRangeWanted(PanelRange.Today);
            OpenStudent(rowOf("MT5-04"));
            Shots.Draw(this, Path.Combine(outDir, "report-not-read.png"), false);
            OpenStudent(rowOf("MT5-05"));
            Shots.Draw(this, Path.Combine(outDir, "report-failed.png"), false);
            CloseStudent();
            Shots.Draw(this, Path.Combine(outDir, "report-back.png"), false);
            // 3.24.2: the mouse on a student's name (only the name opens the student's page).
            grid.PreviewNameHover(1);
            Shots.Draw(this, Path.Combine(outDir, "name-hover.png"), false);
            grid.PreviewNameHover(-1);
            // 3.25: «متن گزارش» for three ticked students (made-up histories; one read yesterday, so the warning shows).
            foreach (string n in new[] { "MT5-02", "MT5-03", "MT5-05" }) chosen.Toggle(n);
            RefreshGrid(false);
            Shots.Draw(this, Path.Combine(outDir, "report-text-bar.png"), false);
            using (var d = new ReportTextDialog(ReportSource(Chosen()), settings, customFrom, customTo))
            {
                d.Preview(0, TextParts.Zero);
                Shots.Draw(d, Path.Combine(outDir, "report-text.png"));
                d.Preview(2, TextParts.None);
                Shots.Draw(d, Path.Combine(outDir, "report-text-week.png"));
                d.Preview(0, TextParts.None);
            }
            chosen.Clear();
            RefreshGrid(false);
            // A folder read again by itself every 30 minutes.
            AutoRefresh.Set(fInvest, 30);
            autoStart[fInvest.Id] = DateTime.Now.AddMinutes(-8);
            autoEnd[fInvest.Id] = DateTime.Now.AddMinutes(-6);
            folderBar.Selected = "f:" + fInvest.Id;
            RefreshAll(true);
            Shots.Draw(this, Path.Combine(outDir, "folder-auto.png"), false);
            Rectangle ab = folderBar.AutoBounds;
            ChooseAuto(folderBar.PointToScreen(new Point(ab.Left, ab.Bottom + Theme.S(2))));
            Shots.Draw(this, Path.Combine(outDir, "folder-auto-menu.png"), false);
            if (folderMenu != null) folderMenu.Close();
            pivot.Selected = "off";
            folderBar.Selected = FolderBar.AllKey;
            Shots.Draw(this, Path.Combine(outDir, "inactive.png"), false);
            pivot.Selected = "all";
            st("MT4-02").Busy = false;
            st("MT4-03").Queued = false;
            // Many folders: those that do not fit go behind "⋯ N پوشه‌ی دیگر".
            var extra = new List<Folder>();
            foreach (string n in new[] { "VIP", "حساب‌های ۵۰ هزار دلاری", "چالش مرحله ۲", "دوره‌ی تابستان", "مشاوره‌ی خصوصی", "پیگیری هفتگی", "بازگشتی‌ها" }) extra.Add(folders.Create(n));
            RefreshAll(true);
            Shots.Draw(this, Path.Combine(outDir, "folders-many.png"), false);
            // 3.22.1: "⋯" → «افزودن به پوشه» with long names: every name whole, the submenu on the side with room.
            if (grid.Rows.Count > 2)
            {
                var cr = (CopyRow)grid.Rows[2].Tag;
                Rectangle cell = grid.GetCellDisplayRectangle(grid.Columns["Action"].Index, 2, false);
                ShowRowMenu(cr, grid.PointToScreen(new Point(cell.Left + Theme.S(10), cell.Top - Theme.S(230))));
                miAddTo.ShowDropDown();
                Shots.Draw(this, Path.Combine(outDir, "folders-add-long.png"), false);
                rowMenu.Close();
            }
            foreach (Folder f in extra) folders.Delete(f.Id);
            RefreshAll(true);
            pivot.Selected = "on";
            Shots.Draw(this, Path.Combine(outDir, "active.png"), false);
            pivot.Selected = "all";
            Instance one = copy("MT5-01");
            using (var d = new StudentDialog(accounts, settings))
            {
                d.Preview("WM Markets");
                Shots.Draw(d, Path.Combine(outDir, "add-student.png"));
            }
            using (var d = new StudentDialog(accounts, settings))
            {
                d.Preview(null);
                Shots.Draw(d, Path.Combine(outDir, "add-student-closed.png"));
            }
            if (one != null)
            {
                Account a1 = accounts.Get(one.Name);
                var shots = new[] {
                    new { s = Login.Waiting, d = "", t = 1, f = "connect-wait.png" },
                    new { s = Login.Connected, d = "", t = 5, f = "connect-ok.png" },
                    new { s = Login.WrongLogin, d = "LE\t0\t14:53:22.150\tNetwork\t'51234567': authorization on WMMarkets-Real1 failed (Invalid account)", t = 5, f = "connect-wrong.png" } };
                foreach (var x in shots)
                    using (var d = new ConnectionDialog(one, a1, DateTime.Now))
                    {
                        d.Preview(x.s, x.d, x.t);
                        Shots.Draw(d, Path.Combine(outDir, x.f));
                    }
            }
            using (var d = new CreateDialog(settings)) Shots.Draw(d, Path.Combine(outDir, "create.png"));
            if (one != null) using (var d = new AccountDialog(one, accounts, settings)) Shots.Draw(d, Path.Combine(outDir, "account.png"));
            using (var d = new SettingsDialog(settings)) Shots.Draw(d, Path.Combine(outDir, "settings.png"));
            using (var d = new HeapDialog(20480)) Shots.Draw(d, Path.Combine(outDir, "heap.png"));
            using (var d = new CleanupDialog(Cleanup.Scan(copies, DateTime.Now), new List<string> { "MT5-02" })) Shots.Draw(d, Path.Combine(outDir, "cleanup.png"));
            using (var d = new MessageDialog(NothingTicked + Lang.T("\n\nمربع کنار نام هر دانشجو را بزنید. مربع بالای ستون (یا Ctrl+A) همه‌ی ردیف‌هایی را که الان دیده می‌شوند انتخاب می‌کند.", "\n\nTick the box next to each student's name. The box at the top of the column (or Ctrl+A) selects every row shown now."), MessageBoxIcon.Warning, MessageBoxButtons.OK)) Shots.Draw(d, Path.Combine(outDir, "nothing-ticked.png"));
            using (var d = new AskDialog(Lang.T("کسی تیک نخورده", "Nobody is ticked"), Lang.T("متن گزارش همه‌ی ۹ نفرِ همین فهرست ساخته شود؟", "Make the report text of all 9 students in this list?"), Lang.T("برای چند نفر خاص، اول کنار اسمشان تیک بزنید.", "For a few students, tick them first."), Lang.T("متن همه‌ی ۹ نفر", "Text of all 9"), Lang.T("انصراف", "Cancel")))
                Shots.Draw(d, Path.Combine(outDir, "report-text-ask.png"));
            using (var d = new MessageDialog(Lang.T("رمز اینوستور: ", "Investor password: ") + PasswordRule.Problem("abc123 "), MessageBoxIcon.Warning, MessageBoxButtons.OK)) Shots.Draw(d, Path.Combine(outDir, "password-check.png"));
            using (var d = new MessageDialog(Lang.T("این نسخه‌ها به سطل بازیافت می‌روند و حساب ذخیره‌شده‌شان در این برنامه هم پاک می‌شود:\nMT5-04، MT5-05\n\nادامه می‌دهید؟", "These copies go to the Recycle Bin and their saved account is removed from this program too:\nMT5-04, MT5-05\n\nContinue?"), MessageBoxIcon.Question, MessageBoxButtons.YesNo)) Shots.Draw(d, Path.Combine(outDir, "confirm.png"));
            using (var d = new TextDialog(Lang.T("راهنما", "Help"), HelpText(), false)) Shots.Draw(d, Path.Combine(outDir, "help.png"));
            search.Box.Text = "zzz";
            Shots.Draw(this, Path.Combine(outDir, "no-match.png"), false);
            search.Box.Text = "";
            foreach (Instance i in copies) { try { Directory.Delete(i.Dir, true); } catch { } }
            RefreshAll(true);
            Shots.Draw(this, Path.Combine(outDir, "empty.png"), false);
        }
#endif
    }
}
