using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace MTManager
{
    public sealed class TelegramUser
    {
        public long Id {get;set;}
        public bool Admin {get;set;}
    }
    public sealed class TelegramControlOptions
    {
        public bool Enabled {get;set;}
        public string TokenEnc {get;set;}
        [ScriptIgnore] public string LoadError {get;set;}
        public List<TelegramUser> Users {get;set;}
        public TelegramControlOptions(){TokenEnc="";Users=new List<TelegramUser>();}
        public bool Allowed(long id){return Users!=null&&Users.Any(u=>u.Id==id&&id>0);}
        public bool Administrator(long id){return Users!=null&&Users.Any(u=>u.Id==id&&u.Admin&&id>0);}
        public string Problem()
        {
            if(Users==null||Users.Any(u=>u==null||u.Id<=0)||Users.Select(u=>u.Id).Distinct().Count()!=Users.Count)return "شناسه‌های کاربران باید عددی، مثبت و بدون تکرار باشند.";
            if(Enabled&&(Users.Count==0||!ValidToken(Secret.Unprotect(TokenEnc))))return "برای فعال‌سازی، توکن و حداقل یک کاربر مجاز لازم است.";
            return null;
        }
        public static bool ValidToken(string token){return Regex.IsMatch(token??"",@"\A[0-9]{5,20}:[A-Za-z0-9_-]{20,100}\z");}
        public TelegramControlOptions Snapshot(){return new TelegramControlOptions{Enabled=Enabled,TokenEnc=TokenEnc,LoadError=LoadError,Users=(Users??new List<TelegramUser>()).Select(u=>new TelegramUser{Id=u.Id,Admin=u.Admin}).ToList()};}
    }
    public static class TelegramControlStore
    {
        public static string FilePath {get{return Path.Combine(AppPaths.DataDir,"telegram-control.json");}}
        public static TelegramControlOptions Load()
        {
            try
            {
                if(!File.Exists(FilePath))return new TelegramControlOptions();if(new FileInfo(FilePath).Length>65536)throw new IOException();
                var o=new JavaScriptSerializer().Deserialize<TelegramControlOptions>(File.ReadAllText(FilePath));if(o==null)throw new IOException();
                if(o.Problem()!=null){o.Enabled=false;o.LoadError="کنترل ربات برای ایمنی خاموش شد؛ توکن قابل خواندن نیست یا کاربران مجاز کامل نشده‌اند. فایل قبلی حفظ شده است.";if(o.Problem()!=null)throw new IOException();}
                return o;
            }
            catch{return new TelegramControlOptions{LoadError="خواندن تنظیمات ربات ناموفق بود؛ اتصال خاموش و فایل قبلی حفظ شد."};}
        }
        public static void Save(TelegramControlOptions o){string p=o.Problem();if(p!=null)throw new ArgumentException(p);TextUtil.WriteLinesAtomically(FilePath,new[]{new JavaScriptSerializer().Serialize(o)});}
        public static List<TelegramUser> ParseUsers(string text)
        {
            var result=new List<TelegramUser>();
            foreach(string raw in (text??"").Split(new[]{'\r','\n',',',';'},StringSplitOptions.RemoveEmptyEntries))
            {
                string[] row=raw.Trim().Split(':');long id;
                if(row.Length>2||!long.TryParse(row[0].Trim(),NumberStyles.None,CultureInfo.InvariantCulture,out id)||id<=0||row.Length==2&&row[1].Trim()!="admin"&&row[1].Trim()!="report")throw new ArgumentException("هر خط: شناسهٔ عددی:admin یا شناسهٔ عددی:report");
                if(result.Any(u=>u.Id==id))throw new ArgumentException("شناسهٔ تکراری است.");
                result.Add(new TelegramUser{Id=id,Admin=row.Length==2&&row[1].Trim()=="admin"});
            }
            return result;
        }
    }
    public interface ITelegramApi
    {
        IDictionary<string,object> Call(string method,object data);
        void Document(long chat,string text);
    }
    public sealed class TelegramConnectionException : IOException
    {
        public int StatusCode {get;private set;}
        public TelegramConnectionException(int status):base("Telegram request failed (HTTP "+status+"); no token or request URL is logged."){StatusCode=status;}
    }
    public sealed class TelegramApi : ITelegramApi, IDisposable
    {
        readonly string token;
        readonly object requestLock=new object();
        readonly HashSet<HttpWebRequest> activeRequests=new HashSet<HttpWebRequest>();
        bool disposed;
        void EndRequest(HttpWebRequest r){if(r!=null)lock(requestLock)activeRequests.Remove(r);}
        public void Dispose(){HttpWebRequest[] requests;lock(requestLock){disposed=true;requests=activeRequests.ToArray();activeRequests.Clear();}foreach(var r in requests)try{r.Abort();}catch{}}
        static TelegramConnectionException Failure(WebException e){var response=e.Response as HttpWebResponse;int code=response==null?0:(int)response.StatusCode;if(response!=null)response.Dispose();return new TelegramConnectionException(code);}
        public TelegramApi(string token){if(!TelegramControlOptions.ValidToken(token))throw new ArgumentException("Invalid token");this.token=token;}
        HttpWebRequest Request(string method)
        {
            if(!new[]{"getMe","getWebhookInfo","getUpdates","setMyCommands","setChatMenuButton","sendMessage","answerCallbackQuery","sendDocument"}.Contains(method))throw new ArgumentException("Unsupported bot operation");
            var r=(HttpWebRequest)WebRequest.Create("https://api.telegram.org/bot"+token+"/"+method);r.Method="POST";r.Timeout=30000;r.ReadWriteTimeout=30000;r.AllowAutoRedirect=false;r.Proxy=WebRequest.DefaultWebProxy;
            ServicePointManager.SecurityProtocol|=(SecurityProtocolType)3072;
            lock(requestLock){if(disposed)throw new ObjectDisposedException("TelegramApi");activeRequests.Add(r);}
            return r;
        }
        public IDictionary<string,object> Call(string method,object data)
        {
            HttpWebRequest r=null;
            try
            {
                r=Request(method);r.ContentType="application/json; charset=utf-8";byte[] bytes=Encoding.UTF8.GetBytes(new JavaScriptSerializer().Serialize(data));r.ContentLength=bytes.Length;
                using(var stream=r.GetRequestStream())stream.Write(bytes,0,bytes.Length);
                using(var response=r.GetResponse())using(var reader=new StreamReader(response.GetResponseStream()))
                {string text=reader.ReadToEnd();if(text.Length>2097152)throw new IOException();var result=new JavaScriptSerializer{MaxJsonLength=2097152}.Deserialize<Dictionary<string,object>>(text);if(!result.ContainsKey("ok")||!object.Equals(result["ok"],true))throw new IOException();return result;}
            }
            catch(WebException e){throw Failure(e);}
            catch{throw new IOException("Telegram request failed; check connection/token. No automatic resend of an uncertain send.");}
            finally{EndRequest(r);}
        }
        public void Document(long chat,string text)
        {
            HttpWebRequest r=null;
            try
            {
                byte[] payload=Encoding.UTF8.GetBytes(text??"");if(payload.Length>2097152)throw new IOException();
                string boundary="mf"+Guid.NewGuid().ToString("N");byte[] before=Encoding.UTF8.GetBytes("--"+boundary+"\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n"+chat.ToString(CultureInfo.InvariantCulture)+"\r\n--"+boundary+"\r\nContent-Disposition: form-data; name=\"document\"; filename=\"MetaFactory-report.txt\"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n");byte[] after=Encoding.UTF8.GetBytes("\r\n--"+boundary+"--\r\n");r=Request("sendDocument");r.ContentType="multipart/form-data; boundary="+boundary;r.ContentLength=before.Length+payload.Length+after.Length;
                using(var stream=r.GetRequestStream()){stream.Write(before,0,before.Length);stream.Write(payload,0,payload.Length);stream.Write(after,0,after.Length);}
                using(var response=r.GetResponse())using(var reader=new StreamReader(response.GetResponseStream())){var result=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(reader.ReadToEnd());if(!object.Equals(result["ok"],true))throw new IOException();}
            }
            catch(WebException e){throw Failure(e);}
            catch{throw new IOException("Telegram document delivery failed or is uncertain; not resent automatically.");}
            finally{EndRequest(r);}
        }
    }
    public sealed class TelegramCandidate
    {
        public long Id;
        public string Name;
    }
    public static class TelegramSetup
    {
        static IDictionary<string,object> Obj(object value){return value as IDictionary<string,object>??new Dictionary<string,object>();}
        static object Get(IDictionary<string,object> value,string key){object result;return value.TryGetValue(key,out result)?result:null;}
        static long Id(IDictionary<string,object> value,string key){long result;return long.TryParse(Convert.ToString(Get(value,key),CultureInfo.InvariantCulture),out result)?result:0;}
        public static List<TelegramCandidate> FindUsers(ITelegramApi api)
        {
            var webhook=Obj(Get(api.Call("getWebhookInfo",new{}),"result"));if(!string.IsNullOrEmpty(Convert.ToString(Get(webhook,"url"))))throw new InvalidOperationException("ربات webhook فعال دارد؛ اتصال قبلی تغییر نکرد.");
            var response=api.Call("getUpdates",new{timeout=0,limit=100});
            var result=new List<TelegramCandidate>();var updates=Get(response,"result") as System.Collections.IEnumerable;if(updates==null)return result;
            foreach(var item in updates)
            {
                var message=Obj(Get(Obj(item),"message"));var chat=Obj(Get(message,"chat"));var from=Obj(Get(message,"from"));long id=Id(from,"id");
                if(id<=0||Id(chat,"id")!=id||Convert.ToString(Get(chat,"type"))!="private"||object.Equals(Get(from,"is_bot"),true)||result.Any(u=>u.Id==id))continue;
                result.Add(new TelegramCandidate{Id=id,Name=TextUtil.OneLine(Convert.ToString(Get(from,"first_name"))+" @"+Convert.ToString(Get(from,"username")))});
            }
            return result;
        }
    }
    public sealed class TelegramTarget
    {
        public string Key,Name,Login,Identity;
        public Dictionary<string,string> Folders=new Dictionary<string,string>();
    }
    public sealed class TelegramRequest
    {
        public long User;
        public string Kind,Range="today";
        public TextParts Parts=TextParts.All;
        public List<TelegramTarget> Targets=new List<TelegramTarget>();
        public DateTime StartedUtc=DateTime.UtcNow;
    }
    public sealed class TelegramReply
    {
        public string Text;
        public object Keyboard;
        public TelegramReply(string text,object keyboard=null){Text=text;Keyboard=keyboard;}
    }
    public sealed class TelegramControl : IDisposable
    {
        sealed class ActionItem{public long User;public DateTime Expires;public string Kind,Range;public List<TelegramTarget> Targets;public bool Used;}
        readonly ITelegramApi api;
        readonly TelegramControlOptions options;
        readonly Func<List<TelegramTarget>> catalog;
        readonly Func<TelegramRequest,Task<string>> execute;
        readonly Action<string> status;
        readonly Dictionary<string,ActionItem> actions=new Dictionary<string,ActionItem>();
        readonly Dictionary<long,TextParts> fields=new Dictionary<long,TextParts>();
        readonly object sync=new object();
        readonly DateTime started=DateTime.UtcNow;
        volatile bool stopped;
        public volatile bool Connected;
        long offset;
        int inflight;
        public TelegramControl(TelegramControlOptions options,ITelegramApi api,Func<List<TelegramTarget>> catalog,Func<TelegramRequest,Task<string>> execute,Action<string> status)
        {this.options=options.Snapshot();this.api=api;this.catalog=catalog;this.execute=execute;this.status=status;}
        static Dictionary<string,object> Obj(object value){return value as Dictionary<string,object>??new Dictionary<string,object>();}
        static object Val(IDictionary<string,object> value,string key){object result;return value.TryGetValue(key,out result)?result:null;}
        static long Num(IDictionary<string,object> value,string key){long result;return long.TryParse(Convert.ToString(Val(value,key),CultureInfo.InvariantCulture),out result)?result:0;}
        static string Str(IDictionary<string,object> value,string key){return Convert.ToString(Val(value,key),CultureInfo.InvariantCulture)??"";}
        public static object Button(string text,string callback){return new Dictionary<string,object>{{"text",text},{"callback_data",callback}};}
        object Keyboard(IEnumerable<object[]> rows){return new Dictionary<string,object>{{"inline_keyboard",rows.ToArray()}};}
        string Link(long user,string kind,List<TelegramTarget> targets=null,string range="today")
        {
            lock(sync)
            {
                foreach(var key in actions.Where(x=>x.Value.Expires<DateTime.UtcNow||x.Value.Used).Select(x=>x.Key).ToList())actions.Remove(key);
                if(actions.Count>=1000)actions.Remove(actions.Keys.First());
                string nonce="mf:"+Guid.NewGuid().ToString("N");actions[nonce]=new ActionItem{User=user,Kind=kind,Targets=targets,Range=range,Expires=DateTime.UtcNow.AddMinutes(10)};return nonce;
            }
        }
        object B(long user,string text,string kind,List<TelegramTarget> targets=null,string range="today")
        {text=TextUtil.OneLine(text);if(text.Length>60){int end=57;if(char.IsHighSurrogate(text[end-1]))end--;text=text.Substring(0,end)+"…";}return Button(text,Link(user,kind,targets,range));}
        public TelegramReply Menu(long user)
        {
            var rows=new List<object[]>{new[]{B(user,"👥 دانشجوها","students"),B(user,"📁 پوشه‌ها","folders")},new[]{B(user,"📊 گزارش همه","all"),B(user,"🟢 وضعیت زنده","status")},new[]{B(user,"🧾 اطلاعات گزارش","fields"),B(user,"راهنما","help")}};
            if(options.Administrator(user))rows.Add(new[]{B(user,"⚙️ مدیریت متاتریدرها","manage")});
            return new TelegramReply("متافکتوری\nمحدوده و نوع گزارش را انتخاب کن. گزارش تازه با زمان خواندن مشخص می‌شود.",Keyboard(rows));
        }
        TelegramReply Scope(long user,List<TelegramTarget> targets)
        {
            if(targets==null||targets.Count==0)return new TelegramReply("حسابی در این محدوده نیست.");
            var rows=new List<object[]>{new[]{B(user,"امروز","fresh",targets),B(user,"دیروز","fresh",targets,"yesterday")},new[]{B(user,"این هفته","fresh",targets,"week"),B(user,"این ماه","fresh",targets,"month")},new[]{B(user,"آخرین گزارش ذخیره‌شده","cached",targets)},new[]{B(user,"وضعیت زنده","live",targets)}};
            if(options.Administrator(user))rows.Add(new[]{B(user,"مدیریت این حساب‌ها","operations",targets)});
            rows.Add(new[]{B(user,"بازگشت به منو","menu")});
            return new TelegramReply("تعداد حساب‌ها: "+targets.Count+"\n"+(targets.Count==1?targets[0].Name+" · "+targets[0].Login:"گزارش برای تمام حساب‌های این محدوده تهیه می‌شود."),Keyboard(rows));
        }
        TelegramReply List(long user,string kind,string query="",int page=0)
        {
            var all=catalog();var rows=new List<object[]>();string title;
            if(kind=="folders")
            {
                title="پوشه‌ها";var folders=all.SelectMany(t=>t.Folders).GroupBy(x=>x.Key).Select(g=>g.First()).ToList();
                foreach(var f in folders.Skip(page*10).Take(10))rows.Add(new[]{B(user,f.Value,"scope",all.Where(t=>t.Folders.ContainsKey(f.Key)).ToList())});
                if((page+1)*10<folders.Count)rows.Add(new[]{B(user,"بعدی","folders:"+(page+1))});
            }
            else
            {
                title="دانشجوها؛ برای جستجو نام یا شماره حساب را پیام بده.";
                all=all.Where(t=>string.IsNullOrEmpty(query)||t.Name.IndexOf(query,StringComparison.OrdinalIgnoreCase)>=0||t.Login.Contains(TextUtil.LatinDigits(query))).ToList();
                foreach(var target in all.Skip(page*10).Take(10))rows.Add(new[]{B(user,target.Name+" · "+target.Login,"scope",new List<TelegramTarget>{target})});
                if((page+1)*10<all.Count)rows.Add(new[]{B(user,"بعدی","students:"+(page+1)+":"+query)});
            }
            rows.Add(new[]{B(user,"منو","menu")});return new TelegramReply(title,Keyboard(rows));
        }
        TelegramReply Fields(long user)
        {
            TextParts selected;lock(sync){if(!fields.TryGetValue(user,out selected))selected=TextParts.All;}
            var rows=new List<object[]>();foreach(var part in ReportText.Names)rows.Add(new[]{B(user,((selected&part.Key)!=0?"✓ ":"□ ")+part.Value,"field:"+((int)part.Key).ToString(CultureInfo.InvariantCulture))});
            rows.Add(new[]{B(user,"انتخاب همه","fieldall"),B(user,"منو","menu")});return new TelegramReply("اطلاعات موردنیاز را انتخاب کن؛ این انتخاب فقط برای حساب تلگرام خودت است. زمان، هویت حساب، اکوئیتی و پروفیت فاکتور کل همیشه درج می‌شود.",Keyboard(rows));
        }
        TelegramReply Operations(long user,List<TelegramTarget> targets)
        {
            if(!options.Administrator(user))return new TelegramReply("دسترسی مدیریتی نداری.");
            return new TelegramReply("مدیریت "+targets.Count+" حساب؛ اجرای زنده یک نسخهٔ اصلی برای هر حساب باز می‌کند.",Keyboard(new[]{new[]{B(user,"▶ اجرای گزارش زنده","confirm:open",targets)},new[]{B(user,"بستن نسخه‌های بررسی؛ زنده بماند","confirm:review",targets)},new[]{B(user,"بستن نسخه‌های زنده","confirm:primary",targets),B(user,"بستن هر دو نسخه","confirm:both",targets)},new[]{B(user,"انصراف / منو","menu")}}));
        }
        TelegramReply Dispatch(long user,string kind,List<TelegramTarget> targets,string range,string query="")
        {
            int page;
            if(kind.StartsWith("students:"))
            {
                string body=kind.Substring(9);int separator=body.IndexOf(':');string number=separator<0?body:body.Substring(0,separator);
                if(int.TryParse(number,out page)&&page>=0)return List(user,"students",separator<0?"":body.Substring(separator+1),page);
            }
            if(kind.StartsWith("folders:")&&int.TryParse(kind.Substring(8),out page))return List(user,"folders","",page);
            if(kind=="menu")return Menu(user);
            if(kind=="students"||kind=="folders")return List(user,kind,query);
            if(kind=="all"||kind=="manage")return Scope(user,catalog());
            if(kind=="scope")return Scope(user,targets);
            if(kind=="help")return new TelegramReply("متافکتوری باید روی کامپیوتر روشن و به اینترنت وصل باشد.\nگزارش تازه از گزارش ذخیره‌شده جداست؛ باز بودن پنجرهٔ متاتریدر به‌تنهایی اثبات گزارش زنده نیست.\nبرای تغییر کاربران و توکن از ابزارها ← ربات تلگرام در برنامه استفاده کن.\n/start منو\n/myid شناسهٔ خودت");
            if(kind=="fields"||kind=="fieldall"||kind.StartsWith("field:"))
            {
                lock(sync){TextParts value;if(!fields.TryGetValue(user,out value))value=TextParts.All;if(kind=="fieldall")value=TextParts.All;else if(kind.StartsWith("field:")){int flag;if(int.TryParse(kind.Substring(6),out flag))value^=(TextParts)flag;}fields[user]=value;}
                return Fields(user);
            }
            if(kind=="operations")return Operations(user,targets);
            if(kind.StartsWith("confirm:"))
            {
                if(!options.Administrator(user))return new TelegramReply("فقط مدیر مجاز است.");
                return new TelegramReply("تأیید می‌کنی؟\nعملیات: "+(kind.Substring(8)=="open"?"اجرای گزارش زنده":kind.Substring(8)=="review"?"بستن نسخه‌های بررسی":kind.Substring(8)=="primary"?"بستن گزارش‌های زنده":"بستن هر دو نسخه")+"\nتعداد حساب‌ها: "+targets.Count+"\n"+string.Join("، ",targets.Take(5).Select(t=>t.Name)),Keyboard(new[]{new[]{B(user,"تأیید اجرا","execute:"+kind.Substring(8),targets),B(user,"انصراف","menu")}}));
            }
            if(kind=="status")targets=catalog();
            if(kind=="status"||kind=="live"||kind=="fresh"||kind=="cached"||kind.StartsWith("execute:"))
            {
                if(kind.StartsWith("execute:")&&!options.Administrator(user))return new TelegramReply("فقط مدیر مجاز است.");
                if(Interlocked.Increment(ref inflight)>4){Interlocked.Decrement(ref inflight);return new TelegramReply("درخواست دیگری در جریان است؛ کمی بعد دوباره امتحان کن.");}
                TextParts parts;lock(sync){if(!fields.TryGetValue(user,out parts))parts=TextParts.All;}
                var request=new TelegramRequest{User=user,Kind=kind,Range=range,Parts=parts,Targets=targets??new List<TelegramTarget>(),StartedUtc=DateTime.UtcNow};
                Task.Run(async ()=>
                {
                    try
                    {
                        string text;try{text=await execute(request);}catch{text="درخواست کامل نشد؛ وضعیت را از برنامه بررسی کن.";}
                        if(!stopped)try{Send(user,new TelegramReply(text));}catch{status("نتیجهٔ ارسال گزارش تأیید نشد؛ خودکار دوباره ارسال نمی‌شود.");}
                    }
                    finally{Interlocked.Decrement(ref inflight);}
                });
                return new TelegramReply(kind=="fresh"?"در حال گرفتن خروجی تازه… نتیجه با زمان خواندن ارسال می‌شود.":"درخواست دریافت شد…");
            }
            return Menu(user);
        }
        public TelegramReply Handle(long user,long chat,string chatType,string text,string callback=null)
        {
            if(stopped)return new TelegramReply("اتصال متوقف شده است.");
            if(chatType!="private"||user<=0||chat!=user)return new TelegramReply("مدیریت و گزارش فقط در گفتگوی خصوصی با ربات فعال است.");
            if(text=="/myid")return new TelegramReply("شناسهٔ عددی خودت: "+user.ToString(CultureInfo.InvariantCulture));
            if(!options.Allowed(user))return new TelegramReply("دسترسی این حساب فعال نشده است. شناسهٔ خودت را به مدیر بده: "+user.ToString(CultureInfo.InvariantCulture));
            if(callback!=null)
            {
                ActionItem item;lock(sync){if(!actions.TryGetValue(callback,out item)||item.User!=user||item.Expires<DateTime.UtcNow||item.Used)return new TelegramReply("این دکمه منقضی شده؛ /start بزن.");if(item.Kind.StartsWith("execute:"))item.Used=true;}
                return Dispatch(user,item.Kind,item.Targets,item.Range);
            }
            string command=(text??"").Trim().Split(' ')[0].Split('@')[0];
            switch(command){case "/start":case "/menu":return Menu(user);case "/students":return List(user,"students");case "/folders":return List(user,"folders");case "/report":return Scope(user,catalog());case "/live":return Dispatch(user,"status",null,"today");case "/manage":return options.Administrator(user)?Scope(user,catalog()):new TelegramReply("فقط مدیر مجاز است.");case "/help":return Dispatch(user,"help",null,"today");default:return command.StartsWith("/")?Menu(user):List(user,"students",(text??"").Trim());}
        }
        void Send(long chat,TelegramReply reply)
        {
            if(stopped)return;
            if((reply.Text??"").Length>3500){api.Document(chat,reply.Text);return;}
            var data=new Dictionary<string,object>{{"chat_id",chat},{"text",reply.Text??""}};if(reply.Keyboard!=null)data["reply_markup"]=reply.Keyboard;api.Call("sendMessage",data);
        }
        public bool QueueReport(long user,List<TelegramTarget> targets,string range)
        {
            if(stopped||!Connected||!options.Allowed(user)||Interlocked.CompareExchange(ref inflight,0,0)>=4)return false;
            Task.Run(()=>{try{Send(user,Dispatch(user,"fresh",targets,range));}catch{status("نتیجهٔ ارسال درخواست دستی تأیید نشد.");}});return true;
        }
        public void Start(){if(options.Problem()!=null||!options.Enabled)return;new Thread(Run){IsBackground=true,Name="telegram-control"}.Start();}
        public string BotUsername {get;private set;}
        public void Provision()
        {
            var webhook=Obj(Val(api.Call("getWebhookInfo",new{}),"result"));if(!string.IsNullOrEmpty(Str(webhook,"url")))throw new InvalidOperationException("این ربات webhook فعال دارد؛ برای حفظ اتصال قبلی، متافکتوری آن را تغییر نداد. یک ربات اختصاصی استفاده کن یا اتصال قبلی را آگاهانه آزاد کن.");
            var me=Obj(Val(api.Call("getMe",new{}),"result"));
            if(!object.Equals(Val(me,"is_bot"),true)||Num(me,"id")<=0)throw new InvalidOperationException("هویت ربات تأیید نشد؛ تغییری انجام نشد.");
            BotUsername=Str(me,"username");if(!Regex.IsMatch(BotUsername,@"\A[A-Za-z0-9_]{1,64}\z"))BotUsername="";
            var commands=new[]{new{command="start",description="منوی متافکتوری"},new{command="students",description="انتخاب دانشجو"},new{command="folders",description="انتخاب پوشه"},new{command="report",description="گزارش تازه یا ذخیره‌شده"},new{command="live",description="وضعیت گزارش زنده"},new{command="help",description="راهنما"},new{command="myid",description="شناسهٔ تلگرام خودم"}};
            foreach(var user in options.Users)
            {
                if(stopped)return;
                try{api.Call("setMyCommands",new{scope=new{type="chat",chat_id=user.Id},commands=commands});api.Call("setChatMenuButton",new{chat_id=user.Id,menu_button=new{type="commands"}});}catch{/* A user may not have started the bot yet. Private /start still displays the inline menu. */}
            }
        }
        void Run()
        {
            while(!stopped)
            {
                try{Provision();Connected=true;status("ربات "+(string.IsNullOrEmpty(BotUsername)?"":"@"+BotUsername+" ")+"متصل است؛ منتظر درخواست کاربران مجاز.");break;}
                catch(InvalidOperationException e){status(e.Message);return;}
                catch(TelegramConnectionException e){if(e.StatusCode==401||e.StatusCode==409){status("توکن معتبر نیست یا ربات در برنامهٔ دیگری فعال است؛ اتصال قبلی تغییر نکرد.");return;}status("اتصال اولیه ناموفق بود؛ بررسی دوباره تا ۳۰ ثانیه دیگر.");}
                catch{status("اتصال اولیه ناموفق بود؛ اینترنت، توکن و /start کاربران را بررسی کن. بررسی دوباره تا ۳۰ ثانیه دیگر.");}
                for(int i=0;i<300&&!stopped;i++)Thread.Sleep(100);
            }
            while(!stopped)
            {
                try
                {
                    var response=api.Call("getUpdates",new{offset=offset,timeout=20,limit=20,allowed_updates=new[]{"message","callback_query"}});Connected=true;
                    var updates=Val(response,"result") as System.Collections.IEnumerable;if(updates==null)continue;
                    foreach(var value in updates)
                    {
                        if(stopped)break;var update=Obj(value);long id=Num(update,"update_id");if(id<offset)continue;offset=id+1;
                        var callback=Obj(Val(update,"callback_query"));var message=Obj(Val(update,"message"));bool isCallback=callback.Count>0;if(isCallback)message=Obj(Val(callback,"message"));
                        var from=Obj(Val(isCallback?callback:message,"from"));var chat=Obj(Val(message,"chat"));long user=Num(from,"id"),chatId=Num(chat,"id");
                        if(!isCallback){long date=Num(message,"date");if(date<(long)(started-new DateTime(1970,1,1,0,0,0,DateTimeKind.Utc)).TotalSeconds-2)continue;}
                        var reply=Handle(user,chatId,Str(chat,"type"),Str(message,"text"),isCallback?Str(callback,"data"):null);
                        if(isCallback)try{api.Call("answerCallbackQuery",new{callback_query_id=Str(callback,"id")});}catch{}
                        Send(chatId,reply);
                    }
                }
                catch(TelegramConnectionException e){Connected=false;if(!stopped){if(e.StatusCode==401||e.StatusCode==409){status("ربات جای دیگری فعال است یا توکن تغییر کرده؛ این اتصال متوقف شد و اتصال قبلی دست‌نخورده ماند.");stopped=true;}else{status("ارتباط تلگرام قطع شد؛ ارسال نامشخص خودکار تکرار نمی‌شود.");for(int i=0;i<100&&!stopped;i++)Thread.Sleep(100);}}}
                catch{Connected=false;if(!stopped){status("ارتباط ربات قطع یا ارسال نامشخص شد؛ درخواست ارسال‌شده خودکار تکرار نمی‌شود.");for(int i=0;i<50&&!stopped;i++)Thread.Sleep(100);}}
            }
        }
        public void Dispose(){stopped=true;Connected=false;var disposable=api as IDisposable;if(disposable!=null)disposable.Dispose();lock(sync){actions.Clear();fields.Clear();}}
    }
}
