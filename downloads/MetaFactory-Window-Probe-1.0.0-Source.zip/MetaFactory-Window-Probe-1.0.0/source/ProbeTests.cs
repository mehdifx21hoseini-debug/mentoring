using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Threading;using MetaFactoryWindowProbe;
class ProbeTests
{
 sealed class Fake:IWindowApi
 {
  readonly ThreadLocal<IntPtr> desktop=new ThreadLocal<IntPtr>(()=>new IntPtr(1));
  public readonly List<string> Events=new List<string>();
  public int CurrentWindowError,IsolatedWindowError,CurrentTimerError,CreateError,AttachError;public bool DestroyOk=true;
  void E(string v){lock(Events)Events.Add(v+":"+Thread.CurrentThread.ManagedThreadId);}
  public IntPtr CurrentDesktop(){return desktop.Value;}public string DesktopName(IntPtr d){return d.ToInt32()==1?"Default":"Temporary";}public int HeapKb(IntPtr d){return d.ToInt32()==1?20480:1024;}
  public IntPtr CreateIsolated(out int error){E("create-desktop");error=CreateError;return error==0?new IntPtr(2):IntPtr.Zero;}
  public bool Attach(IntPtr d,out int error){E("attach-desktop");error=AttachError;if(error!=0)return false;desktop.Value=d;return true;}
  public IntPtr CreateTinyWindow(out int error){int d=desktop.Value.ToInt32();E("create-window-"+d);error=d==1?CurrentWindowError:IsolatedWindowError;return error==0?new IntPtr(10+d):IntPtr.Zero;}
  public UIntPtr StartTimer(IntPtr h,out int error){E("timer-"+h);error=h.ToInt32()==11?CurrentTimerError:0;return error==0?new UIntPtr(7):UIntPtr.Zero;}
  public bool StopTimer(IntPtr h,UIntPtr t){E("kill-timer-"+h);return true;}
  public bool Destroy(IntPtr h){E("destroy-window-"+h);return DestroyOk;}
  public bool CloseIsolated(IntPtr d){E("close-desktop");return true;}
 }
 static int checks;static void Check(bool ok,string why){if(!ok)throw new Exception(why);checks++;Console.WriteLine("PASS "+why);}
 static int Index(Fake f,string key){return f.Events.FindIndex(x=>x.StartsWith(key+":"));}
 static int Main()
 {
  string root=Path.Combine(Path.GetTempPath(),"mf-window-probe-test-"+Guid.NewGuid().ToString("N"));
  try
  {
   var api=new Fake();var pair=ProbeSuite.Run(api);
   Check(pair.Current.WindowCreated&&pair.Current.TimerCreated&&pair.Isolated.WindowCreated&&pair.Isolated.TimerCreated,"both contexts tested");
   Check(pair.Current.WindowDestroyed&&pair.Isolated.WindowDestroyed&&pair.DesktopClosed,"both windows destroyed and owned desktop closed");
   Check(Index(api,"destroy-window-12")<Index(api,"close-desktop"),"desktop handle closes only after worker destroys its window and exits");
   Check(api.Events.Count(x=>x.StartsWith("attach-desktop:"))==1,"inherited desktop is not switched; only isolated worker attaches");
   Check(pair.Current.HeapKb==20480&&pair.Isolated.HeapKb==1024,"context capacities remain separate and are not usage estimates");
   Check(pair.Observation.Contains("does_not_prove_full_terminal_capacity"),"tiny successful allocations do not claim full terminal readiness");
   api=new Fake{CurrentWindowError=8};pair=ProbeSuite.Run(api);
   Check(!pair.Current.WindowCreated&&pair.Current.WindowError==8&&pair.Isolated.WindowCreated,"real current-desktop failure code preserved alongside isolated success");
   Check(!api.Events.Any(x=>x.StartsWith("destroy-window-11:"))&&!api.Events.Any(x=>x.StartsWith("timer-11:")),"failed allocation never destroys or uses a null window");
   Check(pair.Observation.Contains("not_automatic_heap_diagnosis"),"isolated success does not overclaim exact exhausted pool");
   api=new Fake{CurrentTimerError=8};pair=ProbeSuite.Run(api);
   Check(pair.Current.WindowCreated&&!pair.Current.TimerCreated&&pair.Current.TimerError==8&&pair.Current.WindowDestroyed,"timer failure still destroys owned window");
   api=new Fake{CreateError=5};pair=ProbeSuite.Run(api);
   Check(pair.DesktopCreateError==5&&!pair.DesktopCreated&&!api.Events.Any(x=>x.StartsWith("attach-desktop:")),"desktop access denial is reported without attaching or closing an unknown handle");
   Check(pair.Observation.Contains("unavailable_not_a_capacity_diagnosis"),"desktop access denial not treated as RAM diagnosis");
   api=new Fake{AttachError=170};pair=ProbeSuite.Run(api);
   Check(!pair.Isolated.Attached&&pair.Isolated.AttachError==170&&pair.DesktopClosed,"attachment failure closes only owned isolated handle after worker exits");
   api=new Fake{CurrentWindowError=8,IsolatedWindowError=8};pair=ProbeSuite.Run(api);
   Check(pair.Observation=="both_probes_failed_cause_unproven","two failures keep cause unresolved");
   api=new Fake{DestroyOk=false};pair=ProbeSuite.Run(api);Check(ProbeSuite.MustStop(pair),"unconfirmed cleanup stops further allocation cycles");
   pair=new PairResult{Current=new ProbeResult{TimedOut=true}};Check(ProbeSuite.MustStop(pair),"timeout prevents further allocation cycles");
   var trace=new BoundedTrace(root);Check(File.ReadAllText(Path.Combine(root,"window-probe.txt")).Contains(BoundedTrace.Schema),"trace schema written");
   bool accepted=true;int i=0;while(accepted&&i++<200)accepted=trace.Write("sample",new{payload=new string('x',8192)});
   string path=Path.Combine(root,"window-probe.txt");Check(!accepted&&new FileInfo(path).Length<=BoundedTrace.MaxBytes,"current trace stays within1MB");
   trace=new BoundedTrace(root);Check(File.Exists(Path.Combine(root,"window-probe-previous.txt")),"one previous owned run retained");
   string foreign=Path.Combine(root,"foreign");Directory.CreateDirectory(foreign);File.WriteAllText(Path.Combine(foreign,"window-probe.txt"),"USER_FILE");bool blocked=false;try{new BoundedTrace(foreign);}catch(IOException){blocked=true;}
   Check(blocked&&File.ReadAllText(Path.Combine(foreign,"window-probe.txt"))=="USER_FILE","unknown file ownership never overwritten");
   Check(Directory.GetFiles(root,"window-probe*.txt").Length==2,"retention contains current and previous only");
   Console.WriteLine("WINDOW PROBE PASS "+checks+" (synthetic native API; Windows allocation test still required)");return 0;
  }
  catch(Exception e){Console.Error.WriteLine(e);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
