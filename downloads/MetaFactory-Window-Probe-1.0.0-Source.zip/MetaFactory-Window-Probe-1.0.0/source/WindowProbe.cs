using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Threading;
using System.Diagnostics;
using System.Globalization;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Web.Script.Serialization;
using System.Reflection;
[assembly: AssemblyTitle("MetaFactory Window Resource Probe")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
namespace MetaFactoryWindowProbe
{
    public interface IWindowApi
    {
        IntPtr CurrentDesktop(); string DesktopName(IntPtr desktop); int HeapKb(IntPtr desktop);
        IntPtr CreateIsolated(out int error); bool Attach(IntPtr desktop,out int error);
        IntPtr CreateTinyWindow(out int error); UIntPtr StartTimer(IntPtr window,out int error);
        bool StopTimer(IntPtr window,UIntPtr timer); bool Destroy(IntPtr window); bool CloseIsolated(IntPtr desktop);
    }
    public sealed class ProbeResult
    {
        public string Context,Desktop,ExceptionType,StartedUtc,FinishedUtc;
        public bool Attached,WindowCreated,TimerCreated,TimerStopped,WindowDestroyed,TimedOut;
        public int HeapKb=-1,AttachError,WindowError,TimerError;
    }
    public sealed class PairResult
    {
        public ProbeResult Current,Isolated;
        public int DesktopCreateError;
        public bool DesktopCreated,DesktopClosed;
        public string Observation;
    }
    public static class ProbeSuite
    {
        public static ProbeResult One(IWindowApi api,IntPtr isolated,string context)
        {
            var result=new ProbeResult{Context=context};
            var worker=new Thread(()=>{
                IntPtr window=IntPtr.Zero;UIntPtr timer=UIntPtr.Zero;result.StartedUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture);
                try
                {
                    int error;
                    result.Attached=isolated==IntPtr.Zero||api.Attach(isolated,out result.AttachError);
                    if(!result.Attached)return;
                    IntPtr desktop=api.CurrentDesktop();result.Desktop=api.DesktopName(desktop);result.HeapKb=api.HeapKb(desktop);
                    window=api.CreateTinyWindow(out error);result.WindowError=error;result.WindowCreated=window!=IntPtr.Zero;
                    if(!result.WindowCreated)return;
                    timer=api.StartTimer(window,out error);result.TimerError=error;result.TimerCreated=timer!=UIntPtr.Zero;
                }
                catch(Exception e){result.ExceptionType=e.GetType().Name;}
                finally
                {
                    try{if(timer!=UIntPtr.Zero)result.TimerStopped=api.StopTimer(window,timer);}catch{}
                    try{if(window!=IntPtr.Zero)result.WindowDestroyed=api.Destroy(window);}catch{}
                    result.FinishedUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture);
                }
            });
            worker.IsBackground=true;worker.Start();
            if(!worker.Join(5000))return new ProbeResult{Context=context,TimedOut=true};
            return result;
        }
        public static PairResult Run(IWindowApi api)
        {
            var pair=new PairResult();pair.Current=One(api,IntPtr.Zero,"inherited_desktop");
            if(pair.Current.TimedOut){pair.Observation="probe_timeout_stop_without_further_allocations";return pair;}
            IntPtr desktop=api.CreateIsolated(out pair.DesktopCreateError);pair.DesktopCreated=desktop!=IntPtr.Zero;
            if(desktop!=IntPtr.Zero)
            {
                try{pair.Isolated=One(api,desktop,"temporary_1024KB_desktop");}
                finally{if(pair.Isolated!=null&&!pair.Isolated.TimedOut)pair.DesktopClosed=api.CloseIsolated(desktop);}
            }
            pair.Observation=Classify(pair);
            return pair;
        }
        public static bool MustStop(PairResult p)
        {
            return p.Current.TimedOut||p.Isolated!=null&&p.Isolated.TimedOut||
                p.Current.WindowCreated&&!p.Current.WindowDestroyed||p.Isolated!=null&&p.Isolated.WindowCreated&&!p.Isolated.WindowDestroyed||
                p.DesktopCreated&&!p.DesktopClosed;
        }
        public static string Classify(PairResult p)
        {
            if(p.Current.TimedOut||p.Isolated!=null&&p.Isolated.TimedOut)return "probe_timeout_stop_without_further_allocations";
            if(!p.DesktopCreated||p.Isolated==null||!p.Isolated.Attached)return "isolated_desktop_unavailable_not_a_capacity_diagnosis";
            bool current=p.Current.WindowCreated&&p.Current.TimerCreated,isolated=p.Isolated.WindowCreated&&p.Isolated.TimerCreated;
            if(current&&isolated)return "both_small_probes_succeeded_does_not_prove_full_terminal_capacity";
            if(!current&&isolated)return "inherited_probe_failed_isolated_succeeded_check_exact_errors_not_automatic_heap_diagnosis";
            if(current)return "isolated_probe_failed_inherited_succeeded_not_inherited_heap_exhaustion_proof";
            return "both_probes_failed_cause_unproven";
        }
    }
    public sealed class NativeApi:IWindowApi
    {
        [DllImport("kernel32.dll")]static extern uint GetCurrentThreadId();
        [DllImport("kernel32.dll",CharSet=CharSet.Unicode)]static extern IntPtr GetModuleHandle(string name);
        [DllImport("user32.dll")]static extern IntPtr GetThreadDesktop(uint thread);
        [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr CreateDesktopEx(string name,IntPtr device,IntPtr mode,uint flags,uint access,IntPtr security,uint heap,IntPtr reserved);
        [DllImport("user32.dll",SetLastError=true)]static extern bool SetThreadDesktop(IntPtr desktop);
        [DllImport("user32.dll",SetLastError=true)]static extern bool CloseDesktop(IntPtr desktop);
        [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr CreateWindowEx(uint ex,string cls,string caption,uint style,int x,int y,int width,int height,IntPtr parent,IntPtr menu,IntPtr instance,IntPtr param);
        [DllImport("user32.dll",SetLastError=true)]static extern bool DestroyWindow(IntPtr window);
        [DllImport("user32.dll",SetLastError=true)]static extern UIntPtr SetTimer(IntPtr window,UIntPtr id,uint interval,IntPtr callback);
        [DllImport("user32.dll")]static extern bool KillTimer(IntPtr window,UIntPtr timer);
        [DllImport("user32.dll",CharSet=CharSet.Unicode,EntryPoint="GetUserObjectInformationW",SetLastError=true)]static extern bool ObjectName(IntPtr handle,int index,StringBuilder text,int bytes,out int needed);
        [DllImport("user32.dll",EntryPoint="GetUserObjectInformationW",SetLastError=true)]static extern bool ObjectNumber(IntPtr handle,int index,out uint value,int bytes,out int needed);
        public IntPtr CurrentDesktop(){return GetThreadDesktop(GetCurrentThreadId());}
        public string DesktopName(IntPtr desktop){var s=new StringBuilder(256);int n;return ObjectName(desktop,2,s,512,out n)?s.ToString():"unknown";}
        public int HeapKb(IntPtr desktop){uint n;int required;return ObjectNumber(desktop,5,out n,4,out required)?(int)n:-1;}
        public IntPtr CreateIsolated(out int error)
        {
            // CREATEWINDOW | READOBJECTS | WRITEOBJECTS only: no SWITCHDESKTOP right, no global setting.
            IntPtr d=CreateDesktopEx("MF_WindowProbe_"+Guid.NewGuid().ToString("N"),IntPtr.Zero,IntPtr.Zero,0,0x83,IntPtr.Zero,1024,IntPtr.Zero);
            error=d==IntPtr.Zero?Marshal.GetLastWin32Error():0;return d;
        }
        public bool Attach(IntPtr desktop,out int error){bool ok=SetThreadDesktop(desktop);error=ok?0:Marshal.GetLastWin32Error();return ok;}
        public IntPtr CreateTinyWindow(out int error)
        {
            // Built-in class, empty caption, hidden popup, owned by this worker; never ShowWindow/SwitchDesktop.
            IntPtr h=CreateWindowEx(0,"STATIC","",0x80000000,0,0,1,1,IntPtr.Zero,IntPtr.Zero,GetModuleHandle(null),IntPtr.Zero);
            error=h==IntPtr.Zero?Marshal.GetLastWin32Error():0;return h;
        }
        public UIntPtr StartTimer(IntPtr window,out int error){UIntPtr id=SetTimer(window,new UIntPtr(1),1000,IntPtr.Zero);error=id==UIntPtr.Zero?Marshal.GetLastWin32Error():0;return id;}
        public bool StopTimer(IntPtr window,UIntPtr timer){return KillTimer(window,timer);}
        public bool Destroy(IntPtr window){return DestroyWindow(window);}
        public bool CloseIsolated(IntPtr desktop){return CloseDesktop(desktop);}
    }
    public sealed class BoundedTrace
    {
        readonly string path;readonly JavaScriptSerializer json=new JavaScriptSerializer();
        public const string Schema="MF_WINDOW_PROBE_1";
        public const int MaxBytes=1024*1024;
        public BoundedTrace(string directory,string name="window-probe")
        {
            Directory.CreateDirectory(directory);path=Path.Combine(directory,name+".txt");string old=Path.Combine(directory,name+"-previous.txt");
            if(File.Exists(path))
            {
                if(!Owned(path)||File.Exists(old)&&!Owned(old))throw new IOException("Unknown file ownership; no existing file overwritten.");
                if(File.Exists(old))File.Delete(old);File.Move(path,old);
            }
            Write("begin",new{schema=Schema,version="1.0.0",utc_offset_minutes=TimeZoneInfo.Local.GetUtcOffset(DateTime.Now).TotalMinutes,
                bitness=IntPtr.Size*8,os=Environment.OSVersion.ToString(),scope="Two short hidden-window and timer allocations every30s for60min; no registry writes, no terminal launch/kill, no desktop switching, no account/window-title/command-line capture.",
                limits="1MBcurrent +1MBprevious max. Sequential tests do not measure free heap bytes, verify timer delivery, broker connection or prove full terminal capacity. Named-process counts include incomplete starts."});
        }
        static bool Owned(string file){using(var reader=new StreamReader(file,Encoding.UTF8,true)){char[] c=new char[512];int n=reader.Read(c,0,c.Length);return new string(c,0,n).Contains(Schema);}}
        public bool Write(string kind,object value)
        {
            string line=json.Serialize(new{event_type=kind,utc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture),data=value})+"\r\n";
            if((File.Exists(path)?new FileInfo(path).Length:0)+Encoding.UTF8.GetByteCount(line)+3>MaxBytes)return false;
            File.AppendAllText(path,line,Encoding.UTF8);return true;
        }
    }
    static class Program
    {
        [StructLayout(LayoutKind.Sequential)]struct MemoryStatus
        {
            public uint Length,Load;public ulong TotalPhysical,AvailablePhysical,TotalPageFile,AvailablePageFile,TotalVirtual,AvailableVirtual,AvailableExtendedVirtual;
        }
        [DllImport("kernel32.dll",SetLastError=true)]static extern bool GlobalMemoryStatusEx(ref MemoryStatus status);
        static object Memory()
        {
            var s=new MemoryStatus{Length=(uint)Marshal.SizeOf(typeof(MemoryStatus))};bool ok=GlobalMemoryStatusEx(ref s);
            return new{available=ok,total_physical_mb=s.TotalPhysical/1048576,free_physical_mb=s.AvailablePhysical/1048576,process_commit_limit_mb=s.TotalPageFile/1048576,available_commit_mb=s.AvailablePageFile/1048576};
        }
        static int CountNamed(string name)
        {
            Process[] processes=null;
            try{processes=Process.GetProcessesByName(name);return processes.Length;}catch{return -1;}
            finally{if(processes!=null)foreach(var p in processes)p.Dispose();}
        }
        [STAThread]static int Main(string[] args){try{return Run();}catch{return 1;}}
        static int Run()
        {
            if(Environment.OSVersion.Platform!=PlatformID.Win32NT)return 2;
            string root=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            bool created;using(var mutex=new Mutex(true,@"Local\MetaFactoryWindowResourceProbe_"+Environment.UserName,out created))
            {
                if(!created)return 3;
                try
                {
                    BoundedTrace trace;
                    try{trace=new BoundedTrace(root,"MetaFactory-Window-Test");}
                    catch{trace=new BoundedTrace(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"MT Manager"),"MetaFactory-Window-Test");}
                    var clock=Stopwatch.StartNew();var native=new NativeApi();
                    while(clock.Elapsed<TimeSpan.FromMinutes(60))
                    {
                        var pair=ProbeSuite.Run(native);
                        if(!trace.Write("probe_pair",new{elapsed_seconds=(int)clock.Elapsed.TotalSeconds,named_mt4_processes=CountNamed("terminal"),named_mt5_processes=CountNamed("terminal64"),memory=Memory(),result=pair}))return 4;
                        if(ProbeSuite.MustStop(pair)){trace.Write("stopped",new{reason="worker timeout or cleanup not confirmed; no further allocations"});return 5;}
                        Thread.Sleep(30000);
                    }
                    trace.Write("completed",new{reason="60minute duration reached"});return 0;
                }
                catch{return 1;}
                finally{mutex.ReleaseMutex();}
            }
        }
    }
}
