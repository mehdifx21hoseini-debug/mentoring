#!/bin/sh
set -e
if [ -n "${MF_REF45:-}" ]; then
  R="-nostdlib -noconfig -r:$MF_REF45/mscorlib.dll -r:$MF_REF45/System.dll -r:$MF_REF45/System.Core.dll -r:$MF_REF45/System.Web.Extensions.dll"
else
  R="-r:System.Core -r:System.Web.Extensions"
fi
mcs -optimize+ -platform:anycpu -target:winexe $R -out:MetaFactory-Window-Probe-1.0.0.exe WindowProbe.cs
mcs -optimize+ $R -r:MetaFactory-Window-Probe-1.0.0.exe -out:ProbeTests.exe ProbeTests.cs
mono ProbeTests.exe
