"""Read-only IPC checks; credentials arrive only on stdin, never in logs.

A service may retain IPC only to a proven live private Windows terminal generation.
Every request still requires explicit login. Unproven legacy requests remain one-shot.
"""
import json
import ntpath
import os
import sys
import time


def _path(value):
    if not isinstance(value, str) or not value.strip():
        return None
    value = value.strip().replace('/', '\\')
    if not ntpath.isabs(value):
        return None
    return ntpath.normcase(ntpath.normpath(value)).rstrip('\\')


def _windows_process_identity(pid):
    """Return (creation FILETIME, executable path) only for a live Windows process."""
    if os.name != 'nt':
        return None
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel.CloseHandle.restype = wintypes.BOOL
    kernel.GetProcessTimes.argtypes = (wintypes.HANDLE,) + (ctypes.POINTER(wintypes.FILETIME),) * 4
    kernel.GetProcessTimes.restype = wintypes.BOOL
    kernel.GetExitCodeProcess.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
    kernel.GetExitCodeProcess.restype = wintypes.BOOL
    kernel.QueryFullProcessImageNameW.argtypes = (wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD))
    kernel.QueryFullProcessImageNameW.restype = wintypes.BOOL
    handle = kernel.OpenProcess(0x1000, False, pid)
    if not handle:
        return None
    try:
        status = wintypes.DWORD()
        created, exited, system, user = (wintypes.FILETIME() for _ in range(4))
        size = wintypes.DWORD(32768)
        executable = ctypes.create_unicode_buffer(size.value)
        if (not kernel.GetExitCodeProcess(handle, ctypes.byref(status)) or status.value != 259
                or not kernel.GetProcessTimes(handle, ctypes.byref(created), ctypes.byref(exited), ctypes.byref(system), ctypes.byref(user))
                or not kernel.QueryFullProcessImageNameW(handle, 0, executable, ctypes.byref(size))):
            return None
        return (created.dwHighDateTime << 32) | created.dwLowDateTime, executable.value
    finally:
        kernel.CloseHandle(handle)


def _reply(request):
    source = request if isinstance(request, dict) else {}
    answer = {key: source.get(key) for key in ('token', 'login', 'server')}
    answer.update(state='unconfirmed', reason='No conclusive connection response.',
                  phase='request', init_ms=0, login_ms=0, verify_ms=0,
                  error_code='', attachment='standalone')
    return answer


def _failure(reply, code, reason, rejected=False):
    reply.update(state='rejected' if rejected else 'unconfirmed', error_code=code, reason=reason)
    return reply


def _timed(reply, key, operation):
    started = time.perf_counter()
    try:
        return operation()
    finally:
        reply[key] += max(0, int((time.perf_counter() - started) * 1000))


class Session:
    def __init__(self, api, process_reader=None):
        self.api = api
        self.process_reader = process_reader or _windows_process_identity
        self.identity = None
        self.attached = False

    def close(self):
        # Shutdown detaches IPC; it does not close or trade in the terminal.
        try:
            if self.attached:
                self.api.shutdown()
        except Exception:
            pass
        finally:
            self.identity = None
            self.attached = False

    def _owned(self, request):
        try:
            # FILETIME must remain an exact integer, never a floating JSON number.
            values = (request['terminal_pid'], request['terminal_started'])
            if any(isinstance(value, bool) or not isinstance(value, (int, str)) for value in values):
                return None
            pid, started = (int(value) for value in values)
        except (KeyError, TypeError, ValueError, OverflowError):
            return None
        executable = _path(request['terminal'])
        if pid <= 0 or pid > 0xffffffff or started <= 0 or not executable:
            return None
        actual = self.process_reader(pid)
        if not actual or int(actual[0]) != started or _path(actual[1]) != executable:
            return None
        return executable, pid, started

    @staticmethod
    def _portable_terminal(terminal, identity):
        if terminal is None:
            return False
        directory = ntpath.dirname(identity[0])
        return _path(getattr(terminal, 'path', None)) == directory and _path(getattr(terminal, 'data_path', None)) == directory

    def check(self, request, persistent=False):
        reply = _reply(request)
        retain = False
        try:
            if not isinstance(request, dict):
                return _failure(reply, 'invalid-request', 'The IPC request was invalid.')
            if request.get('cancelled') is True:
                reply['phase'] = 'cancelled'
                return _failure(reply, 'cancelled', 'The IPC check was cancelled.')
            if (any(key not in request for key in ('token', 'login', 'server', 'password', 'terminal', 'timeout'))
                    or not isinstance(request['server'], str) or not request['server'].strip()
                    or not isinstance(request['password'], str) or not isinstance(request['terminal'], str)):
                return _failure(reply, 'invalid-request', 'The IPC request was invalid.')
            timeout = max(1000, min(60000, int(request['timeout'])))
            login = int(request['login'])
            if login <= 0:
                return _failure(reply, 'invalid-request', 'The account number was invalid.')

            owned = persistent and ('terminal_pid' in request or 'terminal_started' in request)
            identity = None
            if owned:
                reply['phase'] = 'ownership'
                token = request['token']
                if not isinstance(token, str) or len(token) != 32 or any(c not in '0123456789abcdefABCDEF' for c in token):
                    return _failure(reply, 'invalid-request-token', 'A fresh request token is required.')
                identity = _timed(reply, 'verify_ms', lambda: self._owned(request))
                if identity is None:
                    return _failure(reply, 'owned-terminal-unverified', 'The private terminal process identity could not be verified.')

            # Reuse only the same owned generation with a healthy portable attachment.
            reuse = identity is not None and self.identity == identity and self.attached
            if reuse:
                current = _timed(reply, 'verify_ms', self.api.terminal_info)
                reuse = self._portable_terminal(current, identity) and bool(getattr(current, 'connected', False))
            if not reuse:
                self.close()
                reply['phase'] = 'initialize'
                self.attached = True  # A failed initialize can leave partial IPC state.
                if not _timed(reply, 'init_ms', lambda: self.api.initialize(request['terminal'], portable=True, timeout=timeout)):
                    return _failure(reply, 'initialize-failed', 'Could not initialize the private MetaTrader terminal.')
                if identity is not None:
                    self.identity = identity
                    current = _timed(reply, 'verify_ms', self.api.terminal_info)
                    if not self._portable_terminal(current, identity):
                        return _failure(reply, 'terminal-path-mismatch', 'The attached terminal path or portable data path did not match the request.')
                    if _timed(reply, 'verify_ms', lambda: self._owned(request)) != identity:
                        return _failure(reply, 'terminal-generation-changed', 'The private terminal process changed during attachment.')
            reply['attachment'] = 'reused' if reuse else 'new' if identity is not None else 'standalone'

            if identity is not None and _timed(reply, 'verify_ms', lambda: self._owned(request)) != identity:
                return _failure(reply, 'terminal-generation-changed', 'The private terminal process changed before login.')

            # Cached account_info NEVER replaces a fresh login, even for the same account.
            reply['phase'] = 'login'
            if not _timed(reply, 'login_ms', lambda: self.api.login(login, password=request['password'], server=request['server'], timeout=timeout)):
                error = self.api.last_error()
                rejected = bool(error and isinstance(error[0], int) and error[0] == -6)
                return _failure(reply, 'login-rejected' if rejected else 'login-unconfirmed',
                                'Account/password rejected.' if rejected else 'Broker connection was not confirmed.', rejected)

            reply['phase'] = 'verify'
            def verify():
                return self.api.account_info(), self.api.terminal_info(), self._owned(request) if identity is not None else None
            account, terminal, current_identity = _timed(reply, 'verify_ms', verify)
            if identity is not None and current_identity != identity:
                return _failure(reply, 'terminal-generation-changed', 'The private terminal process changed during login.')
            if identity is not None and not self._portable_terminal(terminal, identity):
                return _failure(reply, 'terminal-path-mismatch', 'The attached terminal path or portable data path did not match the request.')
            if not account or not terminal or not terminal.connected:
                return _failure(reply, 'terminal-disconnected', 'The connected account or server did not match the request.')
            if (int(account.login) != login
                    or str(account.server).strip().casefold() != request['server'].strip().casefold()):
                return _failure(reply, 'account-server-mismatch', 'The connected account or server did not match the request.')
            reply.update(state='connected', reason='Fresh login acknowledged by MetaTrader IPC.', phase='verified', error_code='')
            if identity is not None:
                reply.update(terminal_pid=identity[1], terminal_started=str(identity[2]))
                retain = True
            return reply
        except KeyboardInterrupt:
            reply['phase'] = 'cancelled'
            return _failure(reply, 'cancelled', 'The IPC check was cancelled.')
        except Exception:
            return _failure(reply, 'ipc-exception', 'MetaTrader IPC check could not be completed.')
        finally:
            if not retain:
                self.close()


def check(request, api):
    """Backward-compatible one-shot check, always detached when complete."""
    return Session(api).check(request)


def serve(input_stream, output_stream, api=None, persistent=False, process_reader=None):
    if api is None:
        try:
            import MetaTrader5 as api
        except Exception:
            api = None
    session = Session(api, process_reader) if api is not None else None
    try:
        for raw in input_stream:
            try:
                request = json.loads(raw)
            except (ValueError, TypeError):
                if session is not None:
                    session.close()
                response = _failure(_reply({}), 'invalid-request', 'The IPC request was invalid.')
            else:
                if session is None:
                    response = _reply(request)
                    response.update(state='unavailable', error_code='runtime-unavailable', reason='The bundled Windows 64-bit MetaTrader IPC runtime could not load.')
                else:
                    response = session.check(request, persistent=persistent)
            print(json.dumps(response), file=output_stream, flush=True)
            if not persistent:
                break
    finally:
        if session is not None:
            session.close()


def main():
    serve(sys.stdin, sys.stdout, persistent='--serve' in sys.argv[1:])


if __name__ == '__main__':
    main()
