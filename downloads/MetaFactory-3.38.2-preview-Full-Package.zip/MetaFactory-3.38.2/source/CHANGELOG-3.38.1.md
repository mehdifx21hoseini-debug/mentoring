# MetaFactory 3.38.1 preview — prevent premature reporting stop

Fixes a 3.38.0 scheduler regression observed in a 39-account MT5 run: two accounts produced fresh reports, then the queue stopped with 37 accounts unattempted after approximately 36 seconds. The speculative second worker's entire wait behind an active reader was counted as a resource timeout. A stale CPU-pressure reason survived resource recovery and triggered shutdown between completed reports.

Resource shutdown now requires a continuous 30-second period with no active report leases and freshly sampled pressure preventing even the first worker from running. Active work, a new admission, or recovered resources resets that period. The stop decision is latched under the admission lock so a competing worker cannot claim a new account after that decision. Recovered resources clear the previous CPU/RAM pause reason.

Regression checks replay the observed wait/recovery sequence, verify continued serial admission, test discontinuous versus sustained pressure, and prevent admission racing with shutdown. MT4/MT5 report scripts, report calculations, login validation, and adaptive concurrency thresholds are unchanged from 3.38.0. This fix addresses the recorded reporting stop; the uploaded archive does not establish an application-process crash.

Validation: 1696 C# checks passed, including 14 new checks; assembly/PE versions, installer payload and embedded probes verified. One legacy chart retry check was skipped because the Mono container lacks python3. UI and Python code are unchanged in this patch. Live Windows/broker testing remains to be performed on the target computer.
