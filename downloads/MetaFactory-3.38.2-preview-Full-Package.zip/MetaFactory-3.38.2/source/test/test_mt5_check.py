import importlib.util
from pathlib import Path
from types import SimpleNamespace
import unittest
import io
import json

spec = importlib.util.spec_from_file_location('probe', Path(__file__).parents[1] / 'bridge/mt5_check.py')
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


class Api:
    def __init__(self):
        self.ok_init = True
        self.ok_login = True
        self.error = (-10005, 'do not expose passwords')
        self.account = SimpleNamespace(login=12345, server='WMMarkets-Demo')
        self.terminal = SimpleNamespace(connected=True)
        self.closed = False
        self.calls = []

    def initialize(self, path, **kwargs):
        self.calls.append(('initialize', path, kwargs))
        return self.ok_init

    def login(self, number, **kwargs):
        self.calls.append(('login', number, kwargs))
        return self.ok_login

    def last_error(self):
        return self.error

    def account_info(self):
        return self.account

    def terminal_info(self):
        return self.terminal

    def shutdown(self):
        self.closed = True


class ProbeTests(unittest.TestCase):
    def setUp(self):
        self.api = Api()
        self.request = dict(token='a' * 32, login='12345', server='WMMarkets-Demo', password='Sensitive!sentinel', terminal='C:/private/terminal64.exe', timeout=15000)

    def run_probe(self):
        reply = probe.check(self.request, self.api)
        self.assertTrue(self.api.closed)
        self.assertNotIn(self.request['password'], str(reply))
        return reply

    def test_success_requires_fresh_ack(self):
        self.assertEqual('connected', self.run_probe()['state'])
        self.assertEqual('login', self.api.calls[1][0])
        self.assertEqual(self.request['token'], self.run_probe()['token'])

    def test_cached_account_does_not_override_rejection(self):
        self.api.ok_login = False
        self.api.error = (-6, self.request['password'])
        self.assertEqual('rejected', self.run_probe()['state'])

    def test_ipc_failure_not_bad_password(self):
        self.api.ok_login = False
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_wrong_account(self):
        self.api.account.login = 99
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_wrong_server(self):
        self.api.account.server = 'Other'
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_disconnected(self):
        self.api.terminal.connected = False
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_unavailable_account(self):
        self.api.account = None
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_failed_initialize(self):
        self.api.ok_init = False
        self.assertEqual('unconfirmed', self.run_probe()['state'])
        self.assertEqual(1, len(self.api.calls))

    def test_exception_does_not_leak_password(self):
        def failing(*a, **kw):
            raise RuntimeError(self.request['password'])
        self.api.login = failing
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_persistent_service_requires_ack_for_each_account(self):
        class SwitchingApi(Api):
            def login(self, number, **kwargs):
                self.calls.append(('login', number, kwargs))
                if kwargs['password'] == 'bad':
                    self.error = (-6, 'rejected')
                    return False
                self.account = SimpleNamespace(login=number, server=kwargs['server'])
                return True
        api = SwitchingApi()
        requests = [dict(self.request, login=str(n), token=str(n) * 32, password=p)
                    for n, p in [(1, 'good'), (2, 'bad'), (3, 'good')]]
        output = io.StringIO()
        probe.serve(io.StringIO(''.join(json.dumps(r) + '\n' for r in requests)), output, api, persistent=True)
        responses = [json.loads(line) for line in output.getvalue().splitlines()]
        self.assertEqual(['connected', 'rejected', 'connected'], [r['state'] for r in responses])
        self.assertEqual([r['token'] for r in requests], [r['token'] for r in responses])
        self.assertEqual(3, len([c for c in api.calls if c[0] == 'login']))
        self.assertNotIn('Sensitive!sentinel', output.getvalue())

    def test_single_request_mode_remains_compatible(self):
        raw = json.dumps(self.request) + '\n'
        output = io.StringIO()
        probe.serve(io.StringIO(raw + raw), output, self.api)
        self.assertEqual(1, len(output.getvalue().splitlines()))


class OwnedApi(Api):
    def __init__(self):
        super().__init__()
        self.shutdowns = 0
        self.terminal.path = 'C:/private'
        self.terminal.data_path = 'C:/private'
        self.after_login = None

    def login(self, number, **kwargs):
        answer = super().login(number, **kwargs)
        if answer:
            self.account = SimpleNamespace(login=number, server=kwargs['server'])
        if self.after_login:
            self.after_login()
        return answer

    def shutdown(self):
        super().shutdown()
        self.shutdowns += 1


class OwnedSessionTests(unittest.TestCase):
    def setUp(self):
        self.api = OwnedApi()
        self.processes = {42: (134076123456789012, 'C:/private/terminal64.exe')}
        self.request = dict(token='a' * 32, login='12345', server='WMMarkets-Demo',
                            password='Sensitive!sentinel', terminal='C:/private/terminal64.exe',
                            timeout=15000, terminal_pid=42, terminal_started='134076123456789012')
        self.session = probe.Session(self.api, self.processes.get)
        self.addCleanup(self.session.close)

    def call(self, **changes):
        answer = self.session.check(dict(self.request, **changes), persistent=True)
        self.assertNotIn(self.request['password'], json.dumps(answer))
        for field in ('init_ms', 'login_ms', 'verify_ms'):
            self.assertIsInstance(answer[field], int)
            self.assertGreaterEqual(answer[field], 0)
        return answer

    def count(self, method):
        return sum(c[0] == method for c in self.api.calls)

    def test_service_reuses_attachment_but_acknowledges_every_account(self):
        requests = [self.request, dict(self.request, login='67890', token='b' * 32)]
        output = io.StringIO()
        probe.serve(io.StringIO(''.join(json.dumps(r) + '\n' for r in requests)), output,
                    self.api, persistent=True, process_reader=self.processes.get)
        responses = [json.loads(line) for line in output.getvalue().splitlines()]
        self.assertEqual(['connected', 'connected'], [r['state'] for r in responses])
        self.assertEqual(['new', 'reused'], [r['attachment'] for r in responses])
        self.assertEqual([r['token'] for r in requests], [r['token'] for r in responses])
        self.assertEqual(['12345', '67890'], [r['login'] for r in responses])
        self.assertEqual([42, 42], [r['terminal_pid'] for r in responses])
        self.assertEqual([self.request['terminal_started']] * 2, [r['terminal_started'] for r in responses])
        self.assertEqual(1, self.count('initialize'))
        self.assertEqual(2, self.count('login'))
        self.assertEqual(1, self.api.shutdowns)  # EOF detaches a retained session.
        self.assertNotIn(self.request['password'], output.getvalue())

    def test_same_account_still_requires_second_login(self):
        self.assertEqual('connected', self.call()['state'])
        second = self.call(token='b' * 32)
        self.assertEqual('reused', second['attachment'])
        self.assertEqual('b' * 32, second['token'])
        self.assertEqual(2, self.count('login'))
        self.assertEqual(0, self.api.shutdowns)

    def test_changed_generation_detaches_and_reinitializes(self):
        self.call()
        self.processes[42] = (134076123456789013, self.request['terminal'])
        answer = self.call(terminal_started='134076123456789013', token='b' * 32)
        self.assertEqual('connected', answer['state'])
        self.assertEqual('new', answer['attachment'])
        self.assertEqual(2, self.count('initialize'))
        self.assertEqual(1, self.api.shutdowns)

    def test_changed_pid_and_path_attach_only_new_owned_terminal(self):
        self.call()
        self.processes[43] = (134076123456789014, 'D:/other/terminal64.exe')
        self.api.terminal.path = self.api.terminal.data_path = 'D:/other'
        answer = self.call(terminal='D:/other/terminal64.exe', terminal_pid=43,
                           terminal_started='134076123456789014', token='b' * 32)
        self.assertEqual('connected', answer['state'])
        self.assertEqual(43, answer['terminal_pid'])
        self.assertEqual(2, self.count('initialize'))
        self.assertEqual(1, self.api.shutdowns)

    def test_invalid_ownership_never_launches_or_logs_in(self):
        variants = [dict(terminal_pid=99), dict(terminal_started='1'), dict(terminal='D:/wrong.exe'),
                    dict(terminal_pid=True), dict(terminal_started=134076123456789012.0),
                    dict(terminal_started='nonsense')]
        for change in variants:
            with self.subTest(change=change):
                answer = self.call(**change)
                self.assertEqual('owned-terminal-unverified', answer['error_code'])
                self.assertEqual('unconfirmed', answer['state'])
        self.assertEqual([], self.api.calls)
        missing = dict(self.request)
        del missing['terminal_started']
        self.assertEqual('owned-terminal-unverified', self.session.check(missing, persistent=True)['error_code'])

    def test_dead_process_detaches_existing_session(self):
        self.call()
        self.processes.clear()
        self.assertEqual('owned-terminal-unverified', self.call()['error_code'])
        self.assertEqual(1, self.count('initialize'))
        self.assertEqual(1, self.count('login'))
        self.assertEqual(1, self.api.shutdowns)

    def test_generation_change_during_initialize_prevents_login(self):
        initialize = self.api.initialize
        def changed(*args, **kwargs):
            result = initialize(*args, **kwargs)
            self.processes.clear()
            return result
        self.api.initialize = changed
        self.assertEqual('terminal-generation-changed', self.call()['error_code'])
        self.assertEqual(0, self.count('login'))
        self.assertEqual(1, self.api.shutdowns)

    def test_generation_change_during_login_cannot_return_success(self):
        self.api.after_login = self.processes.clear
        self.assertEqual('terminal-generation-changed', self.call()['error_code'])
        self.assertEqual(1, self.api.shutdowns)

    def test_nonportable_or_wrong_terminal_path_prevents_credentials(self):
        for field in ('path', 'data_path'):
            with self.subTest(field=field):
                original = getattr(self.api.terminal, field)
                setattr(self.api.terminal, field, 'C:/unrelated')
                self.assertEqual('terminal-path-mismatch', self.call()['error_code'])
                self.assertEqual(0, self.count('login'))
                setattr(self.api.terminal, field, original)

    def test_path_change_after_login_cannot_return_success(self):
        self.api.after_login = lambda: setattr(self.api.terminal, 'data_path', 'C:/unrelated')
        self.assertEqual('terminal-path-mismatch', self.call()['error_code'])
        self.assertEqual(1, self.api.shutdowns)

    def test_disconnected_attachment_reinitializes_then_requires_fresh_login(self):
        self.call()
        self.api.terminal.connected = False
        self.api.after_login = lambda: setattr(self.api.terminal, 'connected', True)
        self.assertEqual('connected', self.call(token='b' * 32)['state'])
        self.assertEqual(2, self.count('initialize'))
        self.assertEqual(2, self.count('login'))

    def test_rejected_login_detaches_and_does_not_accept_cached_account(self):
        self.call()
        self.api.ok_login = False
        self.api.error = (-6, self.request['password'])
        answer = self.call(token='b' * 32)
        self.assertEqual('rejected', answer['state'])
        self.assertEqual('login-rejected', answer['error_code'])
        self.assertEqual('login', answer['phase'])
        self.assertEqual(1, self.api.shutdowns)
        self.api.ok_login = True
        self.assertEqual('new', self.call(token='c' * 32)['attachment'])
        self.assertEqual(2, self.count('initialize'))

    def test_verified_account_and_server_must_match_current_request(self):
        for field, value in (('login', 98), ('server', 'Other')):
            with self.subTest(field=field):
                self.api.after_login = lambda: setattr(self.api.account, field, value)
                answer = self.call(token='b' * 32)
                self.assertEqual('account-server-mismatch', answer['error_code'])
                self.assertEqual('b' * 32, answer['token'])
                self.assertFalse(self.session.attached)

    def test_invalid_token_detaches_and_does_not_reuse_old_reply(self):
        self.call()
        for token in ('', 'previous-request', 'z' * 32, None):
            answer = self.call(token=token)
            self.assertEqual('invalid-request-token', answer['error_code'])
            self.assertEqual(token, answer['token'])
        self.assertEqual(1, self.count('login'))
        self.assertEqual(1, self.api.shutdowns)

    def test_cancellation_detaches_and_next_request_reattaches(self):
        self.call()
        self.assertEqual('cancelled', self.call(cancelled=True)['error_code'])
        self.assertEqual(1, self.api.shutdowns)
        self.assertEqual('new', self.call(token='b' * 32)['attachment'])

    def test_keyboard_interrupt_and_exception_detach_without_secret_details(self):
        for exception in (KeyboardInterrupt(self.request['password']), RuntimeError(self.request['password'])):
            with self.subTest(exception=type(exception).__name__):
                def failing(*args, **kwargs):
                    raise exception
                self.api.login = failing
                answer = self.call()
                self.assertIn(answer['error_code'], ('cancelled', 'ipc-exception'))
                self.assertFalse(self.session.attached)

    def test_legacy_service_requests_remain_one_shot(self):
        request = dict(self.request)
        del request['terminal_pid'], request['terminal_started']
        for _ in range(2):
            answer = self.session.check(request, persistent=True)
            self.assertEqual('connected', answer['state'])
            self.assertEqual('standalone', answer['attachment'])
        self.assertEqual(2, self.count('initialize'))
        self.assertEqual(2, self.api.shutdowns)

    def test_malformed_json_detaches_and_does_not_echo_input(self):
        output = io.StringIO()
        raw = json.dumps(self.request) + '\nSensitive!sentinel {broken\n' + json.dumps(self.request) + '\n'
        probe.serve(io.StringIO(raw), output, self.api, persistent=True, process_reader=self.processes.get)
        responses = [json.loads(line) for line in output.getvalue().splitlines()]
        self.assertEqual(['connected', 'unconfirmed', 'connected'], [r['state'] for r in responses])
        self.assertEqual('invalid-request', responses[1]['error_code'])
        self.assertEqual(2, self.count('initialize'))
        self.assertEqual(2, self.api.shutdowns)
        self.assertNotIn('Sensitive!sentinel', output.getvalue())

    def test_broken_response_pipe_detaches_retained_attachment(self):
        class BrokenOutput:
            def write(self, text):
                raise BrokenPipeError('pipe closed')
        with self.assertRaises(BrokenPipeError):
            probe.serve(io.StringIO(json.dumps(self.request) + '\n'), BrokenOutput(),
                        self.api, persistent=True, process_reader=self.processes.get)
        self.assertEqual(1, self.api.shutdowns)

    def test_process_reader_failure_detaches_without_leaking_details(self):
        self.call()
        def unavailable(pid):
            raise OSError(self.request['password'])
        self.session.process_reader = unavailable
        self.assertEqual('ipc-exception', self.call()['error_code'])
        self.assertEqual(1, self.api.shutdowns)
        self.assertEqual(1, self.count('login'))


if __name__ == '__main__':
    unittest.main()
