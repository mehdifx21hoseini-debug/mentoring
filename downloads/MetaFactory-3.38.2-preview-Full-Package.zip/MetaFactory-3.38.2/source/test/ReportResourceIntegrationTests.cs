using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Web.Script.Serialization;
using System.Collections.Generic;

namespace MTManager
{
    static partial class Tests
    {
        static void ReportResourceIntegrationChecks()
        {
            var a = new Account { Login = "1234", Server = "Test-Demo", VerifyToken = new string('a', 32) };
            var serializer = new JavaScriptSerializer();
            var reply = new Dictionary<string, object> { { "token", a.VerifyToken }, { "login", a.Login }, { "server", a.Server }, { "state", "connected" }, { "terminal_pid", 123 }, { "terminal_started", "456" } };
            Check(DirectProbe.OwnedPythonReply(serializer.Serialize(reply), a, 123, 456).Connected, "owned IPC accepts fresh account and exact terminal generation proof");
            Check(DirectProbe.OwnedPythonReply(serializer.Serialize(reply), a, 123, 457) == null, "owned IPC rejects a reused terminal process generation");
            Check(DirectProbe.OwnedPythonReply(serializer.Serialize(reply), a, 124, 456) == null, "owned IPC rejects another terminal process");
            reply.Remove("terminal_started");
            Check(DirectProbe.OwnedPythonReply(serializer.Serialize(reply), a, 123, 456) == null, "connected IPC reply without process proof cannot become success");
            reply["state"] = "rejected";
            Check(DirectProbe.OwnedPythonReply(serializer.Serialize(reply), a, 123, 456).State == Login.WrongLogin, "nonce-matched explicit rejection remains distinguishable from connection timeout");
            reply["token"] = new string('b', 32);
            Check(DirectProbe.OwnedPythonReply(serializer.Serialize(reply), a, 123, 456) == null, "stale rejection cannot be attached to a different account request");
            var observation = ReportIpcObservation.Parse("{\"phase\":\"initialize\",\"error_code\":\"initialize-failed\",\"attachment\":\"new\",\"init_ms\":125,\"login_ms\":-99,\"verify_ms\":9999999}");
            Equal("init", observation.Phase, "IPC initialization failure is represented in the correct diagnostic phase");
            Equal("initialize-failed", observation.ErrorCode, "IPC stable failure code survives C# decoding");
            Check(observation.InitMs == 125 && observation.LoginMs == 0 && observation.VerifyMs == 120000, "IPC timing metadata is bounded and cannot contain negative durations");
            observation = ReportIpcObservation.Parse("{\"phase\":\"Password123\",\"error_code\":\"Password123\",\"attachment\":\"Password123\"}");
            Check(observation.Phase == "unknown" && observation.ErrorCode == "" && observation.Attachment == "", "arbitrary helper payload does not become phase/error diagnostics");
            var budget = new ReportStartBudget();
            var native = budget.TryAcquireExtra(() => 8075, () => 2200, 512, 256);
            Check(native != null, "native bundle receives its resource reservation");
            var helper = budget.TryAcquireExtra(() => 8075, () => 2200, 256, 256);
            Check(helper != null && budget.PendingGrowthMb == 768, "new Python helper startup growth is covered in addition to the native reservation");
            Check(budget.TryAcquireExtra(() => 8075, () => 2200, 512, 256) == null, "parallel startup cannot spend RAM already promised to helper and native");
            helper.Dispose(); native.Dispose(); Equal(0UL, budget.PendingGrowthMb, "failed helper launch releases temporary growth reservations");
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("mt5-runtime.zip"))
            using (var zip = new ZipArchive(stream, ZipArchiveMode.Read))
            using (var reader = new StreamReader(zip.GetEntry("mt5_check.py").Open()))
            {
                string bundled = reader.ReadToEnd();
                Check(bundled == File.ReadAllText("bridge/mt5_check.py"), "installed runtime contains the tested persistent IPC helper source");
                Check(DirectProbe.RuntimeTag.EndsWith("probe3"), "new helper installs in a new versioned runtime instead of reusing old ready marker");
            }
        }
    }
}
