"""Run the actual MQL WaitForHistory body in a deterministic native API stub.

This validates its control flow and bounds, not MetaEditor compilation or broker IO.
"""
import pathlib
import shutil
import subprocess
import tempfile
import unittest


@unittest.skipUnless(shutil.which("g++"), "g++ required for native history control-flow harness")
class HistoryReconnectTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        source = (pathlib.Path(__file__).resolve().parents[1] / "report/MTManagerReport.mq5").read_text()
        start = source.index("bool WaitForHistory()")
        opening = source.index("{", start)
        depth = 1
        end = opening + 1
        while depth:
            depth += (source[end] == "{") - (source[end] == "}")
            end += 1
        body = source[start:end]
        cls.temp = tempfile.TemporaryDirectory()
        folder = pathlib.Path(cls.temp.name)
        cls.binary = folder / "history"
        stub = r'''
#include <string>
#include <iostream>
#include <cmath>
#include <cstdlib>
using uint = unsigned int;
using string = std::string;
uint nowMs = 0;
int scenario, selects = 0, dealCount = 309, historyError = 0;
double sumAll = 309;
string historyFailure;
const int TERMINAL_CONNECTED = 1, ACCOUNT_LOGIN = 2, ACCOUNT_BALANCE = 3;
uint GetTickCount() { return nowMs; }
void Sleep(int n) { nowMs += n; }
bool IsStopped() { return scenario == 5 && nowMs >= 2000; }
bool ExpectedAccount() { return !(scenario == 3 && nowMs >= 1500); }
long AccountInfoInteger(int) { return 12345; }
double AccountInfoDouble(int) { return 309; }
bool TerminalInfoInteger(int) {
 if(scenario == 1 || scenario == 5) return nowMs < 1500 || nowMs >= 3500;
 if(scenario == 2) return nowMs < 1500;
 if(scenario == 4) return nowMs % 2000 < 1000;
 return true;
}
void Pulse(string) {}
void Step(string) {}
double MathAbs(double x) { return std::abs(x); }
string IntegerToString(int x) { return std::to_string(x); }
bool AddsUp() { return true; }
bool AddUp() { ++selects; dealCount = nowMs < 3500 ? 309 : 310; sumAll = dealCount; return true; }
'''
        main = r'''
int main(int argc, char** argv) {
 scenario = std::atoi(argv[1]);
 bool result = WaitForHistory();
 std::cout << result << "|" << nowMs << "|" << selects << "|" << dealCount << "|" << historyFailure;
}
'''
        cpp = folder / "history.cpp"
        cpp.write_text(stub + body + main)
        subprocess.run(["g++", "-std=c++11", str(cpp), "-o", str(cls.binary)], check=True, capture_output=True)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def run_scenario(self, n):
        result = subprocess.run([str(self.binary), str(n)], check=True, capture_output=True, text=True, timeout=5)
        success, elapsed, selections, deals, failure = result.stdout.split("|", 4)
        return int(success), int(elapsed), int(selections), int(deals), failure

    def test_healthy_history_no_added_delay(self):
        ok, elapsed, _, deals, _ = self.run_scenario(0)
        self.assertEqual((ok, elapsed, deals), (1, 3000, 309))

    def test_brief_disconnect_reselects_and_restarts_stability(self):
        ok, elapsed, selections, deals, _ = self.run_scenario(1)
        self.assertEqual(ok, 1)
        self.assertGreaterEqual(elapsed, 5500)
        self.assertLessEqual(elapsed, 6500)
        self.assertGreater(selections, 3)
        self.assertEqual(deals, 310)  # Recovered history, never the pre-disconnect snapshot.

    def test_persistent_disconnect_fails_at_bounded_grace(self):
        ok, elapsed, _, _, failure = self.run_scenario(2)
        self.assertEqual((ok, elapsed, failure), (0, 9500, "history connection lost"))

    def test_account_change_does_not_receive_network_grace(self):
        ok, elapsed, _, _, failure = self.run_scenario(3)
        self.assertEqual((ok, elapsed, failure), (0, 1500, "history connection lost"))

    def test_repeated_disconnects_cannot_extend_total_budget(self):
        ok, elapsed, _, _, _ = self.run_scenario(4)
        self.assertEqual((ok, elapsed), (0, 90000))

    def test_stop_during_reconnect_never_publishes_success(self):
        ok, elapsed, _, _, _ = self.run_scenario(5)
        self.assertEqual((ok, elapsed), (0, 2000))
