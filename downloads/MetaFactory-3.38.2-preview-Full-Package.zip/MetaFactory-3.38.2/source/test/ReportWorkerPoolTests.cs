using System;
using System.Diagnostics;
using System.Threading;

namespace MTManager
{
    static partial class Tests
    {
        static void ReportWorkerPoolChecks()
        {
            var terminal = new ReportProcessMemory { Known = true, Alive = true, CurrentMb = 300, PeakMb = 500 };
            var helper = new ReportProcessMemory { Known = true, Alive = true, CurrentMb = 80, PeakMb = 150 };
            var bundle = ReportBundleMemory.Combine(terminal, helper);
            Check(bundle.Known && bundle.CurrentMb == 380 && bundle.PeakMb == 650 && bundle.LiveProcesses == 2,
                "owned terminal and Python helper both contribute current memory and conservative peak bound");
            bundle = ReportBundleMemory.Combine(ReportProcessMemory.Absent(), helper);
            Check(bundle.Known && bundle.CurrentMb == 80 && bundle.LiveProcesses == 1, "remaining helper memory is retained after native terminal exit");
            bundle = ReportBundleMemory.Combine(terminal, ReportProcessMemory.Unknown());
            Check(!bundle.Known && bundle.CurrentMb == 300, "unknown helper usage cannot be reported as a completely measured zero-cost bundle");
            Check(!new ReportProcessIdentity(0, 0).Sample().Known, "missing process generation remains unknown rather than free memory");
            using (Process current = Process.GetCurrentProcess())
            {
                var identity = ReportProcessIdentity.Capture(current);
                Check(identity != null && identity.Pid == current.Id, "owned process identity captures its PID");
                if (identity.StartedUtcTicks > 0)
                    Check(!new ReportProcessIdentity(identity.Pid, identity.StartedUtcTicks + 1).Sample().Alive,
                        "recycled PID generation cannot be mistaken for the owned process");
            }

            var pool = new ReportWorkerPool(); int closes = 0;
            var lease = pool.BeginJob(1, () => false);
            pool.Retain(1, () => ReportBundleMemory.Combine(terminal, helper), () => { closes++; return true; });
            Check(!pool.TryReclaimOne() && closes == 0 && pool.TryBeginJob(1) == null,
                "busy account lease excludes both eviction and another owner");
            Check(pool.SnapshotBySlot()[1].CurrentMb == 380, "busy warm bundle remains measurable while its account is being read");
            lease.Dispose(); lease.Dispose();
            Check(!pool.TryReclaimOne(1) && closes == 0, "reclaimer respects the excluded slot");
            Check(pool.TryReclaimOne() && closes == 1 && pool.SnapshotBySlot().Count == 0,
                "idle bundle is removed only after confirmed closure");

            bool canClose = false;
            using (pool.BeginJob(1, () => false))
                pool.Retain(1, () => ReportBundleMemory.Combine(terminal), () => canClose);
            Check(!pool.ReleaseIdle(1) && pool.SnapshotBySlot().ContainsKey(1), "failed close cannot erase a resident bundle's accounting");
            canClose = true;
            Check(pool.ReleaseIdle(1), "previously failed idle close can be retried");
            using (pool.BeginJob(1, () => false))
                pool.Retain(1, () => { throw new InvalidOperationException(); }, () => { throw new InvalidOperationException(); });
            Check(!pool.Snapshot().Known && !pool.ReleaseIdle(1) && pool.SnapshotBySlot().ContainsKey(1),
                "sampling and close failures retain unknown resident ownership conservatively");
            using (pool.BeginJob(1, () => false)) pool.Forget(1);
            Check(pool.SnapshotBySlot().Count == 0, "busy owner can forget a bundle after its own verified cleanup");

            using (var closing = new ManualResetEvent(false))
            using (var finishClose = new ManualResetEvent(false))
            {
                using (pool.BeginJob(1, () => false))
                    pool.Retain(1, () => ReportBundleMemory.Combine(terminal), () => { closing.Set(); return finishClose.WaitOne(5000); });
                bool evicted = false;
                var reclaim = new Thread(() => { evicted = pool.ReleaseIdle(1); }) { IsBackground = true };
                reclaim.Start();
                Check(closing.WaitOne(2000), "idle reclamation starts its close callback");
                Check(pool.TryBeginJob(1) == null, "new account cannot enter a slot while eviction owns it");
                using (var other = pool.TryBeginJob(2)) Check(other != null, "slow close callback does not hold the pool lock or block unrelated slots");
                finishClose.Set();
                Check(reclaim.Join(2000) && evicted, "idle close finishes and releases ownership");
                using (var next = pool.TryBeginJob(1)) Check(next != null, "new account can acquire a successfully reclaimed slot");
            }

            using (pool.BeginJob(1, () => false)) pool.Retain(1, () => ReportBundleMemory.Combine(terminal), () => true);
            using (pool.BeginJob(2, () => false)) pool.Retain(2, () => ReportBundleMemory.Combine(helper), () => true);
            Check(pool.ReleaseAllIdle() == 2 && pool.Snapshot().CurrentMb == 0, "worker/batch shutdown releases all idle terminal/helper bundles promptly");

            long elapsed = 0; int waiting = 0; bool capacity = false;
            bool admitted = ReportWorkerPool.WaitForCapacity(() => capacity, () => { capacity = true; return true; }, () => false,
                1000, () => waiting++, () => elapsed, ms => elapsed += ms);
            Check(admitted && elapsed == 0, "idle reclamation can satisfy admission without delaying or consuming an account attempt");
            elapsed = 0;
            admitted = ReportWorkerPool.WaitForCapacity(() => false, () => false, () => false,
                350, () => waiting++, () => elapsed, ms => elapsed += ms);
            Check(!admitted && elapsed == 350 && waiting == 1, "persistent resource pressure returns a bounded capacity pause rather than infinite wait");
            elapsed = 0; bool cancelled = false;
            try { ReportWorkerPool.WaitForCapacity(() => false, () => false, () => elapsed >= 100,
                1000, null, () => elapsed, ms => elapsed += ms); }
            catch (OperationCanceledException) { cancelled = true; }
            Check(cancelled && elapsed == 100, "resource pause responds to cancellation before starting an account");
            using (pool.BeginJob(1, () => false))
            {
                cancelled = false;
                try { pool.BeginJob(1, () => true); } catch (OperationCanceledException) { cancelled = true; }
                Check(cancelled, "busy-slot lease wait is cancellable");
            }
        }
    }
}
