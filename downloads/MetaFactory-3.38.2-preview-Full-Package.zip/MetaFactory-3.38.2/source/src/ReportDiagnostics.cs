using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MTManager
{
    /// <summary>Bounded evidence for one reporting run. Never copies settings, credentials or report/trade payloads.</summary>
    public sealed class ReportDiagnostics
    {
        const int MaxLineChars = 1600, MaxNativeBytes = 32768, MaxTailBytes = 65536, KeepRuns = 5;
        internal const long MaxRunBytes = 16 * 1024 * 1024;
        static readonly object gate = new object();
        static readonly Regex RunName = new Regex(@"^run-[0-9]{8}T[0-9]{9}-[a-f0-9]{32}$");
        static readonly Regex NativeName = new Regex(@"^native-[0-9]{5}-[0-9]{5}-[0-9]{2}\.txt$");
        static readonly Regex CredentialAssignment = new Regex(@"(?i)\b(password|passwd|investorpassword|masterpassword|authorization|access[_-]?token|refresh[_-]?token)\s*[:=]\s*[^\r\n]+", RegexOptions.CultureInvariant);
        static ReportDiagnostics latestActive;
        readonly List<string> secrets = new List<string>();
        readonly Stopwatch clock = Stopwatch.StartNew();
        readonly string directory;
        readonly Dictionary<string, long> fileBytes = new Dictionary<string, long>();
        readonly Dictionary<string, AttemptInfo> attempts = new Dictionary<string, AttemptInfo>();
        readonly Dictionary<int, string> requested = new Dictionary<int, string>();
        readonly Dictionary<string, long> runPhases = new Dictionary<string, long>();
        readonly Dictionary<string, CapacityInfo> capacities = new Dictionary<string, CapacityInfo>();
        readonly Dictionary<string, IpcInfo> ipcResults = new Dictionary<string, IpcInfo>();
        readonly int workers;
        int captureId;
        long usedBytes;
        bool truncated, finished;
        public string DirectoryPath { get { return directory; } }
        static string Root { get { return Path.Combine(AppPaths.DataDir, "report-diagnostics"); } }

        sealed class AttemptInfo
        {
            public int Index, Pass;
            public string Name, Copy, Platform, State = "pending", Code = "", Route = "";
            public bool Begun, HasResult;
            public long TotalMs, ReadMs;
            public readonly Dictionary<string, long> Phases = new Dictionary<string, long>();
            public readonly Dictionary<string, int> PhaseCounts = new Dictionary<string, int>();
            public readonly HashSet<string> Evidence = new HashSet<string>();
        }
        sealed class CapacityInfo
        {
            public int Samples, UnknownMemory, LastActive, MaxActive, LastCeiling, LastKnownWorker, CpuSamples;
            public ulong LastCurrent, LastTerminal, LastHelper, MaxCurrent, MaxPeak, MinFree = ulong.MaxValue, MaxFree;
            public double MaxCpu = -1, CpuTotal;
            public readonly HashSet<int> Workers = new HashSet<int>();
            public readonly Dictionary<string, int> Actions = new Dictionary<string, int>();
        }
        sealed class IpcInfo
        {
            public int Count, Success, Failed, Unknown;
            public readonly Dictionary<string, int> Errors = new Dictionary<string, int>();
            public readonly Dictionary<string, int> Attachments = new Dictionary<string, int>();
        }
        AttemptInfo Attempt(ReportJob job)
        {
            string key = job.Index + ":" + job.Attempt;
            AttemptInfo value;
            if (!attempts.TryGetValue(key, out value))
            {
                value = new AttemptInfo { Index = job.Index, Pass = job.Attempt, Name = Cell(job.Name), Copy = Cell(job.Copy.Name), Platform = job.Copy.Kind.ToString() };
                attempts.Add(key, value);
            }
            return value;
        }

        public ReportDiagnostics(IEnumerable<ReportJob> jobs, int parallel)
        {
            try
            {
                var list = (jobs ?? Enumerable.Empty<ReportJob>()).ToList();
                workers = parallel;
                foreach (var job in list) requested[job.Index] = job.Copy.Kind.ToString();
                foreach (var job in list)
                {
                    if (job.Account == null) continue;
                    foreach (string value in new[] { Secret.Unprotect(job.Account.MasterEnc), Secret.Unprotect(job.Account.InvestorEnc) })
                        if (!string.IsNullOrEmpty(value) && !secrets.Contains(value)) secrets.Add(value);
                }
                secrets.Sort((a, b) => b.Length.CompareTo(a.Length));
                directory = Path.Combine(Root, "run-" + DateTime.UtcNow.ToString("yyyyMMdd'T'HHmmssfff", CultureInfo.InvariantCulture) + "-" + Guid.NewGuid().ToString("N"));
                lock (gate)
                {
                    Directory.CreateDirectory(directory);
                    latestActive = this;
                    Write("manifest.txt", "MetaFactory report diagnostics\nVersion: " + AppInfo.Version + "\nStarted UTC: " + DateTime.UtcNow.ToString("o") +
                        "\nRequested students: " + list.Count + "\nWorkers: " + parallel + "\nCPU threads: " + Environment.ProcessorCount + "\nTotal RAM MB: " + Checks.TotalRamMb() +
                        "\nOS: " + Environment.OSVersion + "\n\nA past success/cache timestamp is historical evidence, not proof of a fresh report.\n" +
                        "Resource observations: capacity.tsv records per-platform worker bundle memory (terminal + IPC helper), admission/promotion/rollback/reclaim decisions.\n" +
                        "Bundle peak is the conservative sum of individual process peaks, not a measured simultaneous peak. Zero/unknown CPU samples do not prove spare capacity.\n" +
                        "Journal/Experts snapshots are bounded tails for the current attempt. Missing lines are not proof that an event never happened.\n" +
                        "The archive omits account configuration files, passwords and trade/report payloads. Account IDs, server names, student names and local paths may be present.\n" +
                        "Limits: last 5 runs, 16 MiB per run, 32 KiB per native snapshot. Some lines are omitted if these limits are reached.\n");
                    Write("events.tsv", "utc\trun_ms\tstudent_index\tpass\tstudent\tcopy\taccount\tserver\tplatform\tevent\tdetail\n");
                    Write("results.tsv", "utc\tstudent_index\tpass\tstudent\tcopy\taccount\tserver\tplatform\tresult\tcode\troute\tread_ms\ttotal_ms\tcache_exported\tdetail\n");
                    Write("timings.tsv", "utc\trun_ms\tstudent_index\tpass\tcopy\tplatform\tphase\tduration_ms\tdetail\n");
                    Write("evidence.tsv", "utc\tstudent_index\tpass\tcopy\tplatform\tcapture\troute\tobservation\tdetail\n");
                    Write("capacity.tsv", "utc\trun_ms\tplatform\taction\tworker\tactive\tceiling\tmemory_known\tterminal_current_mb\thelper_current_mb\tbundle_current_mb\tbundle_peak_sum_mb\tfree_mb\tcpu_percent\treason\n");
                    SaveSummary();
                    Prune();
                }
            }
            catch (Exception e) { Log.Write("report diagnostics initialization: " + e.GetType().Name); }
        }

        internal string Redact(string text)
        {
            string clean = text ?? "";
            foreach (string secret in secrets) clean = clean.Replace(secret, "[REDACTED]");
            return CredentialAssignment.Replace(clean, "$1=[REDACTED]");
        }
        string Cell(object value)
        {
            string text = Redact(Convert.ToString(value, CultureInfo.InvariantCulture) ?? "").Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ');
            return text.Length > MaxLineChars ? text.Substring(0, MaxLineChars) + " [truncated]" : text;
        }
        string Cells(params object[] values) { return string.Join("\t", values.Select(Cell)) + "\n"; }
        static string Utc { get { return DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture); } }
        bool Write(string file, string text, bool append = false)
        {
            if (directory == null) return false;
            string safe = Redact(text); long size = Encoding.UTF8.GetByteCount(safe);
            long oldSize; fileBytes.TryGetValue(file, out oldSize);
            long nextSize = usedBytes + size - (append ? 0 : oldSize);
            // Reserve room for the concise summary even if raw event evidence reaches its cap.
            if (nextSize > (file == "summary.txt" ? MaxRunBytes : MaxRunBytes - 262144))
            {
                if (!truncated)
                {
                    truncated = true;
                    File.AppendAllText(Path.Combine(directory, "manifest.txt"), "\nCapture limit reached; later evidence may be omitted.\n", Encoding.UTF8);
                }
                return false;
            }
            string path = Path.Combine(directory, file);
            if (append) File.AppendAllText(path, safe, Encoding.UTF8); else File.WriteAllText(path, safe, Encoding.UTF8);
            fileBytes[file] = append ? oldSize + size : size;
            usedBytes = nextSize; return true;
        }
        static int TerminalCount()
        {
            int n = 0;
            foreach (string name in new[] { "terminal", "terminal64" })
                try { foreach (var p in Process.GetProcessesByName(name)) { n++; p.Dispose(); } } catch { }
            return n;
        }
        public void BeginAttempt(ReportJob job, DateTime? previousSuccess = null)
        {
            try
            {
                lock (gate) { if (finished || job == null) return; Attempt(job).Begun = true; }
                Stage(job, "attempt.begin", "free_ram_mb=" + Checks.FreeRamMb() + "; terminals=" + TerminalCount() +
                    (previousSuccess.HasValue ? "; previous_success=" + previousSuccess.Value.ToString("o") + " (historical, not fresh)" : ""));
            }
            catch (Exception e) { Log.Write("report diagnostics attempt: " + e.GetType().Name); }
        }
        public void Stage(ReportJob job, string code, string detail)
        {
            try
            {
                lock (gate)
                {
                    if (finished || job == null) return;
                    if (code == "ipc-result") ObserveIpc(job.Copy.Kind.ToString(), detail);
                    Write("events.tsv", Cells(Utc, clock.ElapsedMilliseconds, job.Index, job.Attempt, job.Name, job.Copy.Name, job.Account.Login, job.Account.Server, job.Copy.Kind, code, detail), true);
                }
            }
            catch (Exception e) { Log.Write("report diagnostics event: " + e.GetType().Name); }
        }
        public void Result(ReportJob job, ReportRow row, string code = null)
        {
            try
            {
                lock (gate)
                {
                    if (finished || job == null || row == null) return;
                    bool deferred = row.Retryable && string.Equals(code, "mt4-connection-deferred", StringComparison.Ordinal) && (row.Journal == null || row.Cached);
                    string state = row.Cancelled ? "stopped" : deferred ? "deferred" : row.Cached ? "previous-only" : row.Journal != null ? "fresh" : "failed";
                    string cached = row.Cached && row.Journal != null ? row.Journal.Exported.ToString("o") : "";
                    var item = Attempt(job); item.HasResult = true; item.State = state; item.Code = Cell(code); item.Route = Cell(row.Route);
                    item.TotalMs = Math.Max(0, row.TotalMs); item.ReadMs = Math.Max(0, row.ReadMs);
                    Write("results.tsv", Cells(Utc, job.Index, job.Attempt, job.Name, job.Copy.Name, job.Account.Login, job.Account.Server, job.Copy.Kind,
                        state, code, row.Route, row.ReadMs, row.TotalMs, cached, row.Error ?? row.Note), true);
                    // Persist a current, readable checkpoint even if the app is interrupted before Finish.
                    // This happens once per completed account attempt, not for timer/progress events.
                    SaveSummary();
                }
            }
            catch (Exception e) { Log.Write("report diagnostics result: " + e.GetType().Name); }
        }

        public void Timing(ReportJob job, string phase, long durationMs, string detail = null)
        {
            try
            {
                lock (gate)
                {
                    if (finished || job == null || string.IsNullOrWhiteSpace(phase)) return;
                    phase = Cell(phase); durationMs = Math.Max(0, durationMs);
                    var item = Attempt(job); long total; item.Phases.TryGetValue(phase, out total);
                    if (item.Phases.ContainsKey(phase) || item.Phases.Count < 64)
                    {
                        item.Phases[phase] = total + durationMs;
                        int count; item.PhaseCounts.TryGetValue(phase, out count); item.PhaseCounts[phase] = count + 1;
                    }
                    Write("timings.tsv", Cells(Utc, clock.ElapsedMilliseconds, job.Index, job.Attempt, job.Copy.Name, job.Copy.Kind, phase, durationMs, detail), true);
                }
            }
            catch (Exception e) { Log.Write("report diagnostics timing: " + e.GetType().Name); }
        }
        static void Count(Dictionary<string, int> values, string key)
        {
            if (!values.ContainsKey(key) && values.Count >= 32) key = "other";
            int n; values.TryGetValue(key, out n); values[key] = n + 1;
        }
        string StableCode(string value)
        {
            string safe = Cell(value).Trim();
            return Regex.IsMatch(safe, @"^[A-Za-z0-9_.:+-]{1,64}$") ? safe : "unclassified";
        }
        void ObserveIpc(string platform, string detail)
        {
            var fields = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (Match match in Regex.Matches(Redact(detail), @"(?:^|;)\s*([A-Za-z_]+)\s*=\s*([^;]*)"))
                fields[match.Groups[1].Value] = match.Groups[2].Value.Trim();
            string phase; fields.TryGetValue("phase", out phase);
            if (phase != "init" && phase != "login" && phase != "verify") phase = "unknown";
            string key = platform + " / ipc-" + phase; IpcInfo info;
            if (!ipcResults.TryGetValue(key, out info)) { info = new IpcInfo(); ipcResults.Add(key, info); }
            info.Count++;
            string success; fields.TryGetValue("success", out success);
            if (string.Equals(success, "true", StringComparison.OrdinalIgnoreCase) || success == "1") info.Success++;
            else if (string.Equals(success, "false", StringComparison.OrdinalIgnoreCase) || success == "0")
            {
                info.Failed++;
                string error;
                if (!fields.TryGetValue("error_code", out error) && !fields.TryGetValue("errorcode", out error)) fields.TryGetValue("code", out error);
                Count(info.Errors, StableCode(error));
            }
            else info.Unknown++;
            string attachment; if (fields.TryGetValue("attachment", out attachment)) Count(info.Attachments, StableCode(attachment));
        }
        public void CapacitySample(Kind platform, string action, int worker, int active, int ceiling,
            ulong terminalMb, ulong helperMb, ulong bundleCurrentMb, ulong bundlePeakMb, ulong freeMb, double cpu,
            string reason = null, bool memoryKnown = true)
        {
            try
            {
                lock (gate)
                {
                    if (finished) return;
                    string kind = platform.ToString(); CapacityInfo info;
                    if (!capacities.TryGetValue(kind, out info)) { info = new CapacityInfo(); capacities.Add(kind, info); }
                    action = StableCode(action); info.Samples++; Count(info.Actions, action);
                    info.LastActive = Math.Max(0, active); info.MaxActive = Math.Max(info.MaxActive, info.LastActive); info.LastCeiling = Math.Max(0, ceiling);
                    if (worker > 0) info.Workers.Add(worker);
                    if (memoryKnown)
                    {
                        info.LastKnownWorker = worker; info.LastTerminal = terminalMb; info.LastHelper = helperMb; info.LastCurrent = bundleCurrentMb;
                        info.MaxCurrent = Math.Max(info.MaxCurrent, bundleCurrentMb); info.MaxPeak = Math.Max(info.MaxPeak, bundlePeakMb);
                    }
                    else info.UnknownMemory++;
                    if (freeMb > 0) { info.MinFree = Math.Min(info.MinFree, freeMb); info.MaxFree = Math.Max(info.MaxFree, freeMb); }
                    bool cpuKnown = !double.IsNaN(cpu) && !double.IsInfinity(cpu) && cpu >= 0 && cpu <= 100;
                    if (cpuKnown) { info.CpuSamples++; info.CpuTotal += cpu; info.MaxCpu = Math.Max(info.MaxCpu, cpu); }
                    Write("capacity.tsv", Cells(Utc, clock.ElapsedMilliseconds, kind, action, worker, active, ceiling, memoryKnown,
                        memoryKnown ? (object)terminalMb : "unknown", memoryKnown ? (object)helperMb : "unknown", memoryKnown ? (object)bundleCurrentMb : "unknown",
                        memoryKnown ? (object)bundlePeakMb : "unknown", freeMb > 0 ? (object)freeMb : "unknown", cpuKnown ? cpu.ToString("0.0", CultureInfo.InvariantCulture) : "unknown", reason), true);
                }
            }
            catch (Exception e) { Log.Write("report diagnostics capacity: " + e.GetType().Name); }
        }
        public void RunStage(string code, string detail)
        {
            try
            {
                lock (gate)
                {
                    if (finished) return;
                    Write("events.tsv", Cells(Utc, clock.ElapsedMilliseconds, -1, 0, "", "", "", "", "run", code, detail), true);
                }
            }
            catch (Exception e) { Log.Write("report diagnostics run stage: " + e.GetType().Name); }
        }
        public void RunTiming(string phase, long durationMs, string detail = null)
        {
            try
            {
                lock (gate)
                {
                    if (finished || string.IsNullOrWhiteSpace(phase)) return;
                    phase = Cell(phase); durationMs = Math.Max(0, durationMs);
                    long before; runPhases.TryGetValue(phase, out before);
                    if (runPhases.ContainsKey(phase) || runPhases.Count < 64) runPhases[phase] = before + durationMs;
                    Write("timings.tsv", Cells(Utc, clock.ElapsedMilliseconds, -1, 0, "", "run", phase, durationMs, detail), true);
                }
            }
            catch (Exception e) { Log.Write("report diagnostics run timing: " + e.GetType().Name); }
        }
        sealed class Measurement : IDisposable
        {
            readonly ReportDiagnostics owner; readonly ReportJob job; readonly string phase;
            readonly Stopwatch clock = Stopwatch.StartNew(); bool done;
            public Measurement(ReportDiagnostics owner, ReportJob job, string phase) { this.owner = owner; this.job = job; this.phase = phase; }
            public void Dispose() { if (done) return; done = true; owner.Timing(job, phase, clock.ElapsedMilliseconds); }
        }
        public IDisposable Measure(ReportJob job, string phase) { return new Measurement(this, job, phase); }

        static string Duration(long ms)
        {
            return (Math.Max(0, ms) / 60000).ToString(CultureInfo.InvariantCulture) + "m " + ((Math.Max(0, ms) / 1000) % 60).ToString("00", CultureInfo.InvariantCulture) + "s";
        }
        void SaveSummary()
        {
            var latest = attempts.Values.GroupBy(a => a.Index).Select(g => g.OrderByDescending(a => a.Pass).First()).ToList();
            var sb = new StringBuilder();
            sb.AppendLine("MetaFactory report run summary / خلاصهٔ عیب‌یابی گزارش‌ها");
            sb.AppendLine("Version: " + AppInfo.Version + " | State: " + (finished ? "finished" : "in progress") + " | Workers: " + workers);
            sb.AppendLine("Wall-clock elapsed / زمان واقعی نوبت: " + Duration(clock.ElapsedMilliseconds) + " (" + clock.ElapsedMilliseconds + " ms)");
            sb.AppendLine("Service times below are summed per attempt; parallel service totals can exceed wall-clock elapsed.");
            sb.AppendLine("Failure means no fresh report, not proof of a bad account/password. Previous-only is cached historical data.");
            foreach (string platform in new[] { "MT4", "MT5" })
            {
                var rows = latest.Where(a => a.Platform == platform).ToList(); var passes = attempts.Values.Where(a => a.Platform == platform).ToList();
                int requestedCount = requested.Values.Count(p => p == platform);
                sb.AppendLine(); sb.AppendLine(platform + ": requested=" + requestedCount + "; fresh=" + rows.Count(a => a.State == "fresh") +
                    "; failed=" + rows.Count(a => a.State == "failed") + "; previous-only=" + rows.Count(a => a.State == "previous-only") +
                    "; stopped=" + rows.Count(a => a.State == "stopped") + "; deferred=" + rows.Count(a => a.State == "deferred") + "; pending=" + Math.Max(0, requestedCount - rows.Count(a => a.HasResult)));
                sb.AppendLine("  Started attempts=" + passes.Count(a => a.Begun) + "; additional retry passes=" + passes.Count(a => a.Begun && a.Pass > 1) +
                    "; accounts retried=" + passes.Where(a => a.Begun && a.Pass > 1).Select(a => a.Index).Distinct().Count());
                sb.AppendLine("  Recoverable connection deferrals=" + passes.Count(a => a.State == "deferred"));
                sb.AppendLine("  Completed attempt service time=" + Duration(passes.Where(a => a.HasResult).Sum(a => a.TotalMs)) +
                    "; unsuccessful attempt service time=" + Duration(passes.Where(a => a.HasResult && a.State != "fresh").Sum(a => a.TotalMs)));
                foreach (var reason in rows.Where(a => a.HasResult && a.State != "fresh").GroupBy(a => string.IsNullOrWhiteSpace(a.Code) ? "unknown" : a.Code).OrderByDescending(g => g.Count()))
                    sb.AppendLine("  Final reason: " + reason.Key + " = " + reason.Count());
                int rejected = rows.Count(a => a.State != "fresh" && a.Evidence.Contains("login-rejected-explicit"));
                sb.AppendLine("  Final unread accounts with explicit login rejection in captured evidence=" + rejected + ". Others must not be labelled wrong-password without further evidence.");
            }
            sb.AppendLine(); sb.AppendLine("Measured phase durations / زمان مراحل (summed; nested phases may overlap):");
            foreach (var phase in attempts.Values.SelectMany(a => a.Phases.Select(p => new { a.Platform, Phase = p.Key, Milliseconds = p.Value })).GroupBy(x => x.Platform + " / " + x.Phase).OrderByDescending(g => g.Sum(x => x.Milliseconds)))
                sb.AppendLine("  " + phase.Key + " = " + Duration(phase.Sum(x => x.Milliseconds)) + " (" + phase.Sum(x => x.Milliseconds) + " ms)");
            foreach (var phase in runPhases.OrderByDescending(p => p.Value))
                sb.AppendLine("  run / " + phase.Key + " = " + Duration(phase.Value) + " (" + phase.Value + " ms; worker waits may overlap)");
            sb.AppendLine("Resource/capacity waiting before an attempt is scheduler time, not a student's failed login or report. Deferred means a recoverable pass-one connection wait, not rejected credentials.");
            sb.AppendLine(); sb.AppendLine("Capacity decisions and actual worker bundles / ظرفیت و حافظهٔ گزارش‌خوان‌ها:");
            if (capacities.Count == 0) sb.AppendLine("  No structured capacity/bundle samples were recorded. Memory headroom cannot be inferred from missing samples.");
            foreach (var pair in capacities.OrderBy(p => p.Key))
            {
                var value = pair.Value;
                sb.AppendLine("  " + pair.Key + ": samples=" + value.Samples + "; worker slots observed=" + value.Workers.Count + "; max active=" + value.MaxActive + "; last active=" + value.LastActive + "; last ceiling=" + value.LastCeiling);
                sb.AppendLine("    Decision events: " + string.Join("; ", value.Actions.OrderBy(a => a.Key).Select(a => a.Key + "=" + a.Value)) + ". These are scheduler events, not failed-account counts.");
                if (value.Samples > value.UnknownMemory)
                {
                    sb.AppendLine("    Last known worker=" + value.LastKnownWorker + ": terminal=" + value.LastTerminal + " MiB; helper=" + value.LastHelper + " MiB; bundle current=" + value.LastCurrent + " MiB.");
                    sb.AppendLine("    Maximum sampled bundle current=" + value.MaxCurrent + " MiB; maximum conservative sum of individual process peaks=" + value.MaxPeak + " MiB (not a simultaneous peak).");
                }
                sb.AppendLine("    Unknown-memory samples=" + value.UnknownMemory + "; free RAM range=" + (value.MinFree == ulong.MaxValue ? "unknown" : value.MinFree + ".." + value.MaxFree + " MiB") +
                    "; CPU samples=" + value.CpuSamples + (value.CpuSamples == 0 ? " (unknown)" : "; observed mean=" + (value.CpuTotal / value.CpuSamples).ToString("0.0", CultureInfo.InvariantCulture) + "%; observed max=" + value.MaxCpu.ToString("0.0", CultureInfo.InvariantCulture) + "% (sampled, not continuous peak)"));
            }
            sb.AppendLine(); sb.AppendLine("IPC phase outcomes / مراحل اتصال IPC (failures do not by themselves establish bad credentials):");
            if (ipcResults.Count == 0) sb.AppendLine("  No structured IPC phase outcomes were recorded; see measured phase timings above.");
            foreach (var pair in ipcResults.OrderBy(p => p.Key))
            {
                var value = pair.Value;
                string[] parts = pair.Key.Split(new[] { " / " }, StringSplitOptions.None);
                var measured = attempts.Values.Where(a => a.Platform == parts[0] && a.Phases.ContainsKey(parts[1])).ToList();
                sb.AppendLine("  " + pair.Key + ": outcomes=" + value.Count + "; success=" + value.Success + "; failed=" + value.Failed + "; unknown=" + value.Unknown +
                    "; measured calls=" + measured.Sum(a => a.PhaseCounts[parts[1]]) + "; measured total=" + measured.Sum(a => a.Phases[parts[1]]) + " ms.");
                if (value.Errors.Count > 0) sb.AppendLine("    Failure codes: " + string.Join("; ", value.Errors.OrderByDescending(e => e.Value).Select(e => e.Key + "=" + e.Value)));
                if (value.Attachments.Count > 0) sb.AppendLine("    Attachment modes: " + string.Join("; ", value.Attachments.OrderBy(a => a.Key).Select(a => a.Key + "=" + a.Value)));
            }
            sb.AppendLine(); sb.AppendLine("Longest completed attempts / طولانی‌ترین تلاش‌ها:");
            foreach (var item in attempts.Values.Where(a => a.HasResult).OrderByDescending(a => a.TotalMs).Take(12))
                sb.AppendLine("  " + item.Platform + " " + item.Copy + " | " + item.Name + " | pass=" + item.Pass + " | " + item.State + " | " + Duration(item.TotalMs) + " | " + item.Code);
            sb.AppendLine(); sb.AppendLine("Evidence is limited to bounded tails. No rejection observed means unknown, not guaranteed valid credentials. See evidence.tsv, timings.tsv and native snapshots.");
            if (truncated) sb.AppendLine("Capture limit reached: raw evidence may be incomplete.");
            Write("summary.txt", sb.ToString());
        }

        static bool PrivateCopy(Instance copy)
        {
            if (copy == null || string.IsNullOrWhiteSpace(copy.Dir)) return false;
            string path = Path.GetFullPath(copy.Dir).Replace('\\', '/');
            return path.IndexOf("/_MTManager/report/", StringComparison.OrdinalIgnoreCase) >= 0;
        }
        static bool Link(string path) { return (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0; }
        // A fixed-size read avoids copying an ever-growing terminal log or blocking on exclusive writers.
        internal static List<string> Tail(string path, DateTime day, DateTime started)
        {
            var lines = new List<string>();
            try
            {
                if (!File.Exists(path) || Link(path)) return lines;
                using (var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                {
                    byte[] first = new byte[2]; int got = file.Read(first, 0, 2);
                    bool wide = got == 2 && (first[0] == 0xff && first[1] == 0xfe || first[0] != 0 && first[1] == 0);
                    long start = Math.Max(wide && first[0] == 0xff ? 2 : 0, file.Length - MaxTailBytes);
                    if (wide && start % 2 != 0) start++;
                    file.Position = Math.Min(file.Length, start);
                    byte[] bytes = new byte[MaxTailBytes]; int read = 0;
                    while (read < bytes.Length) { int n = file.Read(bytes, read, bytes.Length - read); if (n <= 0) break; read += n; }
                    string text = (wide ? Encoding.Unicode : TextFiles.Bytes).GetString(bytes, 0, wide ? read - read % 2 : read);
                    IEnumerable<string> whole = text.Split('\n'); if (start > 2) whole = whole.Skip(1);
                    lines = ConnectionCheck.After(whole, day == started.Date ? started.TimeOfDay.Subtract(TimeSpan.FromSeconds(2)) : TimeSpan.Zero).ToList();
                    if (lines.Count > 96) lines = lines.Skip(lines.Count - 96).ToList();
                }
            }
            catch { }
            return lines;
        }
        internal static Dictionary<string, string> NativeEvidence(IEnumerable<string> lines, string login)
        {
            var evidence = new Dictionary<string, string>();
            string number = TextUtil.LatinDigits((login ?? "").Trim()).TrimStart('0');
            foreach (string raw in lines)
            {
                string lower = (raw ?? "").ToLowerInvariant();
                bool ours = number.Length > 0 && Regex.IsMatch(lower, @"(?<![0-9])0*" + Regex.Escape(number) + @"(?![0-9])");
                var owner = Regex.Match(lower, "[\"']([0-9]+)[\"']\\s*:");
                if (owner.Success && owner.Groups[1].Value.TrimStart('0') != number) ours = false;
                bool network = lower.Contains("no connection") || lower.Contains("connection failed") || lower.Contains("connection timeout") || lower.Contains("connection timed out");
                if (network) evidence["connection-failure-observed"] = raw;
                // Only explicit, account-scoped rejection is authentication evidence.
                // A timeout or missing reporter is never converted into a password diagnosis.
                if (ours && !network && (lower.Contains("invalid account") || lower.Contains("invalid password") || lower.Contains("account disabled") || lower.Contains("login rejected") || lower.Contains("authorization rejected")))
                    evidence["login-rejected-explicit"] = raw;
                else if (ours && !network && (lower.Contains("authoriz") || lower.Contains("authoris") || lower.Contains("login")) && lower.Contains("failed"))
                    evidence["login-failure-unclassified"] = raw;
                if (ours && Regex.IsMatch(lower, @"\b(?:authori[sz]ed\s+on|login(?:\s+datacenter)?\s+on|logged\s+in|login\s+succeeded)\b"))
                    evidence["login-confirmed-observed"] = raw;
                if (lower.Contains("symbol") && lower.Contains("synchronization timeout")) evidence["symbol-synchronization-timeout"] = raw;
                if (!lower.Contains("mtmanagerreport")) continue;
                if (lower.Contains("mt4 connection deferred")) evidence["mt4-deferral-observed"] = "Native reporter logged a recoverable connection deferral; this is not a credential rejection. " + raw;
                if (lower.Contains("lifecycle: oninit")) evidence["reporter-init-observed"] = raw;
                if (lower.Contains("lifecycle: ondeinit")) evidence["reporter-deinit-observed"] = raw;
                if (lower.Contains("loaded successfully")) evidence["reporter-loaded-observed"] = raw;
                if (lower.Contains("initialization failed") || lower.Contains("init failed") || lower.Contains("timer failed")) evidence["reporter-initialization-failed"] = raw;
                if (lower.Contains("cannot load") || lower.Contains("load failed") || lower.Contains("not found")) evidence["reporter-load-failed"] = raw;
                if (lower.Contains("historyselect") && lower.Contains("failed") || lower.Contains("history selection failed")) evidence["history-selection-failed"] = raw;
                if (lower.Contains("write failed") || lower.Contains("cannot write")) evidence["reporter-output-failed"] = raw;
            }
            if (evidence.Count == 0) evidence["unknown"] = "No decisive account-scoped authentication or reporter failure evidence in the captured lines.";
            return evidence;
        }
        internal static Dictionary<string, string> Mt4StateEvidence(string text, string token, Account account)
        {
            var evidence = new Dictionary<string, string>();
            var state = string.IsNullOrEmpty(token) ? null : Mt4ReportState.TryParse(text, token, account);
            if (state == null)
            {
                evidence["mt4-state-unverified"] = "No complete MT4 state matching the current request/account/server. Missing, partial or old state is unknown; it is not a password diagnosis.";
                return evidence;
            }
            evidence["current-request-mt4-state"] = "stage=" + state.Stage + "; request_elapsed_ms=" + state.ElapsedMilliseconds +
                "; actual_login=" + state.ActualLogin + "; actual_server=" + state.ActualServer + "; native_connected=" + state.Connected;
            if (state.MatchingConnected)
                evidence["mt4-account-connected"] = "Native state confirms the requested account/server connected; history/report completion is a separate requirement.";
            else
            {
                string actual = TextUtil.LatinDigits((state.ActualLogin ?? "").Trim()).TrimStart('0');
                string wanted = TextUtil.LatinDigits((account.Login ?? "").Trim()).TrimStart('0');
                if (actual.Length == 0) evidence["mt4-waiting-login"] = "The terminal has not yet exposed an active login. The reason is not established.";
                else if (!string.Equals(actual, wanted, StringComparison.Ordinal)) evidence["mt4-actual-account-mismatch"] = "The terminal currently exposes another account; this may be a pending switch and does not establish incorrect credentials.";
                if (!string.IsNullOrWhiteSpace(state.ActualServer) && !string.Equals(state.ActualServer.Trim(), account.Server.Trim(), StringComparison.OrdinalIgnoreCase))
                    evidence["mt4-actual-server-mismatch"] = "The actual terminal server differs from the requested server; this does not establish incorrect credentials.";
                else if (string.IsNullOrWhiteSpace(state.ActualServer)) evidence["mt4-waiting-server"] = "The terminal has not yet exposed the requested server.";
                if (!state.Connected) evidence["mt4-connection-unconfirmed"] = "The native connection flag is false; network/server/login readiness remains unresolved.";
            }
            if (state.Stage == "deferred") evidence["mt4-connection-deferred-ack"] = "The reporter acknowledged deferral while waiting for the requested connection; recoverable, not a credential rejection.";
            if (state.Stage == "failed") evidence["mt4-reporter-failed-state"] = "The current reporter state says failed; inspect the specific native error/result code, not a guessed password error.";
            return evidence;
        }
        static string ReadPulse(string path)
        {
            try
            {
                if (!File.Exists(path) || Link(path)) return null;
                using (var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                {
                    if (file.Length <= 0 || file.Length > 8192) return null;
                    using (var reader = new StreamReader(file, Encoding.Unicode, true)) return reader.ReadToEnd();
                }
            }
            catch { return null; }
        }
        public void Capture(ReportJob job, Instance copy, DateTime started, string route, string expectedToken = null)
        {
            try
            {
                if (!PrivateCopy(copy)) { Stage(job, "native.skipped", "Not a private report copy"); return; }
                // Never follow a linked root/log folder outside the private report terminal.
                string[] folders = { copy.Dir, Path.Combine(copy.Dir, "logs"), Path.Combine(copy.Dir, Kinds.Mql(copy.Kind)), Path.Combine(copy.Dir, Kinds.Mql(copy.Kind), "Logs") };
                if (folders.Any(f => Directory.Exists(f) && Link(f))) { Stage(job, "native.skipped", "Linked log directory"); return; }
                var lines = new List<string>();
                DateTime today = DateTime.Now.Date;
                DateTime first = started.Date < today.AddDays(-1) ? today.AddDays(-1) : started.Date;
                for (DateTime day = first; day <= today; day = day.AddDays(1))
                {
                    lines.AddRange(Tail(ConnectionCheck.JournalFile(copy, day), day, started).Select(s => "Journal: " + s));
                    lines.AddRange(Tail(ReportTrace.ProgramsLog(copy, day), day, started).Select(s => "Experts: " + s));
                }
                var observations = NativeEvidence(lines, job.Account.Login);
                string pulseText = copy.Kind == Kind.MT5 ? ReadPulse(ReportLaunch.OutputPath(copy) + ".pulse") : null;
                var pulse = copy.Kind == Kind.MT5 && !string.IsNullOrEmpty(expectedToken) ? Mt5ReporterPulse.TryParse(pulseText, expectedToken, job.Account) : null;
                if (pulse != null)
                {
                    observations["current-request-pulse"] = "stage=" + pulse.Stage + "; request_elapsed_ms=" + pulse.ElapsedMilliseconds + "; matching_account_connected=" + pulse.Connected;
                    if (pulse.Connected) observations["login-confirmed-observed"] = "Native pulse confirms current request/account/server connected; this is not proof of report completion.";
                }
                else if (copy.Kind == Kind.MT5) observations["pulse-unverified"] = string.IsNullOrEmpty(expectedToken) ? "No request token supplied; pulse freshness/identity not verified." : "No complete pulse matching the current request. Absence is not proof of a stopped process or wrong password.";
                if (copy.Kind == Kind.MT4)
                    foreach (var observation in Mt4StateEvidence(ReadPulse(ReportLaunch.OutputPath(copy) + ".state"), expectedToken, job.Account)) observations[observation.Key] = observation.Value;
                lock (gate)
                {
                    if (finished) return;
                    string header = "Account: " + Cell(job.Account.Login) + "\nServer: " + Cell(job.Account.Server) + "\nCopy: " + Cell(job.Copy.Name) +
                        "\nPrivate terminal: " + Cell(copy.Dir) + "\nPass: " + job.Attempt + "\nRoute: " + Cell(route) + "\nAttempt start (local): " + started.ToString("o") +
                        "\nCaptured UTC: " + Utc + "\nTerminal version: " + Cell(TerminalUpdate.FileVersion(copy.Exe)) + "\nFree RAM MB: " + Checks.FreeRamMb() + "\n\nObserved evidence (not a conclusive diagnosis):\n" +
                        string.Join("\n", observations.Select(o => o.Key + ": " + Cell(o.Value))) + "\n\n";
                    var selected = new List<string>(); int budget = Math.Max(0, (MaxNativeBytes - Encoding.UTF8.GetByteCount(header)) / 2);
                    // Keep evidence from both streams even if one is exceptionally noisy.
                    foreach (string stream in new[] { "Journal: ", "Experts: " })
                    {
                        var part = new List<string>(); int bytes = 0;
                        foreach (string line in Enumerable.Reverse(lines.Where(l => l.StartsWith(stream, StringComparison.Ordinal))))
                        {
                            string safe = Cell(line); int n = Encoding.UTF8.GetByteCount(safe) + 1;
                            if (bytes + n > budget) break;
                            part.Add(safe); bytes += n;
                        }
                        part.Reverse(); selected.AddRange(part);
                    }
                    if (selected.Count == 0) selected.Add("No timestamped native lines found in the bounded tail for this attempt.");
                    string name = "native-" + (++captureId).ToString("D5") + "-" + Math.Max(0, job.Index).ToString("D5") + "-" + Math.Max(0, job.Attempt).ToString("D2") + ".txt";
                    Write(name, header + string.Join("\n", selected) + "\n");
                    var item = Attempt(job);
                    foreach (var observation in observations)
                    {
                        item.Evidence.Add(observation.Key);
                        Write("evidence.tsv", Cells(Utc, job.Index, job.Attempt, job.Copy.Name, job.Copy.Kind, name, route, observation.Key, observation.Value), true);
                    }
                }
            }
            catch (Exception e) { Stage(job, "native.capture-error", e.GetType().Name); }
        }
        public void Finish()
        {
            try
            {
                lock (gate)
                {
                    if (finished) return;
                    Write("manifest.txt", "\nFinished UTC: " + Utc + "\nElapsed ms: " + clock.ElapsedMilliseconds + "\n", true);
                    clock.Stop(); finished = true; SaveSummary(); secrets.Clear(); if (latestActive == this) latestActive = null;
                }
            }
            catch (Exception e) { Log.Write("report diagnostics finish: " + e.GetType().Name); }
        }
        static bool AllowedFile(string name) { return name == "manifest.txt" || name == "events.tsv" || name == "results.tsv" || name == "summary.txt" || name == "timings.tsv" || name == "evidence.tsv" || name == "capacity.tsv" || NativeName.IsMatch(name); }
        static IEnumerable<string> Runs()
        {
            if (!Directory.Exists(Root)) return Enumerable.Empty<string>();
            return Directory.GetDirectories(Root).Where(d => RunName.IsMatch(Path.GetFileName(d)) && !Link(d) && File.Exists(Path.Combine(d, "manifest.txt"))).OrderByDescending(d => Path.GetFileName(d), StringComparer.Ordinal).ToArray();
        }
        static string LatestDirectory()
        {
            if (latestActive != null && latestActive.directory != null && latestActive.directory.StartsWith(Root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) && File.Exists(Path.Combine(latestActive.directory, "manifest.txt"))) return latestActive.directory;
            return Runs().FirstOrDefault();
        }
        public static bool HasLatest { get { try { lock (gate) return LatestDirectory() != null; } catch { return false; } } }
        static void Prune()
        {
            string active = latestActive == null ? null : latestActive.directory;
            foreach (string run in Runs().Where(r => r != active).Skip(KeepRuns - (active == null ? 0 : 1)))
            {
                try
                {
                    foreach (string file in Directory.GetFiles(run).Where(f => AllowedFile(Path.GetFileName(f)) && !Link(f))) File.Delete(file);
                    if (!Directory.EnumerateFileSystemEntries(run).Any()) Directory.Delete(run);
                }
                catch { }
            }
        }
        public static void ExportLatest(string destination)
        {
            lock (gate)
            {
                if (latestActive != null) latestActive.SaveSummary();
                string run = LatestDirectory();
                if (run == null) throw new UserMessage(Lang.T("هنوز گزارش عیب‌یابی ثبت نشده است؛ یک نوبت گزارش‌گیری اجرا کنید.", "No report diagnostics have been recorded yet; run a report first."));
                string full = Path.GetFullPath(destination);
                if (full.StartsWith(Path.GetFullPath(Root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                    throw new UserMessage(Lang.T("فایل خروجی را بیرون از پوشهٔ داخلی عیب‌یابی ذخیره کنید.", "Save the exported ZIP outside the internal diagnostics folder."));
                string temporary = full + "." + Guid.NewGuid().ToString("N") + ".tmp";
                try
                {
                    using (var output = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    using (var zip = new ZipArchive(output, ZipArchiveMode.Create))
                    {
                        long total = 0;
                        foreach (string file in Directory.GetFiles(run).Where(f => AllowedFile(Path.GetFileName(f)) && !Link(f)).OrderBy(f => f))
                        {
                            long size = new FileInfo(file).Length;
                            if (size > MaxRunBytes || total + size > MaxRunBytes + 4096) continue;
                            var entry = zip.CreateEntry(Path.GetFileName(file), CompressionLevel.Optimal);
                            using (var input = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read))
                            using (var target = entry.Open()) input.CopyTo(target);
                            total += size;
                        }
                    }
                    if (File.Exists(full)) File.Replace(temporary, full, null); else File.Move(temporary, full);
                }
                finally { if (File.Exists(temporary)) File.Delete(temporary); }
            }
        }
    }
}
