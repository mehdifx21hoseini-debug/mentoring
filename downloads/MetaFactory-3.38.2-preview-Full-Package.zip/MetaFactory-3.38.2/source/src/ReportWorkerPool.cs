using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;

namespace MTManager
{
    public sealed class ReportProcessMemory
    {
        public bool Known, Alive;
        public ulong CurrentMb, PeakMb;
        public static ReportProcessMemory Unknown() { return new ReportProcessMemory { Known = false }; }
        public static ReportProcessMemory Absent() { return new ReportProcessMemory { Known = true }; }
    }

    // Capture once when ownership is established. A recycled PID is not this process.
    public sealed class ReportProcessIdentity
    {
        public readonly int Pid;
        public readonly long StartedUtcTicks;
        public ReportProcessIdentity(int pid, long startedUtcTicks) { Pid = pid; StartedUtcTicks = startedUtcTicks; }
        public static ReportProcessIdentity Capture(Process process)
        {
            if (process == null) return null;
            int pid = 0; long start = 0;
            try { pid = process.Id; start = process.StartTime.ToUniversalTime().Ticks; } catch { }
            return new ReportProcessIdentity(pid, start);
        }
        static ulong Mb(long bytes) { return bytes <= 0 ? 0 : ((ulong)bytes + 1048575UL) / 1048576UL; }
        public ReportProcessMemory Sample()
        {
            if (Pid <= 0 || StartedUtcTicks <= 0) return ReportProcessMemory.Unknown();
            try
            {
                using (Process process = Process.GetProcessById(Pid))
                {
                    if (process.StartTime.ToUniversalTime().Ticks != StartedUtcTicks || process.HasExited) return ReportProcessMemory.Absent();
                    process.Refresh();
                    ulong current = Mb(process.WorkingSet64), peak = Mb(process.PeakWorkingSet64);
                    return new ReportProcessMemory { Known = true, Alive = true, CurrentMb = current, PeakMb = Math.Max(current, peak) };
                }
            }
            catch (ArgumentException) { return ReportProcessMemory.Absent(); }
            catch { return ReportProcessMemory.Unknown(); }
        }
    }

    public sealed class ReportBundleMemory
    {
        public bool Known = true;
        public ulong CurrentMb, PeakMb;
        public int LiveProcesses;
        // The sum of individual process peaks is a conservative bound, not a claim that
        // terminal and Python attained their peaks at exactly the same instant.
        public static ReportBundleMemory Combine(params ReportProcessMemory[] processes)
        {
            var result = new ReportBundleMemory();
            foreach (ReportProcessMemory process in processes ?? new ReportProcessMemory[0])
            {
                if (process == null || !process.Known) { result.Known = false; continue; }
                if (!process.Alive) continue;
                result.LiveProcesses++;
                result.CurrentMb += process.CurrentMb;
                result.PeakMb += Math.Max(process.CurrentMb, process.PeakMb);
            }
            return result;
        }
    }

    // Slot ownership and resource reclamation are separate from account/report validity.
    // Acquire a busy lease BEFORE claiming work. Reclaimers can only close idle slots.
    public sealed class ReportWorkerPool
    {
        sealed class Slot
        {
            public bool Busy, Evicting;
            public Func<ReportBundleMemory> Sample;
            public Func<bool> Close;
        }
        readonly object gate = new object();
        readonly Dictionary<int, Slot> slots = new Dictionary<int, Slot>();
        Slot Get(int slot)
        {
            if (slot <= 0) throw new ArgumentOutOfRangeException("slot");
            Slot state; if (!slots.TryGetValue(slot, out state)) slots.Add(slot, state = new Slot());
            return state;
        }
        public sealed class Lease : IDisposable
        {
            ReportWorkerPool owner;
            readonly int slot;
            internal Lease(ReportWorkerPool owner, int slot) { this.owner = owner; this.slot = slot; }
            public void Dispose()
            {
                ReportWorkerPool previous = Interlocked.Exchange(ref owner, null);
                if (previous == null) return;
                lock (previous.gate) { previous.Get(slot).Busy = false; Monitor.PulseAll(previous.gate); }
            }
        }
        public Lease TryBeginJob(int slot)
        {
            lock (gate)
            {
                Slot state = Get(slot);
                if (state.Busy || state.Evicting) return null;
                state.Busy = true;
                return new Lease(this, slot);
            }
        }
        public Lease BeginJob(int slot, Func<bool> cancel)
        {
            while (true)
            {
                if (cancel != null && cancel()) throw new OperationCanceledException();
                Lease lease = TryBeginJob(slot);
                if (lease != null) return lease;
                lock (gate) Monitor.Wait(gate, 100);
            }
        }
        public void Retain(int slot, Func<ReportBundleMemory> sample, Func<bool> close)
        {
            if (sample == null || close == null) throw new ArgumentNullException();
            lock (gate)
            {
                Slot state = Get(slot);
                if (!state.Busy || state.Evicting) throw new InvalidOperationException("Only the busy slot owner can register its process bundle.");
                state.Sample = sample; state.Close = close;
            }
        }
        // The owner calls this only after confirming its normal close completed.
        public void Forget(int slot)
        {
            lock (gate)
            {
                Slot state = Get(slot);
                if (!state.Busy || state.Evicting) throw new InvalidOperationException("Only the busy slot owner can forget a closed process bundle.");
                state.Sample = null; state.Close = null;
            }
        }
        bool CloseIdle(int slot)
        {
            Slot state; Func<bool> close;
            lock (gate)
            {
                if (!slots.TryGetValue(slot, out state) || state.Busy || state.Evicting || state.Close == null) return false;
                state.Evicting = true; close = state.Close;
            }
            bool closed = false;
            try { closed = close(); return closed; }
            catch { return false; }
            finally
            {
                lock (gate)
                {
                    if (closed) { state.Sample = null; state.Close = null; }
                    state.Evicting = false;
                    Monitor.PulseAll(gate);
                }
            }
        }
        public bool ReleaseIdle(int slot) { return CloseIdle(slot); }
        public bool TryReclaimOne(int exceptSlot = 0)
        {
            int[] candidates;
            lock (gate) candidates = slots.Where(x => x.Key != exceptSlot && !x.Value.Busy && !x.Value.Evicting && x.Value.Close != null).Select(x => x.Key).ToArray();
            foreach (int slot in candidates) if (CloseIdle(slot)) return true;
            return false;
        }
        public int ReleaseAllIdle()
        {
            int[] candidates; lock (gate) candidates = slots.Keys.ToArray();
            return candidates.Count(CloseIdle);
        }
        public Dictionary<int, ReportBundleMemory> SnapshotBySlot()
        {
            KeyValuePair<int, Func<ReportBundleMemory>>[] readers;
            lock (gate) readers = slots.Where(x => x.Value.Sample != null).Select(x => new KeyValuePair<int, Func<ReportBundleMemory>>(x.Key, x.Value.Sample)).ToArray();
            var result = new Dictionary<int, ReportBundleMemory>();
            foreach (var reader in readers)
            {
                try { result[reader.Key] = reader.Value() ?? new ReportBundleMemory { Known = false }; }
                catch { result[reader.Key] = new ReportBundleMemory { Known = false }; }
            }
            return result;
        }
        public ReportBundleMemory Snapshot()
        {
            var result = new ReportBundleMemory();
            foreach (ReportBundleMemory item in SnapshotBySlot().Values)
            { result.Known &= item.Known; result.CurrentMb += item.CurrentMb; result.PeakMb += item.PeakMb; result.LiveProcesses += item.LiveProcesses; }
            return result;
        }
        // A false result means capacity is still paused, NOT that an account failed.
        // Call before account claim; never spend its retry budget on this wait.
        public static bool WaitForCapacity(Func<bool> available, Func<bool> reclaimIdle, Func<bool> cancel,
            int maximumMilliseconds, Action waiting = null, Func<long> elapsed = null, Action<int> sleep = null)
        {
            if (maximumMilliseconds < 0) throw new ArgumentOutOfRangeException("maximumMilliseconds");
            var clock = Stopwatch.StartNew();
            Func<long> now = elapsed ?? (() => clock.ElapsedMilliseconds);
            Action<int> pause = sleep ?? (ms => Thread.Sleep(ms));
            long started = now(); bool announced = false;
            while (true)
            {
                if (cancel != null && cancel()) throw new OperationCanceledException();
                if (available()) return true;
                if (reclaimIdle != null && reclaimIdle() && available()) return true;
                if (!announced) { announced = true; if (waiting != null) waiting(); }
                long remaining = maximumMilliseconds - (now() - started);
                if (remaining <= 0) return false;
                pause((int)Math.Min(100, remaining));
            }
        }
    }
}
