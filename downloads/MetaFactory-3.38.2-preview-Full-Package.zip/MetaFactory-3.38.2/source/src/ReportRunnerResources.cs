using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Threading;

namespace MTManager
{
    public sealed partial class ReportRunner
    {
        readonly ReportWorkerPool workerPool = new ReportWorkerPool();
        readonly ConcurrentDictionary<int, OwnedReportBundle> ownedBundles = new ConcurrentDictionary<int, OwnedReportBundle>();
        readonly object sampleGate = new object();
        volatile bool capacityPaused;
        public string CleanupWarning { get; private set; }
        static readonly ConcurrentDictionary<string, Func<bool>> deferredCleanup = new ConcurrentDictionary<string, Func<bool>>(StringComparer.OrdinalIgnoreCase);
        void RetryDeferredCleanup()
        {
            foreach (var entry in deferredCleanup.ToArray())
                try { if (entry.Value()) { Func<bool> removed; deferredCleanup.TryRemove(entry.Key, out removed); } } catch { }
        }
        void FinishOwnedCleanup()
        {
            workerPool.ReleaseAllIdle();
            foreach (var entry in ownedBundles.ToArray())
            {
                int slot = entry.Key;
                deferredCleanup[entry.Value.Copy.Dir] = () => CloseOwned(slot);
            }
            if (!ownedBundles.IsEmpty)
            {
                CleanupWarning = Lang.T("بسته‌شدن بعضی گزارش‌خوان‌ها تأیید نشد؛ پاک‌سازی در نوبت بعد دوباره بررسی می‌شود.", "Some reporter processes could not be confirmed closed; cleanup will be retried on the next run.");
                Log.Write(CleanupWarning);
                if (diagnostics != null) diagnostics.RunStage("cleanup-unconfirmed", "retained owned bundles=" + ownedBundles.Count + "; fresh report results remain unchanged");
            }
        }
        long lastCapacityLog = -2000;
        int lastAdmissionLimit;
        sealed class OwnedReportBundle
        {
            public Instance Copy;
            public Process Process;
            public ReportProcessIdentity Identity;
            public ReportStartBudget.Reservation Reservation;
            public volatile ReportLoginSession Login;
            public bool HelperSeen;
            public ulong Peak;
        }
        ReportBundleMemory SampleOwned(int slot)
        {
            OwnedReportBundle bundle;
            if (!ownedBundles.TryGetValue(slot, out bundle)) return new ReportBundleMemory();
            ReportProcessMemory native = bundle.Identity == null ? ReportProcessMemory.Unknown() : bundle.Identity.Sample();
            ReportLoginSession login = bundle.Login;
            ReportProcessMemory helper = login == null ? ReportProcessMemory.Absent() : login.Memory();
            ReportBundleMemory sample = ReportBundleMemory.Combine(native, helper);
            lock (bundle)
            {
                if (helper.Known && helper.Alive) bundle.HelperSeen = true;
                if (sample.Known) bundle.Peak = Math.Max(bundle.Peak, sample.PeakMb);
                sample.PeakMb = Math.Max(sample.PeakMb, bundle.Peak);
            }
            return sample;
        }
        void TrackOwned(int slot, Instance copy, Process process, ReportStartBudget.Reservation reservation)
        {
            var bundle = new OwnedReportBundle { Copy = copy, Process = process, Identity = ReportProcessIdentity.Capture(process), Reservation = reservation };
            ownedBundles[slot] = bundle;
            workerPool.Retain(slot, () => SampleOwned(slot), () => CloseOwned(slot));
            if (reservation != null)
                reservation.Observe(() => { var sample = SampleOwned(slot); return !sample.Known ? (ulong?)0 : sample.LiveProcesses == 0 ? null : (ulong?)sample.CurrentMb; });
            SampleResources(false);
        }
        static bool ConfirmedExited(Process process)
        { try { process.Refresh(); return process.HasExited; } catch { return false; } }
        bool CloseOwned(int slot)
        {
            OwnedReportBundle bundle;
            if (!ownedBundles.TryGetValue(slot, out bundle)) return true;
            ReportLoginSession login = bundle.Login;
            if (login != null && !login.TryClose()) return false;
            End(bundle.Process, bundle.Copy);
            if (!ConfirmedExited(bundle.Process) || !EndLeftover(bundle.Copy)) return false;
            OwnedReportBundle removed; ownedBundles.TryRemove(slot, out removed);
            WarmTerminal previous; warm.TryRemove(slot, out previous);
            lock (live) live.Remove(bundle.Process);
            if (bundle.Reservation != null) bundle.Reservation.Dispose();
            if (admission != null) admission.NativeReleased(slot);
            try { bundle.Process.Dispose(); } catch { }
            if (admission != null) admission.ObserveBundle(slot, true, 0, bundle.Peak, resourceRead().MonotonicMs);
            return true;
        }
        void SampleResources(bool log)
        {
            if (!Monitor.TryEnter(sampleGate)) return;
            try
            {
                ReportResourceSnapshot resources = resourceRead();
                bool record = log && resources.MonotonicMs - lastCapacityLog >= 2000;
                if (record) lastCapacityLog = resources.MonotonicMs;
                foreach (var entry in ownedBundles.ToArray())
                {
                    OwnedReportBundle bundle = entry.Value;
                    ReportBundleMemory memory = SampleOwned(entry.Key);
                    if (admission != null) admission.ObserveBundle(entry.Key, memory.Known, memory.CurrentMb, memory.PeakMb, resources.MonotonicMs);
                    if (record && diagnostics != null)
                    {
                        ReportProcessMemory native = bundle.Identity.Sample();
                        var login = bundle.Login; ReportProcessMemory helper = login == null ? ReportProcessMemory.Absent() : login.Memory();
                        diagnostics.CapacitySample(bundle.Copy.Kind, "sample", entry.Key, admission == null ? 0 : admission.Active, Parallel,
                            native.CurrentMb, helper.CurrentMb, memory.CurrentMb, memory.PeakMb, resources.FreeMb, resources.CpuPercent,
                            admission == null ? "fixed capacity" : admission.Reason, memory.Known);
                    }
                }
                if (admission != null && diagnostics != null && lastAdmissionLimit != admission.Limit)
                {
                    int next = admission.Limit;
                    diagnostics.CapacitySample(jobs.All(j => j.Copy.Kind == Kind.MT4) ? Kind.MT4 : Kind.MT5,
                        next > lastAdmissionLimit ? "promote" : "rollback", 0, admission.Active, Parallel, 0, 0, 0, 0,
                        resources.FreeMb, resources.CpuPercent, "active_limit=" + next + "; " + admission.Reason);
                    lastAdmissionLimit = next;
                }
            }
            catch (Exception e) { Log.Write("report resource sample: " + e.GetType().Name); }
            finally { Monitor.Exit(sampleGate); }
        }
        bool ReclaimIdle(int exceptSlot)
        {
            bool freed = workerPool.TryReclaimOne(exceptSlot);
            if (freed && diagnostics != null) diagnostics.RunStage("capacity-reclaim", "closed an idle owned reporter bundle; active account leases were excluded");
            return freed;
        }
        void PauseForResources()
        {
            capacityPaused = true; stop = true;
            if (diagnostics != null) diagnostics.RunStage("capacity-paused", "capacity remained unavailable after bounded waiting and idle cleanup; unread accounts were stopped, not failed");
            var note = Note; if (note != null) try { note(CapacityReason()); } catch { }
        }
        string CapacityReason()
        { return Lang.T("گزارش‌گیری به دلیل کافی نبودن منابع سیستم متوقف شد؛ حساب‌های باقی‌مانده ناموفق محسوب نشده‌اند.", "Reporting paused because system resources remained unavailable; remaining accounts were not marked failed."); }
        void IpcDiagnostics(ReportJob job, ReportLoginSession session)
        {
            ReportIpcObservation result = session.LastObservation;
            if (diagnostics == null || result == null) return;
            diagnostics.Timing(job, "ipc-init", result.InitMs);
            diagnostics.Timing(job, "ipc-login", result.LoginMs);
            diagnostics.Timing(job, "ipc-verify", result.VerifyMs);
            diagnostics.Stage(job, "ipc-result", "phase=" + (result.Phase == "verified" ? "verify" : result.Phase)
                + "; success=" + result.Success.ToString().ToLowerInvariant() + "; error_code=" + result.ErrorCode + "; attachment=" + result.Attachment);
        }
    }
}
