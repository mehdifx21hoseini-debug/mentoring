using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using MTManager;

// Actual asynchronous MainForm queue with injected process creation, not a native MT capacity test.
class UnrestrictedManualLaunchSmoke
{
    static readonly BindingFlags F=BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic;
    static readonly Assembly A=typeof(Settings).Assembly;
    static int checks;
    static object Get(object o,string name){return o.GetType().GetField(name,F).GetValue(o);}
    static void Set(object o,string name,object value){o.GetType().GetField(name,F).SetValue(o,value);}
    static object Call(object o,string name,params object[] values){return o.GetType().GetMethods(F).Single(m=>m.Name==name&&m.GetParameters().Length==values.Length).Invoke(o,values);}
    static void Check(bool ok,string text){if(!ok)throw new Exception(text);checks++;Console.WriteLine("PASS "+text);}
    static void Pump(){Application.DoEvents();Thread.Sleep(5);}
    static void Drain(Form main,Queue<Instance> queue)
    {
        var clock=Stopwatch.StartNew();
        while((queue.Count>0||(bool)Get(main,"preparingCopy"))&&clock.ElapsedMilliseconds<120000)
        {Call(main,"StartNext");Pump();}
        Check(queue.Count==0&&!(bool)Get(main,"preparingCopy"),"production asynchronous queue drains");
    }
    static Instance Copy(string root,int number)
    {
        var copy=new Instance{Name="Synthetic-"+number,Kind=number%2==0?Kind.MT5:Kind.MT4,Dir=Path.Combine(root,"Synthetic-"+number)};
        Directory.CreateDirectory(copy.Dir);File.WriteAllText(copy.Exe,"synthetic never executed");return copy;
    }
    [STAThread]static int Main()
    {
        string root=Path.Combine(Path.GetTempPath(),"mf-unrestricted-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=root;
        Process helper=null;
        try
        {
            Application.EnableVisualStyles();A.GetType("MTManager.Theme").GetMethod("Init",F).Invoke(null,null);Lang.En=true;
            var settings=new Settings{BaseDir=Path.Combine(root,"copies"),DelaySeconds=0,MaxMt4=1,AutoStart=false,LastBackup=DateTime.Now};Directory.CreateDirectory(settings.BaseDir);
            helper=Process.Start(new ProcessStartInfo("/bin/sleep","180"){UseShellExecute=false});
            using(var main=(Form)Activator.CreateInstance(A.GetType("MTManager.MainForm"),F,null,new object[]{settings,new AccountStore()},null))
            {
                main.Show();Pump();
                foreach(var field in main.GetType().GetFields(F))if(field.FieldType==typeof(System.Windows.Forms.Timer))((System.Windows.Forms.Timer)field.GetValue(main)).Stop();
                var copies=(List<Instance>)Get(main,"copies");copies.Clear();for(int k=0;k<200;k++)copies.Add(Copy(settings.BaseDir,k));
                Set(main,"launchTotalRam",(Func<ulong>)(()=>8192));Set(main,"launchFreeRam",(Func<ulong>)(()=>1));Set(main,"sandboxAvailable",(Func<bool>)(()=>false));
                var attempted=new List<string>();
                Set(main,"startTerminal",(Func<Instance,StartResult>)(copy=>{
                    lock(attempted)attempted.Add(copy.Name);
                    if(copy.Name=="Synthetic-7"||copy.Name=="Synthetic-39")throw new Win32Exception(1450,"Synthetic allocation failure");
                    return new StartResult{Process=copy.Name=="Synthetic-0"?helper:null};
                }));
                Call(main,"Enqueue",copies.Concat(copies).ToList());var queue=(Queue<Instance>)Get(main,"startQueue");Drain(main,queue);
                Check(attempted.Count==200&&attempted.Distinct().Count()==200,"all200 mixed MT4/MT5 attempts survive low RAM, legacy report cap1 and duplicate input");
                Check((int)Get(main,"launchFailed")==2,"two allocation failures recorded without aborting the remaining198 attempts");
                var recovery=(LaunchResourceRecovery)Get(main,"resourceRecovery");Check(!recovery.Waiting(DateTime.UtcNow),"no resource-error recovery pause remains after actual queue failures");
                Check(!helper.HasExited,"previous headless process is not killed to make room");
                Check(((string)Get(main,"launchMemoryWarning")).Length>0,"low memory is still observable without denying starts");
                Set(main,"launchFreeRam",(Func<ulong>)(()=>0));for(int k=200;k<204;k++)queue.Enqueue(Copy(settings.BaseDir,k));Drain(main,queue);
                Check(attempted.Count==204,"unknown RAM cannot block later manual launches");
                queue.Enqueue(Copy(settings.BaseDir,204));Set(main,"appClosing",true);Call(main,"StartNext");
                Check(attempted.Count==204&&queue.Count==1,"application close still cancels new work");queue.Clear();main.Close();Pump();
            }
            Console.WriteLine("UNRESTRICTED MANUAL QUEUE PASS "+checks+" (204 simulated starts; no real terminal capacity claim)");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
        finally
        {
            if(helper!=null){try{if(!helper.HasExited){helper.Kill();helper.WaitForExit();}helper.Dispose();}catch{}}
            try{Directory.Delete(root,true);}catch{}
        }
    }
}
