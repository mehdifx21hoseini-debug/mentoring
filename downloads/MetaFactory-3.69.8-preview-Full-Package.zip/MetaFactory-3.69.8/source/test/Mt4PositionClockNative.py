"""Execute actual MQL4 position quote sampling bodies with synthetic MT4 APIs.
No broker login; not a Windows/MetaEditor test.
"""
from pathlib import Path
import subprocess,tempfile
src=(Path(__file__).resolve().parents[1]/'report/MTManagerLive.mq4').read_text()
def function(signature):
    start=src.index(signature);begin=src.index('{',start);end=begin+1;depth=1
    while depth:
        depth+=(src[end]=='{')-(src[end]=='}');end+=1
    return src[start:end]
code=r'''
#include <string>
#include <vector>
#include <map>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <iostream>
using string=std::string;using uint=uint32_t;using datetime=long;
struct MqlTick{datetime time=0;double bid=1,ask=2;};
std::map<string,MqlTick> quotes;std::map<string,bool> selected;
std::vector<string> clockSymbols;std::vector<datetime> clockSymbolTimes;std::vector<uint> clockSymbolTicks;
const int MaxClockSymbols=256,SYMBOL_SELECT=1,SELECT_BY_POS=2,MODE_TRADES=3,OP_BUY=0,OP_SELL=1;
struct Order{string symbol;int type;};std::vector<Order> orders;int orderIndex=0,selectCalls=0,quoteReads=0;
bool allowSelect=true,allowQuote=true,failTimesResize=false;
uint tick=1000,clockTick=0;datetime utc=1795853400,quoteTime=utc-3600*8,clockLastServer=0,clockServer=0;
long clockOffset=0;bool clockKnown=false;string clockSource="",positionQuoteSymbol="",positionQuoteStatus="no-open-position";datetime positionQuoteTime=0;
uint GetTickCount(){return tick;}datetime TimeCurrent(){return quoteTime;}datetime TimeGMT(){return utc;}
double MathRound(double x){return std::round(x);}double MathAbs(double x){return std::abs(x);}
bool MathIsValidNumber(double x){return std::isfinite(x);}int StringLen(string s){return s.size();}
string IntegerToString(long x){return std::to_string(x);}
bool SymbolInfoInteger(string s,int){return selected[s];}
bool SymbolSelect(string s,bool value){selectCalls++;if(!allowSelect)return false;selected[s]=value;return true;}
bool SymbolInfoTick(string s,MqlTick& q){quoteReads++;if(!allowQuote||!selected[s]||!quotes.count(s))return false;q=quotes[s];return true;}
template<class T>int ArraySize(std::vector<T> const& v){return v.size();}
int ArrayResize(std::vector<string>& v,int n){v.resize(n);return n;}
int ArrayResize(std::vector<datetime>& v,int n){if(failTimesResize)return -1;v.resize(n);return n;}
int ArrayResize(std::vector<uint>& v,int n){v.resize(n);return n;}
int OrdersTotal(){return orders.size();}bool OrderSelect(int i,int,int){orderIndex=i;return i>=0&&i<(int)orders.size();}
int OrderType(){return orders[orderIndex].type;}string OrderSymbol(){return orders[orderIndex].symbol;}
'''
for signature in ['void CalibrateBrokerClock(', 'void SampleBrokerClock(', 'bool BrokerClockKnown()', 'string Offset()', 'datetime ServerNow()', 'void SamplePositionClock(', 'void SamplePositionClocks()']:
    code+=function(signature).replace('string seen[];','std::vector<string> seen;')+'\n'
code+=r'''
int checks=0;void check(bool ok,string why){if(!ok)throw std::runtime_error(why);++checks;std::cout<<"PASS "<<why<<"\n";}
void reset(){tick=1000;utc=1795853400;quoteTime=utc-3600*8;clockLastServer=clockServer=clockTick=clockOffset=0;clockKnown=false;clockSource="";clockSymbols.clear();clockSymbolTimes.clear();clockSymbolTicks.clear();quotes.clear();selected.clear();orders.clear();allowSelect=allowQuote=true;failTimesResize=false;selectCalls=quoteReads=0;}
void bitcoin(){orders={{"BTCUSD@",0},{"BTCUSD@",1}};quotes["BTCUSD@"]={utc+7200,60000,60001};}
int main(){
 reset();bitcoin();SampleBrokerClock();SamplePositionClocks();check(selected["BTCUSD@"]&&selectCalls==1&&quoteReads==1,"two BTC positions subscribe/read their exact symbol once per pulse");
 check(!clockKnown,"first cached BTC quote does not certify freshness");
 tick+=1000;utc++;quotes["BTCUSD@"].time++;SampleBrokerClock();SamplePositionClocks();
 check(BrokerClockKnown()&&Offset()=="7200"&&clockSource=="BTCUSD@","Saturday BTC quote calibrates while chart/terminal FX clock stays frozen");
 check(quoteTime<utc-3600&&ServerNow()==utc+7200,"broker clock follows active position instead of stale chart time");
 int before=selectCalls;tick+=1000;utc++;quotes["BTCUSD@"].time++;SamplePositionClocks();check(selectCalls==before&&clockTick==tick,"existing subscription reused and unchanged bid/ask with fresh quote time remains live");
 reset();SamplePositionClocks();check(selectCalls==0&&!clockKnown,"account without positions never guesses a crypto symbol or timezone");
 reset();bitcoin();allowSelect=false;SamplePositionClocks();check(!clockKnown&&quoteReads==0,"failed subscription is not treated as a live quote");
 reset();bitcoin();allowQuote=false;SamplePositionClocks();check(!clockKnown&&clockSymbols.empty(),"failed tick read cannot create clock proof");
 reset();bitcoin();quotes["BTCUSD@"].bid=NAN;SamplePositionClocks();check(!clockKnown&&clockSymbols.empty(),"nonfinite quote is rejected");
 reset();bitcoin();quotes["BTCUSD@"].ask=0;SamplePositionClocks();check(!clockKnown&&clockSymbols.empty(),"empty price quote is rejected");
 reset();bitcoin();SamplePositionClocks();tick+=1000;utc++;quotes["BTCUSD@"].time--;SamplePositionClocks();check(!clockKnown,"regressed position quote cannot certify freshness");
 reset();bitcoin();SamplePositionClocks();for(int i=0;i<10;i++){tick+=1000;utc++;SamplePositionClocks();}check(!clockKnown,"unchanged cached quote cannot turn into a fabricated live clock");
 reset();bitcoin();SamplePositionClocks();quotes["BTCUSD@"].time++;tick+=1000;utc++;SamplePositionClocks();tick+=86400001;utc+=86400;SamplePositionClocks();check(!BrokerClockKnown(),"heartbeat polling without fresh position quotes cannot renew expired clock");
 reset();bitcoin();orders.push_back({"EURUSD",2});SamplePositionClocks();check(!selected.count("EURUSD"),"pending orders are not added as position quote subscriptions");
 reset();bitcoin();selected["BTCUSD@"]=true;SamplePositionClocks();check(selectCalls==0,"user-selected symbol remains selected without redundant writes");
 reset();bitcoin();failTimesResize=true;SamplePositionClocks();check(clockSymbols.empty()&&clockSymbolTimes.empty(),"partial cache allocation failure rolls back both array lengths");
 reset();bitcoin();for(int i=0;i<256;i++){clockSymbols.push_back("OLD"+std::to_string(i));clockSymbolTimes.push_back(1);clockSymbolTicks.push_back(tick);}SamplePositionClocks();check(clockSymbols.size()==256&&selected["BTCUSD@"]&&!clockKnown,"clock cache stays bounded while actual position subscription is still enabled");
 reset();bitcoin();SamplePositionClocks();tick+=3600000;utc+=3600;quotes["BTCUSD@"].time+=1800;SamplePositionClocks();check(!clockKnown&&positionQuoteStatus=="rebaseline","returning to a symbol after a long gap cannot mistake a newer cached quote for fresh data");
 std::cout<<"MT4 POSITION CLOCK MOCK PASS "<<checks<<"\n";
}
'''
with tempfile.TemporaryDirectory(prefix='mf-position-clock-') as tmp:
    p=Path(tmp);(p/'test.cpp').write_text(code)
    subprocess.run(['g++','-std=c++17','-Wall','-Wextra',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
    subprocess.run([str(p/'test')],check=True)
assert 'SampleBrokerClock();\n   SamplePositionClocks();' in src
assert 'TimeDayOfWeek' not in src and 'DayOfWeek' not in src
print('MT4 quote sampling runs on timers without a weekday gate')
