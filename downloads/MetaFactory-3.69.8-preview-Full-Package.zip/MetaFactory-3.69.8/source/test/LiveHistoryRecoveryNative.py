"""Execute the actual MT4 recovery function bodies against a mocked terminal API.
This exercises native control flow with C++; it is not a MetaEditor/Windows broker test.
"""
from pathlib import Path
import subprocess,tempfile
src=(Path(__file__).resolve().parents[1]/'report/MTManagerLive.mq4').read_text()
def function(signature):
 start=src.index(signature); brace=src.index('{',start);depth=1;i=brace+1
 while depth:
  if src[i]=='{':depth+=1
  elif src[i]=='}':depth-=1
  i+=1
 return src[start:i]
code=r'''
#include <string>
#include <vector>
#include <cstdint>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <stdexcept>
using string=std::string;using uint=uint32_t;
uint tick=1000,allHistoryAskedAt=0,lastPoll=0,lastHistoryCheck=0,recoveryStarted=0,stableSince=0,bootTick=0;
bool allHistoryAttempted=false,posted=false,historyScanOk=false,dll=true,restoreOnRequest=false,postOk=true,connected=true,identity=true,backedOff=false,dirty=true,exportTrusted=false,writeOk=true,sourceOk=true;
int chart=1,window=2,requests=0,scans=0,exports=0,histCount=0,sourceCount=10,observedCount=0;
double sumAll=0,sourceSum=1000,balance=1000,observedBalance=0,observedCredit=0;
uint historyHash1=1,historyHash2=2;long revision=0,exportRevision=0;
string liveState="bootstrap",stableSignature="",exportedSignature="",previousOpenKey="",previousDay="2026.11.27",OutFile="",rootPath="synthetic",diagnostic;
const int CHART_WINDOW_HANDLE=1;
uint GetTickCount(){return tick;}bool IsDllsAllowed(){return dll;}
int ChartGetInteger(int,int){return chart;}int WindowHandle(string,int){return chart;}
string Offset(){return "";}
string Symbol(){return "EURUSD";}int Period(){return 1;}int GetAncestor(int,int){return window;}
int PostMessageW(int,int,int command,int){if(command!=33058)throw std::runtime_error("wrong command");requests++;if(postOk&&restoreOnRequest){sourceSum=balance;sourceCount=10;}return postOk?1:0;}
void AddUp(){scans++;histCount=sourceCount;sumAll=sourceSum;historyScanOk=sourceOk;}
double Balance(){return balance;}double Credit(){return 0;}double MathAbs(double n){return std::abs(n);}double MathMax(double a,double b){return std::max(a,b);}
bool ExpectedAccount(){return identity;}bool Connected(){return connected;}
int ScannedCount(){return histCount;}int HistoryCount(){return sourceCount;}
template<class T> string IntegerToString(T v){return std::to_string(v);}string N(double n){return std::to_string(n);}
void HistoryDiagnostic(string s){diagnostic=s;}
bool ExportReport(){exports++;exportTrusted=historyScanOk&&posted&&std::abs(sumAll-balance)<.02;return exportTrusted;}
'''
code+='\n'.join(function(s) for s in ['void AskAllHistory()','bool AddsUp()','bool ScanHistory()','bool HistoryTrusted()','void PollHistory()'])
code+=r'''
int checks=0;void check(bool ok,string why){if(!ok)throw std::runtime_error(why);checks++;std::cout<<"PASS "<<why<<"\n";}
void reset(){tick=1000;allHistoryAskedAt=lastPoll=lastHistoryCheck=recoveryStarted=stableSince=bootTick=0;allHistoryAttempted=posted=backedOff=false;historyScanOk=dll=postOk=connected=identity=sourceOk=true;restoreOnRequest=false;requests=scans=exports=0;sourceSum=balance=1000;sourceCount=10;revision=exportRevision=0;stableSignature=exportedSignature="";liveState="bootstrap";dirty=true;}
int main(){
 reset();PollHistory();check(requests==1&&revision==0,"bootstrap requests all history and waits for stability");tick=4000;PollHistory();check(revision==1&&liveState=="ready","reconciled stable baseline is published");
 tick=20000;sourceSum=50;sourceCount=2;restoreOnRequest=true;dirty=true;PollHistory();check(requests==2&&revision==1,"already-posted request is retried after filter truncation");tick=22000;PollHistory();tick=24000;PollHistory();check(liveState=="ready"&&!dirty&&exports==1,"recovered unchanged history reuses proof without needless full export");
 int before=requests;for(int n=0;n<100;n++){tick+=1000;ScanHistory();}check(requests==before,"healthy history never receives repeated filter commands");
 reset();posted=true;sourceSum=40;tick=20000;ScanHistory();tick=25000;ScanHistory();check(requests==1,"mismatch retry is limited to once per ten seconds");tick=30000;ScanHistory();check(requests==2,"persistent mismatch is retried after bounded interval");
 reset();dll=false;PollHistory();tick=4000;PollHistory();check(revision==0&&exports==0&&diagnostic=="all-history-request-unavailable","missing DLL permission never creates trusted history");dll=true;tick=12000;PollHistory();tick=14000;PollHistory();check(revision==1&&requests==1,"permission restored can recover without restarting observer");
 reset();posted=true;sourceSum=40;for(int n=0;n<100;n++){tick=1000+n*30000;PollHistory();}check(revision==0&&exports==0&&requests>2,"thirty minutes of unreconciled history never publishes false success");check(diagnostic=="history-balance-mismatch","persistent mismatch records its exact reason");
 reset();sourceSum=40;postOk=false;ScanHistory();tick+=10000;postOk=true;ScanHistory();check(posted&&requests==2,"failed Windows command is retried rather than permanently assumed successful");
 reset();sourceSum=40;tick=UINT32_MAX-5000;ScanHistory();tick=1000;ScanHistory();check(requests==1,"retry throttle handles tick-counter wrap");tick=6000;ScanHistory();check(requests==2,"retry resumes after wrapped interval");
 reset();sourceOk=false;PollHistory();check(revision==0&&exports==0&&diagnostic=="scan-or-connection-incomplete","partial scan cannot publish history");
 std::cout<<"NATIVE RECOVERY MOCK PASS "<<checks<<"\n";
}
'''
with tempfile.TemporaryDirectory(prefix='mf-history-') as d:
 p=Path(d);(p/'test.cpp').write_text(code)
 subprocess.run(['g++','-std=c++17','-Wall','-Wextra',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
