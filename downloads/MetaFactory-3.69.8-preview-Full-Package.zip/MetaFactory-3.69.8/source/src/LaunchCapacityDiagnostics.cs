using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace MTManager
{
    /// <summary>Read-only, bounded launch observations. A retained Windows duplicate handle preserves the real exit code.
    /// The original Process belongs to the launcher and is never disposed, closed or killed by this observer.</summary>
    public static class LaunchCapacityDiagnostics
    {
        const int HistoryLimit = 256, WatchLimit = 512;
        static readonly object Gate = new object();
        static readonly List<Entry> Watching = new List<Entry>();
        static readonly Queue<string> History = new Queue<string>();
        static readonly Queue<string> PendingLog = new Queue<string>();
        static readonly ConditionalWeakTable<Process, object> Seen = new ConditionalWeakTable<Process, object>();
        static bool logScheduled;
        static Timer timer;
        static int sampling, sequence;
        static readonly bool Windows = Environment.OSVersion.Platform == PlatformID.Win32NT;

        public sealed class ResourceSnapshot
        {
            public long TotalPhysicalMb = -1, AvailablePhysicalMb = -1;
            public long CommitUsedMb = -1, CommitLimitMb = -1, CommitPeakMb = -1;
            // UOI_HEAPSIZE is the live desktop's allocated heap size, NOT current heap usage.
            public long ObserverDesktopHeapKb = -1;
            public string Text()
            {
                return "ram-total-mb=" + N(TotalPhysicalMb) + " ram-free-mb=" + N(AvailablePhysicalMb) +
                    " commit-used-mb=" + N(CommitUsedMb) + " commit-limit-mb=" + N(CommitLimitMb) +
                    " commit-peak-mb=" + N(CommitPeakMb) + " observer-live-desktop-heap-kb=" + N(ObserverDesktopHeapKb);
            }
        }

        sealed class Entry
        {
            public int Number, Pid;
            public string Copy;
            public Process BorrowedProcess;
            public IntPtr Handle;
            public readonly Stopwatch Age = Stopwatch.StartNew();
            public int? ExitCode;
            public long Handles = -1, UserObjects = -1, GdiObjects = -1, PrivateBytes = -1, WorkingSetBytes = -1;
            public bool Missing, Sampled;
            public string Counters() { return "handles=" + N(Handles) + " user=" + N(UserObjects) + " gdi=" + N(GdiObjects) + " private-bytes=" + N(PrivateBytes) + " working-set-bytes=" + N(WorkingSetBytes); }
            public void Release()
            {
                if (Handle != IntPtr.Zero) { try { CloseHandle(Handle); } catch { } Handle = IntPtr.Zero; }
                BorrowedProcess = null; // The caller owns the object; never Dispose it.
            }
        }

        static string N(long value) { return value < 0 ? "unknown" : value.ToString(CultureInfo.InvariantCulture); }
        public static string SafeCopy(string value)
        {
            string clean = Regex.Replace(value ?? "unknown", @"[^\p{L}\p{N}_.-]", "_");
            return clean.Length > 64 ? clean.Substring(0, 64) : clean;
        }

        public static string ExitEvidence(int? exitCode, ResourceSnapshot snapshot)
        {
            string text;
            if (!exitCode.HasValue) text = "exit-code=unknown; cause unknown";
            else
            {
                uint code = unchecked((uint)exitCode.Value);
                text = "exit-code=" + exitCode.Value.ToString(CultureInfo.InvariantCulture) + " (0x" + code.ToString("X8", CultureInfo.InvariantCulture) + ")";
                if (code == 0) text += "; normal exit code; cause unknown";
                else if (code == 0xC0000017 || code == 0xC000009A || code == 0xC000012D)
                    text += "; native memory/resource status reported; investigate resource limits";
                else text += "; nonzero exit; cause unknown";
            }
            if (snapshot != null && ((snapshot.AvailablePhysicalMb >= 0 && snapshot.AvailablePhysicalMb < 512) ||
                (snapshot.CommitLimitMb >= 0 && snapshot.CommitUsedMb >= 0 && snapshot.CommitLimitMb - snapshot.CommitUsedMb < 512)))
                text += "; low resource headroom observed, not proof of exit cause";
            return text;
        }

        static void AddRecord(string record)
        {
            History.Enqueue(record);
            while (History.Count > HistoryLimit) History.Dequeue();
            PendingLog.Enqueue(record);
            while (PendingLog.Count > HistoryLimit) PendingLog.Dequeue();
            if (!logScheduled) { logScheduled = true; ThreadPool.QueueUserWorkItem(_ => FlushLogs()); }
        }

        static void FlushLogs()
        {
            while (true)
            {
                string record;
                lock (Gate)
                {
                    if (PendingLog.Count == 0) { logScheduled = false; return; }
                    record = PendingLog.Dequeue();
                }
                Log.Write("launch capacity: " + record);
            }
        }

        public static void Watch(Process process, string copy)
        {
            if (process == null) return;
            var entry = new Entry { Copy = SafeCopy(copy), BorrowedProcess = process };
            try { entry.Pid = process.Id; }
            catch { return; }
            if (Windows)
            {
                try
                {
                    IntPtr self = GetCurrentProcess();
                    IntPtr duplicate;
                    if (DuplicateHandle(self, process.Handle, self, out duplicate, 0, false, 2)) entry.Handle = duplicate;
                }
                catch { }
            }
            lock (Gate)
            {
                // Weak keys prevent duplicate observations even if a rapid exit happened between two Watch calls.
                object seen;
                if (Seen.TryGetValue(process, out seen)) { entry.Release(); return; }
                entry.Number = ++sequence;
                LaunchEvidence.Observe(()=>LaunchEvidence.Started(process,copy,entry.Number));
                if (Watching.Count >= WatchLimit)
                {
                    AddRecord("observer capacity reached; copy=" + entry.Copy + "; terminal launch is unaffected"); entry.Release(); return;
                }
                Seen.Add(process, new object());
                Watching.Add(entry);
                AddRecord("watch=" + entry.Number + " copy=" + entry.Copy + " pid=" + entry.Pid + " retained-handle=" + (entry.Handle != IntPtr.Zero));
                if (timer == null) timer = new Timer(Sample, null, 0, 1000);
            }
        }

        public static void Failure(string copy, Exception error)
        {
            int? native = null;
            for (Exception e = error; e != null; e = e.InnerException)
            {
                var win32 = e as Win32Exception;
                if (win32 != null) { native = win32.NativeErrorCode; break; }
            }
            // Exception messages may contain command arguments; collect type and native code only.
            string line = "launch-failed copy=" + SafeCopy(copy) + " exception=" + (error == null ? "unknown" : error.GetType().Name) +
                " native-code=" + (native.HasValue ? native.Value.ToString(CultureInfo.InvariantCulture) : "unknown");
            ThreadPool.QueueUserWorkItem(_ => { var resources = CaptureResources(); lock (Gate) AddRecord(line + " " + resources.Text()); });
        }

        static bool Finished(Entry entry)
        {
            if (entry.Handle != IntPtr.Zero)
            {
                uint wait = WaitForSingleObject(entry.Handle, 0);
                if (wait == 258) return false; // WAIT_TIMEOUT; exit code 259 can also be a legitimate final exit code.
                if (wait == 0)
                {
                    uint code;
                    if (GetExitCodeProcess(entry.Handle, out code)) entry.ExitCode = unchecked((int)code);
                    return true;
                }
                entry.Missing = true; return true;
            }
            try
            {
                if (!entry.BorrowedProcess.HasExited) return false;
                entry.ExitCode = entry.BorrowedProcess.ExitCode;
            }
            catch { entry.Missing = true; }
            return true;
        }

        static void Sample(object state)
        {
            if (Interlocked.Exchange(ref sampling, 1) != 0) return;
            try
            {
                var resources = CaptureResources();
                lock (Gate)
                {
                    for (int n = Watching.Count - 1; n >= 0; n--)
                    {
                        Entry entry = Watching[n];
                        bool done;
                        try { done = Finished(entry); }
                        catch { entry.Missing = true; done = true; }
                        if (!done)
                        {
                            try
                            {
                                if (entry.Handle != IntPtr.Zero)
                                {
                                    uint count;
                                    if (GetProcessHandleCount(entry.Handle, out count)) entry.Handles = count;
                                    entry.UserObjects = GuiCount(entry.Handle, 1); entry.GdiObjects = GuiCount(entry.Handle, 0);
                                    var memory = new ProcessMemoryCounters { Size = (uint)Marshal.SizeOf(typeof(ProcessMemoryCounters)) };
                                    if (GetProcessMemoryInfo(entry.Handle, ref memory, memory.Size))
                                    {
                                        entry.PrivateBytes = (long)memory.PrivateUsage.ToUInt64();
                                        entry.WorkingSetBytes = (long)memory.WorkingSetSize.ToUInt64();
                                    }
                                }
                                else
                                {
                                    try
                                    {
                                        entry.BorrowedProcess.Refresh(); entry.Handles = entry.BorrowedProcess.HandleCount;
                                        entry.PrivateBytes = entry.BorrowedProcess.PrivateMemorySize64;
                                        entry.WorkingSetBytes = entry.BorrowedProcess.WorkingSet64;
                                    }
                                    catch { }
                                }
                            }
                            catch { /* diagnostic access failure must never stop a launch or crash the application */ }
                            LaunchEvidence.Observe(()=>LaunchEvidence.Sample(entry.Copy,entry.Pid,entry.Counters(),resources,false,null,entry.Number));
                            LaunchComparison.Observe(entry.BorrowedProcess,entry.Copy,resources,false,entry.PrivateBytes,entry.WorkingSetBytes);
                            if (!entry.Sampled)
                            {
                                entry.Sampled = true;
                                AddRecord("first-live watch=" + entry.Number + " copy=" + entry.Copy + " pid=" + entry.Pid + " " + entry.Counters() + " " + resources.Text());
                            }
                            continue;
                        }
                        LaunchEvidence.Observe(()=>LaunchEvidence.Sample(entry.Copy,entry.Pid,entry.Counters(),resources,true,entry.ExitCode,entry.Number));
                        AddRecord("exit watch=" + entry.Number + " copy=" + entry.Copy + " pid=" + entry.Pid +
                            " age-ms=" + entry.Age.ElapsedMilliseconds + " " + ExitEvidence(entry.ExitCode, resources) +
                            (entry.Missing ? "; process observation unavailable" : "") + " last-live-" + entry.Counters() + " " + resources.Text());
                        LaunchComparison.Observe(entry.BorrowedProcess,entry.Copy,resources,true,entry.PrivateBytes,entry.WorkingSetBytes);
                        entry.Release(); Watching.RemoveAt(n);
                    }
                    if (Watching.Count == 0 && timer != null) { timer.Dispose(); timer = null; }
                }
            }
            finally { Interlocked.Exchange(ref sampling, 0); }
        }

        public static string Summary()
        {
            ResourceSnapshot resources = CaptureResources();
            lock (Gate)
            {
                var sb = new StringBuilder("— Launch capacity observations (unknown is not zero; no count-based diagnosis) —\n");
                sb.AppendLine(resources.Text());
                sb.AppendLine("Live desktop heap is allocated capacity, not usage; USER/GDI counts are per process, not a 10000 aggregate cap.");
                foreach (var entry in Watching)
                    sb.AppendLine("active watch=" + entry.Number + " copy=" + entry.Copy + " pid=" + entry.Pid + " age-ms=" + entry.Age.ElapsedMilliseconds + " " + entry.Counters());
                foreach (string line in History) sb.AppendLine(line);
                return sb.ToString();
            }
        }

        public static void StopWatching()
        {
            lock (Gate)
            {
                if (timer != null) { timer.Dispose(); timer = null; }
                foreach (var entry in Watching) entry.Release();
                Watching.Clear();
            }
        }

        static long GuiCount(IntPtr handle, uint kind)
        {
            SetLastError(0); uint n = GetGuiResources(handle, kind);
            return n == 0 && Marshal.GetLastWin32Error() != 0 ? -1 : (long)n;
        }

        public static ResourceSnapshot CaptureResources()
        {
            var result = new ResourceSnapshot();
            if (!Windows) return result;
            try
            {
                var m = new MemoryStatus { Length = (uint)Marshal.SizeOf(typeof(MemoryStatus)) };
                if (GlobalMemoryStatusEx(ref m)) { result.TotalPhysicalMb = (long)(m.TotalPhys / 1048576); result.AvailablePhysicalMb = (long)(m.AvailPhys / 1048576); }
                var p = new PerformanceInfo { Size = (uint)Marshal.SizeOf(typeof(PerformanceInfo)) };
                if (GetPerformanceInfo(ref p, p.Size))
                {
                    result.CommitUsedMb = Mb(p.CommitTotal, p.PageSize); result.CommitLimitMb = Mb(p.CommitLimit, p.PageSize); result.CommitPeakMb = Mb(p.CommitPeak, p.PageSize);
                }
                uint heap, needed;
                if (GetUserObjectInformation(GetThreadDesktop(GetCurrentThreadId()), 5, out heap, 4, out needed)) result.ObserverDesktopHeapKb = heap;
            }
            catch { /* unavailable metrics remain unknown; never invent zero */ }
            return result;
        }
        static long Mb(UIntPtr pages, UIntPtr size) { return (long)(pages.ToUInt64() * size.ToUInt64() / 1048576); }
        [StructLayout(LayoutKind.Sequential)] struct MemoryStatus
        { public uint Length, Load; public ulong TotalPhys, AvailPhys, TotalPageFile, AvailPageFile, TotalVirtual, AvailVirtual, AvailExtendedVirtual; }
        [StructLayout(LayoutKind.Sequential)] struct PerformanceInfo
        {
            public uint Size;
            public UIntPtr CommitTotal, CommitLimit, CommitPeak, PhysicalTotal, PhysicalAvailable, SystemCache, KernelTotal, KernelPaged, KernelNonpaged, PageSize;
            public uint HandleCount, ProcessCount, ThreadCount;
        }
        [StructLayout(LayoutKind.Sequential)] struct ProcessMemoryCounters
        {
            public uint Size, PageFaultCount;
            public UIntPtr PeakWorkingSetSize, WorkingSetSize, QuotaPeakPagedPoolUsage, QuotaPagedPoolUsage,
                QuotaPeakNonPagedPoolUsage, QuotaNonPagedPoolUsage, PagefileUsage, PeakPagefileUsage, PrivateUsage;
        }
        [DllImport("psapi.dll", SetLastError = true)] static extern bool GetProcessMemoryInfo(IntPtr handle, ref ProcessMemoryCounters counters, uint size);
        [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool DuplicateHandle(IntPtr from, IntPtr source, IntPtr to, out IntPtr duplicate, uint access, bool inherit, uint options);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
        [DllImport("kernel32.dll", SetLastError = true)] static extern uint WaitForSingleObject(IntPtr handle, uint milliseconds);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool GetExitCodeProcess(IntPtr handle, out uint code);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool GetProcessHandleCount(IntPtr handle, out uint count);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool GlobalMemoryStatusEx(ref MemoryStatus status);
        [DllImport("psapi.dll", SetLastError = true)] static extern bool GetPerformanceInfo(ref PerformanceInfo info, uint size);
        [DllImport("user32.dll", SetLastError = true)] static extern uint GetGuiResources(IntPtr handle, uint flags);
        [DllImport("kernel32.dll")] static extern void SetLastError(uint code);
        [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
        [DllImport("user32.dll")] static extern IntPtr GetThreadDesktop(uint id);
        [DllImport("user32.dll", EntryPoint = "GetUserObjectInformationW", SetLastError = true)] static extern bool GetUserObjectInformation(IntPtr obj, int index, out uint data, uint length, out uint needed);
    }
}
