using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;
namespace MTManager
{
    // Bounded A/B evidence, never credentials. Unknown timings are never replaced with zero.
    public static class LaunchComparison
    {
        public sealed class Item
        {
            public string Copy, Platform, Error;
            public int Pid, ReporterConfigured=-1, Restarts;
            public List<int> Pids=new List<int>();
            public string ObserverNote;
            public bool CpuPartial;
            public DateTime RequestedUtc, ProcessUtc, CurrentProcessUtc;
            public long PreparationMs=-1, SpawnMs=-1, WindowMs=-1, FreshMs=-1, CpuMs=-1, PeakPrivateMb=-1, PeakWorkingMb=-1;
            public bool Exited;
            internal Process Process;
            internal bool OwnsProcess;
            internal Stopwatch Clock;
            internal long LastSampleMs=-5000, CompletedCpuMs, SegmentCpuMs=-1;
            internal string ExpectedExe, AccountKey;
            internal bool SegmentFinished;
        }
        public sealed class Run
        {
            public string Id, Mode, Cohort, Conditions;
            public DateTime StartedUtc;
            public int OtherRunning;
            public long FreeBeforeMb=-1, MinFreeMb=-1, CommitBeforeMb=-1, CommitLimitMb=-1;
            public List<Item> Items=new List<Item>();
        }
        static readonly object Gate=new object();
        static List<Run> runs;
        static Run current;
        static DateTime savedUtc;
        static bool dirty;
        public static string FilePath { get { return Path.Combine(AppPaths.DataDir,"launch-comparison.json"); } }
        static string Hash(string text) { using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(text))).Replace("-","").ToLowerInvariant(); }
        static string AccountIdentity(Account account,Kind kind)
        {return Hash(kind+":"+(account==null?"no-account":(account.Login??"").Trim()+"@"+(account.Server??"").Trim()));}
        static void ReleaseOwnedProcess(Item item)
        {
            if(item.OwnsProcess && item.Process!=null){try{item.Process.Dispose();}catch{}}
            item.OwnsProcess=false;
        }
        public static void ReleaseObservedProcesses()
        {
            lock(Gate){if(runs==null)return;foreach(var run in runs)foreach(var item in run.Items){ReleaseOwnedProcess(item);item.Process=null;}}
        }
        static void Load()
        {
            if(runs!=null)return;runs=new List<Run>();
            try { if(File.Exists(FilePath) && new FileInfo(FilePath).Length<=1024*1024)
            { var values=new JavaScriptSerializer{MaxJsonLength=1024*1024}.Deserialize<List<Run>>(File.ReadAllText(FilePath));
                if(values!=null && values.Count<=8 && values.All(r=>r!=null && (r.Mode=="plain"||r.Mode=="live") && r.Items!=null && r.Items.Count<=128 && r.Items.All(i=>i!=null && i.Copy!=null && i.Copy.Length<=64)))runs=values;
            }}catch{ }
        }
        static void Save(bool force=false)
        {
            dirty=true;if(!force && (DateTime.UtcNow-savedUtc).TotalSeconds<5)return;
            try { TextUtil.WriteLinesAtomically(FilePath,new[]{new JavaScriptSerializer{MaxJsonLength=1024*1024}.Serialize(runs)});dirty=false;savedUtc=DateTime.UtcNow; }
            catch(Exception e){Log.Write("launch comparison persistence: "+e.GetType().Name);}
        }
        public static void Begin(bool live,IEnumerable<Instance> copies,Settings settings,AccountStore accounts,int otherRunning)
        {
            try {lock(Gate){Load();var list=copies.Take(128).ToList();var resources=LaunchCapacityDiagnostics.CaptureResources();
                current=new Run{Id=Guid.NewGuid().ToString("N"),Mode=live?"live":"plain",StartedUtc=DateTime.UtcNow,OtherRunning=otherRunning,
                    FreeBeforeMb=resources.AvailablePhysicalMb,MinFreeMb=resources.AvailablePhysicalMb,CommitBeforeMb=resources.CommitUsedMb,CommitLimitMb=resources.CommitLimitMb,
                    Conditions="version="+AppInfo.Version+" mt5-pacing=bounded-memory delay="+settings.DelaySeconds+" minimized="+settings.Minimized+" light="+settings.Light+" charts="+settings.StartCharts+" low-priority="+settings.LowPriority+" sandbox="+settings.SandboxieOverflow+" trim="+settings.TrimMemory,
                    Cohort=Hash(string.Join("|",list.OrderBy(i=>i.Name,StringComparer.OrdinalIgnoreCase).Select(i=>{var a=accounts.Get(i.Name);return i.Name+":"+i.Kind+":"+(a==null?"":a.Login+"@"+a.Server);}))),
                    Items=list.Select(i=>new Item{Copy=LaunchCapacityDiagnostics.SafeCopy(i.Name),Platform=i.Kind.ToString(),RequestedUtc=DateTime.UtcNow,AccountKey=AccountIdentity(accounts.Get(i.Name),i.Kind)}).ToList()};
                runs.Add(current);while(runs.Count>8){foreach(var item in runs[0].Items)ReleaseOwnedProcess(item);runs.RemoveAt(0);}Save(true);
                Log.Write("launch A/B begin "+current.Id+" mode="+current.Mode+" count="+list.Count+" other-running="+otherRunning);
            }}catch(Exception e){Log.Write("launch comparison begin: "+e.GetType().Name);}
        }
        static Item Find(string copy) {string key=LaunchCapacityDiagnostics.SafeCopy(copy);return current==null?null:current.Items.LastOrDefault(i=>i.Copy==key && i.Pid==0);}
        public static void Preparing(Instance copy)
        {try{lock(Gate){var item=Find(copy.Name);if(item!=null)item.Clock=Stopwatch.StartNew();}}catch{}}
        public static void Prepared(Instance copy,bool reporterConfigured=false)
        {try{lock(Gate){var item=Find(copy.Name);if(item!=null && item.Clock!=null){item.PreparationMs=item.Clock.ElapsedMilliseconds;item.ReporterConfigured=reporterConfigured?1:0;}}}catch{}}
        public static void Started(Instance copy,Process process)
        {try{lock(Gate){var item=Find(copy.Name);if(item==null||process==null)return;item.Pid=process.Id;item.Process=process;item.ProcessUtc=item.CurrentProcessUtc=DateTime.UtcNow;item.ExpectedExe=Path.GetFullPath(copy.Exe);item.Pids=new List<int>{item.Pid};
            item.SpawnMs=item.Clock==null||item.PreparationMs<0?-1:item.Clock.ElapsedMilliseconds-item.PreparationMs;Save();}}catch{}}
        static void CompleteCpuSegment(Item item)
        {
            if(item.SegmentFinished)return;
            try{if(item.Process!=null)item.SegmentCpuMs=Math.Max(item.SegmentCpuMs,(long)item.Process.TotalProcessorTime.TotalMilliseconds);}catch{}
            if(item.SegmentCpuMs>=0){item.CompletedCpuMs+=item.SegmentCpuMs;item.CpuMs=item.CompletedCpuMs;}
            else item.CpuPartial=true;
            item.SegmentFinished=true;
        }
        public static void ReboundAfterUpdate(Instance copy,Process process,Account account)
        {
            if(copy==null || process==null)return;
            Process retained=null;bool attached=false;
            try
            {
                string key=LaunchCapacityDiagnostics.SafeCopy(copy.Name);
                lock(Gate){Load();var latest=runs.AsEnumerable().Reverse().SelectMany(r=>r.Items.Where(i=>i.Copy==key)).FirstOrDefault();if(latest==null || latest.Pid==process.Id)return;}
                // The caller's enumeration object is disposed after RefreshGrid. Own a distinct wrapper.
                // Compare the kernel creation time as well as the exact image path to reject PID reuse.
                DateTime created=process.StartTime.ToUniversalTime();
                retained=Process.GetProcessById(process.Id);
                if(retained.HasExited || retained.StartTime.ToUniversalTime()!=created)return;
                string observed=Processes.PathOf(retained);if(observed==null)return;
                if(!string.Equals(Path.GetFullPath(observed),Path.GetFullPath(copy.Exe),StringComparison.OrdinalIgnoreCase))return;
                lock(Gate)
                {
                    foreach(var run in runs.AsEnumerable().Reverse())
                    {
                        var item=run.Items.LastOrDefault(i=>i.Copy==key);if(item==null)continue;
                        if(item.AccountKey!=AccountIdentity(account,copy.Kind)){item.ObserverNote="account changed during launch observation";Save();return;}
                        if(item.ExpectedExe==null || !string.Equals(item.ExpectedExe,Path.GetFullPath(copy.Exe),StringComparison.OrdinalIgnoreCase))return;
                        if(item.Pid==retained.Id)return;
                        if(item.Pids==null)item.Pids=new List<int>();
                        if(item.Pids.Contains(retained.Id) || item.Pids.Count>=8){item.ObserverNote="ambiguous-or-over-limit PID chain; observation unchanged";Save();return;}
                        if(created<item.RequestedUtc.AddSeconds(-1))return;
                        if(item.Process!=null && !item.Process.HasExited)return;
                        CompleteCpuSegment(item);ReleaseOwnedProcess(item);
                        item.Process=retained;item.OwnsProcess=true;attached=true;
                        item.Pid=retained.Id;item.Pids.Add(item.Pid);item.Restarts++;
                        item.CurrentProcessUtc=DateTime.UtcNow;item.LastSampleMs=-5000;item.SegmentCpuMs=-1;item.SegmentFinished=false;item.Exited=false;
                        item.ObserverNote="managed updater PID hand-off observed; independent observer handle; elapsed time anchored to original launch";
                        Save();break;
                    }
                }
                if(attached)LaunchCapacityDiagnostics.Watch(retained,copy.Name);
            }
            catch(Exception e){Log.Write("launch comparison rebind: "+e.GetType().Name);}
            finally{if(!attached && retained!=null)retained.Dispose();}
        }
        public static void Failure(string copy,Exception error)
        {try{lock(Gate){var item=Find(copy);if(item==null)return;item.Error=error.GetType().Name;Save(true);}}catch{}}
        public static bool IsPlain(string copy)
        {
            try{string key=LaunchCapacityDiagnostics.SafeCopy(copy);lock(Gate){Load();foreach(var run in runs.AsEnumerable().Reverse()){var item=run.Items.LastOrDefault(i=>i.Copy==key);
                if(item==null)continue;return run.Mode=="plain" && item.Process!=null && !item.Process.HasExited;}}}catch{}return false;
        }
        public static void Fresh(Instance copy,Account account,DateTime heartbeatUtc)
        {
            try{string key=LaunchCapacityDiagnostics.SafeCopy(copy.Name);lock(Gate){Load();foreach(var run in runs.AsEnumerable().Reverse()){var item=run.Items.LastOrDefault(i=>i.Copy==key);if(item==null)continue;
                if(item.AccountKey!=AccountIdentity(account,copy.Kind))break;
                if(run.Mode=="live" && item.ProcessUtc!=DateTime.MinValue && heartbeatUtc>=item.CurrentProcessUtc && item.FreshMs<0 && item.Process!=null && !item.Exited && !item.Process.HasExited)
                {item.FreshMs=(long)Math.Max(0,(DateTime.UtcNow-item.ProcessUtc).TotalMilliseconds);LaunchEvidence.Observe(()=>LaunchEvidence.Stage(copy.Name,"verified_live_dashboard",item.Pid));Save();}break;}}}catch{}
        }
        public static void Observe(Process process,string copy,LaunchCapacityDiagnostics.ResourceSnapshot resources,bool exited,long privateBytes,long workingBytes)
        {
            try{string key=LaunchCapacityDiagnostics.SafeCopy(copy);lock(Gate){Load();Run owner=null;Item item=null;
                foreach(var run in runs.AsEnumerable().Reverse()){item=run.Items.LastOrDefault(i=>i.Copy==key && i.Process==process);if(item!=null){owner=run;break;}}
                if(item==null)return;if(exited){CompleteCpuSegment(item);ReleaseOwnedProcess(item);item.Exited=true;item.Process=null;Save();return;}
                long age=(long)(DateTime.UtcNow-item.CurrentProcessUtc).TotalMilliseconds;
                long chainAge=(long)(DateTime.UtcNow-item.ProcessUtc).TotalMilliseconds;
                if(age<=600000 && item.WindowMs<0){process.Refresh();if(process.MainWindowHandle!=IntPtr.Zero){item.WindowMs=chainAge;Save();}}
                if(age>120000 || age-item.LastSampleMs<5000)return;item.LastSampleMs=age;
                if(privateBytes>=0)item.PeakPrivateMb=Math.Max(item.PeakPrivateMb,privateBytes/1048576);
                if(workingBytes>=0)item.PeakWorkingMb=Math.Max(item.PeakWorkingMb,workingBytes/1048576);
                item.SegmentCpuMs=(long)process.TotalProcessorTime.TotalMilliseconds;item.CpuMs=item.CompletedCpuMs+item.SegmentCpuMs;
                if(resources.AvailablePhysicalMb>=0)owner.MinFreeMb=owner.MinFreeMb<0?resources.AvailablePhysicalMb:Math.Min(owner.MinFreeMb,resources.AvailablePhysicalMb);Save();
            }}catch{ }
        }
        static string N(long n) { return n<0?"unknown":n.ToString(CultureInfo.InvariantCulture); }
        static string Mean(IEnumerable<long> values) {var all=values.Where(x=>x>=0).ToArray();return all.Length==0?"unknown":all.Average().ToString("0",CultureInfo.InvariantCulture)+" ms (n="+all.Length+")";}
        public static string Summary()
        {
            lock(Gate){Load();if(dirty)Save(true);var text=new StringBuilder("— Launch A/B comparison —\r\n");
                text.AppendLine("plain = isolated empty profile without report EA/preflight/compiler; live = original live preparation. Measures the entire live path, NOT the EA alone.");
                text.AppendLine("Close the same accounts before each run. Disable folder auto-refresh and scheduled delivery; do not Refresh reports or prepare reporters during the test. Use the same delay and wait 2 minutes after the last start. Repeat in reversed order: cache, vendor updates and network can affect results.");
                text.AppendLine("Window is first observed HWND, NOT proof of broker connection; window/live durations start when the launcher returns a PID; live-ready requires fresh verified dashboard data. Missing/closed-before-ready timings remain unknown. Resource samples every 5s for first 120s per PID; window observation up to 10min per PID. Managed native update restarts retain original elapsed times and get new PID observations; live-ready still requires a fresh validated native frame. CPU covers observed PID segments; cpu-partial identifies missing segments. Preparation excludes first-copy provisioning; batch-to-launch-return includes queue/provisioning and configured delays. Spawn includes Sandboxie migration/PID discovery. CPU is cumulative process CPU time, not percent. Per-process peaks must not be added as simultaneous RAM.");
                text.AppendLine("Rows with pid-chain=legacy-untracked retain old observations; missed past updater restarts/readiness are not reconstructed.");
                var plain=runs.LastOrDefault(r=>r.Mode=="plain");var live=runs.LastOrDefault(r=>r.Mode=="live");
                if(plain!=null && live!=null)text.AppendLine("Latest pair setup: "+(plain.Cohort==live.Cohort && plain.Conditions==live.Conditions && plain.OtherRunning==live.OtherRunning?"same cohort/settings/other-running count; resource baselines and external effects still differ":"MISMATCH: cohort, settings or other-running count differs; not a controlled pair"));
                foreach(var run in runs){text.AppendLine("Run "+run.Id+" "+run.StartedUtc.ToString("u")+" mode="+run.Mode+" requested="+run.Items.Count+" started="+run.Items.Count(i=>i.Pid>0)+" windows="+run.Items.Count(i=>i.WindowMs>=0)+" live-ready="+run.Items.Count(i=>i.FreshMs>=0)+" failed="+run.Items.Count(i=>i.Error!=null)+" other-running="+run.OtherRunning+" free-before-mb="+N(run.FreeBeforeMb)+" min-free-mb="+N(run.MinFreeMb)+" commit-before-mb="+N(run.CommitBeforeMb)+" commit-limit-mb="+N(run.CommitLimitMb));
                    text.AppendLine(run.Conditions);text.AppendLine("mean preparation="+Mean(run.Items.Select(i=>i.PreparationMs))+"; first-window-after-launch-return="+Mean(run.Items.Select(i=>i.WindowMs))+"; verified-live="+(run.Mode=="plain"?"N/A":Mean(run.Items.Select(i=>i.FreshMs))));
                    foreach(var i in run.Items)text.AppendLine(i.Copy+" "+i.Platform+" pid="+i.Pid+" pid-chain="+(i.Pids==null||i.Pids.Count==0?"legacy-untracked":string.Join(",",i.Pids))+" restarts="+i.Restarts+" cpu-partial="+i.CpuPartial+" reporter-startup-configured="+N(i.ReporterConfigured)+" batch-to-launch-return-ms="+(i.ProcessUtc==DateTime.MinValue?"unknown":Math.Max(0,(long)(i.ProcessUtc-run.StartedUtc).TotalMilliseconds).ToString(CultureInfo.InvariantCulture))+" prep-ms="+N(i.PreparationMs)+" spawn-ms="+N(i.SpawnMs)+" window-after-launch-return-ms="+N(i.WindowMs)+" verified-live-after-launch-return-ms="+(run.Mode=="plain"?"N/A":N(i.FreshMs))+" cpu-ms="+N(i.CpuMs)+" sampled-peak-private-mb="+N(i.PeakPrivateMb)+" sampled-peak-working-mb="+N(i.PeakWorkingMb)+" exit-observed="+i.Exited+" failure="+(i.Error??"none")+" observation="+(i.ObserverNote??"initial PID"));}
                if(runs.Count==0)text.AppendLine("No A/B launch batch recorded yet.");return text.ToString();}
        }
    }
}
