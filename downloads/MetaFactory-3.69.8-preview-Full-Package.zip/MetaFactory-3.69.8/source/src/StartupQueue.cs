using System;using System.Diagnostics;
namespace MTManager
{
    // Manual launches never acquire a RAM/count/readiness admission slot.
    // The independent StartPace policy still honors the user's configured interval.
    public static class StartupAdmission
    {
        public static int Spacing(int configured,ulong freeMb){return 0;}
        public static bool Wait(double elapsed,int configured,ulong freeMb){return false;}
    }
    public sealed class LaunchResourceRecovery
    {
        // Keep error classification/recording, without a launch recovery delay.
        public bool Record(Exception error,DateTime now){return GuiResourceSafety.IsResourceError(error);}
        public bool Waiting(DateTime now){return false;}
    }
    sealed partial class MainForm
    {
        readonly LaunchResourceRecovery resourceRecovery=new LaunchResourceRecovery();
        string StartupQueueSummary(){return "\r\n— Manual startup admission —\r\nNo automatic RAM/count/history/CPU/window admission gate or resource-error recovery pause. All manual queue entries are attempted. Only the user-configured Start interval / original early-ready policy and serialized per-copy preparation remain. Failed process starts are recorded and the remaining queue continues; no existing terminal is closed to make room. Windows/terminal failures can still prevent a native window from opening.\r\n";}
        void TrackMt5Startup(Instance copy,StartResult result)
        {
            if(result.Process!=null)LaunchComparison.ReboundAfterUpdate(copy,result.Process,accounts.Get(copy.Name));
        }
        void UpdateMt5StartupProcess(Instance copy,Process process)
        {
            if(process!=null)LaunchComparison.ReboundAfterUpdate(copy,process,accounts.Get(copy.Name));
        }
        bool WaitForStartupSlot(Instance next){return false;}
    }
}
