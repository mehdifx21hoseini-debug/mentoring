using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace MTManager
{
    // Diagnostics only: no process launch/termination, GUI creation, account access or registry writes.
    public static class LaunchEvidence
    {
        sealed class Attempt
        {
            internal string Run,Name,Root,Platform,Exe;
            internal DateTime RequestedUtc,StartUtc,LastSample;
            internal int Pid,WatchId;
        }
        sealed class Item
        {
            internal string Directory,Run,Kind;
            internal bool Sample;
            internal Dictionary<string,object> Data;
        }
        static readonly object Gate=new object();
        static readonly Queue<Item> Pending=new Queue<Item>();
        static readonly Dictionary<string,Attempt> Attempts=new Dictionary<string,Attempt>(StringComparer.OrdinalIgnoreCase);
        static readonly Dictionary<int,Attempt> Pids=new Dictionary<int,Attempt>();
        static readonly Queue<string> Recent=new Queue<string>();
        static readonly AutoResetEvent Drained=new AutoResetEvent(false);
        static string run="",directory="",writeRun="",writeDirectory="",lastError="";
        static bool writing,samplesFull,totalFull;
        static long sequence,sampleBytes,totalBytes,dropped;
        static DateTime lastWindows,lastEventLog,batchStartUtc;
        static readonly HashSet<string> SeenEvents=new HashSet<string>();
        static int heavy;
        const long SampleLimit=2*1024*1024,TotalLimit=4*1024*1024;
        public static void Observe(Action action)
        {try{action();}catch(Exception e){lock(Gate)lastError=e.GetType().Name;}}
        public static string CurrentPath { get {lock(Gate)return Path.Combine(directory.Length==0?AppPaths.DataDir:directory,"launch-evidence.txt");} }
        static Dictionary<string,object> D(params object[] values)
        {var d=new Dictionary<string,object>();for(int i=0;i+1<values.Length;i+=2)d[(string)values[i]]=values[i+1];return d;}
        static string U(DateTime value){return value==DateTime.MinValue?"unknown":value.ToUniversalTime().ToString("o",CultureInfo.InvariantCulture);}
        static void Event(string kind,Dictionary<string,object> data,bool sample=false,string origin=null)
        {
            lock(Gate)
            {
                if(run.Length==0)return;
                data["event"]=kind;data["run_id"]=origin??run;data["sequence"]=++sequence;data["recorded_utc"]=U(DateTime.UtcNow);
                if(Pending.Count>=1024){dropped++;return;}
                data["dropped_queue_records"]=dropped;
                Pending.Enqueue(new Item{Directory=directory,Run=origin??run,Kind=kind,Sample=sample,Data=data});
                Recent.Enqueue(kind+" "+(data.ContainsKey("copy")?data["copy"]:"")+" "+U(DateTime.UtcNow));while(Recent.Count>24)Recent.Dequeue();
                if(!writing){writing=true;ThreadPool.QueueUserWorkItem(_=>WritePending());}
            }
        }
        static bool Owned(string path)
        {
            using(var f=new StreamReader(path,Encoding.UTF8,true)){char[] head=new char[1024];int n=f.Read(head,0,head.Length);return new string(head,0,n).Contains("MF_LAUNCH_EVIDENCE_1");}
        }
        static void WritePending()
        {
            var json=new JavaScriptSerializer();
            while(true)
            {
                Item item;
                lock(Gate)
                {
                    if(Pending.Count==0){writing=false;Drained.Set();return;}
                    item=Pending.Dequeue();
                }
                try
                {
                    Directory.CreateDirectory(item.Directory);
                    string file=Path.Combine(item.Directory,"launch-evidence.txt");
                    if(item.Kind=="batch_begin")
                    {
                        writeRun="";writeDirectory="";
                        string old=Path.Combine(item.Directory,"launch-evidence-previous.txt");
                        if(File.Exists(file))
                        {
                            if(!Owned(file)||File.Exists(old)&&!Owned(old))throw new IOException("Evidence filename belongs to an unknown file.");
                            if(File.Exists(old))File.Delete(old);File.Move(file,old);
                        }
                        writeRun=item.Run;writeDirectory=item.Directory;sampleBytes=totalBytes=0;samplesFull=totalFull=false;
                    }
                    if(writeDirectory!=item.Directory||writeRun.Length==0)continue;
                    string line=json.Serialize(item.Data)+"\r\n";int bytes=Encoding.UTF8.GetByteCount(line);
                    if(item.Sample && sampleBytes+bytes>SampleLimit)
                    {
                        if(!samplesFull){File.AppendAllText(file,json.Serialize(D("event","sample_budget_reached","run_id",writeRun,"recorded_utc",U(DateTime.UtcNow),"note","Periodic samples omitted; critical events retained."))+"\r\n",Encoding.UTF8);samplesFull=true;}
                        continue;
                    }
                    if(totalBytes+bytes>(item.Kind=="user_stopped_queue"?TotalLimit-2048:TotalLimit-65536))
                    {
                        if(!totalFull){File.AppendAllText(file,json.Serialize(D("event","trace_budget_reached","run_id",writeRun,"recorded_utc",U(DateTime.UtcNow),"note","Further events omitted; this trace is incomplete."))+"\r\n",Encoding.UTF8);totalFull=true;}
                        continue;
                    }
                    File.AppendAllText(file,line,Encoding.UTF8);totalBytes+=bytes;if(item.Sample)sampleBytes+=bytes;
                }
                catch(Exception e){lock(Gate)lastError=e.GetType().Name;}
            }
        }
        public static void BeginBatch(IEnumerable<Instance> copies,Settings settings)
        {
            lock(Gate){run=Guid.NewGuid().ToString("N");directory=AppPaths.DataDir;Attempts.Clear();Recent.Clear();lastWindows=lastEventLog=DateTime.MinValue;batchStartUtc=DateTime.UtcNow;SeenEvents.Clear();}
            Event("batch_begin",D("schema","MF_LAUNCH_EVIDENCE_1","app_version",AppInfo.Version,"requested_copies",copies.Select(c=>LaunchCapacityDiagnostics.SafeCopy(c.Name)).ToArray(),
                "local_time",DateTime.Now.ToString("o",CultureInfo.InvariantCulture),"utc_offset_minutes",TimeZoneInfo.Local.GetUtcOffset(DateTime.Now).TotalMinutes,
                "os",Environment.OSVersion.ToString(),"cores",Environment.ProcessorCount,"configured_interval_seconds",settings.DelaySeconds,
                "live_mode",settings.ManualLiveReports,"light",settings.Light,"low_priority",settings.LowPriority,"trim_memory",settings.TrimMemory,
                "minimized",settings.Minimized,"sandbox_overflow",settings.SandboxieOverflow,"mt5_updates_paused",settings.PauseMt5Updates,
                "desktop_heap_registry_kb",Heap.Current().HasValue?(object)Heap.Current().Value:"unknown",
                "resource_snapshot",LaunchCapacityDiagnostics.CaptureResources().Text(),"privacy","No credentials, command lines, window captions or account identifiers collected.",
                "storage","Current and previous trace only, max4MB per run; explicit truncation markers."));
            string dataDirectory=directory;Background(()=>CaptureHeapBackups(dataDirectory));
        }
        public static void Request(Instance copy)
        {
            lock(Gate)
            {
                if(run.Length==0)return;
                Attempts[copy.Name]=new Attempt{Run=run,Name=LaunchCapacityDiagnostics.SafeCopy(copy.Name),Root=copy.Dir,Exe=copy.Exe,Platform=copy.Kind.ToString(),RequestedUtc=DateTime.UtcNow};
            }
            Event("launch_requested",D("copy",LaunchCapacityDiagnostics.SafeCopy(copy.Name),"platform",copy.Kind.ToString()));
        }
        public static void Started(Process process,string copy,int watchId=0)
        {
            Attempt a;
            lock(Gate)
            {
                Attempt requested;if(!Attempts.TryGetValue(copy,out requested))return;
                a=new Attempt{Run=requested.Run,Name=requested.Name,Root=requested.Root,Exe=requested.Exe,Platform=requested.Platform,RequestedUtc=requested.RequestedUtc,WatchId=watchId};
                try{a.Pid=process.Id;a.StartUtc=process.StartTime.ToUniversalTime();}catch{try{a.Pid=process.Id;}catch{return;}}
                Pids[a.Pid]=a;Attempts[copy]=a;
            }
            Event("process_created",D("copy",a.Name,"pid",a.Pid,"process_start_utc",U(a.StartUtc),"request_utc",U(a.RequestedUtc),"watch_id",a.WatchId),false,a.Run);
            Background(()=>CaptureProfile(a));
        }
        public static void Sample(string copy,int pid,string counters,LaunchCapacityDiagnostics.ResourceSnapshot resources,bool exited,int? exitCode,int watchId=0)
        {
            Attempt a;bool windows=false;
            lock(Gate)
            {
                if(!Pids.TryGetValue(pid,out a)||!string.Equals(LaunchCapacityDiagnostics.SafeCopy(copy),a.Name,StringComparison.OrdinalIgnoreCase))return;
                if(a.WatchId!=watchId){Event("stale_process_observation",D("copy",a.Name,"pid",pid,"expected_watch",a.WatchId,"observed_watch",watchId),false,a.Run);return;}
                var now=DateTime.UtcNow;
                if(!exited && now-a.LastSample<TimeSpan.FromSeconds(now-a.RequestedUtc<TimeSpan.FromMinutes(2)?5:15))return;
                a.LastSample=now;if(exited)Pids.Remove(pid);if(now-lastWindows>=TimeSpan.FromSeconds(5)){lastWindows=now;windows=true;}
            }
            Event(exited?"process_exited":"process_sample",D("copy",a.Name,"pid",pid,"process_start_utc",U(a.StartUtc),"observed_utc",U(DateTime.UtcNow),
                "watch_id",a.WatchId,"age_ms",Math.Max(0,(DateTime.UtcNow-a.RequestedUtc).TotalMilliseconds),"exit_code",exitCode.HasValue?(object)exitCode.Value:"unknown",
                "counters",counters,"resources",resources.Text(),"cause",exited?"not inferred from exit code alone":"not applicable"),!exited,a.Run);
            if(windows)Background(CaptureWindows);
            if(exited)Task.Delay(1500).ContinueWith(_=>Background(()=>{CaptureNative(a);CaptureEvents(a.RequestedUtc);}));
        }
        public static void Failure(Instance copy,Exception error)
        {
            Event("process_start_failed",D("copy",LaunchCapacityDiagnostics.SafeCopy(copy.Name),"error_codes",GuiResourceSafety.ErrorCodes(error),"stack",error.StackTrace??"","filtered_message",FilterOperational(new[]{error.Message??""})));
            Attempt a;lock(Gate)Attempts.TryGetValue(copy.Name,out a);
            if(a!=null)Background(()=>{CaptureProfile(a);CaptureNative(a);CaptureEvents(a.RequestedUtc);});
        }
        public static void Stage(string copy,string phase,int pid=0,string detail="")
        {Event("launch_stage",D("copy",LaunchCapacityDiagnostics.SafeCopy(copy),"phase",phase,"pid",pid,"detail",detail));}
        public static void UserStop(IEnumerable<string> queued,bool inFlight)
        {Event("user_stopped_queue",D("cancelled_before_request",queued.Select(LaunchCapacityDiagnostics.SafeCopy).ToArray(),"in_flight_preparation",inFlight,"meaning","User cancellation is not a launch failure; existing terminals are not closed."));}
        public static void CloseRequested(int pid,string source)
        {Event("close_requested",D("pid",pid,"source",source,"meaning","Recorded request, not proof of the ultimate exit cause."));}
        public static void GuiFailure(Exception error)
        {Event("gui_creation_failed",D("error_codes",GuiResourceSafety.ErrorCodes(error),"stack",error.StackTrace??"","app_counters",GuiResourceSafety.Counters(),"resources",LaunchCapacityDiagnostics.CaptureResources().Text()));}
        static void Background(Action action)
        {
            if(Interlocked.Increment(ref heavy)>4){Interlocked.Decrement(ref heavy);Event("capture_skipped",D("reason","background capture capacity","note","Trace completeness reduced; launches unaffected."));return;}
            ThreadPool.QueueUserWorkItem(_=>{try{action();}catch(Exception e){Event("capture_unavailable",D("exception",e.GetType().Name));}finally{Interlocked.Decrement(ref heavy);}});
        }
        static int CountCharts(string root)
        {
            int count=0,visited=0;var pending=new Queue<string>();pending.Enqueue(root);
            while(pending.Count>0&&visited++<128&&count<1001)
            {
                string dir=pending.Dequeue();if((File.GetAttributes(dir)&FileAttributes.ReparsePoint)!=0)continue;
                count+=Directory.EnumerateFiles(dir,"*.chr",SearchOption.TopDirectoryOnly).Take(1001-count).Count();
                foreach(string child in Directory.EnumerateDirectories(dir).Take(Math.Max(0,128-pending.Count)))pending.Enqueue(child);
            }
            return count;
        }
        static void CaptureHeapBackups(string root)
        {
            var rows=new List<object>();
            foreach(string path in Directory.EnumerateFiles(root,"heap-backup-*.txt").Take(128).OrderByDescending(File.GetLastWriteTimeUtc).Take(4))
            {
                var f=new FileInfo(path);if(f.Length>16384||(f.Attributes&FileAttributes.ReparsePoint)!=0)continue;
                int? prior=Heap.Interactive(File.ReadAllText(path,Encoding.UTF8));
                rows.Add(D("backup",f.Name,"write_utc",U(f.LastWriteTimeUtc),"previous_configured_interactive_kb",prior.HasValue?(object)prior.Value:"unknown"));
            }
            Event("desktop_heap_backups",D("backups",rows,"limits","Read-only numeric extraction from up to4 legacy backup files /128 candidates. A registry backup is not proof of active capacity at that time."));
        }
        static void CaptureProfile(Attempt a)
        {
            var data=D("copy",a.Name,"pid",a.Pid,"platform",a.Platform);
            try{var f=new FileInfo(a.Exe);data["exe_version"]=FileVersionInfo.GetVersionInfo(a.Exe).FileVersion;data["exe_bytes"]=f.Length;data["exe_write_utc"]=U(f.LastWriteTimeUtc);}catch(Exception e){data["exe_metadata_error"]=e.GetType().Name;}
            try{string root=Path.Combine(a.Root,"profiles");data["saved_chart_files_observed"]=Directory.Exists(root)?CountCharts(root):0;data["chart_scan_limits"]="up to128 directories/1001 files; count may be a lower bound";}catch(Exception e){data["chart_count_error"]=e.GetType().Name;}
            Event("copy_profile",data,false,a.Run);
        }
        // Never record raw login/authorization records or arbitrary application messages.
        public static string[] FilterOperational(IEnumerable<string> lines)
        {
            var sensitive=new Regex(@"password|passwd|pwd|token|secret|investor|master|login|log\s*in|account|authoriz|سرمایه|رمز|حساب",RegexOptions.IgnoreCase);
            var operational=new Regex(@"error|fail|fault|process id|memory|resource|window|initializ|crash|exception|shutdown|closed|stopp|terminal|update|allocat|not enough|fatal",RegexOptions.IgnoreCase);
            return lines.Where(x=>x!=null&&!sensitive.IsMatch(x)&&operational.IsMatch(x)).Select(x=>x.Length>600?x.Substring(0,600)+" [clipped]":x).Take(32).ToArray();
        }
        static string[] Tail(string path,DateTime since)
        {
            if(!File.Exists(path))return new string[0];
            using(var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))
            {
                int first=f.ReadByte(),second=f.ReadByte();bool unicode=first==255&&second==254 || first>0&&second==0;
                long start=Math.Max(2,f.Length-16384);if(unicode&&start%2!=0)start++;f.Position=Math.Min(start,f.Length);
                byte[] bytes=new byte[(int)(f.Length-f.Position)];int got=0;while(got<bytes.Length){int n=f.Read(bytes,got,bytes.Length-got);if(n<=0)break;got+=n;}
                string text=(unicode?Encoding.Unicode:Encoding.Default).GetString(bytes,0,unicode?got-got%2:got);
                return FilterOperational(ConnectionCheck.After(text.Split('\n').Skip(start>2?1:0),since.TimeOfDay-TimeSpan.FromSeconds(Math.Min(2,since.TimeOfDay.TotalSeconds))));
            }
        }
        static void CaptureNative(Attempt a)
        {
            var rows=new List<object>();DateTime from=a.RequestedUtc.ToLocalTime();
            foreach(string relative in new[]{"logs",Path.Combine(a.Platform=="MT4"?"MQL4":"MQL5","Logs")})
            foreach(DateTime day in new[]{from.Date,DateTime.Now.Date}.Distinct())
            {
                string path=Path.Combine(a.Root,relative,day.ToString("yyyyMMdd",CultureInfo.InvariantCulture)+".log");
                try{rows.Add(D("log_kind",relative,"date",day.ToString("yyyy-MM-dd"),"exists",File.Exists(path),"filtered_lines",Tail(path,day==from.Date?from:day)));}
                catch(Exception e){rows.Add(D("log_kind",relative,"read_error",e.GetType().Name));}
            }
            Event("native_journal",D("copy",a.Name,"pid",a.Pid,"request_utc",U(a.RequestedUtc),"captured_utc",U(DateTime.UtcNow),"logs",rows,
                "limits","Tail16KB, max32 operational lines/file, local-clock filter. Empty output is NOT proof of a clean native shutdown."),false,a.Run);
        }
        static void CaptureEvents(DateTime since)
        {
            lock(Gate){if(DateTime.UtcNow-lastEventLog<TimeSpan.FromSeconds(20))return;lastEventLog=DateTime.UtcNow;if(batchStartUtc!=DateTime.MinValue&&batchStartUtc<since)since=batchStartUtc;}
            if(Environment.OSVersion.Platform!=PlatformID.Win32NT){Event("windows_events_unavailable",D("reason","not Windows"));return;}
            foreach(string name in new[]{"Application","System"})
            try
            {
                using(var log=new EventLog(name))
                {
                    int read=0,found=0;
                    for(int i=log.Entries.Count-1;i>=0&&read++<512&&found<8;i--)
                    {
                        var entry=log.Entries[i];if(entry.TimeGenerated.ToUniversalTime()<since.AddSeconds(-5))break;
                        long id=entry.InstanceId&65535;if(id!=1000&&id!=1001&&id!=2004)continue;
                        string message=entry.Message??"";
                        if(id!=2004&&message.IndexOf("terminal",StringComparison.OrdinalIgnoreCase)<0&&message.IndexOf("MetaFactory",StringComparison.OrdinalIgnoreCase)<0&&message.IndexOf("MTManager",StringComparison.OrdinalIgnoreCase)<0)continue;
                        string identity=name+":"+entry.Index+":"+entry.TimeGenerated.Ticks;
                        lock(Gate){if(SeenEvents.Contains(identity))continue;if(SeenEvents.Count>=512){Event("event_capture_limit",D("limit",512));return;}SeenEvents.Add(identity);}
                        Event("windows_event_candidate",D("log",name,"record_index",entry.Index,"id",id,"time_utc",U(entry.TimeGenerated.ToUniversalTime()),"source",entry.Source,
                            "filtered_lines",FilterOperational(message.Split('\n')),"attribution","Candidate OS event; not automatically attributed to a PID or declared causal."));found++;
                    }
                }
            }
            catch(Exception e){Event("windows_events_unavailable",D("log",name,"exception",e.GetType().Name));}
        }
        delegate bool EnumProc(IntPtr hwnd,IntPtr ignored);
        [DllImport("user32.dll",SetLastError=true)] static extern bool EnumWindows(EnumProc callback,IntPtr ignored);
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint pid);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hwnd);
        [DllImport("user32.dll")] static extern bool IsHungAppWindow(IntPtr hwnd);
        [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr hwnd,StringBuilder text,int length);
        [DllImport("user32.dll")] static extern IntPtr GetThreadDesktop(uint tid);
        [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool GetUserObjectInformation(IntPtr handle,int index,StringBuilder text,int length,out int needed);
        static void CaptureWindows()
        {
            if(Environment.OSVersion.Platform!=PlatformID.Win32NT){Event("window_snapshot_unavailable",D("reason","not Windows"),true);return;}
            Dictionary<int,Attempt> targets;lock(Gate)targets=new Dictionary<int,Attempt>(Pids);
            var rows=new List<object>();var seen=new HashSet<int>();bool clipped=false;int totalTop=0,otherTop=0;
            bool ok=EnumWindows((hwnd,ignored)=>{
                totalTop++;
                if(rows.Count>=1024){clipped=true;return false;}
                uint pid;uint thread=GetWindowThreadProcessId(hwnd,out pid);Attempt a;
                if(!targets.TryGetValue((int)pid,out a)){otherTop++;return true;}
                try
                {
                    using(var p=Process.GetProcessById((int)pid))
                    {
                        if(a.StartUtc!=DateTime.MinValue&&p.StartTime.ToUniversalTime()!=a.StartUtc)return true;
                        var cls=new StringBuilder(128);GetClassName(hwnd,cls,cls.Capacity);
                        var desk=new StringBuilder(256);int needed;bool named=GetUserObjectInformation(GetThreadDesktop(thread),2,desk,desk.Capacity*2,out needed);
                        rows.Add(D("copy",a.Name,"source_run",a.Run,"pid",pid,"process_start_utc",U(a.StartUtc),"session",p.SessionId,"class",cls.ToString(),"visible",IsWindowVisible(hwnd),
                            "hung",IsHungAppWindow(hwnd),"thread_id",thread,"desktop",named?desk.ToString():"unknown","identity_verified",a.StartUtc!=DateTime.MinValue));seen.Add((int)pid);
                    }
                }catch{}
                return true;
            },IntPtr.Zero);int error=ok?0:Marshal.GetLastWin32Error();
            Event("window_snapshot",D("enumeration_ok",ok,"truncated",clipped,"scope","observer desktop top-level windows","total_top_windows",totalTop,"other_top_windows",otherTop,"native_error",error,"observed_utc",U(DateTime.UtcNow),"windows",rows.Take(1024).ToArray(),
                "tracked_pids_without_top_window",ok?targets.Keys.Where(p=>!seen.Contains(p)).ToArray():new int[0],"limits","Top-level windows only; no captions/control text. No-window is not a broker/auth diagnosis."),true);
        }
        public static string Summary()
        {
            lock(Gate)return "\r\n— Detailed launch evidence —\r\nRun="+run+"\r\nAutomatic evidence file: "+CurrentPath+"\r\nQueue pending="+Pending.Count+" dropped="+dropped+" writer-error="+(lastError.Length==0?"none":lastError)+
                "\r\nDiagnostics only; window/exit events do not imply a cause. User queue cancellation is separate from failure. Current+previous files only; capped4MB each.\r\n"+string.Join("\r\n",Recent.ToArray())+"\r\n";
        }
        public static bool Flush(int milliseconds=2000)
        {
            var clock=Stopwatch.StartNew();while(clock.ElapsedMilliseconds<milliseconds){lock(Gate)if(!writing&&Pending.Count==0)return true;Drained.WaitOne(20);}return false;
        }
    }
}
