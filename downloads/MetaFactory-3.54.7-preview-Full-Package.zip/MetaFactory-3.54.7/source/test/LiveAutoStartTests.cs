using System;
using System.Linq;
namespace MTManager { static partial class Tests {
static void LiveAutoStartChecks() {
 LaunchWorkChecks();
 Mt5UpdatePolicyChecks();
 string selectionState="";Action<string,string> record=(state,detail)=>selectionState=state;
 Equal("OwnRecent",LiveAutoStart.ChooseMt5StartupSymbol(()=>{throw new Exception("should not run");},"OwnRecent",null,new string[0],record),"recent own-account startup skips private terminal entirely");
 Equal("recent-account-hint",selectionState,"cached symbol is explicitly a hint rather than a fresh proof");
 Equal("NativeGood",LiveAutoStart.ChooseMt5StartupSymbol(()=>"NativeGood",null,null,new[]{"Old"},record),"fresh native symbol wins over history hint");
 Equal("verified",selectionState,"fresh proof labelled separately");
 foreach(var failure in new Exception[]{new UserMessage("no symbol"),new TimeoutException(),new System.IO.IOException(),new InvalidOperationException()})
 {
  Equal("Alternate",LiveAutoStart.ChooseMt5StartupSymbol(()=>{throw failure;},null,"Bad",new[]{"Bad","Alternate"},record),"failed symbol helper permits cached alternative: "+failure.GetType().Name);
  Equal("unverified-fallback",selectionState,"fallback is never marked verified");
 }
 Equal(null,LiveAutoStart.ChooseMt5StartupSymbol(()=>{throw new TimeoutException();},null,"Uncertified",new string[0],record),"no own cache permits terminal-only launch without guessing a fixed symbol");
 Equal("terminal-only",selectionState,"terminal-only outcome explicitly recorded");
 Throws<OperationCanceledException>(()=>LiveAutoStart.ChooseMt5StartupSymbol(()=>{throw new OperationCanceledException();},null,null,new[]{"Own"},record),"cancellation must not accidentally launch terminal");
 Equal(null,LiveAutoStart.FallbackSymbol("bad\nSymbol=X",new[]{"bad\nSymbol=X"}),"fallback rejects launch configuration injection");

 var privateSource=Dir("symbol-private-source");
 System.IO.File.WriteAllText(System.IO.Path.Combine(privateSource,"terminal64.exe"),"fixture-native-terminal");
 System.IO.File.WriteAllText(System.IO.Path.Combine(privateSource,"mtm-live-start-"+new string('a',32)+".ini"),"secret-login-sentinel");
 System.IO.Directory.CreateDirectory(System.IO.Path.Combine(privateSource,"MQL5","Experts"));
 System.IO.File.WriteAllText(System.IO.Path.Combine(privateSource,"MQL5","Experts","foreign.ex5"),"unrelated-user-EA");
 var privateSettings=new Settings{BaseDir=Dir("symbol-private-root")};
 var privateCopy=new Instance{Name="probe",Kind=Kind.MT5,Dir=System.IO.Path.Combine(privateSettings.BaseDir,"probe")};
 StudentDirectory.Prepare(privateSettings,privateSource,privateCopy,()=>false);
 Check(System.IO.File.Exists(privateCopy.Exe),"symbol verifier gets complete native terminal from current managed source");
 Equal(0,System.IO.Directory.GetFiles(privateCopy.Dir,"mtm-live-start-*.ini").Length,"private symbol verifier never clones credential launch files");
 Check(!System.IO.Directory.Exists(System.IO.Path.Combine(privateCopy.Dir,"MQL5","Experts")),"private symbol verifier never clones unrelated user EAs");

 var symbolProofAccount=new Account{Login="123",Server="Broker-Demo",VerifyToken=new string('d',32)};
 var symbolReply=new System.Collections.Generic.Dictionary<string,object>{{"token",symbolProofAccount.VerifyToken},{"login","123"},{"server","Broker-Demo"},{"state","connected"},{"symbol_status","ready"},{"symbol","EURUSD.account"},{"bar_count",2},{"last_close",1.1},{"bid",1.1},{"ask",1.2},{"tick_time",1760000000}};
 var symbolJson=new System.Web.Script.Serialization.JavaScriptSerializer();
 var oldCulture=System.Threading.Thread.CurrentThread.CurrentCulture;
 try{
 System.Threading.Thread.CurrentThread.CurrentCulture=new System.Globalization.CultureInfo("fr-FR");
 Equal("EURUSD.account",DirectProbe.PythonReply(symbolJson.Serialize(symbolReply),symbolProofAccount).ValidatedSymbol,"fresh exact-account quote and candles accepted across decimal cultures");
 }finally{System.Threading.Thread.CurrentThread.CurrentCulture=oldCulture;}
 symbolReply["login"]="999";
 Equal(null,DirectProbe.PythonReply(symbolJson.Serialize(symbolReply),symbolProofAccount),"other account symbol proof rejected");
 symbolReply["login"]="123";symbolReply["bar_count"]=0;
 Equal(null,DirectProbe.PythonReply(symbolJson.Serialize(symbolReply),symbolProofAccount).ValidatedSymbol,"price without candles cannot certify startup symbol");
 symbolReply["bar_count"]=2;symbolReply["bid"]=0;
 Equal(null,DirectProbe.PythonReply(symbolJson.Serialize(symbolReply),symbolProofAccount).ValidatedSymbol,"zero quote cannot certify startup symbol");
 symbolReply["bid"]=1.1;symbolReply["symbol"]="bad\nSymbol=Injected";
 Equal(null,DirectProbe.PythonReply(symbolJson.Serialize(symbolReply),symbolProofAccount).ValidatedSymbol,"symbol cannot inject launch configuration");
 symbolReply["symbol"]="EURUSD.account";symbolReply["symbol_status"]="unavailable";
 Check(DirectProbe.PythonReply(symbolJson.Serialize(symbolReply),symbolProofAccount).Connected,"symbol unavailability does not report bad credentials");
 Equal(null,DirectProbe.PythonReply(symbolJson.Serialize(symbolReply),symbolProofAccount).ValidatedSymbol,"unavailable symbol not used");

 Equal(180,Launcher.SelfUpdateWaitSeconds(Kind.MT4),"MT4 confirmed self-update policy unchanged");
 Equal(PendingStart.ProtectedSeconds,Launcher.SelfUpdateWaitSeconds(Kind.MT5),"MT5 updater recovery waits within protected configuration lifetime");

 DateTime proofNow=DateTime.UtcNow;proofNow=proofNow.AddTicks(-(proofNow.Ticks%TimeSpan.TicksPerSecond));
 var proofCopy=new Instance{Name="MT5-proof",Kind=Kind.MT5,Dir=Dir("mt5-symbol-proof")};
 var proofAccount=new Account{Login="123",Server="Broker-Demo"};var proofTarget=LiveMonitorTarget.Create(proofCopy,proofAccount);proofTarget.Token=FeedToken;
 System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(proofTarget.SnapshotPath));
 string proofPlan=System.IO.Path.Combine(proofCopy.Dir,"MQL5","Files","MetaFactoryLive","launch-plan.txt");
 System.IO.File.WriteAllText(proofPlan,"MLPLAN\t1\nPlatform=MT5\nSymbol=XAUUSD@\n");System.IO.File.SetLastWriteTimeUtc(proofPlan,proofNow.AddSeconds(-5));
 System.IO.File.WriteAllText(proofTarget.SnapshotPath,FeedFrame(proofNow),System.Text.Encoding.Unicode);
 Equal("XAUUSD@",LiveAutoStart.OwnRecentSymbol(proofCopy,proofAccount,new[]{proofTarget},proofNow.AddMinutes(30)),"same-account recent successful symbol can bypass slow preflight");
 Equal(null,LiveAutoStart.OwnRecentSymbol(proofCopy,new Account{Login="999",Server="Broker-Demo"},new[]{proofTarget},proofNow),"recent symbol cache cannot cross accounts");
 Equal(null,LiveAutoStart.OwnRecentSymbol(proofCopy,proofAccount,new[]{proofTarget},proofNow.AddHours(25)),"old account symbol cache expires");
 Equal(null,LiveAutoStart.OwnRecentSymbol(new Instance{Name="Other",Kind=Kind.MT5,Dir=Dir("other-symbol-target")},proofAccount,new[]{proofTarget},proofNow),"recent symbol cache cannot cross managed copies");
 Equal("XAUUSD@",LiveAutoStart.Mt5LiveSymbol(new[]{proofTarget},"Broker-Demo",proofNow),"fresh ready same-server observer startup symbol overrides stale historical symbol");
 Equal(null,LiveAutoStart.Mt5LiveSymbol(new[]{proofTarget},"Other-Real",proofNow),"live symbol is never shared across servers");
 Equal(null,LiveAutoStart.Mt5LiveSymbol(new[]{proofTarget},"Broker-Demo",proofNow.AddSeconds(11)),"stale observer cannot certify startup symbol");
 System.IO.File.WriteAllText(proofTarget.SnapshotPath,FeedFrame(proofNow,state:"bootstrap",revision:0),System.Text.Encoding.Unicode);
 Equal(null,LiveAutoStart.Mt5LiveSymbol(new[]{proofTarget},"Broker-Demo",proofNow),"unready observer cannot certify symbol");
 System.IO.File.WriteAllText(proofTarget.SnapshotPath,FeedFrame(proofNow).Replace(FeedToken,new string('f',32)),System.Text.Encoding.Unicode);
 Equal(null,LiveAutoStart.Mt5LiveSymbol(new[]{proofTarget},"Broker-Demo",proofNow),"wrong-session frame cannot certify symbol");
 System.IO.File.WriteAllText(proofTarget.SnapshotPath,FeedFrame(proofNow),System.Text.Encoding.Unicode);System.IO.File.SetLastWriteTimeUtc(proofPlan,proofNow.AddSeconds(1));
 Equal(null,LiveAutoStart.Mt5LiveSymbol(new[]{proofTarget},"Broker-Demo",proofNow),"newer launch plan cannot inherit previous ready snapshot proof");

 var symbolSettings=new Settings{BaseDir=Dir("mt5-known-fallback")};
 string symbolRoot=ReportLaunch.ReportRoot(symbolSettings.BaseDir);
 System.IO.Directory.CreateDirectory(System.IO.Path.Combine(symbolRoot,"worker","Bases","Same-Demo","history","XAUUSD@"));
 System.IO.Directory.CreateDirectory(System.IO.Path.Combine(symbolRoot,"worker","Bases","Other-Real","history","GBPUSD.bad"));
 var missingSymbols=new Instance{Kind=Kind.MT5,Dir=Dir("mt5-empty-symbols")};
 var sharedSymbols=LiveAutoStart.Mt5KnownSymbols(symbolSettings,missingSymbols,"Same-Demo");
 Check(sharedSymbols.Contains("XAUUSD@") && !sharedSymbols.Contains("GBPUSD.bad"),"empty MT5 copy reuses only same-server known symbols");
 Equal("XAUUSD@",LiveAutoStart.Mt5Symbol("GBPUSD",sharedSymbols),"stale symbol replaced with known same-server fallback");

 var restartCopy=new Instance{Name="MT5-restart",Kind=Kind.MT5,Dir=Dir("mt5-restart")};var restartAccounts=new AccountStore();
 var originalStart=Launcher.WriteStartFile(restartCopy,new Settings{Light=true},restartAccounts,true);
 string originalPath=originalStart.StartFile;
 var observerLines=LiveAutoStart.Lines(Kind.MT5,"MF_Live_demo","session.set","XAUUSD@");
 System.IO.File.Delete(originalPath);
 Launcher.RestoreMt5LiveStart(restartCopy,new Settings{Light=true},restartAccounts,originalPath,observerLines);
 string restored=System.IO.File.ReadAllText(originalPath);
 Check(restored.Contains("ProfileLast="+Launcher.LiveMt5ProfileName) && restored.Contains("Expert=MF_Live_demo") && restored.Contains("ExpertParameters=session.set") && restored.Contains("Symbol=XAUUSD@"),"self-update restores complete EA context to exact original MT5 config path");
 Check(restored.Contains("AllowLiveTrading=0"),"MT5 live restart leaves algorithmic trading disabled");
 Equal(1,System.IO.Directory.GetFiles(restartCopy.Dir,"mtm-live-start-*.ini").Length,"restore leaves no extra credential configuration behind");
 Throws<ArgumentException>(()=>Launcher.RestoreMt5LiveStart(restartCopy,new Settings(),restartAccounts,System.IO.Path.Combine(restartCopy.Dir,"mtm-start.ini"),observerLines),"restart cannot overwrite unrelated configuration");
 string productionAuto=System.IO.File.ReadAllText("src/LiveAutoStart.cs");
 int prepareStart=productionAuto.IndexOf("public static List<string> Prepare(",StringComparison.Ordinal);
 int prepareEnd=productionAuto.IndexOf("// Recent successful same-account",prepareStart,StringComparison.Ordinal);
 string launchPreparation=productionAuto.Substring(prepareStart,prepareEnd-prepareStart);
 Check(launchPreparation.Contains("StartupHint(recent,preferred,candidates)")&&!launchPreparation.Contains("AccountSymbol(")&&!launchPreparation.Contains("StrictStartupSymbol("),"production launch cannot be blocked by unavailable private quote preflight");
 string productionCore=System.IO.File.ReadAllText("src/Core.cs");
 Check(!productionCore.Contains("ProtectStartFile(")&&!productionCore.Contains("Cannot protect login configuration"),"unsupported file ACL cannot block production launch");
 string updaterRoot=System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"MetaQuotes","Terminal");
 Check(ScopedUpdaterConsent.IsOwnCache(System.IO.Path.Combine(updaterRoot,new string('A',32),"liveupdate","terminal64.exe")),"per-user updater policy accepts exact own cache shape");
 Check(!ScopedUpdaterConsent.IsOwnCache(System.IO.Path.Combine(updaterRoot,new string('A',32),"liveupdate","other.exe")),"per-user updater policy rejects arbitrary executable");
 Check(!ScopedUpdaterConsent.IsOwnCache(System.IO.Path.Combine(updaterRoot,"..","elsewhere","terminal64.exe")),"per-user updater policy rejects directory traversal");
 var keep=new PendingStart{Path=originalPath,Time=DateTime.Now,WaitForConfigRead=true,KeepForRestart=true};
 Equal(null,keep.Ready(keep.Time.AddSeconds(100)),"MT5 retains acknowledged configuration for updater grace period");
 Equal("time",keep.Ready(keep.Time.AddSeconds(PendingStart.ProtectedSeconds)),"MT5 updater retention remains bounded");
 Launcher.DeleteStartFile(originalPath);

 var presetCopy=new Instance{Name="MT5-presets",Kind=Kind.MT5,Dir=Dir("mt5-startup-presets")};
 var presetPaths=LiveAutoStart.StartupPresetPaths(presetCopy,"MetaFactoryLive-session.set");
 Equal(2,presetPaths.Length,"MT5 startup preset supplied to both native lookup locations");
 Check(presetPaths.Any(x=>x.EndsWith(System.IO.Path.Combine("MQL5","Presets","MetaFactoryLive-session.set"))) && presetPaths.Any(x=>x.EndsWith(System.IO.Path.Combine("Profiles","Presets","MetaFactoryLive-session.set"))),"MT5 preset filename exactly matches startup reference");
 Equal("EURUSD@",LiveAutoStart.Mt5Symbol("GBPUSD",new[]{"EURUSD@","XAUUSD@"}),"MT5 replaces stale chart symbol with broker-known suffix");
 Equal("GBPUSD@",LiveAutoStart.Mt5Symbol("GBPUSD@",new[]{"EURUSD@","GBPUSD@"}),"MT5 preserves existing broker-valid symbol");
 LiveAutoStart.EnsureMt5Profile(presetCopy);
 string mt5Profile=System.IO.Path.Combine(presetCopy.Dir,"MQL5","Profiles","Charts",Launcher.LiveMt5ProfileName);
 System.IO.File.WriteAllText(System.IO.Path.Combine(mt5Profile,"chart01.chr"),"prior MT5 observer");LiveAutoStart.EnsureMt5Profile(presetCopy);
 Equal(0,System.IO.Directory.GetFiles(mt5Profile).Length,"MT5 private profile starts empty for one startup EA chart");
 Check(System.IO.Directory.GetFiles(System.IO.Path.Combine(presetCopy.Dir,"MTManager-backup","mt5-live-profile"),"chart01.chr",System.IO.SearchOption.AllDirectories).Any(x=>System.IO.File.ReadAllText(x)=="prior MT5 observer"),"MT5 previous private chart backed up intact");
 var mt5Start=Launcher.WriteStartFile(presetCopy,new Settings{Light=true},new AccountStore(),true);
 string mt5Config=System.IO.File.ReadAllText(mt5Start.StartFile);
 Check(mt5Start.WaitForConfigRead && mt5Config.Contains("ProfileLast="+Launcher.LiveMt5ProfileName),"MT5 live launch selects private profile and retains startup until acknowledgement");
 Check(PendingStart.ConfigAcknowledged("Startup successfully initialized from start config "+System.IO.Path.GetFileName(mt5Start.StartFile),mt5Start.StartFile),"MT5 positive native startup acknowledgement accepted");
 Check(!PendingStart.ConfigAcknowledged("cannot load config "+System.IO.Path.GetFileName(mt5Start.StartFile),mt5Start.StartFile),"MT5 failure is not an acknowledgement");
 Launcher.DeleteStartFile(mt5Start.StartFile);

 string mt4Recovery=LiveReporter.SourceText(Kind.MT4);
 Check(mt4Recovery.Contains("timer-fallback-awaiting-tick") && mt4Recovery.Contains("void OnTick()"),"MT4 observer retains attachment and uses tick fallback after timer failure");
 Check(!mt4Recovery.Contains("InitProblem(\"timer-create\",GetLastError());return INIT_FAILED;"),"MT4 timer failure no longer detaches observer");
 Check(mt4Recovery.Contains("now-timerRetryAt>=5000") && mt4Recovery.Contains("now-fallbackPollAt<1000"),"MT4 recovery and fallback work stay bounded");
 Check(!LiveReporter.SourceText(Kind.MT5).Contains("timer-fallback-awaiting-tick"),"MT5 lifecycle unchanged by MT4 recovery");

 var emptyCopy=new Instance{Name="MT4-single-live",Kind=Kind.MT4,Dir=Dir("mt4-single-live")};
 string profileRoot=System.IO.Path.Combine(emptyCopy.Dir,"profiles");System.IO.Directory.CreateDirectory(profileRoot);
 string userDir=System.IO.Path.Combine(profileRoot,"UserProfile");System.IO.Directory.CreateDirectory(userDir);
 string userChart=System.IO.Path.Combine(userDir,"chart01.chr");System.IO.File.WriteAllText(userChart,"<expert>MyOtherEA</expert>");
 string lastProfile=System.IO.Path.Combine(profileRoot,"lastprofile.ini");System.IO.File.WriteAllText(lastProfile,"UserProfile");
 LiveAutoStart.EnsureMt4Chart(emptyCopy,"EURUSD.m","5");
 string singleDir=System.IO.Path.Combine(profileRoot,LiveAutoStart.Mt4ProfileName);
 Equal(LiveAutoStart.Mt4ProfileName,System.IO.File.ReadAllText(lastProfile),"MT4 selects private startup-only profile");
 Equal(0,System.IO.Directory.GetFiles(singleDir,"*.chr").Length,"no preloaded chart duplicates startup Expert chart");
 Equal("<expert>MyOtherEA</expert>",System.IO.File.ReadAllText(userChart),"user EA chart preserved in original profile");
 string saved=System.IO.Path.Combine(singleDir,"chart01.chr");System.IO.File.WriteAllText(saved,"saved observer bytes");
 System.IO.File.WriteAllText(System.IO.Path.Combine(singleDir,"chart02.chr"),"extra saved chart bytes");
 LiveAutoStart.EnsureMt4Chart(emptyCopy,"EURUSD.m","5");
 Equal(0,System.IO.Directory.GetFileSystemEntries(singleDir).Length,"relaunch resets only private profile instead of restoring extra charts");
 string backup=System.IO.Path.Combine(emptyCopy.Dir,"MTManager-backup","single-live-profile");
 string[] backups=System.IO.Directory.GetDirectories(backup);
 Equal(1,backups.Length,"previous private profile backed up once");
 Equal("saved observer bytes",System.IO.File.ReadAllText(System.IO.Path.Combine(backups[0],"chart01.chr")),"saved observer profile backup preserves exact bytes");
 Equal("extra saved chart bytes",System.IO.File.ReadAllText(System.IO.Path.Combine(backups[0],"chart02.chr")),"extra private chart is backed up, not deleted");
 LiveAutoStart.EnsureMt4Chart(emptyCopy,"EURUSD.m","5");
 Equal(1,System.IO.Directory.GetDirectories(backup).Length,"empty private profile creates no redundant chart backups");
 var startResult=Launcher.WriteStartFile(emptyCopy,new Settings{Light=true,StartCharts=ChartModes.Empty},new AccountStore(),true);
 Equal(LiveAutoStart.Mt4ProfileName,System.IO.File.ReadAllText(lastProfile),"live launch keeps private profile despite empty/light settings");
 Launcher.DeleteStartFile(startResult.StartFile);
 Check(System.IO.File.ReadAllBytes(lastProfile)[0]==(byte)'M',"MT4 profile selector remains ASCII without BOM");
 Throws<ArgumentException>(()=>LiveAutoStart.EnsureMt4Chart(emptyCopy,"EURUSD\nperiod=60","1"),"single-chart startup rejects injected symbol");
 var mt5NoTouch=new Instance{Kind=Kind.MT5,Dir=Dir("mt5-single-unchanged")};LiveAutoStart.EnsureMt4Chart(mt5NoTouch,"EURUSD","1");
 Check(!System.IO.Directory.Exists(System.IO.Path.Combine(mt5NoTouch.Dir,"profiles")),"MT5 profile preparation unchanged");
 Equal(null,PendingStart.ProtectedReady(11,false),"MT4 retains startup beyond old ten-second deadline");
 Equal(null,PendingStart.ProtectedReady(120,false),"MT4 allows slow bootstrap without configuration acknowledgement");
 Equal(null,PendingStart.ProtectedReady(180,false),"slow MT4 startup retains settings past three minutes");
 Equal("time",PendingStart.ProtectedReady(PendingStart.ProtectedSeconds,false),"MT4 credential retention has bounded deadline");
 Equal(null,PendingStart.ProtectedReady(2,true),"filename acknowledgement alone cannot delete config during startup");
 Equal("journal",PendingStart.ProtectedReady(15,true),"acknowledged config cleanup after startup grace is bounded");
 Check(PendingStart.ConfigAcknowledged("Started with configuration file 'mtm-live-start-abc.ini'","/tmp/mtm-live-start-abc.ini"),"exact startup configuration acknowledgement accepted");
 Check(!PendingStart.ConfigAcknowledged("cannot load configuration file mtm-live-start-abc.ini","/tmp/mtm-live-start-abc.ini"),"configuration failure does not delete startup early");
 Check(!PendingStart.ConfigAcknowledged("Started with configuration file mtm-live-start-old.ini","/tmp/mtm-live-start-abc.ini"),"previous run acknowledgement cannot delete new startup");
 var protectedPending=new PendingStart {Time=DateTime.Now,WaitForConfigRead=true};
 Equal(null,protectedPending.Ready(protectedPending.Time.AddSeconds(90)),"missing parent process does not delete protected configuration");

 var bootstrapAccount=new Account {Login="12345",Server="Synthetic-Demo"};
 string token=new string('a',32), binding=LiveAutoStart.BootstrapText(bootstrapAccount,token);
 Check(binding=="MLBOOT\t1\r\n"+token+"\r\n12345\r\nSynthetic-Demo\r\n","fallback binding has exact bounded account-specific UTF16 text schema");
 var bootstrapCopy=new Instance {Name="MT4-bootstrap",Kind=Kind.MT4,Dir=Dir("live-bootstrap")};
 LiveAutoStart.WriteBootstrap(bootstrapCopy,bootstrapAccount,token);
 string bootstrapPath=System.IO.Path.Combine(bootstrapCopy.Dir,"MQL4","Files","MetaFactoryLive","bootstrap.txt");
 Equal(binding,System.IO.File.ReadAllText(bootstrapPath,System.Text.Encoding.Unicode),"atomic bootstrap is readable in native FILE_UNICODE form");
 bootstrapAccount.Login="67890";LiveAutoStart.WriteBootstrap(bootstrapCopy,bootstrapAccount,new string('b',32));
 Check(System.IO.File.ReadAllText(bootstrapPath).Contains("67890")&&!System.IO.File.ReadAllText(bootstrapPath).Contains(token),"closed-copy binding update replaces previous account atomically");
 Throws<UserMessage>(()=>LiveAutoStart.BootstrapText(new Account{Login="123",Server="Demo\nOther=bad"},token),"bootstrap server cannot inject extra binding lines");
 foreach(Kind nativeKind in new[]{Kind.MT4,Kind.MT5}) {
  string source=LiveReporter.SourceText(nativeKind);
  Check(source.Contains("bool ResolveSession()") && source.Contains("MLBOOT\\t1") && source.Contains("WorkToken==\"\" && WorkLogin==\"\" && WorkServer==\"\""),"native fallback only applies to wholly absent explicit inputs for "+nativeKind);
  Check(source.Contains("GlobalVariableSetOnCondition(ownerKey,ownerId,previous)") && source.Contains("observer-renewed-during-claim") && source.Contains("if(!RefreshLease()){FileDelete(tmp);return false;}"),"native atomic lease handles renewal races and rechecks ownership before publishing for "+nativeKind);
  Check(source.Contains("retryInitAt>=5000") && source.Contains("BeginLiveSession();retryInitAt=GetTickCount();") && source.Contains("return INIT_SUCCEEDED;"),"recoverable native session failure keeps terminal initialized and retries for "+nativeKind);
 }

 Equal("5",LiveAutoStart.FreePeriod(new[]{"symbol=EURUSD\nperiod=1\n<expert>OtherEA</expert>"},"EURUSD",new string('a',32)),"automatic observer chooses separate timeframe from existing EA chart");
 Equal("1",LiveAutoStart.FreePeriod(new[]{"symbol=EURUSD\nperiod=1\nMTManagerLive\n"+new string('a',32)},"EURUSD",new string('a',32)),"same account live chart can be reused");
 foreach (Kind kind in new[] { Kind.MT4, Kind.MT5 }) {
  var lines = LiveAutoStart.Lines(kind, @"MetaFactoryLive\version\MTManagerLive", "session.set", "EURUSD.m");
  Check(lines.Contains(@"Expert=MetaFactoryLive\version\MTManagerLive") && lines.Contains("ExpertParameters=session.set"), "automatic live startup binds independent EA and preset for " + kind);
  Check(lines.Contains("Symbol=EURUSD.m"), "automatic startup keeps broker symbol suffix for " + kind);
  Check(!lines.Any(x => (x.StartsWith("Script=") && x!="Script=") || (kind==Kind.MT4 && x.StartsWith("AllowLiveTrading=")) || x.StartsWith("ExpertsTrades=")), "live auto startup does not change trading permissions for " + kind);
  Check(kind != Kind.MT4 || lines.Contains("ExpertsDllImport=true"),"MT4 live startup enables history DLL access");
  Check(kind != Kind.MT5 || !lines.Any(x=>x.StartsWith("ExpertsDllImport=")),"MT5 DLL policy unchanged");
  Check(kind != Kind.MT4 || lines.Contains("ShutdownTerminal=false"),"MT4 auto-run explicitly disables startup terminal shutdown");
  Check(kind != Kind.MT5 || lines.First()=="[Experts]" && lines.Contains("AllowLiveTrading=0") && lines.Contains("[StartUp]") && lines.Contains("ShutdownTerminal=0"), "MT5 live startup stays open");
 }
 Throws<ArgumentException>(() => LiveAutoStart.Lines(Kind.MT4,"EA\nExpert=bad","s.set","EURUSD"), "automatic EA setting rejects newline injection");
 Check(LiveAutoStart.Prepare(new Instance(),new Settings(),null).Count==0,"copies without stored account do not attempt live compilation");
}
static void Mt5UpdatePolicyChecks()
{
 string[] copies={"02","03","05","06","18","19"};
 string[] hashes={"DAEB5476312A61A4CA9610260BE08302","C5357C285E6755F83E975D3FF5055739","78A4795D3155C7C07DFDA13070B2B649","B31997070C27027AEB2041348628EEC6","EC03107D380D7553A7BB1E6996F170F0","1E0C2AA7A3516AF6EA0E245A18FDA497"};
 for(int k=0;k<copies.Length;k++)Equal(hashes[k],Mt5UpdatePolicy.CacheKey(@"E:\MetaTrader\MT5-"+copies[k]),"cache mapping matches actual user journal/UAC capture "+copies[k]);
 Equal(hashes[1],Mt5UpdatePolicy.CacheKey(@"e:\metatrader\mt5-03\"),"cache mapping normalizes case and trailing separator");
 var options=new Settings();Check(options.PauseMt5Updates,"requested no-update mode defaults on");bool said=false;options.Set("PauseMt5Updates","0",ref said);Check(!options.PauseMt5Updates,"no-update mode can be disabled");options.Set("PauseMt5Updates","1",ref said);Check(options.PauseMt5Updates,"no-update mode can be enabled");
 string root=Dir("update-cache-barrier"),key=hashes[1],folder=System.IO.Path.Combine(root,key),live=System.IO.Path.Combine(folder,"liveupdate"),backup=System.IO.Path.Combine(folder,"liveupdate.MetaFactory-backup");
 System.IO.Directory.CreateDirectory(live);System.IO.File.WriteAllText(System.IO.Path.Combine(live,"terminal64.exe"),"preserved update bytes");
 try
 {
  Mt5UpdatePolicy.HoldAt(root,key);
  Check(System.IO.File.Exists(live)&&!System.IO.Directory.Exists(live),"cache barrier prevents updater directory placement");
  Equal("preserved update bytes",System.IO.File.ReadAllText(System.IO.Path.Combine(backup,"terminal64.exe")),"existing updater preserved by rename, not deleted or patched");
  bool blocked=false;try{System.IO.Directory.CreateDirectory(live);}catch(System.IO.IOException){blocked=true;}
  Check(blocked,"real filesystem refuses updater directory while owned marker occupies the path");
  blocked=false;try{using(var file=System.IO.File.Open(live,System.IO.FileMode.Open,System.IO.FileAccess.Write,System.IO.FileShare.ReadWrite)){} }catch(System.IO.IOException){blocked=true;}
  Check(blocked,"held marker rejects concurrent write access");
  Mt5UpdatePolicy.HoldAt(root,key);Check(System.IO.Directory.Exists(backup),"repeat preparation leaves saved cache intact");
  Mt5UpdatePolicy.ReleaseHandles();Mt5UpdatePolicy.HoldAt(root,key);Check(System.IO.File.Exists(live),"restart reacquires existing owned marker without another cache rename");
  Check(Mt5UpdatePolicy.RestoreAt(root,key),"disabling policy restores owned cache");
  Equal("preserved update bytes",System.IO.File.ReadAllText(System.IO.Path.Combine(live,"terminal64.exe")),"original updater restored exactly");
  Check(!System.IO.Directory.Exists(backup),"restored cache does not leave duplicate backup");
  Check(!Mt5UpdatePolicy.RestoreAt(root,key),"restore does not touch ordinary liveupdate directory");
  System.IO.Directory.Delete(live,true);System.IO.File.WriteAllText(live,"unrelated user's file");
  blocked=false;try{Mt5UpdatePolicy.HoldAt(root,key);}catch(System.IO.IOException){blocked=true;}
  Check(blocked&&System.IO.File.ReadAllText(live)=="unrelated user's file","unknown file preserved and never claimed as owned");
  System.IO.File.Delete(live);System.IO.Directory.CreateDirectory(live);System.IO.Directory.CreateDirectory(backup);
  blocked=false;try{Mt5UpdatePolicy.HoldAt(root,key);}catch(System.IO.IOException){blocked=true;}
  Check(blocked&&System.IO.Directory.Exists(live)&&System.IO.Directory.Exists(backup),"backup collision preserves both existing directories");
  blocked=false;try{Mt5UpdatePolicy.HoldAt(root,"../../escape");}catch(ArgumentException){blocked=true;}
  Check(blocked,"cache identity rejects path traversal");
 }
 finally{Mt5UpdatePolicy.ReleaseHandles();}
}

static void LaunchWorkChecks()
{
 var work=new LaunchWorkProgress();Equal(0,work.Total,"empty launch progress hidden");
 work.Add("MT5-01");work.Add("MT5-02");work.Add("mt5-01");Equal(2,work.Total,"launch target count deduplicates copy names");
 work.Complete("MT5-01",true);Equal(.5,work.Fraction,"launch progress counts completed dispatches");
 work.Complete("MT5-01",false);Equal(0,work.Failed,"late duplicate outcome cannot replace a completed dispatch");
 work.Stop(true);Check(work.Stopped&&work.Stopping&&!work.Finished,"stop during worker waits for the current operation without claiming finished");
 Equal(.5,work.Fraction,"stopped progress is not falsely filled to100percent");
 work.Add("MT5-03");Equal(2,work.Total,"stopped run does not absorb new work");
 work.SettleStop();work.Complete("MT5-02",true);Check(work.Finished&&work.Stopped&&work.Done==2,"late current worker settles into stopped result");
 var next=new LaunchWorkProgress();next.Add("A");next.Add("B");next.Complete("A",false);next.Skip("B");
 Check(next.Finished&&next.Done==2&&next.Failed==1&&next.Skipped==1,"failed and individually cancelled starts settle independently");
 next.Complete("foreign",true);Equal(2,next.Done,"unrelated launch completion cannot advance progress");
 var partial=new LaunchWorkProgress();partial.Add("A");partial.Add("B");partial.Stop(false);
 Check(partial.Finished&&partial.Fraction==0&&partial.Remaining==2,"stopping queued work leaves partial bar and remaining count");
}

}}
