# 3.40.0 — manual launch without an application count ceiling

Based on 3.39.0. Only the requested manual/open-all path changes; deferred report, drawdown, delivery, sorting and Late-label requirements are not implemented here.

- Manual MT4/MT5 launch no longer checks MaxMt4 or clears the queue when physical memory is low/unknown. Memory remains a non-modal banner advisory; no confirmation is required.
- Remove unused MT4 waiting-list implementation and the misleading manual-launch count setting. Legacy settings are retained for unchanged report/import compatibility.
- A process launch or initial copy preparation failure is recorded per instance and the rest of the queue proceeds. No failure popup blocks unattended opening.
- Early process exit and missing/slow windows do not discard queued copies. Next launch honors the configured start interval. Existing processes are not killed to make room.
- Remove count-based attribution of early exits to a universal 32-terminal MT4 limit. Show available error/journal evidence; do not fabricate a cause from process count alone.
- System diagnostics explain manual unlimited admission separately from unchanged report/import worker controls. Settings and bundled guides describe the new behavior.
- Keep user-requested close/cancellation and duplicate selection protection. Successful retries clear saved launch errors.

Validation: 16 production-queue integration checks per language (English/Persian), including 70 simulated MT4 and 30 simulated MT5 requests with legacy MaxMt4=1, low/unknown memory, injected OS failures, preparation failure, slow-window timing, early exit and application close. 72 existing UI checks per language passed. Full C# regression suite: 1546 passed, zero failed (one legacy chart test requires python3 inside the Mono container and remains skipped). Installer payload, embedded report resources and executable versions are verified before delivery.

These tests exercise code with an injected launcher. They do not demonstrate that 70 real MT4 terminals stay connected on Windows. Live broker/native Windows capacity validation remains to be done on the destination system. Report/import engines are byte-identical to 3.39.0 (MANUAL-LAUNCH-VERIFICATION.json).

See OPEN-MANY-fa.md for capacity planning and alternatives: one stronger Windows host first, then independent VMs/hosts if an OS or terminal constraint remains. No registry/session patch, terminal binary modification or distributed server controller is included.
