# MetaFactory 3.32.0 (preview)

## Approved dashboard changes

- A continuous blue report-progress strip above the original footer. Every selected eligible student has equal weight. Queued/start/read/terminal phases drive progress; animation smooths actual phase changes, not elapsed-time guesses. One student also advances through phases before completion. Finished/failed counts are separate; cancellation does not manufacture completed work.
- Header clicks on Student, Copy, Account, Server, Groups, Today and Status cycle ascending → descending → original manual order, with a drawn triangle arrow. Action/selection columns retain their existing behavior. Sorting is a view operation, preserving ticked and focused students and the report queue.
- Copy/account numbers use natural/numeric ordering without 20-digit overflow. Today uses numeric daily net values, with missing data at the end. Status groups the displayed badges. Server sorting groups explicit Demo/Trial/Practice and Real/Live names, leaving unknown or conflicting names last; unknown types are never guessed from account numbers.
- Only configured Master accounts show a compact amber M beside the account number. Investor accounts have no extra badge. Tooltip identifies configured mode; the program does not infer the actual password role from its characters.
- Once known trading history establishes activity, a historical login verification no longer overrides the Active/Inactive badge while closed. Unknown-history behavior otherwise remains documented in STATUS-LABELS-fa-en.md.

## Master credentials across entry points

- Excel keeps legacy Name/Platform/Login/Server/Investor/Folder compatibility, adding optional Mode and Master columns. Explicit Mode values are investor/master; a Master-only column implies master; both supplied without Mode default to investor. A generic Password column follows Mode. Missing/invalid selected credentials remain row-level failures.
- Registration, persistent verification, retry, direct MT4/MT5 verification and reports accept the selected Master password. Account edits invalidate proofs based on the active encrypted credential, including Master changes. Missing credentials fail before provisioning.
- Manual New Student offers Investor/Master selection. Existing CSV, account editor and backup Mode/Master data continue to work. Backup restore and Excel export/reimport preserve Master mode and credentials.
- Reporting and private verification issue no trading commands. Their private terminal launches disable automatic live trading for both modes; interactive user-opened Master terminals retain existing behavior.
- Both password fields are redacted from row errors; queue/result exports exclude passwords. Password-inclusive directory exports remain explicitly selected by the user. Passwords on disk remain DPAPI encrypted.

## Validation

1218 logical assertions passed; 34 UI assertions passed in each of Persian and English, plus the 11 Python IPC tests. One existing chart-retry test is skipped because python3 is absent from the Mono test image. Tests cover progress for 1/10 students, cancellation, stable sorting, numeric edge cases, Demo/Real classification, selection/focus retention, M-only marking, Master Excel/backup/queue/report credential selection and read-only report commands.

Builds target official .NET Framework 4.5 reference assemblies. Native Windows broker connectivity, native IPC authentication and MQL compilation with MetaEditor cannot be established by Linux/Mono simulations. This remains a preview for Windows validation.
