# MetaFactory 3.30.0

- Main toolbar: Export to Excel next to Report text, before Tools. Exports the entire saved directory regardless of filters. Includes account details, platform, server, copy path, mode and all group memberships, including missing copies. Saved passwords can be included or excluded before choosing a local file. Unreadable encrypted values are left blank and explicitly identified. Workbook is compatible with bulk import for its first six columns; only the first group is imported.
- Bulk connection checks: publish scoped initial authentication immediately, independently of history and process shutdown. Preserve later explicit authentication rejections. Poll every 150 ms. One bounded cleanup job may overlap preparing the next account and is joined before another terminal is started.
- MT4 buffered journal: after 12 seconds and a window stable for at least 3 seconds, close only this operation's process once and read its flushed journal. If inconclusive, restart once with a fresh session baseline within the original 90-second budget. Never classify an open window as authenticated.
- Runtime teardown is drained when the import worker finishes, including cancellation and failure.

Windows/broker end-to-end validation still requires the user's machine. Automated checks use synthetic login journals and runtimes.
