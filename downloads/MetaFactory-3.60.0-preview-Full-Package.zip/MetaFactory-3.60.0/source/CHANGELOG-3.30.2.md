# MetaFactory 3.30.2

- Extend early buffered-journal confirmation to MT5: after at least 8 seconds from launch and a window stable for 3 seconds, close only the verification process and read its flushed journal. MT4 keeps its existing 12-second grace.
- Only a fresh exact-account authentication confirms success. An inconclusive early check restarts once with a fresh journal baseline, within the original 90-second budget. Actual rejection remains failure. An already-written authorization still completes immediately.
- Preserve 3.30.1 waiting for the previous terminal to close and bounded background teardown. Add timing-only diagnostics around journal confirmation and early flush; passwords and raw journal messages are not logged.
- This reduces waiting when MT5 buffers its successful login journal; it does not guarantee an 8-second login or accelerate the broker's network authentication.
