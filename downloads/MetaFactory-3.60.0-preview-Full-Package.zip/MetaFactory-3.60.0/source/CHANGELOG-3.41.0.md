# 3.41.0 — same-Windows launch capacity investigation

Based on 3.40.1. Manual MT4 and MT5 launches have no application count cap; low memory remains advisory. This release does not claim that 33 or 70 native MT4 terminals have been successfully kept open.

- Removed earlier 40960/65536 KB interactive desktop heap presets. Microsoft KB947246 advises against a second SharedSection value above 20480 KB. Oversized values now prompt review; 20480 is no longer described as an insufficient count limit. Dialog and command-line setters reject oversized values. Applying the offered correction backs up the registry value, preserves other fields, requires Windows admin consent and a subsequent user-initiated restart. No registry change is automatic.
- Dispose temporary Process wrappers from repeated process discovery, UI refresh, queue checks, memory trimming and system reports. Long-lived launch/pending process owners remain separate.
- Observe manual terminal launches using a separate duplicated Windows process handle and a bounded timer. Record actual exit status, lifetime, native launch error code, system commit usage/limit and available physical memory, plus last observed per-process handles, USER/GDI counts and private bytes. Monitoring never kills terminals, changes the queue or restricts terminal counts. Logging is asynchronous and bounded; unknown metrics remain unknown. No account arguments or passwords are recorded.
- Include observations in System check and application logs. Configured desktop heap and live allocated desktop heap are labeled separately; allocation is not measured usage. Aggregate USER object counts are not treated as a 10000-object session cap.
- Preserve current-privilege child launches, report algorithms, MQL4/MQL5 scripts and deferred features.

Evidence: the supplied log records 59 distinct MT4 launches, first 32 surviving and following 27 exiting early, with configured heap 65536 KB and low available memory. It does not establish the exit reason, a universal MT4 hard cap, or that the configured heap is active. The old 40/64 MB advice is an actionable defect but is not established as the cause.

Microsoft reference: https://learn.microsoft.com/en-us/troubleshoot/windows-server/performance/desktop-heap-limitation-out-of-memory (KB947246). Its advice is not an MT4 capacity guarantee.

See SAME-WINDOWS-CAPACITY-fa.md for the controlled Windows verification. Native Windows APIs, broker terminals and a 33+ process workload cannot be exercised on this Linux build host.

Validation: 1588 C# checks passed, zero failed; one existing Unix chart retry check remains skipped because python3 is absent in the Mono container. 19 manual launch/heap UI checks per language (English and Persian) passed using a simulated 70 MT4 + 30 MT5 workload, plus 72 existing UI checks per language. Installer payload and assembly/PE versions match the tested app; embedded runtime, probes and MQL scripts match source. The report and bridge directories are byte-identical to 3.40.1. No real 33+ Windows-terminal test was possible here.
