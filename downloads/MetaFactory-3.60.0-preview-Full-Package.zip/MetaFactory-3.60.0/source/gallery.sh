#!/bin/sh
# One set of screenshots per look: gallery.sh OUTDIR
set -e
cd "$(dirname "$0")"
OUT=$1
for look in ${LOOKS:-blue green violet dark}; do
  W=$(mktemp -d -p ..)
  mkdir -p "$W/home/.fonts" "$W/data" "$W/copies" "$OUT/$look"
  for n in 01 02 03 04 05 06; do mkdir -p "$W/copies/MT5-$n"; : > "$W/copies/MT5-$n/terminal64.exe"; done
  for n in 01 02 03; do mkdir -p "$W/copies/MT4-$n"; : > "$W/copies/MT4-$n/terminal.exe"; done
  printf 'BaseDir=%s\nLook=%s\n' "$W/copies" "$look" > "$W/data/settings.ini"
  HOME="$W/home" XDG_CONFIG_HOME="$W/home/.config" MTM_SCALE=1 MTM_LOOK=$look MTM_GALLERY=1 \
    timeout 180 mono snapshot.exe --snapshot "$OUT/$look" "$W/data" 2>&1 | grep -v "^Gtk" || true
  HOME="$W/home" XDG_CONFIG_HOME="$W/home/.config" MTM_SCALE=1 MTM_LOOK=$look \
    timeout 120 mono setup-snapshot.exe --snapshot "$OUT/$look" 2>&1 | grep -v "^Gtk" || true
  rm -rf "$W"
done
