# MetaFactory 3.30.1

- Fix cascading bulk-import failures after a checked MetaTrader takes longer to close. A failed initial teardown result is rechecked against the previous copy, rather than latched permanently for the rest of the import.
- The next student shows a waiting message and resumes automatically after the previous terminal disappears. No timeout converts this wait into a login failure. Stop cancels the wait and leaves later rows uncreated.
- Keep preparing the next copy while background teardown runs. Before launching the next terminal, join our teardown and, if necessary, wait for the previous path to become free. No other process is closed or terminated by this wait.
- Joining teardown on dialog completion does not wait indefinitely for a manually launched or replacement terminal.
