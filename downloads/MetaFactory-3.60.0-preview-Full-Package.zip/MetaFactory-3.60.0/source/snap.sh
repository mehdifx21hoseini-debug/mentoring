#!/bin/sh
# Screenshots of every window on a virtual screen: snap.sh OUTDIR SCALE
set -e
cd "$(dirname "$0")"
OUT=$1; SCALE=${2:-1}
W=$(mktemp -d -p "$PWD/..")
mkdir -p "$W/home/.fonts" "$W/data" "$W/copies" "$OUT"
# Mono cannot measure fonts loaded from memory: the build check installs the same Vazirmatn files instead.
cp fonts/*.ttf "$W/home/.fonts/"
fc-cache -f "$W/home/.fonts" >/dev/null 2>&1 || true
for n in 01 02 03 04 05 06; do mkdir -p "$W/copies/MT5-$n"; : > "$W/copies/MT5-$n/terminal64.exe"; done
for n in 01 02 03; do mkdir -p "$W/copies/MT4-$n"; : > "$W/copies/MT4-$n/terminal.exe"; done
# Old full copies carry the editor, tester, uninstaller and an archive (sparse files: no real disk use).
for n in 01 02 03 04; do d="$W/copies/MT5-$n"; truncate -s 104M "$d/MetaEditor64.exe"; truncate -s 20M "$d/metatester64.exe"; truncate -s 5M "$d/uninstall.exe"; truncate -s 15M "$d/MetaEditor64.part1.rar"; mkdir -p "$d/Tester"; truncate -s 300M "$d/Tester/cache.dat"; done
# What the expert of versions before 3.12 left in two copies (offered by the cleanup tool).
for n in 03 04; do d="$W/copies/MT5-$n/MQL5"; mkdir -p "$d/Experts" "$d/Files/MTManager"; truncate -s 60K "$d/Experts/MTManagerMonitor.ex5"; truncate -s 3M "$d/Files/MTManager/history.txt"; done
# The server lists saved from MetaQuotes while building, so the server search has its real data offline.
for k in 4 5; do python3 -I -c 'import json,sys; d=json.load(open(sys.argv[1])); print("\n".join(d["mt"+sys.argv[2]]))' "../research/mq/servers$k.json" $k > "$W/data/servers-MT$k.txt" 2>/dev/null || true; done
printf 'BaseDir=%s\nDelaySeconds=5\nMinimized=true\nLight=true\nAutoStart=false\n' "$W/copies" > "$W/data/settings.ini"
export HOME="$W/home" XDG_CONFIG_HOME="$W/home/.config" DISPLAY=${DISPLAY:-:97} MTM_SCALE=$SCALE MTM_FONT=${MTM_FONT:-Vazirmatn}
timeout 180 mono snapshot.exe --snapshot "$OUT" "$W/data" 2>&1 | grep -v "^Gtk not found" || true
timeout 120 mono setup-snapshot.exe --snapshot "$OUT" 2>&1 | grep -v "^Gtk not found" || true
rm -rf "$W"
