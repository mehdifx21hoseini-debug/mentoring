# 3.46.0 — opt-in live account monitoring preview

Adds an independent read-only observer EA for MT4 and MT5 plus a modeless live monitor under Tools and the Refresh menu. Existing manual collectors and journal/cache/report calculations are unchanged from3.45.1.

The live monitor prepares reporters only for already-open managed copies. It compiles with the user's Windows MetaEditor, caches by source/compiler identity, deploys to a versioned Experts subdirectory and creates an account-bound preset. Initial attachment is manual on a new dedicated chart. Existing EAs are not replaced; the observer contains no trading calls. A successful preparation opts the copy into preserving its existing charts during future light-mode launches. Closing the monitor stops polling but does not detach the EA.

Snapshots normally publish once per second, with independent token/run/sequence identity and exclusive writer ownership. Current balance/equity/margin/positions/P&L+swap and current missing SL are separate from historical calculations. History is initialized once, rebuilt after detected changes and reconciled on staggered60–75second intervals. Source fingerprints are rechecked before publishing a history revision. This is change-triggered full-baseline replacement, not incremental deal streaming. Failed history scans back off rather than loop continuously.

The receiver rejects expired, mismatched, replayed and malformed data. Only a matching, complete full-history proof supplies overall DD and realized-day statistics. MT5 realized-day figures use matched deal timestamps, including partial exits, reversals and entry costs booked on the day, with closing-deal count. MT4 uses closed orders. Cash/credit are excluded. Full DD recalculates only on revision changes, not price ticks. Per-feed histories consume memory proportional to their size.

Monitoring is off by default and after reopening. Per-copy opt-in session configuration and setup instructions persist without account passwords. Live summary copy is separate from manual report text. Existing scheduling/delivery and terminal count policies are unchanged.

The requested persistent desktop-heap registry advisory is removed from the main page. No registry value is changed; manual diagnostics and RAM advisory remain available.

## Verification scope

Build targets Microsoft .NET Framework4.5 reference assemblies. Automated tests cover native source invariants, receiver identity/freshness/proof, deployment collisions and chart preservation, UI/store lifecycle, financial summaries, and existing manual/reporting behavior. Native source invariant checks do not substitute for MetaEditor compilation.

A mock Linux/Mono filesystem benchmark with50 feeds,1001 full-history events per feed and one changing position measured about233ms initial parsing and5ms median warm processing for all50, with exactly one DD calculation per baseline. It excludes terminal startup, MetaTrader APIs, broker networking and terminal memory. It is not a50-terminal load test.

No Windows/MetaEditor/live-broker runtime is available in the build environment. Native EA compilation, actual feed operation, Sandbox file visibility and large-terminal resource consumption remain destination-system validation requirements. See LIVE-SETUP-fa.md and LIVE_PROTOCOL.md.

Integrated logic suite: **2085 passed, 0 failed**. One existing Unix/Python-dependent chart-retry test was skipped. Installer embedded payload, PE/assembly versions and all embedded native source resources verified.

Live window smoke:20/20 checks across English/Persian. Existing schedule integration:20/20 English and20/20 Persian. Screenshots reviewed under Mono/Xvfb; Windows rendering and native terminal operation still require destination-system verification.
