# MetaFactory live feed, version 1

The manual report protocol and its files remain unchanged. Each opted-in personal terminal writes only under `MQL4/Files/MetaFactoryLive/<SessionToken>/` or `MQL5/Files/MetaFactoryLive/<SessionToken>/`. The controller supplies a persistent 32-hex-character token and expected login/server. Each EA initialization creates a new unique ASCII alphanumeric/hyphen RunId (1–96 characters). Sequence starts at 1 and strictly increases within that RunId. A stopped EA cannot be reported as live from an old file.

All files are UTF-16LE with BOM (UTF-8 with BOM is also readable). Write a temporary file, flush/close it, and atomically replace the destination. There are exactly three published filenames: `snapshot.txt`, `history-0.txt`, `history-1.txt`. Never include credentials, commands or arbitrary paths.

`snapshot.txt`, normally once a second, is tab-separated:

```text
MLIVE  1  MT4|MT5
Q  <SessionToken>
R  <RunId>  <sequence>  <UTC Unix seconds from TimeGMT>
A  <actual login>  <actual server>  <currency>
S  <connected 0|1>  <state>
V  <balance>  <equity>  <margin>  <free margin>  <credit>
H  <history revision>  <slot 0|1>
O  <ticket> <symbol> <side 0buy|1sell> <volume> <server open epoch seconds> <open price> <current SL> <TP> <profit> <swap> <entry SL> <current price> <commission>
END  <number of O rows>
```

Every metadata row appears exactly once; O has the same 14 fields (including the O tag) as current MTR2 O records. States: `bootstrap`, `ready`, `history-pending`, `history-unconfirmed`, `disconnected`, `identity-mismatch`, `stopped`, `error`. Revision 0 means no baseline. A positive revision references exactly that revision in the named slot. Open positions are complete snapshots, not deltas. All numeric values must be finite; ticket/sequence positive, revision nonnegative; credit/debt monetary values may be negative. Maximum 10,000 positions and 2 MiB snapshot.

History baseline uses existing MTR2 with full J/JC proof and adds `LIVE\t1\t<SessionToken>\t<RunId>\t<revision>` plus `Q\t<SessionToken>`. LIVE metadata is not included in END's T/O/B/J count. Write the alternate slot completely before publishing its revision in snapshot.txt. Bootstrap and changed history trigger baseline exports; unchanged history does not export each second. Native periodic reconciliation may discover same-count corrections. Maximum baseline size is 64 MiB. A slot overwritten two generations later is rejected unless LIVE identity/revision matches the current snapshot.

Receiver identity-checks platform/login/server/token. It validates full-history proof, baseline identity, run and revision, and compares baseline balance with snapshot balance using native reconciliation tolerance. A mismatch shows fresh positions with history pending; no old history is presented as current. The baseline is parsed only when its reference changes (failed availability retries are throttled). It is separate from the manual journal cache.

Heartbeat expires after 10 seconds, rejects timestamps over 5 seconds into the future, and repeated/decreasing sequence does not refresh receipt time. History revision cannot decrease within the same RunId. Run changes retire the previous RunId so it cannot replay later. Late new runs with a heartbeat earlier than the accepted run are rejected. Disconnect, stop, identity mismatch, stale/partial/malformed files expose no current money/position values. Bootstrap/history-pending may expose fresh connected current positions, while historical metrics remain unavailable until the matching proof is ready.

Snapshot balances and positions are live values as of heartbeat. Position timestamps use broker time; heartbeat uses UTC. No current-day closed P/L, daily historical floating, or drawdown may be inferred from the heartbeat's UTC date. Consumers treat cached AccountJournal objects as immutable and recompute historical analytics only on a new baseline revision.

Memory use scales with the number of opted-in feeds and their retained history. Each reader caches one bounded parsed baseline; there is no arbitrary feed-count cap. Applications should measure actual resource use on the target computer.

## Bootstrap and startup diagnostics (EA1.01 / app3.46.2)

Automatic Run atomically writes UTF-16LE+BOM `MetaFactoryLive/bootstrap.txt` under this copy's MQL Files sandbox. Four lines: `MLBOOT\t1` (literal tab), 32hex session token, positive signed64 login, server. No passwords. Native size bound2048bytes. Bootstrap is used only when all three explicit inputs are empty; partial explicit inputs never fall back. Actual account identity is still checked before any current money is exposed.

Recoverable session initialization failures retry every5seconds while the EA remains initialized. `init-status.txt` and Experts log identify stage/error. These diagnostics have no identity/freshness proof and must not be shown as live account data. A valid current snapshot remains the only readiness proof. Owner generation writes are verified by bounded readback. A timer creation failure remains an explicit initialization failure.

## Ownership update (EA1.02 / app3.47.1)

The persistent exclusive owner.lock handle is retired. EA1.02 uses terminal-local temporary Global Variables with atomic compare-and-swap ownership, per-owner heartbeat and a30second stale-owner budget. A claimant abandons takeover if the prior owner renewed during the claim; every publishing path refreshes/rechecks ownership. Hashing/writing pulses renew a healthy owner; an old owner which lost the claim cannot publish. Generation is terminal-local and RunId also retains GMT/tick/chart identity. Private .part names include RunId to avoid temporary-file interference between old/new publishers.

Upgrade occurs with the terminal closed: host backs up saved charts, removes only recognized MetaFactory observer blocks and starts one new short root-level Expert alias. The host cannot claim an EA1.01 file-lock observer will coordinate with EA1.02 unless that old attachment has been retired; close/reopen during this upgrade is required. Current freshness, identity and full-history proof rules are unchanged. The C++ mock test in test/native_live_lease_model.py validates extracted ownership decisions, not MQL runtime semantics.
