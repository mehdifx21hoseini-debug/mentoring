# 3.55.1

- Public report mode: any private /start visitor receives menus and can request reports without manual user IDs or enrollment.
- Compact setup: token, enable and save/connect; public access explained in the window. Saving opts this installation into public reports; existing private profiles retain private mode on passive upgrade.
- Public command scope and default menu button provisioned for all private chats.
- Manual-send recipients discovered automatically from incoming private chats; existing explicit recipient lists are retained for legacy private mode.
- Callback chat ownership, finite work queues, request-time freshness, cache distinction, account binding and administrator separation preserved.
- No supplied credential in public artifacts. Native/financial sources unchanged. Direct real Telegram validation remains blocked by this environment's proxy403; Windows activation required.
