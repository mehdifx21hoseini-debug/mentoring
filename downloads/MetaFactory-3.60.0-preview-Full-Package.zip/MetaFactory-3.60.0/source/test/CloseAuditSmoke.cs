using System;using System.IO;using System.Linq;using MTManager;
class CloseAuditSmoke{
static int checks;static void Check(bool v,string name){if(!v)throw new Exception(name);checks++;}
static void Main(){string root=Path.Combine(Path.GetTempPath(),"close-audit-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=root;try{
var copy=new Instance{Name="MT4-03",Kind=Kind.MT4,Dir=Path.Combine(root,"MT4-03")};var other=new Instance{Name="MT4-04",Kind=Kind.MT4,Dir=Path.Combine(root,"MT4-04")};var now=DateTime.UtcNow;
TerminalCloseAudit.Record(1234,456,copy.Exe,"manual-close",now);
Check(TerminalCloseAudit.MatchingRequest(copy,1234,now.AddSeconds(-2),now.AddSeconds(2)).Contains("manual-close"),"matching close intent found");
Check(!TerminalCloseAudit.MatchingRequest(other,1234,now.AddSeconds(-2),now.AddSeconds(2)).Contains("app-close-request=manual-close"),"exact path guard");
Check(!TerminalCloseAudit.MatchingRequest(copy,1235,now.AddSeconds(-2),now.AddSeconds(2)).Contains("app-close-request=manual-close"),"exact PID guard");
Check(!TerminalCloseAudit.MatchingRequest(copy,1234,now.AddHours(1),now.AddHours(2)).Contains("app-close-request=manual-close"),"old run guard");
TerminalCloseAudit.Record(1234,456,copy.Exe,"Password=must-not-log",now);Check(!File.ReadAllText(TerminalCloseAudit.FilePath).Contains("must-not-log"),"arbitrary reason/secret is never stored");
for(int n=0;n<220;n++)TerminalCloseAudit.Record(1234,456,copy.Exe,"report-helper-close",now);
Check(File.ReadAllLines(TerminalCloseAudit.FilePath).Length==192,"audit bounded across writes");
string[] fields=new string[12];fields[0]="terminal.exe";fields[3]="fault.dll";fields[6]="c0000005";fields[8]="0x4d2";fields[10]=copy.Exe;fields[11]="Password=must-not-export";
string match=TerminalCloseAudit.FaultMatch(fields,1234,copy.Exe);Check(match!=null&&match.Contains("c0000005")&&!match.Contains("must-not-export"),"Windows schema extracts only safe fault metadata");
Check(TerminalCloseAudit.FaultMatch(fields,1235,copy.Exe)==null&&TerminalCloseAudit.FaultMatch(fields,1234,other.Exe)==null,"fault matching rejects other PID/path");
Check(TerminalCloseAudit.FaultMatch(new string[2],1234,copy.Exe)==null,"unknown event schema not guessed");
Check(PendingStart.ProtectedReady(2,true)==null&&PendingStart.ProtectedReady(15,true)=="journal"&&PendingStart.ProtectedReady(900,false)=="time","early config mention cannot remove file before grace; max bound retained");
Directory.CreateDirectory(copy.Dir);string ini=Path.Combine(copy.Dir,"mtm-live-start-test.ini");File.WriteAllText(ini,"fake credential fixture");var start=DateTime.Now.AddMinutes(-1);string journal=ConnectionCheck.JournalFile(copy,start.Date);Directory.CreateDirectory(Path.GetDirectoryName(journal));File.WriteAllText(journal,"0\t"+start.AddSeconds(1).ToString("HH:mm:ss.fff")+"\tStarted with configuration file '"+ini+"'\n");var pending=new System.Collections.Generic.List<PendingStart>{new PendingStart{Copy=copy,Path=ini,Time=start,WaitForConfigRead=true}};
pending=Launcher.CleanStartFiles(pending,start.AddSeconds(2),false);Check(pending.Count==1&&File.Exists(ini),"acknowledged file survives real cleanup during startup grace");File.Delete(journal);pending=Launcher.CleanStartFiles(pending,start.AddSeconds(16),false);Check(pending.Count==0&&!File.Exists(ini),"cached acknowledgement cleans file after grace even if journal rotates");
foreach(var kind in new[]{Kind.MT4,Kind.MT5}){var lines=LiveAutoStart.Lines(kind,"EA","session.set","EURUSD");Check(lines.Contains("Script=")&&lines.Any(l=>l=="ShutdownTerminal=false"||l=="ShutdownTerminal=0"),"live startup clears inherited script and disables automatic shutdown "+kind);}
Console.WriteLine("CLOSE AUDIT PASS "+checks);
}finally{Directory.Delete(root,true);}}}
