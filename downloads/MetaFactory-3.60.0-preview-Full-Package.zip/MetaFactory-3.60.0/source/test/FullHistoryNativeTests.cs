using System;

namespace MTManager
{
    static partial class Tests
    {
        // Structural protocol checks only. These do not substitute for MetaEditor compilation
        // or a real broker test of the terminal's delivered history.
        static void FullHistoryNativeChecks()
        {
            string mt4 = ReportScript.SourceText(Kind.MT4), mt5 = ReportScript.SourceText(Kind.MT5);
            Check(mt4.Contains("#define SCRIPT_VERSION \"1.23\"") && mt5.Contains("#define SCRIPT_VERSION \"1.26\""),
                "new native chronology protocol invalidates older MT4 and MT5 reporter versions");
            foreach (string source in new[] { mt4, mt5 })
            {
                int curve = source.IndexOf("Line(h, \"J\\t\"", StringComparison.Ordinal);
                int metadata = source.IndexOf("Line(h, \"JC\\t1\\t\"", StringComparison.Ordinal);
                int end = source.IndexOf("Line(h, \"END\\t\"", StringComparison.Ordinal);
                Check(curve >= 0 && metadata > curve && end > metadata,
                    "complete chronology rows and explicit metadata precede the native final record count");
                Check(source.Contains("curveCount++; records++; curveSum += net;"),
                    "chronology records contribute both their independent count and total END count");
                Check(source.Contains("N(snapshotBalance)") && source.Contains("MathIsValidNumber(curveSum)")
                    && source.Contains("bool curveReconciled = curveScanOk && addsUp"),
                    "chronology metadata uses a consistent balance snapshot and cannot certify nonfinite or incomplete data");
                Check(source.Contains("GetTickCount() - begun < 8000") && source.Contains("RetryFullHistory()"),
                    "unreconciled full history receives a bounded retry without unbounded waiting");
                Check(source.Contains("fullHistoryStable") && source.Contains("GetTickCount() - stable >= 2000"),
                    "last-moment history arriving at retry timeout is not certified before stability");
            }
            int j4 = mt4.IndexOf("Line(h, \"J\\t\"", StringComparison.Ordinal);
            Check(j4 < mt4.IndexOf("if(OrderOpenTime() < base) continue;", StringComparison.Ordinal)
                && j4 < mt4.IndexOf("if(OrderCloseTime() < base) continue;", StringComparison.Ordinal),
                "MT4 chronology includes initial funding and trades before the requested report window");
            Check(mt4.Contains("type == OP_BUY || type == OP_SELL || type == 6")
                && mt4.Contains("IntegerToString(type == 6 ? 2 : type)") && mt4.Contains("(long)eventTime * 1000"),
                "MT4 balance events normalize cash type and timestamp while credit/canceled orders stay outside the curve");
            Check(mt4.Contains("if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) { historyScanOk = false;")
                && mt4.Contains("curveSeen == histCount") && mt4.Contains("OrdersHistoryTotal() == histCount"),
                "MT4 selection failures and changing history invalidate full-history metadata");
            Check(mt4.Contains("if(historyScanOk && AddsUp()) return true;") && mt4.Contains("(posted ? \"1\" : \"0\")"),
                "MT4 reconciled fast path has no extra wait and metadata records whether All History was requested");

            int j5 = mt5.IndexOf("Line(h, \"J\\t\"", StringComparison.Ordinal);
            Check(j5 < mt5.IndexOf("if(t < base) continue;", StringComparison.Ordinal)
                && mt5.Contains("HistorySelect(0, FAR_DATE)"),
                "MT5 chronology is selected from zero and is emitted before the display-window filter");
            Check(mt5.Contains("HistoryDealGetInteger(d, DEAL_TIME_MSC, eventTimeMs)")
                && mt5.Contains("HistoryDealGetDouble(d, DEAL_COMMISSION, commission)")
                && mt5.Contains("HistoryDealGetDouble(d, DEAL_FEE, fee)")
                && mt5.Contains("HistoryDealGetDouble(d, DEAL_SWAP, swap)"),
                "MT5 chronology includes timestamped entry fees and all net balance components with checked getters");
            Check(mt5.Contains("type != DEAL_TYPE_CREDIT && !(bonusExcluded && type == DEAL_TYPE_BONUS)")
                && mt5.Contains("MathAbs(sumAll - sumBonus - snapshotBalance) <= curveTolerance"),
                "MT5 credits are excluded and bonus exclusion requires the existing explicit balance reconciliation alternative");
            Check(mt5.Contains("curveSeen == dealCount") && mt5.Contains("HistoryDealsTotal() == dealCount")
                && mt5.Contains("if(!fieldsOk || (long)d <= 0 || eventTimeMs <= 0 || !MathIsValidNumber(net)) curveScanOk = false;"),
                "MT5 invalid identifiers, failed property reads, invalid amounts and changing counts cannot certify a whole-account curve");
        }
    }
}
