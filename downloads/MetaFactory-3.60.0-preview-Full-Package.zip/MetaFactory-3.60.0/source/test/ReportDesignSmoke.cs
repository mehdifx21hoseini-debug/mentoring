using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using MTManager;

static class ReportTextBrowseSmoke
{
    static int checks;
    static void Assert(bool ok, string message) { checks++; if (!ok) throw new Exception(message); }
    static object Get(object value, string name) { return value.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public).GetValue(value); }
    static void Set(object value, string name, object field) { value.GetType().GetField(name).SetValue(value, field); }
    static void Call(object value, string name, params object[] args) { value.GetType().GetMethod(name, BindingFlags.Instance | BindingFlags.NonPublic).Invoke(value, args); }
    static void Pump() { for (int n = 0; n < 12; n++) { Application.DoEvents(); Thread.Sleep(10); } }
    [STAThread] static int Main(string[] args)
    {
        string root = Path.Combine(Path.GetTempPath(), "mtm-report-browse-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(root); AppPaths.DataDirOverride = root;
        Lang.En = args.Contains("en"); Application.EnableVisualStyles();
        var assembly = typeof(Account).Assembly; assembly.GetType("MTManager.Theme").GetMethod("Init").Invoke(null, null);
        var names = new List<string> { "علی کریمی", "BETA student", "Cedar", "Unread", "Student five", "Student six", "Student seven", "Student eight" };
        int entryCalls = 0;
        Func<PanelRange, DateTime, DateTime, List<TextEntry>> entries = (kind, a, b) =>
        {
            entryCalls++;
            return names.Select((name, k) => new TextEntry { Name = name, Login = (8001 + k).ToString(), Number = 11 + k,
                View = k == 3 ? null : new PanelView { ReturnPct = kind == PanelRange.Month ? -k : k, Currency = "USD" } }).ToList();
        };
        object source = Activator.CreateInstance(assembly.GetType("MTManager.ReportTextSource"));
        Set(source, "Names", names); Set(source, "Entries", entries);
        Set(source, "RangeOf", new Func<PanelRange, DateTime, DateTime, ReportRange>((kind, a, b) => new ReportRange { From = new DateTime(2026, 11, 20), To = new DateTime(2026, 11, 21) }));
        Set(source, "NotReadToday", new Func<List<string>>(() => new List<string>())); Set(source, "StaleSince", new Func<DateTime?>(() => null));
        Set(source, "Reading", new Func<int>(() => 0)); Set(source, "ReadNow", new Action<PanelRange, DateTime, DateTime>((kind, a, b) => { }));
        Set(source, "Fingerprint", new Func<string>(() => "unchanged")); Set(source, "StaleNotes", new Func<List<string>>(() => names.Select(n => "").ToList()));
        try
        {
            using (var dialog = (Form)Activator.CreateInstance(assembly.GetType("MTManager.ReportTextDialog"), new object[] { source, new Settings(), DateTime.Today, DateTime.Today }))
            {
                dialog.Size = new Size(1080, 720); dialog.Show(); Pump();
                if (args.Any(a => a.EndsWith(".png")))
                    using (var shot = new Bitmap(dialog.Width, dialog.Height)) { using (var graphics = Graphics.FromImage(shot)) graphics.CopyFromScreen(dialog.Location, Point.Empty, dialog.Size); shot.Save(args.First(a => a.EndsWith(".png"))); }
                var roster = (IList)Get(dialog, "roster"); var list = (Panel)Get(dialog, "rosterPanel");
                var search = (TextBox)Get(Get(dialog, "search"), "Box"); var sort = (ComboBox)Get(dialog, "sort");
                var copy = (Button)Get(dialog, "copyButton"); var save = (Button)Get(dialog, "saveButton");
                var preview = (RichTextBox)Get(dialog, "box");
                var rangeBounds=((Control)Get(dialog,"range")).RectangleToScreen(((Control)Get(dialog,"range")).ClientRectangle);
                var allFields=dialog.Controls.Find("AllReportFields",true).Single();
                Assert(!rangeBounds.IntersectsWith(allFields.RectangleToScreen(allFields.ClientRectangle)),"include-all action never overlaps range tabs in either language");
                var ticks=(IEnumerable)Get(dialog,"ticks");int tickCount=0;
                foreach(var tick in ticks){var check=(Control)tick.GetType().GetProperty("Value").GetValue(tick,null);tickCount++;Assert(check.Width>=TextRenderer.MeasureText(check.Text,check.Font).Width+12,"report checkbox label has readable width: "+check.Text);Rectangle bounds=check.RectangleToScreen(check.ClientRectangle);for(Control parent=check.Parent;parent!=null;parent=parent.Parent)Assert(parent.RectangleToScreen(parent.ClientRectangle).Contains(bounds),"report content checkbox is entirely visible through every parent: "+check.Text);}
                Assert(tickCount==12,"all twelve original report-content controls remain accessible");
                var rangeControl=Get(dialog,"range");rangeControl.GetType().GetProperty("Selected").SetValue(rangeControl,4,null);((Action)rangeControl.GetType().GetField("Changed",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(rangeControl))();Pump();
                Assert(((Control)Get(dialog,"fromBox")).Visible && ((Control)Get(dialog,"toBox")).Visible,"custom date inputs are available in redesigned report settings");
                rangeControl.GetType().GetProperty("Selected").SetValue(rangeControl,0,null);((Action)rangeControl.GetType().GetField("Changed",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(rangeControl))();Pump();
                Assert(((List<int>)Get(dialog, "visibleIndices")).Count == 8, "all supplied students appear initially");
                Assert(!list.HorizontalScroll.Visible, "compact roster needs no horizontal scrolling");
                Assert(copy.Visible && save.Visible && copy.Bottom <= copy.Parent.ClientSize.Height, "copy and save buttons remain available at small window size");
                roster[1].GetType().GetProperty("On").SetValue(roster[1], false, null); Call(dialog, "Rebuild", false);
                int before = entryCalls; list.AutoScrollPosition = new Point(0, 400); Pump(); search.Text = "علي كريمي"; Pump();
                Assert(((List<int>)Get(dialog, "visibleIndices")).SequenceEqual(new[] { 0 }), "Persian/Arabic search filters roster by original identity");
                Assert(preview.Text.Contains("علی کریمی") && !preview.Text.Contains("Cedar"), "preview excludes hidden students");
                Assert(((Control)roster[0]).Top >= 0, "filter after scrolling restores first visible row");
                Assert(!list.HorizontalScroll.Visible, "filtering removes unused scrolling without retaining hidden-row widths");
                Assert(entryCalls == before, "typing search does not rebuild account metrics");
                search.Text = "٨٠٠٣"; Pump();
                Assert(preview.Text.Contains("Cedar") && !preview.Text.Contains("علی کریمی"), "account digits filter generated text consistently");
                search.Text = "absent-account"; Pump();
                Assert((string)Get(dialog, "text") == "" && !copy.Enabled && !save.Enabled && preview.Text.Length > 0, "no-match message is displayed but never exported/copied as report text");
                search.Clear(); sort.SelectedIndex = 1; Pump();
                Assert(((List<int>)Get(dialog, "visibleIndices")).First() == 7 && ((List<int>)Get(dialog, "visibleIndices")).Last() == 3, "descending return puts best first and unknown last");
                Assert(!(bool)roster[1].GetType().GetProperty("On").GetValue(roster[1], null) && !preview.Text.Contains("BETA student"), "search/sort preserve unchecked students");
                Assert(((Control)roster[7]).Top < ((Control)roster[0]).Top, "roster positions follow return order");
                Assert(preview.Text == (string)Get(dialog, "text"), "preview uses exactly the text supplied to copy/save");
                sort.SelectedIndex = 2; Pump(); Assert(((List<int>)Get(dialog, "visibleIndices")).First() == 0, "ascending return reverses known values");
                object range = Get(dialog, "range"); range.GetType().GetProperty("Selected").SetValue(range, 3, null); Call(dialog, "Rebuild", true); Pump();
                Assert(((List<int>)Get(dialog, "visibleIndices")).First() == 7, "changing selected date range recomputes return order");
                Assert(!(bool)roster[1].GetType().GetProperty("On").GetValue(roster[1], null), "range change preserves checkbox choices");
                sort.SelectedIndex = 0; Pump(); Assert(((List<int>)Get(dialog, "visibleIndices")).SequenceEqual(Enumerable.Range(0, 8)), "default sort restores initial roster order");
                search.Text = "8003"; Call(dialog, "SetRoster", false); search.Clear(); Pump();
                Assert(!(bool)roster[2].GetType().GetProperty("On").GetValue(roster[2], null) && (bool)roster[0].GetType().GetProperty("On").GetValue(roster[0], null), "select-none during search changes visible matches only");
                dialog.Close(); Pump();
            }
            Console.WriteLine("PASS " + checks + " report-text UI checks (" + (Lang.En ? "en" : "fa") + ")"); return 0;
        }
        catch (Exception e) { Console.Error.WriteLine(e); return 1; }
        finally { try { Directory.Delete(root, true); } catch { } }
    }
}
