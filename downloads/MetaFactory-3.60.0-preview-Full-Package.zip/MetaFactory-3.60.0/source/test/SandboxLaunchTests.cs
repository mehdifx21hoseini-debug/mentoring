using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MTManager
{
    static partial class Tests
    {
        static void SandboxLaunchChecks()
        {
            string temp = Path.Combine(Path.GetTempPath(), "metafactory-sandbox-tests-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(temp);
            try
            {
                var map = new SandboxLaunch.Assignments(temp);
                string first = null;
                for (int n = 0; n < 70; n++)
                {
                    string box = map.Assign(Path.Combine(temp, "MT4-" + n));
                    if (n == 0) first = box;
                    if (n < 24) Equal(first, box, "first 24 MT4 copies share one managed box");
                    Check(box.StartsWith("MetaFactory_", StringComparison.Ordinal) && box != "DefaultBox", "only dedicated owned boxes are assigned");
                }
                Equal(3, map.Boxes.Values.Distinct().Count(), "70 overflow copies use three groups");
                Check(map.Boxes.Values.GroupBy(x => x).All(x => x.Count() <= 24), "no managed group exceeds 24 copies");
                string path = Path.Combine(temp, "assignments.tsv"); map.Save(path);
                var restored = SandboxLaunch.Assignments.Read(path, temp);
                Equal(map.Owner, restored.Owner, "ownership identity survives restart");
                Equal(first, restored.Assign(Path.Combine(temp, "MT4-0")), "assigned copy stays in its box after restart");
                Equal(70, restored.Boxes.Count, "repeated assignment does not consume another box slot");
                restored.Save(path);
                Equal(70, SandboxLaunch.Assignments.Read(path, temp).Boxes.Count, "atomic replacement preserves all mappings");
                Check(!restored.ValidBox("DefaultBox") && !restored.ValidBox("MetaFactory_FOREIGN_1"), "foreign/default boxes cannot be accepted from a map");
                File.WriteAllText(path, "invalid-owner\n"); bool invalid = false;
                try { SandboxLaunch.Assignments.Read(path, temp); } catch (UserMessage) { invalid = true; }
                Check(invalid, "corrupt map fails closed rather than reassigning existing copies");
                Equal("\"C:\\a b\\\\\"", SandboxLaunch.Quote("C:\\a b\\"), "directory trailing slash is escaped without swallowing next argument");
                Equal("\"a\\\"b\"", SandboxLaunch.Quote("a\"b"), "embedded quotes cannot inject launcher switches");
                Check(SandboxLaunch.ManagedDirectoryRule(Path.Combine(temp, "MT4 copy 1")).EndsWith("MT4 copy 1\\", StringComparison.Ordinal), "narrow managed directory preserves spaces and trailing separator");
                foreach (string bad in new[] { Path.GetPathRoot(temp), "relative-copy", Path.Combine(temp, "comma,copy"), Path.Combine(temp, "%TEMP%"), Path.Combine(temp, "wild*card"), Path.Combine(temp, "question?"), Path.Combine(temp, "line\nbreak") })
                {
                    bool rejected = false;
                    try { SandboxLaunch.ManagedDirectoryRule(bad); } catch (UserMessage) { rejected = true; }
                    Check(rejected, "root, relative, expanded or parsed rule paths fail closed");
                }
                string iniPath = @"C:\Meta Trader\MT4-29\";
                string iniArg = SandboxLaunch.IniQuote(iniPath);
                // Pinned SbieIni CmdCopyString skips the leading quote and copies literally to the closing quote.
                string parsedIniPath = iniArg.Substring(1, iniArg.IndexOf('"', 1) - 1);
                Equal(iniPath, parsedIniPath, "SbieIni's literal parser retains exactly one trailing separator");
                Check(SandboxLaunch.Quote(iniPath) != iniArg, "SbieIni literal quoting remains distinct from Windows process-argument escaping");
                bool badIni = false;
                try { SandboxLaunch.IniQuote("bad\"argument"); } catch (UserMessage) { badIni = true; }
                Check(badIni, "SbieIni quoted arguments reject embedded delimiters");
                var previous = new HashSet<int> { 12 };
                string terminal = Path.Combine(temp, "MT4-0", "terminal.exe");
                Check(SandboxLaunch.ExpectedTerminal(first, terminal, 100, previous, 15, first, 110, terminal), "only a fresh exact terminal in the intended box is accepted");
                Check(!SandboxLaunch.ExpectedTerminal(first, terminal, 100, previous, 15, "DefaultBox", 110, terminal), "a terminal in another box is rejected");
                Check(!SandboxLaunch.ExpectedTerminal(first, terminal, 100, previous, 15, first, 110, Path.Combine(temp, "Start.exe")), "launcher PID/path can never stand in for the terminal");
                Check(!SandboxLaunch.ExpectedTerminal(first, terminal, 100, previous, 12, first, 110, terminal), "a PID present before this launch is rejected");
                Check(!SandboxLaunch.ExpectedTerminal(first, terminal, 100, previous, 15, first, 99, terminal), "an old process creation timestamp is rejected");
                Check(!SandboxLaunch.ExpectedTerminal(first, terminal, 100, previous, 15, first, 110, null), "unverifiable executable identity fails closed");
                var roundtrip = new Settings(); bool said = false;
                roundtrip.Set("SandboxieOverflow", "0", ref said);
                Check(!roundtrip.SandboxieOverflow && roundtrip.Lines().Contains("SandboxieOverflow=0"), "routing off round trips through settings lines");
                roundtrip.Set("SandboxieOverflow", "1", ref said);
                Check(roundtrip.SandboxieOverflow && roundtrip.Lines().Contains("SandboxieOverflow=1"), "routing on round trips through settings lines");
                roundtrip.Set("SandboxieOverflow", "garbage", ref said);
                Check(roundtrip.SandboxieOverflow, "malformed setting cannot silently disable routing");
                Check(BackupFormat.PortableSettings.Contains("SandboxieOverflow"), "backup retains the user's routing preference");
                var settings = new Settings { SandboxieOverflow = false, MaxMt4 = 777 };
                Check(!SandboxLaunch.IsEnabled(settings), "disabled routing stays native");
                Equal(777, SandboxLaunch.ReportLimit(settings), "disabled routing preserves legacy report admission");
                if (Environment.OSVersion.Platform != PlatformID.Win32NT)
                {
                    Check(!SandboxLaunch.Available && !SandboxLaunch.IsSandboxedPid(1), "non-Windows makes no native Sandboxie calls");
                    settings.SandboxieOverflow = true;
                    Check(!SandboxLaunch.IsEnabled(settings), "enabled setting alone does not claim Sandboxie is installed");
                    Equal(777, SandboxLaunch.ReportLimit(settings), "unavailable Sandboxie preserves legacy report admission");
                }
            }
            finally { Directory.Delete(temp, true); }
        }
    }
}
