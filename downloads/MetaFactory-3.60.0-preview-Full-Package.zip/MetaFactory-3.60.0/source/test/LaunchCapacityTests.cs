using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;

namespace MTManager
{
    static partial class Tests
    {
        static void LaunchCapacityChecks()
        {
            var unknown = new LaunchCapacityDiagnostics.ResourceSnapshot();
            Check(unknown.Text().Contains("ram-free-mb=unknown") && unknown.Text().Contains("commit-limit-mb=unknown"), "missing capacity counters are unknown, never invented zero");
            string unknownExit = LaunchCapacityDiagnostics.ExitEvidence(null, unknown);
            Check(unknownExit.Contains("exit-code=unknown") && unknownExit.Contains("cause unknown") && !unknownExit.Contains("low resource"), "unobserved exit is not a terminal cap or resource diagnosis");
            var pressure = new LaunchCapacityDiagnostics.ResourceSnapshot { AvailablePhysicalMb = 456, CommitUsedMb = 7900, CommitLimitMb = 8000 };
            string normal = LaunchCapacityDiagnostics.ExitEvidence(0, pressure);
            Check(normal.Contains("normal exit code") && normal.Contains("not proof of exit cause"), "normal exit and low RAM do not establish a cause");
            string unusual = LaunchCapacityDiagnostics.ExitEvidence(42, unknown);
            Check(unusual.Contains("0x0000002A") && unusual.Contains("cause unknown"), "exit code retains hex value without inventing its meaning");
            string commit = LaunchCapacityDiagnostics.ExitEvidence(unchecked((int)0xC000012D), pressure);
            Check(commit.Contains("0xC000012D") && commit.Contains("native memory/resource status"), "known native resource status distinguished from a low-RAM coincidence");
            Equal("MT4-33__secret_path", LaunchCapacityDiagnostics.SafeCopy("MT4-33\r\nsecret/path"), "copy identifiers cannot insert extra log records or path separators");
            Check(LaunchCapacityDiagnostics.SafeCopy(new string('x', 100)).Length == 64, "copy identifier length bounded");
            var counterType = typeof(LaunchCapacityDiagnostics).GetNestedType("ProcessMemoryCounters", System.Reflection.BindingFlags.NonPublic);
            Equal(IntPtr.Size == 8 ? 80 : 44, System.Runtime.InteropServices.Marshal.SizeOf(counterType), "PROCESS_MEMORY_COUNTERS_EX layout matches native pointer width");
            if (Environment.OSVersion.Platform != PlatformID.Win32NT)
                Check(LaunchCapacityDiagnostics.CaptureResources().CommitLimitMb == -1, "unsupported OS counters remain explicitly unknown");
            LaunchCapacityDiagnostics.Watch(null, "nothing");
            LaunchCapacityDiagnostics.Failure("capacity-native-failure", new Win32Exception(1455, "private-command password=SHOULD_NOT_BE_LOGGED"));
            var until = Stopwatch.StartNew();
            while (!LaunchCapacityDiagnostics.Summary().Contains("copy=capacity-native-failure") && until.ElapsedMilliseconds < 3000) Thread.Sleep(20);
            string failure = LaunchCapacityDiagnostics.Summary();
            Check(failure.Contains("native-code=1455") && !failure.Contains("SHOULD_NOT_BE_LOGGED"), "native creation code captured without logging exception messages containing secrets");
            if (File.Exists("/bin/sh") && File.Exists("/bin/sleep"))
            {
                using (var immediate = Process.Start(new ProcessStartInfo("/bin/sh", "-c \"exit 42\"") { UseShellExecute = false }))
                {
                    immediate.WaitForExit(); // The hardest registration race: process already finished before Watch.
                    LaunchCapacityDiagnostics.Watch(immediate, "capacity-immediate-42");
                    until.Restart();
                    while (!LaunchCapacityDiagnostics.Summary().Split('\n').Any(x => x.StartsWith("exit watch=") && x.Contains("copy=capacity-immediate-42 ")) && until.ElapsedMilliseconds < 3000) Thread.Sleep(20);
                    string summary = LaunchCapacityDiagnostics.Summary();
                    var records = summary.Split('\n').Where(x => x.StartsWith("exit watch=") && x.Contains("copy=capacity-immediate-42 ")).ToList();
                    Check(records.Count == 1 && records[0].Contains("exit-code=42 (0x0000002A)"), "exit-before-registration captured exactly once with real child exit code");
                    Check(immediate.ExitCode == 42, "observer did not dispose the original caller-owned Process");
                    LaunchCapacityDiagnostics.Watch(immediate, "capacity-immediate-42"); Thread.Sleep(50);
                    Equal(1, LaunchCapacityDiagnostics.Summary().Split('\n').Count(x => x.StartsWith("exit watch=") && x.Contains("copy=capacity-immediate-42 ")), "duplicate registration after observed exit cannot produce a second exit record");
                }
                using (var live = Process.Start(new ProcessStartInfo("/bin/sleep", "20") { UseShellExecute = false }))
                {
                    try
                    {
                        var elapsed = Stopwatch.StartNew(); LaunchCapacityDiagnostics.Watch(live, "capacity-live"); elapsed.Stop();
                        Check(elapsed.ElapsedMilliseconds < 1000, "watch registration does not wait for a running terminal to exit");
                        LaunchCapacityDiagnostics.Watch(live, "capacity-live");
                        Thread.Sleep(100);
                        string liveSummary = LaunchCapacityDiagnostics.Summary();
                        Check(liveSummary.Contains("private-bytes=") && liveSummary.Contains("working-set-bytes="), "latest per-process memory counters are present in active summary");
                        LaunchCapacityDiagnostics.StopWatching(); LaunchCapacityDiagnostics.StopWatching();
                        Check(!live.HasExited && live.Id > 0, "StopWatching is idempotent and neither kills nor disposes the original process");
                        Check(!LaunchCapacityDiagnostics.Summary().Split('\n').Any(x => x.StartsWith("active watch=") && x.Contains("copy=capacity-live ")), "stopped observers release their active records");
                    }
                    finally { if (!live.HasExited) live.Kill(); live.WaitForExit(); }
                }
            }
            LaunchCapacityDiagnostics.StopWatching();
        }
    }
}
