using System;using System.IO;using System.Linq;using System.Reflection;using System.Collections.Generic;using System.Diagnostics;using System.Threading;using System.Windows.Forms;using MTManager;
static class LaunchProgressUiSmoke
{
 static int checks;
 static BindingFlags F=BindingFlags.Instance|BindingFlags.NonPublic;
 static object Get(object o,string n){return o.GetType().GetField(n,F).GetValue(o);}
 static void Set(object o,string n,object v){o.GetType().GetField(n,F).SetValue(o,v);}
 static void Call(object o,string n,params object[] args){o.GetType().GetMethod(n,F).Invoke(o,args);}
 static void Check(bool value,string what){if(!value)throw new Exception(what);checks++;}
 static void Pump(){Application.DoEvents();Thread.Sleep(10);}
 [STAThread]static int Main(string[] args)
 {
  string root=Path.Combine(Path.GetTempPath(),"launch-progress-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=root;Lang.En=!args.Contains("fa");
  Application.EnableVisualStyles();typeof(Account).Assembly.GetType("MTManager.Theme").GetMethod("Init",BindingFlags.Static|BindingFlags.Public).Invoke(null,null);
  var settings=new Settings{BaseDir=Path.Combine(root,"copies"),DelaySeconds=0};Directory.CreateDirectory(settings.BaseDir);Process helper=null;
  try
  {
   var type=typeof(Account).Assembly.GetType("MTManager.MainForm");
   using(var main=(Form)Activator.CreateInstance(type,new object[]{settings,new AccountStore()}))
   {
    main.Show();Pump();foreach(var field in type.GetFields(F))if(field.FieldType==typeof(System.Windows.Forms.Timer))((System.Windows.Forms.Timer)field.GetValue(main)).Stop();
    var copies=(List<Instance>)Get(main,"copies");copies.Clear();
    for(int k=1;k<=2;k++){var copy=new Instance{Name="MT4-progress-"+k,Kind=Kind.MT4,Dir=Path.Combine(settings.BaseDir,"copy"+k)};Directory.CreateDirectory(copy.Dir);File.WriteAllText(copy.Exe,"test-only");copies.Add(copy);}
    Launcher.PrepareLiveManual=null;
    Set(main,"sandboxAvailable",(Func<bool>)(()=>true));Set(main,"launchFreeRam",(Func<ulong>)(()=>4000));Set(main,"launchTotalRam",(Func<ulong>)(()=>8000));
    using(var entered=new ManualResetEvent(false))using(var release=new ManualResetEvent(false))
    {
     int started=0;Set(main,"startTerminal",(Func<Instance,StartResult>)(copy=>{Interlocked.Increment(ref started);helper=Process.Start("/bin/sleep","60");entered.Set();release.WaitOne(5000);return new StartResult{Process=helper};}));
     Call(main,"Enqueue",new List<Instance>(copies));Check(entered.WaitOne(2000),"async launcher entered");Pump();
     var strip=(Control)Get(main,"launchProgress");var button=(Control)Get(strip,"stopButton");var work=(LaunchWorkProgress)Get(main,"launchWork");
     Check(strip.Visible&&strip.Dock==DockStyle.Bottom,"launch progress visible at bottom");Check(work.Total==2&&work.Done==0,"whole batch registered before first dispatch settles");Check(button.Visible&&button.Enabled,"stop available during preparation");
     ((Action)Get(strip,"StopRequested"))();
     Check(((Queue<Instance>)Get(main,"startQueue")).Count==0,"stop event clears remaining queue");Check(work.Stopped&&work.Stopping,"in-flight stop displays stopping state");Check(!button.Visible,"stop disabled after request");
     Check(helper!=null&&!helper.HasExited,"stop never kills already started helper");
     release.Set();var clock=Stopwatch.StartNew();while((bool)Get(main,"preparingCopy")&&clock.ElapsedMilliseconds<5000)Pump();
     Check(!(bool)Get(main,"preparingCopy")&&work.Finished,"late worker settles stopped run");Check(started==1,"queued second copy never launched after stop");Check(work.Done==1&&work.Total==2&&work.Fraction==.5,"stopped bar remains partial after current completion");Check(!helper.HasExited,"late completion preserves running process");
     using(var image=new System.Drawing.Bitmap(strip.Width,strip.Height)){strip.DrawToBitmap(image,new System.Drawing.Rectangle(0,0,image.Width,image.Height));image.Save("/workspace/MetaFactory-delivery/MetaFactory-3.50.9-launch-progress-"+(Lang.En?"en":"fa")+".png");}
    }
    Set(main,"sandboxAvailable",(Func<bool>)(()=>false));Set(main,"startTerminal",(Func<Instance,StartResult>)(copy=>new StartResult{Process=helper}));
    Call(main,"Enqueue",new List<Instance>{copies[1]});var next=(LaunchWorkProgress)Get(main,"launchWork");
    Check(!next.Stopped&&next.Total==1&&next.Done==1&&next.Fraction==1,"new launch resets stopped batch and reaches100percent");
    Set(main,"startTerminal",(Func<Instance,StartResult>)(copy=>{throw new IOException("simulated launch failure");}));Call(main,"Enqueue",new List<Instance>(copies));Call(main,"StartNext");
    var failed=(LaunchWorkProgress)Get(main,"launchWork");Check(failed.Finished&&failed.Done==2&&failed.Failed==2,"failed attempts advance progress without stalling queue");
    Check(!helper.HasExited,"failure handling does not close unrelated running helper");
    Set(main,"appClosing",true);
   }
   Console.WriteLine(checks+" UI launch-progress/stop checks passed ("+(Lang.En?"en":"fa")+"); no broker execution tested.");return 0;
  }
  catch(Exception error){Console.WriteLine(error);return 1;}
  finally{if(helper!=null){try{if(!helper.HasExited)helper.Kill();}catch{}helper.Dispose();}}
 }
}
