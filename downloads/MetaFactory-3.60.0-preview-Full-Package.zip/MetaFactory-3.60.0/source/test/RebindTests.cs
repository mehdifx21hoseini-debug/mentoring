using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Diagnostics;using System.Threading;using System.Web.Script.Serialization;
namespace MTManager {static partial class Tests {
static LaunchComparison.Item LastLaunchObservation(){LaunchComparison.Summary();return new JavaScriptSerializer().Deserialize<List<LaunchComparison.Run>>(File.ReadAllText(LaunchComparison.FilePath)).Last().Items.Single();}
static Process CurrentComparisonProcess(){return ((LaunchComparison.Run)typeof(LaunchComparison).GetField("current",System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic).GetValue(null)).Items.Single().Process;}
static void RebindChecks()
{
    if(!File.Exists("/bin/sleep"))return;
    var copy=new Instance{Name="MT5-rebind",Kind=Kind.MT5,Dir=Dir("rebind-copy")};File.Copy("/bin/sleep",copy.Exe,true);
    using(var chmod=Process.Start(new ProcessStartInfo("/bin/chmod","+x \""+copy.Exe+"\""){UseShellExecute=false})){chmod.WaitForExit();Equal(0,chmod.ExitCode,"test helper executable made runnable");}
    var account=new Account{Instance=copy.Name,Platform="MT5",Login="54321",Server="Rebind-Demo"};var store=new AccountStore();store.Set(account);
    var settings=new Settings{BaseDir=copy.Dir,ManualLiveReports=true};Process first=null,replacement=null,foreign=null;
    try{
        LaunchComparison.Begin(true,new[]{copy},settings,store,0);LaunchComparison.Preparing(copy);LaunchComparison.Prepared(copy,true);
        first=Process.Start(new ProcessStartInfo(copy.Exe,"1"){UseShellExecute=false});LaunchComparison.Started(copy,first);
        LaunchComparison.Observe(first,copy.Name,new LaunchCapacityDiagnostics.ResourceSnapshot(),false,4*1048576,8*1048576);
        var original=LastLaunchObservation();first.WaitForExit();LaunchComparison.Observe(first,copy.Name,new LaunchCapacityDiagnostics.ResourceSnapshot(),true,-1,-1);
        replacement=Process.Start(new ProcessStartInfo(copy.Exe,"30"){UseShellExecute=false});
        var wrong=account.Snapshot();wrong.Login="different";LaunchComparison.ReboundAfterUpdate(copy,replacement,wrong);
        Equal(0,LastLaunchObservation().Restarts,"account change cannot attach replacement PID to old cohort");
        LaunchComparison.ReboundAfterUpdate(copy,replacement,account);var rebound=LastLaunchObservation();
        Equal(1,rebound.Restarts,"native updater replacement is recorded once");Check(rebound.Pids.SequenceEqual(new[]{first.Id,replacement.Id}),"PID chain preserves original and replacement");Equal(original.ProcessUtc,rebound.ProcessUtc,"restart does not reset original launch anchor");Check(!rebound.Exited,"replacement remains an active observation");
        LaunchComparison.Observe(first,copy.Name,new LaunchCapacityDiagnostics.ResourceSnapshot(),true,-1,-1);Check(!LastLaunchObservation().Exited,"late original exit cannot end replacement observation");
        LaunchComparison.Fresh(copy,account,original.ProcessUtc);Equal(-1L,LastLaunchObservation().FreshMs,"old-process heartbeat cannot claim replacement readiness");
        LaunchComparison.Fresh(copy,wrong,DateTime.UtcNow);Equal(-1L,LastLaunchObservation().FreshMs,"other-account readiness cannot count toward cohort");
        LaunchComparison.Fresh(copy,account,DateTime.UtcNow);var ready=LastLaunchObservation();Check(ready.FreshMs>=900,"first valid replacement readiness includes update duration");
        LaunchComparison.Observe(CurrentComparisonProcess(),copy.Name,new LaunchCapacityDiagnostics.ResourceSnapshot(),false,5*1048576,9*1048576);
        Check(LastLaunchObservation().CpuMs>=Math.Max(0,original.CpuMs),"CPU accumulation does not reset on replacement");
        LaunchComparison.ReboundAfterUpdate(copy,replacement,account);Equal(1,LastLaunchObservation().Restarts,"same PID callbacks are idempotent");
        foreign=Process.Start(new ProcessStartInfo("/bin/sleep","10"){UseShellExecute=false});LaunchComparison.ReboundAfterUpdate(copy,foreign,account);Equal(1,LastLaunchObservation().Restarts,"different executable path cannot join PID chain");
        Check(!File.ReadAllText(LaunchComparison.FilePath).Contains("54321"),"new PID diagnostics do not persist account number");
        replacement.Kill();replacement.WaitForExit();LaunchComparison.Observe(CurrentComparisonProcess(),copy.Name,new LaunchCapacityDiagnostics.ResourceSnapshot(),true,-1,-1);
        LaunchComparison.Begin(false,new[]{copy},settings,store,0);LaunchComparison.Preparing(copy);LaunchComparison.Prepared(copy,false);
        using(var ordinary=Process.Start(new ProcessStartInfo(copy.Exe,"1"){UseShellExecute=false})){
            LaunchComparison.Started(copy,ordinary);ordinary.WaitForExit();LaunchComparison.Observe(ordinary,copy.Name,new LaunchCapacityDiagnostics.ResourceSnapshot(),true,-1,-1);
            using(var again=Process.Start(new ProcessStartInfo(copy.Exe,"10"){UseShellExecute=false})){
                try{LaunchComparison.ReboundAfterUpdate(copy,again,account);Check(LaunchComparison.IsPlain(copy.Name),"ordinary updater replacement remains excluded from live feed");LaunchComparison.Fresh(copy,account,DateTime.UtcNow);Equal(-1L,LastLaunchObservation().FreshMs,"ordinary PID chain never records live readiness");}
                finally{again.Kill();again.WaitForExit();LaunchComparison.Observe(CurrentComparisonProcess(),copy.Name,new LaunchCapacityDiagnostics.ResourceSnapshot(),true,-1,-1);}
            }
        }
    }finally{foreach(var process in new[]{first,replacement,foreign})if(process!=null){try{if(!process.HasExited){process.Kill();process.WaitForExit();}process.Dispose();}catch{}}}
}
static void DisposedRebindCallerChecks()
{
    if(!File.Exists("/bin/sleep"))return;
    var copy=new Instance{Name="MT5-disposed-caller",Kind=Kind.MT5,Dir=Dir("disposed-caller-copy")};File.Copy("/bin/sleep",copy.Exe,true);
    using(var chmod=Process.Start(new ProcessStartInfo("/bin/chmod","+x \""+copy.Exe+"\""){UseShellExecute=false})){chmod.WaitForExit();}
    var account=new Account{Instance=copy.Name,Platform="MT5",Login="54322",Server="Rebind-Demo"};var store=new AccountStore();store.Set(account);
    var settings=new Settings{BaseDir=copy.Dir};Process original=null,replacement=null;
    try
    {
        LaunchComparison.Begin(true,new[]{copy},settings,store,0);LaunchComparison.Preparing(copy);LaunchComparison.Prepared(copy,true);
        original=Process.Start(new ProcessStartInfo(copy.Exe,"1"){UseShellExecute=false});LaunchComparison.Started(copy,original);original.WaitForExit();
        LaunchComparison.Observe(original,copy.Name,new LaunchCapacityDiagnostics.ResourceSnapshot(),true,-1,-1);
        replacement=Process.Start(new ProcessStartInfo(copy.Exe,"30"){UseShellExecute=false});Process observed;
        using(var borrowed=Process.GetProcessById(replacement.Id))
        {
            LaunchComparison.ReboundAfterUpdate(copy,borrowed,account);observed=CurrentComparisonProcess();
            Check(observed!=null && !object.ReferenceEquals(observed,borrowed),"rebind retains independent observer wrapper");
        } // Production RefreshGrid disposes its enumeration object here.
        observed.Refresh();Check(!observed.HasExited,"disposing caller enumeration does not break observer");
        LaunchComparison.Fresh(copy,account,DateTime.UtcNow);
        Check(LastLaunchObservation().FreshMs>=0,"valid ready frame is counted after caller disposal");
        LaunchComparison.Observe(observed,copy.Name,new LaunchCapacityDiagnostics.ResourceSnapshot(),false,4*1048576,8*1048576);
        Equal(1,LastLaunchObservation().Restarts,"observer chain remains intact after caller disposal");
        LaunchCapacityDiagnostics.StopWatching();LaunchComparison.ReleaseObservedProcesses();
        Check(!replacement.HasExited,"observer cleanup releases handles without closing terminal");
    }
    finally{foreach(var process in new[]{original,replacement})if(process!=null){try{if(!process.HasExited){process.Kill();process.WaitForExit();}process.Dispose();}catch{}}}
}

}}
