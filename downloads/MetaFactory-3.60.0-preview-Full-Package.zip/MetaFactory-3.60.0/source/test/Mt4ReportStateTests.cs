using System;
using System.IO;
using System.Linq;
using System.Text;

namespace MTManager
{
    static partial class Tests
    {
        static void Mt4ReportStateChecks()
        {
            string token = new string('a', 32);
            var account = new Account { Login = "1234", Server = "Example-Demo" };
            Func<string, long, string, string, bool, string> text = (stage, elapsed, actualLogin, actualServer, connected) =>
                "MTS\t1\r\nQ\t" + token + "\r\nA\t1234\tExample-Demo\r\nS\t" + stage + "\r\nT\t" + elapsed +
                "\r\nC\t" + actualLogin + "\t" + actualServer + "\t" + (connected ? "1" : "0") + "\r\nEND\r\n";
            Func<long, Mt4ReportState> waiting = elapsed => Mt4ReportState.TryParse(text("waiting-login", elapsed, "0", "", false), token, account);
            string valid = text("waiting-login", 1000, "0", "", false);
            var parsed = Mt4ReportState.TryParse(valid, token, account);
            Check(parsed != null && parsed.Waiting && !parsed.Connected && !parsed.MatchingConnected && parsed.ElapsedMilliseconds == 1000, "MT4 state decodes a request-matched live connection wait");
            Check(Mt4ReportState.TryParse(valid, new string('b', 32), account) == null, "MT4 wrong nonce cannot describe this request");
            Check(Mt4ReportState.TryParse(valid, token, new Account { Login = "9999", Server = account.Server }) == null, "MT4 wrong requested account is rejected");
            Check(Mt4ReportState.TryParse(valid, token, new Account { Login = account.Login, Server = "Different-Demo" }) == null, "MT4 wrong requested server is rejected");
            Check(Mt4ReportState.TryParse(valid.Replace("END\r\n", ""), token, account) == null && Mt4ReportState.TryParse(valid + "extra", token, account) == null,
                "MT4 incomplete or extra-field snapshots are not usable evidence");
            Check(Mt4ReportState.TryParse(valid.Replace("T\t1000", "T\t-1"), token, account) == null && Mt4ReportState.TryParse(valid.Replace("S\twaiting-login", "S\tunknown"), token, account) == null,
                "MT4 malformed clocks and unknown states are ignored");
            parsed = Mt4ReportState.TryParse(text("waiting-account", 2000, "9999", account.Server, true), token, account);
            Check(parsed != null && parsed.Connected && !parsed.MatchingConnected && parsed.ActualLogin == "9999", "MT4 records a different actual account without calling credentials invalid");
            parsed = Mt4ReportState.TryParse(text("waiting-server", 2000, account.Login, "Different-Demo", true), token, account);
            Check(parsed != null && parsed.Connected && !parsed.MatchingConnected, "MT4 differentiates actual-server mismatch from disconnected network");
            Check(Mt4ReportState.TryParse(text("waiting-login", 2000, account.Login, account.Server, true), token, account) == null,
                "MT4 contradictory waiting state with requested account connected cannot justify deferral");
            Check(Mt4ReportState.TryParse(text("connected", 2000, "9999", account.Server, true), token, account) == null,
                "MT4 connected state must identify the requested account");

            var fast = new Mt4ReportWaitPolicy(true);
            fast.Observe(waiting(0), 0); fast.Observe(waiting(1000), 1000); fast.Observe(waiting(29000), 29000);
            Check(!fast.ShouldRequestDeferral(29999) && fast.ShouldRequestDeferral(30000), "MT4 first pass can request cooperative deferral only at the thirty-second boundary");
            Check(fast.ShouldRequestDeferral(32500) && !fast.ShouldRequestDeferral(32501), "MT4 state freshness is bounded to 3.5 seconds of a new native observation");
            fast.DeferralRequested(); Check(!fast.ShouldRequestDeferral(30000), "MT4 sends at most one deferral request per attempt");
            var final = new Mt4ReportWaitPolicy(false);
            final.Observe(waiting(0), 0); final.Observe(waiting(60000), 60000);
            Check(!final.ShouldRequestDeferral(60000), "MT4 final retry retains the full native connection budget");
            var stale = new Mt4ReportWaitPolicy(true);
            stale.Observe(waiting(0), 0); stale.Observe(waiting(1000), 1000); stale.Observe(waiting(1000), 30000);
            Check(!stale.ShouldRequestDeferral(30000), "rereading a stale file does not refresh MT4 native progress evidence");
            var singleton = new Mt4ReportWaitPolicy(true);
            singleton.Observe(waiting(30000), 30000);
            Check(!singleton.ShouldRequestDeferral(45000), "one snapshot without an advancing native heartbeat cannot authorize MT4 deferral");
            var progress = new Mt4ReportWaitPolicy(true);
            progress.Observe(waiting(0), 0); progress.Observe(waiting(1000), 1000);
            progress.Observe(Mt4ReportState.TryParse(text("waiting-account", 25000, "9999", account.Server, true), token, account), 25000);
            progress.Observe(Mt4ReportState.TryParse(text("waiting-account", 30000, "9999", account.Server, true), token, account), 30000);
            Check(!progress.ShouldRequestDeferral(30000), "a real connection/identity change receives a fresh settling period");
            progress.Observe(Mt4ReportState.TryParse(text("waiting-account", 37000, "9999", account.Server, true), token, account), 37000);
            Check(progress.ShouldRequestDeferral(37000), "an unchanged mismatched account can be deferred after the quiet budget");
            foreach (string phase in new[] { "connected", "history", "writing", "done" })
            {
                var reading = new Mt4ReportWaitPolicy(true);
                reading.Observe(waiting(0), 0); reading.Observe(waiting(1000), 1000);
                reading.Observe(Mt4ReportState.TryParse(text(phase, 25000, account.Login, account.Server, true), token, account), 25000);
                reading.Observe(waiting(30000), 30000);
                Check(reading.HistoryObserved && !reading.ShouldRequestDeferral(30000), "MT4 actual connection/history permanently disables first-pass deferral: " + phase);
            }
            var lostDuringHistory = new Mt4ReportWaitPolicy(true);
            lostDuringHistory.Observe(Mt4ReportState.TryParse(text("history", 10000, account.Login, account.Server, false), token, account), 10000);
            lostDuringHistory.Observe(waiting(30000), 30000);
            Check(lostDuringHistory.HistoryObserved && !lostDuringHistory.ShouldRequestDeferral(30000), "a connection loss after history began does not invoke the fast-start deferral policy");

            var copy = new Instance { Kind = Kind.MT4, Dir = Dir("mt4-state", "_MTManager", "report", "MT4-Example-Demo-1") };
            Directory.CreateDirectory(Path.GetDirectoryName(Mt4ReportState.StatePath(copy)));
            File.WriteAllText(Mt4ReportState.StatePath(copy), valid, Encoding.Unicode);
            Check(Mt4ReportState.Read(copy, token, account) != null, "MT4 state reader handles the native UTF16 sidecar");
            File.WriteAllText(Mt4ReportState.StatePath(copy), new string('x', 9000), Encoding.Unicode);
            Check(Mt4ReportState.Read(copy, token, account) == null, "MT4 oversized native state is ignored without unbounded reading");
            Mt4ReportState.WriteDeferralRequest(copy, token, account);
            string command = File.ReadAllText(Mt4ReportState.DeferralPath(copy), Encoding.Unicode);
            Check(command.Contains("MTD\t1") && command.Contains("Q\t" + token) && command.Contains("A\t1234\tExample-Demo") && command.TrimEnd().EndsWith("END"),
                "MT4 cooperative deferral command is request-bound and complete");
            string kept = ReportLaunch.OutputPath(copy); File.WriteAllText(kept, "preserved-result");
            foreach (string path in Mt4ReportState.TemporaryPaths(copy)) File.WriteAllText(path, "stale");
            Mt4ReportState.ClearRequestFiles(copy);
            Check(Mt4ReportState.TemporaryPaths(copy).All(path => !File.Exists(path)) && File.ReadAllText(kept) == "preserved-result",
                "MT4 stale state and deferral markers are cleared without changing report data");
            foreach (string error in new[] { "mt4 connection deferred", "mt4 connection not confirmed", "mt4 account not matched", "mt4 server not matched" })
            {
                File.WriteAllText(kept, "MTR\t2\tMT4\t1492\t1.23\r\nQ\t" + token + "\r\nERR\t" + error + "\r\n", Encoding.Unicode);
                var outcome = ReportRunner.ReadOutput(kept, account, new DateTime(2026, 11, 1), token);
                Check(outcome != null && outcome.Transient && outcome.Journal == null && outcome.Code.StartsWith("mt4-", StringComparison.Ordinal),
                    "MT4 native connection evidence is a retryable non-success, never proof of bad credentials: " + error);
                Check(ReportRunner.ReadOutput(kept, account, new DateTime(2026, 11, 1), new string('b', 32)) == null,
                    "MT4 deferral/connection error from another request is ignored: " + error);
            }

            string native = ReportScript.SourceText(Kind.MT4);
            Check(native.Contains("k < 120") && native.Contains("Sleep(500)") && native.Contains("quiet >= (uint)(posted ? 45000 : 15000)"),
                "MT4 native connection and complete-history wait budgets are retained");
            Check(native.Contains("ConnectionDeferralRequested() && (!IsConnected() || AccountNumber() == 0 || !ExpectedAccount())") && native.Contains("mt4 connection deferred"),
                "MT4 deferral acknowledgement rechecks live expected-account readiness inside the native wait");
            int history = native.IndexOf("AskAllHistory();", StringComparison.Ordinal), export = native.IndexOf("void ExportReport()", StringComparison.Ordinal);
            Check(!native.Substring(history, export - history).Contains("ConnectionDeferralRequested"), "MT4 never consults the deferral command during history loading");
        }
    }
}
