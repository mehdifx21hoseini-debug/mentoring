using System;
using System.Globalization;
using System.Linq;

namespace MTManager
{
    static partial class Tests
    {
        static JournalBalanceEvent DdEvent(long ticket, DateTime time, int type, double net)
        { return new JournalBalanceEvent { Ticket = ticket, TimeMilliseconds = (long)(time - new DateTime(1970, 1, 1)).TotalMilliseconds, Type = type, Net = net }; }

        static void ProveDdCurve(AccountJournal journal, params JournalBalanceEvent[] events)
        {
            events = events.Where(x => x.Type != 3 && (!journal.FullHistoryBonusExcluded || x.Type != 6)).ToArray();
            journal.FullHistory.Clear(); journal.FullHistory.AddRange(events);
            journal.FullHistoryPresent = journal.FullHistoryValid = journal.FullHistoryReconciled = journal.FullHistoryScanOk = journal.FullHistoryRequested = true;
            journal.HistoryChecked = journal.HistoryOk = true;
            journal.FullHistoryCount = events.Length;
            journal.FullHistorySum = events.Where(x => x.Type != 3).Sum(x => x.Net);
            journal.Balance = events.Where(x => x.Type != 3 && (!journal.FullHistoryBonusExcluded || x.Type != 6)).Sum(x => x.Net);
            journal.FullHistoryBalance = journal.Balance;
            journal.HistorySum = journal.FullHistorySum; journal.HistoryBalance = journal.Balance;
        }

        static void FullHistoryDrawdownChecks()
        {
            bool previousLanguage = Lang.En; Lang.En = true;
            try
            {
                DateTime first = new DateTime(2024, 1, 1), later = first.AddMonths(5), end = first.AddMonths(10);
                var j = new AccountJournal { Platform = "MT4", Complete = true, Balance = 550.10, Exported = end,
                    From = end.Date.AddDays(-1), TrustedFrom = DateTime.MaxValue, FloatingBars = AccountJournal.TradesOnly };
                // Anonymous extrema reduction of an independently replayed full MT4 statement.
                ProveDdCurve(j, DdEvent(1, first, 2, 1416), DdEvent(2, later, 0, 798.81),
                    DdEvent(3, later.AddDays(1), 2, -365.36), DdEvent(4, end, 1, -1299.35));
                var view = new PanelView(); PanelMath.AccountDrawdown(j, view);
                Check(view.AccountDdComplete && Math.Abs(view.AccountDdPct - 58.66643188354757) < 0.0000001,
                    "native MT4 full trading curve reproduces Relative DD58.67 even when visible history begins much later");
                Check(PanelMath.AccountDdValue(view) == "58.67%" && Math.Abs(view.AccountMaxDdMoney - 1299.35) < 0.000001,
                    "native fixture money1299.35 and relative58.67 agree independently");
                Check(Math.Abs(view.AccountDdPeak - 2214.81) < 0.000001 && Math.Abs(view.AccountDdTrough - 915.46) < 0.000001
                    && view.AccountDdPeakAt == later && view.AccountDdTroughAt == end,
                    "native trading curve retains numeric and temporal peak/trough evidence");
                Check(view.AccountDdFrom == first && view.AccountDdTo == end && view.AccountDdBasis.Contains("not equity"),
                    "full-history scope ignores display window and never claims equity DD");

                Check(Math.Abs(view.ProfitFactor-798.81/1299.35)<0.0000001,"overall MT4 PF excludes funding and uses all closed history");
                var dayPf=PanelMath.Build(j,new ReportRange{From=end.Date,To=end.Date.AddDays(1)},new TradeLimits());
                var monthPf=PanelMath.Build(j,new ReportRange{From=end.AddMonths(-1),To=end.AddDays(1)},new TradeLimits());
                Check(dayPf.ProfitFactor==monthPf.ProfitFactor && dayPf.ProfitFactor==view.ProfitFactor,"overall PF is unchanged by selected display range");
                var pfj=new AccountJournal{Platform="MT5",Login="12345",Server="Demo",Complete=true,Exported=end,From=end.AddDays(-1),ScriptVersion="1.25"};
                ProveDdCurve(pfj,DdEvent(21,first,2,1000),DdEvent(22,later,0,200),DdEvent(23,later.AddDays(1),1,-100),DdEvent(24,end,0,-3));
                pfj.AccountPfPresent=pfj.AccountPfValid=true;pfj.AccountPfCount=2;pfj.AccountPfGain=200;pfj.AccountPfLoss=100;pfj.AccountPfTradingNet=97;
                string pfText=JournalFile.Write(pfj);
                var pfRead=JournalFile.Parse(pfText);
                Check(pfRead!=null && pfRead.FullHistoryValid && pfRead.AccountPfValid,"MT5 closed-position PF proof survives serialization and full-history reconciliation");
                var pfView=new PanelView();PanelMath.AccountDrawdown(pfRead,pfView);
                Check(pfView.ProfitFactor==2,"MT5 overall PF excludes open-position fee instead of treating it as a losing trade");
                var badPf=JournalFile.Parse(pfText.Replace("PF\t1\t2\t200\t100\t97","PF\t1\t2\t200\t100\t98"));
                Check(!badPf.AccountPfValid && badPf.FullHistoryValid,"mismatching PF proof is unavailable without corrupting existing report history");
                var duplicatePf=JournalFile.Parse(pfText.Replace("PF\t1\t2\t200\t100\t97","PF\t1\t2\t200\t100\t97\r\nPF\t1\t2\t200\t100\t97"));
                Check(!duplicatePf.AccountPfValid,"duplicate PF proof is rejected");
                pfj.FullHistoryValid=false;PanelMath.AccountDrawdown(pfj,pfView);Check(double.IsNaN(pfView.ProfitFactor),"unverified full history never presents an overall PF");

                double oldWindowPct = (835.0 - 550.10) / 835.0 * 100;
                Check(Math.Round(oldWindowPct, 2) == 34.12 && Math.Abs(oldWindowPct - view.AccountDdPct) > 20,
                    "old month-window34.12 is demonstrably not whole-history native58.67");
                j.FullHistoryPresent = j.FullHistoryValid = false;
                j.HistoryChecked = j.HistoryOk = true; j.From = j.TrustedFrom = first; j.FirstSeen = first;
                j.Cash.Add(new JournalCash { Time = first, Amount = 1416 });
                j.Trades.Add(new JournalTrade { Ticket = 1, Close = end, Profit = -500.54 });
                PanelMath.AccountDrawdown(j, view);
                Check(double.IsNaN(view.AccountDdPct) && !view.AccountDdComplete,
                    "legacy and partial T/B history never masquerades as full native Relative DD");

                j.Balance = 4500;
                ProveDdCurve(j, DdEvent(1, first, 2, 1000), DdEvent(2, first.AddHours(1), 0, -200),
                    DdEvent(3, first.AddHours(2), 1, 4200), DdEvent(4, first.AddHours(3), 0, -500));
                PanelMath.AccountDrawdown(j, view);
                Check(view.AccountDdPct == 20 && view.AccountRelativeDdMoney == 200 && view.AccountMaxDdMoney == 500 && view.AccountMaxDdPct == 10,
                    "largest percentage and largest monetary drawdown are tracked separately");

                ProveDdCurve(j, DdEvent(1, first, 2, 600), DdEvent(2, first.AddSeconds(1), 2, 400),
                    DdEvent(3, first.AddSeconds(2), 0, -200), DdEvent(4, first.AddSeconds(3), 2, 5000),
                    DdEvent(5, first.AddSeconds(4), 3, 999), DdEvent(6, first.AddSeconds(5), 1, -100));
                PanelMath.AccountDrawdown(j, view);
                Check(view.AccountDdPct == 30 && view.AccountDdPeak == 1000,
                    "multiple pre-trade funding records establish seed; later external funding and credit do not alter trading DD");
                j.FullHistory.Reverse(); PanelMath.AccountDrawdown(j, view);
                Check(view.AccountDdPct == 30, "full curve is ordered by close/deal timestamp rather than serialized/open order");
                j.FullHistoryScanOk = false; PanelMath.AccountDrawdown(j, view);
                Check(double.IsNaN(view.AccountDdPct), "incomplete native scan is unknown, not zero DD");
                j.FullHistoryScanOk = true; j.FullHistoryReconciled = false; PanelMath.AccountDrawdown(j, view);
                Check(double.IsNaN(view.AccountDdPct), "unreconciled full curve is unknown");
                j.FullHistoryReconciled = true; j.FullHistoryCount++; PanelMath.AccountDrawdown(j, view);
                Check(double.IsNaN(view.AccountDdPct), "declared curve count mismatch is rejected by math as well as parser");
                ProveDdCurve(j, DdEvent(1, first, 0, -50)); PanelMath.AccountDrawdown(j, view);
                Check(double.IsNaN(view.AccountDdPct), "unproven initial capital cannot yield a fabricated percentage");
                ProveDdCurve(j, DdEvent(1, first, 2, 1000)); PanelMath.AccountDrawdown(j, view);
                Check(view.AccountDdPct == 0 && view.AccountDdComplete, "proven funded account without trading losses has zero relative DD");
                ProveDdCurve(j, DdEvent(1, first, 2, 1000), DdEvent(2, first.AddSeconds(1), 0, double.NaN));
                PanelMath.AccountDrawdown(j, view);
                Check(double.IsNaN(view.AccountDdPct), "nonfinite event cannot become a valid relative DD");

                j.Platform = "MT5"; j.Balance = 990;
                ProveDdCurve(j, DdEvent(1, first, 2, 1000), DdEvent(2, first.AddSeconds(1), 0, -10),
                    DdEvent(3, first.AddSeconds(2), 1, -400), DdEvent(4, first.AddSeconds(3), 1, 400));
                PanelMath.AccountDrawdown(j, view);
                Check(view.AccountDdPct == 41 && view.AccountDdBasis.Contains("native MT5 statement parity not yet verified"),
                    "MT5 full deals preserve entry fees and partial close chronology while disclosing unverified native parity");
                ProveDdCurve(j, DdEvent(1, first, 2, 200), DdEvent(2, first.AddSeconds(1), 7, -50),
                    DdEvent(3, first.AddSeconds(2), 2, 800), DdEvent(4, first.AddSeconds(3), 0, 0));
                PanelMath.AccountDrawdown(j, view);
                Check(view.AccountDdPct == 25 && view.AccountDdPeak == 200,
                    "MT5 funding after an early commission cannot retroactively dilute that loss");
            }
            finally { Lang.En = previousLanguage; }
        }
    }
}
