using System;
using System.Globalization;
using System.Linq;

namespace MTManager
{
    static partial class Tests
    {
        static string WholeHistoryFixture()
        {
            var first = new DateTime(2026, 11, 1);
            string t = JournalFile.Unix(first), end = JournalFile.Unix(first.AddDays(10));
            return "MTR\t2\tMT4\t\t1.23\nA\t123\tBroker-Demo\tUSD\t900\t900\t" + end + "\t" + JournalFile.Unix(first.AddDays(9))
                + "\nH\t1\t900\t900\nJ\t" + t + "000\t1\t2\t1000\nJ\t" + (long.Parse(t, CultureInfo.InvariantCulture) + 60).ToString(CultureInfo.InvariantCulture)
                + "000\t2\t0\t-100\nJC\t1\t2\t900\t900\t1\t1\t1\t0\nEND\t2\n";
        }

        static void FullHistoryJournalChecks()
        {
            string text = WholeHistoryFixture();
            AccountJournal j = JournalFile.Parse(text);
            Check(j.Complete && j.FullHistoryPresent && j.FullHistoryValid && j.FullHistory.Count == 2,
                "J/JC proof validates whole account curve independently of display-window records");
            Check(j.FullHistory[0].Time < j.From && j.FullHistory[0].Type == 2 && j.FullHistory[1].Net == -100,
                "full-history events before WorkFrom survive without changing trade-display From");
            var clone = JournalFile.Parse(JournalFile.Write(j));
            Check(clone.FullHistoryValid && clone.FullHistoryCount == 2 && clone.FullHistory[0].TimeMilliseconds == j.FullHistory[0].TimeMilliseconds,
                "whole-history proof survives scheduled-report Write/Parse deep snapshot");
            Check(!object.ReferenceEquals(j.FullHistory[0], clone.FullHistory[0]), "serialized whole-history events are independent copies");

            string legacy = string.Join("\n", text.Split('\n').Where(l => !l.StartsWith("J\t") && !l.StartsWith("JC\t"))).Replace("END\t2", "END\t0");
            var old = JournalFile.Parse(legacy);
            Check(old.Complete && !old.FullHistoryPresent && !old.FullHistoryValid, "reconciled old cache cannot claim full-account DD without J/JC");
            foreach (string damaged in new[] {
                text.Replace("JC\t1\t2", "JC\t2\t2"),
                text.Replace("JC\t1\t2", "JC\t1\t3"),
                text.Replace("JC\t1\t2\t900", "JC\t1\t2\t901"),
                text.Replace("JC\t1\t2\t900\t900", "JC\t1\t2\t900\t899"),
                text.Replace("\t2\t0\t-100", "\t2\t0\tNaN"),
                text.Replace("\t2\t0\t-100", "\t2\t0\tInfinity"),
                text.Replace("\t2\t0\t-100", "\t2\t3\t-100"),
                text.Replace("\t2\t0\t-100", "\t1\t0\t-100"),
                text.Replace("\t2\t0\t-100", "\t2\t18\t-100"),
                text.Replace("\t1\t1\t1\t0\nEND", "\t0\t1\t1\t0\nEND"),
                text.Replace("\t1\t1\t1\t0\nEND", "\t1\t0\t1\t0\nEND"),
                text.Replace("\t1\t1\t1\t0\nEND", "\t1\t1\t0\t0\nEND"),
                text.Replace("\t1\t1\t1\t0\nEND", "\t1\ttrue\t1\t0\nEND"),
                text.Replace("H\t1\t900\t900", "H\t0\t900\t900"),
                text.Replace("H\t1\t900\t900", "H\t1\t899\t900"),
                text.Replace("H\t1\t900\t900", "H\t1\t900\t899"),
                text.Replace("H\t1\t900\t900", "H\t1\tNaN\t900"),
                text.Replace("JC\t1\t2\t900\t900\t1\t1\t1\t0", "JC\t1\t2\t900\t900\t1\t1\t1\t0\nJC\t1\t2\t900\t900\t1\t1\t1\t0")
            })
            {
                var bad = JournalFile.Parse(damaged);
                Check(bad != null && bad.Complete && !bad.FullHistoryValid, "malformed/full-history-unconfirmed evidence disables DD without fabricating normal report failure");
                Check(!JournalFile.Parse(JournalFile.Write(bad)).FullHistoryValid, "rewriting invalid curve cannot launder it into trusted proof");
            }
            string firstMs = j.FullHistory[0].TimeMilliseconds.ToString(CultureInfo.InvariantCulture);
            Check(!JournalFile.Parse(text.Replace(firstMs, "253402300800000")).FullHistoryValid, "overflowing timestamp fails full-history proof safely");
            string future = ((long.Parse(JournalFile.Unix(j.Exported), CultureInfo.InvariantCulture) + 1) * 1000).ToString(CultureInfo.InvariantCulture);
            Check(!JournalFile.Parse(text.Replace(firstMs, future)).FullHistoryValid, "curve cannot extend beyond its snapshot time");
            Check(!JournalFile.Parse(text.Replace("END\t2", "END\t1")).Complete, "END count must include every J event");
            Check(!JournalFile.Parse(text.Replace("END\t2", "")).FullHistoryValid, "cut-off proof is never valid without complete END");
            Check(!JournalFile.Parse(legacy + "J\t" + firstMs + "\t1\t2\t1000\n").Complete,
                "events appended after END cannot pass the report record count");
            string empty = legacy.Replace("\t900", "\t0").Replace("END\t0", "JC\t1\t0\t0\t0\t1\t1\t1\t0\nEND\t0");
            Check(JournalFile.Parse(empty).FullHistoryValid, "fully scanned requested empty zero-balance history has valid coverage proof");
            string bonus = text.Replace("MT4\t\t1.23", "MT5\t\t1.25").Replace("H\t1\t900\t900", "H\t1\t1000\t900").Replace("\t1\t1\t1\t0\nEND", "\t1\t1\t1\t1\nEND");
            Check(JournalFile.Parse(bonus).FullHistoryValid, "declared native bonus exclusion permits original H sum to differ from current balance");
            Check(!JournalFile.Parse(bonus.Replace("MT5\t\t1.25", "MT4\t\t1.23")).FullHistoryValid,
                "MT4 cannot claim the MT5-specific excluded bonus policy");
            Check(!JournalFile.Parse(bonus.Replace("\t1\t2\t1000", "\t1\t6\t1000")).FullHistoryValid,
                "bonus-excluded proof cannot retain bonus events in its curve");

            AccountJournal kept = JournalFile.Parse(text), fresh = JournalFile.Parse(text);
            kept.From = kept.From.AddDays(-2); kept.Exported = fresh.From.AddDays(1);
            var merged = JournalCache.Merge(kept, fresh);
            Check(merged.FullHistoryValid && merged.FullHistory.Count == fresh.FullHistory.Count && merged.FullHistory.Count == 2,
                "cache merge replaces whole-history curve instead of duplicating an old prefix");
            fresh.FullHistory[0].Net = 7;
            Check(merged.FullHistory[0].Net == 1000, "merged whole-history curve does not share mutable event objects");
            var missing = JournalCache.Merge(kept, JournalFile.Parse(legacy));
            Check(!missing.FullHistoryPresent && !missing.FullHistoryValid && missing.FullHistory.Count == 0,
                "fresh report without whole-history proof clears stale full-account DD metadata");
            fresh = JournalFile.Parse(text); fresh.Server = "Different-Broker";
            Check(object.ReferenceEquals(fresh, JournalCache.Merge(kept, fresh)), "same login on another server cannot inherit history or proof");
            fresh = JournalFile.Parse(text); fresh.Platform = "MT5";
            Check(object.ReferenceEquals(fresh, JournalCache.Merge(kept, fresh)), "same login on another platform cannot inherit history or proof");
        }
    }
}
