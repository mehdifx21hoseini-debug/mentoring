import importlib.util
from pathlib import Path
from types import SimpleNamespace
import unittest
import io
import json

spec = importlib.util.spec_from_file_location('probe', Path(__file__).parents[1] / 'bridge/mt5_check.py')
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


class Api:
    def __init__(self):
        self.ok_init = True
        self.ok_login = True
        self.error = (-10005, 'do not expose passwords')
        self.account = SimpleNamespace(login=12345, server='WMMarkets-Demo')
        self.terminal = SimpleNamespace(connected=True)
        self.closed = False
        self.calls = []

    def initialize(self, path, **kwargs):
        self.calls.append(('initialize', path, kwargs))
        return self.ok_init

    def login(self, number, **kwargs):
        self.calls.append(('login', number, kwargs))
        return self.ok_login

    def last_error(self):
        return self.error

    def account_info(self):
        return self.account

    def terminal_info(self):
        return self.terminal

    def shutdown(self):
        self.closed = True


class ProbeTests(unittest.TestCase):
    def setUp(self):
        self.api = Api()
        self.request = dict(token='a' * 32, login='12345', server='WMMarkets-Demo', password='Sensitive!sentinel', terminal='C:/private/terminal64.exe', timeout=15000)

    def run_probe(self):
        reply = probe.check(self.request, self.api)
        self.assertTrue(self.api.closed)
        self.assertNotIn(self.request['password'], str(reply))
        return reply

    def test_success_requires_fresh_ack(self):
        self.assertEqual('connected', self.run_probe()['state'])
        self.assertEqual('login', self.api.calls[1][0])
        self.assertEqual(self.request['token'], self.run_probe()['token'])

    def test_cached_account_does_not_override_rejection(self):
        self.api.ok_login = False
        self.api.error = (-6, self.request['password'])
        self.assertEqual('rejected', self.run_probe()['state'])

    def test_ipc_failure_not_bad_password(self):
        self.api.ok_login = False
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_wrong_account(self):
        self.api.account.login = 99
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_wrong_server(self):
        self.api.account.server = 'Other'
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_disconnected(self):
        self.api.terminal.connected = False
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_unavailable_account(self):
        self.api.account = None
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_failed_initialize(self):
        self.api.ok_init = False
        self.assertEqual('unconfirmed', self.run_probe()['state'])
        self.assertEqual(1, len(self.api.calls))

    def test_exception_does_not_leak_password(self):
        def failing(*a, **kw):
            raise RuntimeError(self.request['password'])
        self.api.login = failing
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_persistent_service_requires_ack_for_each_account(self):
        class SwitchingApi(Api):
            def login(self, number, **kwargs):
                self.calls.append(('login', number, kwargs))
                if kwargs['password'] == 'bad':
                    self.error = (-6, 'rejected')
                    return False
                self.account = SimpleNamespace(login=number, server=kwargs['server'])
                return True
        api = SwitchingApi()
        requests = [dict(self.request, login=str(n), token=str(n) * 32, password=p)
                    for n, p in [(1, 'good'), (2, 'bad'), (3, 'good')]]
        output = io.StringIO()
        probe.serve(io.StringIO(''.join(json.dumps(r) + '\n' for r in requests)), output, api, persistent=True)
        responses = [json.loads(line) for line in output.getvalue().splitlines()]
        self.assertEqual(['connected', 'rejected', 'connected'], [r['state'] for r in responses])
        self.assertEqual([r['token'] for r in requests], [r['token'] for r in responses])
        self.assertEqual(3, len([c for c in api.calls if c[0] == 'login']))
        self.assertNotIn('Sensitive!sentinel', output.getvalue())

    def test_single_request_mode_remains_compatible(self):
        raw = json.dumps(self.request) + '\n'
        output = io.StringIO()
        probe.serve(io.StringIO(raw + raw), output, self.api)
        self.assertEqual(1, len(output.getvalue().splitlines()))


class SymbolApi(Api):
    SYMBOL_TRADE_MODE_DISABLED = 0
    TIMEFRAME_M1 = 1

    def __init__(self):
        super().__init__()
        import time
        self.now = int(time.time())
        self.symbols = [SimpleNamespace(name='Unusable@', trade_mode=4, bid=1, ask=2, select=True),
                        SimpleNamespace(name='BrokerSuffix.EURUSD', trade_mode=4, bid=1, ask=2, select=False)]
        self.ticks = {s.name: SimpleNamespace(bid=1, ask=2, time=self.now) for s in self.symbols}
        self.rates = {'Unusable@': [], 'BrokerSuffix.EURUSD': [dict(close=1.2, time=self.now)]}
        self.selected = []
        self.rate_calls = []

    def symbols_get(self):
        return self.symbols

    def symbol_select(self, name, enable):
        self.selected.append(name)
        return True

    def symbol_info_tick(self, name):
        return self.ticks.get(name)

    def copy_rates_from_pos(self, name, timeframe, start, count):
        self.rate_calls.append(name)
        return self.rates.get(name)


class SymbolTests(unittest.TestCase):
    def setUp(self):
        self.api = SymbolApi()
        self.request = dict(token='a'*32, login='12345', server='WMMarkets-Demo', password='sentinel',
                            terminal='private/terminal64.exe', timeout=25000, action='symbols', preferred='Unusable@')

    def check(self):
        result = probe.check(self.request, self.api)
        self.assertNotIn('sentinel', str(result))
        self.assertTrue(self.api.closed)
        return result

    def test_own_history_hint_reaches_symbol_beyond_broker_prefix(self):
        own = self.api.symbols[1]
        prefix = [SimpleNamespace(name='AAA_CFD_%03d' % i, trade_mode=4, bid=1, ask=2, select=True) for i in range(100)]
        self.api.symbols = prefix + [own]
        for info in prefix:
            self.api.ticks[info.name] = SimpleNamespace(bid=1, ask=2, time=self.api.now)
        self.request['candidates'] = [own.name]
        self.assertEqual(own.name, self.check()['symbol'])
        self.assertEqual([own.name], self.api.rate_calls)

    def test_symbol_failure_counts_explain_missing_report(self):
        self.api.rates = {}
        result = self.check()
        self.assertEqual(2, result['catalogue_count'])
        self.assertEqual(2, result['attempted'])
        self.assertEqual(2, result['no_bars'])
        self.assertEqual(0, result['no_quote'])

    def test_one_instrument_api_exception_does_not_abort_catalogue(self):
        original = self.api.copy_rates_from_pos
        def rates(name, *args):
            if name == 'Unusable@':
                raise RuntimeError('sentinel')
            return original(name, *args)
        self.api.copy_rates_from_pos = rates
        result = self.check()
        self.assertEqual('BrokerSuffix.EURUSD', result['symbol'])
        self.assertEqual(1, result['no_bars'])

    def test_candidate_work_is_bounded(self):
        self.api.symbols = [SimpleNamespace(name='CFD_%03d' % i, trade_mode=4, bid=1, ask=2, select=True) for i in range(100)]
        self.api.ticks = {}
        result = self.check()
        self.assertEqual(64, result['attempted'])
        self.assertEqual(64, result['no_quote'])
        self.assertNotIn('symbol', result)

    def test_initial_sdk_connection_includes_requested_account(self):
        self.check()
        args = self.api.calls[0][2]
        self.assertEqual(12345, args['login'])
        self.assertEqual(self.request['password'], args['password'])
        self.assertEqual(self.request['server'], args['server'])
        self.assertTrue(args['portable'])
        self.assertEqual('login', self.api.calls[1][0])

    def test_legacy_login_initialization_remains_unchanged(self):
        self.request['action'] = 'login'
        self.check()
        self.assertNotIn('password', self.api.calls[0][2])
        self.assertNotIn('login', self.api.calls[0][2])

    def test_initialization_failure_never_proves_or_queries_a_symbol(self):
        self.api.ok_init = False
        result = self.check()
        self.assertEqual('unconfirmed', result['state'])
        self.assertNotIn('symbol', result)
        self.assertEqual([], self.api.selected)

    def test_unreadable_preferred_uses_account_alternate(self):
        result = self.check()
        self.assertEqual('BrokerSuffix.EURUSD', result['symbol'])
        self.assertEqual(['Unusable@', 'BrokerSuffix.EURUSD'], self.api.rate_calls)
        self.assertEqual('ready', result['symbol_status'])

    def test_weekend_quote_and_bars_accepted(self):
        name = self.api.symbols[1].name
        self.api.ticks[name].time -= 2*86400
        self.api.rates[name][0]['time'] -= 2*86400
        self.assertEqual(name, self.check()['symbol'])

    def test_bad_quotes_not_selected_for_chart(self):
        self.api.ticks['BrokerSuffix.EURUSD'].bid = float('nan')
        self.assertEqual('unavailable', self.check()['symbol_status'])

    def test_disabled_instrument_skipped(self):
        self.api.symbols[1].trade_mode = 0
        self.assertEqual('unavailable', self.check()['symbol_status'])
        self.assertNotIn('BrokerSuffix.EURUSD', self.api.selected)

    def test_stale_quote_skipped(self):
        self.api.ticks['BrokerSuffix.EURUSD'].time -= 10*86400
        self.assertEqual('unavailable', self.check()['symbol_status'])

    def test_stale_bars_skipped(self):
        self.api.rates['BrokerSuffix.EURUSD'][0]['time'] -= 10*86400
        self.assertEqual('unavailable', self.check()['symbol_status'])

    def test_positive_quote_without_candles_not_enough(self):
        self.api.rates = {}
        result = self.check()
        self.assertEqual('connected', result['state'])
        self.assertEqual('unavailable', result['symbol_status'])
        self.assertNotIn('symbol', result)

    def test_other_account_catalogue_never_queried(self):
        self.api.account.login = 12346
        result = self.check()
        self.assertEqual('unconfirmed', result['state'])
        self.assertEqual([], self.api.selected)

    def test_rejection_never_queries_symbols(self):
        self.api.ok_login = False
        result = self.check()
        self.assertNotIn('symbol', result)
        self.assertEqual([], self.api.selected)

    def test_read_only_account_can_report(self):
        self.api.account.trade_allowed = False
        self.assertEqual('ready', self.check()['symbol_status'])

    def test_no_fixed_names_or_peer_catalogue(self):
        name = 'UniqueBroker.CFD'
        self.api.symbols = [SimpleNamespace(name=name, trade_mode=4, bid=1, ask=2, select=True)]
        self.api.ticks[name] = SimpleNamespace(bid=5, ask=6, time=self.api.now)
        self.api.rates[name] = [dict(close=5, time=self.api.now)]
        self.assertEqual(name, self.check()['symbol'])

    def test_login_only_keeps_existing_behavior(self):
        self.request['action'] = 'login'
        self.assertEqual('connected', self.check()['state'])
        self.assertEqual([], self.api.selected)

if __name__ == '__main__':
    unittest.main()
