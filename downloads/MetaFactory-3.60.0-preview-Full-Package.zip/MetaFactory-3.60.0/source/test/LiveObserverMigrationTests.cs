using System;
using System.IO;
using System.Linq;
using System.Text;
namespace MTManager { static partial class Tests {
static void LiveObserverMigrationChecks()
{
 string expert="<expert>\r\nname=MTManagerLive\r\n<inputs>\r\nSessionToken=\r\n</inputs>\r\n</expert>\r\n";
 string before="<chart>\r\nsymbol=GBPUSD\r\nperiod=1\r\n",after="<window>\r\nheight=100\r\n</window>\r\n</chart>\r\n";
 bool changed;Equal(before+after,LiveObserverMigration.WithoutObserver(before+expert+after,out changed),"retiring our observer preserves the surrounding chart byte-for-byte");
 Check(changed,"legacy observer is identified even when startup inputs were empty");
 string other="<expert>\nname=MyTradingEA\ncomment=MTManagerLive\n</expert>\n";
 Equal(other,LiveObserverMigration.WithoutObserver(other,out changed),"another EA mentioning our name is untouched");Check(!changed,"another EA is not classified as ours");
 string partial="<expert>\nname=MTManagerLive\n";Equal(partial,LiveObserverMigration.WithoutObserver(partial,out changed),"an incomplete expert block is preserved");
 Check(!changed,"an incomplete observer block is not removed");
 foreach(Kind kind in new[]{Kind.MT4,Kind.MT5}){
  var copy=new Instance{Name=kind+"-migration",Kind=kind,Dir=Dir("observer-migration",kind.ToString())};
  string profile=ChartProfile.DefaultDir(copy);Directory.CreateDirectory(profile);string chart=Path.Combine(profile,"chart01.chr");
  var encoding=kind==Kind.MT4?Encoding.UTF8:Encoding.Unicode;File.WriteAllText(chart,before+expert+after,encoding);byte[] original=File.ReadAllBytes(chart);
  string user=Path.Combine(profile,"chart02.chr");File.WriteAllText(user,other,encoding);byte[] userBytes=File.ReadAllBytes(user);
  var retired=LiveObserverMigration.RetireClosed(copy);
  Check(retired.Retired==1&&retired.Symbol=="GBPUSD"&&retired.Period=="1","closed-copy migration returns the former observer slot for "+kind);
  Equal(before+after,TextFiles.ReadText(chart),"only observer block removed for "+kind);
  Check(File.ReadAllBytes(user).SequenceEqual(userBytes),"trading EA chart remains byte-identical for "+kind);
  string backup=Directory.GetFiles(Path.Combine(copy.Dir,"MTManager-backup","live-observers"),"*.bak").Single();
  Check(File.ReadAllBytes(backup).SequenceEqual(original),"original observer chart backup preserves encoding and all bytes for "+kind);
  Equal(0,LiveObserverMigration.RetireClosed(copy).Retired,"observer migration is idempotent for "+kind);
  string binary=Path.Combine(copy.Dir,"synthetic-live-binary");File.WriteAllBytes(binary,new byte[]{1,2,3,4});
  var deployment=new LiveReporterDeployment{ExpertPath=binary,SourceHash=new string('A',64)};
  string alias=LiveObserverMigration.FlatAlias(copy,deployment);
  Check(!alias.Contains("\\")&&!alias.Contains("/")&&alias.Length<63,"startup EA alias is a short root-level name for "+kind);
  string dest=Path.Combine(copy.Dir,Kinds.Mql(kind),"Experts",alias+(kind==Kind.MT4?".ex4":".ex5"));
  Check(File.ReadAllBytes(dest).SequenceEqual(File.ReadAllBytes(binary)),"root startup alias is byte-identical to compiled EA for "+kind);
  Equal(alias,LiveObserverMigration.FlatAlias(copy,deployment),"root alias deployment is idempotent for "+kind);
  Check(LiveObserverMigration.Ours(alias),"new flat observer alias is recognized for retirement for "+kind);
  File.WriteAllText(dest,"user replacement");Throws<UserMessage>(()=>LiveObserverMigration.FlatAlias(copy,deployment),"modified alias is not overwritten for "+kind);
 }
 Equal("60",LiveObserverMigration.PeriodOf("period_type=1\nperiod_size=1\n"),"MT5 hourly chart slot is read correctly");
}
}}
