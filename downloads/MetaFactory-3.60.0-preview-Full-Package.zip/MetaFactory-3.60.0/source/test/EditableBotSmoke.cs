using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using MTManager;
class DeliveryEmbeddedSmoke {
 static int checks;
 static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);Console.WriteLine("PASS "+message);}
 static T Field<T>(object o,string name){return (T)o.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(o);}
 static bool Dirty(ScheduleDialog d){return (bool)d.GetType().GetProperty("IsDirty",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(d,null);}
 static Control Content(ScheduleDialog d){return (Control)d.GetType().GetProperty("EditorContent",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(d,null);}
 static void Select(ScheduleDialog d,string key){d.GetType().GetMethod("SelectChannel",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(d,new object[]{key});}
 static void Pump(){for(int i=0;i<8;i++){Application.DoEvents();Thread.Sleep(35);}}
 static void Shot(Form f,string path){Pump();using(var b=new Bitmap(f.Width,f.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(f.Location,Point.Empty,f.Size);b.Save(path);}}
 static ScheduleOptions Model(){return new ScheduleOptions{Enabled=false,Time="22:00",Platform="All",TelegramEnabled=true,BaleEnabled=true,EmailEnabled=true,TelegramTokenEnc=Secret.Protect("123456:"+new string('a',35)),TelegramChatId="-100123456789",BaleTokenEnc=Secret.Protect("123456:"+new string('b',35)),BaleChatId="12345",SmtpHost="smtp.example.com",SmtpPort=587,SmtpSsl=true,SmtpUser="reports@example.com",SmtpPasswordEnc=Secret.Protect("synthetic-password"),EmailFrom="reports@example.com",EmailTo="mentor@example.com"};}
 [STAThread]static int Main(string[] args){try{
  Application.EnableVisualStyles();typeof(Account).Assembly.GetType("MTManager.Theme").GetMethod("Init").Invoke(null,null);string output=args[0];Directory.CreateDirectory(output);
  foreach(bool english in new[]{false,true}){
   Lang.En=english;var model=Model();
   using(var editor=new ScheduleDialog(model,""))using(var host=new Form{ClientSize=new Size(740,460),StartPosition=FormStartPosition.CenterScreen,Text="Synthetic delivery UI host"}){
    var content=Content(editor);host.Controls.Add(content);content.Dock=DockStyle.Fill;host.Show();Pump();Check(!Dirty(editor),"opening embedded editor does not mark delivery dirty");
    foreach(string channel in new[]{"telegram","bale","email"}){
     Select(editor,channel);Pump();Shot(host,Path.Combine(output,"delivery-"+(english?"en":"fa")+"-"+channel+".png"));Check(!Dirty(editor),"channel navigation not dirty "+channel);
     Check(Field<CheckBox>(editor,"telegramEnabled").Checked&&Field<CheckBox>(editor,"baleEnabled").Checked&&Field<CheckBox>(editor,"emailEnabled").Checked,"navigation preserves independent channel enables "+channel);
    }
    foreach(string name in new[]{"telegramToken","telegramChat","baleToken","baleChat","smtpHost","smtpUser","smtpPassword","emailFrom","emailTo","time"})Check(Field<TextBox>(editor,name).RightToLeft==RightToLeft.No,"LTR input "+name);
    Check(Field<TextBox>(editor,"telegramToken").UseSystemPasswordChar&&Field<TextBox>(editor,"baleToken").UseSystemPasswordChar&&Field<TextBox>(editor,"smtpPassword").UseSystemPasswordChar,"all secret fields remain masked");
    ScheduleOptions result;Check(editor.TryCollect(out result),"unchanged valid model collects without persistence");Check(result.Time=="22:00"&&result.TelegramEnabled&&result.BaleEnabled&&result.EmailEnabled,"all values retained");
    Field<TextBox>(editor,"time").Text="۲۲:۳۰";Check(Dirty(editor),"time edit marks delivery dirty");Check(editor.TryCollect(out result)&&result.Time=="22:30","Persian time normalized by existing rules");Check(editor.Options.Time=="22:00"&&model.Time=="22:00"&&editor.DialogResult==DialogResult.None,"TryCollect does not mutate Options or input or close host");
    Check(result.TelegramTokenEnc==model.TelegramTokenEnc&&result.BaleTokenEnc==model.BaleTokenEnc&&result.SmtpPasswordEnc==model.SmtpPasswordEnc,"unchanged secrets preserve exact ciphertext");
    Field<TextBox>(editor,"time").Text="22:00";Check(!Dirty(editor),"reverting values clears dirty state");
    Select(editor,"telegram");Field<CheckBox>(editor,"telegramEnabled").Checked=false;Check(Field<Button>(editor,"telegramPaste").Enabled&&Field<TextBox>(editor,"telegramToken").Enabled,"channel off still allows preparing token");Field<CheckBox>(editor,"telegramEnabled").Checked=true;
    Clipboard.SetText("123456:"+new string('z',35));Field<Button>(editor,"telegramPaste").PerformClick();Check(Field<TextBox>(editor,"telegramToken").Text=="123456:"+new string('z',35)&&Field<TextBox>(editor,"telegramToken").UseSystemPasswordChar,"paste token stays masked and only edits local field");Field<TextBox>(editor,"telegramToken").Text=Secret.Unprotect(model.TelegramTokenEnc);Check(!Dirty(editor),"restoring pasted token clears dirty state");
    Select(editor,"bale");Field<CheckBox>(editor,"baleEnabled").Checked=false;Check(Field<TextBox>(editor,"baleToken").Enabled&&Field<TextBox>(editor,"baleChat").Enabled&&Field<Button>(editor,"balePaste").Enabled,"Bale token and chat editable while sending off");Clipboard.SetText("  123456:"+new string('y',35)+"\r\n");Field<Button>(editor,"balePaste").PerformClick();Check(Field<TextBox>(editor,"baleToken").Text=="123456:"+new string('y',35)&&Field<TextBox>(editor,"baleToken").UseSystemPasswordChar,"Bale paste trims external whitespace and remains masked");Check(editor.TryCollect(out result)&&!result.BaleEnabled&&Secret.Unprotect(result.BaleTokenEnc)==Field<TextBox>(editor,"baleToken").Text,"Bale token encrypted without enabling sending");Check(model.BaleEnabled&&model.BaleTokenEnc!=result.BaleTokenEnc,"editing Bale preserves original model until save");Field<TextBox>(editor,"baleToken").Text=Secret.Unprotect(model.BaleTokenEnc);Field<CheckBox>(editor,"baleEnabled").Checked=true;Check(!Dirty(editor),"reverting Bale edits restores clean state");
    Field<CheckBox>(editor,"dailyEnabled").Checked=true;Field<TextBox>(editor,"time").Text="99:99";Check(!editor.TryCollect(out result)&&result==null,"invalid schedule returns failure and no candidate");Check(!model.Enabled&&editor.Options.Time=="22:00","validation never mutates source options");
    Field<TextBox>(editor,"time").Text="22:00";Field<TextBox>(editor,"telegramToken").Text="123456:"+new string('c',35);Check(editor.TryCollect(out result)&&Secret.Unprotect(result.TelegramTokenEnc)==Field<TextBox>(editor,"telegramToken").Text&&result.TelegramTokenEnc!=model.TelegramTokenEnc,"edited secret encrypts only candidate");
    host.Close();
   }
   var unreadable=new ScheduleOptions{Enabled=true,TelegramEnabled=true,TelegramTokenEnc="unreadable-ciphertext",Time="22:00",Platform="All"};
   using(var editor=new ScheduleDialog(unreadable,"")){
    Check(!Dirty(editor),"unreadable saved secret not automatically dirty");Field<CheckBox>(editor,"dailyEnabled").Checked=false;ScheduleOptions value;Check(editor.TryCollect(out value)&&!value.Enabled&&value.TelegramTokenEnc==unreadable.TelegramTokenEnc,"disabling unreadable configuration retains ciphertext");
   }
  }
  Console.WriteLine("DELIVERY EMBEDDED PASS "+checks);return 0;
 }catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
