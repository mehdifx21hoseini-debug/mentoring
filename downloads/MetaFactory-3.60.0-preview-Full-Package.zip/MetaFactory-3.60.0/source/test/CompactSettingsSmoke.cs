using System;using System.Collections;using System.Collections.Generic;using System.Drawing;using System.IO;using System.Linq;using System.Reflection;using System.Threading;using System.Windows.Forms;using MTManager;
class UnifiedSettingsSmoke
{
 const BindingFlags I=BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic;
 const BindingFlags S=BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic;
 static int checks;static Type dialogType;
 static void Check(bool yes,string label){if(!yes)throw new Exception(label);checks++;Console.WriteLine("PASS "+label);}
 static object Field(object o,string name){return o.GetType().GetField(name,I).GetValue(o);}
 static void Set(object o,string name,object value){o.GetType().GetField(name,I).SetValue(o,value);}
 static object Property(object o,string name){return o.GetType().GetProperty(name,I).GetValue(o,null);}
 static void Call(object o,string name,params object[] values){o.GetType().GetMethod(name,I).Invoke(o,values);}
 static IEnumerable<LinkLabel> FindLinks(Control c){foreach(Control child in c.Controls){if(child is LinkLabel)yield return (LinkLabel)child;foreach(var link in FindLinks(child))yield return link;}}
 static void Pump(){for(int i=0;i<6;i++){Application.DoEvents();Thread.Sleep(25);}}
 static Dictionary<string,string> Model(object model){var result=new Dictionary<string,string>();foreach(var f in model.GetType().GetFields(I).Where(f=>!f.IsStatic)){var v=f.GetValue(model);var strings=v as IEnumerable<string>;result[f.Name]=strings==null?Convert.ToString(v):string.Join("|",strings);}return result;}
 static bool Same(Dictionary<string,string> before,object after){var now=Model(after);return before.Count==now.Count&&before.All(x=>now.ContainsKey(x.Key)&&now[x.Key]==x.Value);}
 static Form Open(Settings settings,ScheduleOptions options,Action<ScheduleOptions> callback,bool delivery){return (Form)Activator.CreateInstance(dialogType,I,null,new object[]{settings,options,"",callback,delivery},null);}
 static void Shot(Form f,string path){Pump();using(var image=new Bitmap(f.Width,f.Height)){using(var g=Graphics.FromImage(image))g.CopyFromScreen(f.Location,Point.Empty,f.Size);image.Save(path);}}
 static Settings Seed(string root,bool english){string folder=Path.Combine(root,"copies");Directory.CreateDirectory(folder);return new Settings{BaseDir=folder,Language=english?"en":"fa",DelaySeconds=7,ReportAtOnce=3,Minimized=false,NormalTerminalRights=false,SandboxieOverflow=false,PauseMt5Updates=true,ManualLiveReports=false,Light=false,LowPriority=false,TrimMemory=false,AutoStart=false,StartCharts="all",LightCharts=false};}
 static ScheduleOptions Schedule(bool invalid){return new ScheduleOptions{Enabled=invalid,Time="22:00",Platform="All",TelegramEnabled=!invalid,BaleEnabled=!invalid,EmailEnabled=!invalid,TelegramTokenEnc=Secret.Protect("123456:"+new string('a',35)),TelegramChatId="-100123456789",BaleTokenEnc=Secret.Protect("123456:"+new string('b',35)),BaleChatId="12345",SmtpHost="smtp.example.com",SmtpPort=587,SmtpSsl=true,SmtpUser="reports@example.com",SmtpPasswordEnc=Secret.Protect("synthetic-password"),EmailFrom="reports@example.com",EmailTo="mentor@example.com"};}
 static void Reach(Control field,Panel viewport,Button save,string label)
 {
  Point p=viewport.PointToClient(field.PointToScreen(Point.Empty));int offset=-viewport.AutoScrollPosition.Y;
  viewport.AutoScrollPosition=new Point(0,Math.Max(0,offset+p.Y-12));Pump();
  var box=field.RectangleToScreen(field.ClientRectangle);var view=viewport.RectangleToScreen(viewport.ClientRectangle);var footer=save.RectangleToScreen(save.ClientRectangle);
  Check(!field.IsDisposed&&field.Visible,label+" visible");
  Check(box.Left>=view.Left-2&&box.Right<=view.Right+2,label+" horizontal bounds");
  Check(box.Bottom<=footer.Top&&box.Top>=view.Top-2,label+" reachable above footer");
 }
 [STAThread]static int Main(string[] args)
 {
  string old=AppPaths.DataDirOverride;string root=Path.Combine(Path.GetTempPath(),"unified-settings-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=Path.Combine(root,"data");Directory.CreateDirectory(AppPaths.DataDirOverride);
  try
  {
   Application.EnableVisualStyles();var assembly=typeof(Settings).Assembly;var theme=assembly.GetType("MTManager.Theme");theme.GetMethod("Init",S).Invoke(null,null);dialogType=assembly.GetType("MTManager.SettingsDialog");Directory.CreateDirectory(args[0]);
   string[][] fields={new[]{"folder","language","autostart","delay","minimized","light","lowPriority","pauseMt5Updates","reportAtOnce","startCharts","sandboxOverflow","normalRights","trimMemory"},new string[0]};
   foreach(bool english in new[]{false,true})
   {
    Lang.En=english;var settings=Seed(root,english);var options=Schedule(false);int callbacks=0;var before=Model(settings);var scheduleBefore=Model(options);
    using(var form=Open(settings,options,c=>callbacks++,false))
    {
     form.Show();Pump();Size initial=form.Size;var pages=(Panel[])Field(form,"pages");var save=(Button)form.AcceptButton;var cancel=(Button)form.CancelButton;
     Check((int)Property(form,"SelectedPage")==0,"ordinary settings opens General and running "+english);
     Check(pages.Length==2,"two compact pages "+english);
     Check((int)Property(Field(form,"delay"),"Value")==7,"saved delay loaded "+english);
     Check((int)Property(Field(form,"reportAtOnce"),"SelectedIndex")==3,"report concurrency loaded "+english);
     foreach(string n in new[]{"minimized","normalRights","sandboxOverflow","light","lowPriority","trimMemory","autostart"})Check(!((CheckBox)Field(form,n)).Checked,"saved unchecked option "+n+" "+english);
     Check(((CheckBox)Field(form,"pauseMt5Updates")).Checked,"saved MT5 update choice loaded "+english);
     Check(!(bool)Property(Field(form,"deliveryEditor"),"IsDirty"),"embedded delivery starts clean "+english);
     for(int page=0;page<2;page++)
     {
      Call(form,"ShowPage",page);Pump();Check(form.Size==initial,"fixed size across page "+page+" "+english);Check(pages[page].Visible,"page displayed "+page+" "+english);
      for(int other=0;other<2;other++)if(other!=page)Check(!pages[other].Visible,"other page hidden "+other+" "+english);
      if(page==0){Check(!FindLinks(form).Any(x=>x.Text.Contains("▾")||x.Text.Contains("گزینه‌های")),"no more-options foldout "+english);Shot(form,Path.Combine(args[0],"general-initial-"+english+".png"));Console.WriteLine("GENERAL viewport="+pages[0].ClientSize+" content="+pages[0].DisplayRectangle+" table="+pages[0].Controls[0].Bounds);Check(!pages[0].VerticalScroll.Visible,"all general controls fit without scrolling "+english);}
      foreach(string name in fields[page])Reach((Control)Field(form,name),pages[page],save,name+" "+english);
      pages[page].AutoScrollPosition=Point.Empty;Pump();Check(save.Visible&&cancel.Visible,"fixed footer visible "+page+" "+english);
      Shot(form,Path.Combine(args[0],"unified-"+(english?"en":"fa")+"-"+page+".png"));
     }
     Check(!(bool)Property(Field(form,"deliveryEditor"),"IsDirty"),"navigation does not dirty delivery "+english);
     ((TextBox)Field(form,"folder")).Text=Path.Combine(root,"cancelled");
     ((CheckBox)Field(form,"minimized")).Checked=true;
     var editor=Field(form,"deliveryEditor");((TextBox)Field(editor,"time")).Text="23:15";
     Check((bool)Property(editor,"IsDirty"),"actual delivery edit becomes dirty "+english);
     cancel.PerformClick();Pump();Check(form.DialogResult==DialogResult.Cancel,"global Cancel closes "+english);
    }
    Check(Same(before,settings)&&Same(scheduleBefore,options)&&callbacks==0,"Cancel preserves both models and callback "+english);
    Check(!File.Exists(AppPaths.SettingsFile),"Cancel writes no general config "+english);

    // An untouched invalid saved schedule must not block unrelated general Save.
    settings=Seed(root,english);before=Model(settings);options=Schedule(true);scheduleBefore=Model(options);callbacks=0;
    using(var form=Open(settings,options,c=>callbacks++,false))
    {
     form.Show();Pump();var editor=Field(form,"deliveryEditor");Check(!(bool)Property(editor,"IsDirty"),"invalid saved schedule starts clean "+english);
     ((Button)form.AcceptButton).PerformClick();Pump();
     Check(form.DialogResult==DialogResult.OK&&(bool)Property(form,"SettingsApplied"),"clean invalid schedule does not block general save "+english);
     Check(callbacks==0&&Property(form,"DeliveryOptions")==null,"clean schedule never invokes delivery callback "+english);
    }
    Check(Same(before,settings),"no-edit general Save preserves all flags "+english);Check(Same(scheduleBefore,options),"clean invalid source schedule unchanged "+english);Check(File.Exists(AppPaths.SettingsFile),"general Save persisted only synthetic config "+english);File.Delete(AppPaths.SettingsFile);

    // Dirty invalid delivery is rejected before changing general settings or disk.
    settings=Seed(root,english);before=Model(settings);options=Schedule(false);callbacks=0;
    using(var form=Open(settings,options,c=>callbacks++,true))
    {
     form.Show();Pump();Check((int)Property(form,"SelectedPage")==1,"delivery entry opens unified Delivery page "+english);
     var editor=Field(form,"deliveryEditor");((TextBox)Field(editor,"time")).Text="99:99";((CheckBox)Field(editor,"dailyEnabled")).Checked=true;
     ((CheckBox)Field(form,"minimized")).Checked=true;
     ((Button)form.AcceptButton).PerformClick();Pump();
     Check(form.DialogResult!=DialogResult.OK&&!(bool)Property(form,"SettingsApplied"),"invalid delivery rejects before general persistence "+english);
     Check((int)Property(form,"SelectedPage")==1,"invalid delivery remains visible "+english);Check(((Label)Field(editor,"error")).Visible,"delivery validation message visible "+english);
     Check(Same(before,settings)&&!File.Exists(AppPaths.SettingsFile)&&callbacks==0,"invalid combined save leaves general model, disk, callback untouched "+english);
     ((Button)form.CancelButton).PerformClick();Pump();
    }

    // A dirty valid delivery edit is collected once, while ciphertext and original inputs survive.
    settings=Seed(root,english);options=Schedule(false);scheduleBefore=Model(options);callbacks=0;ScheduleOptions saved=null;
    using(var form=Open(settings,options,c=>{callbacks++;saved=c;},true))
    {
     form.Show();Pump();var editor=Field(form,"deliveryEditor");
     ((TextBox)Field(editor,"time")).Text="۲۲:۳۰";((CheckBox)Field(editor,"dailyEnabled")).Checked=true;
     ((ComboBox)Field(editor,"platform")).SelectedIndex=2;((Button)form.AcceptButton).PerformClick();Pump();
     Check(form.DialogResult==DialogResult.OK&&callbacks==1&&saved!=null,"dirty valid delivery callback exactly once "+english);
     Check(saved.Time=="22:30"&&saved.Platform=="MT5"&&saved.Enabled,"delivery normalization preserved "+english);
     Check(saved.TelegramEnabled&&saved.BaleEnabled&&saved.EmailEnabled,"all three channels preserved "+english);
     Check(saved.TelegramTokenEnc==options.TelegramTokenEnc&&saved.BaleTokenEnc==options.BaleTokenEnc&&saved.SmtpPasswordEnc==options.SmtpPasswordEnc,"existing encrypted secrets preserved "+english);
    }
    Check(Same(scheduleBefore,options),"valid global save leaves source schedule object unchanged "+english);if(File.Exists(AppPaths.SettingsFile))File.Delete(AppPaths.SettingsFile);
   }
   Console.WriteLine("UNIFIED SETTINGS PASS "+checks);return 0;
  }
  catch(Exception e){Console.Error.WriteLine(e);return 1;}
  finally{AppPaths.DataDirOverride=old;try{Directory.Delete(root,true);}catch{}}
 }
}
