using System;
using System.Linq;

namespace MTManager
{
    static partial class Tests
    {
        static void ReportPresentationChecks()
        {
            DateTime first = new DateTime(2026, 11, 1), today = first.AddDays(2);
            var j = new AccountJournal { Platform = "MT4", Currency = "USD", Balance = 900,
                Complete = true, HistoryChecked = true, HistoryOk = true, HistorySum = 900, HistoryBalance = 900,
                From = first, TrustedFrom = first, FirstSeen = first, Exported = today.AddHours(12),
                FloatingBars = AccountJournal.TradesOnly };
            j.Cash.Add(new JournalCash { Time = first, Amount = 1000 });
            j.Trades.Add(new JournalTrade { Ticket = 1, Open = first.AddHours(1), Close = first.AddHours(2), Profit = -300, SlFinal = 1 });
            j.Trades.Add(new JournalTrade { Ticket = 2, Open = first.AddHours(3), Close = first.AddHours(4), Profit = 100, SlFinal = 1 });
            j.Cash.Add(new JournalCash { Time = first.AddHours(5), Amount = 500 });
            j.Cash.Add(new JournalCash { Time = first.AddHours(6), Amount = -400 });
            j.Open.Add(new JournalOpen { Ticket = 3, Open = first.AddDays(1), Profit = -50, SlEntry = 1, Sl = 0 });
            ProveDdCurve(j, DdEvent(10, first, 2, 1000), DdEvent(11, first.AddHours(2), 0, -300),
                DdEvent(12, first.AddHours(4), 1, 100), DdEvent(13, first.AddHours(5), 2, 500), DdEvent(14, first.AddHours(6), 2, -400));
            var range = ServerDays.Range(PanelRange.Today, today);
            PanelView v = PanelMath.Build(j, range, new TradeLimits());
            Check(Math.Abs(v.AccountDdPct - 30) < 0.0001 && v.AccountDdComplete,
                "account balance DD includes prior-day losses, ignores later deposits/withdrawals in the native trading curve, and survives disabled floating reconstruction");
            Equal("O/-50/No SL/DD-30%", PanelMath.Short(v), "open summary leads with O and uses current removed stop even when entry had SL");
            Check(v.Trades.Single().Stop == StopKind.Unprotected, "current open protection does not inherit a removed entry stop");
            Check(PanelMath.SummaryDetail(v).Contains(Lang.T("نه افت اکوئیتی", "not equity")) && PanelMath.SummaryDetail(v).Contains("2026.11.01"),
                "compact account DD has explicit balance basis and date provenance");
            string dayText = DayText.Make(1, "Student", "1", v);
            string reportText = ReportText.Make(range, new[] { new TextEntry { Number = 1, Name = "Student", Login = "1", View = v } }, TextParts.Dd);
            Check(dayText.Contains(PanelMath.DdText(v)) && reportText.Contains(PanelMath.DdText(v)) && PanelMath.AccountDdValue(v) == "30%",
                "both text export routes use the exact same available account DD as the panel");

            var historical = PanelMath.Build(j, ServerDays.Range(PanelRange.Today, first.AddDays(1)), new TradeLimits());
            Check(PanelMath.Short(historical).StartsWith("O/?/") && !PanelMath.Short(historical).Contains("-50"),
                "historical range never presents current floating result as historical P/L");
            var closedView = PanelMath.Build(j, ServerDays.Range(PanelRange.Today, first), new TradeLimits());
            Check(!PanelMath.Short(closedView).StartsWith("O/") && PanelMath.Short(closedView).StartsWith("-200/SL/DD-30%"),
                "closed result has no O prefix and delayed/MT4 stop distinctions do not appear as Late");
            j.FirstSeen = first.AddDays(-10);
            PanelMath.AccountDrawdown(j, v);
            Check(v.AccountDdComplete && Math.Abs(v.AccountDdPct - 30) < 0.0001,
                "full-curve proof is independent of the old visible-window FirstSeen marker");
            j.FullHistoryReconciled = false;
            PanelMath.AccountDrawdown(j, v);
            Check(double.IsNaN(v.AccountDdPct) && PanelMath.Short(v).Contains("DD?"), "unreconciled history yields unknown, not fabricated zero DD");

            var mt5 = new AccountJournal { Platform = "MT5", Balance = 990, Complete = true, HistoryChecked = true, HistoryOk = true,
                HistorySum = 990, HistoryBalance = 990, From = first, TrustedFrom = first, FirstSeen = first, Exported = today,
                FloatingBars = AccountJournal.TradesOnly };
            mt5.Deals.Add(new JournalDeal { Ticket = 1, Time = first, Type = 2, Profit = 1000 });
            mt5.Deals.Add(new JournalDeal { Ticket = 2, Time = first.AddHours(1), Type = 0, Position = 12, Commission = -7, Fee = -3 });
            mt5.Deals.Add(new JournalDeal { Ticket = 3, Time = first.AddHours(2), Type = 1, Position = 12, Profit = -400 });
            mt5.Deals.Add(new JournalDeal { Ticket = 4, Time = first.AddHours(3), Type = 1, Position = 12, Profit = 400 });
            mt5.Trades.Add(new JournalTrade { Ticket = 12, Open = first.AddHours(1), Close = first.AddHours(3), Commission = -10 });
            ProveDdCurve(mt5, DdEvent(1, first, 2, 1000), DdEvent(2, first.AddHours(1), 0, -10),
                DdEvent(3, first.AddHours(2), 1, -400), DdEvent(4, first.AddHours(3), 1, 400));
            PanelMath.AccountDrawdown(mt5, v);
            Check(Math.Abs(v.AccountDdPct - 41) < 0.0001, "MT5 full curve preserves partial-close drawdown and entry commission/fee timing hidden by position totals");
            mt5.FullHistoryValid = false;
            PanelMath.AccountDrawdown(mt5, v);
            Check(double.IsNaN(v.AccountDdPct), "windowed MT5 D records cannot replace a missing validated full-history curve");
        }
    }
}
