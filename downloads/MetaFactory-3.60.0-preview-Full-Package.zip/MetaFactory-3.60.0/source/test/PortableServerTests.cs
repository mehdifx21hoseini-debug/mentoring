using System;
using System.IO;
using System.Linq;
using System.Text;

namespace MTManager
{
    static partial class Tests
    {
        static void PortableServerChecks()
        {
            foreach (Kind kind in new[] { Kind.MT4, Kind.MT5 })
            {
                string label = kind.ToString();
                string install = Dir("server-transfer", label, "MetaQuotes Terminal");
                Touch(Path.Combine(install, Kinds.Exe(kind)), "terminal executable");
                Touch(Path.Combine(install, "config", "servers.dat"), "factory default server catalog");
                Touch(Path.Combine(install, "config", "accounts.ini"), "source account cache");
                string data = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MetaQuotes", "Terminal", "server-sync-" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(data);
                File.WriteAllText(Path.Combine(data, "origin.txt"), install, Encoding.Unicode);
                const string server = "WMMarkets-PortableSync-Demo";
                try
                {
                    Touch(Path.Combine(data, "Config", "servers.dat"), "working broker endpoint catalog version one");
                    Touch(Path.Combine(data, "Config", "accounts.dat"), "sensitive native account cache");
                    Touch(Path.Combine(data, "Config", "common.ini"), "sensitive native proxy settings");
                    Touch(Path.Combine(data, "Logs", "session.log"), "do not transfer");
                    if (kind == Kind.MT4) Touch(Path.Combine(data, "Config", server + ".SRV"), "working demo endpoints");
                    else Directory.CreateDirectory(Path.Combine(data, "Bases", server));
                    bool sure;
                    string guess = Dir("server-transfer", label, "WMMarkets-PortableSync Terminal");
                    Equal(install, ServerCatalog.ChooseInstall(kind, server, new[] { guess, install }, out sure, Installs.FindDataFolder), label + " exact AppData server beats broker-folder name guesses");
                    Check(sure, label + " exact AppData selection is recognized");
                    Check(PortableServers.Roots(install).Contains(data), label + " finds the native data folder through origin.txt");
                    var settings = new Settings { BaseDir = Dir("server-transfer", label, "copies") };
                    var copy = new Instance { Name = label + "-01", Kind = kind, Dir = Path.Combine(settings.BaseDir, label + "-01") };
                    StudentDirectory.Prepare(settings, install, copy, () => false);
                    Equal("working broker endpoint catalog version one", File.ReadAllText(Path.Combine(copy.Dir, "config", "servers.dat")), label + " lazy/private copy receives the active AppData catalog");
                    Check(!File.Exists(Path.Combine(copy.Dir, "config", "accounts.dat")), label + " never imports native cached credentials");
                    Check(!File.Exists(Path.Combine(copy.Dir, "config", "accounts.ini")), label + " never imports source cached credentials");
                    Check(!File.Exists(Path.Combine(copy.Dir, "config", "common.ini")), label + " does not import proxy/login settings");
                    Check(!Directory.Exists(Path.Combine(copy.Dir, "Logs")), label + " never imports native logs");
                    if (kind == Kind.MT4) Check(File.Exists(Path.Combine(copy.Dir, "config", server + ".SRV")), "MT4 .srv endpoint definition reaches portable copy");
                    Equal(0, PortableServers.Sync(install, copy.Dir, kind), label + " unchanged catalogs cause no writes");
                    string targetFile = Path.Combine(copy.Dir, "config", "servers.dat");
                    DateTime matchingTime = File.GetLastWriteTimeUtc(targetFile);
                    string desiredCatalog = File.ReadAllText(Path.Combine(data, "Config", "servers.dat"));
                    File.WriteAllText(targetFile, new string('x', desiredCatalog.Length)); File.SetLastWriteTimeUtc(targetFile, matchingTime);
                    Check(PortableServers.Sync(install, copy.Dir, kind) > 0, label + " same size and timestamp cannot conceal different endpoint bytes");
                    Equal(desiredCatalog, File.ReadAllText(targetFile), label + " authoritative native endpoint bytes replace stale equal-metadata content");
                    string before = File.ReadAllText(Path.Combine(copy.Dir, "config", "servers.dat"));
                    Touch(Path.Combine(data, "Config", "servers.dat"), "updated working broker endpoints version two");
                    StudentDirectory.Prepare(settings, install, copy, () => false);
                    Equal("updated working broker endpoints version two", File.ReadAllText(Path.Combine(copy.Dir, "config", "servers.dat")), label + " existing private copies are repaired without rebuilding executable");
                    Equal("terminal executable", File.ReadAllText(copy.Exe), label + " repair preserves the existing terminal executable");
                    Check(File.Exists(Path.Combine(copy.Dir, "config", "servers.dat.mtm-server-backup")), label + " replaced endpoint catalog has a backup");
                    Equal(0, PortableServers.Sync(install, install, kind), label + " native installation is never written into itself");
                    string cancelled = Dir("server-transfer", label, "cancelled");
                    Throws<OperationCanceledException>(() => PortableServers.Sync(install, cancelled, kind, null, () => true), label + " catalogue transfer can be cancelled before mutation");
                    Check(!Directory.Exists(Path.Combine(cancelled, "config")), label + " cancelled transfer creates no partial configuration");
                    string report = Path.Combine(settings.BaseDir, "report-copy");
                    ReportCopies.CopyFrom(new Instance { Name = "native-install", Kind = kind, Dir = install }, report);
                    Equal("updated working broker endpoints version two", File.ReadAllText(Path.Combine(report, "config", "servers.dat")), label + " report copies also inherit native endpoint information");
                    var legacyNames = CopyMaker.Create(new CreateRequest { Kind = kind, Source = install, Count = 1, Prefix = "Legacy" + label, CopyData = false }, settings, null);
                    Equal("updated working broker endpoints version two", File.ReadAllText(Path.Combine(settings.BaseDir, legacyNames[0], "config", "servers.dat")), label + " single-student and backup copy creation inherit AppData endpoints");
                    var legacy = new Instance { Name = legacyNames[0], Kind = kind, Dir = Path.Combine(settings.BaseDir, legacyNames[0]) };
                    File.WriteAllText(Path.Combine(legacy.Dir, "config", "servers.dat"), "obsolete portable catalog");
                    Check(PortableServers.RefreshClosed(legacy, settings, new Account { Instance = legacy.Name, Login = "123", Server = server }) > 0, label + " pre-existing closed personal copies repaired before start");
                    Equal("updated working broker endpoints version two", File.ReadAllText(Path.Combine(legacy.Dir, "config", "servers.dat")), label + " native exact server data replaces obsolete portable catalog");
                    var isolated = Dir("server-transfer", label, "isolated");
                    Touch(Path.Combine(isolated, "config", "accounts.ini"), "existing target account remains unchanged");
                    PortableServers.Sync(install, isolated, kind, server);
                    Equal("existing target account remains unchanged", File.ReadAllText(Path.Combine(isolated, "config", "accounts.ini")), label + " repair never touches an existing target account cache");
                    if (kind == Kind.MT4)
                    {
                        Touch(Path.Combine(data, "Config", "Other-Real.srv"), "unrelated endpoints");
                        PortableServers.Sync(install, isolated, kind, server);
                        Check(!File.Exists(Path.Combine(isolated, "config", "Other-Real.srv")), "MT4 targeted repair does not replace unrelated server definitions");
                    }
                    File.WriteAllBytes(Path.Combine(data, "Config", "servers.dat"), new byte[0]);
                    PortableServers.Sync(install, isolated, kind, server);
                    Equal("updated working broker endpoints version two", File.ReadAllText(Path.Combine(isolated, "config", "servers.dat")), label + " uninitialized native catalog never overwrites a working portable catalog");
                }
                finally { try { Directory.Delete(data, true); } catch { } }
            }
            Check(!PortableServers.Allowed("accounts.dat") && !PortableServers.Allowed("common.ini") && !PortableServers.Allowed("terminal.ini"), "network sync allowlist excludes credentials and terminal settings");
        }
    }
}
