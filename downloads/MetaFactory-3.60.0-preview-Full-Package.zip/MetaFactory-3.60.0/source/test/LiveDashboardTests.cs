using System;
using System.Linq;
namespace MTManager { static partial class Tests {
static void LiveDashboardChecks()
{
 DateTime utc=new DateTime(2026,11,20,9,0,0,DateTimeKind.Utc);
 var journal=LiveAccuracyHistory(utc.AddHours(2));
 var copy=new Instance{Name="MT5-live-dashboard",Kind=Kind.MT5,Dir=Dir("live-dashboard")};
 var account=new Account {Instance=copy.Name,Login=journal.Login,Server=journal.Server};
 var target=LiveMonitorTarget.Create(copy,account);target.Token=new string('a',32);
 var projector=new LiveDashboardProjectionCache();var summaries=new LiveReportSummaryCache();
 var feed=LiveAccuracySample(journal,utc,1,1,LiveFeedStatus.Live,50);
 var data=projector.Update(target,feed,summaries.Update(feed,utc));
 Check(data!=null && data.Today.Open==1 && data.Today.Closed==1,"verified live history projects current open and closed counts to dashboard");
 Check(data.Today.ClosedNet==-100 && data.Today.Floating==48 && data.Today.Net==-52,"dashboard realized costs and floating P/L are counted once");
 Check(Math.Abs(data.Today.AccountDdPct-10)<0.000001,"dashboard keeps the proved whole-account DD");
 Check(journal.Open.Count==0 && journal.Exported==utc.AddHours(2),"live projection never mutates its validated baseline");
 Check(data.Journal.Open.Single().Commission==0 && data.Journal.Open.Single().Sl==0,"MT5 current commission is not counted twice and current missing SL survives");
 Check(data.Matches(copy,account,utc.AddSeconds(9)) && !data.Matches(copy,account,utc.AddSeconds(11)),"dashboard currentness expires after native heartbeat limit");
 Check(!data.Matches(copy,new Account{Instance=copy.Name,Login="999",Server=account.Server},utc),"dashboard overlay rejects edited account identity");
 var second=LiveAccuracySample(journal,utc.AddSeconds(1),2,1,LiveFeedStatus.Live,80,opened:feed.Positions[0].Open);
 var updated=projector.Update(target,second,summaries.Update(second,utc.AddSeconds(1)));
 Check(updated.Today.Net==-22 && data.Today.Net==-52 && projector.Builds==1,"price pulse refreshes dashboard money without mutating older snapshot or rebuilding history");
 Check(updated.Journal.Exported==utc.AddHours(2).AddSeconds(1),"report read time is the actual heartbeat on the broker clock");
 var pending=LiveAccuracySample(journal,utc.AddSeconds(2),3,1,LiveFeedStatus.HistoryPending,80);
 Check(projector.Update(target,pending,summaries.Update(pending,utc.AddSeconds(2)))==null,"pending history cannot be published as a fresh full dashboard report");
 var unknown=LiveAccuracyHistory(utc.AddHours(2));unknown.GmtOffset=null;
 var unknownFeed=LiveAccuracySample(unknown,utc,4,2,LiveFeedStatus.Live,50);
 Check(projector.Update(target,unknownFeed,new LiveReportSummaryCache().Update(unknownFeed,utc))==null,"unknown broker clock cannot fabricate today's report");
 var tomorrow=LiveAccuracySample(journal,utc.AddDays(1),5,1,LiveFeedStatus.Live,50);
 Check(projector.Update(target,tomorrow,new LiveReportSummaryCache().Update(tomorrow,utc.AddDays(1)))==null,"previous-day baseline cannot become a zero-trade fresh day");
 Check(LiveDashboardMath.Build(data.Journal,ServerDays.Range(PanelRange.Today,data.Journal.Exported.Date.AddDays(1)))==null,"live report projection cannot fabricate a zero-trade day beyond its collection time");
 var incomplete=LiveAccuracyHistory(utc.AddHours(2));incomplete.Deals.Clear();double net;int count;
 Check(!LiveDashboardMath.Realized(incomplete,utc.AddHours(2).Date,utc.AddHours(2).Date.AddDays(1),out net,out count),"live range totals require deal/full-curve alignment");
 var newer=LiveAccuracyHistory(utc.AddHours(2).AddMinutes(5));
 Check(JournalCache.Save(newer),"newer manually-collected history is stored for live-cache precedence test");
 Check(!JournalCache.SaveLiveBaseline(journal) && JournalCache.Load(journal.Login,journal.Server).Exported==newer.Exported,"older live baseline cannot overwrite a newer manual report");
 var wrongPlatform=LiveAccuracyHistory(utc.AddHours(2).AddMinutes(6));wrongPlatform.Platform="MT4";
 Check(!JournalCache.SaveLiveBaseline(wrongPlatform),"live baseline cannot replace another platform's journal cache");
 var fresh=LiveAccuracyHistory(utc.AddHours(2).AddMinutes(7));
 Check(JournalCache.SaveLiveBaseline(fresh) && JournalCache.Load(fresh.Login,fresh.Server).Exported==fresh.Exported,"verified newer baseline persists with its original native read time");
}
}}
