"""Runs extracted MQL lease functions as C++ with mocked terminal APIs.
This verifies ownership decisions, not MQL compilation or Windows terminal behavior.
Requires Python3 and g++; never launches a terminal or reads user account files.
"""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
lease=[]
for ext in ('mq4','mq5'):
 s=(root/'report'/('MTManagerLive.'+ext)).read_text()
 lease.append(s[s.index('bool sessionOwned=false;'):s.index('uint bootTick =')])
assert lease[0]==lease[1], 'MT4 and MT5 lease logic differs'
preamble=r'''
#include <map>
#include <mutex>
#include <string>
#include <sstream>
#include <iomanip>
#include <functional>
#include <iostream>
#include <thread>
#include <vector>
#include <atomic>
#include <stdexcept>
using string=std::string;using uint=unsigned int;
std::map<string,double> vars;std::mutex gate;long now=1795183170;std::function<void()> beforeCas;
bool GlobalVariableCheck(string k){std::lock_guard<std::mutex> l(gate);return vars.count(k);}
double GlobalVariableGet(string k){std::lock_guard<std::mutex> l(gate);auto f=vars.find(k);return f==vars.end()?0:f->second;}
bool GlobalVariableTemp(string k){std::lock_guard<std::mutex> l(gate);return vars.emplace(k,0).second;}
long GlobalVariableSet(string k,double v){std::lock_guard<std::mutex> l(gate);vars[k]=v;return now;}
bool GlobalVariableSetOnCondition(string k,double value,double expected){if(beforeCas){auto hook=beforeCas;beforeCas=nullptr;hook();}std::lock_guard<std::mutex> l(gate);auto f=vars.find(k);if(f==vars.end()||f->second!=expected)return false;f->second=value;return true;}
long TimeLocal(){return now;}uint GetTickCount(){return (uint)now*1000;}
int GetLastError(){return 0;}
string DoubleToString(double d,int){std::ostringstream s;s<<std::fixed<<std::setprecision(0)<<d;return s.str();}
struct Context {string WorkToken=string(32,'a'),problem;long chart;
Context(long c):chart(c){}long ChartID(){return chart;}
bool InitProblem(string why,int e=0){problem=why;return false;}
'''
post=r'''
};
int checks=0;void check(bool b,const char* name){if(!b)throw std::runtime_error(name);checks++;std::cout<<"PASS "<<name<<"\n";}
int main(){try{
 Context a(1),b(2);check(a.AcquireLease(),"first observer acquires lease");
 check(!b.AcquireLease(),"second observer cannot replace a fresh owner");
 check(a.RefreshLease(),"rejected contender leaves original writer active");
 now+=31;check(b.AcquireLease(),"expired owner can be replaced");
 check(!a.RefreshLease(),"old observer cannot publish after ownership changed");
 check(b.RefreshLease(),"replacement observer retains ownership");
 GlobalVariableSetOnCondition(b.ownerKey,0,b.ownerId);check(a.AcquireLease(),"released lease can be reclaimed");
 now+=31;beforeCas=[&]{check(a.RefreshLease(),"original owner renews during takeover attempt");};
 check(!b.AcquireLease(),"takeover is abandoned if original owner renewed during claim");
 check(a.RefreshLease(),"renewal race restores the original owner");
 Context different(3);different.WorkToken=string(32,'b');check(different.AcquireLease(),"another session is independent");
 vars.clear();std::atomic<int> winners{0};std::vector<std::thread> workers;
 for(int i=0;i<20;i++)workers.emplace_back([&,i]{Context c(100+i);if(c.AcquireLease())winners++;});
 for(auto& t:workers)t.join();check(winners==1,"twenty competing observers yield exactly one owner");
 std::cout<<"EXTRACTED NATIVE LEASE MODEL PASS "<<checks<<" (mock terminal APIs, not MQL runtime)\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}}
'''
with tempfile.TemporaryDirectory(prefix='mf-native-lease-') as tmp:
 source=Path(tmp)/'lease.cpp';exe=Path(tmp)/'lease'
 source.write_text(preamble+lease[0]+post)
 subprocess.run(['g++','-std=c++17','-O2','-pthread',str(source),'-o',str(exe)],check=True)
 subprocess.run([str(exe)],check=True)
