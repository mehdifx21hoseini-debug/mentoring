using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using MTManager;

static class ScheduleUiSmoke
{
    static int checks;
    static void Assert(bool ok, string message) { checks++; if (!ok) throw new Exception(message); }
    static T Field<T>(object value, string name) { return (T)value.GetType().GetField(name, BindingFlags.NonPublic | BindingFlags.Instance).GetValue(value); }
    static void Pump() { for (int n = 0; n < 8; n++) { Application.DoEvents(); Thread.Sleep(10); } }
    static void Shot(Form f, string path)
    { using (var shot = new Bitmap(f.Width, f.Height)) { using (var g = Graphics.FromImage(shot)) g.CopyFromScreen(f.Location, Point.Empty, f.Size); shot.Save(path); } }
    [STAThread] static int Main(string[] args)
    {
        Lang.En = Array.IndexOf(args, "en") >= 0; Application.EnableVisualStyles();
        typeof(Account).Assembly.GetType("MTManager.Theme").GetMethod("Init").Invoke(null, null);
        var options = new ScheduleOptions { Enabled = false, Time = "22:00", Platform = "All",
            TelegramTokenEnc = Secret.Protect("123456:" + new string('a', 35)), TelegramChatId = "-100123456789",
            BaleTokenEnc = Secret.Protect("123456:" + new string('b', 35)), BaleChatId = "12345",
            SmtpPasswordEnc = Secret.Protect("test-password-do-not-send"), SmtpPort = 587 };
        try
        {
            using (var dialog = new ScheduleDialog(options, Lang.T("هنوز اجرای برنامه‌ریزی‌شده‌ای انجام نشده", "No scheduled run yet")))
            {
                dialog.Size = new Size(640, 480); dialog.Show(); Pump();
                if (args.Length > 1) Shot(dialog, Path.ChangeExtension(args[1], null) + "-top.png");
                Assert(!ReferenceEquals(dialog.Options, options), "dialog owns a cloned model");
                Assert(Field<TextBox>(dialog, "telegramToken").UseSystemPasswordChar && Field<TextBox>(dialog, "baleToken").UseSystemPasswordChar && Field<TextBox>(dialog, "smtpPassword").UseSystemPasswordChar, "all secret inputs are masked");
                var scroll = Field<Panel>(dialog, "scroll"); var save = Field<Button>(dialog, "saveButton"); var cancel = Field<Button>(dialog, "cancelButton");
                Assert(scroll.VerticalScroll.Visible, "small dialog scrolls configuration rather than clipping it");
                Assert(save.Visible && cancel.Visible && save.Bottom <= save.Parent.ClientSize.Height, "save and cancel remain visible at small size");
                Assert(!Field<TextBox>(dialog, "baleToken").Enabled, "unchecked channel inputs are inactive");
                Field<CheckBox>(dialog, "baleEnabled").Checked = true; Field<CheckBox>(dialog, "telegramEnabled").Checked = true;
                Assert(Field<TextBox>(dialog, "baleToken").Enabled && Field<TextBox>(dialog, "telegramToken").Enabled, "channels can be enabled together");
                Field<CheckBox>(dialog, "emailEnabled").Checked = true;
                Field<TextBox>(dialog, "smtpHost").Text = "smtp.example.com";
                Field<TextBox>(dialog, "smtpUser").Text = "reports@example.com";
                Field<TextBox>(dialog, "emailFrom").Text = "reports@example.com";
                Field<TextBox>(dialog, "emailTo").Text = "mentor@example.com";
                Field<CheckBox>(dialog, "dailyEnabled").Checked = true; Field<TextBox>(dialog, "time").Text = "99:99";
                save.PerformClick(); Pump();
                Assert(dialog.DialogResult != DialogResult.OK && Field<Label>(dialog, "error").Visible, "invalid schedule is shown locally and not saved");
                Assert(!options.Enabled && options.Time == "22:00", "editing and invalid save never mutate original options");
                Field<TextBox>(dialog, "time").Text = "۲۲:۳۰"; Field<ComboBox>(dialog, "platform").SelectedIndex = 2;
                Field<TextBox>(dialog, "smtpPassword").Text = "replacement-password";
                scroll.AutoScrollPosition = new Point(0, 10000); Pump();
                if (args.Length > 1) Shot(dialog, args[1]);
                save.PerformClick(); Pump();
                Assert(dialog.DialogResult == DialogResult.OK && dialog.Options.Enabled && dialog.Options.Time == "22:30" && dialog.Options.Platform == "MT5", "save normalizes local Persian digits and platform scope");
                Assert(dialog.Options.TelegramEnabled && dialog.Options.BaleEnabled && dialog.Options.EmailEnabled, "all three channel choices can be saved together");
                Assert(dialog.Options.TelegramTokenEnc == options.TelegramTokenEnc && dialog.Options.BaleTokenEnc == options.BaleTokenEnc, "unchanged secrets preserve exact ciphertext");
                Assert(Secret.Unprotect(dialog.Options.SmtpPasswordEnc) == "replacement-password" && dialog.Options.SmtpPasswordEnc != "replacement-password", "edited secrets are encrypted");
                Assert(options.Time == "22:00" && !options.Enabled && Secret.Unprotect(options.SmtpPasswordEnc) == "test-password-do-not-send", "successful save still leaves input model untouched");
            }
            using (var dialog = new ScheduleDialog(options, ""))
            {
                dialog.Size = new Size(2000, 1600); dialog.Show(); Pump();
                Assert(Screen.FromControl(dialog).WorkingArea.Contains(dialog.Bounds), "oversized dialog is clamped to working area so footer remains reachable");
                Field<TextBox>(dialog, "time").Text = "10:00";
                Field<Button>(dialog, "cancelButton").PerformClick(); Pump();
                Assert(dialog.DialogResult == DialogResult.Cancel && options.Time == "22:00" && dialog.Options.Time == "22:00", "Cancel discards edits");
            }
            var unreadable = new ScheduleOptions { Enabled = true, TelegramEnabled = true, TelegramTokenEnc = "unreadable-existing-ciphertext", Time = "22:00", Platform = "All" };
            using (var dialog = new ScheduleDialog(unreadable, ""))
            {
                dialog.Show(); Pump(); Field<CheckBox>(dialog, "dailyEnabled").Checked = false; Field<Button>(dialog, "saveButton").PerformClick(); Pump();
                Assert(dialog.DialogResult == DialogResult.OK && !dialog.Options.Enabled && dialog.Options.TelegramTokenEnc == unreadable.TelegramTokenEnc,
                    "broken stored credentials never block disabling the schedule and their ciphertext is preserved");
            }
            Console.WriteLine("PASS " + checks + " schedule UI checks (" + (Lang.En ? "en" : "fa") + ")"); return 0;
        }
        catch (Exception e) { Console.Error.WriteLine(e); return 1; }
    }
}
