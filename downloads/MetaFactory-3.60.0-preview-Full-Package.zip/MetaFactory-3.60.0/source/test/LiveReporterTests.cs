using System;
using System.IO;
using System.Text;

namespace MTManager
{
    static partial class Tests
    {
        static void LiveReporterChecks()
        {
            const string token = "0123456789abcdef0123456789abcdef";
            Equal(token, LiveReporter.ValidateToken(token.ToUpperInvariant()), "live token normalized to fixed safe directory name");
            Throws<UserMessage>(() => LiveReporter.ValidateToken("../" + token), "live token cannot traverse paths");
            Throws<UserMessage>(() => LiveReporter.ValidateToken(token + "\n"), "live token rejects trailing newline");
            Throws<UserMessage>(() => LiveReporter.ValidateToken("short"), "live token must contain 32 hex digits");
            var account = new Account { Instance = "MT4-live-test", Login = "0012345", Server = "WMMarkets-DEMO", MasterEnc = "private-master", InvestorEnc = "private-investor" };
            string preset = LiveReporter.PresetText(account, token);
            Check(preset.Contains("ExpectedLogin=12345\r\n") && preset.Contains("ExpectedServer=WMMarkets-DEMO\r\n"), "live preset binds canonical account and exact server");
            Check(!preset.Contains("private-master") && !preset.Contains("private-investor") && !preset.Contains("Password"), "live preset contains no account password");
            var invalid = account.Snapshot(); invalid.Server = "good\r\nOtherInput=bad";
            Throws<UserMessage>(() => LiveReporter.PresetText(invalid, token), "server cannot inject native preset settings");
            invalid = account.Snapshot(); invalid.Login = "18446744073709551616";
            Throws<UserMessage>(() => LiveReporter.PresetText(invalid, token), "live login overflow is rejected before deployment");
            invalid = account.Snapshot(); invalid.Login = "9223372036854775808";
            Throws<UserMessage>(() => LiveReporter.PresetText(invalid, token), "live login respects native signed-long range");
            invalid = account.Snapshot(); invalid.Server = "WM\tDemo";
            Throws<UserMessage>(() => LiveReporter.PresetText(invalid, token), "live server rejects tab delimiters");
            invalid.Server = new string('x', 257);
            Throws<UserMessage>(() => LiveReporter.PresetText(invalid, token), "live server length is bounded");
            Equal(null, SandboxLaunch.LiveDirectoryDecision("MetaFactory_known_1", "metafactory_KNOWN_1", true), "live deployment permits a matching managed box with verified direct directory access");
            Check(SandboxLaunch.LiveDirectoryDecision("MetaFactory_known_1", "DefaultBox", true) != null, "live deployment rejects a different custom box even if a managed assignment exists");
            Check(SandboxLaunch.LiveDirectoryDecision("MetaFactory_known_1", "MetaFactory_known_1", false) != null, "live deployment rejects missing owner/direct-path proof");
            Check(SandboxLaunch.LiveDirectoryDecision(null, "DefaultBox", false) != null, "unmanaged DefaultBox yields explicit unsupported guidance");
            string binary = Path.Combine(Dir("live-reporter-test", "cache"), "mock.ex4");
            File.WriteAllBytes(binary, new byte[] { 1, 2, 3, 4 });
            string hash = new string('A', 64);
            foreach (Kind kind in new[] { Kind.MT4, Kind.MT5 })
            {
                var copy = new Instance { Name = kind + "-live-test", Kind = kind, Dir = Dir("live-reporter-test", kind.ToString()) };
                string expertRoot = Dir("live-reporter-test", kind.ToString(), Kinds.Mql(kind), "Experts");
                string userExpert = Path.Combine(expertRoot, "ExistingUserEA" + (kind == Kind.MT4 ? ".ex4" : ".ex5"));
                string profile = Path.Combine(Dir("live-reporter-test", kind.ToString(), "profiles", "default"), "chart01.chr");
                File.WriteAllText(userExpert, "user expert"); File.WriteAllText(profile, "user profile with attached EA");
                LiveReporterDeployment deployment = LiveReporter.DeployBuilt(copy, binary, hash, token, preset);
                Check(File.Exists(deployment.ExpertPath) && File.Exists(deployment.PresetPath), "live binary and per-session preset deployed for " + kind);
                Check(deployment.ExpertPath.Contains("MetaFactoryLive") && deployment.ExpertPath.EndsWith(LiveReporter.BinaryName(kind)), "live EA uses independent versioned expert directory for " + kind);
                Equal(Path.Combine(copy.Dir, Kinds.Mql(kind), "Files", "MetaFactoryLive", token, "snapshot.txt"), deployment.SnapshotPath, "live snapshot path matches native token protocol for " + kind);
                Equal("user expert", File.ReadAllText(userExpert), "existing user EA is never overwritten for " + kind);
                Equal("user profile with attached EA", File.ReadAllText(profile), "existing profile is untouched for " + kind);
                Check(LiveChartPolicy.HasPreservedCharts(copy), "successful live preparation opts this copy into chart preservation for " + kind);
                string again = LiveReporter.DeployBuilt(copy, binary, hash, token, preset).ExpertPath;
                Equal(deployment.ExpertPath, again, "identical live deployment is idempotent for " + kind);
                Throws<UserMessage>(() => LiveReporter.DeployBuilt(copy, binary, hash, token, preset + "Changed=1\r\n"), "existing session preset cannot be silently rebound for " + kind);
                File.WriteAllText(deployment.ExpertPath, "do not overwrite");
                Throws<UserMessage>(() => LiveReporter.DeployBuilt(copy, binary, hash, token, preset), "modified existing EA is preserved for " + kind);
                Equal("do not overwrite", File.ReadAllText(deployment.ExpertPath), "collision leaves EA contents unchanged for " + kind);
            }
            var cancelledCopy = new Instance { Name = "MT4-cancelled", Kind = Kind.MT4, Dir = Path.Combine(root, "live-not-created") };
            Throws<OperationCanceledException>(() => LiveReporter.DeployBuilt(cancelledCopy, binary, hash, token, preset, () => true), "cancelled live deployment stops before any terminal files are written");
            Check(!Directory.Exists(cancelledCopy.Dir), "cancellation does not create or start a terminal copy");
            LiveChartPolicyChecks();
            if (Environment.OSVersion.Platform != PlatformID.Win32NT)
                Throws<UserMessage>(() => LiveReporter.Build(new Settings(), Kind.MT4), "non-Windows build is explicitly unsupported, never reported as compiled");
        }

        static void LiveChartPolicyChecks()
        {
            foreach (Kind kind in new[] { Kind.MT4, Kind.MT5 })
            {
                var copy = new Instance { Name = kind + "-preserved", Kind = kind, Dir = Dir("live-chart-policy", kind.ToString()) };
                Check(!LiveChartPolicy.HasPreservedCharts(copy), "plain copy has no live preservation opt-in for " + kind);
                LiveChartPolicy.PreserveCharts(copy);
                Check(LiveChartPolicy.HasPreservedCharts(copy), "exact live marker is recognized for " + kind);
                string profile = ChartProfile.DefaultDir(copy); Directory.CreateDirectory(profile);
                File.WriteAllText(Path.Combine(profile, "chart01.chr"), "existing EA chart");
                File.WriteAllText(Path.Combine(profile, "chart02.chr"), "live EA chart");
                var settings = new Settings { BaseDir = Path.GetDirectoryName(copy.Dir), StartCharts = ChartModes.One, Light = true };
                var accounts = new AccountStore();
                StartResult start = Launcher.WriteStartFile(copy, settings, accounts);
                Equal(2, Directory.GetFiles(profile, "*.chr").Length, "manual launch preparation preserves both existing and live chart for " + kind);
                Launcher.DeleteStartFile(start.StartFile);
                File.Delete(LiveChartPolicy.MarkerPath(copy));
                start = Launcher.WriteStartFile(copy, settings, accounts);
                Equal(1, Directory.GetFiles(profile, "*.chr").Length, "non-opted-in copy retains normal light-profile behavior for " + kind);
                Launcher.DeleteStartFile(start.StartFile);
                File.WriteAllText(LiveChartPolicy.MarkerPath(copy), new string('x', 10000));
                Check(!LiveChartPolicy.HasPreservedCharts(copy), "oversized live marker is rejected with bounded reading for " + kind);
                Throws<UserMessage>(() => LiveChartPolicy.PreserveCharts(copy), "unrecognized existing marker is not overwritten for " + kind);
            }
        }
    }
}
