using System;
using System.Globalization;
using System.IO;
using System.Text;

namespace MTManager
{
    static partial class Tests
    {
        const string FeedToken = "0123456789abcdef0123456789abcdef";
        static long feedWrite;
        static string FeedFrame(DateTime now, long sequence = 1, string run = "run-a", string state = "ready", bool connected = true, long revision = 1)
        {
            return "MLIVE\t1\tMT5\nQ\t" + FeedToken + "\nR\t" + run + "\t" + sequence + "\t" + JournalFile.Unix(now)
                + "\nA\t123\tBroker-Demo\tUSD\nS\t" + (connected ? "1" : "0") + "\t" + state
                + "\nV\t900\t905.5\t20\t885.5\t0\nH\t" + revision + "\t0"
                + "\nO\t77\tEURUSD\t0\t2.5\t" + JournalFile.Unix(now.AddHours(-1)) + "\t1.1\t1.0\t1.4\t10\t-1.5\t-1\t1.2\t-3\nEND\t1\n";
        }
        static string FeedHistory(DateTime now, long revision = 1, string run = "run-a")
        {
            var j = new AccountJournal { Platform = "MT5", Login = "123", Server = "Broker-Demo", Currency = "USD", Balance = 900, Equity = 900,
                From = now.Date, Exported = now, Complete = true, HistoryChecked = true, HistoryOk = true, HistorySum = 900, HistoryBalance = 900,
                FullHistoryPresent = true, FullHistoryValid = true, FullHistoryRequested = true, FullHistoryScanOk = true, FullHistoryReconciled = true,
                FullHistoryCount = 2, FullHistorySum = 900, FullHistoryBalance = 900, FloatingBars = AccountJournal.TradesOnly };
            long ms = long.Parse(JournalFile.Unix(now.AddDays(-2)), CultureInfo.InvariantCulture) * 1000;
            j.FullHistory.Add(new JournalBalanceEvent { TimeMilliseconds = ms, Ticket = 1, Type = 2, Net = 1000 });
            j.FullHistory.Add(new JournalBalanceEvent { TimeMilliseconds = ms + 1000, Ticket = 2, Type = 0, Net = -100 });
            return JournalFile.Write(j).Replace("\r\nA\t", "\r\nQ\t" + FeedToken + "\r\nLIVE\t1\t" + FeedToken + "\t" + run + "\t" + revision + "\r\nA\t");
        }
        static void FeedWrite(string path, string text)
        { File.WriteAllText(path, text, Encoding.Unicode); File.SetLastWriteTimeUtc(path, new DateTime(2026, 11, 20).AddSeconds(++feedWrite)); }

        static void LiveFeedChecks()
        {
            DateTime rawNow=new DateTime(2026,11,20,12,0,0,DateTimeKind.Utc);
            string rawDirectory=Dir("live-feed-bomless");
            string rawSnapshot=Path.Combine(rawDirectory,"snapshot.txt"),rawHistory=Path.Combine(rawDirectory,"history-0.txt");
            File.WriteAllBytes(rawSnapshot,Encoding.Unicode.GetBytes(FeedFrame(rawNow)));
            File.WriteAllBytes(rawHistory,Encoding.Unicode.GetBytes(FeedHistory(rawNow)));
            var rawReader=new LiveFeedReader(Kind.MT5,"123","Broker-Demo",FeedToken,rawDirectory);
            var rawResult=rawReader.Poll(rawNow);
            Check(rawResult.Status==LiveFeedStatus.Live && rawResult.History!=null && rawResult.Positions.Count==1,"native UTF16 without BOM is accepted for both snapshot and full-history proof");
            byte[] odd=Encoding.Unicode.GetBytes(FeedFrame(rawNow));Array.Resize(ref odd,odd.Length-1);File.WriteAllBytes(rawSnapshot,odd);
            Check(!new LiveFeedReader(Kind.MT5,"123","Broker-Demo",FeedToken,rawDirectory).Poll(rawNow).IsLive,"odd/truncated BOM-less Unicode cannot become fresh financial data");

            DateTime now = new DateTime(2026, 11, 20, 12, 0, 0, DateTimeKind.Utc);
            string dir = Dir("live-feed-protocol"), snapshot = Path.Combine(dir, "snapshot.txt"), history = Path.Combine(dir, "history-0.txt");
            var reader = new LiveFeedReader(Kind.MT5, "123", "Broker-Demo", FeedToken, dir);
            Check(reader.Poll(now).Status == LiveFeedStatus.Waiting, "live receiver waits without launching a terminal");
            FeedWrite(snapshot, FeedFrame(now));
            var result = reader.Poll(now);
            Check(result.IsLive && result.Status == LiveFeedStatus.HistoryPending && result.History == null,
                "fresh current values remain distinct from missing historical proof");
            Check(result.Positions.Count == 1 && result.Positions[0].Net == 5.5 && result.Positions[0].SlEntry == -1 && result.Positions[0].Price == 1.2 && result.Positions[0].Commission == -3,
                "native 14-field O mapping preserves exact profit/swap/commission/current-price semantics");
            FeedWrite(history, FeedHistory(now));
            result = reader.Poll(now.AddSeconds(2));
            Check(result.Status == LiveFeedStatus.Live && result.History != null && result.History.FullHistoryValid,
                "matching session/run/revision baseline becomes usable after bounded availability retry");
            var kept = result.History;
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(3), 2)); result = reader.Poll(now.AddSeconds(3));
            Check(object.ReferenceEquals(kept, result.History), "ordinary heartbeats reuse parsed baseline instead of scanning whole history each second");
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(4), 3, state: "history-pending")); result = reader.Poll(now.AddSeconds(4));
            Check(result.IsLive && result.History == null && result.NativeState == "history-pending", "same-balance history dirtiness cannot reuse old history as current");
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(5), 4).Replace("V\t900", "V\t901")); result = reader.Poll(now.AddSeconds(5));
            Check(result.Status == LiveFeedStatus.HistoryPending && result.History == null, "current balance mismatch with baseline suppresses historical metrics");
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(6), 5, revision: 2));
            result = reader.Poll(now.AddSeconds(6));
            Check(result.History == null, "slot content for another history revision is rejected");
            FeedWrite(history, FeedHistory(now.AddSeconds(6), 2)); result = reader.Poll(now.AddSeconds(8));
            Check(result.History != null && result.HistoryRevision == 2, "atomically replaced matching history revision becomes usable");
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(9), 6, revision: 1));
            Check(reader.Poll(now.AddSeconds(9)).Reason == "history-revision-replay", "same-run higher sequence cannot roll history revision backward");
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(9), 6, connected: false, revision: 2)); result = reader.Poll(now.AddSeconds(9));
            Check(!result.IsLive && result.Status == LiveFeedStatus.Disconnected && double.IsNaN(result.Balance) && result.Positions.Count == 0 && result.History == null,
                "disconnected snapshots never expose cached amounts as live");
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(10), 7, state: "stopped", revision: 2)); result = reader.Poll(now.AddSeconds(10));
            Check(result.Status == LiveFeedStatus.Stopped && !result.IsLive, "explicit native stopped state wins even if native connected flag stayed true");
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(11), 8, revision: 2)); result = reader.Poll(now.AddSeconds(22));
            Check(result.Status == LiveFeedStatus.Stale && !result.IsLive, "stale heartbeats do not become live when a file is reread");
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(40), 8, revision: 2)); result = reader.Poll(now.AddSeconds(23));
            Check(result.Status == LiveFeedStatus.Stale && !result.IsLive, "future heartbeats outside clock-skew allowance fail closed");
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(24), 8, revision: 2)); reader.Poll(now.AddSeconds(24));
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(35), 8, revision: 2)); result = reader.Poll(now.AddSeconds(35));
            Check(result.Status == LiveFeedStatus.Stale, "same sequence cannot refresh heartbeat receipt or revive expired data");
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(36), 1, "run-b")); result = reader.Poll(now.AddSeconds(36));
            Check(result.IsLive && result.RunId == "run-b" && result.History == null, "new EA run can restart sequence but cannot inherit old run baseline");
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(37), 100, "run-a")); result = reader.Poll(now.AddSeconds(37));
            Check(!result.IsLive && result.Reason == "retired-or-older-run", "retired run cannot replay even with a fresh timestamp and higher sequence");
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(38), 3, "run-b")); reader.Poll(now.AddSeconds(38));
            FeedWrite(snapshot, FeedFrame(now.AddSeconds(39), 2, "run-b")); result = reader.Poll(now.AddSeconds(39));
            Check(!result.IsLive && result.Reason == "sequence-replay", "decreasing sequence cannot replace current data");
            foreach (string invalid in new[] {
                FeedFrame(now.AddSeconds(40), 4, "run-b").Replace("A\t123", "A\t999"),
                FeedFrame(now.AddSeconds(40), 4, "run-b").Replace("Broker-Demo", "Different-Demo"),
                FeedFrame(now.AddSeconds(40), 4, "run-b").Replace("MLIVE\t1\tMT5", "MLIVE\t1\tMT4"),
                FeedFrame(now.AddSeconds(40), 4, "run-b").Replace(FeedToken, "ffffffffffffffffffffffffffffffff") })
            {
                FeedWrite(snapshot, invalid); result = reader.Poll(now.AddSeconds(40));
                Check(result.Status == LiveFeedStatus.IdentityMismatch && !result.IsLive && double.IsNaN(result.Balance), "account/platform/session changes cannot present the wrong account live");
            }
            foreach (string invalid in new[] { FeedFrame(now.AddSeconds(40), 4, "run-b").Replace("END\t1", ""),
                FeedFrame(now.AddSeconds(40), 4, "run-b").Replace("END\t1", "END\t2"),
                FeedFrame(now.AddSeconds(40), 4, "run-b").Replace("V\t900", "V\tNaN"),
                FeedFrame(now.AddSeconds(40), 4, "run-b") + "H\t2\t0\n" })
            {
                FeedWrite(snapshot, invalid); result = reader.Poll(now.AddSeconds(40));
                Check(result.Status == LiveFeedStatus.Invalid && !result.IsLive, "partial/nonfinite/trailing snapshot fails closed");
            }
            FeedWrite(snapshot, new string('x', LiveFeedReader.MaximumSnapshotBytes));
            Check(reader.Poll(now.AddSeconds(40)).Status == LiveFeedStatus.Invalid, "oversized Unicode snapshot is bounded before decode");
            Check(reader.Poll(now, () => true).Status == LiveFeedStatus.Stopped, "receiver cancellation returns promptly without file work");
            // A separate reader isolates baseline rejection tests from accepted generation caching.
            foreach (string invalidHistory in new[] {
                FeedHistory(now) + "LIVE\t1\t" + FeedToken + "\trun-a\t1\n",
                FeedHistory(now).Replace("LIVE\t1\t" + FeedToken + "\trun-a\t1", "LIVE\t1\t" + FeedToken + "\tother-run\t1"),
                FeedHistory(now).Replace("JC\t1\t2", "JC\t1\t3"),
                FeedHistory(now).Replace("Broker-Demo", "Other-Server") })
            {
                FeedWrite(snapshot, FeedFrame(now)); FeedWrite(history, invalidHistory);
                var isolated = new LiveFeedReader(Kind.MT5, "123", "Broker-Demo", FeedToken, dir);
                var rejected = isolated.Poll(now);
                Check(rejected.IsLive && rejected.History == null, "invalid identity/count/trailing baseline metadata cannot be attached as proven current history");
            }
            FeedWrite(snapshot, FeedFrame(now, state: "error", connected: false));
            var errorReader = new LiveFeedReader(Kind.MT5, "123", "Broker-Demo", FeedToken, dir);
            Check(errorReader.Poll(now).Reason == "native-error", "native collection error remains distinct from broker disconnection");
            File.Delete(snapshot);
            Check(!reader.Poll(now.AddSeconds(40)).IsLive, "missing snapshot never resurrects last accepted values");
        }
    }
}
