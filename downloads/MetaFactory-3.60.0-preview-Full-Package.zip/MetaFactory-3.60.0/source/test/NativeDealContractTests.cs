using System;using System.IO;using System.Text;using System.Linq;using System.Globalization;
namespace MTManager {static partial class Tests {
static void NativeDealContractChecks()
{
    string native=LiveReporter.SourceText(Kind.MT5);
    int export=native.IndexOf("bool ExportReport()",StringComparison.Ordinal);
    int detail=native.IndexOf("Line(h,\"D\\t\"",export,StringComparison.Ordinal);
    int skip=native.IndexOf("if(type == DEAL_TYPE_BUY || type == DEAL_TYPE_SELL) continue;",export,StringComparison.Ordinal);
    Check(detail>export && detail<skip,"production MT5 live exporter emits D detail before skipping buy/sell cash rows");
    Check(native.Contains("T(detailTime)")&&native.Contains("N(commission)+\"\\t\"+N(fee)+\"\\t\"+N(swap)+\"\\t\"+N(profit)"),"native deal layout preserves timestamp and separate commission/fee/swap/profit fields");
    Check(native.Contains("if(!detailOk)curveScanOk=false;")&&native.Contains("!ValidateExport("),"failed deal reads invalidate native publication instead of creating daily zeros");
    string detailBlock=native.Substring(detail,skip-detail);
    Check(!detailBlock.Contains("records++"),"native D extension must not increase legacy END record count");
    // Consumer regression: the old native exporter had J/T but no D. A valid balance proof
    // with current-day trading events must remain unavailable until matching D details arrive.
    DateTime utc=new DateTime(2026,11,23,12,0,0,DateTimeKind.Utc),server=utc.AddHours(2);
    var history=LiveAccuracyHistory(server);history.Deals.Clear();
    var missing=new LiveReportSummaryCache().Update(LiveAccuracySample(history,utc,1,1,LiveFeedStatus.Live,0),utc);
    Check(missing.HistoryReady&&!missing.TodayKnown&&double.IsNaN(missing.TodayClosedNet),"old J/T-only export reproduces screenshot: live history ready but daily result unknown");
    history.Deals.Add(new JournalDeal{Ticket=2,Order=20,Position=9,Type=0,Entry=1,Symbol="SYNTH",Time=server.AddMinutes(-3),Volume=1,Price=1.2,Profit=-90,Commission=-6,Swap=-4,Fee=0});
    string raw=JournalFile.Write(history);var parsed=JournalFile.Parse(raw);
    Check(parsed!=null&&parsed.Complete&&parsed.FullHistoryValid&&parsed.Deals.Count==1,"native D protocol roundtrips with unchanged full-curve proof and END count");
    int counted=raw.Split(new[]{"\r\n"},StringSplitOptions.RemoveEmptyEntries).Count(x=>x.StartsWith("J\t")||x.StartsWith("T\t")||x.StartsWith("O\t")||x.StartsWith("B\t"));
    string wire=raw.Replace("END\t"+counted+"\r\n","END\t"+(counted+parsed.Deals.Count)+"\r\n");
    var oldNative=JournalFile.Parse(wire);
    Check(oldNative!=null&&!oldNative.Complete&&!oldNative.FullHistoryValid,"3504 native END plus D reproduces rejected history proof");
    Check(raw.Contains("END\t"+counted+"\r\n")&&parsed.Complete,"3505 native END counts J/T/O/B only, preserving extension protocol");
    var ready=new LiveReportSummaryCache().Update(LiveAccuracySample(parsed,utc,2,1,LiveFeedStatus.Live,0),utc);
    Check(ready.TodayKnown&&ready.TodayClosedCount==1&&Math.Abs(ready.TodayClosedNet+100)<1e-9,"matching detailed deal unlocks exact daily result without loosening validation");
    parsed.Deals[0].Fee=-1;var mismatched=new LiveReportSummaryCache().Update(LiveAccuracySample(parsed,utc,3,1,LiveFeedStatus.Live,0),utc);
    Check(!mismatched.TodayKnown,"incorrect deal fee still fails daily validation");
    parsed.Deals[0].Fee=0;parsed.Deals.Add(parsed.Deals[0]);
    Check(!new LiveReportSummaryCache().Update(LiveAccuracySample(parsed,utc,4,1,LiveFeedStatus.Live,0),utc).TodayKnown,"duplicate deal remains rejected, not double-counted");
}
}}
