using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

namespace MTManager
{
    static partial class Tests
    {
        static void LiveIntegrationChecks()
        {
            var copy = new Instance { Name = "MT5-live", Kind = Kind.MT5, Dir = Dir("live-student") };
            var account = new Account { Login = "123456", Server = "Broker-Demo", Trader = "Live student", Platform = "MT5" };
            var target = LiveMonitorTarget.Create(copy, account);
            Check(target.Valid && target.Token.Length == 32 && target.Matches(copy, account), "live target has a random session tied to copy, platform, login and server");
            Check(target.Token != LiveMonitorTarget.Create(copy, account).Token, "new live preparation identities do not reuse another target's session");
            var changed = account.Snapshot(); changed.Login = "123457";
            Check(!target.Matches(copy, changed), "changing account invalidates old live session");
            changed = account.Snapshot(); changed.Server = "Other-Demo";
            Check(!target.Matches(copy, changed), "changing server invalidates old live session");
            Check(!target.Matches(new Instance { Name = copy.Name, Kind = Kind.MT4, Dir = copy.Dir }, account), "changing platform invalidates live identity");
            Check(!target.Matches(new Instance { Name = copy.Name, Kind = Kind.MT5, Dir = copy.Dir + "-new" }, account), "moving copy invalidates live identity");
            Check(target.SnapshotPath == Path.Combine(copy.Dir, "MQL5", "Files", "MetaFactoryLive", target.Token, "snapshot.txt"), "live reader uses only dedicated per-session sandbox file");
            string saved = AppPaths.DataDirOverride;
            try
            {
                AppPaths.DataDirOverride = Dir("live-settings");
                target.Guide = "Attach only on a new chart.";
                LiveMonitorStore.Save(new[] { target }); string problem;
                var loaded = LiveMonitorStore.Load(out problem);
                Check(problem == null && loaded.Count == 1 && loaded[0].Token == target.Token && loaded[0].Matches(copy, account) && loaded[0].Guide == target.Guide, "live identity and token survive restart without auto-enabling monitoring");
                string json = File.ReadAllText(LiveMonitorStore.FilePath);
                Check(!json.Contains("Enabled") && !json.Contains("Investor") && !json.Contains("Password") && !json.Contains("Master"), "live settings contain neither activation nor credentials");
                File.WriteAllText(LiveMonitorStore.FilePath, "broken json");
                Check(LiveMonitorStore.Load(out problem).Count == 0 && problem != null, "corrupt live settings fail closed with explicit prepare-again message");
                var bad = target.Snapshot(); bad.Token = "../escape";
                bool rejected = false; try { LiveMonitorStore.Save(new[] { bad }); } catch (InvalidDataException) { rejected = true; }
                Check(rejected, "live settings reject a token containing path traversal");
                rejected = false; try { LiveMonitorStore.Save(new[] { target, target }); } catch (InvalidDataException) { rejected = true; }
                Check(rejected, "duplicate target identities are not persisted");
            }
            finally { AppPaths.DataDirOverride = saved; }
            var expiring = new LiveMonitorView { State = "Live", Balance = "100", Equity = "101", Floating = "1", NoSl = "0", Today = "2", Drawdown = "3%", LiveUntilUtc = DateTime.UtcNow.AddSeconds(-1) };
            var expired = expiring.VisibleAt(DateTime.UtcNow);
            Check(expired.Balance == "—" && expired.Equity == "—" && expired.Floating == "—" && expired.Today == "—" && expiring.Balance == "100", "UI independently expires old values even if a background file read stalls, without mutating the worker snapshot");
            var candidates = new List<LiveMonitorCandidate> { new LiveMonitorCandidate { Copy = copy, Account = account } };
            var configured = new List<LiveMonitorTarget> { target };
            int reads = 0;
            using (var controller = new LiveMonitorController(() => new HashSet<string>(StringComparer.OrdinalIgnoreCase), (t, now, cancelled) => { Interlocked.Increment(ref reads); return null; }))
            {
                controller.Poll(configured, candidates); Thread.Sleep(20);
                Check(!controller.Enabled && reads == 0 && controller.Snapshot().Count == 0, "live controller starts disabled and reads nothing before explicit opt-in");
                controller.Enable(true); controller.Poll(configured, candidates);
                Check(SpinWait.SpinUntil(() => !controller.Polling, 2000), "closed-terminal live poll completes promptly");
                Check(reads == 0 && controller.Snapshot().Count == 1 && controller.Snapshot()[0].Balance == "—", "closed terminals are never read or shown with stale numeric values");
                controller.Enable(false); Check(controller.Snapshot().Count == 0, "disabling live monitoring immediately clears displayed live data");
            }
            using (var started = new ManualResetEvent(false))
            using (var release = new ManualResetEvent(false))
            using (var controller = new LiveMonitorController(() => new HashSet<string>(new[] { copy.Exe }, StringComparer.OrdinalIgnoreCase), (t, now, cancelled) => {
                Interlocked.Increment(ref reads); started.Set(); release.WaitOne(2000); return null;
            }))
            {
                reads = 0; controller.Enable(true); controller.Poll(configured, candidates);
                Check(started.WaitOne(2000), "live poll runs on a background worker");
                controller.Poll(configured, candidates); Check(reads == 1, "slow live reads cannot overlap another polling worker");
                controller.Enable(false); controller.Enable(true); release.Set();
                Check(SpinWait.SpinUntil(() => !controller.Polling, 2000), "cancelled live worker finishes without blocking UI shutdown");
                Check(controller.Snapshot().Count == 0, "old-generation worker cannot republish data after disable/re-enable");
                controller.Poll(configured, new List<LiveMonitorCandidate> { new LiveMonitorCandidate { Copy = copy, Account = changed } });
                Check(SpinWait.SpinUntil(() => !controller.Polling, 2000), "identity-mismatch poll finishes");
                Check(reads == 1 && controller.Snapshot()[0].Balance == "—", "account identity change blocks stale session before any file read");
            }
        }
    }
}
