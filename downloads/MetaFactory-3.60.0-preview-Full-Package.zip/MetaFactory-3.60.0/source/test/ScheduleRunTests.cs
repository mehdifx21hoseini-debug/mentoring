using System;
using System.IO;

namespace MTManager
{
    static partial class Tests
    {
        static void ScheduleRunChecks()
        {
            var now = new DateTime(2026, 11, 20, 22, 0, 0);
            var options = new ScheduleOptions { Enabled = true, Time = "22:00" };
            string path = Path.Combine(Dir("schedule-ledger"), "state.json");
            var ledger = new ScheduleLedger(path);
            Check(!ledger.Due(options, now.AddSeconds(-1)) && ledger.Due(options, now), "daily schedule reaches exact local minute");
            Check(ledger.Due(options, now.AddHours(1)), "same-day missed schedule catches up after opening");
            options.Enabled = false; Check(!ledger.Due(options, now), "disabled scheduler never runs"); options.Enabled = true;
            Check(!ScheduleLedger.TimeReached("24:00", now) && !ScheduleLedger.TimeReached("bad", now), "invalid clock fails closed");
            ledger.Begin(options, now, now.ToUniversalTime());
            Check(File.Exists(path) && !ledger.Due(options, now.AddHours(1)), "claim persisted before work prevents duplicate same-day run");
            var restarted = new ScheduleLedger(path);
            Check(restarted.State.Phase == "interrupted" && !restarted.Due(options, now), "restart during read marks interrupted and does not rerun");
            restarted.Set("sending", "pending"); restarted = new ScheduleLedger(path);
            Check(restarted.State.Phase == "interrupted" && !restarted.Due(options, now), "uncertain delivery after crash is not automatically resent");
            Check(!restarted.Due(options, now.AddHours(-1)) && !restarted.Due(options, now.AddDays(-1)), "clock rollback/DST repeated hour cannot duplicate run");
            Check(restarted.Due(options, now.AddDays(1)), "next local date gets one new scheduled run");
            restarted.Begin(options, now.AddDays(1), now.ToUniversalTime().AddDays(1)); restarted.Set("delivery-failed", "failure");
            Check(!restarted.Due(options, now.AddDays(1).AddHours(1)), "failed external send is not silently retried");
            File.WriteAllText(path, "invalid-json"); var broken = new ScheduleLedger(path);
            Check(broken.Error != null && !broken.Due(options, now.AddDays(3)), "corrupt ledger fails closed rather than resending");
            string manualPath = Path.Combine(Dir("schedule-manual"), "state.json"); var early = new ScheduleLedger(manualPath);
            early.Begin(options, now.AddHours(-2), now.ToUniversalTime().AddHours(-2)); early.Set("sent", "ok");
            Check(early.Due(options, now), "explicit early manual run does not cancel night's scheduled report");
            early.Begin(options, now, now.ToUniversalTime()); early.Set("sent", "ok");
            Check(!early.Due(options, now.AddMinutes(1)), "manual send after due time satisfies today's scheduled run");
        }
    }
}
