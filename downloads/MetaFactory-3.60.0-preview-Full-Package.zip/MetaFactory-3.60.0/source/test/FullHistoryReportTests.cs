using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace MTManager
{
    static partial class Tests
    {
        static string FullReportProof(string platform, string token, string login)
        {
            DateTime day = new DateTime(2026, 11, 10);
            string first = (long.Parse(JournalFile.Unix(day.AddDays(-20)), CultureInfo.InvariantCulture) * 1000).ToString(CultureInfo.InvariantCulture);
            string second = (long.Parse(JournalFile.Unix(day.AddDays(-19)), CultureInfo.InvariantCulture) * 1000).ToString(CultureInfo.InvariantCulture);
            return "MTR\t2\t" + platform + "\t6000\t" + (platform == "MT4" ? "1.23" : "1.25") + "\nQ\t" + token
                + "\nA\t" + login + "\tTest-Demo\tUSD\t90\t90\t" + JournalFile.Unix(day.AddHours(12)) + "\t" + JournalFile.Unix(day)
                + "\nH\t1\t90\t90\nM\ttrades-only\nJ\t" + first + "\t1\t2\t100\nJ\t" + second
                + "\t2\t0\t-10\nJC\t1\t2\t90\t90\t1\t1\t1\t0\nEND\t2\n";
        }

        static void FullHistoryReportChecks()
        {
            DateTime day = new DateTime(2026, 11, 10); string token = new string('9', 32);
            string file = Path.Combine(root, "full-history-report-proof.txt");
            foreach (string platform in new[] { "MT4", "MT5" })
            {
                var account = new Account { Login = "991199", Server = "Test-Demo", Platform = platform };
                string good = FullReportProof(platform, token, account.Login);
                Func<string, ReportRunner.Outcome> read = raw => { File.WriteAllText(file, raw); return ReportRunner.ReadOutput(file, account, day, token); };
                var accepted = read(good);
                Check(accepted != null && accepted.Journal != null && accepted.Journal.FullHistoryValid && accepted.Journal.FullHistory.Count == 2,
                    platform + " fresh acceptance requires a reconciled full chronology outside the selected trade window");
                Check(ReportRunner.ReadOutput(file, account, day, new string('8', 32)) == null, platform + " old request token cannot satisfy full report");
                account.Platform = platform == "MT4" ? "MT5" : "MT4";
                Check(read(good).Journal == null, platform + " same login and server on another requested platform is rejected");
                account.Platform = ""; Check(read(good).Journal != null, platform + " legacy account without stored platform accepts exact current reporter proof"); account.Platform = platform;
                Check(read(good.Replace("\t991199\t", "\t991198\t")).Journal == null, platform + " another account's full proof is rejected");
                Check(read(good.Replace("Test-Demo", "Other-Demo")).Journal == null, platform + " another server's full proof is rejected");
                Check(read(good.Replace(platform == "MT4" ? "1.23" : "1.25", platform == "MT4" ? "1.22" : "1.24")).Journal == null,
                    platform + " previous reporter cannot claim current full-history freshness");
                foreach (string invalid in new[] {
                    good.Replace("\t90\t90\t1\t1\t1\t0", "\t90\t90\t0\t1\t1\t0"),
                    good.Replace("\t90\t90\t1\t1\t1\t0", "\t90\t90\t1\t0\t1\t0"),
                    good.Replace("\t90\t90\t1\t1\t1\t0", "\t90\t90\t1\t1\t0\t0"),
                    good.Replace("\t2\t0\t-10", "\t2\t0\tNaN"),
                    good.Replace("JC\t1\t2\t90\t90\t1\t1\t1\t0\n", ""),
                    good.Replace("END\t2\n", "END\t3\n"),
                    good.Replace("END\t2\n", "") })
                {
                    var rejected = read(invalid);
                    Check(rejected != null && rejected.Journal == null && rejected.Transient && rejected.Code == "history-full-unconfirmed",
                        platform + " missing, incomplete or unreconciled curve is retryable and never accepted as fresh");
                }
                var legacyLines = good.Split('\n').Where(l => !l.StartsWith("J\t", StringComparison.Ordinal) && !l.StartsWith("JC\t", StringComparison.Ordinal));
                string windowOnly = string.Join("\n", legacyLines).Replace("END\t2", "END\t0");
                Check(read(windowOnly).Transient && read(windowOnly).Journal == null, platform + " window-only output cannot masquerade as full current history");
                File.WriteAllText(file, windowOnly.Replace(platform == "MT4" ? "1.23" : "1.25", "1.20"));
                Check(ReportRunner.ReadOutput(file, account, day).Journal != null, platform + " no-token legacy parser remains compatible with old saved reports");
                string persisted = JournalFile.Write(accepted.Journal); File.WriteAllText(file, persisted);
                Check(!persisted.Contains("Q\t") && ReportRunner.ReadOutput(file, account, day, token) == null,
                    platform + " cached full-history proof loses live request token and cannot be replayed as fresh");
                string empty = "MTR\t2\t" + platform + "\t6000\t" + (platform == "MT4" ? "1.23" : "1.25") + "\nQ\t" + token
                    + "\nA\t991199\tTest-Demo\tUSD\t0\t0\t" + JournalFile.Unix(day.AddHours(1)) + "\t" + JournalFile.Unix(day)
                    + "\nH\t1\t0\t0\nM\ttrades-only\nJC\t1\t0\t0\t0\t1\t1\t1\t0\nEND\t0\n";
                Check(read(empty).Journal != null, platform + " explicitly proven empty zero account is distinct from missing history");
            }
            var settings = new Settings { BaseDir = Dir("full-history-deferred") };
            var jobs = new List<ReportJob>();
            foreach (string name in new[] { "recover", "good", "incomplete" })
                jobs.Add(new ReportJob { Index = jobs.Count, Name = name, Copy = new Instance { Name = name, Kind = Kind.MT4, Dir = settings.BaseDir }, Account = new Account { Login = (100 + jobs.Count).ToString(), Server = "Test-Demo", Platform = "MT4" } });
            var sequence = new List<string>();
            var runner = new ReportRunner(settings, jobs, new List<Instance>(), name => null, new ReportRange { From = day, To = day.AddDays(1) }, 1,
                (job, slot) => {
                    sequence.Add(job.Name + ":" + job.Attempt);
                    string raw = FullReportProof("MT4", token, job.Account.Login);
                    if (job.Name == "incomplete" || job.Name == "recover" && job.Attempt == 1) raw = raw.Replace("\t90\t90\t1\t1\t1\t0", "\t90\t90\t1\t0\t1\t0");
                    File.WriteAllText(file, raw); var result = ReportRunner.ReadOutput(file, job.Account, day, token);
                    return new ReportRow { Copy = job.Copy.Name, Journal = result.Journal, Error = result.Journal == null ? result.Long : null, FailureCode = result.Code, Retryable = result.Transient };
                });
            var rows = runner.Run();
            Equal("recover:1,good:1,incomplete:1,recover:2,incomplete:2", string.Join(",", sequence), "full history failures defer once behind other first-pass accounts");
            Check(rows[0].Journal != null && rows[0].Attempts == 2 && rows[1].Attempts == 1, "full history recovery accepts only validated second-pass output");
            Check(rows[2].Journal == null && rows[2].Attempts == 2 && rows[2].FailureCode == "history-full-unconfirmed", "permanently incomplete history stops after the bounded deferred attempt without false success");
        }
    }
}
