using System;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Linq;
using System.Collections.Generic;
namespace MTManager { static partial class Tests {
static void Check(bool ok,string what){if(!ok)throw new Exception(what);}
static void Equal<T>(T e,T a,string what){Check(EqualityComparer<T>.Default.Equals(e,a),what);}
static string root;
static string Dir(params string[] parts){string d=root;foreach(string p in parts)d=Path.Combine(d,p);Directory.CreateDirectory(d);return d;}
static int Main(){root=Path.Combine(Path.GetTempPath(),"live-bench-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);try{return Run();}finally{Directory.Delete(root,true);}}
static int Run(){
 const int count=50, rounds=20;DateTime now=DateTime.UtcNow;now=now.AddTicks(-(now.Ticks%TimeSpan.TicksPerSecond));
 string token=new string('a',32);long epoch=(long)(now-new DateTime(1970,1,1,0,0,0,DateTimeKind.Utc)).TotalSeconds;
 var readers=new List<LiveFeedReader>();var summaries=new List<LiveReportSummaryCache>();var dirs=new List<string>();
 for(int i=0;i<count;i++){
 string dir=Dir(i.ToString());dirs.Add(dir);var j=LiveAccuracyHistory(now.AddHours(2));j.Login=(10000+i).ToString();
 var events=new List<JournalBalanceEvent>{DdEvent(1,j.Exported.AddDays(-3),2,1000)};
 for(int n=0;n<1000;n++)events.Add(DdEvent(n+2,j.Exported.AddDays(-2).AddSeconds(n),n%2,n%2==0?-1:1));
 ProveDdCurve(j,events.ToArray());j.Equity=j.Balance+48;
 string baseline=JournalFile.Write(j).Replace("END\t","Q\t"+token+"\r\nLIVE\t1\t"+token+"\trun-"+i+"\t1\r\nEND\t");
 File.WriteAllText(Path.Combine(dir,"history-1.txt"),baseline,Encoding.Unicode);
 readers.Add(new LiveFeedReader(Kind.MT5,j.Login,j.Server,token,dir));summaries.Add(new LiveReportSummaryCache());
 }
 Action<int> publish=round=>{for(int i=0;i<count;i++){
 string snapshot="MLIVE\t1\tMT5\nQ\t"+token+"\nR\trun-"+i+"\t"+(round+1)+"\t"+(epoch+round)+"\nA\t"+(10000+i)+"\tSynthetic-Demo\tUSD\nS\t1\tready\nV\t1000\t1048\t20\t1028\t0\nH\t1\t1\nO\t8\tSYNTH\t0\t1\t"+(epoch-3600)+"\t100\t0\t120\t"+(50+round)+"\t-2\t90\t110\t-3\nEND\t1\n";
 File.WriteAllText(Path.Combine(dirs[i],"snapshot.txt"),snapshot,Encoding.Unicode);
 }};
 var times=new List<double>();for(int round=0;round<rounds;round++){
 publish(round);var timer=Stopwatch.StartNew();for(int i=0;i<count;i++){
 var feed=readers[i].Poll(now.AddSeconds(round));var summary=summaries[i].Update(feed,now.AddSeconds(round));
 Check(feed.Status==LiveFeedStatus.Live && feed.Sequence==round+1 && summary.HistoryReady && summary.FloatingProfitSwap==48+round,"fresh mock feed "+i+" "+feed.Reason);
 }timer.Stop();times.Add(timer.Elapsed.TotalMilliseconds);
 }
 Console.WriteLine("MOCK FILE BENCHMARK ONLY: 50 feeds, 1001 full-history events per feed, 1 live position per feed, 20 updated snapshots.");
 Console.WriteLine("Cold parse+summary all50="+times[0].ToString("0.00")+"ms; warm median="+times.Skip(1).OrderBy(x=>x).ElementAt(9).ToString("0.00")+"ms; warm max="+times.Skip(1).Max().ToString("0.00")+"ms.");
 Console.WriteLine("DD calculations="+summaries.Sum(x=>x.HistoryCalculations)+" (expected50), no terminals/network/native compiler used.");return 0;
}
}}
