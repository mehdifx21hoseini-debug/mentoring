using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace MTManager
{
    static partial class Tests
    {
        sealed class FakeScheduledTransport : IScheduledDeliveryTransport
        {
            public readonly List<ScheduledDeliveryRequest> Requests = new List<ScheduledDeliveryRequest>();
            public Action<ScheduledDeliveryRequest> Behavior;
            public void Send(ScheduledDeliveryRequest request, Func<bool> cancel)
            { Requests.Add(request); if (Behavior != null) Behavior(request); }
        }
        static ScheduleOptions DeliveryFixture()
        {
            return new ScheduleOptions { Enabled = true, TelegramEnabled = true, BaleEnabled = true, EmailEnabled = true,
                TelegramTokenEnc = Secret.Protect("123456:Telegram_Test_Token_Only"), TelegramChatId = "-100123456789",
                BaleTokenEnc = Secret.Protect("456789:Bale_Test_Token_Only"), BaleChatId = "12345",
                SmtpHost = "smtp.example.invalid", SmtpUser = "local-test", SmtpPasswordEnc = Secret.Protect("Only-a-test-password!"),
                EmailFrom = "sender@example.invalid", EmailTo = "recipient@example.invalid" };
        }
        static void ScheduledDeliveryChecks()
        {
            string previous = AppPaths.DataDirOverride;
            AppPaths.DataDirOverride = Path.Combine(root, "scheduled-delivery-tests");
            try
            {
                var empty = ScheduleStore.Load();
                Check(!empty.Enabled && empty.Time == "22:00" && empty.Platform == "All" && empty.SmtpPort == 587 && empty.SmtpSsl, "new schedule defaults disabled with local22:00 and STARTTLS587");
                Check(!empty.TelegramEnabled && !empty.BaleEnabled && !empty.EmailEnabled, "new schedule never selects recipients implicitly");
                Check(ScheduledDelivery.Validate(empty) != null, "explicit Run now requires a selected delivery channel even when daily timer disabled");
                ScheduleStore.Save(empty); Check(File.Exists(ScheduleStore.FilePath), "disabled unconfigured schedule can be saved without enabling delivery");
                var options = DeliveryFixture(); Equal(null, ScheduledDelivery.Validate(options), "fully specified selected channels validate locally without sending");
                options.Time = "۲۲:۰۰"; options.LoadError = "must not be serialized"; ScheduleStore.Save(options);
                var loaded = ScheduleStore.Load(); string json = File.ReadAllText(ScheduleStore.FilePath);
                Check(loaded.Enabled && loaded.Time == "22:00" && loaded.TelegramChatId == options.TelegramChatId, "schedule persistence normalizes digits and restores selected destinations");
                Equal(options.TelegramTokenEnc, loaded.TelegramTokenEnc, "schedule store preserves DPAPI ciphertext exactly");
                Check(!json.Contains("Telegram_Test_Token_Only") && !json.Contains("Bale_Test_Token_Only") && !json.Contains("Only-a-test-password!") && !json.Contains("LoadError"), "schedule JSON excludes plaintext secrets and runtime error messages");
                Check(ScheduleStore.FilePath != AppPaths.SettingsFile && !Directory.GetFiles(AppPaths.DataDir, "*.new").Any(), "schedule lives outside portable settings and atomic save leaves no temporary file");
                Check(Secret.Unprotect(loaded.SmtpPasswordEnc) == "Only-a-test-password!", "saved SMTP secret decrypts for this test user");
                var broken = options.Snapshot(); broken.Time = "24:00"; Check(ScheduledDelivery.Validate(broken) != null, "invalid local clock time is rejected");
                broken = options.Snapshot(); broken.Platform = "MT6"; Check(ScheduledDelivery.Validate(broken) != null, "unsupported platform is rejected");
                broken = options.Snapshot(); broken.TelegramTokenEnc = Secret.Protect("bad/token?redirect=evil"); Check(ScheduledDelivery.Validate(broken) != null, "bot token cannot inject paths or queries");
                broken = options.Snapshot(); broken.BaleChatId = "123\r\nother"; Check(ScheduledDelivery.Validate(broken) != null, "chat identifiers cannot inject multipart headers");
                broken = options.Snapshot(); broken.SmtpHost = "https://smtp.example.invalid"; Check(ScheduledDelivery.Validate(broken) != null, "SMTP expects host rather than arbitrary URI");
                broken = options.Snapshot(); broken.SmtpPort = 465; Check(ScheduledDelivery.Validate(broken) != null, "unsupported implicit TLS is identified before attempting delivery");
                broken = options.Snapshot(); broken.SmtpPort = 70000; Check(ScheduledDelivery.Validate(broken) != null, "invalid SMTP port is rejected");
                broken = options.Snapshot(); broken.EmailTo = "recipient@example.invalid\r\nBcc:other@example.invalid"; Check(ScheduledDelivery.Validate(broken) != null, "recipient header injection is rejected");
                broken = options.Snapshot(); broken.SmtpPasswordEnc = Convert.ToBase64String(new byte[64]); Check(ScheduledDelivery.Validate(broken) != null, "unreadable selected SMTP password prevents automatic setup");
                broken.Enabled = false; ScheduleStore.Save(broken); Check(!ScheduleStore.Load().Enabled, "user can disable a schedule even when its encrypted channel secret became unreadable");
                File.WriteAllText(ScheduleStore.FilePath, "{broken settings, PRIVATE-DATA-TEST}");
                var badLoad = ScheduleStore.Load(); Check(!badLoad.Enabled && badLoad.LoadError != null && !badLoad.LoadError.Contains("PRIVATE-DATA-TEST"), "malformed scheduling JSON fails closed with sanitized error");
                Check(File.ReadAllText(ScheduleStore.FilePath).Contains("PRIVATE-DATA-TEST"), "failed load does not overwrite potentially recoverable settings");
                broken = DeliveryFixture(); broken.TelegramTokenEnc = Convert.ToBase64String(new byte[64]);
                File.WriteAllText(ScheduleStore.FilePath, new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(broken));
                badLoad = ScheduleStore.Load(); Check(!badLoad.Enabled && badLoad.LoadError != null, "enabled but undecryptable configuration is disabled on load");

                Uri telegram = ScheduledDelivery.Endpoint("Telegram", "123456:Test_Only_Token"); Uri bale = ScheduledDelivery.Endpoint("Bale", "123456:Test_Only_Token");
                Check(telegram.Scheme == "https" && telegram.Host == "api.telegram.org" && telegram.AbsolutePath.EndsWith("/sendDocument") && telegram.Query == "", "Telegram upload endpoint is pinned HTTPS sendDocument");
                Check(bale.Scheme == "https" && bale.Host == "tapi.bale.ai" && bale.AbsolutePath.EndsWith("/sendDocument"), "Bale upload uses its fixed HTTPS Bot API endpoint");
                Throws<ArgumentException>(() => ScheduledDelivery.Endpoint("Other", "123456:Test_Only_Token"), "unknown transport cannot supply an arbitrary bot host");
                Check(new[] { 408, 500, 502, 503, 504 }.All(code => ScheduledNetworkTransport.HttpFailure(code).Uncertain), "HTTP timeout/server errors do not falsely claim the provider could not have delivered the report");
                Check(new[] { 301, 400, 401, 403, 429 }.All(code => !ScheduledNetworkTransport.HttpFailure(code).Uncertain), "explicit request rejection remains distinct from uncertain provider outcome");
                Check(ScheduledNetworkTransport.HttpFailure(504).Message.Contains("504"), "uncertain gateway timeout retains safe HTTP status for diagnosis");

                options = DeliveryFixture(); string body = string.Concat(Enumerable.Repeat("گزارش کامل معاملات — full history\r\n", 600));
                var fake = new FakeScheduledTransport(); var outcomes = ScheduledDelivery.Send(options, "Daily\r\nreport", body, () => false, fake);
                Check(outcomes.Count == 3 && outcomes.All(o => o.Success) && fake.Requests.Count == 3, "all three selected channels independently accept through injected transport without real network");
                Check(fake.Requests.All(r => r.Body == body && Encoding.UTF8.GetString(r.Document).TrimStart('\uFEFF') == body), "long Persian report remains complete in UTF8 attachment for every channel");
                Check(fake.Requests.All(r => !r.Subject.Contains("\r") && !r.Subject.Contains("\n")), "subject is a single line for email and captions");
                string multipart = Encoding.UTF8.GetString(ScheduledNetworkTransport.Multipart(fake.Requests[0], "test-boundary"));
                Check(multipart.Contains("name=\"document\"") && multipart.Contains("text/plain; charset=utf-8") && multipart.Contains(body) && multipart.EndsWith("--test-boundary--\r\n"), "bot attachment multipart preserves full report and closes its boundary");
                Check(!multipart.Contains("Telegram_Test_Token_Only"), "bot token is not copied into document or multipart fields");
                var firstFailure = new FakeScheduledTransport { Behavior = request => { if (request.Channel == "Telegram") throw new TimeoutException("sensitive provider URL/Telegram_Test_Token_Only"); } };
                outcomes = ScheduledDelivery.Send(options, "report", body, () => false, firstFailure);
                Check(!outcomes[0].Success && outcomes[0].Uncertain && outcomes.Skip(1).All(o => o.Success), "uncertain first-channel failure does not block other selected channels");
                Equal(1, firstFailure.Requests.Count(r => r.Channel == "Telegram"), "uncertain upload is never automatically retried");
                Check(!outcomes[0].Detail.Contains("Telegram_Test_Token_Only") && !outcomes[0].Detail.Contains("URL"), "unexpected transport exceptions never expose provider URL or tokens");
                var invalidFirst = options.Snapshot(); invalidFirst.TelegramTokenEnc = "unreadable"; fake = new FakeScheduledTransport();
                outcomes = ScheduledDelivery.Send(invalidFirst, "report", body, () => false, fake);
                Check(outcomes.Count == 3 && !outcomes[0].Success && outcomes.Skip(1).All(o => o.Success) && fake.Requests.Count == 2, "one invalid channel does not prevent independently valid destinations");
                fake = new FakeScheduledTransport(); outcomes = ScheduledDelivery.Send(options, "report", body, () => true, fake);
                Check(fake.Requests.Count == 0 && outcomes.All(o => !o.Success && !o.Uncertain), "cancel before delivery makes no transport call");
                bool cancelled = false; fake = new FakeScheduledTransport { Behavior = request => cancelled = true };
                outcomes = ScheduledDelivery.Send(options, "report", body, () => cancelled, fake);
                Check(fake.Requests.Count == 1 && outcomes[0].Success && outcomes.Skip(1).All(o => !o.Success), "cancellation between channels preserves accepted result and skips remaining channels");
                // Capture before mutation to prove that changes during Telegram delivery cannot retarget Email.
                string emailDestination = null; options = DeliveryFixture();
                fake = new FakeScheduledTransport { Behavior = request => { if (request.Channel == "Telegram") options.EmailTo = "changed@example.invalid"; if (request.Channel == "Email") emailDestination = request.Options.EmailTo; } };
                ScheduledDelivery.Send(options, "report", body, () => false, fake);
                Equal("recipient@example.invalid", emailDestination, "recipient configuration is frozen for the entire scheduled run");
                options = DeliveryFixture(); options.Enabled = false; options.BaleEnabled = options.EmailEnabled = false; fake = new FakeScheduledTransport();
                outcomes = ScheduledDelivery.Send(options, "report", body, () => false, fake);
                Check(outcomes.Count == 1 && outcomes[0].Success, "explicit Run now can send configured channel while daily schedule is disabled");
                Check(ScheduledDelivery.TimeoutMilliseconds == 30000, "each network transport has a bounded thirty-second deadline");
            }
            finally { AppPaths.DataDirOverride = previous; }
        }
    }
}
