using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Diagnostics;using System.Reflection;using System.Threading;using System.Windows.Forms;
namespace MTManager {static class StartupQueueUiSmoke {
const BindingFlags F=BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public;static int n;
static object Get(object o,string name){return o.GetType().GetField(name,F).GetValue(o);}static void Set(object o,string name,object value){o.GetType().GetField(name,F).SetValue(o,value);}static object Call(object o,string name,params object[] values){return o.GetType().GetMethod(name,F).Invoke(o,values);}static void Check(bool yes,string text){if(!yes)throw new Exception(text);n++;Console.WriteLine("PASS "+text);}
static void Finish(Form main){for(int i=0;i<250;i++){Application.DoEvents();Thread.Sleep(10);if(!(bool)Get(main,"preparingCopy"))return;}throw new Exception("fake launch did not finish");}
[STAThread]static int Main(){Application.EnableVisualStyles();Theme.Init();Lang.En=true;string root=Path.Combine(Path.GetTempPath(),"fast-start-ui-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=root;Process a=null,b=null;
try{var settings=new Settings{BaseDir=Path.Combine(root,"copies"),AutoStart=false,DelaySeconds=5,LastBackup=DateTime.Now};Directory.CreateDirectory(settings.BaseDir);using(var main=new MainForm(settings,new AccountStore())){
main.Show();for(int i=0;i<5;i++){Application.DoEvents();Thread.Sleep(15);}
foreach(var field in main.GetType().GetFields(F))if(field.FieldType==typeof(System.Windows.Forms.Timer))((System.Windows.Forms.Timer)field.GetValue(main)).Stop();
a=Process.Start(new ProcessStartInfo("/bin/sleep","120"){UseShellExecute=false});b=Process.Start(new ProcessStartInfo("/bin/sleep","120"){UseShellExecute=false});
var one=new Instance{Name="MT5-01",Kind=Kind.MT5,Dir=Path.Combine(root,"one")};var two=new Instance{Name="MT5-02",Kind=Kind.MT5,Dir=Path.Combine(root,"two")};var next=new Instance{Name="MT5-03",Kind=Kind.MT5,Dir=Path.Combine(root,"next")};Directory.CreateDirectory(next.Dir);File.WriteAllBytes(next.Exe,new byte[0]);
Call(main,"TrackMt5Startup",one,new StartResult{Process=a});Call(main,"TrackMt5Startup",two,new StartResult{Process=b});
Set(main,"launchFreeRam",(Func<ulong>)(()=>4096));Set(main,"lastStartAt",DateTime.Now.AddSeconds(-3));Check(!(bool)Call(main,"WaitForStartupSlot",next),"two headless processes cannot impose a ninety-second startup gate");
Set(main,"launchFreeRam",(Func<ulong>)(()=>700));Set(main,"lastStartAt",DateTime.Now.AddSeconds(-5));Check((bool)Call(main,"WaitForStartupSlot",next),"low RAM adds bounded spacing");Set(main,"lastStartAt",DateTime.Now.AddSeconds(-10));Check(!(bool)Call(main,"WaitForStartupSlot",next),"low RAM gap expires at ten seconds without window or CPU readiness");
Set(main,"launchFreeRam",(Func<ulong>)(()=>325));Set(main,"lastStartAt",DateTime.Now.AddSeconds(-15));Check(!(bool)Call(main,"WaitForStartupSlot",next),"critical RAM cannot hold an initializer slot");
Check(!(bool)Call(main,"WaitForStartupSlot",new Instance{Name="MT4-01",Kind=Kind.MT4,Dir=root}),"MT4 pacing unchanged");
for(int i=0;i<30;i++){Set(main,"lastStartAt",DateTime.Now.AddSeconds(-15));Check(!(bool)Call(main,"WaitForStartupSlot",next),"bounded admission "+i);}
Check(!a.HasExited&&!b.HasExited,"slow earlier processes are never killed");
int attempted=0;Set(main,"startTerminal",(Func<Instance,StartResult>)(copy=>{attempted++;return new StartResult();}));var queue=(Queue<Instance>)Get(main,"startQueue");queue.Enqueue(next);Set(main,"pacing",a);Set(main,"lastLaunched",one);Set(main,"lastStartAt",DateTime.Now.AddSeconds(-15));Call(main,"PaceTick");Finish(main);Check(attempted==1&&queue.Count==0,"production PaceTick dispatches after critical-memory gap instead of ninety seconds");
}
Console.WriteLine("STARTUP QUEUE UI PASS "+n);return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}finally{foreach(var process in new[]{a,b})if(process!=null){try{if(!process.HasExited){process.Kill();process.WaitForExit();}process.Dispose();}catch{}}try{Directory.Delete(root,true);}catch{}}}
}}
