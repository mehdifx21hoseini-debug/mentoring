using System;

namespace MTManager
{
    static partial class Tests
    {
        static void SandboxAdmissionChecks()
        {
            Equal(null, ReportRunner.NativeAdmissionProblem(false, true, 70, 32), "disabled automatic routing preserves existing report preflight behavior");
            Equal(null, ReportRunner.NativeAdmissionProblem(true, false, 32, 32), "MT5-only reports do not require an MT4 place");
            Equal(null, ReportRunner.NativeAdmissionProblem(true, true, 28, 32), "28 native terminals leave reserved report places regardless of boxed total");
            Equal(null, ReportRunner.NativeAdmissionProblem(true, true, 31, 32), "one native place admits a report run");
            Check(ReportRunner.NativeAdmissionProblem(true, true, 32, 32) != null, "full native context is explained before a report run starts");
            Check(ReportRunner.NativeAdmissionProblem(true, true, 20, 20) != null, "explicit lower native report setting is respected");
            Check(ReportRunner.NativeAdmissionProblem(true, true, 70, 32) != null, "a count above the boundary is not treated as free capacity");
        }
    }
}
