using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using MTManager;

// Standalone UI integration checks. Never shows MainForm (its Shown event starts real services),
// never invokes a transport, and never launches a terminal.
static class ScheduleIntegrationSmoke
{
    static int checks;
    const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic;
    static FieldInfo Field(object target, string name) { return target.GetType().GetField(name, Private); }
    static void Call(object target, string name, params object[] args)
    { target.GetType().GetMethod(name, Private).Invoke(target, args); }
    static void Check(bool value, string message) { if (!value) throw new Exception(message); checks++; }

    [STAThread] static int Main(string[] args)
    {
        string previous = AppPaths.DataDirOverride;
        string root = Path.Combine(Path.GetTempPath(), "metafactory-schedule-ui-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root); AppPaths.DataDirOverride = root; Lang.En = !args.Contains("fa");
        Application.EnableVisualStyles();
        typeof(Account).Assembly.GetType("MTManager.Theme").GetMethod("Init").Invoke(null, null);
        try
        {
            var settings = new Settings { BaseDir = Path.Combine(root, "copies") };
            Directory.CreateDirectory(settings.BaseDir);
            Type type = typeof(Account).Assembly.GetType("MTManager.MainForm");
            using (var form = (Form)Activator.CreateInstance(type, new object[] { settings, new AccountStore() }))
            {
                Call(form, "InitializeSchedule");
                ((Timer)Field(form, "scheduleTimer").GetValue(form)).Stop();
                var options = (ScheduleOptions)Field(form, "scheduleOptions").GetValue(form);
                Check(!options.Enabled, "New installations do not enable automatic delivery.");
                Check(!options.TelegramEnabled && !options.BaleEnabled && !options.EmailEnabled,
                    "New installations have no enabled destinations.");
                var menu = (ContextMenuStrip)Field(form, "toolsMenu").GetValue(form);
                string[] labels = menu.Items.Cast<ToolStripItem>().Select(i => i.Text).ToArray();
                Check(labels.Any(s => s == (Lang.En ? "Schedule and delivery…" : "زمان‌بندی و ارسال گزارش…")), "Tools exposes schedule configuration.");
                Check(labels.Any(s => s == (Lang.En ? "Read fresh reports and send now" : "گزارش تازه و ارسال به مقصدها اکنون")), "Immediate delivery is an explicit separate command.");
                Check(labels.Any(s => s == (Lang.En ? "Last automated report and delivery…" : "آخرین گزارش و وضعیت ارسال…")), "Tools exposes last delivery status.");

                Type batchType = type.GetNestedType("ScheduledBatch", BindingFlags.NonPublic);
                object batch = Activator.CreateInstance(batchType, true);
                var expected = new Account { Instance = "MT5-test", Login = "123", Server = "Test-Demo", Mode = "investor" };
                batchType.GetField("Accounts").SetValue(batch, new Dictionary<string, Account>(StringComparer.OrdinalIgnoreCase) { { expected.Instance, expected.Snapshot() } });
                Field(form, "scheduledBatch").SetValue(form, batch);
                var journals = (Dictionary<string, AccountJournal>)batchType.GetField("Journals").GetValue(batch);
                var job = new ReportJob { Copy = new Instance { Name = expected.Instance, Kind = Kind.MT5 }, Account = expected.Snapshot() };
                DateTime stamp = new DateTime(2026, 11, 20, 12, 0, 0);
                var fresh = new AccountJournal { Platform = "MT5", Login = "123", Server = "Test-Demo", Currency = "USD", Balance = 1234,
                    Equity = 1234, Exported = stamp, From = stamp.Date, TrustedFrom = stamp.Date, Complete = true, GmtOffset = 0 };
                fresh.Trades.Add(new JournalTrade { Ticket = 1, Symbol = "EURUSD", Open = stamp.AddMinutes(-20), Close = stamp.AddMinutes(-10), Profit = 34 });
                Call(form, "CaptureScheduledJournal", job, new ReportRow { Journal = fresh, Cached = true });
                Check(journals.Count == 0, "Cached journal cannot become scheduled fresh evidence.");
                Call(form, "CaptureScheduledJournal", job, new ReportRow { Journal = fresh, Error = "fixture failure" });
                Check(journals.Count == 0, "Error result cannot become scheduled fresh evidence.");
                Call(form, "CaptureScheduledJournal", job, new ReportRow { Journal = fresh, Cancelled = true });
                Check(journals.Count == 0, "Cancelled result cannot become scheduled fresh evidence.");
                fresh.Complete = false;
                Call(form, "CaptureScheduledJournal", job, new ReportRow { Journal = fresh });
                Check(journals.Count == 0, "Incomplete result cannot become complete by serialization.");
                fresh.Complete = true;
                job.Account.Login = "999";
                Call(form, "CaptureScheduledJournal", job, new ReportRow { Journal = fresh });
                Check(journals.Count == 0, "Changed account credentials cannot enter the frozen scheduled batch.");
                job.Account = expected.Snapshot();
                Call(form, "CaptureScheduledJournal", job, new ReportRow { Journal = fresh });
                Check(journals.Count == 1 && journals[expected.Instance].Balance == 1234,
                    "Fresh result is captured directly without any shared journal cache file.");
                fresh.Balance = 9999; fresh.Trades[0].Profit = 9999;
                Check(journals[expected.Instance].Balance == 1234 && journals[expected.Instance].Trades[0].Profit == 34,
                    "Scheduled journal is a deep snapshot immune to later mutable result changes.");
                var queue = (List<string>)Field(form, "readQueue").GetValue(form);
                queue.Add("scheduled-sentinel");
                Call(form, "Read", new[] { "manual-student" }, null);
                Check(queue.SequenceEqual(new[] { "scheduled-sentinel" }), "Manual Read cannot append to a scheduled batch.");
                var results = (ReportRunSummary)Field(form, "reportResults").GetValue(form);
                Check(results.Total == 0, "Blocked manual Read cannot reset or add result rows.");
                Call(form, "AutoRefreshTick");
                Check(queue.SequenceEqual(new[] { "scheduled-sentinel" }), "Folder auto refresh cannot contaminate a scheduled batch.");
                Check(!(bool)type.GetProperty("ScheduleIdle", Private).GetValue(form, null), "Scheduled context blocks a second schedule even before a reader is active.");

                queue.Clear(); results.Begin(); results.StopPending();
                Call(form, "CompleteScheduledReport");
                var ledger = (ScheduleLedger)Field(form, "scheduleLedger").GetValue(form);
                Check(ledger.State.Phase == "stopped", "Cancellation is persisted before any delivery.");
                Check(Field(form, "scheduledBatch").GetValue(form) == null, "Stopped schedule releases its batch context.");
                Check(!File.Exists(Path.Combine(root, "scheduled-last-report.txt")), "Stopped batch does not write a sendable report.");
                Check(!Directory.EnumerateFileSystemEntries(settings.BaseDir).Any(), "Integration checks did not provision or launch a terminal.");
                ((Timer)Field(form, "scheduleTimer").GetValue(form)).Stop();
            }
            Console.WriteLine("Schedule integration smoke: " + checks + " checks passed (no network or terminal).");
            return 0;
        }
        catch (Exception e) { Console.Error.WriteLine(e); return 1; }
        finally { AppPaths.DataDirOverride = previous; try { Directory.Delete(root, true); } catch { } }
    }
}
