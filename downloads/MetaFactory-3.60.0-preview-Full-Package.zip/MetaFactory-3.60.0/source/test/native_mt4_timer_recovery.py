from pathlib import Path
import subprocess
s=(Path(__file__).resolve().parents[1]/'report'/'MTManagerLive.mq4').read_text()
def function(name):
 start=s.index(name); opening=s.index('{',start);level=1;end=opening+1
 while level:
  if s[end]=='{':level+=1
  elif s[end]=='}':level-=1
  end+=1
 return s[start:end]
code='''#include <cstdint>
#include <cassert>
#include <iostream>
using uint=unsigned int;
uint clockNow=0,timerRetryAt=0,fallbackPollAt=0,retryInitAt=0;
bool timerActive=false,fallbackPolled=false,timerResult=false;
int attempts=0,pumps=0,starts=0;
const int INIT_SUCCEEDED=0,TERMINAL_DATA_PATH=1;
template<typename... A>void Print(A... a){}
const char* TerminalInfoString(int){return "mock";}
void ResetLastError(){} int GetLastError(){return 4024;}
uint GetTickCount(){return clockNow;}
bool EventSetTimer(int seconds){assert(seconds==1);attempts++;return timerResult;}
bool BeginLiveSession(){starts++;return true;}
bool InitProblem(const char*,int error=0){return false;}
void OnTimer(){pumps++;}
'''+function('int OnInit()')+'\n'+function('void OnTick()')+'''
int main(){
assert(OnInit()==INIT_SUCCEEDED && starts==1 && !timerActive); // failure retains EA
OnTick();assert(pumps==1 && attempts==1); // no busy retry
clockNow=500;OnTick();assert(pumps==1);
clockNow=1000;OnTick();assert(pumps==2);
clockNow=5000;OnTick();assert(attempts==2 && pumps==3 && !timerActive);
clockNow=10000;timerResult=true;OnTick();assert(timerActive && pumps==4 && attempts==3);
clockNow=10500;OnTick();assert(pumps==4 && attempts==3);
timerActive=false;timerRetryAt=0xfffffff0u;clockNow=6000;OnTick();assert(timerActive); // tick wrap
std::cout<<"MT4 extracted lifecycle: 8 checks passed (mock, not MetaEditor)\\n";
}
'''
Path('/tmp/mt4_timer_recovery.cpp').write_text(code)
subprocess.run(['g++','-std=c++11','/tmp/mt4_timer_recovery.cpp','-o','/tmp/mt4_timer_recovery'],check=True)
subprocess.run(['/tmp/mt4_timer_recovery'],check=True)
