class TestFile { static void Main() { } }
