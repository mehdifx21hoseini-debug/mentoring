using System;using System.IO;using System.Linq;using System.Text;using System.Diagnostics;using System.Reflection;using System.Threading;
namespace MTManager {static partial class Tests {
static void LaunchComparisonChecks()
{
    var originalHook=Launcher.PrepareLiveManual;var store=new AccountStore();var settings=new Settings{BaseDir=Dir("launch-ab"),AutoStart=false};
    Check(settings.ManualLiveReports,"existing installs default to live manual launch");
    string settingsPath=AppPaths.SettingsFile; // Save/Load isolated test data directory.
    string previous=File.Exists(settingsPath)?File.ReadAllText(settingsPath):null;
    try{settings.ManualLiveReports=false;settings.Save();Check(!Settings.Load().ManualLiveReports,"ordinary mode survives restart");settings.ManualLiveReports=true;settings.Save();Check(Settings.Load().ManualLiveReports,"live mode survives restart");}
    finally{if(previous==null)File.Delete(settingsPath);else File.WriteAllText(settingsPath,previous);}
    try{
        int calls=0;Launcher.PrepareLiveManual=(i,s,a)=>{calls++;return new System.Collections.Generic.List<string>{"Expert=sentinel"};};
        foreach(Kind kind in new[]{Kind.MT4,Kind.MT5}){
            string name=kind+"-AB";var copy=new Instance{Name=name,Kind=kind,Dir=Dir("launch-ab/"+name)};var account=new Account{Instance=name,Platform=kind.ToString(),Login="12345",Server="AB-Demo",InvestorEnc=""};store.Set(account);
            string rootCharts=kind==Kind.MT4?Path.Combine(copy.Dir,"profiles"):Path.Combine(copy.Dir,"MQL5","Profiles","Charts");
            string own=Path.Combine(rootCharts,"Default");Directory.CreateDirectory(own);string chart=Path.Combine(own,"original.chr");File.WriteAllText(chart,"<chart>\r\n<expert>\r\nname=MF_Live_0123456789ab_0123456789ab\r\n</expert>\r\n</chart>");byte[] original=File.ReadAllBytes(chart);
            settings.ManualLiveReports=false;int before=calls;Check(Launcher.PrepareManualLines(copy,settings,account,true)==null && calls==before,"ordinary bypasses live preparer/compiler/symbol helper "+kind);
            string plain=Path.Combine(rootCharts,PlainLaunch.ProfileName);Check(Directory.Exists(plain)&&!Directory.EnumerateFileSystemEntries(plain).Any(),"plain selected profile starts empty "+kind);
            Check(original.SequenceEqual(File.ReadAllBytes(chart)),"saved observer chart remains byte identical "+kind);
            if(kind==Kind.MT4)Equal(PlainLaunch.ProfileName,File.ReadAllText(Path.Combine(rootCharts,"lastprofile.ini")),"MT4 selects isolated profile");
            string saved=Path.Combine(plain,"saved.chr");File.WriteAllText(saved,"saved chart with arbitrary EA");PlainLaunch.PrepareProfile(copy);Check(!File.Exists(saved)&&Directory.GetFiles(Path.Combine(copy.Dir,"MTManager-backup","plain-launch"),"saved.chr",SearchOption.AllDirectories).Length==1,"charts saved during ordinary run are backed up, not loaded or deleted "+kind);
            var start=Launcher.WriteStartFile(copy,settings,store,true,true);string text=File.ReadAllText(start.StartFile,kind==Kind.MT5?Encoding.Unicode:Encoding.Default);
            Check(text.Contains("Login=12345")&&text.Contains("Server=AB-Demo"),"ordinary config retains account login "+kind);
            if(kind==Kind.MT5)Check(text.Contains("ProfileLast="+PlainLaunch.ProfileName)&&!text.Contains("ProfileLast="+Launcher.LiveMt5ProfileName),"MT5 never selects live profile in ordinary mode");
            Check(start.WaitForConfigRead,"ordinary credentials retain delayed-read protection "+kind);Launcher.DeleteStartFile(start.StartFile);
            var startup=PlainLaunch.StartupLines(kind);Check(startup.Contains("Expert=") && startup.Contains("Script=")&&!startup.Any(l=>l.StartsWith("Symbol=")),"plain startup neither attaches expert nor creates symbol chart "+kind);
            settings.ManualLiveReports=true;var lines=Launcher.PrepareManualLines(copy,settings,account,true);Check(calls==before+1&&lines[0]=="Expert=sentinel","live mode calls unchanged preparer "+kind);
            int last=calls;Check(Launcher.PrepareManualLines(copy,settings,account,false)==null&&calls==last,"non-manual report launches ignore manual mode "+kind);
        }
        var sample=new Instance{Name="MT5-ab-resource",Kind=Kind.MT5,Dir=Dir("launch-ab/resource")};settings.ManualLiveReports=false;
        LaunchComparison.Begin(false,new[]{sample},settings,store,0);LaunchComparison.Preparing(sample);LaunchComparison.Prepared(sample);
        if(File.Exists("/bin/sleep"))using(var child=Process.Start(new ProcessStartInfo("/bin/sleep","4"){UseShellExecute=false})){
            LaunchComparison.Started(sample,child);Check(LaunchComparison.IsPlain(sample.Name),"ordinary PID is excluded from live controller");
            LaunchComparison.Observe(child,sample.Name,new LaunchCapacityDiagnostics.ResourceSnapshot{AvailablePhysicalMb=777},false,10*1048576,20*1048576);
            string summary=LaunchComparison.Summary();Check(summary.Contains("mode=plain")&&summary.Contains("verified-live-after-launch-return-ms=N/A"),"plain readiness is N/A rather than fabricated live");
            Check(summary.Contains("sampled-peak-private-mb=10")&&summary.Contains("min-free-mb=777"),"measured resource samples are attributed to run");
            Check(summary.Contains("window-after-launch-return-ms=unknown"),"headless process is not a ready window");
            Check(!File.ReadAllText(LaunchComparison.FilePath).Contains("12345")&&!File.ReadAllText(LaunchComparison.FilePath).Contains("Password="),"comparison persistence excludes account IDs and passwords");
            child.WaitForExit();LaunchComparison.Observe(child,sample.Name,new LaunchCapacityDiagnostics.ResourceSnapshot(),true,-1,-1);Check(!LaunchComparison.IsPlain(sample.Name),"exited ordinary PID no longer suppresses live");
        }
        LaunchComparison.Begin(true,new[]{sample},settings,store,1);LaunchComparison.Preparing(sample);LaunchComparison.Failure(sample.Name,new Exception("password=secret"));
        string pair=LaunchComparison.Summary();Check(pair.Contains("MISMATCH")&&!pair.Contains("password=secret"),"mismatched starting conditions flagged, exception text excluded");
        Check(pair.Contains("Window is first observed HWND, NOT proof of broker connection"),"diagnostics separate window from connection proof");
    }finally{Launcher.PrepareLiveManual=originalHook;}
}
}}
