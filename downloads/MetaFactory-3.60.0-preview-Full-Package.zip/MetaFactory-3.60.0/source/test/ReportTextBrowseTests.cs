using System;
using System.Collections.Generic;
using System.Linq;

namespace MTManager
{
    static partial class Tests
    {
        static void ReportTextBrowseChecks()
        {
            var entries = new List<TextEntry>
            {
                new TextEntry { Number = 17, Name = "علی کریمی", Login = "001234", View = new PanelView { ReturnPct = 5 } },
                new TextEntry { Number = 2, Name = "BETA student", Login = "8002", View = new PanelView { ReturnPct = -2 } },
                new TextEntry { Number = 9, Name = "Unread", Login = "8003", View = null },
                new TextEntry { Number = 4, Name = "No balance", Login = "8004", View = new PanelView { ReturnPct = double.NaN } },
                new TextEntry { Number = 6, Name = "Cedar", Login = "8005", View = new PanelView { ReturnPct = 5 } },
                new TextEntry { Number = 1, Name = "Overflow", Login = "8006", View = new PanelView { ReturnPct = double.PositiveInfinity } },
                new TextEntry { Number = 8, Name = "Zero", Login = "8007", View = new PanelView { ReturnPct = 0 } },
            };
            Check(ReportTextBrowse.Indices(entries, "", 0).SequenceEqual(Enumerable.Range(0, 7)), "report text default retains source order and selected student identities");
            Check(ReportTextBrowse.Indices(entries, "علي كريمي", 0).SequenceEqual(new[] { 0 }), "report search recognizes Arabic/Persian name variants");
            Check(ReportTextBrowse.Indices(entries, "۰۰۱۲۳۴", 0).SequenceEqual(new[] { 0 }), "report search recognizes Persian account digits and leading zeros");
            Check(ReportTextBrowse.Indices(entries, "٨٠٠٢", 0).SequenceEqual(new[] { 1 }), "report search recognizes Arabic account digits");
            Check(ReportTextBrowse.Indices(entries, " beta  8002 ", 0).SequenceEqual(new[] { 1 }), "report search combines name/account terms case-insensitively");
            Equal(0, ReportTextBrowse.Indices(entries, "missing account", 0).Count, "report search no-match result stays empty");
            Check(ReportTextBrowse.Indices(entries, "", 1).SequenceEqual(new[] { 0, 4, 6, 1, 2, 3, 5 }), "return descending sorts finite values, stabilizes ties, puts all unknowns last");
            Check(ReportTextBrowse.Indices(entries, "", 2).SequenceEqual(new[] { 1, 6, 0, 4, 2, 3, 5 }), "return ascending puts negative/zero/positive values first and unknowns last");
            Check(ReportTextBrowse.Indices(entries, "800", 1).SequenceEqual(new[] { 4, 6, 1, 2, 3, 5 }), "filter and return sort compose over the same entries");
            Equal(17, entries[0].Number, "filtering and sorting do not renumber original report entries");
            Equal("001234", entries[0].Login, "filtering does not alter account data");
            var chosen = new HashSet<int> { 0, 1, 4 };
            var filtered = ReportTextBrowse.Indices(entries, "800", 2).Where(chosen.Contains).Select(k => entries[k]).ToList();
            Check(filtered.Select(e => e.Number).SequenceEqual(new[] { 2, 6 }), "checked entry identity survives filtering and sorting");
            var range = new ReportRange { From = new DateTime(2026, 11, 20), To = new DateTime(2026, 11, 21) };
            string text = ReportText.Make(range, filtered, TextParts.Name | TextParts.Return);
            Check(text.IndexOf("BETA student", StringComparison.Ordinal) < text.IndexOf("Cedar", StringComparison.Ordinal) && !text.Contains("علی"), "generated output follows filtered selected order without hidden students");
            entries[1].View.ReturnPct = 10;
            Check(ReportTextBrowse.Indices(entries, "", 1).First() == 1, "updated range/return values immediately change sorting");
            Check(ReportTextBrowse.Indices(entries, "", 0).SequenceEqual(Enumerable.Range(0, 7)), "default order restores independently of return updates");
        }
    }
}
