# MetaFactory 3.33.0 preview

- Report batches track actual fresh, failed, cached-only, stopped and remaining accounts, with per-account reasons and attempt counts. Results are available during work and automatically saved without passwords under the existing application data directory, report-runs/. A completed or stopped user batch opens its result window; users can export Excel and retry unread accounts.
- Stop immediately cancels remaining batches and the private report terminals owned by that run. Copy preparation and MetaEditor compilation honor cancellation. Completed reports remain available. A previously cached report is never counted as fresh success.
- Unknown trading history no longer defaults to Active. Report failures override the activity badge with Needs review. Inactive now reads Inactive · 14d; the existing >14 Monday–Friday trading-day rule is unchanged.
- Transient server/script-start failures get exactly one deferred retry after first-pass accounts. Permanent credential failures are not automatically repeated. Report chart symbols also use native installation/AppData symbol history; start detection has a 45-second budget and tries broker-compatible alternative charts.
- Bulk interactive launches check actual available physical RAM before every start, reserve capacity for Windows, and use observed terminal peaks plus headroom. Insufficient/unknown memory, MT4 limits, early process exit or stalled startup stops the remaining queue with counts. Open terminals are not closed. This cannot guarantee any arbitrary count such as 100; Windows desktop heap and broker/platform limits still apply.
- Per-user installer shortcut becomes MetaFactory and recognized MT Manager/MTManager/legacy Persian shortcuts migrate. Internal executable and application-data paths remain compatible.

Validation details and platform limitations are in the bundled release README.
