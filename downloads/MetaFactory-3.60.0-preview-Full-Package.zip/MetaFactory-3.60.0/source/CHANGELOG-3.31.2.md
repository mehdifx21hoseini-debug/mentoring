# MetaFactory 3.31.2 — portable broker-server metadata repair (preview)

## Defect addressed

A normal MetaQuotes installation can authenticate a broker account using server definitions in its Windows-user data folder. A lean `/portable` copy previously took the installation files but omitted those definitions. Selecting a broker by installation-folder name also missed MT4 `.srv` definitions stored only in AppData.

## Change

- Server selection checks exact MT4 server definitions and exact MT5 server directories in both the installation and its `origin.txt`-associated native data folder before broker-folder-name guesses.
- Only broker-network catalog files (`config/*.srv` and `config/servers.dat`) are synchronized from those roots. The active AppData catalog takes precedence over factory defaults.
- Account databases, passwords, proxy/terminal settings, logs, charts and history are not imported by this synchronization. New copy creation also excludes source `config/accounts.*` caches.
- The shared path covers lazy Excel/student copies, verifier copies, ordinary single-student/copy creation, backup restoration and report copies.
- Existing verifier copies refresh during preparation. Existing personal copies refresh before launching, and report copies after their previous owned process is closed. A running personal terminal is left untouched by the refresh wrapper.
- Writes use atomic replacement and retain a one-time endpoint-file backup. Unchanged catalogs are skipped. Linked configuration targets, oversized/unsteady catalogs and cancellation fail without overwriting the old endpoint file. Empty native catalogs cannot replace working target catalogs.
- The live Excel results view, short/deferred check budgets, warm MT5 workers and previous concurrency policy remain in place.

## Validation

1152 logical assertions passed, including 49 new server-transfer/selection/regression assertions for MT4 and MT5. The Persian and English UI suites passed 18 assertions each. One pre-existing chart-retry test is skipped because the Mono test image lacks python3. The Python helper suite has 11 passing tests.

The native broker-server formats are copied byte-for-byte, not reverse engineered. Tests validate selection, copying, priority, privacy boundaries, cancellation and old-copy repair using synthetic endpoint files. They do not authenticate a real Windows broker session or prove that another machine's only cause was missing server metadata. This remains a preview for Windows validation.

## Existing installations

On the same Windows user, connect the installed native MT4/MT5 once to the exact desired broker server and then close it. Install this version, reopen MetaFactory and use Tools → Student connection checks → Retry unsuccessful for previously saved failed accounts. Reimporting the same Excel file is unnecessary and would correctly skip duplicates. No manual AppData copying or journal submission is required for this repair.
