# 3.40.1 — item 10: current-privilege terminal launches

Based on 3.40.0; its unlimited manual opening remains intact. Other deferred requirements remain deferred.

- New NormalTerminalRights setting, ON by default and persisted through settings/backup, with a checkbox in Settings and an entry in system diagnostics.
- TerminalProcessPolicy configures only the child's ProcessStartInfo. It disables shell execution, clears an elevation verb and supplies a process-scoped RunAsInvoker layer while retaining unrelated compatibility flags. No parent/machine environment, registry, ACL, scheduled task, UAC policy or terminal executable is modified.
- Applied to manual terminal launch, MT4/MT5 report terminal launch, MetaEditor report/probe compilation and both IPC helper paths so their child terminals inherit the same policy. Arguments, account files, process window style, input/output pipes, report timing and MQL scripts remain unchanged.
- Turning the setting OFF leaves the previous process-start configuration intact. This setting does not change existing terminals or independent desktop-shortcut launches.

Limits: RunAsInvoker grants no administrator privileges and is not a secure-desktop auto-clicker. An updater explicitly requiring elevation, protected paths, or enterprise policy may still require consent or fail. MetaFactory already running elevated retains its current token. Native Windows/real MT5 AVX2 UAC behavior was not tested in this Linux environment, so universal prompt suppression is not claimed.

Evidence: the supplied 2026-11-16-1407 diagnostic archive contains MT5 LiveUpdate /update executions from per-terminal AppData liveupdate directories. This supports an updater hypothesis but does not prove the precise cause of the latest UAC screenshot.

Validation: 1563 C# checks passed, zero failed (one existing Unix chart test needs python3 inside the Mono container and remains skipped). New checks include real child environment inheritance, unchanged parent environment, preserved compatibility flags/account arguments/minimized state/IPC streams, settings save/load and backup inclusion. 17 manual queue/setting checks per language and 72 existing UI checks per language passed. Installer payload, PE/assembly versions and embedded scripts/probes/runtime matched the built app and source.

See NORMAL-LAUNCH-fa.md for installation, opt-out, update guidance and the remaining Windows verification.
