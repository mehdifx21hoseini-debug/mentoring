# MetaFactory 3.33.1 preview

- Remove the unused Bring back charts set aside command from Tools. Existing chart launch preferences and stored chart backups are preserved.
- Report completion and cancellation retain their fresh/failed/stopped/remaining counts inline above the bottom progress bar. Remove the Results button, latest-results menu and separate results window; there is no automatic popup. Password-free per-account summaries continue to be saved under the existing report-runs application-data folder. The stop button is hidden after the run is finished or cancellation requested.
- Add to folder is directly in the student's context menu. Remove the redundant Folder nesting and Move command from row and multi-selection folder commands. Checkboxes toggle membership independently and update in place, keeping both menus open for successive folder selections. Escape and outside dismissal continue to work.
- Styled submenu placement shares the parent menu edge, prefers the natural reading direction and flips at screen edges, retaining the existing font, colors and renderer.

Validation: 1249 logical checks, 51 UI checks in each of English and Persian, and 11 Python tests passed. UI coverage includes independent multi-folder membership, persistence, submenu adjacency, menu dismissal, and absence of result popups. One pre-existing chart retry test requires python3 inside the Mono image and remains skipped. Built against official .NET Framework 4.5 references; native Windows and live broker behavior were not tested in Linux/Mono.
