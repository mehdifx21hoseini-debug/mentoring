# MetaFactory 3.39.0 — combined verified reporting baselines

Combines the field-tested MT5 3.36.2 path with the MT4 3.37.0 reporting improvements. This release is based on the 3.37.0 source archive; it does not build upon the experimental 3.38 series.

- `ReportMt5.cs` preserves the 3.36.2 cold-report method verbatim except its name. Dispatch sends only MT5 calls to it. The warm-report path, chart selection, startup checks, Python bridge/runtime, and MQL5 reporter remain the 3.36.2 versions.
- The MT4 attempt path and MQL4 reporter remain the 3.37.0 versions. They include measured admission of a second worker and cooperative connection deferral, without interrupting history that has already started.
- The extra constructor resource sample and adaptive worker gating are restricted to MT4-only batches. MT5 and mixed batches preserve their caller-selected 3.36.2 worker count; cold starts still use the existing shared RAM reservations and pacing.
- No experimental 3.38 worker pool, third-worker pilot, persistent IPC attachment, chart-learning change or MQL5 reconnect change is included.

The supplied 14:07 diagnostic establishes 39 fresh MT5 reports out of 39 in 244494 ms with two workers on 3.36.2, including one deferred retry. The 12:56 MT4 diagnostic establishes 59 fresh reports out of 64 on 3.37.0; the user subsequently removed the five failing accounts. These are prior-run observations, not timing or success guarantees for this new combined binary, different accounts, or mixed-platform runs.

`BASELINE-PROVENANCE.json` records verified source and method hashes. Dedicated queue checks verify that MT5 can run the selected two workers without MT4 sampling/promotion requirements, and that mixed batches do not activate the MT4-only pilot. The app keeps the same account/settings schema and installer location.

Validation: 1546 C# checks, 11 baseline Python tests, and 72 UI checks in each of Persian and English passed under Mono/Xvfb. Assembly/PE versions, installer contents and embedded baseline report/runtime sources were verified. One legacy chart retry check was skipped because the Mono container lacks python3; Python tests ran on the host. Native Windows/MetaEditor/broker execution of this combined release has not been tested here.
