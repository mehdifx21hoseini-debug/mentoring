# 3.55.0

Adds a separately configured opt-in Telegram controller with encrypted token storage, explicit numeric report/admin allowlist, private-chat callbacks bound to user/scope/expiry, one-use admin confirmations, scoped command provisioning and webhook preservation. Adds read-only pending-sender discovery with explicit role selection; nobody is auto-enrolled. Manual recipient/range sends reuse the existing selected/current list.

Fresh requests reuse validated live dashboard snapshots after request-time heartbeat checks, or the normal report queue for non-live/missing coverage. Cached, wrong-identity, incomplete/unverified, old/future or clock-unknown results cannot supply fresh financial figures. Existing financial methods and all native sources remain unchanged. Status/diagnostics never include tokens, account passwords, notes or user IDs.

Direct live Telegram verification remains blocked by environment proxy403 to api.telegram.org. Public installer/package contain no supplied token. The user's private .mfbot setup file is distributed separately and requires explicit allowed-user selection/enablement on the Windows PC. Existing daily delivery settings are not replaced.
