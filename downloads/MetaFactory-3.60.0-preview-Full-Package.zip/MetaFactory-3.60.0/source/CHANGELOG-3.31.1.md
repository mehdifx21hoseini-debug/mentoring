# MetaFactory 3.31.1 — Excel checks and faster verification (preview)

- The Excel window stays open after fast registration and displays live queued/checking/connected/failed outcomes, per-row reasons, pause, retry and result export. Closing it deliberately leaves checks running in the background.
- MT5 keeps its owned private terminal and Python helper alive between consecutive accounts on the same server. Each request still requires a new explicit login acknowledgement, matching account/server and a unique attempt token. Account state from a prior login is never accepted as proof.
- MT5 helper uses JSON lines on stdin/stdout; it imports the official runtime once per process, rather than once per student. Credentials are never command-line arguments. IPC detaches after each request while the terminal stays available.
- Reuse stops on timeout, malformed/mismatched response, cancellation, server/platform changes or process exit. Idle MT5 workers release their private processes after five seconds; paused/stopped workers clean them up too.
- MT4 publishes fresh proof before its owned cleanup completes. Cleanup overlaps result persistence/display and is joined before that private terminal is started again. MT4 still needs a new terminal login session for the next account; no official MT5-style login API was introduced or claimed for MT4.
- Connection verification has its own concurrency policy: two workers on machines with at least two processor threads, 6 GB total RAM and 2.5 GB free RAM at startup; one otherwise. The more restrictive trade-history report policy is unchanged.
- First-pass and deferred-check budgets remain bounded. Registration, authentication results and attempts survive restart; failed accounts do not prevent other rows being checked.
- Automatic import result workbooks are updated with final connection outcomes, including after retry.
- MT5 timing logs distinguish warm requests and retained workers, without credentials, so Windows broker measurements can distinguish cold launch from authentication latency.

## Validation boundary

Tests cover queue state, authentication correlation, reused-service request handling and both language versions of the Excel UI using simulated verifiers. Linux/Mono tests do not establish real Windows broker latency, confirm native MetaTrader IPC compatibility or compile MQL4 with MetaEditor. Native Windows validation is still required. This remains a preview; earlier downloads are preserved.
