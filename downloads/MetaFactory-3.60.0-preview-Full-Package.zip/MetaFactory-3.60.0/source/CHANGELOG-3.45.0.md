# MetaFactory 3.45.0 — full-account Relative Drawdown

- Native MT4/MT5 reporters export a compact balance-event timeline over all selected account history independently of the requested day/month detail window. Detailed trade presentation remains incremental.
- Whole-history metadata checks event count, numeric values, account balance reconciliation, stable collection and the all-history request. Incomplete proof is not replaced with a percentage calculated over a shorter window.
- An additional bounded history refresh is attempted only when the history does not reconcile. Fresh report acceptance uses the existing bounded recovery queue for unconfirmed full history.
- Account Relative DD uses chronological realized trading results and initial funding, excluding later external cash movements. Relative percentage and maximum monetary drawdown are tracked independently. This replaces the earlier cash-adjusted, window-dependent BDD.
- Full-history records survive cache serialization and scheduled-report snapshots; each new read replaces the previous full curve. No mixing of curves across reads, servers or platforms.
- Main-row and text-report shorthand is DD; open positions retain O/. Historical equity drawdown is not inferred from realized trades.
- Reporter source hashes and versions invalidate old compiled reporters automatically. The next read compiles the new embedded scripts using the configured MetaEditor.

## Evidence and limits

The supplied private MT4 DetailedStatement was replayed locally: Relative DD 58.67%, maximum monetary drawdown 1299.35. The earlier 34.12% was reproduced from its November window, demonstrating the scope bug. Running the old cash-adjusted algorithm over all events instead gives 70.26%, demonstrating why extending the window alone was insufficient.

Only anonymized reduced numerical regression cases are included in this package. The original statement, trader identity, account number and complete private transaction history are excluded.

The supplied fixture has a single initial deposit and does not establish every broker cash-event convention. MT5 uses its full deal timeline, including fees and partial closes; parity with a native MT5 statement has not been independently established by this MT4 fixture. The metric basis is disclosed in its detail text.

Native all-history selection and balance reconciliation cannot retrieve records a broker no longer supplies. Missing/unconfirmed history is retried within bounded budgets rather than reported as a complete numerical result. No Windows terminal or MetaEditor execution is available in the build environment; native source is checked structurally and is compiled on the user's Windows installation. Live broker verification remains necessary.

Existing scheduling, delivery destinations, terminal launch capacity and Sandboxie behavior are retained.

## Release checks

- 1944 logic/regression checks passed; zero failed. One existing chart-retry test requiring Python inside the Mono container was skipped.
- Report text UI:19 checks each in English/Persian. Scheduling integration:20 checks each in English/Persian; no live network destinations.
- Application/installer assembly and PE versions, exact embedded app payload, native reporter source hashes and unchanged probe/runtime resources verified.
- Full private statement replay against the built application and J/JC serialization independently verifies2651closedtrades/2674balance events; original file is excluded from distribution.
