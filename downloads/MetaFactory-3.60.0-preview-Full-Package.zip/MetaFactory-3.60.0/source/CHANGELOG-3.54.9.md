# 3.54.9

- Compact left-grouped primary commands, preserving the graphite toolbar and existing command behavior.
- Report-text dialog design4: side roster, top range/content groups, preview and copy/save footer. Twelve content flags and search/sort/custom-range behavior preserved.
- Alternating row backgrounds remain white/gray regardless of open/selection/hover state. Existing checkboxes, name hover, accent edge and command states remain.
- Compact question/message dialogs without repeated inner MetaFactory heading.
- Whole-account PF independent of display range. MT4 uses the validated complete closed-order chronology; MT5 uses a new optional PF1 closed-position proof from full-history aggregates, including costs and excluding open/partial positions. Validation reconciles trading net against complete J chronology, rejects malformed/duplicate proof, persists fresh proof through cache merge. Old reporters remain readable but do not supply MT5 overall PF until refreshed with the new exporter.
- MT5 manual reporter1.26, live observer1.06/report protocol1.26. Existing launch/readiness/UAC/account logic, DD formulas and MT4 native sources unchanged.
- Telegram bot commands/token binding are not part of this release. User will supply bot setup next.

Automated model and UI validation available in release records. Native Windows MetaEditor/live MT5 statement parity not run in this Linux environment. Pre-existing MT4-03 primary exit/access issue remains a separate pending native investigation.
