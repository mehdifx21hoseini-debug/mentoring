using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace MTManager
{
    /// <summary>A search box with a magnifier and a gray hint; on the dark band it takes the band's colors.</summary>
    sealed class SearchBox : Panel
    {
        public readonly TextBox Box = new TextBox { BorderStyle = BorderStyle.None };
        readonly string hint;
        readonly Label cue;
        readonly bool dark;
        readonly Color back, line, focusLine, iconColor;

        public SearchBox(string hint, int width, bool dark = false)
        {
            this.hint = hint;
            this.dark = dark;
            back = dark ? Theme.BandField : Theme.Input;
            line = dark ? Theme.BandFieldLine : Theme.BorderStrong;
            focusLine = dark ? Theme.BandPrimary : Theme.Accent;
            iconColor = dark ? Color.FromArgb(0xC8, 0xC8, 0xC8) : Theme.Faint;
            // .NET Framework's TextBox has no placeholder: a gray label over the empty box says what to type.
            cue = new Label { Text = hint, AutoSize = false, UseMnemonic = false, BackColor = back, ForeColor = dark ? Theme.BandFieldText : Theme.Faint, Font = Theme.Font, TextAlign = ContentAlignment.MiddleRight, Cursor = Cursors.IBeam };
            cue.Click += (s, e) => Box.Focus();
            Controls.Add(cue);
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Size = new Size(Theme.S(width), Theme.S(32));
            BackColor = back;
            Box.BackColor = back;
            Box.ForeColor = dark ? Theme.BandText : Theme.Text;
            Box.Font = Theme.Font;
            Box.TextChanged += (s, e) => { cue.Visible = Box.Text.Length == 0; Invalidate(); };
            Box.GotFocus += (s, e) => Invalidate();
            Box.LostFocus += (s, e) => Invalidate();
            Box.KeyDown += (s, e) => { if (e.KeyCode == Keys.Escape && Box.Text.Length > 0) { Box.Text = ""; e.Handled = e.SuppressKeyPress = true; } };
            Controls.Add(Box);
            cue.BringToFront();
            Cursor = Cursors.IBeam;
            Click += (s, e) => Box.Focus();
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            bool rtl = RightToLeft == RightToLeft.Yes;
            int icon = Theme.S(30);
            Box.Width = Width - icon - Theme.S(12);
            Box.Location = new Point(rtl ? Theme.S(10) : icon, (Height - Box.Height) / 2);
            cue.Bounds = new Rectangle(Box.Left, 2, Box.Width, Height - 4);
            cue.TextAlign = rtl ? ContentAlignment.MiddleRight : ContentAlignment.MiddleLeft;
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent == null ? this : Parent));
            bool focused = Box.Focused;
            Theme.Box(g, ClientRectangle, Theme.Sf(dark ? 6 : 4), back, focused ? focusLine : line);
            if (focused && !dark)
                using (var b = new SolidBrush(focusLine)) g.FillRectangle(b, Theme.S(1), Height - Theme.S(2), Width - Theme.S(2), Theme.S(2));
            bool rtl = RightToLeft == RightToLeft.Yes;
            int sz = Theme.S(14);
            float x = rtl ? Width - Theme.S(11) - sz : Theme.S(11), y = (Height - sz) / 2f;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (var pen = new Pen(iconColor, Theme.Sf(1.4f)))
            {
                // The handle points down to the reading start, like Windows 11's search icon.
                g.DrawEllipse(pen, x + sz * 0.3f, y, sz * 0.66f, sz * 0.66f);
                g.DrawLine(pen, x + sz * 0.38f, y + sz * 0.6f, x + sz * 0.05f, y + sz * 0.95f);
            }
        }

        public string Hint { get { return hint; } }
    }

    /// <summary>A text box that lets its owner take Enter, Esc and the arrows before the dialog does (for a drop-down list).</summary>
    sealed class KeyTextBox : TextBox
    {
        public Func<Keys, bool> KeyHook;

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (KeyHook != null && KeyHook(keyData)) return true;
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }

    /// <summary>3.26 (CHANGE-008, approved): the list under a drop-down box, like the menus: a soft frame, a little room around the rows,
    /// a light gray row under the mouse, and an optional line at the bottom (how many there are).</summary>
    sealed class PopFrame : Panel
    {
        public readonly ListBox List;
        string footer = "";

        public PopFrame(ListBox list)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            List = list;
            list.BorderStyle = BorderStyle.None;
            list.Visible = true;
            list.ItemHeight = Theme.S(30);
            BackColor = Theme.Surface;
            Visible = false;
            TabStop = false;
            Controls.Add(list);
        }

        public string Footer
        {
            get { return footer; }
            set { value = value ?? ""; if (value == footer) return; footer = value; PerformLayout(); Invalidate(); }
        }

        int Edge { get { return Theme.S(5); } }
        int FooterHeight { get { return footer.Length > 0 ? Theme.S(28) : 0; } }
        /// <summary>The height besides the rows.</summary>
        public int Extra { get { return 2 * Edge + FooterHeight; } }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            List.Bounds = new Rectangle(Edge, Edge, Math.Max(0, Width - 2 * Edge), Math.Max(0, Height - 2 * Edge - FooterHeight));
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.Surface);
            // A soft outer line and a darker inner one: a light shadow without drawing outside the panel.
            using (var pen = new Pen(Theme.Mix(Theme.Border, Theme.Surface, 0.5f))) g.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
            Theme.Box(g, new Rectangle(1, 1, Width - 3, Height - 3), Theme.Sf(6), Theme.Surface, Theme.Mix(Theme.BorderStrong, Color.White, 0.25f));
            if (FooterHeight > 0)
            {
                int y = Height - Edge - FooterHeight;
                using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, Theme.S(10), y, Width - Theme.S(10), y);
                Theme.Line(g, footer, Theme.Small, new Rectangle(Theme.S(10), y, Width - Theme.S(20), FooterHeight), Theme.Faint, true);
            }
        }

        /// <summary>A row: a rounded light gray fill under the mouse or the keys (like the menus).</summary>
        public static void RowBack(DrawItemEventArgs e, bool sel)
        {
            using (var b = new SolidBrush(Theme.Surface)) e.Graphics.FillRectangle(b, e.Bounds);
            if (!sel) return;
            var r = new Rectangle(e.Bounds.X + 1, e.Bounds.Y + 1, e.Bounds.Width - 2, e.Bounds.Height - 2);
            Theme.Box(e.Graphics, r, Theme.Sf(4), Theme.Mix(Theme.Hover, Color.Black, 0.035f), Color.Transparent);
        }
    }

    /// <summary>A box like a combo box, drawn like the rest of the program (full frame, arrow at the end): the arrow opens a list
    /// under it, choosing fills the box and closes the list. The text can also be typed, e.g. a folder path.</summary>
    sealed class DropBox : Panel, IMessageFilter
    {
        public readonly KeyTextBox Box = new KeyTextBox { RightToLeft = RightToLeft.No, BorderStyle = BorderStyle.None };
        readonly ListBox list = new ListBox { RightToLeft = RightToLeft.No, IntegralHeight = false, BorderStyle = BorderStyle.FixedSingle, DrawMode = DrawMode.OwnerDrawFixed, TabStop = false };
        readonly PopFrame frame;
        public event EventHandler Changed;

        int Arrow { get { return Theme.S(30); } }

        public DropBox(int width)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Surface;
            Size = new Size(Theme.S(width), Theme.FieldHeight + 2 * Theme.FieldRing);
            Box.Font = Theme.Font;
            Box.BackColor = Theme.Input;
            Box.ForeColor = Theme.Text;
            list.Font = Theme.Font;
            frame = new PopFrame(list);
            Controls.Add(Box);
            MouseEnter += (s, e) => Hover();
            MouseLeave += (s, e) => Hover();
            Box.MouseEnter += (s, e) => Hover();
            Box.MouseLeave += (s, e) => Hover();
            Box.TextChanged += (s, e) => { if (Changed != null) Changed(this, EventArgs.Empty); };
            Box.GotFocus += (s, e) => Invalidate();
            Box.LostFocus += (s, e) => { Invalidate(); CloseLater(); };
            Box.KeyHook = Key;
            list.DrawItem += DrawItem;
            list.MouseMove += (s, e) => { int k = list.IndexFromPoint(e.Location); if (k >= 0 && k != list.SelectedIndex) list.SelectedIndex = k; };
            list.MouseClick += (s, e) => { int k = list.IndexFromPoint(e.Location); if (k >= 0) { list.SelectedIndex = k; Pick(); } };
            list.LostFocus += (s, e) => CloseLater();
        }

        public string Value { get { return Box.Text.Trim(); } set { Box.Text = value ?? ""; Box.SelectionStart = Box.Text.Length; } }

        public int Count { get { return list.Items.Count; } }

        bool pickOnly;

        /// <summary>3.26 (CHANGE-011): only one of the listed items, not typed (in place of Windows' own drop-down list); a click
        /// anywhere on the box opens the list.</summary>
        public bool PickOnly
        {
            get { return pickOnly; }
            set
            {
                pickOnly = value;
                Box.ReadOnly = value;
                Box.BackColor = Theme.Input;
                Box.Cursor = value ? Cursors.Hand : Cursors.IBeam;
                Box.RightToLeft = value ? Theme.Dir : RightToLeft.No;
                PerformLayout();
                Cursor = value ? Cursors.Hand : Cursors.Default;
                if (value) Box.MouseDown += (s, e) => { if (IsOpen) Close(); else Open(); };
            }
        }

        /// <summary>The place of the chosen item in the list (-1: none of them).</summary>
        public int SelectedIndex
        {
            get
            {
                for (int k = 0; k < list.Items.Count; k++)
                    if (string.Equals((string)list.Items[k], Value, StringComparison.Ordinal)) return k;
                return -1;
            }
            set { if (value >= 0 && value < list.Items.Count) Value = (string)list.Items[value]; }
        }

        public void SetItems(IEnumerable<string> items)
        {
            list.BeginUpdate();
            list.Items.Clear();
            foreach (string i in items) list.Items.Add(i);
            list.EndUpdate();
            Invalidate();
        }

        public bool IsOpen { get { return frame.Visible; } }

        bool Key(Keys key)
        {
            switch (key)
            {
                case Keys.Alt | Keys.Down:
                case Keys.F4:
                    if (IsOpen) Close(); else Open();
                    return true;
                case Keys.Down:
                    if (!IsOpen) { Open(); return true; }
                    if (list.Items.Count > 0) list.SelectedIndex = Math.Min(list.Items.Count - 1, list.SelectedIndex + 1);
                    return true;
                case Keys.Up:
                    if (IsOpen && list.Items.Count > 0) { list.SelectedIndex = Math.Max(0, list.SelectedIndex - 1); return true; }
                    return false;
                case Keys.Enter:
                    if (!IsOpen) return false;
                    if (list.SelectedIndex >= 0) Pick(); else Close();
                    return true;
                case Keys.Escape:
                    if (!IsOpen) return false;
                    Close();
                    return true;
                case Keys.Tab:
                case Keys.Shift | Keys.Tab:
                    Close();
                    return false;
            }
            return false;
        }

        public void Open()
        {
            Form f = FindForm();
            if (f == null || !Visible || list.Items.Count == 0) return;
            if (frame.Parent != f)
            {
                f.Controls.Add(frame);
                f.Disposed += (s, e) => Application.RemoveMessageFilter(this);
            }
            for (int k = 0; k < list.Items.Count; k++)
                if (string.Equals((string)list.Items[k], Value, StringComparison.OrdinalIgnoreCase)) { list.SelectedIndex = k; break; }
            int ring = Theme.FieldRing;
            Point top = f.PointToClient(PointToScreen(new Point(ring, Height - ring)));
            int h = Math.Max(1, Math.Min(8, list.Items.Count)) * list.ItemHeight + frame.Extra;
            int room = f.ClientSize.Height - top.Y - Theme.S(6);
            if (room < Math.Min(h, list.ItemHeight * 2 + frame.Extra))
            {
                Point above = f.PointToClient(PointToScreen(new Point(ring, ring)));
                h = Math.Min(h, above.Y - Theme.S(6));
                frame.Bounds = new Rectangle(above.X, above.Y - h - Theme.S(2), Width - 2 * ring, h);
            }
            else frame.Bounds = new Rectangle(top.X, top.Y + Theme.S(2), Width - 2 * ring, Math.Min(h, room));
            if (!frame.Visible)
            {
                frame.Visible = true;
                Application.AddMessageFilter(this);
            }
            frame.BringToFront();
            Invalidate();
        }

        public void Close()
        {
            if (!frame.Visible) return;
            frame.Visible = false;
            Application.RemoveMessageFilter(this);
            Invalidate();
        }

        void CloseLater()
        {
            if (!IsHandleCreated) return;
            BeginInvoke((Action)(() => { if (!Box.Focused && !list.Focused) Close(); }));
        }

        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg != 0x201 && m.Msg != 0x204 && m.Msg != 0xA1 && m.Msg != 0xA4) return false;
            Control c = Control.FromHandle(m.HWnd);
            if (c != list && c != frame && c != Box && c != this && IsHandleCreated) BeginInvoke((Action)Close);
            return false;
        }

        void Pick()
        {
            string v = list.SelectedItem as string;
            if (v == null) return;
            Value = v;
            Close();
            Box.Focus();
        }

        void DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0 || e.Index >= list.Items.Count) return;
            bool sel = (e.State & DrawItemState.Selected) != 0;
            PopFrame.RowBack(e, sel);
            var r = new Rectangle(e.Bounds.X + Theme.S(10), e.Bounds.Y, e.Bounds.Width - Theme.S(16), e.Bounds.Height);
            if (pickOnly) Theme.Line(e.Graphics, (string)list.Items[e.Index], Theme.Font, r, Theme.Text);
            else
                TextRenderer.DrawText(e.Graphics, (string)list.Items[e.Index], Theme.Font, r, Theme.Text,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.NoPrefix | TextFormatFlags.PathEllipsis);
        }

        bool hover;

        void Hover()
        {
            bool now = IsHandleCreated && ClientRectangle.Contains(PointToClient(Cursor.Position));
            if (now != hover) { hover = now; Invalidate(); }
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            int ring = Theme.FieldRing;
            Box.Width = Width - 2 * ring - Theme.S(10) - Arrow;
            // A pick-only (Persian) box has its arrow at the left end and its text at the right.
            Box.Location = new Point(pickOnly && !Lang.En ? ring + Arrow : ring + Theme.S(10), (Height - Box.Height) / 2);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            Box.Focus();
            if (IsOpen) Close(); else Open();
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent == null ? this : Parent));
            bool focused = Box.Focused || IsOpen;
            Theme.Field(g, ClientRectangle, !Enabled ? FieldLook.Off : focused ? FieldLook.Focus : hover ? FieldLook.Hover : FieldLook.Normal);
            int a = Theme.S(14);
            float ax = pickOnly && !Lang.En ? Theme.FieldRing + (Arrow - a) / 2f + Theme.S(2) : Width - Theme.FieldRing - Arrow + (Arrow - a) / 2f - Theme.S(2);
            Glyphs.Draw(g, Glyph.Chevron, new RectangleF(ax, (Height - a) / 2f, a, a), list.Items.Count > 0 ? Theme.Muted : Theme.Faint);
        }
    }

    /// <summary>The server field: a box like a combo box. Clicking it or typing opens a list of matching servers under it
    /// (this computer's and MetaQuotes' public list, fetched in the background); choosing one fills the box and closes the list.</summary>
    sealed class ServerPicker : Panel, IMessageFilter
    {
        sealed class Item
        {
            public string Name;
            public bool Local;
            public override string ToString() { return Name; }
        }

        public readonly KeyTextBox Box = new KeyTextBox { RightToLeft = RightToLeft.No, BorderStyle = BorderStyle.None };
        readonly ListBox list = new ListBox { RightToLeft = RightToLeft.No, IntegralHeight = false, BorderStyle = BorderStyle.FixedSingle, DrawMode = DrawMode.OwnerDrawFixed, TabStop = false };
        readonly PopFrame frame;
        readonly Label note = Theme.Label("", 0, Theme.Small, Theme.Faint);
        Kind kind;
        List<string> local = new List<string>(), online = new List<string>();
        readonly Settings settings;
        readonly AccountStore store;
        bool picking, filtering;

        int BoxHeight { get { return Theme.FieldHeight + 2 * Theme.FieldRing; } }
        bool hover;

        void Hover()
        {
            bool now = IsHandleCreated && new Rectangle(0, 0, Width, BoxHeight).Contains(PointToClient(Cursor.Position));
            if (now != hover) { hover = now; Invalidate(); }
        }
        int Arrow { get { return Theme.S(30); } }

        public ServerPicker(Settings settings, AccountStore store, int width)
        {
            this.settings = settings;
            this.store = store;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Surface;
            Size = new Size(Theme.S(width), BoxHeight + Theme.S(27));
            Box.Font = Theme.Font;
            Box.BackColor = Theme.Input;
            Box.ForeColor = Theme.Text;
            list.Font = Theme.Font;
            frame = new PopFrame(list);
            Controls.Add(Box);
            Controls.Add(note);
            note.AutoSize = false;
            MouseEnter += (s, e) => Hover();
            MouseLeave += (s, e) => Hover();
            MouseMove += (s, e) => Hover();
            Box.MouseEnter += (s, e) => Hover();
            Box.MouseLeave += (s, e) => Hover();
            Box.TextChanged += (s, e) => { if (!picking) { Filter(); if (Box.Focused) Open(); } };
            Box.MouseDown += (s, e) => Open();
            Box.GotFocus += (s, e) => Invalidate();
            Box.LostFocus += (s, e) => { Invalidate(); CloseLater(); };
            Box.KeyHook = Key;
            list.DrawItem += DrawItem;
            list.MouseMove += (s, e) => { int k = list.IndexFromPoint(e.Location); if (k >= 0 && k != list.SelectedIndex) list.SelectedIndex = k; };
            list.MouseClick += (s, e) => { int k = list.IndexFromPoint(e.Location); if (k >= 0) { list.SelectedIndex = k; Pick(); } };
            list.LostFocus += (s, e) => CloseLater();
            Box.HandleCreated += (s, e) => Cue(Box, Lang.T("نام بروکر یا سرور، مثلاً WM Markets", "Broker or server name, e.g. WM Markets"));
        }

        [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
        static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);

        /// <summary>Windows' own gray hint inside an empty text box (EM_SETCUEBANNER).</summary>
        static void Cue(TextBox box, string text)
        {
            try { SendMessage(box.Handle, 0x1501, (IntPtr)1, text); } catch { }
        }

        public string Server { get { return Box.Text.Trim(); } set { picking = true; Box.Text = value ?? ""; picking = false; Filter(); } }

        public bool IsOpen { get { return frame.Visible; } }

        bool Key(Keys key)
        {
            switch (key)
            {
                case Keys.Down:
                case Keys.Alt | Keys.Down:
                case Keys.F4:
                    if (!IsOpen) { Open(); return true; }
                    if (list.Items.Count > 0) list.SelectedIndex = Math.Min(list.Items.Count - 1, list.SelectedIndex + 1);
                    return true;
                case Keys.Up:
                    if (IsOpen && list.Items.Count > 0) { list.SelectedIndex = Math.Max(0, list.SelectedIndex - 1); return true; }
                    return false;
                case Keys.Enter:
                    if (!IsOpen) return false;
                    if (list.SelectedIndex >= 0) Pick(); else Close();
                    return true;
                case Keys.Escape:
                    if (!IsOpen) return false;
                    Close();
                    return true;
                case Keys.Tab:
                case Keys.Shift | Keys.Tab:
                    Close();
                    return false;
            }
            return false;
        }

        /// <summary>Shows the list under the box, over the rest of the window.</summary>
        public void Open()
        {
            Form f = FindForm();
            if (f == null || !Visible) return;
            if (frame.Parent != f)
            {
                f.Controls.Add(frame);
                f.Disposed += (s, e) => Application.RemoveMessageFilter(this);
            }
            int ring = Theme.FieldRing;
            Point top = f.PointToClient(PointToScreen(new Point(ring, BoxHeight - ring)));
            int rows = Math.Max(1, Math.Min(8, list.Items.Count));
            int h = rows * list.ItemHeight + frame.Extra;
            int room = f.ClientSize.Height - top.Y - Theme.S(6);
            if (room < Math.Min(h, list.ItemHeight * 3 + frame.Extra))
            {
                // Not enough room under the box: open above it.
                Point above = f.PointToClient(PointToScreen(new Point(ring, ring)));
                h = Math.Min(h, above.Y - Theme.S(6));
                frame.Bounds = new Rectangle(above.X, above.Y - h - Theme.S(2), Width - 2 * ring, h);
            }
            else frame.Bounds = new Rectangle(top.X, top.Y + Theme.S(2), Width - 2 * ring, Math.Min(h, room));
            if (!frame.Visible)
            {
                frame.Visible = true;
                Application.AddMessageFilter(this);
            }
            frame.BringToFront();
            Invalidate();
        }

        public void Close()
        {
            if (!frame.Visible) return;
            frame.Visible = false;
            Application.RemoveMessageFilter(this);
            Invalidate();
        }

        /// <summary>Focus went somewhere else: close, unless it went into the list itself (a click on it).</summary>
        void CloseLater()
        {
            if (!IsHandleCreated) return;
            BeginInvoke((Action)(() => { if (!Box.Focused && !list.Focused) Close(); }));
        }

        /// <summary>A click anywhere outside the box and the list closes the list.</summary>
        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg != 0x201 && m.Msg != 0x204 && m.Msg != 0xA1 && m.Msg != 0xA4) return false;
            Control c = Control.FromHandle(m.HWnd);
            if (c != list && c != frame && c != Box && c != this && IsHandleCreated) BeginInvoke((Action)Close);
            return false;
        }

        void Pick()
        {
            var item = list.SelectedItem as Item;
            if (item == null) return;
            picking = true;
            Box.Text = item.Name;
            Box.SelectionStart = Box.Text.Length;
            picking = false;
            Close();
            Box.Focus();
            Filter();
        }

        void DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0 || e.Index >= list.Items.Count) return;
            var item = (Item)list.Items[e.Index];
            bool sel = (e.State & DrawItemState.Selected) != 0;
            PopFrame.RowBack(e, sel);
            var r = new Rectangle(e.Bounds.X + Theme.S(10), e.Bounds.Y, e.Bounds.Width - Theme.S(20), e.Bounds.Height);
            // 3.26 (CHANGE-008): the server's name in bold; where it comes from as a small green label or muted words at the other end.
            string from = item.Local ? Lang.T("روی این کامپیوتر", "On this computer") : Lang.T("فهرست MetaQuotes", "MetaQuotes list");
            int tw = Theme.Measure(from, Theme.Small).Width;
            int tag = tw + (item.Local ? Theme.S(16) : 0);
            TextRenderer.DrawText(e.Graphics, item.Name, Theme.Bold, new Rectangle(r.X, r.Y, Math.Max(0, r.Width - tag - Theme.S(10)), r.Height), Theme.Text,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
            if (item.Local)
            {
                int h = Theme.S(20);
                var pill = new Rectangle(r.Right - tag, r.Y + (r.Height - h) / 2, tag, h);
                Theme.Box(e.Graphics, pill, Theme.Square ? 0 : h / 2f, Theme.OkSoft, Color.Transparent);
                Theme.Line(e.Graphics, from, Theme.Small, pill, Theme.Ok, true);
            }
            else
                TextRenderer.DrawText(e.Graphics, from, Theme.Small, r, Theme.Faint, Theme.Rtl | TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine);
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            int ring = Theme.FieldRing;
            Box.Width = Width - 2 * ring - Theme.S(10) - Arrow;
            Box.Location = new Point(ring + Theme.S(10), (BoxHeight - Box.Height) / 2);
            note.Bounds = new Rectangle(ring, BoxHeight, Width - 2 * ring, Height - BoxHeight);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Y > BoxHeight) return;
            // The arrow (or the frame) opens and closes the list, like a combo box.
            Box.Focus();
            if (IsOpen) Close(); else Open();
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent == null ? this : Parent));
            bool focused = Box.Focused || IsOpen;
            var frame = new Rectangle(0, 0, Width, BoxHeight);
            Theme.Field(g, frame, !Enabled ? FieldLook.Off : focused ? FieldLook.Focus : hover ? FieldLook.Hover : FieldLook.Normal);
            int a = Theme.S(14);
            Glyphs.Draw(g, Glyph.Chevron, new RectangleF(Width - Theme.FieldRing - Arrow + (Arrow - a) / 2f - Theme.S(2), (BoxHeight - a) / 2f, a, a), Theme.Muted);
        }

        /// <summary>Loads the servers of a platform; the public list is refreshed in the background when older than a week.</summary>
        public void Load(Kind k)
        {
            kind = k;
            local = ServerCatalog.Local(k, settings, store);
            online = ServerCatalog.Online(k);
            Filter();
            note.Text = online.Count > 0 ? CountNote() : Lang.T("در حال گرفتن فهرست سرورها از MetaQuotes…", "Getting the server list from MetaQuotes…");
            // The refresh answers through this control's window, so it starts once the window exists.
            if (IsHandleCreated) StartRefresh(k);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            StartRefresh(kind);
        }

        string CountNote() { return Fa.N(local.Count + online.Count) + Lang.T(" سرور از فهرست MetaQuotes و همین کامپیوتر", " servers from the MetaQuotes list and this computer"); }

        void StartRefresh(Kind k)
        {
            if (ServerCatalog.Fresh(k)) return;
            var t = new Thread(() =>
            {
                string error = null;
                try { ServerCatalog.Refresh(k); }
                catch (Exception e) { error = e.Message; Log.Write("server list " + k + ": " + e.Message); }
                try
                {
                    if (IsHandleCreated && !IsDisposed)
                        BeginInvoke((Action)(() =>
                        {
                            if (kind != k || IsDisposed) return;
                            online = ServerCatalog.Online(k);
                            Filter();
                            if (error == null) note.Text = CountNote();
                            else if (online.Count > 0) note.Text = CountNote() + Lang.T(" (فهرست ذخیره‌شده)", " (saved list)");
                            else note.Text = Lang.T("فهرست اینترنتی در دسترس نبود؛ ", "The online list is not available; ") + Fa.N(local.Count) + Lang.T(" سرورِ این کامپیوتر نشان داده می‌شود. نام سرور را می‌شود دستی هم نوشت.", " servers of this computer are shown. You can also type the server name.");
                        }));
                }
                catch { }
            }) { IsBackground = true };
            t.Start();
        }

        void Filter()
        {
            if (filtering) return;
            filtering = true;
            try
            {
                List<string> mine = ServerCatalog.Search(local, Box.Text, 100);
                var mineSet = new HashSet<string>(mine, StringComparer.OrdinalIgnoreCase);
                List<string> rest = ServerCatalog.Search(online.Where(x => !mineSet.Contains(x)), Box.Text, 300);
                list.BeginUpdate();
                list.Items.Clear();
                foreach (string s in mine) list.Items.Add(new Item { Name = s, Local = true });
                foreach (string s in rest) list.Items.Add(new Item { Name = s });
                // The exact server already in the box is shown chosen.
                for (int k = 0; k < list.Items.Count; k++)
                    if (string.Equals(((Item)list.Items[k]).Name, Box.Text.Trim(), StringComparison.OrdinalIgnoreCase)) { list.SelectedIndex = k; break; }
                list.EndUpdate();
                // 3.26 (CHANGE-008): how many were found, at the bottom of the list.
                string q = Box.Text.Trim();
                frame.Footer = list.Items.Count == 0 ? "" : Fa.N(list.Items.Count) + Lang.T(" سرور", " servers") + (q.Length > 0 ? Lang.T(" برای «", " for “") + q + "»" : "");
                if (IsOpen) Open();
            }
            finally { filtering = false; }
        }
    }

    /// <summary>Opens the student's MetaTrader and reports, in plain words, whether the login worked.</summary>
    sealed class ConnectionDialog : FormDialog
    {
        readonly Instance inst;
        readonly Account acc;
        readonly DateTime since;
        readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer { Interval = 2000 };
        readonly GlyphBox mark = new GlyphBox(Glyph.Info, 40);
        readonly Label head = Theme.Label("", 0, Theme.Heading, Theme.Text);
        readonly Label body = Theme.Label("", 460, Theme.Font, Theme.LabelColor);
        readonly Button close, edit;
        public bool WantsEdit, WantsShow;
        int ticks;
#if SNAPSHOT
        bool previewing;
#endif
        public LoginResult Result = new LoginResult { State = Login.Waiting };

        public ConnectionDialog(Instance inst, Account acc, DateTime since)
            : base(Lang.T("بررسی اتصال | ", "Check connection | ") + (acc != null && acc.Trader.Length > 0 ? acc.Trader : inst.Name), null, false)
        {
            this.inst = inst;
            this.acc = acc;
            this.since = since;
            var row = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = Padding.Empty };
            var texts = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false, Margin = Theme.Pad(14, 0, 0, 0) };
            texts.Controls.Add(head);
            texts.Controls.Add(body);
            row.Controls.Add(mark);
            row.Controls.Add(texts);
            Wide(row);
            var page = AddButton(Lang.T("نمایش متاتریدر", "Show MetaTrader"), (s, e) => { WantsShow = true; Close(DialogResult.OK); }, true);
            edit = AddButton(Lang.T("ویرایش اطلاعات حساب", "Edit account details"), (s, e) => { WantsEdit = true; Close(DialogResult.Retry); });
            close = AddButton(Lang.T("بستن", "Close"), (s, e) => Close(DialogResult.Cancel));
            edit.Visible = false;
            MinWidth(520);
            Finish();
            AcceptButton = page;
            CancelButton = close;
            Show(Login.Waiting, "");
            timer.Tick += (s, e) => Poll();
#if SNAPSHOT
            Shown += (s, e) => { if (!previewing) timer.Start(); };
#else
            Shown += (s, e) => timer.Start();
#endif
            FormClosed += (s, e) => timer.Stop();
        }

        void Poll()
        {
            ticks++;
            LoginResult r;
            try { r = ConnectionCheck.Probe(inst, acc, since); }
            catch (Exception e) { Log.Write("connection check: " + e.Message); return; }
            // "No connection" is often only the first try of a terminal that has just opened: keep watching.
            bool final = r.State == Login.Connected || r.State == Login.WrongLogin || r.State == Login.NoServer || ticks >= 45;
            if (final)
            {
                timer.Stop();
                Result = r;
                Log.Write("connection check " + inst.Name + ": " + r.State + " " + r.Detail);
            }
            Show(r.State, r.Detail, r);
        }

        void Show(Login state, string detail, LoginResult r = null)
        {
            string login = acc != null ? acc.Login : "";
            string server = acc != null ? acc.Server : "";
            switch (state)
            {
                case Login.Connected:
                    mark.Glyph = Glyph.Success;
                    head.Text = Lang.T("وصل شد", "Connected");
                    body.Text = Lang.T("حساب ", "Account ") + login + Lang.T(" روی سرور ", " on server ") + server + Lang.T(" وارد شد. متاتریدرش باز است و در فهرست «فعال» دیده می‌شود.", " signed in. Its MetaTrader is open and shows under “Active”.");
                    break;
                case Login.WrongLogin:
                    mark.Glyph = Glyph.Error;
                    head.Text = Lang.T("شماره حساب یا رمز اینوستور درست نیست", "The account number or investor password is wrong");
                    body.Text = Lang.T("سرور جواب داد، ولی ورود را نپذیرفت. شماره حساب و رمز اینوستور را دوباره بپرسید و وارد کنید.", "The server answered but refused the login. Ask for the account number and investor password again and enter them.") + Detail(detail);
                    break;
                case Login.NoServer:
                    mark.Glyph = Glyph.Error;
                    head.Text = Lang.T("سرور پیدا نشد", "Server not found");
                    body.Text = Lang.T("متاتریدر سرور «", "MetaTrader does not know the server “") + server + Lang.T("» را نمی‌شناسد. نام سرور را از فهرست انتخاب کنید؛ اگر بروکر جدید است، متاتریدرِ همان بروکر را یک بار از سایتش نصب کنید و دانشجو را دوباره اضافه کنید.", "”. Pick the server from the list; if the broker is new, install that broker's MetaTrader once from its website and add the student again.") + Detail(detail);
                    break;
                case Login.NoConnection:
                    mark.Glyph = Glyph.Warning;
                    head.Text = ticks >= 45 ? Lang.T("اتصال برقرار نشد", "Could not connect") : Lang.T("اتصال برقرار نشد؛ دوباره تلاش می‌شود…", "Could not connect; trying again…");
                    body.Text = Lang.T("متاتریدر به سرور وصل نمی‌شود: اینترنت این کامپیوتر یا سرور بروکر را بررسی کنید.", "MetaTrader cannot reach the server: check this computer's internet or the broker's server.") + Detail(detail);
                    break;
                default:
                    mark.Glyph = Glyph.Info;
                    if (ticks >= 45)
                    {
                        head.Text = Lang.T("هنوز نتیجه‌ای معلوم نیست", "No result yet");
                        body.Text = Lang.T("متاتریدر باز است ولی خبری از ورود نداد. «نمایش متاتریدر» را بزنید و پایین پنجره‌اش را ببینید: اگر وصل است، همه‌چیز درست است.", "MetaTrader is open but has not reported a login. Press “Show MetaTrader” and look at the bottom of its window: if it is connected, all is well.");
                    }
                    else
                    {
                        head.Text = Lang.T("در حال اتصال…", "Connecting…");
                        body.Text = Lang.T("متاتریدر این دانشجو باز می‌شود و با شماره حساب ", "This student's MetaTrader opens and connects with account ") + login + Lang.T(" به سرور ", " to server ") + server + Lang.T(" وصل می‌شود. چند ثانیه صبر کنید.", ". Please wait a few seconds.");
                    }
                    break;
            }
            edit.Visible = state == Login.WrongLogin || state == Login.NoServer;
            mark.Invalidate();
        }

        /// <summary>The terminal's own words, without the journal's code and time columns.</summary>
        static string Detail(string d)
        {
            if (string.IsNullOrEmpty(d)) return "";
            string[] parts = d.Split('\t');
            string text = parts[parts.Length - 1].Trim();
            // On its own line and embedded left-to-right, so the English sentence keeps its word order.
            return text.Length == 0 ? "" : Lang.T("\n\nگزارش متاتریدر:\n\u202A", "\n\nMetaTrader's log:\n\u202A") + text + "\u202C";
        }

#if SNAPSHOT
        public void Preview(Login state, string detail, int tick)
        {
            previewing = true;
            timer.Stop();
            ticks = tick;
            Show(state, detail, new LoginResult { State = state, Detail = detail });
        }
#endif
    }
}
