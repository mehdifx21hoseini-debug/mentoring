using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
namespace MTManager
{
    public sealed class LaunchWorkProgress
    {
        readonly HashSet<string> targets=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        readonly HashSet<string> done=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        readonly HashSet<string> skipped=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        readonly HashSet<string> failed=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        volatile bool stopped;
        public bool Stopped { get{return stopped;} }
        public bool Stopping { get; private set; }
        public string Detail="";
        public int Total { get{return targets.Count;} }
        public int Done { get{return done.Count;} }
        public int Skipped {get{return skipped.Count;}}
        public int Failed { get{return failed.Count;} }
        public int Remaining { get{return Math.Max(0,Total-Done);} }
        public double Fraction { get{return Total==0?0:(double)Done/Total;} }
        public bool Finished { get{return Total>0 && (Stopped?!Stopping:Done>=Total);} }
        public void Add(string copy){if(!Stopped && !string.IsNullOrEmpty(copy))targets.Add(copy);}
        public void Complete(string copy,bool success){if(targets.Contains(copy)&&done.Add(copy)&&!success)failed.Add(copy);}
        public void Skip(string copy){if(targets.Contains(copy)&&done.Add(copy))skipped.Add(copy);}
        public void Stop(bool inFlight){if(Total==0 || Done>=Total)return;stopped=true;Stopping=inFlight;}
        public void SettleStop(){Stopping=false;}
    }
    sealed partial class MainForm
    {
        readonly ReportProgressStrip launchProgress=new ReportProgressStrip{Dock=DockStyle.Bottom,Visible=false};
        LaunchWorkProgress launchWork=new LaunchWorkProgress();
        void RefreshLaunchProgress(bool reset=false){launchProgress.SetLaunch(launchWork,reset);}
        void StopLaunchQueue()
        {
            if(startQueue.Count==0&&!preparingCopy)return;
            startQueue.Clear();startTimer.Stop();
            launchWork.Stop(preparingCopy);
            launchWork.Detail=preparingCopy?Lang.T("ادامهٔ صف لغو شد؛ پردازش جاری در حال پایان است","Queued starts cancelled; current work is finishing")
                :Lang.T("متاتریدرهای شروع‌شده باز می‌مانند","Already started terminals remain open");
            RefreshLaunchProgress();
            SetStatus(Lang.T("ادامهٔ اجرا متوقف شد؛ متاتریدرهای باز بسته نشدند.","Further launches stopped; running terminals were left open."));
        }
    }
}
