using System;using System.Diagnostics;
namespace MTManager
{
    public static class StartupAdmission
    {
        // Bounded spacing, never a wait for broker history/quiet CPU/window readiness.
        public static int Spacing(int configured,ulong freeMb)
        {
            int floor=freeMb==0?7:freeMb<384?15:freeMb<768?10:freeMb<1536?7:0;
            return Math.Max(Math.Min(2,Math.Max(0,configured)),floor);
        }
        public static bool Wait(double elapsed,int configured,ulong freeMb){return elapsed<Spacing(configured,freeMb);}
    }
    sealed partial class MainForm
    {
        bool hasStartedMt5;
        string startupWaitKey="";
        int startupWaits;
        string StartupQueueSummary(){return "\r\n— MT5 startup pacing —\r\nNo initializer-slot/history/quiet-CPU gate. Keeps original configured maximum interval / early-ready behavior; adds only a memory minimum gap; low-RAM minimum gaps: <1536MB=7s, <768MB=10s, <384MB=15s, unknown=7s. Configured maximum timing is still handled by the original StartPace policy. No total terminal cap or forced close.\r\nMemory pacing transitions="+startupWaits+"\r\n";}
        void TrackMt5Startup(Instance copy,StartResult result){if(result.Process==null)return;if(copy.Kind==Kind.MT5)hasStartedMt5=true;LaunchComparison.ReboundAfterUpdate(copy,result.Process,accounts.Get(copy.Name));}
        void UpdateMt5StartupProcess(Instance copy,Process process)
        {
            if(process!=null)LaunchComparison.ReboundAfterUpdate(copy,process,accounts.Get(copy.Name));
        }
        bool WaitForStartupSlot(Instance next)
        {
            if(next.Kind!=Kind.MT5 || !hasStartedMt5)return false;
            ulong free=launchFreeRam();double elapsed=(DateTime.Now-lastStartAt).TotalSeconds;
            int spacing=StartupAdmission.Spacing(settings.DelaySeconds,free);
            bool wait=StartupAdmission.Wait(Math.Max(0,elapsed),settings.DelaySeconds,free);
            string key=wait?spacing.ToString():"";
            if(key!=startupWaitKey)
            {
                startupWaitKey=key;
                if(wait){startupWaits++;Log.Write("MT5 bounded memory pacing: gap="+spacing+" s; elapsed="+elapsed.ToString("0.0",System.Globalization.CultureInfo.InvariantCulture)+" s; no history/CPU readiness gate");}
            }
            return wait;
        }
    }
}
