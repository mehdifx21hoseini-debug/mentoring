using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;

namespace MTManager
{
    public static class StudentDirectory
    {
        static readonly object copyGate = new object();
        public static Kind KindOf(Account a) { return a.Platform == "MT4" || a.Instance.StartsWith("MT4", StringComparison.OrdinalIgnoreCase) ? Kind.MT4 : Kind.MT5; }
        public static List<Instance> All(Settings s, AccountStore accounts)
        {
            var result = Installs.Copies(s);
            var names = new HashSet<string>(result.Select(i => i.Name), StringComparer.OrdinalIgnoreCase);
            foreach (Account a in accounts.All.Where(a => a.DeferredDir.Length > 0))
                if (names.Add(a.Instance)) result.Add(new Instance { Name = a.Instance, Kind = KindOf(a), Dir = a.DeferredDir });
            return result;
        }
        public static string Reserve(Settings s, AccountStore accounts, Kind kind)
        {
            var names = new HashSet<string>(All(s, accounts).Select(c => c.Name), StringComparer.OrdinalIgnoreCase);
            int index = CopyMaker.NextIndex(s.AllFolders, kind.ToString());
            while (names.Contains(kind + "-" + index.ToString("00"))) index++;
            return kind + "-" + index.ToString("00");
        }
        public static string Source(Settings s, Kind kind, string server, Func<bool> cancel)
        {
            return StudentImportRuntime.FindWithDeadline(() => { bool sure; return ServerCatalog.InstallFor(kind, server, s, out sure); }, cancel, 15000);
        }
        public static void EnsureCopy(Settings s, Instance copy, Account a, Func<bool> cancel)
        {
            if (File.Exists(copy.Exe)) return;
            if (a == null || a.DeferredDir.Length == 0) throw new UserMessage(Lang.T("فایل متاتریدر پیدا نشد.", "The terminal executable was not found."));
            lock (copyGate)
            {
                if (File.Exists(copy.Exe)) return;
                string source = Source(s, copy.Kind, a.Server, cancel);
                if (source == null) throw new UserMessage(copy.Kind + Lang.T(" بروکر نصب نیست.", " broker terminal is not installed."));
                Prepare(s, source, copy, cancel);
            }
        }
        // Atomic staging under _MTManager, never exposed as a student directory while copying.
        public static void Prepare(Settings s, string source, Instance copy, Func<bool> cancel)
        {
            if (File.Exists(copy.Exe)) { PortableServers.Sync(source, copy.Dir, copy.Kind, null, cancel); return; }
            if (Directory.Exists(copy.Dir)) throw new UserMessage(Lang.T("پوشهٔ مقصد ناقص است؛ برای حفظ فایل‌ها بازنویسی نشد.", "Destination folder is incomplete; existing files were preserved."));
            string stage = Path.Combine(s.BaseDir, "_MTManager", "provision", Guid.NewGuid().ToString("N"));
            var clock = Stopwatch.StartNew();
            try
            {
                Copy(source, stage, "", copy.Kind, () => {
                    if (cancel()) throw new OperationCanceledException();
                    if (clock.Elapsed.TotalSeconds > 120) throw new TimeoutException("Terminal preparation timed out.");
                });
                PortableServers.Sync(source, stage, copy.Kind, null, cancel);
                if (!File.Exists(Path.Combine(stage, Kinds.Exe(copy.Kind)))) throw new IOException("Terminal executable was not copied.");
                if (cancel()) throw new OperationCanceledException();
                Directory.CreateDirectory(Path.GetDirectoryName(copy.Dir));
                Directory.Move(stage, copy.Dir);
            }
            finally { try { if (Directory.Exists(stage)) Directory.Delete(stage, true); } catch { } }
        }
        static void Copy(string source, string dest, string relative, Kind kind, Action check)
        {
            check(); Directory.CreateDirectory(dest);
            foreach (string f in Directory.GetFiles(source))
            {
                check(); string name = Path.GetFileName(f), rel = relative.Length == 0 ? name : relative + "/" + name;
                // Unique live launch INIs may contain login credentials. Never clone them into a verifier.
                if(relative.Length==0 && name.StartsWith("mtm-live-start-",StringComparison.OrdinalIgnoreCase) && name.EndsWith(".ini",StringComparison.OrdinalIgnoreCase))continue;
                if (ReportCopies.Skip(rel, false, kind) || (File.GetAttributes(f) & FileAttributes.ReparsePoint) != 0) continue;
                // Files held by a running source terminal may still be read safely; personal caches are excluded.
                using (var input = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                using (var output = File.Create(Path.Combine(dest, name)))
                {
                    var buffer = new byte[65536]; int n;
                    while ((n = input.Read(buffer, 0, buffer.Length)) > 0) { check(); output.Write(buffer, 0, n); }
                }
            }
            foreach (string d in Directory.GetDirectories(source))
            {
                string name = Path.GetFileName(d), rel = relative.Length == 0 ? name : relative + "/" + name;
                if ((File.GetAttributes(d) & FileAttributes.ReparsePoint) != 0 || ReportCopies.Skip(rel, true, kind)) continue;
                if (relative.Length == 0 && new[] { "_MTManager", "profiles", "templates", "MQL4", "MQL5", "reports" }.Contains(name, StringComparer.OrdinalIgnoreCase)) continue;
                Copy(d, Path.Combine(dest, name), rel, kind, check);
            }
        }
    }
}
