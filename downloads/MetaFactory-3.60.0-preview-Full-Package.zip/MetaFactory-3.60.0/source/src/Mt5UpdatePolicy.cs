using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Diagnostics;
using System.Collections.Generic;
using System.Security.Cryptography;
namespace MTManager
{
    // Reversible current-user cache barrier. No elevation, executable patching, UAC or network policy changes.
    public static class Mt5UpdatePolicy
    {
        const string Magic="MetaFactory-MT5-Update-Pause-1\n";
        static readonly object gate=new object();
        static readonly Dictionary<string,FileStream> held=new Dictionary<string,FileStream>(StringComparer.OrdinalIgnoreCase);
        public static string CacheKey(string fullDirectory)
        {
            string canonical=fullDirectory.TrimEnd('\\','/').ToUpperInvariant();
            using(var hash=MD5.Create())return BitConverter.ToString(hash.ComputeHash(Encoding.Unicode.GetBytes(canonical))).Replace("-","");
        }
        static string Folder(string root,string key)
        {
            if(!System.Text.RegularExpressions.Regex.IsMatch(key??"",@"\A[0-9A-F]{32}\z"))throw new ArgumentException("Invalid cache identity.");
            string folder=Path.Combine(Path.GetFullPath(root),key);
            if(Directory.Exists(root) && (File.GetAttributes(root)&FileAttributes.ReparsePoint)!=0)throw new IOException("Cache root is a link.");
            if(Directory.Exists(folder) && (File.GetAttributes(folder)&FileAttributes.ReparsePoint)!=0)throw new IOException("Cache folder is a link.");
            return folder;
        }
        static bool Owned(string marker,string key)
        {
            if(!File.Exists(marker) || (File.GetAttributes(marker)&FileAttributes.ReparsePoint)!=0 || new FileInfo(marker).Length>160)return false;
            using(var stream=new FileStream(marker,FileMode.Open,FileAccess.Read,FileShare.ReadWrite))
            using(var reader=new StreamReader(stream,Encoding.ASCII))return reader.ReadToEnd()==Magic+key+"\n";
        }
        public static void HoldAt(string root,string key)
        {
            lock(gate)
            {
                string folder=Folder(root,key),marker=Path.Combine(folder,"liveupdate"),backup=Path.Combine(folder,"liveupdate.MetaFactory-backup");
                if(held.ContainsKey(marker))return;
                Directory.CreateDirectory(folder);
                FileStream stream=null;bool moved=false,created=false;
                try
                {
                    if(Directory.Exists(marker))
                    {
                        if((File.GetAttributes(marker)&FileAttributes.ReparsePoint)!=0)throw new IOException("Update directory is a link.");
                        if(Directory.Exists(backup)||File.Exists(backup))throw new IOException("A preserved update cache already exists; nothing overwritten.");
                        Directory.Move(marker,backup);moved=true;
                    }
                    if(File.Exists(marker))
                    {
                        if(!Owned(marker,key))throw new IOException("Existing liveupdate file is not owned by MetaFactory.");
                        stream=new FileStream(marker,FileMode.Open,FileAccess.Read,FileShare.Read);
                    }
                    else
                    {
                        stream=new FileStream(marker,FileMode.CreateNew,FileAccess.ReadWrite,FileShare.Read);created=true;
                        byte[] content=Encoding.ASCII.GetBytes(Magic+key+"\n");stream.Write(content,0,content.Length);stream.Flush();
                    }
                    held.Add(marker,stream);stream=null;
                }
                catch
                {
                    if(stream!=null)stream.Dispose();
                    if(created)try{File.Delete(marker);}catch{}
                    if(moved && !File.Exists(marker) && !Directory.Exists(marker))try{Directory.Move(backup,marker);}catch{}
                    throw;
                }
            }
        }
        public static bool RestoreAt(string root,string key)
        {
            lock(gate)
            {
                string folder=Folder(root,key),marker=Path.Combine(folder,"liveupdate"),backup=Path.Combine(folder,"liveupdate.MetaFactory-backup");
                FileStream stream;if(held.TryGetValue(marker,out stream)){held.Remove(marker);stream.Dispose();}
                if(!Owned(marker,key))return false; // Never remove somebody else's file or directory.
                File.Delete(marker);
                if(Directory.Exists(backup))Directory.Move(backup,marker);
                return true;
            }
        }
        public static void ReleaseHandles()
        {
            lock(gate){foreach(var stream in held.Values)stream.Dispose();held.Clear();}
        }
        public static void RestoreAll()
        {
            string[] markers;lock(gate)markers=held.Keys.ToArray();
            foreach(string marker in markers)try{var directory=Directory.GetParent(marker);RestoreAt(directory.Parent.FullName,directory.Name);}catch(Exception e){Log.Write("MT5 update pause restore: "+e.GetType().Name);}
        }
        public static string Summary(){lock(gate)return "update-cache barriers held="+held.Count+"; per-copy current-user cache only; no UAC approval or global update disable";}
        public static void Apply(Instance copy,Settings settings)
        {
            if(copy.Kind!=Kind.MT5 || !System.Text.RegularExpressions.Regex.IsMatch(copy.Name??"",@"\AMT5-[0-9]+\z") || Environment.OSVersion.Platform!=PlatformID.Win32NT)return;
            string root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"MetaQuotes","Terminal"),key=CacheKey(Path.GetFullPath(copy.Dir));
            if(!settings.PauseMt5Updates){RestoreAt(root,key);return;}
            // Do not invalidate an already pending consent/update. Existing installed copies are checked closed by Launcher.
            var consent=Process.GetProcessesByName("consent");bool pending=consent.Length>0;foreach(var process in consent)process.Dispose();
            if(pending)throw new UserMessage(Lang.T("ابتدا پنجرهٔ تأیید ویندوز را ببندید و دوباره اجرا کنید؛ فایل به‌روزرسانیِ در حال تأیید تغییر نکرد.","Close the pending Windows consent dialog, then Run again; the pending updater was not changed."));
            try
            {
                HoldAt(root,key);
                Log.Write("MT5 automatic updates paused for "+copy.Name+"; own cache="+key+"; original update directory preserved; no UAC or executable changes");
            }
            catch(Exception error)
            {
                Log.Write("MT5 update pause failed for "+copy.Name+": "+error.GetType().Name+" "+error.Message);
                throw new UserMessage(Lang.T("توقف به‌روزرسانی این نسخه ممکن نشد. در تنظیمات، «اجرای MT5 بدون به‌روزرسانی خودکار» را خاموش کنید تا با رفتار قبلی اجرا شود. ","Cannot pause updates for this copy. Disable 'Run MT5 without automatic updates' in Settings to use the previous launch behavior. ")+error.GetType().Name);
            }
        }
    }
}
