using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MTManager
{
    /// <summary>All saved student/account fields, independent of the current list filters.</summary>
    public static class StudentExport
    {
        public static List<string[]> Rows(IEnumerable<Instance> copies, AccountStore accounts, FolderStore folders, bool passwords)
        {
            var instances = copies.ToDictionary(c => c.Name, StringComparer.OrdinalIgnoreCase);
            var names = accounts.All.Select(a => a.Instance).Concat(instances.Keys).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x, StringComparer.OrdinalIgnoreCase);
            var result = new List<string[]> { new[] { "Name", "Platform", "Login", "Server", "Investor", "Folder", "Copy", "Path", "Mode", "Master", "AllFolders", "CopyAvailable", "PasswordStatus", "OriginalName" } };
            foreach (string name in names)
            {
                Account a = accounts.Get(name); Instance copy;
                instances.TryGetValue(name, out copy);
                var groups = folders.All.Where(f => folders.Has(f.Id, name)).Select(f => f.Name).ToList();
                string investor = "", master = "", status = passwords ? "Not stored" : "Excluded";
                if (passwords && a != null)
                {
                    investor = Secret.Unprotect(a.InvestorEnc ?? ""); master = Secret.Unprotect(a.MasterEnc ?? "");
                    status = investor == null || master == null ? "Some passwords could not be decrypted on this Windows user" : "Included";
                }
                result.Add(new[] { a == null ? "" : a.Trader, copy != null ? copy.Kind.ToString() : name.StartsWith("MT4", StringComparison.OrdinalIgnoreCase) ? "MT4" : name.StartsWith("MT5", StringComparison.OrdinalIgnoreCase) ? "MT5" : "", a == null ? "" : a.Login, a == null ? "" : a.Server,
                    investor ?? "", groups.FirstOrDefault() ?? "", name, copy == null ? "" : copy.Dir, a == null ? "" : a.Mode, master ?? "", string.Join(" | ", groups), copy == null || !File.Exists(copy.Exe) ? "No" : "Yes", status, a==null?"":a.OriginalTrader });
            }
            return result;
        }

        public static void Write(string path, IList<string[]> rows, bool passwords)
        {
            Spreadsheet.Write(path, rows, new[] {
                "MetaFactory — Student directory / فهرست دانشجوها",
                "All saved students are exported regardless of search, platform or folder filters. / همه دانشجوها، مستقل از فیلتر صفحه.",
                "Name, Platform, Login, Server, Investor and Folder are compatible with bulk import. Extra columns are ignored when importing.",
                "Folder is the first membership; AllFolders contains all memberships. Bulk import uses only Folder and never overwrites duplicates.",
                "CopyAvailable means the terminal copy was found on disk. It does not mean the account was connected or the password verified.",
                "PasswordStatus identifies passwords that cannot be decrypted for this Windows user; their cells are left empty.",
                passwords ? "Passwords are readable in this workbook. Store it privately. / رمزها در این فایل خوانا هستند؛ در محل امن نگهداری کنید." : "Passwords were excluded. / رمزها در این فایل نیستند."
            });
        }
    }

    sealed class StudentExportDialog : FormDialog
    {
        readonly CheckBox passwords = new CheckBox { AutoSize = true, Checked = true, Text = Lang.T("رمزهای ذخیره‌شده هم در فایل قرار بگیرند", "Include saved passwords") };
        public bool IncludePasswords { get { return passwords.Checked; } }
        public StudentExportDialog(int count)
            : base(Lang.T("خروجی اکسل", "Export to Excel"), Fa.N(count) + Lang.T(" دانشجو؛ همه‌ی فهرست، مستقل از فیلتر و جستجو.", " students; the entire directory, regardless of filters and search."))
        {
            Wide(Theme.Label(Lang.T("نام، حساب، متاتریدر، سرور، پوشه‌ها و اطلاعات نسخه در فایل ذخیره می‌شوند.", "Names, accounts, platform, server, groups and copy details are saved."), 460));
            Wide(passwords);
            Wide(Theme.Label(Lang.T("با فعال بودن این گزینه، رمزها در اکسل خوانا هستند؛ فایل را در محل امن نگه دارید.", "When enabled, passwords are readable in Excel; store the file privately."), 460, Theme.Small, Theme.Muted));
            var ok = AddButton(Lang.T("انتخاب محل و ذخیره", "Choose location and save"), (s, e) => Close(DialogResult.OK), true);
            var cancel = AddButton(Lang.T("انصراف", "Cancel"), (s, e) => Close(DialogResult.Cancel));
            Finish(); AcceptButton = ok; CancelButton = cancel;
        }
    }
}
