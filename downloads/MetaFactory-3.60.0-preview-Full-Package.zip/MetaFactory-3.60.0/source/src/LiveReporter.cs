using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace MTManager
{
    public sealed class LiveReporterDeployment
    {
        public string CopyName, Platform, ExpertPath, PresetPath, OutputDirectory, Instructions, SourceHash;
        public string SnapshotPath { get { return Path.Combine(OutputDirectory, "snapshot.txt"); } }
    }

    /// <summary>Build and deploy an independent read-only EA. This helper never starts/stops a terminal,
    /// attaches an EA, changes profiles/accounts, or replaces an existing EA file. Call on a worker thread.</summary>
    public static class LiveReporter
    {
        public const string ExpertName = "MTManagerLive";
        const int CompileMilliseconds = 120000;
        static string SourceName(Kind kind) { return ExpertName + (kind == Kind.MT4 ? ".mq4" : ".mq5"); }
        public static string BinaryName(Kind kind) { return ExpertName + (kind == Kind.MT4 ? ".ex4" : ".ex5"); }

        public static string SourceText(Kind kind)
        {
            ValidateKind(kind);
            using (Stream source = Assembly.GetExecutingAssembly().GetManifestResourceStream(SourceName(kind)))
            {
                if (source == null) throw new UserMessage(Lang.T("کد گزارش‌خوان زنده داخل برنامه موجود نیست: ", "Live reporter source is missing from this application: ") + SourceName(kind));
                using (var reader = new StreamReader(source)) return reader.ReadToEnd();
            }
        }

        static void ValidateKind(Kind kind)
        {
            if (kind != Kind.MT4 && kind != Kind.MT5) throw new ArgumentException("Expected MT4 or MT5.", "kind");
        }

        public static string ValidateToken(string token)
        {
            if (token == null || !Regex.IsMatch(token, "\\A[0-9a-fA-F]{32}\\z"))
                throw new UserMessage(Lang.T("شناسهٔ جلسهٔ زنده معتبر نیست؛ دوباره آماده‌سازی کنید.", "The live session identifier is invalid; prepare it again."));
            return token.ToLowerInvariant();
        }

        static string LoginOf(Account account)
        {
            string login = account == null ? "" : (account.Login ?? "").Trim();
            long number;
            if (!Regex.IsMatch(login, "\\A[0-9]{1,20}\\z") || !long.TryParse(login, NumberStyles.None, CultureInfo.InvariantCulture, out number) || number <= 0)
                throw new UserMessage(Lang.T("شمارهٔ حساب برای گزارش زنده معتبر نیست.", "The account number is invalid for live reporting."));
            return number.ToString(CultureInfo.InvariantCulture);
        }

        static string ServerOf(Account account)
        {
            string raw = account == null ? "" : (account.Server ?? "");
            string server = raw.Trim();
            if (server.Length == 0 || server.Length > 256 || raw.Any(char.IsControl))
                throw new UserMessage(Lang.T("نام سرور برای گزارش زنده معتبر نیست.", "The server name is invalid for live reporting."));
            return server;
        }

        public static string PresetText(Account account, string token)
        {
            return "SessionToken=" + ValidateToken(token) + "\r\nExpectedLogin=" + LoginOf(account) +
                "\r\nExpectedServer=" + ServerOf(account) + "\r\n";
        }

        public static string OutputPath(Instance copy, string token)
        {
            ValidateKind(copy.Kind);
            return Path.Combine(Path.GetFullPath(copy.Dir), Kinds.Mql(copy.Kind), "Files", "MetaFactoryLive", ValidateToken(token));
        }

        static void Cancelled(Func<bool> cancel)
        {
            if (cancel != null && cancel()) throw new OperationCanceledException();
        }

        static string FileHash(string path)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create())
            using (var stream = File.OpenRead(path)) return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "");
        }

        static bool Cached(string binary, string stamp, string sourceHash)
        {
            try
            {
                string[] proof = File.ReadAllLines(stamp, Encoding.UTF8);
                return proof.Length == 2 && proof[0] == sourceHash && File.Exists(binary) && new FileInfo(binary).Length > 0 && proof[1] == FileHash(binary);
            }
            catch { return false; }
        }

        /// <summary>The cache is separate from manual-report binaries and keyed by source plus compiler identity.</summary>
        public static string Build(Settings settings, Kind kind, Func<bool> cancel = null)
        {
            ValidateKind(kind); Cancelled(cancel);
            if (Environment.OSVersion.Platform != PlatformID.Win32NT)
                throw new UserMessage(Lang.T("ساخت گزارش‌خوان زنده باید روی ویندوز با MetaEditor انجام شود.", "The live reporter must be compiled on Windows with MetaEditor."));
            string source = SourceText(kind), sourceHash = ReportScript.Stamp(source);
            string editor = ReportScript.FindEditor(kind, settings);
            if (editor == null) throw new UserMessage(Lang.T("MetaEditor برای ", "MetaEditor for ") + kind + Lang.T(" پیدا نشد. نسخهٔ اصلی این متاتریدر را همراه MetaEditor نصب کنید و دوباره آماده‌سازی کنید.", " was not found. Install the original terminal with MetaEditor and prepare again."));
            string compiler = Path.GetFullPath(editor) + "|" + new FileInfo(editor).LastWriteTimeUtc.Ticks.ToString(CultureInfo.InvariantCulture) + "|" + TerminalUpdate.FileVersion(editor);
            string dir = Path.Combine(settings.BaseDir, "_MTManager", "live", "build", kind.ToString(), ReportScript.Stamp(sourceHash + "|" + compiler));
            string binary = Path.Combine(dir, BinaryName(kind)), stamp = binary + ".stamp";
            string gateName = "Local\\MetaFactoryLiveBuild_" + ReportScript.Stamp(Path.GetFullPath(dir).ToUpperInvariant()).Substring(0, 24);
            using (var gate = new Mutex(false, gateName))
            {
                bool held = false; var admission = Stopwatch.StartNew();
                try
                {
                    while (!held)
                    {
                        Cancelled(cancel);
                        try { held = gate.WaitOne(100); } catch (AbandonedMutexException) { held = true; }
                        if (!held && admission.ElapsedMilliseconds >= CompileMilliseconds)
                            throw new UserMessage(Lang.T("ساخت دیگری از گزارش‌خوان زنده هنوز تمام نشده؛ بعداً دوباره امتحان کنید.", "Another live reporter build is still pending; retry later."));
                    }
                    if (Cached(binary, stamp, sourceHash)) return binary;
                    Directory.CreateDirectory(dir);
                    string sourcePath = Path.Combine(dir, SourceName(kind)), log = Path.Combine(dir, "compile.log");
                    File.WriteAllText(sourcePath, source, Encoding.UTF8);
                    // Only incomplete artifacts in this private hash cache are replaced, never deployed EAs.
                    if (File.Exists(binary)) File.Delete(binary);
                    if (File.Exists(stamp)) File.Delete(stamp);
                    if (File.Exists(log)) File.Delete(log);
                    Cancelled(cancel);
                    var psi = new ProcessStartInfo(editor, "/compile:\"" + sourcePath + "\" /log:\"" + log + "\"")
                    { UseShellExecute = false, CreateNoWindow = true, WorkingDirectory = Path.GetDirectoryName(editor) };
                    Log.Write("live reporter compile: platform=" + kind + " source=" + sourceHash + " editor=" + editor);
                    using (Process process = Process.Start(TerminalProcessPolicy.Prepare(psi, settings)))
                    {
                        if (process == null) throw new UserMessage(Lang.T("MetaEditor شروع نشد.", "MetaEditor did not start."));
                        var elapsed = Stopwatch.StartNew();
                        try
                        {
                            while (!process.WaitForExit(100))
                            {
                                Cancelled(cancel);
                                if (elapsed.ElapsedMilliseconds >= CompileMilliseconds)
                                    throw new UserMessage(Lang.T("ساخت گزارش‌خوان زنده بیش از دو دقیقه طول کشید.", "Live reporter compilation exceeded two minutes."));
                            }
                        }
                        finally
                        {
                            // This is only the compiler process created above; no terminal is ever closed.
                            try { if (!process.HasExited) { process.Kill(); process.WaitForExit(1000); } } catch { }
                        }
                    }
                    Cancelled(cancel);
                    string report = TextFiles.ReadText(log) ?? "";
                    Log.Write("live reporter compiler output " + kind + ": " + TextUtil.OneLine(report));
                    if (!File.Exists(binary) || new FileInfo(binary).Length == 0)
                        throw new UserMessage(Lang.T("ساخت گزارش‌خوان زنده ناموفق بود؛ گزارش MetaEditor:\n", "Live reporter compilation failed; MetaEditor output:\n") + Tail(report, 3000));
                    File.WriteAllLines(stamp, new[] { sourceHash, FileHash(binary) }, Encoding.UTF8);
                    return binary;
                }
                finally { if (held) gate.ReleaseMutex(); }
            }
        }

        static string Tail(string text, int length)
        {
            text = (text ?? "").Trim();
            return text.Length <= length ? text : "…" + text.Substring(text.Length - length);
        }

        public static LiveReporterDeployment Prepare(Settings settings, Instance copy, Account account, string token, Func<bool> cancel = null)
        {
            if (settings == null || copy == null) throw new ArgumentNullException(settings == null ? "settings" : "copy");
            ValidateKind(copy.Kind); token = ValidateToken(token); Cancelled(cancel);
            if (account == null || !string.Equals(account.Instance, copy.Name, StringComparison.OrdinalIgnoreCase))
                throw new UserMessage(Lang.T("حساب انتخاب‌شده با این نسخهٔ متاتریدر مطابقت ندارد.", "The selected account does not match this terminal copy."));
            string preset = PresetText(account, token);
            if (!File.Exists(copy.Exe)) throw new UserMessage(Lang.T("فایل متاتریدر این دانشجو پیدا نشد.", "This student's terminal executable was not found."));
            string sandboxProblem = SandboxLaunch.LiveDirectoryProblem(copy);
            if (sandboxProblem != null) throw new UserMessage(sandboxProblem);
            string binary = Build(settings, copy.Kind, cancel), sourceHash = ReportScript.Stamp(SourceText(copy.Kind));
            return DeployBuilt(copy, binary, sourceHash, token, preset, cancel);
        }

        internal static LiveReporterDeployment DeployBuilt(Instance copy, string binary, string sourceHash, string token, string preset, Func<bool> cancel = null)
        {
            ValidateKind(copy.Kind); token = ValidateToken(token); Cancelled(cancel);
            string binaryHash = FileHash(binary);
            // A newly compiled version receives its own directory, even if the source hash is unchanged.
            string version = sourceHash.Substring(0, 16) + "-" + binaryHash.Substring(0, 12);
            string root = Path.GetFullPath(copy.Dir);
            string expert = Path.Combine(root, Kinds.Mql(copy.Kind), "Experts", "MetaFactoryLive", version, BinaryName(copy.Kind));
            Directory.CreateDirectory(Path.GetDirectoryName(expert));
            if (File.Exists(expert))
            {
                if (FileHash(expert) != binaryHash) throw new UserMessage(Lang.T("فایل هم‌نام گزارش‌خوان زنده متفاوت است؛ هیچ فایل موجودی جایگزین نشد.", "An existing live reporter file differs; no existing file was replaced."));
            }
            else File.Copy(binary, expert, false);
            Cancelled(cancel);
            string presetPath = Path.Combine(root, Kinds.Mql(copy.Kind), "Presets", ExpertName + "-" + token + ".set");
            Directory.CreateDirectory(Path.GetDirectoryName(presetPath));
            Encoding encoding = copy.Kind == Kind.MT5 ? Encoding.Unicode : Encoding.Default;
            if (File.Exists(presetPath))
            {
                if (File.ReadAllText(presetPath, encoding) != preset)
                    throw new UserMessage(Lang.T("تنظیمات این جلسه تغییر کرده؛ جلسهٔ جدید بسازید. فایل قبلی دست‌نخورده ماند.", "This session's settings differ; create a new session. The existing preset was preserved."));
            }
            else
                using (var file = new FileStream(presetPath, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var writer = new StreamWriter(file, encoding)) writer.Write(preset);
            string output = OutputPath(copy, token);
            Directory.CreateDirectory(output);
            Cancelled(cancel);
            LiveChartPolicy.PreserveCharts(copy);
            var result = new LiveReporterDeployment { CopyName = copy.Name, Platform = copy.Kind.ToString(), ExpertPath = expert,
                PresetPath = presetPath, OutputDirectory = output, SourceHash = sourceHash };
            result.Instructions = InstructionsFor(result);
            return result;
        }

        public static string InstructionsFor(LiveReporterDeployment deployment)
        {
            string permissions = deployment.Platform == Kind.MT4.ToString()
                ? Lang.T("مجوز معامله لازم نیست. در MT4 نمایش موجودی و معاملات باز بدون DLL کار می‌کند؛ اما برای تأیید تاریخچهٔ کامل و محاسبهٔ دراودان معتبر، این اکسپرت به Allow DLL imports نیاز دارد تا All History را انتخاب کند. انتخاب دستی All History به‌تنهایی در این نسخه تأیید کامل محسوب نمی‌شود. بدون این مجوز، تاریخچه تأییدنشده می‌ماند.", "Trading permission is not needed. In MT4, balances and open positions work without DLL permission; this EA requires Allow DLL imports to select All History and confirm full history for trusted drawdown. Selecting All History manually alone is not accepted as full-history confirmation in this version. Without DLL permission, history remains unconfirmed.")
                : Lang.T("مجوز معامله یا DLL برای این گزارش‌خوان MT5 لازم نیست.", "This MT5 reporter does not require trading or DLL permissions.");
            return Lang.T("فایل آماده شد؛ هنوز به چارت متصل نشده است.\n۱. در همین متاتریدر یک چارت جدید باز کنید؛ از چارت دارای اکسپرت استفاده نکنید.\n۲. در Navigator > Expert Advisors راست‌کلیک و Refresh کنید؛ گزارش‌خوان همین پوشه را روی چارت جدید قرار دهید:\n", "Prepared; not yet attached to a chart.\n1. Open a NEW chart in this terminal; do not use a chart with an existing EA.\n2. Right-click Navigator > Expert Advisors, choose Refresh, then attach the reporter from this folder to the new chart:\n") +
                Path.GetDirectoryName(deployment.ExpertPath) + "\n" +
                Lang.T("۳. در Inputs گزینهٔ Load را بزنید و این فایل را انتخاب کنید:\n", "3. In Inputs, choose Load and select this preset:\n") + deployment.PresetPath + "\n" +
                Lang.T("۴. تأیید کنید و این چارت را باز نگه دارید. ", "4. Confirm and keep this chart open. ") + permissions + "\n" +
                Lang.T("اگر قبلاً MTManagerLive روی همین حساب متصل شده، پیش از اتصال نسخهٔ جدید فقط گزارش‌خوان قبلی MTManagerLive را بردارید یا چارت اختصاصی آن را ببندید؛ به اکسپرت‌های دیگر دست نزنید. هر جلسه فقط یک گزارش‌خوان دارد.\nبرنامه زمانی اتصال زنده را نشان می‌دهد که پیام تازه از همان حساب دریافت کند. چارت‌های این نسخه در اجراهای بعدی توسط MetaFactory خالی یا کم نمی‌شوند؛ بعد از بازکردن دوبارهٔ متاتریدر، حضور گزارش‌خوان روی چارت ذخیره‌شده را بررسی کنید.\nاین آماده‌سازی، متاتریدر را باز یا بسته نکرده و اکسپرت‌ها و محتوای پروفایل‌های قبلی را تغییر نداده است.", "If MTManagerLive is already attached for this account, remove ONLY the previous MTManagerLive observer or close its dedicated chart before attaching the new version; leave other EAs untouched. Each session permits only one observer.\nThe app will show live readiness only after receiving a fresh message from the expected account. MetaFactory will preserve this copy's charts on subsequent launches; after reopening the terminal, verify that the reporter remains attached to the saved chart.\nPreparation has not opened/closed the terminal or changed existing EAs or profile contents.");
        }
    }
}
