using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Xml;

namespace MTManager
{
    public sealed class SheetRow
    {
        public int Number;
        public string Problem = "";
        public readonly Dictionary<int, string> Cells = new Dictionary<int, string>();
        public readonly HashSet<int> Numeric = new HashSet<int>();
    }

    /// <summary>Small, bounded Open XML reader/writer. No Office installation, macros or formula evaluation.</summary>
    public static class Spreadsheet
    {
        const string Ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        const string Rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        const long MaxXml = 16 * 1024 * 1024;

        static XmlDocument Xml(ZipArchive zip, string path, bool optional = false)
        {
            ZipArchiveEntry entry = zip.GetEntry(path);
            if (entry == null)
            {
                if (optional) return null;
                throw new InvalidDataException(Lang.T("ساختار فایل Excel کامل نیست: ", "Incomplete Excel file: ") + path);
            }
            if (entry.Length > MaxXml) throw new InvalidDataException("Excel XML is too large.");
            var doc = new XmlDocument { XmlResolver = null };
            using (Stream input = entry.Open())
            using (XmlReader r = XmlReader.Create(input, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = MaxXml })) doc.Load(r);
            return doc;
        }

        static string Text(XmlNode node)
        {
            return string.Concat(node.SelectNodes(".//*[local-name()='t']").Cast<XmlNode>().Select(n => n.InnerText));
        }

        static int Column(string cell)
        {
            int n = 0;
            foreach (char c in cell)
            {
                if (c < 'A' || c > 'Z') break;
                n = checked(n * 26 + c - 'A' + 1);
                if (n > 64) throw new InvalidDataException(Lang.T("حداکثر ۶۴ ستون پشتیبانی می‌شود.", "At most 64 columns are supported."));
            }
            if (n == 0) throw new InvalidDataException("Invalid Excel cell reference.");
            return n - 1;
        }

        public static List<SheetRow> Read(string path) { return Read(path, false); }
        public static List<SheetRow> ReadForImport(string path) { return Read(path, true); }
        static List<SheetRow> Read(string path, bool tolerateRows)
        {
            if (!string.Equals(Path.GetExtension(path), ".xlsx", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException(Lang.T("فایل را در Excel با قالب Excel Workbook (.xlsx) ذخیره کنید؛ فایل قدیمی .xls پشتیبانی نمی‌شود.", "Save as Excel Workbook (.xlsx); old .xls files are not supported."));
            if (new FileInfo(path).Length > 20 * 1024 * 1024) throw new InvalidDataException("Excel file exceeds 20 MB.");
            using (var file = File.OpenRead(path))
            using (var zip = new ZipArchive(file, ZipArchiveMode.Read))
            {
                if (zip.Entries.Count > 2000 || zip.Entries.Sum(e => e.Length) > 64 * 1024 * 1024) throw new InvalidDataException("Excel workbook is too large.");
                XmlDocument book = Xml(zip, "xl/workbook.xml");
                XmlNode sheet = book.SelectSingleNode("//*[local-name()='sheets']/*[local-name()='sheet']");
                if (sheet == null) throw new InvalidDataException("Excel workbook has no worksheet.");
                string id = ((XmlElement)sheet).GetAttribute("id", Rel);
                XmlDocument rels = Xml(zip, "xl/_rels/workbook.xml.rels");
                XmlElement link = rels.DocumentElement.ChildNodes.OfType<XmlElement>().FirstOrDefault(n => n.GetAttribute("Id") == id);
                if (link == null || link.GetAttribute("TargetMode") == "External") throw new InvalidDataException("Invalid worksheet relationship.");
                string target = link.GetAttribute("Target").Replace('\\', '/');
                string sheetPath = target.StartsWith("/") ? target.TrimStart('/') : "xl/" + target;
                if (sheetPath.Split('/').Contains("..")) throw new InvalidDataException("Invalid worksheet path.");
                var shared = new List<string>();
                XmlDocument strings = Xml(zip, "xl/sharedStrings.xml", true);
                if (strings != null) foreach (XmlNode item in strings.SelectNodes("//*[local-name()='si']")) shared.Add(Text(item));
                XmlDocument data = Xml(zip, sheetPath);
                var rows = new List<SheetRow>();
                int lastRow = 0;
                foreach (XmlElement row in data.SelectNodes("//*[local-name()='sheetData']/*[local-name()='row']"))
                {
                    int number;
                    if (!int.TryParse(row.GetAttribute("r"), out number)) number = lastRow + 1;
                    if (number <= lastRow || number > 1048576) throw new InvalidDataException("Invalid Excel row number.");
                    lastRow = number;
                    var result = new SheetRow { Number = number };
                    int next = 0;
                    try
                    {
                    foreach (XmlElement cell in row.ChildNodes.OfType<XmlElement>().Where(n => n.LocalName == "c"))
                    {
                        int col = cell.HasAttribute("r") ? Column(cell.GetAttribute("r")) : next;
                        next = col + 1;
                        if (col >= 64 || result.Cells.ContainsKey(col)) throw new InvalidDataException("Invalid Excel column.");
                        if (cell.SelectSingleNode("*[local-name()='f']") != null)
                            throw new InvalidDataException(Lang.T("فرمول در سطر ", "Formula in row ") + number + Lang.T("؛ ابتدا Paste Values کنید.", "; paste values first."));
                        string type = cell.GetAttribute("t");
                        XmlNode value = cell.SelectSingleNode("*[local-name()='v']");
                        string text = value == null ? "" : value.InnerText;
                        if ((type == "" || type == "n") && text.Length > 0) result.Numeric.Add(col);
                        if (type == "inlineStr") text = Text(cell);
                        else if (type == "s")
                        {
                            int index;
                            if (!int.TryParse(text, out index) || index < 0 || index >= shared.Count) throw new InvalidDataException("Invalid shared string.");
                            text = shared[index];
                        }
                        else if (type == "e") throw new InvalidDataException(Lang.T("خطای Excel در سطر ", "Excel error in row ") + number);
                        if (text.Length > 4096) throw new InvalidDataException("Excel cell exceeds 4096 characters.");
                        result.Cells[col] = text;
                    }
                    }
                    catch (InvalidDataException)
                    {
                        if (!tolerateRows || rows.Count == 0) throw;
                        result.Problem = Lang.T("این ردیف فرمول، خطای Excel یا سلول نامعتبر دارد؛ Paste Values کنید.", "This row has a formula, Excel error or invalid cell; paste values first.");
                    }
                    if (result.Problem.Length == 0 && !result.Cells.Values.Any(v => !string.IsNullOrWhiteSpace(v))) continue;
                    rows.Add(result);
                    if (rows.Count > 1001) throw new InvalidDataException(Lang.T("هر فایل حداکثر ۱۰۰۰ دانشجو داشته باشد.", "Use at most 1,000 students per file."));
                }
                return rows;
            }
        }

        static void Entry(ZipArchive zip, string path, Action<XmlWriter> write)
        {
            using (Stream s = zip.CreateEntry(path).Open())
            using (XmlWriter w = XmlWriter.Create(s, new XmlWriterSettings { Encoding = new UTF8Encoding(false), CloseOutput = false })) write(w);
        }

        static string Letter(int col)
        {
            string s = "";
            for (int n = col + 1; n > 0; n = (n - 1) / 26) s = (char)('A' + (n - 1) % 26) + s;
            return s;
        }

        public static void Write(string path, IList<string[]> rows, string[] guide = null)
        {
            // Stage beside the destination so an interrupted write never truncates an existing workbook.
            string part = path + "." + Guid.NewGuid().ToString("N") + ".part";
            try
            {
                using (var file = File.Create(part))
                using (var zip = new ZipArchive(file, ZipArchiveMode.Create))
                {
                    int sheets = guide == null ? 1 : 2;
                    Entry(zip, "[Content_Types].xml", w => {
                        w.WriteStartElement("Types", "http://schemas.openxmlformats.org/package/2006/content-types");
                        w.WriteStartElement("Default"); w.WriteAttributeString("Extension", "rels"); w.WriteAttributeString("ContentType", "application/vnd.openxmlformats-package.relationships+xml"); w.WriteEndElement();
                        w.WriteStartElement("Default"); w.WriteAttributeString("Extension", "xml"); w.WriteAttributeString("ContentType", "application/xml"); w.WriteEndElement();
                        foreach (string kind in new[] { "workbook", "styles" }) { w.WriteStartElement("Override"); w.WriteAttributeString("PartName", "/xl/" + kind + ".xml"); w.WriteAttributeString("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml." + (kind == "workbook" ? "sheet.main" : "styles") + "+xml"); w.WriteEndElement(); }
                        for (int i = 1; i <= sheets; i++) { w.WriteStartElement("Override"); w.WriteAttributeString("PartName", "/xl/worksheets/sheet" + i + ".xml"); w.WriteAttributeString("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"); w.WriteEndElement(); }
                        w.WriteEndElement();
                    });
                    Entry(zip, "_rels/.rels", w => Relationships(w, new[] { new[] { "rId1", "officeDocument", "xl/workbook.xml" } }));
                    Entry(zip, "xl/workbook.xml", w => {
                        w.WriteStartElement("workbook", Ns); w.WriteStartElement("sheets", Ns);
                        for (int i = 1; i <= sheets; i++) { w.WriteStartElement("sheet", Ns); w.WriteAttributeString("name", i == 1 ? "Students" : "Guide"); w.WriteAttributeString("sheetId", i.ToString()); w.WriteAttributeString("r", "id", Rel, "rId" + i); w.WriteEndElement(); }
                        w.WriteEndElement(); w.WriteEndElement();
                    });
                    Entry(zip, "xl/_rels/workbook.xml.rels", w => {
                        var links = new List<string[]>();
                        for (int i = 1; i <= sheets; i++) links.Add(new[] { "rId" + i, "worksheet", "worksheets/sheet" + i + ".xml" });
                        links.Add(new[] { "style", "styles", "styles.xml" }); Relationships(w, links);
                    });
                    Entry(zip, "xl/styles.xml", w => {
                        w.WriteStartElement("styleSheet", Ns);
                        w.WriteStartElement("fonts", Ns); w.WriteAttributeString("count", "1"); w.WriteStartElement("font", Ns); w.WriteStartElement("sz", Ns); w.WriteAttributeString("val", "11"); w.WriteEndElement(); w.WriteStartElement("name", Ns); w.WriteAttributeString("val", "Calibri"); w.WriteEndElement(); w.WriteEndElement(); w.WriteEndElement();
                        w.WriteStartElement("fills", Ns); w.WriteAttributeString("count", "2"); foreach (string pattern in new[] { "none", "gray125" }) { w.WriteStartElement("fill", Ns); w.WriteStartElement("patternFill", Ns); w.WriteAttributeString("patternType", pattern); w.WriteEndElement(); w.WriteEndElement(); } w.WriteEndElement();
                        w.WriteStartElement("borders", Ns); w.WriteAttributeString("count", "1"); w.WriteElementString("border", Ns, ""); w.WriteEndElement();
                        foreach (string section in new[] { "cellStyleXfs", "cellXfs" }) { w.WriteStartElement(section, Ns); w.WriteAttributeString("count", "1"); w.WriteStartElement("xf", Ns); w.WriteAttributeString("numFmtId", "49"); w.WriteAttributeString("fontId", "0"); w.WriteAttributeString("fillId", "0"); w.WriteAttributeString("borderId", "0"); if (section == "cellXfs") { w.WriteAttributeString("xfId", "0"); w.WriteAttributeString("applyNumberFormat", "1"); } w.WriteEndElement(); w.WriteEndElement(); }
                        w.WriteStartElement("cellStyles", Ns); w.WriteAttributeString("count", "1"); w.WriteStartElement("cellStyle", Ns); w.WriteAttributeString("name", "Normal"); w.WriteAttributeString("xfId", "0"); w.WriteAttributeString("builtinId", "0"); w.WriteEndElement(); w.WriteEndElement();
                        w.WriteEndElement();
                    });
                    Entry(zip, "xl/worksheets/sheet1.xml", w => Sheet(w, rows, true));
                    if (guide != null) Entry(zip, "xl/worksheets/sheet2.xml", w => Sheet(w, guide.Select(t => new[] { t }).ToList(), false));
                }
                if (File.Exists(path)) File.Replace(part, path, null); else File.Move(part, path);
            }
            finally { if (File.Exists(part)) File.Delete(part); }
        }

        static void Relationships(XmlWriter w, IEnumerable<string[]> links)
        {
            w.WriteStartElement("Relationships", "http://schemas.openxmlformats.org/package/2006/relationships");
            foreach (string[] link in links) { w.WriteStartElement("Relationship"); w.WriteAttributeString("Id", link[0]); w.WriteAttributeString("Type", Rel + "/" + link[1]); w.WriteAttributeString("Target", link[2]); w.WriteEndElement(); }
            w.WriteEndElement();
        }

        static void Sheet(XmlWriter w, IList<string[]> rows, bool freeze)
        {
            w.WriteStartElement("worksheet", Ns);
            w.WriteStartElement("sheetViews", Ns); w.WriteStartElement("sheetView", Ns); w.WriteAttributeString("workbookViewId", "0");
            if (freeze) { w.WriteStartElement("pane", Ns); w.WriteAttributeString("ySplit", "1"); w.WriteAttributeString("topLeftCell", "A2"); w.WriteAttributeString("state", "frozen"); w.WriteEndElement(); }
            w.WriteEndElement(); w.WriteEndElement();
            w.WriteStartElement("cols", Ns); w.WriteStartElement("col", Ns); w.WriteAttributeString("min", "1"); w.WriteAttributeString("max", "64"); w.WriteAttributeString("width", freeze ? "24" : "115"); w.WriteAttributeString("customWidth", "1"); w.WriteAttributeString("style", "0"); w.WriteEndElement(); w.WriteEndElement();
            w.WriteStartElement("sheetData", Ns);
            for (int r = 0; r < rows.Count; r++)
            {
                w.WriteStartElement("row", Ns); w.WriteAttributeString("r", (r + 1).ToString(CultureInfo.InvariantCulture));
                for (int c = 0; c < rows[r].Length; c++)
                {
                    w.WriteStartElement("c", Ns); w.WriteAttributeString("r", Letter(c) + (r + 1)); w.WriteAttributeString("t", "inlineStr"); w.WriteAttributeString("s", "0");
                    w.WriteStartElement("is", Ns); w.WriteStartElement("t", Ns); w.WriteAttributeString("xml", "space", "http://www.w3.org/XML/1998/namespace", "preserve"); w.WriteString(rows[r][c] ?? ""); w.WriteEndElement(); w.WriteEndElement(); w.WriteEndElement();
                }
                w.WriteEndElement();
            }
            w.WriteEndElement(); w.WriteEndElement();
        }
    }
}
