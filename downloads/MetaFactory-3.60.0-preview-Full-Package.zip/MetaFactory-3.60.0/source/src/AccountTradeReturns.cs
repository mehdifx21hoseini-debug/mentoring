using System;using System.Collections.Generic;using System.Globalization;using System.Linq;
namespace MTManager
{
    /// <summary>Reconstructs actual pre-entry account balance from verified balance events, including funding/withdrawals.
    /// This is a return denominator, independent of normalized account DD and potential SL risk.</summary>
    internal sealed class AccountTradeReturns
    {
        readonly JournalBalanceEvent[] events=new JournalBalanceEvent[0];readonly double[] prefix=new double[1];
        readonly Dictionary<long,List<JournalDeal>> deals=new Dictionary<long,List<JournalDeal>>();
        readonly Dictionary<long,JournalBalanceEvent> byTicket=new Dictionary<long,JournalBalanceEvent>();
        readonly bool valid,mt5;readonly DateTime exported;
        static readonly DateTime Epoch=new DateTime(1970,1,1);
        static bool Finite(double n){return !double.IsNaN(n)&&!double.IsInfinity(n);}
        internal AccountTradeReturns(AccountJournal journal)
        {
            if(journal==null||!journal.Complete||!journal.HistoryChecked||!journal.HistoryOk||!journal.FullHistoryPresent||!journal.FullHistoryValid||!journal.FullHistoryReconciled||!journal.FullHistoryScanOk||!journal.FullHistoryRequested||!Finite(journal.Balance))return;
            mt5=journal.Platform=="MT5";if(!mt5&&journal.Platform!="MT4")return;exported=journal.Exported;
            var ledger=journal.FullHistory.OrderBy(e=>e.TimeMilliseconds).ThenBy(e=>e.Ticket).ToArray();
            if(ledger.Length!=journal.FullHistoryCount||ledger.Length==0||ledger.Any(e=>e.TimeMilliseconds<=0||!Finite(e.Net))||ledger.Select(e=>e.Ticket).Distinct().Count()!=ledger.Length)return;
            double total=ledger.Sum(e=>e.Net),tolerance=Math.Max(.02,Math.Abs(journal.Balance)*.000001);
            if(!Finite(total)||Math.Abs(total-journal.Balance)>tolerance)return;
            events=ledger;prefix=new double[events.Length+1];for(int i=0;i<events.Length;i++){prefix[i+1]=prefix[i]+events[i].Net;byTicket[events[i].Ticket]=events[i];}
            foreach(var group in journal.Deals.GroupBy(d=>d.Position))deals[group.Key]=group.ToList();valid=true;
        }
        int Lower(long time){int lo=0,hi=events.Length;while(lo<hi){int mid=lo+(hi-lo)/2;if(events[mid].TimeMilliseconds<time)lo=mid+1;else hi=mid;}return lo;}
        internal double EntryBalance(long ticket,DateTime opened,bool closed)
        {
            if(!valid||opened<=Epoch||opened>exported)return double.NaN;
            long start=(opened.Ticks-Epoch.Ticks)/TimeSpan.TicksPerMillisecond;long end=start+999;bool precise=false;
            List<JournalDeal> own;deals.TryGetValue(ticket,out own);var knownOwn=new HashSet<long>();
            if(mt5&&own!=null)
            {
                var entries=own.Where(d=>(d.Type==0||d.Type==1)&&d.Entry==0).Select(d=>{JournalBalanceEvent item;return byTicket.TryGetValue(d.Ticket,out item)?item:null;}).Where(e=>e!=null&&e.TimeMilliseconds>=start&&e.TimeMilliseconds<=end).ToList();
                if(entries.Count>0){start=entries.Min(e=>e.TimeMilliseconds);end=start;precise=true;foreach(var deal in own.Where(d=>d.Type==0||d.Type==1))knownOwn.Add(deal.Ticket);}
            }
            int index=Lower(start);
            // A different balance-changing event at the same entry timestamp/second has unknown ordering.
            // Own entry charges or an immediate own close are known to follow the position's initial entry.
            for(int i=index;i<events.Length&&events[i].TimeMilliseconds<=end;i++)
            {
                var item=events[i];if(Math.Abs(item.Net)<1e-12)continue;
                bool ownAfterEntry=mt5?precise&&knownOwn.Contains(item.Ticket):closed&&item.Ticket==ticket&&(item.Type==0||item.Type==1);
                if(!ownAfterEntry)return double.NaN;
            }
            double balance=prefix[index];return Finite(balance)&&balance>0?balance:double.NaN;
        }
        internal static double Percent(double net,double entryBalance)
        {if(!Finite(net)||!Finite(entryBalance)||entryBalance<=0)return double.NaN;double n=net/entryBalance*100;return Finite(n)?n:double.NaN;}
        internal static string PercentText(double n)
        {return !Finite(n)?"—":Math.Round(n,2,MidpointRounding.AwayFromZero).ToString("+0.00;-0.00;0.00",CultureInfo.InvariantCulture)+"%";}
        internal static string ResultText(PanelTrade trade,string currency)
        {return PanelMath.Money(trade.Net,currency)+" · "+PercentText(trade.ResultPct)+(trade.Closed?"":Lang.T(" شناور"," floating"));}
    }
}
