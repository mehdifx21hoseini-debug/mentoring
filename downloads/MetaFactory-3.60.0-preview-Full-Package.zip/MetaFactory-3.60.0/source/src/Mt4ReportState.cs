using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace MTManager
{
    // A native observation for one request, not proof of a complete report. The report's existing
    // account/server/nonce validation remains the only successful-result acceptance path.
    internal sealed class Mt4ReportState
    {
        public string Stage, RequestedLogin, RequestedServer, ActualLogin, ActualServer;
        public bool Connected;
        public long ElapsedMilliseconds;
        public bool MatchingConnected
        {
            get { return Connected && ActualLogin == RequestedLogin && string.Equals(ActualServer, RequestedServer, StringComparison.OrdinalIgnoreCase); }
        }
        public bool Waiting { get { return Stage == "waiting-login" || Stage == "waiting-account" || Stage == "waiting-server"; } }
        public bool HistoryStarted { get { return Stage == "connected" || Stage == "history" || Stage == "writing" || Stage == "done"; } }

        static bool ValidToken(string token) { return token != null && token.Length == 32 && token.All(Uri.IsHexDigit); }
        static string Single(string value) { return (value ?? "").Trim(); }
        static bool SafeIdentity(string value) { return !string.IsNullOrWhiteSpace(value) && value.IndexOfAny(new[] { '\r', '\n', '\t' }) < 0; }

        public static Mt4ReportState TryParse(string text, string token, Account account)
        {
            if (string.IsNullOrEmpty(text) || text.Length > 4096 || !ValidToken(token) || account == null) return null;
            string login = Single(account.Login), server = Single(account.Server);
            if (!SafeIdentity(login) || !SafeIdentity(server)) return null;
            string[] lines = text.TrimEnd('\r', '\n').Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            if (lines.Length != 7 || lines[0] != "MTS\t1" || lines[1] != "Q\t" + token || lines[6] != "END") return null;
            string[] expected = lines[2].Split('\t'), stage = lines[3].Split('\t'), time = lines[4].Split('\t'), actual = lines[5].Split('\t');
            long elapsed;
            if (expected.Length != 3 || expected[0] != "A" || expected[1] != login || !string.Equals(expected[2], server, StringComparison.OrdinalIgnoreCase)
                || stage.Length != 2 || stage[0] != "S" || time.Length != 2 || time[0] != "T"
                || !long.TryParse(time[1], NumberStyles.None, CultureInfo.InvariantCulture, out elapsed) || elapsed < 0 || elapsed > uint.MaxValue
                || actual.Length != 4 || actual[0] != "C" || actual[3] != "0" && actual[3] != "1") return null;
            string[] phases = { "waiting-login", "waiting-account", "waiting-server", "connected", "history", "writing", "done", "failed", "deferred" };
            if (!phases.Contains(stage[1])) return null;
            var state = new Mt4ReportState { Stage = stage[1], RequestedLogin = login, RequestedServer = server,
                ActualLogin = actual[1], ActualServer = actual[2], Connected = actual[3] == "1", ElapsedMilliseconds = elapsed };
            // Inconsistent waiting/connected claims are not grounds to interrupt work.
            if (state.Waiting && state.MatchingConnected || state.Stage == "connected" && !state.MatchingConnected) return null;
            if (state.Stage == "waiting-login" && state.Connected && state.ActualLogin.Length > 0 && state.ActualLogin != "0") return null;
            if (state.Stage == "waiting-account" && (!state.Connected || state.ActualLogin == "0" || state.ActualLogin.Length == 0 || state.ActualLogin == login)) return null;
            if (state.Stage == "waiting-server" && (!state.Connected || state.ActualLogin != login || string.Equals(state.ActualServer, server, StringComparison.OrdinalIgnoreCase))) return null;
            return state;
        }

        static void CheckCopy(Instance copy)
        { if (copy == null || copy.Kind != Kind.MT4) throw new ArgumentException("An MT4 report copy is required.", "copy"); }
        public static string StatePath(Instance copy) { CheckCopy(copy); return ReportLaunch.OutputPath(copy) + ".state"; }
        public static string DeferralPath(Instance copy) { CheckCopy(copy); return ReportLaunch.OutputPath(copy) + ".defer"; }
        public static string[] TemporaryPaths(Instance copy)
        {
            string state = StatePath(copy), defer = DeferralPath(copy);
            return new[] { state, state + ".part", defer, defer + ".part" };
        }
        public static void ClearRequestFiles(Instance copy)
        { foreach (string path in TemporaryPaths(copy)) if (File.Exists(path)) File.Delete(path); }
        public static Mt4ReportState Read(Instance copy, string token, Account account)
        {
            try
            {
                string path = StatePath(copy);
                if (!File.Exists(path) || new FileInfo(path).Length > 8192) return null;
                using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                using (var reader = new StreamReader(stream, Encoding.Unicode, true))
                {
                    char[] buffer = new char[4097]; int total = 0, count;
                    while (total < buffer.Length && (count = reader.Read(buffer, total, buffer.Length - total)) > 0) total += count;
                    return total > 4096 ? null : TryParse(new string(buffer, 0, total), token, account);
                }
            }
            catch (IOException) { return null; }
            catch (UnauthorizedAccessException) { return null; }
        }
        // Cooperative request only: the native script acknowledges it while still in its
        // connection wait. Never kill a terminal merely because this file has been written.
        public static void WriteDeferralRequest(Instance copy, string token, Account account)
        {
            if (!ValidToken(token) || account == null || !SafeIdentity(Single(account.Login)) || !SafeIdentity(Single(account.Server)))
                throw new ArgumentException("A valid report request identity is required.");
            string path = DeferralPath(copy), temporary = path + ".part";
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            try
            {
                File.WriteAllLines(temporary, new[] { "MTD\t1", "Q\t" + token, "A\t" + Single(account.Login) + "\t" + Single(account.Server), "END" }, Encoding.Unicode);
                if (File.Exists(path)) File.Replace(temporary, path, null, true); else File.Move(temporary, path);
            }
            finally { if (File.Exists(temporary)) File.Delete(temporary); }
        }
    }

    internal sealed class Mt4ReportWaitPolicy
    {
        public const long FirstPassMilliseconds = 30000, QuietMilliseconds = 12000, FreshnessMilliseconds = 3500;
        readonly bool firstPass;
        Mt4ReportState latest;
        long lastNativeElapsed = -1, lastObservation, lastProgress;
        string lastIdentity;
        bool advanced, requested;
        public bool HistoryObserved { get; private set; }
        public Mt4ReportWaitPolicy(bool firstPass) { this.firstPass = firstPass; }
        public void Observe(Mt4ReportState state, long elapsedMilliseconds)
        {
            if (state == null || elapsedMilliseconds < 0 || state.ElapsedMilliseconds < lastNativeElapsed) return;
            if (state.MatchingConnected || state.HistoryStarted) HistoryObserved = true;
            string identity = state.Stage + "|" + state.ActualLogin + "|" + state.ActualServer + "|" + state.Connected;
            if (state.ElapsedMilliseconds > lastNativeElapsed)
            {
                if (lastNativeElapsed >= 0) advanced = true;
                lastObservation = elapsedMilliseconds;
                lastNativeElapsed = state.ElapsedMilliseconds;
            }
            if (lastIdentity != identity) { lastIdentity = identity; lastProgress = elapsedMilliseconds; }
            latest = state;
        }
        public bool ShouldRequestDeferral(long elapsedMilliseconds)
        {
            return firstPass && !requested && !HistoryObserved && advanced && latest != null && latest.Waiting && !latest.MatchingConnected
                && elapsedMilliseconds >= FirstPassMilliseconds && elapsedMilliseconds >= lastObservation
                && elapsedMilliseconds - lastObservation <= FreshnessMilliseconds && elapsedMilliseconds - lastProgress >= QuietMilliseconds;
        }
        public void DeferralRequested() { requested = true; }
    }
}
