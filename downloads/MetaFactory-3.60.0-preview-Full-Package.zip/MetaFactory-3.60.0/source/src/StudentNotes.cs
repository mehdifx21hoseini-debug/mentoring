using System;using System.IO;using System.Text;using System.Linq;using System.Collections.Generic;using System.Globalization;using System.Drawing;using System.Windows.Forms;
namespace MTManager
{
    public sealed class StudentNote
    {
        public string Text="";public DateTime UpdatedUtc;
        public StudentNote Snapshot(){return (StudentNote)MemberwiseClone();}
    }
    // Separate from credentials: legacy versions cannot drop appended account columns.
    public sealed class StudentNotes
    {
        public const int MaxLength=20000;
        public static string FilePath{get{return Path.Combine(AppPaths.DataDir,"student-notes.tsv");}}
        readonly Dictionary<string,StudentNote> values=new Dictionary<string,StudentNote>(StringComparer.OrdinalIgnoreCase);
        readonly object sync=new object();public bool Readable{get;private set;}
        public static StudentNotes Load(){var store=new StudentNotes{Readable=true};try{if(!File.Exists(FilePath))return store;foreach(string line in File.ReadAllLines(FilePath,new UTF8Encoding(false,true))){if(line.Length==0||line[0]=='#')continue;var f=line.Split('\t');DateTime when;if(f.Length!=3||!DateTime.TryParseExact(f[2],"o",CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out when))throw new FormatException();string key=Decode(f[0]),text=Decode(f[1]);Validate(key,text);if(!string.IsNullOrWhiteSpace(text))store.values[key]=new StudentNote{Text=text,UpdatedUtc=when.ToUniversalTime()};}}catch(Exception){store.Readable=false;Log.Write("student notes could not be read; existing file retained");}return store;}
        static string Encode(string value){return Convert.ToBase64String(Encoding.UTF8.GetBytes(value??""));}static string Decode(string value){return new UTF8Encoding(false,true).GetString(Convert.FromBase64String(value));}
        static void Validate(string key,string text){if(string.IsNullOrWhiteSpace(key)||key.IndexOfAny(new[]{'\r','\n','\t'})>=0)throw new ArgumentException("Invalid student key.");if((text??"").Length>MaxLength)throw new ArgumentException(Lang.T("یادداشت بیش از حد طولانی است.","The note is too long."));}
        public StudentNote Get(string copy){lock(sync){StudentNote note;return copy!=null&&values.TryGetValue(copy,out note)?note.Snapshot():null;}}
        public void Set(string copy,string text,DateTime utc){var changes=new Dictionary<string,StudentNote>(StringComparer.OrdinalIgnoreCase);changes[copy]=new StudentNote{Text=text??"",UpdatedUtc=utc.ToUniversalTime()};Apply(changes);}
        void Apply(IDictionary<string,StudentNote> changes){lock(sync){if(!Readable)throw new IOException(Lang.T("فایل یادداشت‌ها خوانده نشد؛ برای جلوگیری از پاک شدن اطلاعات ذخیره انجام نشد.","Notes could not be read; saving was blocked to preserve existing data."));var next=new Dictionary<string,StudentNote>(values,StringComparer.OrdinalIgnoreCase);foreach(var item in changes){Validate(item.Key,item.Value.Text);if(string.IsNullOrWhiteSpace(item.Value.Text))next.Remove(item.Key);else next[item.Key]=item.Value.Snapshot();}var lines=new List<string>{"# MetaFactory student notes v1; UTF-8 base64 fields"};foreach(var item in next.OrderBy(x=>x.Key,StringComparer.OrdinalIgnoreCase))lines.Add(Encode(item.Key)+"\t"+Encode(item.Value.Text)+"\t"+item.Value.UpdatedUtc.ToString("o",CultureInfo.InvariantCulture));TextUtil.WriteLinesAtomically(FilePath,lines);values.Clear();foreach(var item in next)values[item.Key]=item.Value;}}
        public static void Restore(BackupData data,IDictionary<string,string> destinations){var changes=new Dictionary<string,StudentNote>(StringComparer.OrdinalIgnoreCase);foreach(var student in data.Students){string target;if(!student.NoteIncluded||!destinations.TryGetValue(student.Copy,out target))continue;changes[target]=new StudentNote{Text=student.NoteText??"",UpdatedUtc=student.NoteUtc.ToUniversalTime()};}if(changes.Count>0)Load().Apply(changes);}
    }
    sealed class StudentNoteDialog : FormDialog
    {
        readonly TextBox editor=new TextBox{Multiline=true,AcceptsReturn=true,AcceptsTab=false,ScrollBars=ScrollBars.Vertical,MaxLength=StudentNotes.MaxLength};
        readonly Action<string> save;
        internal StudentNoteDialog(string name,string account,StudentNote note,Action<string> persist):base(Lang.T("یادداشت ","Note · ")+name,account)
        {
            save=persist;editor.Text=note==null?"":note.Text;editor.Size=Theme.Sz(500,210);editor.Font=Theme.Font;editor.RightToLeft=Theme.Dir;editor.AccessibleName=Lang.T("متن یادداشت دانشجو","Student note text");Wide(editor);
            string edited=note==null?Lang.T("هنوز یادداشتی ذخیره نشده است.","No note saved yet."):Lang.T("آخرین ویرایش: ","Last edited: ")+note.UpdatedUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm",CultureInfo.CurrentCulture);Wide(Theme.Label(edited,500,Theme.Small,Theme.Muted));
            var ok=AddButton(Lang.T("ذخیره","Save"),Save,true);var cancel=AddButton(Lang.T("انصراف","Cancel"),(s,e)=>Close(DialogResult.Cancel));var remove=AddButton(Lang.T("حذف یادداشت","Delete note"),(s,e)=>{if(Ui.Confirm(this,Lang.T("این یادداشت حذف شود؟","Delete this note?"))){editor.Text="";Save(s,e);}});remove.Enabled=note!=null;
            Finish();AcceptButton=ok;CancelButton=cancel;Shown+=(s,e)=>editor.Focus();
        }
        void Save(object sender,EventArgs e){try{save(editor.Text);Close(DialogResult.OK);}catch(Exception error){Ui.Error(this,error);}}
    }
    sealed partial class MainForm
    {
        StudentNotes studentNotes=StudentNotes.Load();
        void EditStudentNote(string copy){var account=accounts.Get(copy);string name=account!=null&&!string.IsNullOrWhiteSpace(account.Trader)?account.Trader:copy;string detail=copy+(account!=null?" · "+account.Login+" · "+account.Server:"");using(var dialog=new StudentNoteDialog(name,detail,studentNotes.Get(copy),text=>studentNotes.Set(copy,text,DateTime.UtcNow)))if(dialog.ShowDialog(this)==DialogResult.OK)ClearChoice();}
        void ConsumeAcceptedSelection(IEnumerable<string> names){if(names.Any()&&chosen.Count>0)ClearChoice();}
    }
}
