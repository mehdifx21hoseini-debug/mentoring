using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace MTManager
{
    sealed class TelegramControlDialog : FormDialog
    {
        readonly CheckBox enabled=new CheckBox{Text=Lang.T("ربات فعال باشد","Enable bot"),AutoSize=true};
        readonly TextBox token=new TextBox{Width=Theme.S(360),UseSystemPasswordChar=true,RightToLeft=RightToLeft.No};
        readonly Label error=Theme.Label("",430,Theme.Small,Theme.Bad);
        readonly TelegramControlOptions original;
        public TelegramControlOptions Options;
        public TelegramControlDialog(TelegramControlOptions options,string status):base(Lang.T("ربات تلگرام","Telegram bot"))
        {
            original=options.Snapshot();enabled.Checked=original.Enabled;token.Text=Secret.Unprotect(original.TokenEnc)??"";
            Wide(enabled);Row(Lang.T("توکن ربات","Bot token"),token);
            Wide(Theme.Label(Lang.T("گزارش عمومی: هر کسی که در گفتگوی خصوصی ربات /start بزند، منوها را می‌بیند و می‌تواند گزارش حساب‌های متافکتوری را دریافت کند. واردکردن شناسه لازم نیست.","Public reports: anyone who sends /start privately can use the menus and request this MetaFactory installation's account reports. No user IDs are required."),430,Theme.Font,Theme.Text));
            Wide(Theme.Label(Lang.T("توکن را وارد کن، ربات را فعال و ذخیره کن. رایانه و متافکتوری باید روشن و اینترنت متصل بمانند.","Enter the token, enable the bot and save. Keep this PC and MetaFactory online."),430,Theme.Small,Theme.Muted));
            if(!string.IsNullOrEmpty(original.LoadError))Wide(Theme.Label(original.LoadError,430,Theme.Small,Theme.Warn));
            if(!string.IsNullOrEmpty(status))Wide(Theme.Label(status,430,Theme.Small,Theme.Muted));
            Wide(error);error.Visible=false;
            AddButton(Lang.T("ورود فایل اتصال…","Import connection…"),(s,e)=>Import());
            AddButton(Lang.T("ذخیره و اتصال","Save and connect"),(s,e)=>Save(),true);
            var cancel=AddButton(Lang.T("انصراف","Cancel"),null);cancel.DialogResult=DialogResult.Cancel;CancelButton=cancel;Finish();
        }
        void Import()
        {
            using(var d=new OpenFileDialog{Filter="MetaFactory bot connection (*.mfbot)|*.mfbot",CheckFileExists=true})
            {
                if(d.ShowDialog(this)!=DialogResult.OK)return;
                try{if(new FileInfo(d.FileName).Length>65536)throw new IOException();var data=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(d.FileName));object value;if(!data.TryGetValue("token",out value)||!TelegramControlOptions.ValidToken(Convert.ToString(value)))throw new IOException();token.Text=Convert.ToString(value);enabled.Checked=false;error.ForeColor=Theme.Accent;error.Text=Lang.T("توکن وارد شد؛ ربات را فعال و ذخیره کن.","Token imported; enable the bot and save.");error.Visible=true;}catch{error.ForeColor=Theme.Bad;error.Text=Lang.T("فایل اتصال معتبر نیست.","Invalid connection file.");error.Visible=true;}
            }
        }
        void Save()
        {
            try
            {
                var next=original.Snapshot();next.Enabled=enabled.Checked;next.PublicReports=true;next.TokenEnc=token.Text==(Secret.Unprotect(original.TokenEnc)??"")?original.TokenEnc:Secret.Protect(token.Text.Trim());next.LoadError=null;
                string problem=next.Problem();if(problem!=null)throw new ArgumentException(problem);Options=next;DialogResult=DialogResult.OK;Close();
            }
            catch(ArgumentException e){error.ForeColor=Theme.Bad;error.Text=e.Message;error.Visible=true;}catch{error.ForeColor=Theme.Bad;error.Text=Lang.T("ذخیرهٔ امن توکن ناموفق بود.","Secure token storage failed.");error.Visible=true;}
        }
    }
    sealed class TelegramUserPicker : Form
    {
        readonly DataGridView grid=new DataGridView{Dock=DockStyle.Fill,AllowUserToAddRows=false,AllowUserToDeleteRows=false,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,RowHeadersVisible=false,BackgroundColor=Theme.Surface};
        public List<TelegramUser> Chosen=new List<TelegramUser>();
        public TelegramUserPicker(List<TelegramCandidate> candidates)
        {
            Text=Lang.T("انتخاب کاربران مجاز","Choose allowed users");Font=Theme.Font;StartPosition=FormStartPosition.CenterParent;ShowInTaskbar=false;MinimizeBox=false;ClientSize=Theme.Sz(600,330);
            var select=new DataGridViewCheckBoxColumn{HeaderText=Lang.T("انتخاب","Allow"),FillWeight=15};grid.Columns.Add(select);
            grid.Columns.Add(new DataGridViewTextBoxColumn{HeaderText=Lang.T("کاربر / شناسه","User / ID"),ReadOnly=true,FillWeight=60});
            var role=new DataGridViewComboBoxColumn{HeaderText=Lang.T("نقش","Role"),FillWeight=25};role.Items.AddRange("report","admin");grid.Columns.Add(role);
            foreach(var c in candidates){int row=grid.Rows.Add(false,c.Name+" · "+c.Id,"report");grid.Rows[row].Tag=c.Id;}
            var note=Theme.Label(Lang.T("فقط کاربران موردنظر را تیک بزن. report: فقط گزارش؛ admin: مدیریت اجرا و بستن. هیچ‌کس پیش‌فرض انتخاب نشده است.","Select only intended users. report: reports only; admin: open/close management. Nobody is selected by default."),560,Theme.Small,Theme.Muted);note.Dock=DockStyle.Top;note.Height=Theme.S(55);
            var buttons=new ButtonRow{Dock=DockStyle.Bottom};var add=buttons.Add(new ModernButton(Lang.T("افزودن انتخاب‌شده‌ها","Add selected"),ButtonKind.Primary));add.Click+=(s,e)=>{grid.EndEdit();foreach(DataGridViewRow row in grid.Rows)if(object.Equals(row.Cells[0].Value,true))Chosen.Add(new TelegramUser{Id=(long)row.Tag,Admin=Convert.ToString(row.Cells[2].Value)=="admin"});DialogResult=DialogResult.OK;Close();};var cancel=buttons.Add(new ModernButton(Lang.T("انصراف","Cancel"),ButtonKind.Secondary));cancel.Click+=(s,e)=>Close();Controls.Add(grid);Controls.Add(note);Controls.Add(buttons);CancelButton=cancel;
        }
    }
    partial class MainForm
    {
        TelegramControlOptions telegramOptions;
        TelegramControl telegramControl;
        TelegramControlOptions baleOptions;
        TelegramControl baleControl;
        string baleStatus="";
        string telegramStatus="";
        bool telegramStarting;
        readonly Timer telegramTimer=new Timer{Interval=1000};
        sealed class TelegramBatch
        {
            public TelegramRequest Request;
            public DateTime Deadline;
            public List<Instance> Copies;
            public readonly HashSet<string> Live=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            public readonly Dictionary<string,AccountJournal> Journals=new Dictionary<string,AccountJournal>(StringComparer.OrdinalIgnoreCase);
            public TaskCompletionSource<string> Completion;
        }
        TelegramBatch telegramBatch;
        string TelegramDiagnostics()
        {
            return "\r\n— Telegram control (no credentials or user IDs) —\r\nEnabled="+(telegramOptions!=null&&telegramOptions.Enabled)+" public-reports="+(telegramOptions!=null&&telegramOptions.PublicReports)+" configured-users="+(telegramOptions==null?0:telegramOptions.Users.Count)+" connected="+(telegramControl!=null&&telegramControl.Connected)+" pending-accounts="+(telegramBatch==null?0:telegramBatch.Copies.Count)+"\r\nTelegram status: "+TextUtil.OneLine(telegramStatus??"")+"\r\nBale enabled="+(baleOptions!=null&&baleOptions.Enabled)+" connected="+(baleControl!=null&&baleControl.Connected)+" status="+TextUtil.OneLine(baleStatus??"")+"\r\n";
        }
        void InitializeTelegram()
        {
            telegramOptions=TelegramControlStore.Load();baleOptions=new TelegramControlOptions{Channel="Bale",PublicReports=true};if(scheduleOptions!=null&&scheduleOptions.BotSettingsUnified)ApplyBotSettings(scheduleOptions,false);telegramTimer.Tick+=(s,e)=>{try{TelegramTick();}catch{var failed=telegramBatch;telegramBatch=null;if(failed!=null)failed.Completion.TrySetResult("خواندن وضعیت ناموفق بود؛ اطلاعات مالی ارسال نشد.");}};telegramTimer.Start();RestartTelegram();RestartBot("Bale");
            FormClosed+=(s,e)=>{if(telegramControl!=null)telegramControl.Dispose();if(baleControl!=null)baleControl.Dispose();if(telegramBatch!=null)telegramBatch.Completion.TrySetResult("برنامه بسته شد؛ خروجی تازه ارسال نشد.");telegramTimer.Stop();telegramTimer.Dispose();};
        }
        sealed class TelegramRecipientDialog : FormDialog
        {
            readonly ComboBox recipient=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList,Width=Theme.S(270)};
            readonly ComboBox range=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList,Width=Theme.S(270)};
            readonly List<TelegramUser> users;
            public long Recipient;
            public string Range;
            public TelegramRecipientDialog(List<TelegramUser> users,int count,string channel="Telegram"):base(Lang.T("ارسال گزارش به ","Send report to ")+(channel=="Bale"?Lang.T("بله","Bale"):Lang.T("تلگرام","Telegram")))
            {
                this.users=users;foreach(var user in users)recipient.Items.Add((string.IsNullOrWhiteSpace(user.Name)?Lang.T("کاربر تلگرام","Telegram user"):user.Name)+" · "+user.Id.ToString(CultureInfo.InvariantCulture));recipient.SelectedIndex=0;
                range.Items.AddRange(new[]{Lang.T("امروز","Today"),Lang.T("دیروز","Yesterday"),Lang.T("این هفته","This week"),Lang.T("این ماه","This month")});range.SelectedIndex=0;
                Wide(Theme.Label(Lang.T("گزارش تازه برای ","Fresh report for ")+count+Lang.T(" حسابِ انتخاب‌شده در فهرست؛ گیرنده را مشخص کن."," accounts from the current selection/list. Choose a recipient."),420,Theme.Font,Theme.Text));
                Row(Lang.T("گیرندهٔ مجاز","Allowed recipient"),recipient);Row(Lang.T("بازه","Range"),range);
                AddButton(Lang.T("گرفتن گزارش تازه و ارسال","Read fresh and send"),(s,e)=>{Recipient=this.users[recipient.SelectedIndex].Id;Range=new[]{"today","yesterday","week","month"}[range.SelectedIndex];DialogResult=DialogResult.OK;Close();},true);
                var cancel=AddButton(Lang.T("انصراف","Cancel"),null);cancel.DialogResult=DialogResult.Cancel;CancelButton=cancel;Finish();
            }
        }
        void SendTelegramNow(){SendBotNow("Telegram");}
        void SendBaleNow(){SendBotNow("Bale");}
        void SendBotNow(string channel)
        {
            var service=BotService(channel);var options=BotOptions(channel);
            if(service==null||options==null||!options.Enabled||!service.Connected){Ui.Message(this,Lang.T("ابتدا ربات را از تنظیمات ← ربات‌ها و ارسال متصل کن.","First connect the bot in Settings > Bots and delivery."));return;}
            var names=new HashSet<string>((chosen.Count>0?Chosen():shown.ToList()).Select(c=>c.Name),StringComparer.OrdinalIgnoreCase);
            var targets=TelegramCatalog().Where(t=>names.Contains(t.Key)).ToList();if(targets.Count==0)return;
            var connector=service;
            var recipients=connector.Recipients();if(recipients.Count==0){Ui.Message(this,Lang.T("ابتدا در ربات /start بفرست تا گفتگوی خودت به گیرنده‌ها اضافه شود؛ نیازی به واردکردن شناسه نیست.","Send /start to the bot first; your chat will appear as a recipient automatically. No ID entry is needed."));return;}
            using(var dialog=new TelegramRecipientDialog(recipients,targets.Count,channel))if(dialog.ShowDialog(this)==DialogResult.OK)
            {
                if(connector!=BotService(channel)||!connector.QueueReport(dialog.Recipient,targets,dialog.Range)){SetStatus(Lang.T("ربات آماده نیست یا درخواست دیگری در جریان است.","Bot unavailable or another request is active."));return;}
                ConsumeAcceptedSelection(targets.Select(t=>t.Key));SetStatus(Lang.T("درخواست گزارش تازه برای تلگرام ثبت شد؛ نتیجه به گیرنده ارسال می‌شود.","Fresh Telegram report requested; results will be sent to the chosen recipient."));
            }
        }
        void EditTelegram(){EditSettingsPage(true);}
        TelegramControlOptions BotOptions(string channel){return channel=="Bale"?baleOptions:telegramOptions;}
        TelegramControl BotService(string channel){return channel=="Bale"?baleControl:telegramControl;}
        string BotStatus(string channel){return channel=="Bale"?baleStatus:telegramStatus;}
        ScheduleOptions BotSettingsForEditor()
        {
            var view=(scheduleOptions??new ScheduleOptions()).Snapshot();
            if(!view.BotSettingsUnified)
            {
                var legacy=telegramOptions??TelegramControlStore.Load();
                if(legacy.Enabled||string.IsNullOrEmpty(view.TelegramTokenEnc))view.TelegramTokenEnc=legacy.TokenEnc;
                view.TelegramBotEnabled=legacy.Enabled;view.BaleBotEnabled=baleOptions!=null&&baleOptions.Enabled;
                view.BotSettingsUnified=true;view.BotSettingsMigrationPending=true;
            }
            return view;
        }
        void ApplyBotSettings(ScheduleOptions value,bool restart=true)
        {
            foreach(string channel in new[]{"Telegram","Bale"})
            {
                var old=BotOptions(channel);var next=(old??new TelegramControlOptions()).Snapshot();next.Channel=channel;next.PublicReports=true;
                next.TokenEnc=channel=="Bale"?value.BaleTokenEnc:value.TelegramTokenEnc;next.Enabled=channel=="Bale"?value.BaleBotEnabled:value.TelegramBotEnabled;
                if(old!=null&&old.Enabled==next.Enabled&&old.TokenEnc==next.TokenEnc&&old.PublicReports==next.PublicReports&&old.Channel==next.Channel)continue;
                if(channel=="Bale")baleOptions=next;else telegramOptions=next;
                if(restart)RestartBot(channel);
            }
        }
        T TelegramOnUi<T>(Func<T> action)
        {
            if(appClosing||IsDisposed||!IsHandleCreated)throw new InvalidOperationException();
            return (T)Invoke(action);
        }
        void RestartTelegram(){RestartBot("Telegram");}
        void RestartBot(string channel)
        {
            var previous=BotService(channel);if(previous!=null)previous.Dispose();if(channel=="Bale")baleControl=null;else telegramControl=null;
            if(telegramBatch!=null&&telegramBatch.Request.Channel==channel){telegramBatch.Completion.TrySetResult("تنظیمات ربات تغییر کرد؛ این درخواست لغو شد.");telegramBatch=null;}
            var epoch=BotOptions(channel);string text=epoch!=null&&epoch.Enabled?"در حال اتصال به ربات…":"ربات خاموش است.";
            if(channel=="Bale")baleStatus=text;else telegramStatus=text;
            if(epoch==null||!epoch.Enabled)return;string problem=epoch.Problem();if(problem!=null){if(channel=="Bale")baleStatus=problem;else telegramStatus=problem;return;}
            var service=new TelegramControl(epoch,new TelegramApi(Secret.Unprotect(epoch.TokenEnc),channel),()=>TelegramOnUi(()=>TelegramCatalog()),request=>TelegramOnUi(()=>TelegramExecute(request,epoch)),status=>{try{BeginInvoke((Action)(()=>{if(BotOptions(channel)==epoch&&!appClosing){if(channel=="Bale")baleStatus=status;else telegramStatus=status;}}));}catch{}});
            if(channel=="Bale")baleControl=service;else telegramControl=service;service.Start();
        }
        List<TelegramTarget> TelegramCatalog()
        {
            return copies.Where(c=>{var a=accounts.Get(c.Name);return a!=null&&a.HasLogin;}).Select(c=>{var a=accounts.Get(c.Name);return new TelegramTarget{Key=c.Name,Name=string.IsNullOrWhiteSpace(a.Trader)?c.Name:a.Trader,Login=a.Login,Identity=a.CredentialKey,Folders=folders.Of(c.Name).ToDictionary(f=>f.Id,f=>f.Name)};}).ToList();
        }
        List<Instance> TelegramTargets(TelegramRequest request)
        {
            var result=new List<Instance>();foreach(var target in request.Targets)
            {
                var copy=copies.FirstOrDefault(c=>c.Name==target.Key);var account=accounts.Get(target.Key);
                if(copy==null||account==null||account.CredentialKey!=target.Identity)throw new InvalidOperationException("Account identity changed");result.Add(copy);
            }
            return result.GroupBy(c=>c.Name,StringComparer.OrdinalIgnoreCase).Select(g=>g.First()).ToList();
        }
        Task<string> TelegramExecute(TelegramRequest request,TelegramControlOptions epoch)
        {
            var currentOptions=BotOptions(request.Channel);
            if(appClosing||currentOptions!=epoch||!currentOptions.Enabled||!currentOptions.Allowed(request.User))return Task.FromResult("دسترسی یا اتصال تغییر کرده است.");
            List<Instance> targets;try{targets=TelegramTargets(request);}catch{return Task.FromResult("اطلاعات حساب تغییر کرده؛ دوباره از منو انتخاب کن.");}
            if(request.Kind=="status"||request.Kind=="live")
            {
                var text=new StringBuilder("وضعیت متافکتوری\n");foreach(var c in targets){var st=StudentOf(c);text.AppendLine(accounts.Get(c.Name).Trader+" · "+accounts.Get(c.Name).Login+" | "+(st.LiveCurrent?"گزارش زنده تأییدشده":"گزارش زنده تأیید نشده")+(st.LiveFeed!=null?" | UTC: "+st.LiveFeed.HeartbeatUtc.ToString("u",CultureInfo.InvariantCulture):""));}return Task.FromResult(text.ToString());
            }
            if(request.Kind.StartsWith("execute:"))
            {
                if(!currentOptions.Administrator(request.User))return Task.FromResult("فقط مدیر مجاز است.");
                if(!ScheduleIdle||reportRepairActive)return Task.FromResult("کار دیگری در برنامه در جریان است؛ پس از پایان دوباره امتحان کن.");
                string operation=request.Kind.Substring(8);
                if(operation=="open")AcceptManualLaunch(targets,1,true);
                else if(operation=="review")CloseCopies(targets,CloseCopyKind.Review);
                else if(operation=="primary")CloseCopies(targets,CloseCopyKind.Primary);
                else if(operation=="both")CloseCopies(targets,CloseCopyKind.Both);
                else return Task.FromResult("عملیات ناشناخته است.");
                return Task.FromResult("درخواست برای "+targets.Count+" حساب ثبت شد. ثبت درخواست به معنی اتصال موفق نیست؛ نتیجه را از وضعیت زنده یا پنل بررسی کن.");
            }
            if(request.Kind=="cached")
            {
                var journals=new Dictionary<string,AccountJournal>();var live=new HashSet<string>();foreach(var c in targets){var s=StudentOf(c);if(s.LiveCurrent||s.LiveData!=null)live.Add(c.Name);if(s.Journal!=null)journals[c.Name]=JournalFile.Parse(JournalFile.Write(s.Journal));}
                return Task.FromResult(TelegramReport(request,targets,journals,false,live));
            }
            if(request.Kind!="fresh")return Task.FromResult("درخواست پشتیبانی نمی‌شود.");
            if(!ScheduleIdle||reportRepairActive)return Task.FromResult("گزارش یا اجرای دیگری در جریان است؛ پس از پایان دوباره درخواست بده.");
            if(targets.Count==0)return Task.FromResult("حسابی انتخاب نشده است.");
            var completion=new TaskCompletionSource<string>();var batch=new TelegramBatch{Request=request,Copies=targets,Deadline=DateTime.UtcNow.AddMinutes(30),Completion=completion};
            foreach(var c in targets)
            {
                var state=StudentOf(c);if(!state.LiveCurrent||state.Journal==null||!state.Journal.GmtOffset.HasValue)continue;
                var kind=request.Range=="month"?PanelRange.Month:request.Range=="week"?PanelRange.Week:request.Range=="yesterday"?PanelRange.Yesterday:PanelRange.Today;
                var range=ServerDays.Range(kind,ServerDays.Now(state.Journal,request.StartedUtc).Date);
                if(JournalCache.CoversTrusted(state.Journal,range.From))batch.Live.Add(c.Name);
            }
            var native=targets.Where(c=>!batch.Live.Contains(c.Name)).ToList();
            if(native.Count>0){string admission=ReportRunner.NativeAdmissionProblem(settings,native);if(admission!=null)return Task.FromResult("گزارش‌گیری در این سیستم آماده نیست؛ جزئیات را از متافکتوری بررسی کن.");}
            telegramBatch=batch;SetStatus(Lang.T("در حال تهیهٔ گزارش درخواستی تلگرام…","Preparing the requested Telegram report…"));
            if(native.Count>0)
            {
                telegramStarting=true;
                try{Read(native.Select(c=>c.Name),request.Range=="month"?DateTime.UtcNow.Date.AddDays(-33):request.Range=="week"?DateTime.UtcNow.Date.AddDays(-9):DateTime.UtcNow.Date.AddDays(-2));}
                catch{telegramBatch=null;completion.TrySetResult("شروع گزارش‌گیری ناموفق بود؛ جزئیات را در برنامه بررسی کن.");}
                finally{telegramStarting=false;}
            }
            return completion.Task;
        }
        static bool TelegramFresh(AccountJournal j,Instance c,Account a,DateTime start)
        {
            if(j==null||a==null||!j.Complete||!j.FullHistoryValid||double.IsNaN(j.Balance)||double.IsInfinity(j.Balance)||double.IsNaN(j.Equity)||double.IsInfinity(j.Equity)||j.Login!=a.Login||!string.Equals(j.Server,a.Server,StringComparison.OrdinalIgnoreCase)||j.Platform!=c.Kind.ToString()||!j.GmtOffset.HasValue)return false;
            var first=ServerDays.Now(j,start).AddSeconds(-1);var last=ServerDays.Now(j,DateTime.UtcNow).AddSeconds(5);
            return j.Exported>=first&&j.Exported<=last;
        }
        void CaptureTelegramJournal(ReportJob job,ReportRow row)
        {
            var batch=telegramBatch;if(batch==null||row.Cached||row.Cancelled||row.Error!=null)return;
            var target=batch.Request.Targets.FirstOrDefault(t=>t.Key==job.Copy.Name);
            if(target==null||target.Identity!=job.Account.CredentialKey||!TelegramFresh(row.Journal,job.Copy,job.Account,batch.Request.StartedUtc))return;
            try{batch.Journals[job.Copy.Name]=JournalFile.Parse(JournalFile.Write(row.Journal));}catch{}
        }
        void TelegramTick()
        {
            var batch=telegramBatch;if(batch==null||appClosing)return;
            var currentOptions=BotOptions(batch.Request.Channel);
            if(currentOptions==null||!currentOptions.Enabled||!currentOptions.Allowed(batch.Request.User)){telegramBatch=null;batch.Completion.TrySetResult("دسترسی لغو شد.");return;}
            foreach(var c in batch.Copies.Where(c=>batch.Live.Contains(c.Name)&&!batch.Journals.ContainsKey(c.Name)))
            {
                var state=StudentOf(c);var account=accounts.Get(c.Name);var target=batch.Request.Targets.First(t=>t.Key==c.Name);
                if(account!=null&&account.CredentialKey==target.Identity&&state.LiveCurrent&&state.LiveFeed!=null&&state.LiveFeed.HeartbeatUtc>=batch.Request.StartedUtc&&TelegramFresh(state.Journal,c,account,batch.Request.StartedUtc))
                    try{batch.Journals[c.Name]=JournalFile.Parse(JournalFile.Write(state.Journal));}catch{}
            }
            bool nativeDone=report==null&&readQueue.Count==0&&!telegramStarting;
            bool liveDone=batch.Live.All(k=>batch.Journals.ContainsKey(k))||DateTime.UtcNow>=batch.Request.StartedUtc.AddSeconds(25);
            if(DateTime.UtcNow<batch.Deadline&&(!nativeDone||!liveDone))return;
            telegramBatch=null;
            try{batch.Completion.TrySetResult(TelegramReport(batch.Request,batch.Copies,batch.Journals,true,batch.Live));}catch{batch.Completion.TrySetResult("تهیهٔ متن گزارش ناموفق بود؛ داده‌ای ارسال نشد.");}
        }
        string TelegramReport(TelegramRequest request,List<Instance> targets,Dictionary<string,AccountJournal> journals,bool fresh,HashSet<string> live)
        {
            var text=new StringBuilder(fresh?"گزارش تازهٔ متافکتوری\n":"آخرین گزارش موجود — این خروجی تضمین لحظه‌ای ندارد\n");text.AppendLine("درخواست UTC: "+request.StartedUtc.ToString("u",CultureInfo.InvariantCulture));int n=0;
            foreach(var copy in targets)
            {
                n++;var target=request.Targets.First(t=>t.Key==copy.Name);var current=accounts.Get(copy.Name);AccountJournal j;journals.TryGetValue(copy.Name,out j);
                text.AppendLine();text.AppendLine(n+". "+target.Name+" · "+target.Login);
                if(current==null||current.CredentialKey!=target.Identity||j==null||!j.Complete||j.Login!=current.Login||!string.Equals(j.Server,current.Server,StringComparison.OrdinalIgnoreCase)||j.Platform!=copy.Kind.ToString()||fresh&&!TelegramFresh(j,copy,current,request.StartedUtc))
                {text.AppendLine("خروجی تازهٔ معتبر در دسترس نیست؛ برای آخرین اطلاعات گزینهٔ گزارش ذخیره‌شده را انتخاب کن.");continue;}
                if(!j.GmtOffset.HasValue){text.AppendLine("پایهٔ زمانی سرور مشخص نیست؛ برای جلوگیری از نمایش بازهٔ اشتباه، ارقام این گزارش ارسال نشد.");continue;}
                text.AppendLine((fresh?"خواندن تأییدشده":"گزارش ذخیره‌شده")+" · زمان سرور: "+j.Exported.ToString("yyyy-MM-dd HH:mm:ss",CultureInfo.InvariantCulture));
                text.AppendLine("Server: "+current.Server);
                PanelRange kind=request.Range=="week"?PanelRange.Week:request.Range=="month"?PanelRange.Month:request.Range=="yesterday"?PanelRange.Yesterday:PanelRange.Today;
                var range=ServerDays.Range(kind,ServerDays.Now(j,request.StartedUtc).Date);
                PanelView view=TelegramPanel(j,range,live.Contains(copy.Name));if(view==null){text.AppendLine("پوشش تاریخچهٔ بازه تأیید نشده؛ گزارش ناقص ارسال نشد.");continue;}
                text.AppendLine(ReportText.Heading(range));text.AppendLine(ReportText.Student(new TextEntry{Number=n,Name=target.Name,Login=target.Login,View=view},request.Parts));
                double factor=view.ProfitFactor;text.AppendLine("Overall profit factor: "+(double.IsNaN(factor)?"unavailable":double.IsPositiveInfinity(factor)?"∞":factor.ToString("0.00",CultureInfo.InvariantCulture)));
                text.AppendLine("Equity: "+j.Equity.ToString("0.00",CultureInfo.InvariantCulture)+" "+j.Currency);
            }
            return text.ToString();
        }
        PanelView TelegramPanel(AccountJournal j,ReportRange range,bool live)
        {
            if(!JournalCache.CoversTrusted(j,range.From))return null;
            if(live)return LiveDashboardMath.Build(j,range);
            return PanelMath.Build(j,range,Limits);
        }
    }
}
