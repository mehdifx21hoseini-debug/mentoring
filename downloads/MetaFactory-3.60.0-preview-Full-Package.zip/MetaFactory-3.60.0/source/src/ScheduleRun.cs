using System;
using System.IO;
using System.Globalization;
using System.Web.Script.Serialization;

namespace MTManager
{
    public sealed class ScheduleRunState
    {
        public string LastScheduledDate = "", RunId = "", Phase = "", Status = "";
        public DateTime StartedUtc;
    }
    // Persist the claim BEFORE reading/sending. A restart never automatically resends an uncertain delivery.
    public sealed class ScheduleLedger
    {
        readonly string path;
        public ScheduleRunState State { get; private set; }
        public string Error { get; private set; }
        public ScheduleLedger(string path)
        {
            this.path = path; State = new ScheduleRunState();
            try
            {
                if (File.Exists(path)) State = new JavaScriptSerializer().Deserialize<ScheduleRunState>(File.ReadAllText(path));
                if (State == null || State.LastScheduledDate == null) throw new InvalidDataException();
                if (State.Phase == "reading" || State.Phase == "sending")
                {
                    State.Phase = "interrupted";
                    State.Status = Lang.T("اجرای قبلی قطع شده؛ ارسال مجدد خودکار انجام نمی‌شود. نتیجهٔ مقصد را بررسی کنید.", "Previous run interrupted; no automatic resend. Check the destination before retrying.");
                    Save();
                }
            }
            catch { Error = Lang.T("وضعیت زمان‌بندی قابل خواندن نیست؛ اجرای خودکار متوقف است.", "Schedule state could not be read; automatic execution is disabled."); }
        }
        public static bool TimeReached(string time, DateTime localNow)
        {
            TimeSpan at;
            return TimeSpan.TryParseExact(time, @"hh\:mm", CultureInfo.InvariantCulture, out at) && at.TotalHours < 24 && localNow.TimeOfDay >= at;
        }
        public bool Due(ScheduleOptions options, DateTime localNow)
        {
            return Error == null && options.Enabled && TimeReached(options.Time, localNow)
                && string.CompareOrdinal(State.LastScheduledDate, localNow.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)) < 0;
        }
        public void Begin(ScheduleOptions options, DateTime localNow, DateTime utcNow)
        {
            if (Error != null) throw new InvalidOperationException(Error);
            // A manually requested send after today's time satisfies today's scheduled run too.
            if (TimeReached(options.Time, localNow)) State.LastScheduledDate = localNow.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
            State.RunId = Guid.NewGuid().ToString("N"); State.StartedUtc = utcNow; State.Phase = "reading";
            State.Status = Lang.T("در حال تهیهٔ گزارش زمان‌بندی‌شده…", "Preparing scheduled report…"); Save();
        }
        public void Set(string phase, string status) { State.Phase = phase; State.Status = status; Save(); }
        void Save()
        {
            try { TextUtil.WriteLinesAtomically(path, new[] { new JavaScriptSerializer().Serialize(State) }); }
            catch { Error = Lang.T("ذخیرهٔ وضعیت زمان‌بندی انجام نشد؛ ارسال متوقف شد.", "Could not save schedule state; sending stopped."); throw; }
        }
    }
}
