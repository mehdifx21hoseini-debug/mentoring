using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MTManager
{
    // 3.26 (CHANGE-009, 010, 011; approved): the small parts of the tidier windows: a two-way choice, a password box with an eye,
    // a «− ۵ +» number, a gray note with a lock and a group heading. Only how things look and are entered; what is saved is the same.

    /// <summary>A row of choices in one frame, the first at the right; the chosen one blue.</summary>
    sealed class Segmented : Control
    {
        readonly string[] items;
        readonly Rectangle[] rects;
        int selected, hover = -1;
        public event EventHandler Changed;

        public Segmented(params string[] items)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            this.items = items;
            rects = new Rectangle[items.Length];
            Font = Theme.Font;
            TabStop = true;
            Cursor = Cursors.Hand;
            AccessibleRole = AccessibleRole.PageTabList;
            Size = new Size(items.Sum(t => ItemWidth(t)) + 2, Theme.FieldHeight);
        }

        int ItemWidth(string t) { return Theme.Measure(t, Theme.Bold).Width + Theme.S(30); }

        public int Selected
        {
            get { return selected; }
            set
            {
                int v = Math.Max(0, Math.Min(items.Length - 1, value));
                if (v == selected) return;
                selected = v;
                Invalidate();
                if (Changed != null) Changed(this, EventArgs.Empty);
            }
        }

        void Place()
        {
            int x = Width - 1;
            for (int k = 0; k < items.Length; k++)
            {
                int w = ItemWidth(items[k]);
                // 3.27: the first at the start: the right in Persian, the left in English.
                rects[k] = Theme.Flip(new Rectangle(x - w, 0, w, Height - 1), 0, Width - 1);
                x -= w;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent == null ? this : Parent));
            Place();
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            var whole = Rectangle.FromLTRB(rects.Min(r => r.Left), 0, rects.Max(r => r.Right), Height - 1);
            Theme.Box(g, whole, Theme.Sf(5), Theme.Surface, Theme.BorderStrong);
            for (int k = 0; k < items.Length; k++)
            {
                Rectangle r = rects[k];
                bool on = k == selected;
                if (on) Theme.Box(g, r, Theme.Sf(5), Theme.Accent, Theme.Accent);
                else if (k == hover) using (var b = new SolidBrush(Theme.Hover)) g.FillRectangle(b, r.X + 1, r.Y + 1, r.Width - 2, r.Height - 2);
                int sx = Lang.En ? r.Left : r.Right;
                if (k > 0 && !on && k - 1 != selected)
                    using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, sx, r.Top + Theme.S(7), sx, r.Bottom - Theme.S(7));
                Theme.Line(g, items[k], on ? Theme.Bold : Theme.Font, r, on ? Theme.OnAccent : Theme.Text, true);
            }
            if (Focused && ShowFocusCues)
            {
                Rectangle f = rects[selected];
                f.Inflate(-Theme.S(3), -Theme.S(3));
                ControlPaint.DrawFocusRectangle(g, f, Theme.OnAccent, Theme.Accent);
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            Place();
            int h = Array.FindIndex(rects, r => r.Contains(e.Location));
            if (h != hover) { hover = h; Invalidate(); }
        }

        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); hover = -1; Invalidate(); }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            Focus();
            Place();
            int k = Array.FindIndex(rects, r => r.Contains(e.Location));
            if (k >= 0 && e.Button == MouseButtons.Left) Selected = k;
        }

        protected override bool IsInputKey(Keys keyData) { return keyData == Keys.Left || keyData == Keys.Right || base.IsInputKey(keyData); }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            // The first is at the start: the arrow away from it goes on to the next.
            if (e.KeyCode == (Lang.En ? Keys.Right : Keys.Left)) Selected = selected + 1;
            else if (e.KeyCode == (Lang.En ? Keys.Left : Keys.Right)) Selected = selected - 1;
        }

        protected override void OnGotFocus(EventArgs e) { base.OnGotFocus(e); Invalidate(); }
        protected override void OnLostFocus(EventArgs e) { base.OnLostFocus(e); Invalidate(); }
    }

    /// <summary>A password box with an eye at its end (left) that shows or hides what is typed.</summary>
    sealed class PasswordBox : Panel
    {
        public readonly TextBox Box = new TextBox { BorderStyle = BorderStyle.None, RightToLeft = RightToLeft.No, UseSystemPasswordChar = true };
        bool shown, hover, hoverEye;
        string cue = "";

        int Eye { get { return Theme.S(34); } }

        public PasswordBox(int width)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Surface;
            Size = new Size(Theme.S(width), Theme.FieldHeight + 2 * Theme.FieldRing);
            Box.Font = Theme.Font;
            Box.BackColor = Theme.Input;
            Box.ForeColor = Theme.Text;
            Controls.Add(Box);
            Box.GotFocus += (s, e) => Invalidate();
            Box.LostFocus += (s, e) => Invalidate();
            Box.MouseEnter += (s, e) => Hover();
            Box.MouseLeave += (s, e) => Hover();
            MouseEnter += (s, e) => Hover();
            MouseLeave += (s, e) => Hover();
            Box.HandleCreated += (s, e) => SetCue();
        }

        public string Value { get { return Box.Text; } set { Box.Text = value ?? ""; } }

        /// <summary>A gray hint inside the empty box (e.g. «اختیاری»).</summary>
        public string Cue { get { return cue; } set { cue = value ?? ""; SetCue(); } }

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);

        void SetCue()
        {
            if (!Box.IsHandleCreated) return;
            try { SendMessage(Box.Handle, 0x1501, (IntPtr)1, cue); } catch { }
        }

        void Hover()
        {
            bool now = IsHandleCreated && ClientRectangle.Contains(PointToClient(Cursor.Position));
            if (now != hover) { hover = now; Invalidate(); }
        }

        /// <summary>At the field's end: the left in Persian, the right in English (3.27).</summary>
        Rectangle EyeRect { get { return Theme.Flip(new Rectangle(Theme.FieldRing, 0, Eye, Height), 0, Width); } }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            int ring = Theme.FieldRing;
            Box.Width = Math.Max(0, Width - 2 * ring - Eye - Theme.S(10));
            Box.Location = new Point(Lang.En ? ring + Theme.S(10) : ring + Eye, (Height - Box.Height) / 2);
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent == null ? this : Parent));
            Theme.Field(g, ClientRectangle, !Enabled ? FieldLook.Off : Box.Focused ? FieldLook.Focus : hover ? FieldLook.Hover : FieldLook.Normal);
            int a = Theme.S(16);
            Rectangle r = EyeRect;
            Glyphs.Draw(g, shown ? Glyph.EyeOff : Glyph.Eye, new RectangleF(r.X + (r.Width - a) / 2f, (Height - a) / 2f, a, a), hoverEye ? Theme.Text : Theme.Muted);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            bool on = EyeRect.Contains(e.Location);
            Cursor = on ? Cursors.Hand : Cursors.IBeam;
            if (on != hoverEye) { hoverEye = on; Invalidate(); }
            Hover();
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button == MouseButtons.Left && EyeRect.Contains(e.Location))
            {
                shown = !shown;
                Box.UseSystemPasswordChar = !shown;
                Invalidate();
            }
            Box.Focus();
        }
    }

    /// <summary>A whole number with «−» at its start (right) and «+» at its end; it can also be typed. Holding a button repeats.</summary>
    sealed class Stepper : Panel
    {
        public readonly TextBox Box = new TextBox { BorderStyle = BorderStyle.None, RightToLeft = RightToLeft.No, TextAlign = HorizontalAlignment.Center };
        readonly Timer repeat = new Timer { Interval = 380 };
        int min, max, value, step, hoverPart;
        bool hover;
        public event EventHandler Changed;

        int Btn { get { return Theme.S(30); } }

        public Stepper(int min, int max, int width = 120)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            this.min = min;
            this.max = max;
            value = min;
            BackColor = Theme.Surface;
            Size = new Size(Theme.S(width), Theme.FieldHeight + 2 * Theme.FieldRing);
            Box.Font = Theme.Font;
            Box.BackColor = Theme.Input;
            Box.ForeColor = Theme.Text;
            Box.Text = Show(value);
            Controls.Add(Box);
            Box.GotFocus += (s, e) => Invalidate();
            Box.LostFocus += (s, e) => { Commit(); Invalidate(); };
            Box.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Up) { Value = value + 1; e.Handled = true; }
                else if (e.KeyCode == Keys.Down) { Value = value - 1; e.Handled = true; }
                else if (e.KeyCode == Keys.Enter) Commit();
            };
            Box.MouseWheel += (s, e) => Value = value + Math.Sign(e.Delta);
            repeat.Tick += (s, e) => { repeat.Interval = 60; Value = value + step; };
            Disposed += (s, e) => repeat.Dispose();
        }

        static string Show(int v) { return v.ToString(CultureInfo.InvariantCulture); }

        public int Value
        {
            get { Commit(); return value; }
            set
            {
                int v = Math.Max(min, Math.Min(max, value));
                if (Box.Text != Show(v)) Box.Text = Show(v);
                if (v == this.value) return;
                this.value = v;
                if (Changed != null) Changed(this, EventArgs.Empty);
            }
        }

        /// <summary>What was typed (Persian or Latin digits) becomes the number, kept within its limits.</summary>
        void Commit()
        {
            string t = TextUtil.LatinDigits(Box.Text.Trim());
            int v;
            if (!int.TryParse(t, NumberStyles.Integer, CultureInfo.InvariantCulture, out v)) v = value;
            Value = v;
            if (Box.Text != Show(value)) Box.Text = Show(value);
        }

        // In the frame: «+» at the left end, «−» at the right end.
        // 3.27: mirrored in English («−» at the left, «+» at the right).
        Rectangle PlusRect { get { return Theme.Flip(new Rectangle(Theme.FieldRing, 0, Btn, Height), 0, Width); } }
        Rectangle MinusRect { get { return Theme.Flip(new Rectangle(Width - Theme.FieldRing - Btn, 0, Btn, Height), 0, Width); } }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            Box.Width = Math.Max(0, Width - 2 * Theme.FieldRing - 2 * Btn - Theme.S(4));
            Box.Location = new Point(Theme.FieldRing + Btn + Theme.S(2), (Height - Box.Height) / 2);
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent == null ? this : Parent));
            Theme.Field(g, ClientRectangle, !Enabled ? FieldLook.Off : Box.Focused ? FieldLook.Focus : hover ? FieldLook.Hover : FieldLook.Normal);
            int ring = Theme.FieldRing, pad = Theme.S(7);
            foreach (int part in new[] { 1, -1 })
            {
                Rectangle r = part > 0 ? PlusRect : MinusRect;
                var inner = new Rectangle(r.X + 1, ring + 1, r.Width - 2, Height - 2 * ring - 2);
                if (hoverPart == part) using (var b = new SolidBrush(Theme.Hover)) g.FillRectangle(b, inner);
                int x = (part > 0) != Lang.En ? r.Right : r.Left;
                using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, x, ring + pad, x, Height - ring - pad);
                bool can = part > 0 ? value < max : value > min;
                Theme.Line(g, part > 0 ? "+" : "−", Theme.Bold, r, can ? Theme.Text : Theme.Faint, true);
            }
        }

        int PartAt(Point p) { return PlusRect.Contains(p) ? 1 : MinusRect.Contains(p) ? -1 : 0; }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            int p = PartAt(e.Location);
            Cursor = p != 0 ? Cursors.Hand : Cursors.Default;
            bool now = ClientRectangle.Contains(e.Location);
            if (p != hoverPart || now != hover) { hoverPart = p; hover = now; Invalidate(); }
        }

        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); hoverPart = 0; hover = false; repeat.Stop(); Invalidate(); }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            Box.Focus();
            step = e.Button == MouseButtons.Left ? PartAt(e.Location) : 0;
            if (step == 0) return;
            Commit();
            Value = value + step;
            Invalidate();
            repeat.Interval = 380;
            repeat.Start();
        }

        protected override void OnMouseUp(MouseEventArgs e) { base.OnMouseUp(e); repeat.Stop(); }
    }

    /// <summary>A short note in a pale gray box with a lock (or another mark) at its start.</summary>
    sealed class NoteBox : Control
    {
        readonly int width;
        Color color;

        public NoteBox(string text, int width)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            this.width = Theme.S(width);
            color = Theme.Muted;
            Font = Theme.Small;
            Text = text;
        }

        public Color Color { get { return color; } set { color = value; Invalidate(); } }

        static TextFormatFlags Flags { get { return Theme.Rtl | Theme.Start | TextFormatFlags.WordBreak; } }

        int Mark { get { return Theme.S(30); } }

        protected override void OnTextChanged(EventArgs e)
        {
            base.OnTextChanged(e);
            Size t = TextRenderer.MeasureText(Text ?? "", Font, new Size(width - Mark - Theme.S(14), 0), Flags);
            Size = new Size(width, t.Height + Theme.S(18));
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent == null ? this : Parent));
            Theme.Box(g, new Rectangle(0, 0, Width - 1, Height - 1), Theme.Sf(6), Theme.Mix(Theme.Hover, Theme.Surface, 0.35f), Color.Transparent);
            int a = Theme.S(14);
            Rectangle cr = ClientRectangle;
            Glyphs.Draw(g, Glyph.Lock, Theme.Flip(new RectangleF(Width - Theme.S(10) - a, Theme.S(10), a, a), cr), Theme.Muted);
            TextRenderer.DrawText(g, Text ?? "", Font, Theme.Flip(new Rectangle(Theme.S(12), Theme.S(9), Width - Mark - Theme.S(14), Height - Theme.S(14)), cr), color, Flags);
        }
    }

    /// <summary>A small group heading with a thin line under it, as wide as the window's rows.</summary>
    sealed class SectionHead : Control
    {
        public SectionHead(string text)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Text = text;
            Font = Theme.Bold;
            Height = Theme.S(30);
            Width = Theme.Measure(text, Theme.Bold).Width + Theme.S(4);
            Anchor = AnchorStyles.Left | AnchorStyles.Right;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent == null ? this : Parent));
            Theme.Line(g, Text, Font, new Rectangle(0, 0, Width, Height - Theme.S(6)), Theme.Text);
            using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, 0, Height - 2, Width, Height - 2);
        }
    }

    /// <summary>3.26 (CHANGE-016): a short question with a heading, a muted hint and two named buttons (Yes / No).</summary>
    sealed class AskDialog : FormDialog
    {
        public AskDialog(string heading, string text, string hint, string yes, string no) : base(Ui.Title, null, false, true)
        {
            var mark = new GlyphBox(Glyph.Info, 40) { Margin = Theme.Pad(0, 2, 0, 0), Anchor = AnchorStyles.Top | AnchorStyles.Left };
            var words = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false, Margin = Theme.Pad(16, 4, 0, 4) };
            Label h = Theme.Label(heading, 340, Theme.Heading, Theme.Text);
            h.Margin = Theme.Pad(0, 0, 0, 6);
            if (!string.Equals(heading, Ui.Title, StringComparison.OrdinalIgnoreCase)) words.Controls.Add(h);
            words.Controls.Add(Theme.Label(text, 340, Theme.Font, Theme.Text));
            if (!string.IsNullOrEmpty(hint)) words.Controls.Add(Theme.Label(hint, 340, Theme.Small, Theme.Muted));
            int r = Body.RowCount;
            Body.RowCount = r + 1;
            Body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Body.Controls.Add(mark, 0, r);
            Body.Controls.Add(words, 1, r);
            Button y = AddButton(yes, null, true);
            y.DialogResult = DialogResult.Yes;
            Button n = AddButton(no, null);
            n.DialogResult = DialogResult.No;
            Finish();
            AcceptButton = y;
            CancelButton = n;
        }
    }
}
