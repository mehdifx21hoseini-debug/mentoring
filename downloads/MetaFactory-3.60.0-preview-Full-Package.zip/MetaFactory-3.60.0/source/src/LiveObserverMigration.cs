using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
namespace MTManager
{
    public sealed class LiveObserverSlot { public string Symbol,Period; public int Retired; }
    public static class LiveObserverMigration
    {
        internal static bool Ours(string name)
        {
            name=(name??"").Trim().Replace('/','\\');
            if(name.EndsWith(".ex4",StringComparison.OrdinalIgnoreCase)||name.EndsWith(".ex5",StringComparison.OrdinalIgnoreCase))name=name.Substring(0,name.Length-4);
            return name.Equals("MTManagerLive",StringComparison.OrdinalIgnoreCase)
                || name.StartsWith("MetaFactoryLive\\",StringComparison.OrdinalIgnoreCase) && name.EndsWith("\\MTManagerLive",StringComparison.OrdinalIgnoreCase)
                || Regex.IsMatch(name,@"\AMF_Live_[0-9a-fA-F]{12}_[0-9a-fA-F]{12}\z");
        }
        public static string WithoutObserver(string text,out bool changed)
        {
            changed=false;var output=new StringBuilder();var block=new StringBuilder();bool inside=false,ours=false;
            for(int pos=0;pos<text.Length;)
            {
                int nl=text.IndexOf('\n',pos),end=nl<0?text.Length:nl+1;string line=text.Substring(pos,end-pos),t=line.Trim();pos=end;
                if(!inside && t.Equals("<expert>",StringComparison.OrdinalIgnoreCase)){inside=true;ours=false;block.Clear().Append(line);continue;}
                if(!inside){output.Append(line);continue;}
                block.Append(line);
                if(t.StartsWith("name=",StringComparison.OrdinalIgnoreCase) && Ours(t.Substring(5)))ours=true;
                if(t.Equals("</expert>",StringComparison.OrdinalIgnoreCase)){inside=false;if(ours)changed=true;else output.Append(block);}
            }
            if(inside)output.Append(block);
            return output.ToString();
        }
        static void RequireClosed(Instance copy)
        {
            var running=Processes.Running();
            try{if(Processes.IsRunning(running,copy.Exe))throw new UserMessage("Close this terminal before migrating its MetaFactory live observer: "+copy.Name);}
            finally{foreach(var p in running.Values)p.Dispose();}
        }
        static string Hash(byte[] bytes)
        {using(var sha=System.Security.Cryptography.SHA256.Create())return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-","");}
        public static LiveObserverSlot RetireClosed(Instance copy)
        {
            RequireClosed(copy);var result=new LiveObserverSlot();
            foreach(string chart in ChartProfile.AllCharts(copy))
            {
                if(new FileInfo(chart).Length>8*1024*1024)throw new UserMessage("A saved chart is too large to migrate safely: "+Path.GetFileName(chart));
                byte[] original=File.ReadAllBytes(chart);string text=TextFiles.Decode(original);bool changed;
                string next=WithoutObserver(text,out changed);if(!changed)continue;
                string symbol=ReportLaunch.ChartSymbol(text);string period=PeriodOf(text);
                if(result.Symbol==null && symbol!=null && period!=null){result.Symbol=symbol;result.Period=period;}
                string backupDir=Path.Combine(copy.Dir,"MTManager-backup","live-observers");Directory.CreateDirectory(backupDir);
                string backup=Path.Combine(backupDir,Path.GetFileName(chart)+"."+Hash(original)+".bak");
                if(!File.Exists(backup))using(var f=new FileStream(backup,FileMode.CreateNew,FileAccess.Write,FileShare.None))f.Write(original,0,original.Length);
                else if(Hash(File.ReadAllBytes(backup))!=Hash(original))throw new UserMessage("A live-observer backup differs; the original chart was preserved.");
                RequireClosed(copy);string temp=chart+".live-"+Guid.NewGuid().ToString("N");
                try{File.WriteAllBytes(temp,TextFiles.Encode(next,original));File.Replace(temp,chart,null);}
                finally{if(File.Exists(temp))File.Delete(temp);}
                result.Retired++;
            }
            return result;
        }
        internal static string PeriodOf(string text)
        {
            var m=Regex.Match(text??"",@"(?im)^period=(\d+)\s*$");int value;
            if(m.Success && int.TryParse(m.Groups[1].Value,out value) && new[]{1,5,15,30,60,240,1440,10080,43200}.Contains(value))return value.ToString();
            var size=Regex.Match(text??"",@"(?im)^period_size=(\d+)\s*$");var type=Regex.Match(text??"",@"(?im)^period_type=(\d+)\s*$");int n,unit;
            if(size.Success&&type.Success&&int.TryParse(size.Groups[1].Value,out n)&&int.TryParse(type.Groups[1].Value,out unit)&&unit>=0&&unit<5&&n>0&&n<=43200)
            {int[] factors={1,60,1440,10080,43200};value=n*factors[unit];if(new[]{1,5,15,30,60,240,1440,10080,43200}.Contains(value))return value.ToString();}
            return null;
        }
        public static string FlatAlias(Instance copy,LiveReporterDeployment deployment)
        {
            byte[] binary=File.ReadAllBytes(deployment.ExpertPath);string stamp=Hash(binary);
            string name="MF_Live_"+deployment.SourceHash.Substring(0,12)+"_"+stamp.Substring(0,12);
            string path=Path.Combine(copy.Dir,Kinds.Mql(copy.Kind),"Experts",name+(copy.Kind==Kind.MT4?".ex4":".ex5"));
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            if(File.Exists(path)){if(Hash(File.ReadAllBytes(path))!=stamp)throw new UserMessage("The live startup alias differs; no existing EA was replaced.");}
            else using(var f=new FileStream(path,FileMode.CreateNew,FileAccess.Write,FileShare.None))f.Write(binary,0,binary.Length);
            return name;
        }
    }
}
