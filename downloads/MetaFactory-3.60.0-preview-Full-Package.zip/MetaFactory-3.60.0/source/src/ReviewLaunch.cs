using System;using System.IO;using System.Linq;using System.Text;using System.Drawing;using System.Collections.Generic;using System.Diagnostics;using System.Windows.Forms;
namespace MTManager
{
    public sealed class ReviewCopyPlan
    {
        public Instance Parent,Copy; public Account Account; public int Number;
    }
    public static class ReviewCopies
    {
        public const int MaxCopies=200;
        const string Marker="metafactory-review.txt";
        public static ReviewCopyPlan Plan(Instance parent,Account account,int number)
        {
            if(parent==null||string.IsNullOrWhiteSpace(parent.Name)||parent.Name=="."||parent.Name==".."||parent.Name.IndexOfAny(new[]{'/','\\','\r','\n'})>=0)throw new ArgumentException("Invalid source copy.");
            if(number<2||number>MaxCopies)throw new ArgumentOutOfRangeException("number");
            string dir=Path.Combine(Path.GetDirectoryName(Path.GetFullPath(parent.Dir)),"_MTManager","review",parent.Name,number.ToString("00"));
            return new ReviewCopyPlan{Parent=parent,Number=number,Account=account==null?null:account.Snapshot(),Copy=new Instance{Name=parent.Name+"~review-"+number.ToString("00"),Kind=parent.Kind,Dir=dir}};
        }
        static string Identity(Instance parent){return Convert.ToBase64String(Encoding.UTF8.GetBytes(Path.GetFullPath(parent.Dir)))+"\t"+parent.Kind;}
        public static bool Owned(ReviewCopyPlan plan){try{return Directory.Exists(plan.Copy.Dir)&&(File.GetAttributes(plan.Copy.Dir)&FileAttributes.ReparsePoint)==0&&File.ReadAllText(Path.Combine(plan.Copy.Dir,Marker))==Identity(plan.Parent);}catch{return false;}}
        public static IEnumerable<Instance> Existing(Instance parent)
        {
            var first=Plan(parent,null,2);string root=Path.GetDirectoryName(first.Copy.Dir);if(!Directory.Exists(root))return new Instance[0];var result=new List<Instance>();
            string[] dirs;try{dirs=Directory.GetDirectories(root);}catch(IOException){return result;}catch(UnauthorizedAccessException){return result;}
            foreach(string dir in dirs){int n;if(!int.TryParse(Path.GetFileName(dir),out n)||n<2||n>MaxCopies)continue;var plan=Plan(parent,null,n);if(Owned(plan)&&File.Exists(plan.Copy.Exe))result.Add(plan.Copy);}return result;
        }
        public static void Prepare(Settings settings,ReviewCopyPlan plan,Func<bool> cancelled)
        {
            if(cancelled())throw new OperationCanceledException();
            if(Directory.Exists(plan.Copy.Dir))
            {if(!Owned(plan))throw new IOException(Lang.T("پوشهٔ نسخهٔ بررسی شناخته نشد؛ فایل‌ها دست‌نخورده ماندند.","Review directory is not managed; existing files were preserved."));if(!File.Exists(plan.Copy.Exe))throw new IOException("Review terminal is incomplete.");return;}
            var provision=PlainSettings(settings);provision.BaseDir=Path.GetDirectoryName(Path.GetFullPath(plan.Parent.Dir));
            StudentDirectory.EnsureCopy(provision,plan.Parent,plan.Account,cancelled);
            StudentDirectory.Prepare(provision,plan.Parent.Dir,plan.Copy,cancelled);
            File.WriteAllText(Path.Combine(plan.Copy.Dir,Marker),Identity(plan.Parent),Encoding.UTF8);
        }
        public static Settings PlainSettings(Settings source)
        {
            var copy=new Settings();foreach(var f in typeof(Settings).GetFields(System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.Public))f.SetValue(copy,f.GetValue(source));copy.Folders=new List<string>(source.Folders);
            copy.ManualLiveReports=false;copy.Minimized=false;copy.Light=false;copy.StartCharts=ChartModes.All;copy.LightCharts=false;copy.AutoStart=false;return copy;
        }
        public static AccountStore Accounts(ReviewCopyPlan plan)
        {var store=new AccountStore();if(plan.Account!=null){var account=plan.Account.Snapshot();account.Instance=plan.Copy.Name;account.DeferredDir="";store.Set(account);}return store;}
    }
    public sealed class ReportRepairResult { public string BackupDirectory,SourceDirectory; }
    public sealed class ReportRepairException : IOException
    {
        public readonly string Phase;public readonly int NativeCode;
        public ReportRepairException(string phase,int nativeCode,string message,Exception inner):base(message,inner){Phase=phase;NativeCode=nativeCode;}
    }
    /// <summary>Explicit offline rebuild; move operations never hold the source executable open.</summary>
    public static class ReportCopyRepair
    {
        public static string DiagnosticPath {get{return Path.Combine(AppPaths.DataDir,"report-repair-last.txt");}}
        static int Code(Exception e){if(e==null)return 0;var win=e as System.ComponentModel.Win32Exception;if(win!=null)return win.NativeErrorCode;uint hr=unchecked((uint)e.HResult);return (hr&0xFFFF0000)==0x80070000?(int)(hr&0xFFFF):-1;}
        static string Attr(string path){try{return Directory.Exists(path)?File.GetAttributes(path).ToString():"missing";}catch(Exception e){return e.GetType().Name;}}
        static void Evidence(Instance copy,string phase,Exception error,string original,string backup,string stage)
        {
            try{TextUtil.WriteLinesAtomically(DiagnosticPath,new[]{"MFREPAIR\t2",DateTime.UtcNow.ToString("u"),"copy="+TextUtil.OneLine(copy==null?"unknown":copy.Name),"phase="+phase,"exception="+(error==null?"none":error.GetType().Name),"native-code="+Code(error),"HRESULT="+(error==null?"none":"0x"+unchecked((uint)error.HResult).ToString("X8")),"original="+TextUtil.OneLine(original??""),"backup="+TextUtil.OneLine(backup??""),"stage="+TextUtil.OneLine(stage??""),"original-attributes="+Attr(original),"original-present="+Directory.Exists(original),"backup-present="+Directory.Exists(backup),"detail="+TextUtil.OneLine(error==null?"":error.Message),"Move denial can be a lock, folder state or access restriction; no cause is inferred from code5 alone. No ACL/UAC changes."});}catch{}
        }
        public static string Diagnostics()
        {
            try{return File.Exists(DiagnosticPath)&&new FileInfo(DiagnosticPath).Length<=16384?"\r\n— Latest report-copy rebuild —\r\n"+TextFiles.ReadText(DiagnosticPath)+"\r\n":"";}catch(Exception e){return "\r\nReport-copy rebuild evidence unavailable: "+e.GetType().Name+"\r\n";}
        }
        static void Move(string source,string destination,Func<bool> cancelled,Func<bool> running,Action<string,string> move)
        {
            for(int attempt=0;;attempt++)
            {
                if(cancelled())throw new OperationCanceledException();
                if(running())throw new IOException("Report terminal opened during repair; replacement stopped.");
                try{move(source,destination);return;}
                catch(Exception error)
                {
                    int code=Code(error);if(!(error is IOException||error is UnauthorizedAccessException)||attempt>=3||(code!=5&&code!=32&&code!=33))throw;
                    System.Threading.Thread.Sleep(100*(1<<attempt));
                }
            }
        }
        static string FailureText(string phase,int code,bool retained,string backup)
        {
            string action=phase=="backup-original"?Lang.T("پشتیبان‌گیری از پوشهٔ قبلی","backing up the previous folder"):phase=="commit-fresh"?Lang.T("جایگزینی نسخهٔ تازه","placing the fresh copy"):Lang.T("آماده‌سازی نسخهٔ گزارش","preparing the report copy");
            return Lang.T("بازسازی در مرحلهٔ ","Rebuild failed while ")+action+Lang.T(" متوقف شد؛ کد ویندوز ","; Windows code ")+(code<0?Lang.T("نامشخص","unknown"):code.ToString(System.Globalization.CultureInfo.InvariantCulture))+". "+(retained?Lang.T("فایل‌های قبلی بازنویسی نشده‌اند. جزئیات در بررسی سیستم.","Previous files were not overwritten. Details are in System check."):Lang.T("فایل‌های قبلی در پشتیبان نگهداری شده‌اند: ","Previous files remain in backup: ")+backup);
        }
        public static ReportRepairResult Rebuild(Settings settings,string source,Instance copy,Func<bool> cancelled,Func<bool> running,Action<string,string> move=null)
        {
            if(copy==null||string.IsNullOrWhiteSpace(copy.Name)||copy.Name=="."||copy.Name==".."||copy.Name.IndexOfAny(new[]{'/','\\','\r','\n'})>=0)throw new ArgumentException("Invalid copy.");
            string original=Path.GetFullPath(copy.Dir).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar),backup=null,stage=null,phase="validate";bool prepared=false,moved=false;
            move=move??((from,to)=>Directory.Move(from,to));
            Evidence(copy,"start",null,original,backup,stage);
            try
            {
                if(!string.Equals(Path.GetFileName(original),copy.Name,StringComparison.OrdinalIgnoreCase)||!Directory.Exists(original)||(File.GetAttributes(original)&FileAttributes.ReparsePoint)!=0)throw new IOException("Original copy directory is missing or not a regular managed copy.");
                source=Path.GetFullPath(source);if(string.Equals(source.TrimEnd(Path.DirectorySeparatorChar),original,StringComparison.OrdinalIgnoreCase)||!File.Exists(Path.Combine(source,Kinds.Exe(copy.Kind))))throw new IOException("A separate installed broker terminal is required.");
                if(cancelled())throw new OperationCanceledException();if(running())throw new IOException("Close the primary report terminal before rebuilding it.");
                phase="prepare-roots";
                string parent=Path.GetDirectoryName(original),root=Path.Combine(parent,"_MTManager");Directory.CreateDirectory(root);if((File.GetAttributes(root)&FileAttributes.ReparsePoint)!=0)throw new IOException("Repair root must not be linked.");
                string stageRoot=Path.Combine(root,"repair-stage");Directory.CreateDirectory(stageRoot);if((File.GetAttributes(stageRoot)&FileAttributes.ReparsePoint)!=0)throw new IOException("Repair stage must not be linked.");
                stage=Path.Combine(stageRoot,Guid.NewGuid().ToString("N"));string backupRoot=Path.Combine(root,"repair-backups");Directory.CreateDirectory(backupRoot);if((File.GetAttributes(backupRoot)&FileAttributes.ReparsePoint)!=0)throw new IOException("Repair backup root must not be linked.");
                string bucket=Path.Combine(backupRoot,copy.Name);Directory.CreateDirectory(bucket);if((File.GetAttributes(bucket)&FileAttributes.ReparsePoint)!=0)throw new IOException("Repair backup must not be linked.");
                backup=Path.Combine(bucket,DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N"));
                phase="prepare-fresh";var provision=ReviewCopies.PlainSettings(settings);provision.BaseDir=parent;
                StudentDirectory.Prepare(provision,source,new Instance{Name=copy.Name,Kind=copy.Kind,Dir=stage},cancelled);prepared=true;
                // Never keep a file handle inside the directory while renaming it on Windows.
                phase="backup-original";Move(original,backup,cancelled,running,move);moved=true;
                phase="commit-fresh";Move(stage,original,cancelled,running,move);
                Evidence(copy,"complete",null,original,backup,stage);
                return new ReportRepairResult{BackupDirectory=backup,SourceDirectory=source};
            }
            catch(Exception error)
            {
                bool previousAtOriginal=!moved;
                if(moved&&!Directory.Exists(original)&&Directory.Exists(backup))
                {
                    try{Move(backup,original,()=>false,()=>false,move);previousAtOriginal=true;}
                    catch(Exception rollback){Evidence(copy,"rollback-original",rollback,original,backup,stage);throw new ReportRepairException("rollback-original",Code(rollback),FailureText("rollback-original",Code(rollback),false,backup),rollback);}
                }
                Evidence(copy,error is OperationCanceledException?"cancelled-"+phase:phase,error,original,backup,stage);
                if(error is OperationCanceledException)throw;
                throw new ReportRepairException(phase,Code(error),FailureText(phase,Code(error),previousAtOriginal,backup),error);
            }
            finally{try{if(prepared&&Directory.Exists(stage)&&(File.GetAttributes(stage)&FileAttributes.ReparsePoint)==0)Directory.Delete(stage,true);}catch{}}
        }
    }
    enum CloseCopyKind { Review, Primary, Both }
    sealed class TerminalActionItem : ToolStripMenuItem
    {
        readonly string detail;readonly Glyph glyph;
        internal TerminalActionItem(string text,string detail,Glyph glyph,Action action):base(text)
        {
            this.detail=detail;this.glyph=glyph;AutoSize=false;Size=new Size(Theme.S(246),Theme.S(string.IsNullOrEmpty(detail)?34:48));
            AccessibleName=text+(string.IsNullOrEmpty(detail)?"":"; "+detail);Click+=(s,e)=>action();
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            using(var background=new SolidBrush(Theme.Surface))e.Graphics.FillRectangle(background,new Rectangle(Point.Empty,Size));
            if(Selected&&Enabled)Theme.Box(e.Graphics,new Rectangle(Theme.S(3),1,Width-Theme.S(6),Height-2),Theme.Sf(4),Theme.Hover,Color.Transparent);
            int icon=Theme.S(18),x=Lang.En?Theme.S(10):Width-Theme.S(28);
            Glyphs.Draw(e.Graphics,glyph,new RectangleF(x,(Height-icon)/2,icon,icon),Enabled?Theme.Muted:Theme.Faint);
            var text=new Rectangle(Lang.En?Theme.S(38):Theme.S(10),Theme.S(string.IsNullOrEmpty(detail)?3:5),Width-Theme.S(48),Theme.S(26));
            Theme.Line(e.Graphics,Text,Theme.Font,text,Enabled?Theme.Text:Theme.Faint);
            if(!string.IsNullOrEmpty(detail)){text.Y=Theme.S(26);text.Height=Theme.S(18);Theme.Line(e.Graphics,detail,Theme.Small,text,Theme.Muted);}
        }
    }
    sealed partial class MainForm
    {
        readonly Dictionary<string,ReviewCopyPlan> reviewPlans=new Dictionary<string,ReviewCopyPlan>(StringComparer.OrdinalIgnoreCase);
        string reviewDiscoveryKey="";int reviewOpenCount;
        void DisposeCopyMenus(){if(compactLaunchMenu!=null)compactLaunchMenu.Dispose();if(closeCopiesMenu!=null)closeCopiesMenu.Dispose();}
        Func<ReviewCopyPlan,Settings,StartResult> startReviewTerminal;
        List<Instance> KnownReviewCopies()
        {
            string key=string.Join("|",copies.Select(i=>i.Dir));if(key!=reviewDiscoveryKey){reviewDiscoveryKey=key;foreach(var parent in copies)foreach(var extra in ReviewCopies.Existing(parent))if(!reviewPlans.ContainsKey(extra.Name))reviewPlans[extra.Name]=new ReviewCopyPlan{Parent=parent,Copy=extra};}
            return reviewPlans.Values.Where(p=>copies.Any(c=>c.Dir==p.Parent.Dir)).Select(p=>p.Copy).ToList();
        }
        bool ReviewSelected(Instance copy){ReviewCopyPlan plan;return chosen.Has(copy.Name)||(reviewPlans.TryGetValue(copy.Name,out plan)&&chosen.Has(plan.Parent.Name));}
        List<Instance> WithReviewCopies(IEnumerable<Instance> parents){var list=parents.ToList();var names=new HashSet<string>(list.Select(i=>i.Name),StringComparer.OrdinalIgnoreCase);return list.Concat(KnownReviewCopies().Where(i=>{ReviewCopyPlan plan;return reviewPlans.TryGetValue(i.Name,out plan)&&names.Contains(plan.Parent.Name);})).GroupBy(i=>i.Dir,StringComparer.OrdinalIgnoreCase).Select(g=>g.First()).ToList();}
        void RequestManualLaunch(List<Instance> targets,bool live=true)
        {
            var snapshot=targets.ToList();if(snapshot.Count==0)return;
            if(preparingCopy||startQueue.Count>0||busy||report!=null||scheduledBatch!=null){SetStatus(Lang.T("عملیات فعلی هنوز تمام نشده؛ پس از پایان دوباره اجرا کنید.","Wait for the current operation before starting a new batch."));return;}
            AcceptManualLaunch(snapshot,1,true);
        }
        void AcceptManualLaunch(List<Instance> targets,int count,bool live)
        {
            if(preparingCopy||startQueue.Count>0||busy||report!=null||scheduledBatch!=null){SetStatus(Lang.T("عملیات فعلی هنوز تمام نشده است.","Wait for the current operation to finish."));return;}
            if(count<1||count>ReviewCopies.MaxCopies)throw new ArgumentOutOfRangeException("count");
            var originals=targets.ToList();
            if(count>1&&originals.Any(parent=>{var a=accounts.Get(parent.Name);return a==null||!a.HasLogin;}))throw new UserMessage(Lang.T("برای نسخهٔ بررسی، ابتدا حساب دانشجو را ثبت کنید.","Save each student's account before opening review instances."));
            var requested=new List<Instance>(originals);
            foreach(var parent in originals)for(int n=2;n<=count;n++){var plan=ReviewCopies.Plan(parent,accounts.Get(parent.Name),n);reviewPlans[plan.Copy.Name]=plan;requested.Add(plan.Copy);}
            settings.ManualLiveReports=live;settings.Save();runButton.SetText(live?Lang.T("اجرا · زنده","Run · live"):Lang.T("اجرا · عادی","Run · ordinary"));
            Enqueue(requested);
        }
        readonly Dictionary<string,int> reviewRunningByParent=new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase);
        ToolStripMenuItem miShowReview;
        string rowCommandName;
        Instance RowCommandCopy(){return rowCommandName==null?OneSelected():copies.FirstOrDefault(c=>c.Name==rowCommandName);}
        int ReviewCount(string name){int count;return reviewRunningByParent.TryGetValue(name,out count)?count:0;}
        void RefreshReviewSnapshot(Dictionary<string,Process> running)
        {
            reviewRunningByParent.Clear();reviewOpenCount=0;
            foreach(var copy in KnownReviewCopies())if(Processes.IsRunning(running,copy.Exe))
            {ReviewCopyPlan plan;if(!reviewPlans.TryGetValue(copy.Name,out plan))continue;reviewRunningByParent[plan.Parent.Name]=ReviewCount(plan.Parent.Name)+1;reviewOpenCount++;}
        }
        bool PrimaryRunning(Instance copy)
        {var running=Processes.Running();try{return Processes.IsRunning(running,copy.Exe);}finally{foreach(var p in running.Values)p.Dispose();}}
        void ShowReview(Instance parent)
        {
            var running=Processes.Running();try
            {
                foreach(var extra in CopiesToClose(new[]{parent},CloseCopyKind.Review))
                {Process p;if(running.TryGetValue(extra.Exe.ToLowerInvariant(),out p)){if(!TerminalWindow.Bring(p))SetStatus(Lang.T("پنجرهٔ بررسی هنوز آماده نیست.","The chart-review window is not ready yet."));return;}}
                SetStatus(Lang.T("نسخهٔ بررسی باز نیست.","No chart-review copy is open."));
            }finally{foreach(var p in running.Values)p.Dispose();}
        }
        string ReviewRuntimeSummary()
        {
            var running=Processes.Running();try
            {
                var lines=new List<string>{"\r\n— Chart-review processes (not live reports) —"};
                foreach(var copy in KnownReviewCopies().Where(i=>Processes.IsRunning(running,i.Exe)).Take(50))
                {
                    var p=running[copy.Exe.ToLowerInvariant()];ReviewCopyPlan plan;if(!reviewPlans.TryGetValue(copy.Name,out plan))continue;
                    DateTime start;try{start=p.StartTime;}catch{start=DateTime.Now.AddMinutes(-2);}
                    DateTime from=start<DateTime.Now.AddDays(-1)?DateTime.Now.AddDays(-1):start;
                    var account=accounts.Get(plan.Parent.Name);var ack=ConnectionCheck.FromJournal(ConnectionCheck.JournalTail(copy,from),account==null?"":account.Login);
                    lines.Add("parent="+plan.Parent.Name+" review="+copy.Name+" pid="+p.Id+" running=True path="+copy.Dir+" native-login-ack-in-run="+ack.State+" log-window-from-UTC="+from.ToUniversalTime().ToString("u")+" (not a live-report heartbeat)");
                }
                if(lines.Count==1)lines.Add("No managed chart-review process is currently open.");return string.Join("\r\n",lines)+"\r\n";
            }finally{foreach(var p in running.Values)p.Dispose();}
        }
        bool reportRepairActive;
        void RebuildReportCopy()
        {
            var copy=RowCommandCopy();if(copy==null)return;var account=accounts.Get(copy.Name);
            if(account==null||!account.HasLogin||!account.IsInvestor){Ui.Message(this,Lang.T("بازسازی فقط برای نسخهٔ گزارش با حساب اینوستور ثبت‌شده است.","Rebuild requires a saved investor report account."));return;}
            if(busy||preparingCopy||startQueue.Count>0||report!=null||scheduledBatch!=null){SetStatus(Lang.T("ابتدا عملیات فعلی را تمام یا متوقف کنید.","Finish or stop the current operation first."));return;}
            if(PrimaryRunning(copy)){Ui.Message(this,Lang.T("ابتدا فقط نسخهٔ زندهٔ این حساب را ببندید؛ بررسی می‌تواند باز بماند.","Close this account's live report first; chart review may remain open."));return;}
            if(!Ui.Confirm(this,copy.Name+" · "+account.Trader+" ("+account.Login+")\r\n"+Lang.T("نسخهٔ گزارش از نصب بروکر دوباره ساخته شود؟\r\nپوشهٔ فعلی کامل در _MTManager\\repair-backups نگهداری می‌شود. حساب، رمز و یادداشت متافکتوری تغییر نمی‌کند و نسخهٔ بررسی باز می‌ماند.","Rebuild this report terminal from the broker installation?\r\nThe entire current folder is retained in _MTManager\\repair-backups. MetaFactory account/password/notes stay saved and chart review stays open.")))return;
            var old=pending.Where(p=>p.Copy!=null&&string.Equals(p.Copy.Dir,copy.Dir,StringComparison.OrdinalIgnoreCase)).ToList();Launcher.CleanStartFiles(old,DateTime.Now,true);pending=pending.Except(old).ToList();Launcher.DeleteLeftovers(new[]{copy});
            foreach(var file in Directory.GetFiles(copy.Dir,"mtm-live-start-*.ini"))if(System.Text.RegularExpressions.Regex.IsMatch(Path.GetFileName(file),@"\Amtm-live-start-[0-9a-fA-F]{32}\.ini\z"))Launcher.DeleteStartFile(file);
            reportRepairActive=true;preparingCopy=true;launchWork=new LaunchWorkProgress();launchWork.Add(copy.Name);launchWork.Detail=Lang.T("بازسازی نسخهٔ گزارش ","Rebuilding report copy ")+copy.Name;RefreshLaunchProgress(true);
            var snapshot=account.Snapshot();
            System.Threading.Tasks.Task.Factory.StartNew(()=>
            {
                Func<bool> cancel=()=>{var current=accounts.Get(copy.Name);return appClosing||launchWork.Stopped||current==null||!current.IsInvestor||current.Login!=snapshot.Login||current.Server!=snapshot.Server;};
                string source=StudentDirectory.Source(settings,copy.Kind,snapshot.Server,cancel);if(source==null)throw new IOException("Installed broker terminal was not found; original files were preserved.");
                return ReportCopyRepair.Rebuild(settings,source,copy,cancel,()=>PrimaryRunning(copy));
            }).ContinueWith(task=>
            {
                var error=task.Exception==null?null:task.Exception.GetBaseException();
                if(appClosing||IsDisposed||!IsHandleCreated)return;
                try{BeginInvoke((Action)(()=>
                {
                    reportRepairActive=false;preparingCopy=false;launchWork.SettleStop();
                    if(error!=null){if(error is OperationCanceledException){launchWork.Skip(copy.Name);SetStatus(Lang.T("بازسازی متوقف شد؛ فایل‌های قبلی حفظ شدند.","Rebuild stopped; previous files were retained."));}else{launchWork.Complete(copy.Name,false);SetStatus(error.Message);}RefreshLaunchProgress();RefreshGrid(false);return;}
                    Log.Write("report copy rebuilt "+copy.Name+" backup="+task.Result.BackupDirectory);
                    if(launchWork.Stopped){launchWork.Skip(copy.Name);RefreshLaunchProgress();SetStatus(Lang.T("بازسازی تمام شد؛ اجرا متوقف مانده است.","Rebuild finished; launch remains stopped."));RefreshGrid(false);return;}
                    launchWork.Skip(copy.Name);RefreshLaunchProgress();launches.Remove(copy.Name);launchErrors.Remove(copy.Name);RequestManualLaunch(new List<Instance>{copy});
                }));}catch(InvalidOperationException){}
            });
        }
        ContextMenuStrip compactLaunchMenu,closeCopiesMenu;
        void ShowLaunchChoices(List<Instance> targets,Control anchor)
        {
            if(compactLaunchMenu!=null)compactLaunchMenu.Dispose();
            var snapshot=targets.ToList();var menu=compactLaunchMenu=Theme.Menu();menu.ShowImageMargin=false;
            menu.Items.Add(new TerminalActionItem(Lang.T("فقط گزارش زنده","Live report only"),"",Glyph.Pulse,()=>{menu.Close();Guard(()=>AcceptManualLaunch(snapshot,1,true));}));
            menu.Items.Add(new TerminalActionItem(Lang.T("زنده + بررسی","Live + chart review"),"",Glyph.Chart,()=>{menu.Close();Guard(()=>AcceptManualLaunch(snapshot,2,true));}));
            ShowCopyMenu(menu,anchor);
        }
        List<Instance> CopiesToClose(IEnumerable<Instance> parents,CloseCopyKind kind)
        {
            var originals=parents.ToList();var all=WithReviewCopies(originals);
            var paths=new HashSet<string>(originals.Select(i=>i.Dir),StringComparer.OrdinalIgnoreCase);
            return all.Where(i=>kind==CloseCopyKind.Both||(kind==CloseCopyKind.Primary?paths.Contains(i.Dir):!paths.Contains(i.Dir))).ToList();
        }
        void ShowCloseCopies(List<Instance> parents,Control anchor)
        {
            if(parents.Count==0)return;
            if(closeCopiesMenu!=null)closeCopiesMenu.Dispose();
            var snapshot=parents.ToList();var menu=closeCopiesMenu=Theme.Menu();menu.ShowImageMargin=false;
            menu.Items.Add(new TerminalActionItem(Lang.T("بستن بررسی‌ها","Close chart review"),Lang.T("زنده باز می‌ماند","Live stays open"),Glyph.Chart,()=>Guard(()=>CloseCopies(snapshot,CloseCopyKind.Review))));
            menu.Items.Add(new TerminalActionItem(Lang.T("بستن زنده‌ها","Close live reports"),Lang.T("بررسی باز می‌ماند","Chart review stays open"),Glyph.Pulse,()=>Guard(()=>CloseCopies(snapshot,CloseCopyKind.Primary))));
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(new TerminalActionItem(Lang.T("بستن هر دو","Close both"),"",Glyph.Stop,()=>Guard(()=>CloseCopies(snapshot,CloseCopyKind.Both))));
            ShowCopyMenu(menu,anchor);
        }
        void ShowCopyMenu(ContextMenuStrip menu,Control anchor)
        {
            if(anchor==grid){var point=grid.PointToClient(Cursor.Position);if(!grid.ClientRectangle.Contains(point))point=new Point(Theme.S(20),Theme.S(24));menu.Show(grid,point);}
            else ShowUnder(menu,anchor);
        }
        void CloseCopies(List<Instance> parents,CloseCopyKind kind)
        {
            // A queued/in-flight preparation must settle before closing by type, so a
            // terminal cannot appear again immediately after the user's close command.
            if(preparingCopy||startQueue.Count>0){SetStatus(Lang.T("ابتدا صبر کنید صف اجرا تمام شود یا آن را متوقف کنید.","Wait for the launch queue to finish, or stop it first."));return;}
            var exact=CopiesToClose(parents,kind);bannerKey=null;StopExact(exact,false);
        }
        bool TryStartReviewCopy()
        {
            ReviewCopyPlan plan;if(startQueue.Count==0||!reviewPlans.TryGetValue(startQueue.Peek().Name,out plan))return false;
            var copy=startQueue.Dequeue();if(plan.Account==null)plan.Account=accounts.Get(plan.Parent.Name);
            preparingCopy=true;lastStartAt=DateTime.Now;pacing=null;launchWork.Add(copy.Name);launchWork.Detail=copy.Name+Lang.T("؛ آماده‌سازی نسخه بررسی","; preparing review instance");RefreshLaunchProgress();LaunchComparison.Preparing(copy);
            var plain=ReviewCopies.PlainSettings(settings);var request=plan;
            System.Threading.Tasks.Task.Factory.StartNew(()=>{
                Func<bool> cancel=()=>appClosing||launchWork.Stopped||accounts.Get(request.Parent.Name)==null;
                ReviewCopies.Prepare(plain,request,cancel);if(cancel())throw new OperationCanceledException();
                return startReviewTerminal!=null?startReviewTerminal(request,plain):Launcher.StartReview(request.Copy,plain,ReviewCopies.Accounts(request));
            }).ContinueWith(task=>{
                var error=task.Exception==null?null:task.Exception.GetBaseException();var result=error==null?task.Result:null;
                if(appClosing||IsDisposed||!IsHandleCreated){CleanDetachedStart(copy,result);return;}
                try{BeginInvoke((Action)(()=>{preparingCopy=false;launchWork.SettleStop();if(error is OperationCanceledException&&launchWork.Stopped)launchWork.Skip(copy.Name);else if(error!=null)RecordLaunchFailure(copy,error);else CompleteManualStart(copy,result);RefreshLaunchProgress();if(startQueue.Count==0)startTimer.Stop();else startTimer.Start();}));}catch(InvalidOperationException){CleanDetachedStart(copy,result);}
            });return true;
        }
    }
}
