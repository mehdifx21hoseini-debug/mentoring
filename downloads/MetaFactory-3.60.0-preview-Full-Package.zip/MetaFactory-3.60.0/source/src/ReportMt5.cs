// MT5 cold reporting compatibility path copied from the field-verified 3.36.2 release.
// Dispatched only for MT5; keep this body auditable against the original release.
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;

namespace MTManager
{
    public sealed partial class ReportRunner
    {
        Outcome AttemptMt5(ReportJob job, Instance rc, string password, List<string> tried, int slot, Action<Outcome> commit)
        {
            Account acc = job.Account;
            string token = Guid.NewGuid().ToString("N"); bool serve = CanWarm(slot, rc), keep = false;
            if (!Mt5Stage(job, "close-previous", Lang.T("بستن گزارش‌خوان قبلی MT5", "Closing the previous MT5 reporter"), () => EndLeftover(rc)))
                return Fail(Lang.T("متاتریدر گزارش باز ماند", "The report MetaTrader stayed open"), Lang.T("متاتریدر گزارش (", "The report MetaTrader (") + rc.Dir + Lang.T(") باز بود و بسته نشد (شاید با دسترسی مدیر اجرا شده). آن را از Task Manager ببندید و «به‌روزرسانی» را دوباره بزنید.", ") was open and did not close (perhaps it runs as administrator). Close it from Task Manager and press “Refresh” again."));
            // A cold reporter must authenticate with this request's credentials, never a saved account book.
            if (!IsReportCopy(rc)) return Fail("Invalid report copy", "A private report copy is required.");
            try
            {
                string config = Path.Combine(rc.Dir, "config");
                if (Directory.Exists(config)) foreach (string file in Directory.GetFiles(config, "accounts.*")) File.Delete(file);
            }
            catch (IOException) { return TransientFail(Lang.T("ذخیرهٔ ورود قبلی آزاد نیست", "Previous login cache is locked"), Lang.T("نسخهٔ خصوصی برای ورود تازه آماده نشد؛ اطلاعات ورود قبلی پاک نشد.", "The private terminal could not reset its previous login cache for a fresh authentication.")); }
            if (rc.Kind == Kind.MT5)
                Mt5Stage(job, "broker-catalog", Lang.T("آماده‌سازی اطلاعات سرور MT5", "Preparing MT5 server information"), () => { Mt5RefreshCatalog(job, rc); return true; });
            else PortableServers.RefreshClosed(rc, settings, acc);
            if (rc.Kind == Kind.MT4) TerminalUpdate.BeforeStart(rc);
            try { OldMonitor.Remove(rc); } catch { }
            // 3.19: no chart of its own, only the script's (the charts the terminal saved there last time are dropped).
            try { ChartProfile.UseEmpty(rc, true); }
            catch (Exception e) { Log.Write("empty profile " + rc.Name + ": " + e.Message); }
            if (!ReportScript.Deploy(settings, rc)) return Fail(Lang.T("اسکریپت در متاتریدر گزارش قرار نگرفت", "The script was not placed in the report MetaTrader"), Lang.T("اسکریپت گزارش در ", "The report script was not placed in ") + rc.Dir + Lang.T(" قرار نگرفت.", "."));

            string output = ReportLaunch.OutputPath(rc), startFile = ReportLaunch.StartFile(rc), stepFile = ReportLaunch.StepPath(rc);
            Encoding enc = rc.Kind == Kind.MT5 ? Encoding.Unicode : Encoding.Default;
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(output));
                foreach (string f in rc.Kind == Kind.MT5 ? new[] { output, output + ".part", stepFile, output + ".pulse", output + ".pulse.part" } : new[] { output, output + ".part", stepFile }) if (File.Exists(f)) File.Delete(f);
                foreach (string preset in ReportLaunch.PresetPaths(rc))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(preset));
                    File.WriteAllLines(preset, ReportLaunch.Preset(FromOf(job), acc, token, serve), enc);
                }
            }
            catch (Exception e) { return Fail(Lang.T("پوشه‌ی متاتریدر گزارش نوشتنی نیست", "The report MetaTrader's folder is not writable"), Lang.T("در پوشه‌ی متاتریدر گزارش نمی‌شود نوشت: ", "Cannot write in the report MetaTrader's folder: ") + e.Message); }

            if (rc.Kind == Kind.MT5) { if (job.From <= DateTime.MinValue) job.From = FromOf(job); WriteRequest(rc, job, token); }
            Process p = null;
            DateTime started;
            string symbol = null;
            // MT4 keeps at most 32 open for one Windows user: one start at a time, and only with room for it.
            bool gate = rc.Kind == Kind.MT4;
            if (gate) Monitor.Enter(Mt4Gate);
            try
            {
                if (Environment.OSVersion.Platform == PlatformID.Win32NT && !LaunchMemoryPolicy.CanStart(Checks.TotalRamMb(), Checks.FreeRamMb(), rc.Kind, 0))
                    return TransientFail(Lang.T("حافظهٔ کافی برای گزارش‌خوان بعدی نیست", "Insufficient memory for another reporter"), Lang.T("برای جلوگیری از کمبود حافظه، اجرای این گزارش‌خوان به تلاش بعدی موکول شد.", "This reporter was deferred to avoid exhausting memory."));
                if (rc.Kind == Kind.MT4 && !WaitForMt4Room(job)) return Fail(Lang.T("جای خالی برای MT4 نبود", "No free place for MT4"), Lang.T("MT4 جای خالی نداشت (حداکثر ", "MT4 had no free place (at most ") + Fa.N(Mt4Limit.Clamp(settings.MaxMt4)) + Lang.T(" هم‌زمان)؛ چند MT4 را ببندید و دوباره امتحان کنید.", " at a time); close a few MT4s and try again."));
                // The script's chart must be on a symbol the broker has, or it does not open (MT4) or never starts (MT5).
                List<string> known;
                if (rc.Kind == Kind.MT5) known = Mt5Stage(job, "chart-symbol", Lang.T("انتخاب نماد چارت MT5", "Selecting the MT5 chart symbol"), () => Mt5Symbols(job, rc, tried));
                else
                {
                known = ReportLaunch.KnownSymbols(job.Copy, acc.Server).Concat(ReportLaunch.KnownSymbols(rc, acc.Server)).ToList();
                bool exact; string native = ServerCatalog.InstallFor(rc.Kind, acc.Server, settings, out exact);
                if (native != null)
                    foreach (string root in PortableServers.Roots(native)) known.AddRange(ReportLaunch.KnownSymbols(new Instance { Kind = rc.Kind, Dir = root }, acc.Server));
                }
                known = known.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                string wanted = SymbolOf(rc);
                if (rc.Kind == Kind.MT5 && wanted == null) wanted = "EURUSD";
                if (rc.Kind == Kind.MT5)
                {
                    string stalled; mt5StalledCharts.TryGetValue(job.Copy.Name, out stalled);
                    string chartSource;
                    symbol = mt5Charts.Choose(acc.Server, wanted, known, tried, out chartSource, job.Attempt > 1 ? stalled : null);
                    if (diagnostics != null) diagnostics.Stage(job, "chart-selected", "symbol=" + (symbol ?? "none") + "; source=" + chartSource
                        + (job.Attempt > 1 && !string.IsNullOrEmpty(stalled) ? "; previous stalled chart=" + stalled : ""));
                }
                else symbol = ReportLaunch.PickSymbol(wanted, known, tried);
                if (symbol == null && tried.Count > 0)
                    return Fail(Lang.T("نماد چارتی برای اسکریپت نماند", "No chart symbol left for the script"),
                                Lang.T("متاتریدر ۵ اسکریپت گزارش را روی چارت ", "MetaTrader 5 kept the report script on the chart of ") + string.Join(Lang.T("، ", ", "), tried) + Lang.T(" نگه داشت و اجرا نکرد (این نمادها در این بروکر آماده نشدند) و نماد دیگری از این بروکر پیدا نشد. ", " and did not run it (these symbols were not ready at this broker), and no other symbol of this broker was found. ") +
                                Lang.T("نسخه‌ی MT5 این دانشجو را یک بار باز کنید تا فهرست نمادها (Market Watch) پر شود و دوباره گزارش بگیرید.", "Open this student's MT5 copy once so its symbol list (Market Watch) fills, then read the report again."));
                Log.Write("report: " + rc.Name + " chart " + (symbol ?? "EURUSD") + " (" + known.Count + " symbols known from the copies" +
                          (known.Count > 0 ? ": " + string.Join(", ", known.Take(6)) + (known.Count > 6 ? ", …" : "") : "") + ")" +
                          (tried.Count > 0 ? ", after " + string.Join(", ", tried) : ""));
                File.WriteAllLines(startFile, ReportLaunch.StartLines(rc.Kind, acc, password, symbol), enc);
                int waited = Pacer.Turn();
                if (waited > 0) Log.Write("report: " + rc.Name + " waited " + waited + " ms after the last start");
                ReportStartBudget.Reservation reservation = null;
                if (Environment.OSVersion.Platform == PlatformID.Win32NT)
                {
                    ulong observedPeak; lock (peaks) observedPeak = peaks.Count == 0 ? 0 : (ulong)peaks.Max();
                    reservation = StartBudget.TryAcquire(Checks.TotalRamMb, Checks.FreeRamMb, rc.Kind, observedPeak);
                    if (reservation == null)
                    {
                        Launcher.DeleteStartFile(startFile);
                        return TransientFail(Lang.T("حافظهٔ کافی برای گزارش‌خوان بعدی نیست", "Insufficient memory for another reporter"), Lang.T("حافظهٔ لازم برای گزارش‌خوان‌های در حال اجرا رزرو شده است؛ این حساب بعد از سایر حساب‌ها دوباره بررسی می‌شود.", "Memory is reserved for reporters already starting or running; this account will be retried after the others."));
                    }
                }
                started = DateTime.Now;
                try
                {
                    p = Process.Start(TerminalProcessPolicy.Prepare(new ProcessStartInfo(rc.Exe, Launcher.Arguments(rc.Kind, startFile))
                    {
                        WorkingDirectory = rc.Dir, UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden,
                    }, settings));
                    if (p != null && reservation != null) reservation.Attach(p);
                }
                catch (Exception e)
                {
                    if (reservation != null) reservation.Dispose();
                    Launcher.DeleteStartFile(startFile);
                    return Fail(Lang.T("متاتریدر گزارش باز نشد", "The report MetaTrader did not open"), Lang.T("متاتریدر گزارش باز نشد: ", "The report MetaTrader did not open: ") + e.Message);
                }
                if (p == null) { if (reservation != null) reservation.Dispose(); Launcher.DeleteStartFile(startFile); return Fail(Lang.T("متاتریدر گزارش باز نشد", "The report MetaTrader did not open"), Lang.T("متاتریدر گزارش باز نشد.", "The report MetaTrader did not open.")); }
                Owned.Add(p, rc.Exe);
                lock (live) live.Add(p);
                if (ending) { try { TerminalCloseAudit.Record(p,Processes.PathOf(p),"report-helper-force");p.Kill(); } catch { } }
                Native.HideWindowsOf(p.Id);
            }
            finally { if (gate) Monitor.Exit(Mt4Gate); }
            if (settings.LowPriority)
            {
                try { p.PriorityClass = ProcessPriorityClass.BelowNormal; } catch { }
            }
            Log.Write("report: started " + rc.Name + " for account " + acc.Login);

            var pending = new PendingStart { Path = startFile, Time = started, Process = p, Copy = rc };
            bool reading = false, updating = false, loaded = false, chartTimeout = false;
            long peak = 0;
            string lastProblem = null, step = null;
            DateTime lastLook = DateTime.MinValue, lastStep = started;
            DateTime lastStartupDisplay = DateTime.MinValue;
            DateTime? connectedAt = null;
            var mt5Startup = new Mt5StartupWatch(false, job.Attempt > 1);
            var nativeClock = Stopwatch.StartNew(); long reporterStartedAt = -1; string lastPulsePhase = null;
            bool nativeTimingRecorded = false;
            try
            {
                while (true)
                {
                    DateTime now = DateTime.Now;
                    if (pending != null && pending.Ready(now) != null)
                    {
                        Launcher.DeleteStartFile(startFile);
                        Log.Write("start file of " + rc.Name + " deleted after " + (now - started).TotalSeconds.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture) + " s");
                        pending = null;
                    }
                    Outcome read = ReadOutput(output, acc, FromOf(job), token);
                    if (read != null)
                    {
                        if (read.Journal != null)
                        {
                            if (rc.Kind == Kind.MT5)
                            {
                                mt5Charts.Remember(acc.Server, symbol);
                                string ignored; mt5StalledCharts.TryRemove(job.Copy.Name, out ignored);
                                if (diagnostics != null) diagnostics.Timing(job, reporterStartedAt < 0 ? "reporter-start" : "history", nativeClock.ElapsedMilliseconds - Math.Max(0, reporterStartedAt), "cold result received; valid request-matched report");
                                nativeTimingRecorded = true;
                            }
                            commit(read);
                            // MT5's native expert serves durable requests regardless of the preset's
                            // ServeMode flag. A successful recovery may keep this very process warm.
                            if (rc.Kind == Kind.MT5 && warmRecovery.ColdSuccess(WarmKey(slot, rc.Dir)) && CanWarm(slot, rc) && !HasExited(p))
                            { warm[slot] = new WarmTerminal { Copy = rc, Process = p, Login = new ReportLoginSession(settings), Server = acc.Server.Trim() }; keep = true; }
                        }
                        return read;
                    }
                    if (ending) return Fail(Lang.T("متوقف شد", "Stopped"), Lang.T("به درخواست شما متوقف شد.", "Stopped at your request."));
                    if (rc.Kind == Kind.MT5 && step == null && (now - lastStartupDisplay).TotalSeconds >= 1)
                    {
                        lastStartupDisplay = now;
                        Say(job.Index, StepState.Starting,
                            (connectedAt.HasValue ? Lang.T("MT5 متصل است؛ منتظر شروع گزارش‌خوان", "MT5 connected; waiting for the reporter") : Lang.T("MT5 اجرا شد؛ منتظر اتصال و شروع گزارش‌خوان", "MT5 launched; waiting for connection and reporter"))
                            + " — " + Fa.N((int)(now - started).TotalSeconds) + Lang.T(" ثانیه", " s"));
                    }
                    // Where the script is: shown in the progress window, and the wait goes on while it moves.
                    string now1 = TextFiles.ReadText(stepFile);
                    if (now1 != null && now1.Trim().Length > 0 && now1.Trim() != step)
                    {
                        step = now1.Trim();
                        Log.Write("report native step: " + job.Copy.Name + " " + step + " at " + (job.Clock == null ? 0 : job.Clock.ElapsedMilliseconds) + "ms");
                        lastStep = now;
                        reading = true;
                        string said = ReportLaunch.StepText(step);
                        if (said != null) Say(job.Index, StepState.Reading, said);
                    }
                    if (rc.Kind == Kind.MT5 && step != null && (now - lastStartupDisplay).TotalSeconds >= 1)
                    {
                        lastStartupDisplay = now;
                        string detail = ReportLaunch.StepText(step);
                        if (detail != null) Say(job.Index, StepState.Reading, detail + " — " + Fa.N((int)(now - lastStep).TotalSeconds) + Lang.T(" ثانیه", " s"));
                    }
                    if (rc.Kind == Kind.MT5)
                    {
                        Mt5ReporterPulse pulse = Mt5ReporterPulse.TryParse(TextFiles.ReadText(output + ".pulse"), token, acc);
                        mt5Startup.Pulse(pulse, nativeClock.ElapsedMilliseconds);
                        if (pulse != null && pulse.Stage != lastPulsePhase) { lastPulsePhase = pulse.Stage; if (mt5Startup.ReporterStarted) lastStep = now; }
                        if (mt5Startup.ReporterStarted && reporterStartedAt < 0)
                        {
                            reporterStartedAt = nativeClock.ElapsedMilliseconds;
                            if (diagnostics != null) diagnostics.Timing(job, "reporter-start", reporterStartedAt, "cold native reporter acknowledged current request");
                        }
                    }
                    bool exited = HasExited(p);
                    if ((now - lastLook).TotalSeconds >= 1.5 || exited)
                    {
                        lastLook = now;
                        if (!exited) { peak = Math.Max(peak, Native.PeakMb(p)); Native.HideWindowsOf(p.Id); }
                        List<string> lines = ConnectionCheck.JournalTail(rc, started);
                        if (SelfUpdate.InLines(lines)) updating = true;
                        LoginResult login = ConnectionCheck.FromJournal(lines, acc.Login.Trim());
                        if (login.State == Login.WrongLogin)
                            return Fail(Lang.T("ورود نشد: رمز ورود یا شماره حساب اشتباه", "Login failed: wrong login password or account number"), Lang.T("ورود نشد: شماره حساب یا رمز ورود اشتباه است.", "Login failed: the account number or login password is wrong."));
                        if (login.State == Login.NoServer)
                            return Fail(Lang.T("سرور پیدا نشد", "Server not found"), Lang.T("سرور «", "Server “") + acc.Server + Lang.T("» در متاتریدر گزارش پیدا نشد.", "” was not found in the report MetaTrader."));
                        if (login.State == Login.NoConnection) lastProblem = Lang.T("اتصال به سرور برقرار نشد", "Could not connect to the server");
                        if (login.State == Login.Connected) { lastProblem = null; if (connectedAt == null) connectedAt = now; }
                        if (login.State == Login.Connected && !reading)
                        {
                            reading = true;
                            Say(job.Index, StepState.Reading, null);
                        }
                        if (rc.Kind == Kind.MT5)
                        {
                            if (!mt5Startup.ReporterStarted) ObserveMt5Network(mt5Startup, lines, acc, nativeClock.ElapsedMilliseconds);
                            if (!loaded) loaded = lines.Any(ReportTrace.ScriptLoaded);
                            if (!chartTimeout) chartTimeout = lines.Any(ReportTrace.ChartTimeout);
                        }
                    }
                    if (exited)
                    {
                        // MT5 closes itself as soon as the script ends: the file may have come with the close.
                        read = ReadOutput(output, acc, FromOf(job), token);
                        if (read != null) { if (read.Journal != null) commit(read); return read; }
                        if (updating)
                        {
                            FollowRestart(rc);
                            return new Outcome { Retry = true, Short = Lang.T("متاتریدر گزارش برای به‌روزرسانی بسته شد", "The report MetaTrader closed to update itself"), Long = Lang.T("متاتریدر گزارش برای به‌روزرسانی خودش بسته شد؛ گزارش را دوباره بگیرید.", "The report MetaTrader closed to update itself; read the report again.") };
                        }
                        string why = ReportTrace.Explain(rc, started, symbol, step == null);
                        return TransientFail(Lang.T("متاتریدر گزارش زودتر بسته شد", "The report MetaTrader closed too early"), Lang.T("متاتریدر گزارش پیش از نوشتن تاریخچه بسته شد", "The report MetaTrader closed before writing the history") + (lastProblem != null ? " (" + lastProblem + ")" : "") + (why != null ? ". " + why : "") + ".");
                    }
                    // MT5 loads the script with its chart and starts it once the chart's symbol is ready. A symbol the broker does not
                    // have is never ready, and MT5 keeps the script waiting for minutes: try another of the broker's symbols instead.
                    if (rc.Kind == Kind.MT5 && !mt5Startup.ReporterStarted && (loaded && chartTimeout || mt5Startup.Expired(nativeClock.ElapsedMilliseconds)))
                    {
                        if (loaded && step == null && !string.IsNullOrEmpty(symbol)) mt5StalledCharts[job.Copy.Name] = symbol;
                        if (diagnostics != null) diagnostics.Timing(job, "reporter-start", nativeClock.ElapsedMilliseconds, "bounded startup wait exhausted; no fresh report accepted");
                        nativeTimingRecorded = true;
                        string why = ReportTrace.Explain(rc, started, symbol, true);
                        return Mt5StartupFailure(step == "ready", chartTimeout, symbol, connectedAt.HasValue, (int)(nativeClock.ElapsedMilliseconds / 1000), why);
                    }
                    if (rc.Kind == Kind.MT4 && (ReportLaunch.HeldOnChart(rc.Kind, step, loaded, chartTimeout, connectedAt, now) || (step == null && connectedAt.HasValue && (now - connectedAt.Value).TotalSeconds >= 10)))
                    {
                        string why = ReportTrace.Explain(rc, started, symbol, true);
                        // No startup acknowledgement does not prove that a broker lacks the symbol.
                        // Rotate charts only with an explicit native synchronization-timeout record.
                        if (rc.Kind == Kind.MT5) return Mt5StartupFailure(false, chartTimeout, symbol, connectedAt.HasValue, (int)(now - started).TotalSeconds, why);
                        Log.Write("report: " + rc.Name + " kept the script waiting on its " + symbol + " chart" + (chartTimeout ? " (symbol synchronization timeout)" : "") +
                                  "; the broker may not have this symbol");
                        return new Outcome
                        {
                            WrongSymbol = symbol, Transient = true,
                            Short = Lang.T("نماد ", "Symbol ") + symbol + Lang.T(" در این بروکر نبود", " was not available at this broker"),
                            Long = Lang.T("متاتریدر ۵ اسکریپت گزارش را روی چارت ", "MetaTrader 5 kept the report script on the chart of ") + symbol + Lang.T(" نگه داشت و اجرا نکرد", " kept it and did not run it") + (why != null ? ": " + why : "") + ".",
                        };
                    }
                    if (rc.Kind == Kind.MT4 && (step == null || step == "start") && lastProblem != null && (now - started).TotalSeconds >= 30)
                        return TransientFail(lastProblem, Lang.T("در مهلت بررسی اتصال سرور برقرار نشد؛ یک تلاش دوباره پس از سایر حساب‌ها انجام می‌شود.", "The server connection did not complete in the check budget; one deferred retry is allowed."));
                    if (rc.Kind == Kind.MT4 && step == null && (now - started).TotalSeconds >= ReportLaunch.StartSeconds)
                    {
                        string why = ReportTrace.Explain(rc, started, symbol, true);
                        return TransientFail(lastProblem ?? Lang.T("اسکریپت گزارش شروع نشد", "The report script did not start"),
                                    Lang.T("اسکریپت گزارش در ", "The report script was not placed in ") + Fa.N(ReportLaunch.StartSeconds) + Lang.T(" ثانیه شروع نشد", " seconds and did not start") + (lastProblem != null ? " (" + lastProblem + ")" : "") + (why != null ? ". " + why : "") + ".");
                    }
                    if ((step != null || rc.Kind == Kind.MT5 && mt5Startup.ReporterStarted) && ((now - lastStep).TotalSeconds >= ReportLaunch.StallSeconds || (now - started).TotalSeconds >= ReportLaunch.MaxSeconds))
                    {
                        string why = ReportTrace.Explain(rc, started, symbol, false);
                        string at = ReportLaunch.StepText(step) ?? step ?? lastPulsePhase ?? Lang.T("دریافت نتیجه", "Receiving result");
                        return TransientFail(Lang.T("اسکریپت گزارش ماند: ", "The report script got stuck: ") + at.TrimEnd('…'),
                                    Lang.T("اسکریپت گزارش در این مرحله ماند و تمام نشد: ", "The report script stopped at this step and did not finish: ") + at.TrimEnd('…') + (why != null ? ". " + why : "") + ".");
                    }
                    Thread.Sleep(500);
                }
            }
            finally
            {
                if (rc.Kind == Kind.MT5 && !nativeTimingRecorded && diagnostics != null)
                    diagnostics.Timing(job, reporterStartedAt < 0 ? "reporter-start" : "history", nativeClock.ElapsedMilliseconds - Math.Max(0, reporterStartedAt), "cold native observation ended");
                if (diagnostics != null) diagnostics.Capture(job, rc, started, keep ? "resident-live" : "cold-before-close", rc.Kind == Kind.MT5 ? token : null);
                Launcher.DeleteStartFile(startFile);
                peak = Math.Max(peak, Native.PeakMb(p));
                if (!keep)
                {
                    using (diagnostics == null ? null : diagnostics.Measure(job, "close")) End(p, rc);
                    if (diagnostics != null) diagnostics.Capture(job, rc, started, "cold-after-close", rc.Kind == Kind.MT5 ? token : null);
                    lock (live) live.Remove(p); if (p != null) p.Dispose();
                }
                if (peak > 0)
                {
                    Log.Write("report: " + rc.Name + " held at most " + peak + " MB of memory");
                    lock (peaks) peaks.Add(peak);
                }
            }
        }

    }
}
