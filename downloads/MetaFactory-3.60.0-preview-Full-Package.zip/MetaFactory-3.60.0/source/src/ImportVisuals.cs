using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MTManager
{
    static class ImportArt
    {
        public static void Text(Graphics g, string text, Font font, Color color, Rectangle bounds, bool center = false)
        {
            var flags = TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter;
            flags |= center ? TextFormatFlags.HorizontalCenter : Lang.En ? TextFormatFlags.Left : TextFormatFlags.Right;
            if (!Lang.En) flags |= TextFormatFlags.RightToLeft;
            TextRenderer.DrawText(g, text, font, bounds, color, flags);
        }
        public static int X(int x, int width, int total) { return Lang.En ? x : total - x - width; }
        public static void Excel(Graphics g, Rectangle box, Color ink)
        {
            Glyphs.Draw(g, Glyph.Doc, box, ink);
            var badge = new Rectangle(box.Left - Theme.S(2), box.Top + box.Height / 3, box.Width * 2 / 3, box.Height / 2);
            Theme.Box(g, badge, Theme.Sf(2), ink, ink);
            Text(g, "X", Theme.Bold, Theme.OnAccent, badge, true);
        }
        public static void Pill(Graphics g, Rectangle box, string text, Color fill, Color color, Glyph icon = Glyph.None)
        {
            if (box.Width < 4 || box.Height < 4) return;
            Theme.Box(g, box, box.Height / 2f, fill, fill);
            var label = Rectangle.Inflate(box, -Theme.S(9), 0);
            if (icon != Glyph.None)
            {
                int size = Theme.S(14);
                int x = Lang.En ? box.Left + Theme.S(9) : box.Right - Theme.S(9) - size;
                var rect = new RectangleF(x, box.Top + (box.Height - size) / 2f, size, size);
                if (icon == Glyph.Refresh)
                {
                    var state = g.Save();
                    g.TranslateTransform(rect.X + size / 2f, rect.Y + size / 2f);
                    g.RotateTransform((Environment.TickCount & int.MaxValue) / 100f * 30 % 360);
                    Glyphs.Draw(g, icon, new RectangleF(-size / 2f, -size / 2f, size, size), color);
                    g.Restore(state);
                }
                else Glyphs.Draw(g, icon, rect, color);
                if (Lang.En) label.X += size + Theme.S(5);
                label.Width -= size + Theme.S(5);
            }
            Text(g, text, Theme.SmallBold, color, label, true);
        }
    }

    class ImportSurface : Panel
    {
        public Color Fill, Edge;
        public ImportSurface()
        {
            Fill = Theme.Surface; Edge = Theme.Border;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.Clear(Theme.BackOf(Parent));
            Theme.Box(e.Graphics, new Rectangle(0, 0, Width - 1, Height - 1), Theme.Sf(10), Fill, Edge);
        }
    }

    sealed class ImportSteps : Control
    {
        int current; bool finished;
        public int Current { get { return current; } set { current = value; Invalidate(); } }
        public bool Finished { get { return finished; } set { finished = value; Invalidate(); } }
        public ImportSteps() { Height = Theme.S(36); SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true); }
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; g.Clear(Theme.Surface); g.SmoothingMode = SmoothingMode.AntiAlias;
            string[] names = { Lang.T("انتخاب فایل", "Select file"), Lang.T("بررسی اطلاعات", "Review data"), Lang.T("بررسی اتصال", "Check connections") };
            int gap = Theme.S(42), group = Math.Max(1, (Width - gap * 2) / 3), h = Theme.S(32);
            for (int i = 0; i < 3; i++)
            {
                int x = ImportArt.X(i * (group + gap), group, Width), y = (Height - h) / 2;
                bool done = i < current || (i == 2 && finished), active = i == current;
                if (active) Theme.Box(g, new Rectangle(x, y, group, h), Theme.Sf(9), Theme.AccentSoft, Theme.AccentSoft);
                int size = Theme.S(21), cx = Lang.En ? x + Theme.S(12) : x + group - Theme.S(12) - size;
                using (var b = new SolidBrush(done || active ? Theme.Accent : Theme.Border)) g.FillEllipse(b, cx, y + (h - size) / 2, size, size);
                if (done) Glyphs.Draw(g, Glyph.Check, new RectangleF(cx + Theme.S(5), y + (h - size) / 2 + Theme.S(5), size - Theme.S(10), size - Theme.S(10)), Theme.OnAccent);
                else ImportArt.Text(g, Fa.N(i + 1), Theme.SmallBold, active ? Theme.OnAccent : Theme.Muted, new Rectangle(cx, y, size, h), true);
                int tx = Lang.En ? cx + size + Theme.S(10) : x + Theme.S(10);
                ImportArt.Text(g, names[i], Theme.Bold, active || done ? Theme.Accent : Theme.Muted, new Rectangle(tx, y, Math.Max(1, group - size - Theme.S(36)), h));
                if (i < 2)
                {
                    int lineX = ImportArt.X(i * (group + gap) + group + Theme.S(8), gap - Theme.S(16), Width);
                    using (var pen = new Pen(i < current ? Theme.Accent : Theme.Border)) g.DrawLine(pen, lineX, Height / 2, lineX + gap - Theme.S(16), Height / 2);
                }
            }
        }
    }

    sealed class ImportStat : Control
    {
        readonly string title; readonly Color fill, color; readonly Glyph glyph;
        readonly Font numberFont;
        int count;
        public int Count { get { return count; } set { count = value; AccessibleName = title + ": " + Fa.N(value); Invalidate(); } }
        public ImportStat(string title, Color fill, Color color, Glyph glyph)
        {
            this.title = title; this.fill = Color.FromArgb((fill.R + Theme.Surface.R) / 2, (fill.G + Theme.Surface.G) / 2, (fill.B + Theme.Surface.B) / 2); this.color = color; this.glyph = glyph;
            numberFont = new Font(Theme.Number.FontFamily, Theme.Number.Size * 1.3f, FontStyle.Bold);
            AccessibleRole = AccessibleRole.StaticText;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; g.Clear(Theme.Surface); g.SmoothingMode = SmoothingMode.AntiAlias;
            Theme.Box(g, new Rectangle(0, 0, Width - 1, Height - 1), Theme.Sf(11), fill, Color.FromArgb(45, color));
            int icon = Theme.S(23), pad = Theme.S(14), x = Lang.En ? pad : Width - pad - icon;
            Glyphs.Draw(g, glyph, new RectangleF(x, Theme.S(12), icon, icon), color);
            int textX = Lang.En ? pad + icon + Theme.S(10) : pad;
            int textW = Math.Max(1, Width - pad * 2 - icon - Theme.S(10));
            ImportArt.Text(g, title, Theme.Bold, color, new Rectangle(textX, Theme.S(8), textW, Theme.S(21)));
            ImportArt.Text(g, Fa.N(count), numberFont, color, new Rectangle(textX, Theme.S(29), textW, Theme.S(30)));
        }
        protected override void Dispose(bool disposing) { if (disposing) numberFont.Dispose(); base.Dispose(disposing); }
    }

    sealed class ImportFileCard : ImportSurface
    {
        readonly Label fileName; readonly Button open, template;
        int count;
        public int Count { get { return count; } set { count = value; Invalidate(); } }
        public ImportFileCard(Label name, Button open, Button template)
        {
            fileName = name; this.open = open; this.template = template;
            Fill = Theme.Surface; BackColor = Theme.Surface; Edge = Theme.Surface;
            Height = Theme.S(52);
            fileName.Font = Theme.Bold; fileName.TextAlign = Lang.En ? ContentAlignment.MiddleLeft : ContentAlignment.MiddleRight;
            fileName.BackColor = Color.Transparent;
            Controls.Add(fileName); Controls.Add(open); Controls.Add(template);
        }
        public override Size GetPreferredSize(Size proposed) { return new Size(400, Theme.S(52)); }
        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            if (fileName == null || open == null || template == null) return;
            int pad = Theme.S(14), gap = Theme.S(8), iw = Theme.S(36), actions = open.Width + template.Width + gap;
            int ax = Lang.En ? Width - pad - actions : pad;
            open.Location = new Point(ax, (Height - open.Height) / 2);
            template.Location = new Point(ax + open.Width + gap, (Height - template.Height) / 2);
            int left = Lang.En ? pad + iw + Theme.S(14) : ax + actions + Theme.S(12);
            int right = Lang.En ? ax - Theme.S(12) : Width - pad - iw - Theme.S(14);
            int badge = Theme.S(78);
            fileName.Bounds = new Rectangle(Lang.En ? left : left + badge + gap, Theme.S(12), Math.Max(1, right - left - badge - gap), Height - Theme.S(24));
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            int pad = Theme.S(14), size = Theme.S(34), x = Lang.En ? pad : Width - pad - size;
            ImportArt.Excel(e.Graphics, new Rectangle(x, (Height - size) / 2, size, size), Theme.Ok);
            int badgeW = Theme.S(78);
            int bx = Lang.En ? fileName.Right + Theme.S(8) : fileName.Left - Theme.S(8) - badgeW;
            ImportArt.Text(e.Graphics, Fa.N(count) + Lang.T(" دانشجو", " students"), Theme.Small, Theme.Muted, new Rectangle(bx, (Height - Theme.S(26)) / 2, badgeW, Theme.S(26)));
        }
    }
}
