using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;

namespace MTManager
{
    /// <summary>Local schedule editor. Saving configures future deliveries; this dialog never sends a report.</summary>
    public sealed class ScheduleDialog : Form
    {
        readonly ScheduleOptions original;
        readonly Panel scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        TableLayoutPanel body;
        readonly Panel channelDetails=new Panel{Dock=DockStyle.Top,AutoSize=true,Margin=Padding.Empty};
        readonly Dictionary<string,TableLayoutPanel> channelPages=new Dictionary<string,TableLayoutPanel>();
        readonly Dictionary<string,DeliveryChannelTab> channelTabs=new Dictionary<string,DeliveryChannelTab>();
        readonly Button telegramPaste=new Button(),balePaste=new Button();
        readonly ToolTip hints=new ToolTip();
        internal Control EditorContent { get { return scroll; } }
        string selectedChannel;
        string initialUiState;
        internal bool IsDirty { get { return original.BotSettingsMigrationPending||initialUiState!=null && UiState()!=initialUiState; } }
        string UiState()
        {
            var values=new[]{telegramBotEnabled.Checked.ToString(),baleBotEnabled.Checked.ToString(),dailyEnabled.Checked.ToString(),time.Text,platform.SelectedIndex.ToString(System.Globalization.CultureInfo.InvariantCulture),telegramEnabled.Checked.ToString(),telegramToken.Text,telegramChat.Text,baleEnabled.Checked.ToString(),baleToken.Text,baleChat.Text,emailEnabled.Checked.ToString(),smtpHost.Text,smtpPort.Value.ToString(System.Globalization.CultureInfo.InvariantCulture),smtpSsl.Checked.ToString(),smtpUser.Text,smtpPassword.Text,emailFrom.Text,emailTo.Text};
            var text=new System.Text.StringBuilder();foreach(string value in values){text.Append(value.Length);text.Append(':');text.Append(value);}
            using(var hash=System.Security.Cryptography.SHA256.Create())return Convert.ToBase64String(hash.ComputeHash(System.Text.Encoding.UTF8.GetBytes(text.ToString())));
        }
        readonly CheckBox telegramBotEnabled=new DeliveryToggle(),baleBotEnabled=new DeliveryToggle();
        readonly Dictionary<string,Label> botStatusLabels=new Dictionary<string,Label>();
        readonly Timer botStatusTimer=new Timer{Interval=1000};
        readonly Timer botAutoTimer=new Timer{Interval=1000};
        readonly Dictionary<string,bool> pendingBotEdits=new Dictionary<string,bool>();
        Func<string,string,bool,ScheduleOptions> autoSaveBot;
        bool applyingBotEdit;
        internal void SetBotAutoSave(Func<string,string,bool,ScheduleOptions> save)
        {
            if(autoSaveBot!=null)throw new InvalidOperationException("Bot autosave is already attached.");
            autoSaveBot=save;
            telegramToken.TextChanged+=(sender,e)=>QueueBotEdit("Telegram",true);
            baleToken.TextChanged+=(sender,e)=>QueueBotEdit("Bale",true);
            telegramBotEnabled.CheckedChanged+=(sender,e)=>QueueBotEdit("Telegram",false);
            baleBotEnabled.CheckedChanged+=(sender,e)=>QueueBotEdit("Bale",false);
        }
        void QueueBotEdit(string channel,bool activate)
        {
            if(applyingBotEdit||autoSaveBot==null)return;
            pendingBotEdits[channel]=activate;botAutoTimer.Stop();botAutoTimer.Start();
        }
        internal void FlushBotConnections()
        {
            botAutoTimer.Stop();if(autoSaveBot==null)return;
            var edits=pendingBotEdits.ToArray();pendingBotEdits.Clear();
            foreach(var edit in edits)
            {
                string channel=edit.Key;var field=channel=="Bale"?baleToken:telegramToken;var toggle=channel=="Bale"?baleBotEnabled:telegramBotEnabled;
                string token=field.Text.Trim();bool enabled=edit.Value||toggle.Checked;
                if(!enabled&&!TelegramControlOptions.ValidTokenFor(channel,token))token=channel=="Bale"?balePlain:telegramPlain;
                if(enabled&&!TelegramControlOptions.ValidTokenFor(channel,token))
                {ShowError(Lang.T("توکن کامل و معتبر وارد کن؛ اتصال قبلی تغییر نکرد.","Enter a complete valid token; the existing connection was preserved."));continue;}
                try
                {
                    var saved=autoSaveBot(channel,token??"",enabled);
                    applyingBotEdit=true;
                    try
                    {
                        toggle.Checked=enabled;
                        if(channel=="Bale"){original.BaleBotEnabled=saved.BaleBotEnabled;original.BaleTokenEnc=saved.BaleTokenEnc;balePlain=Secret.Unprotect(saved.BaleTokenEnc);}
                        else{original.TelegramBotEnabled=saved.TelegramBotEnabled;original.TelegramTokenEnc=saved.TelegramTokenEnc;telegramPlain=Secret.Unprotect(saved.TelegramTokenEnc);}
                        original.BotSettingsUnified=true;original.BotSettingsMigrationPending=false;
                    }
                    finally{applyingBotEdit=false;}
                    error.Visible=false;RefreshBotStatus();
                }
                catch{ShowError(Lang.T("ذخیرهٔ خودکار اتصال انجام نشد؛ توکن را دوباره وارد کن. اتصال قبلی حفظ شد.","Could not save the bot connection automatically; enter the token again. The previous connection was preserved."));}
            }
        }

        Func<string,string> botStatusProvider;
        internal void SetBotStatus(Func<string,string> provider){botStatusProvider=provider;RefreshBotStatus();botStatusTimer.Start();}
        void RefreshBotStatus(){if(botStatusProvider==null)return;foreach(var pair in botStatusLabels)pair.Value.Text=botStatusProvider(pair.Key)??"";FitLabels();}
        readonly CheckBox dailyEnabled = new DeliveryToggle(), telegramEnabled = new CheckBox(), baleEnabled = new CheckBox(), emailEnabled = new DeliveryToggle(), smtpSsl = new CheckBox();
        readonly TextBox time = Box(), telegramToken = Box(true), telegramChat = Box(), baleToken = Box(true), baleChat = Box();
        readonly TextBox smtpHost = Box(), smtpUser = Box(), smtpPassword = Box(true), emailFrom = Box(), emailTo = Box();
        readonly NumericUpDown smtpPort = new NumericUpDown { Minimum = 1, Maximum = 65535 };
        readonly ComboBox platform = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
        readonly Label error = new Label { AutoSize = true };
        readonly Button saveButton = new Button(), cancelButton = new Button();
        readonly List<Label> fullLabels = new List<Label>();
        string telegramPlain, balePlain;
        readonly string smtpPlain;
        public ScheduleOptions Options { get; private set; }

        static TextBox Box(bool secret = false)
        { return new TextBox { UseSystemPasswordChar = secret, RightToLeft = RightToLeft.No, Dock = DockStyle.Fill }; }

        static ScheduleOptions Copy(ScheduleOptions value)
        {
            value = value ?? new ScheduleOptions();
            return new ScheduleOptions {
                Enabled = value.Enabled, Time = value.Time, Platform = value.Platform, BotSettingsUnified=value.BotSettingsUnified,TelegramBotEnabled=value.TelegramBotEnabled,BaleBotEnabled=value.BaleBotEnabled,BotSettingsMigrationPending=value.BotSettingsMigrationPending,
                TelegramEnabled = value.TelegramEnabled, TelegramTokenEnc = value.TelegramTokenEnc, TelegramChatId = value.TelegramChatId,
                BaleEnabled = value.BaleEnabled, BaleTokenEnc = value.BaleTokenEnc, BaleChatId = value.BaleChatId,
                EmailEnabled = value.EmailEnabled, SmtpHost = value.SmtpHost, SmtpPort = value.SmtpPort, SmtpSsl = value.SmtpSsl,
                SmtpUser = value.SmtpUser, SmtpPasswordEnc = value.SmtpPasswordEnc, EmailFrom = value.EmailFrom, EmailTo = value.EmailTo
            };
        }

        public ScheduleDialog(ScheduleOptions options, string lastStatus)
        {
            original = Copy(options); Options = Copy(original);
            Text = Lang.T("ارسال و زمان‌بندی", "Delivery and scheduling");
            Font = Theme.Font; BackColor = Theme.Surface; ForeColor = Theme.Text;
            StartPosition = FormStartPosition.CenterParent; MinimizeBox = false;
            ClientSize = new Size(Theme.S(760), Theme.S(540)); MinimumSize = new Size(Theme.S(580), Theme.S(400));
            RightToLeft = Lang.En ? RightToLeft.No : RightToLeft.Yes;
            scroll.BackColor=Theme.Surface;scroll.Padding=Theme.Pad(16,12,16,10);scroll.RightToLeft=RightToLeft.No;
            var content=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=1,Padding=Padding.Empty,Margin=Padding.Empty,RightToLeft=RightToLeft.No};
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));scroll.Controls.Add(content);Controls.Add(scroll);
            body=NewBody();body.Padding=Padding.Empty;AddContent(content,body);
            error.ForeColor = Theme.Bad; error.Font = Theme.Small; error.Visible = false; Full(error);
            if (!string.IsNullOrWhiteSpace(lastStatus)) Full(Lang.T("آخرین وضعیت: ", "Last status: ") + lastStatus, Theme.Small, Theme.Muted);
            if (options != null && !string.IsNullOrEmpty(options.LoadError)) Full(options.LoadError, Theme.Small, Theme.Warn);

            dailyEnabled.Checked=original.Enabled;dailyEnabled.AccessibleName=Lang.T("گزارش و ارسال خودکار روزانه فعال باشد", "Enable daily reports and automatic delivery");
            dailyEnabled.Size=new Size(Theme.S(42),Theme.S(26));dailyEnabled.Anchor=AnchorStyles.None;
            time.Text = original.Time ?? "22:00"; time.MaxLength = 5;
            time.AccessibleName=Lang.T("ساعت محلی (HH:mm)", "Local time (HH:mm)");
            platform.Items.AddRange(new object[] { Lang.T("همهٔ حساب‌ها", "All accounts"), "MT4", "MT5" });
            platform.SelectedIndex = string.Equals(original.Platform, "MT4", StringComparison.OrdinalIgnoreCase) ? 1 : string.Equals(original.Platform, "MT5", StringComparison.OrdinalIgnoreCase) ? 2 : 0;
            platform.RightToLeft=RightToLeft.No;platform.AccessibleName=Lang.T("محدودهٔ حساب‌ها","Account scope");
            hints.SetToolTip(time,Lang.T("ساعت محلی همین کامپیوتر؛ HH:mm","This PC's local time; HH:mm"));
            var dailyRow=new TableLayoutPanel{Dock=DockStyle.Top,Height=Theme.S(46),ColumnCount=7,Margin=Theme.Pad(0,0,0,8),Padding=Padding.Empty,RightToLeft=RightToLeft.No};
            dailyRow.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            var dailyLabel=new Label{Text=Lang.T("ارسال روزانه","Daily delivery"),Font=Theme.Font,ForeColor=Theme.Text,Dock=DockStyle.Fill,TextAlign=Lang.En?ContentAlignment.MiddleLeft:ContentAlignment.MiddleRight,RightToLeft=Lang.En?RightToLeft.No:RightToLeft.Yes,Margin=Padding.Empty};
            if(Lang.En)
            {
                dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(112)));dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(48)));dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(105)));dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(12)));dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(185)));dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,0));
                dailyRow.Controls.Add(dailyLabel,0,0);dailyRow.Controls.Add(dailyEnabled,1,0);dailyRow.Controls.Add(time,3,0);dailyRow.Controls.Add(platform,5,0);
            }
            else
            {
                dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(185)));dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(12)));dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(105)));dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(48)));dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(112)));dailyRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,0));
                dailyRow.Controls.Add(platform,0,0);dailyRow.Controls.Add(time,2,0);dailyRow.Controls.Add(dailyEnabled,4,0);dailyRow.Controls.Add(dailyLabel,5,0);
            }
            time.Dock=DockStyle.Fill;time.Margin=Theme.Pad(0,8,0,6);platform.Dock=DockStyle.Fill;platform.Margin=Theme.Pad(0,7,0,6);AddContent(content,dailyRow);
            var tabs=new TableLayoutPanel{Dock=DockStyle.Top,Height=Theme.S(62),ColumnCount=3,Margin=Theme.Pad(0,0,0,12),Padding=Padding.Empty,RightToLeft=RightToLeft.No};
            for(int i=0;i<3;i++)tabs.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100f/3));tabs.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            AddContent(content,tabs);
            AddChannelTab(tabs,Lang.En?0:2,"telegram",Lang.T("تلگرام","Telegram"),telegramBotEnabled,original.TelegramBotEnabled);
            AddChannelTab(tabs,1,"bale",Lang.T("بله","Bale"),baleBotEnabled,original.BaleBotEnabled);
            AddChannelTab(tabs,Lang.En?2:0,"email",Lang.T("ایمیل","Email"),emailEnabled,original.EmailEnabled);
            AddContent(content,channelDetails);

            body=NewChannelPage("bale");
            balePlain = Secret.Unprotect(original.BaleTokenEnc); baleToken.Text = balePlain ?? ""; baleChat.Text = original.BaleChatId ?? "";
            Row(Lang.T("توکن ربات", "Bot token"),TokenField(baleToken,balePaste));
            BotChannelControls("Bale",baleEnabled,original.BaleEnabled,baleChat);
            SecretNote(balePlain, original.BaleTokenEnc);
            Full(Lang.T("توکن کامل را وارد کن؛ ذخیره و اتصال خودکار است. هر کسی /start بفرستد می‌تواند گزارش بگیرد؛ نیازی به شناسه نیست.","Paste a complete token to save and connect automatically. Anyone can send /start and request reports; no user ID is required."),Theme.Small,Theme.Muted);
            BotEditing(baleToken,baleChat,balePaste);

            body=NewChannelPage("telegram");
            telegramPlain = Secret.Unprotect(original.TelegramTokenEnc); telegramToken.Text = telegramPlain ?? ""; telegramChat.Text = original.TelegramChatId ?? "";
            Row(Lang.T("توکن ربات", "Bot token"),TokenField(telegramToken,telegramPaste));
            BotChannelControls("Telegram",telegramEnabled,original.TelegramEnabled,telegramChat);
            SecretNote(telegramPlain, original.TelegramTokenEnc);
            BotEditing(telegramToken,telegramChat,telegramPaste);
            Full(Lang.T("تیک کنار لوگو، پاسخ‌گویی به /start و دریافت گزارش را فعال می‌کند. توکن کامل را وارد کن؛ ذخیره و اتصال خودکار است. همین توکن برای ارسال و دریافت مشترک است.","The logo switch enables /start menus and report requests. Paste a complete token to save and connect automatically. This token is shared by bot replies and outbound delivery."),Theme.Small,Theme.Muted);

            body=NewChannelPage("email");
            smtpHost.Text = original.SmtpHost ?? ""; smtpPort.Value = Math.Max(1, Math.Min(65535, original.SmtpPort));
            smtpUser.Text = original.SmtpUser ?? ""; smtpPlain = Secret.Unprotect(original.SmtpPasswordEnc); smtpPassword.Text = smtpPlain ?? "";
            emailFrom.Text = original.EmailFrom ?? ""; emailTo.Text = original.EmailTo ?? "";
            Row(Lang.T("سرور SMTP", "SMTP server"), smtpHost); Row(Lang.T("پورت", "Port"), smtpPort);
            Check(smtpSsl, "TLS / STARTTLS", original.SmtpSsl);
            Row(Lang.T("نام کاربری SMTP", "SMTP username"), smtpUser); Row(Lang.T("رمز SMTP / رمز برنامه", "SMTP / app password"), smtpPassword);
            Row(Lang.T("ایمیل فرستنده", "From email"), emailFrom); Row(Lang.T("ایمیل گیرنده", "To email"), emailTo);
            SecretNote(smtpPlain, original.SmtpPasswordEnc);
            EnableFields(emailEnabled, smtpHost, smtpPort, smtpSsl, smtpUser, smtpPassword, emailFrom, emailTo);

            var detailsButton=new Button{Text=Lang.T("⌄  جزئیات زمان‌بندی","Scheduling details  ⌄"),FlatStyle=FlatStyle.Flat,Font=Theme.Small,ForeColor=Theme.Text,Height=Theme.S(32),Margin=Theme.Pad(0,8,0,0),Dock=DockStyle.Top,TextAlign=Lang.En?ContentAlignment.MiddleLeft:ContentAlignment.MiddleRight,RightToLeft=Lang.En?RightToLeft.No:RightToLeft.Yes};
            detailsButton.FlatAppearance.BorderSize=0;AddContent(content,detailsButton);
            body=NewBody();body.Visible=false;AddContent(content,body);var explanation=body;
            Full(Lang.T("این کامپیوتر باید روشن و بیدار باشد و MetaFactory در ساعت تعیین‌شده باز بماند. ساعت برنامه‌ریزی، ساعت محلی همین کامپیوتر است؛ روز معاملات با ساعت سرور بروکر محاسبه می‌شود.",
                "Keep this PC awake and MetaFactory running at the scheduled time. The schedule uses this PC's local clock; the trading day uses each broker's server clock."), Theme.Small, Theme.Muted);
            Full(Lang.T("گزارش همهٔ حساب‌های محدودهٔ انتخابی تهیه و به تمام کانال‌های تیک‌خورده ارسال می‌شود. با فعال‌کردن برنامهٔ روزانه، ارسال خودکار به مقصدهای زیر فعال می‌شود. ذخیرهٔ تنظیمات، گزارش را همین حالا ارسال نمی‌کند.",
                "All accounts in the selected platform scope are reported and sent to every checked channel. Enabling the daily schedule enables automatic delivery to the destinations below. Saving does not send a report now."), Theme.Small, Theme.Muted);
            Full(Lang.T("اگر ساعت گذشته باشد، پس از بازشدن برنامه یا پایان گزارش قبلی، گزارش همین روز یک‌بار اجرا می‌شود؛ روزهای گذشته جبران نمی‌شوند. فعال‌کردن برنامه پس از ساعت تعیین‌شده نیز آن را در بررسی بعدی زمان‌بندی اجرا می‌کند.",
                "If today's time has passed, the report runs once when the app opens or the previous report finishes; earlier days are skipped. Enabling an overdue schedule also starts it at the next schedule check."), Theme.Small, Theme.Muted);
            Full(Lang.T("توکن‌ها و رمزها رمزگذاری‌شده روی همین کامپیوتر ذخیره می‌شوند. مقدار ذخیره‌شده‌ای که ویرایش نکنید حفظ می‌شود.",
                "Tokens and passwords are stored encrypted on this PC. Stored values you do not edit are preserved."), Theme.Small, Theme.Muted);
            detailsButton.Click+=(sender,e)=>{explanation.Visible=!explanation.Visible;FitLabels();};
            var footer = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = Theme.S(62), Padding = Theme.Pad(16, 12),
                FlowDirection = FlowDirection.LeftToRight,RightToLeft=RightToLeft.No, WrapContents = false, BackColor = Theme.Surface };
            saveButton.Text = Lang.T("ذخیرهٔ تغییرات", "Save changes"); cancelButton.Text = Lang.T("انصراف", "Cancel");
            foreach (Button button in new[] { saveButton, cancelButton })
            {
                button.Size = new Size(Theme.S(140), Theme.S(36)); button.Font = Theme.Bold;
                button.FlatStyle = FlatStyle.Flat; button.FlatAppearance.BorderColor = Theme.BorderStrong;
                button.Margin = Theme.Pad(5, 0); button.BackColor = Theme.Surface; button.ForeColor = Theme.Text;
            }
            saveButton.BackColor = Theme.Accent; saveButton.ForeColor = Theme.OnAccent;
            saveButton.Click += SaveClicked; cancelButton.DialogResult = DialogResult.Cancel;
            footer.Controls.Add(saveButton); footer.Controls.Add(cancelButton); Controls.Add(footer);
            AcceptButton = saveButton; CancelButton = cancelButton;
            Theme.Window(this);Controls.Add(Theme.GraphiteHeader(Text));
            scroll.Resize += (sender,e)=>FitLabels();
            botStatusTimer.Tick+=(sender,e)=>RefreshBotStatus();
            botAutoTimer.Tick+=(sender,e)=>FlushBotConnections();
            scroll.Disposed+=(sender,e)=>{botAutoTimer.Stop();botAutoTimer.Dispose();botStatusTimer.Stop();botStatusTimer.Dispose();foreach(var page in channelPages.Values)if(!page.IsDisposed)page.Dispose();hints.Dispose();};
            foreach(var page in channelPages.Values)Theme.StyleInputs(page);
            Theme.StyleInputs(content);
            SelectChannel("telegram");FitLabels();initialUiState=UiState();
        }

        TableLayoutPanel NewBody()
        {
            var panel=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=2,GrowStyle=TableLayoutPanelGrowStyle.AddRows,BackColor=Theme.Surface,Padding=Theme.Pad(0,2),Margin=Padding.Empty,RightToLeft=RightToLeft.No};
            if(Lang.En){panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(145)));panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));}
            else{panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(145)));}
            return panel;
        }
        TableLayoutPanel NewChannelPage(string name){var page=NewBody();channelPages[name]=page;return page;}
        static void AddContent(TableLayoutPanel host,Control control)
        {int row=host.RowCount++;host.RowStyles.Add(new RowStyle(SizeType.AutoSize));control.Anchor=AnchorStyles.Left|AnchorStyles.Right;host.Controls.Add(control,0,row);}
        void AddChannelTab(TableLayoutPanel host,int column,string name,string title,CheckBox enabled,bool value)
        {
            enabled.Checked=value;enabled.Size=new Size(Theme.S(42),Theme.S(24));enabled.AccessibleName=(name=="email"?Lang.T("ارسال به ","Send to "):Lang.T("ربات پاسخ‌گو: ","Bot replies: "))+title;
            var tab=new DeliveryChannelTab(name,title,enabled){Dock=DockStyle.Fill,Margin=Padding.Empty};tab.SelectRequested+=()=>SelectChannel(name);channelTabs[name]=tab;host.Controls.Add(tab,column,0);
        }
        void SelectChannel(string name)
        {
            if(selectedChannel==name)return;
            channelDetails.SuspendLayout();channelDetails.Controls.Clear();channelDetails.Controls.Add(channelPages[name]);selectedChannel=name;
            foreach(var tab in channelTabs)tab.Value.Selected=tab.Key==name;
            channelDetails.ResumeLayout(true);FitLabels();
        }
        void BotChannelControls(string channel,CheckBox send,bool selected,TextBox chat)
        {
            send.Checked=selected;send.Text=Lang.T("ارسال خودکار به مقصد مشخص","Scheduled delivery to a fixed destination");send.AutoSize=true;
            Check(send,send.Text,selected);
            var chatHost=new Panel{Height=Theme.S(38)};chatHost.Controls.Add(chat);
            Row(Lang.T("مقصد ارسال خودکار","Scheduled destination"),chatHost);
            var host=body;var chatLabel=host.Controls.OfType<Label>().Single(item=>host.GetRow(item)==host.GetRow(chatHost));
            Action update=()=>{chatHost.Visible=send.Checked;chatLabel.Visible=send.Checked;host.PerformLayout();FitLabels();};send.CheckedChanged+=(sender,e)=>update();update();
            var label=new Label{Text=Lang.T("ربات هنوز متصل نشده است.","Bot is not connected yet."),AutoSize=true,ForeColor=Theme.Muted,Font=Theme.Small};botStatusLabels[channel]=label;Full(label);
        }
        Control TokenField(TextBox field,Button paste)
        {
            var row=new TableLayoutPanel{Dock=DockStyle.Fill,Height=Theme.S(40),ColumnCount=3,Margin=Padding.Empty,Padding=Padding.Empty,RightToLeft=RightToLeft.No};
            if(Lang.En){row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(10)));row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(125)));row.Controls.Add(field,0,0);row.Controls.Add(paste,2,0);}
            else{row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(125)));row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(10)));row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));row.Controls.Add(paste,0,0);row.Controls.Add(field,2,0);}
            field.Dock=DockStyle.Fill;field.Margin=Theme.Pad(0,3,0,3);paste.Dock=DockStyle.Fill;paste.Margin=Padding.Empty;paste.Text=Lang.T("چسباندن توکن","Paste token");paste.Font=Theme.Small;paste.FlatStyle=FlatStyle.Flat;paste.FlatAppearance.BorderColor=Theme.BorderStrong;paste.BackColor=Theme.Surface;paste.ForeColor=Theme.Text;
            paste.Click+=(sender,e)=>{try{if(Clipboard.ContainsText()){field.Text=Clipboard.GetText().Trim();QueueBotEdit(field==baleToken?"Bale":"Telegram",true);}}catch{ShowError(Lang.T("دسترسی به کلیپ‌بورد ممکن نشد؛ توکن را در کادر وارد کنید.","Clipboard is unavailable; enter the token in the field."));}};
            return row;
        }

        protected override void OnShown(EventArgs e)
        {
            Rectangle area = Screen.FromControl(this).WorkingArea;
            int width = Math.Max(1, area.Width - 20), height = Math.Max(1, area.Height - 20);
            MinimumSize = new Size(Math.Min(MinimumSize.Width, width), Math.Min(MinimumSize.Height, height));
            Size = new Size(Math.Min(Width, width), Math.Min(Height, height));
            Location = new Point(Math.Max(area.Left, Math.Min(Left, area.Right - Width)), Math.Max(area.Top, Math.Min(Top, area.Bottom - Height)));
            base.OnShown(e);
        }

        void Section(string text) { Full(text, Theme.Bold, Theme.Text); }
        void Full(string text, Font font, Color color)
        { Full(new Label { Text = text, Font = font, ForeColor = color, AutoSize = true }); }
        void Full(Label label)
        {
            label.Margin = Theme.Pad(0, 3, 0, 5); label.Anchor = AnchorStyles.Left | AnchorStyles.Right;label.RightToLeft=Lang.En?RightToLeft.No:RightToLeft.Yes;label.TextAlign=Lang.En?ContentAlignment.MiddleLeft:ContentAlignment.MiddleRight;
            int row = body.RowCount++; body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            body.Controls.Add(label, 0, row); body.SetColumnSpan(label, 2); fullLabels.Add(label);
        }
        void Check(CheckBox control, string text, bool value)
        {
            control.Text = text; control.Checked = value; control.AutoSize = true; control.Margin = Theme.Pad(0, 3, 0, 3);control.RightToLeft=Lang.En?RightToLeft.No:RightToLeft.Yes;control.Anchor=Lang.En?AnchorStyles.Left:AnchorStyles.Right;
            int row = body.RowCount++; body.RowStyles.Add(new RowStyle(SizeType.AutoSize)); body.Controls.Add(control, 0, row); body.SetColumnSpan(control, 2);
        }
        void Row(string title, Control control)
        {
            int row = body.RowCount++; body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var label = new Label { Text = title, AutoSize = true, Anchor = AnchorStyles.Left | AnchorStyles.Right, Margin = Theme.Pad(0, 7, 10, 7),RightToLeft=Lang.En?RightToLeft.No:RightToLeft.Yes,TextAlign=Lang.En?ContentAlignment.MiddleLeft:ContentAlignment.MiddleRight };
            control.Dock = DockStyle.Fill; control.Margin = Theme.Pad(0, 3, 0, 3); control.RightToLeft = RightToLeft.No;
            body.Controls.Add(label, Lang.En?0:1, row); body.Controls.Add(control, Lang.En?1:0, row);
        }
        void FitLabels()
        {
            int width = Math.Max(Theme.S(240), scroll.ClientSize.Width - scroll.Padding.Horizontal - SystemInformation.VerticalScrollBarWidth - Theme.S(12));
            foreach (Label label in fullLabels) label.MaximumSize = new Size(width, 0);
        }
        void SecretNote(string plain, string encrypted)
        {
            if (plain == null && !string.IsNullOrEmpty(encrypted))
                Full(Lang.T("رمز ذخیره‌شده با این کاربر ویندوز باز نمی‌شود؛ برای فعال‌کردن این کانال، مقدار جدید وارد کنید.",
                    "The stored secret cannot be opened by this Windows user; enter a replacement to enable this channel."), Theme.Small, Theme.Warn);
        }
        static void BotEditing(params Control[] fields){foreach(var field in fields)field.Enabled=true;}
        static void EnableFields(CheckBox enabled, params Control[] fields)
        {
            Action sync = () => { foreach (Control field in fields) field.Enabled = enabled.Checked; };
            enabled.CheckedChanged += (s, e) => sync(); sync();
        }
        static string ProtectedValue(TextBox field, string plain, string encrypted)
        { return field.Text == (plain ?? "") ? encrypted ?? "" : Secret.Protect(field.Text); }

        void ShowError(string message)
        {error.Text=message;error.Visible=true;scroll.ScrollControlIntoView(error);}

        /// <summary>Collect and validate only. The caller owns persistence and delivery; this method never sends.</summary>
        public bool TryCollect(out ScheduleOptions candidate)
        {
            candidate=null;
            try
            {
                var value = Copy(original);
                value.BotSettingsUnified=true;value.BotSettingsMigrationPending=false;value.TelegramBotEnabled=telegramBotEnabled.Checked;value.BaleBotEnabled=baleBotEnabled.Checked;
                value.Enabled = dailyEnabled.Checked; value.Time = TextUtil.LatinDigits(time.Text.Trim());
                value.Platform = platform.SelectedIndex == 1 ? "MT4" : platform.SelectedIndex == 2 ? "MT5" : "All";
                value.BaleEnabled = baleEnabled.Checked; value.BaleChatId = baleChat.Text.Trim(); value.BaleTokenEnc = ProtectedValue(baleToken, balePlain, original.BaleTokenEnc);
                value.TelegramEnabled = telegramEnabled.Checked; value.TelegramChatId = telegramChat.Text.Trim(); value.TelegramTokenEnc = ProtectedValue(telegramToken, telegramPlain, original.TelegramTokenEnc);
                value.EmailEnabled = emailEnabled.Checked; value.SmtpHost = smtpHost.Text.Trim(); value.SmtpPort = (int)smtpPort.Value; value.SmtpSsl = smtpSsl.Checked;
                value.SmtpUser = smtpUser.Text.Trim(); value.SmtpPasswordEnc = ProtectedValue(smtpPassword, smtpPlain, original.SmtpPasswordEnc);
                value.EmailFrom = emailFrom.Text.Trim(); value.EmailTo = emailTo.Text.Trim();
                // Disabling must remain possible even if a previously saved destination is no longer usable.
                string invalid = value.Enabled ? ScheduledDelivery.Validate(value) : ScheduledDelivery.StructureProblem(value);
                if(invalid!=null){ShowError(invalid);return false;}
                candidate=value;error.Visible=false;return true;
            }
            catch
            {
                ShowError(Lang.T("تنظیمات ذخیره نشد؛ رمزگذاری اطلاعات روی این کاربر ویندوز را بررسی کنید.", "Settings could not be saved; check credential encryption for this Windows user."));
                return false;
            }
        }
        void SaveClicked(object sender, EventArgs e)
        {
            ScheduleOptions candidate;if(!TryCollect(out candidate))return;
            Options=candidate;DialogResult=DialogResult.OK;Close();
        }

    }
    internal sealed class DeliveryChannelTab : Panel
    {
        readonly string channel,title;readonly CheckBox enabled;bool selected;
        public event Action SelectRequested;
        public bool Selected{get{return selected;}set{selected=value;Invalidate();}}
        public DeliveryChannelTab(string channel,string title,CheckBox enabled)
        {this.channel=channel;this.title=title;this.enabled=enabled;DoubleBuffered=true;BackColor=Theme.Surface;Cursor=Cursors.Hand;TabStop=true;AccessibleName=title;Controls.Add(enabled);enabled.CheckedChanged+=(sender,e)=>Invalidate();Resize+=(sender,e)=>PlaceToggle();PlaceToggle();}
        void PlaceToggle(){enabled.Location=new Point(Lang.En?Math.Max(Theme.S(8),Width-Theme.S(50)):Theme.S(8),Theme.S(17));}
        protected override void OnClick(EventArgs e){base.OnClick(e);if(SelectRequested!=null)SelectRequested();Focus();}
        protected override bool IsInputKey(Keys keyData){Keys key=keyData&Keys.KeyCode;return key==Keys.Space||key==Keys.Enter||base.IsInputKey(keyData);}
        protected override void OnKeyDown(KeyEventArgs e){base.OnKeyDown(e);if(e.KeyCode==Keys.Space||e.KeyCode==Keys.Enter){if(SelectRequested!=null)SelectRequested();e.Handled=true;e.SuppressKeyPress=true;}}
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using(var pen=new Pen(Theme.Border,1))g.DrawLine(pen,0,Height-1,Width,Height-1);
            if(selected)using(var blue=new Pen(Theme.Accent,Theme.S(3)))g.DrawLine(blue,Theme.S(6),Height-Theme.S(2),Width-Theme.S(6),Height-Theme.S(2));
            int icon=Theme.S(28),x=Lang.En?Theme.S(12):Width-Theme.S(40);DeliveryChannelIcons.Paint(g,channel,new Rectangle(x,Theme.S(14),icon,icon));
            int left=Lang.En?Theme.S(47):Theme.S(53),right=Lang.En?Theme.S(53):Theme.S(47);
            var flags=TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis|TextFormatFlags.VerticalCenter|(Lang.En?TextFormatFlags.Left:TextFormatFlags.Right|TextFormatFlags.RightToLeft);
            TextRenderer.DrawText(g,title,Theme.Font,new Rectangle(left,Theme.S(10),Math.Max(5,Width-left-right),Theme.S(37)),Theme.Text,flags);
            if(Focused)ControlPaint.DrawFocusRectangle(g,new Rectangle(3,3,Width-6,Height-6));
        }
    }
    internal sealed class DeliveryToggle : CheckBox
    {
        public DeliveryToggle(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);AutoSize=false;Cursor=Cursors.Hand;}
        protected override void OnCheckedChanged(EventArgs e){base.OnCheckedChanged(e);Invalidate();}
        protected override void OnPaint(PaintEventArgs e)
        {
            var g=e.Graphics;g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;g.Clear(Parent==null?Theme.Surface:Parent.BackColor);
            int size=Theme.S(20),x=(Width-size)/2,y=(Height-size)/2;var box=new Rectangle(x,y,size,size);
            Theme.Box(g,box,Theme.Sf(4),Checked?Theme.Accent:Theme.Surface,Checked?Theme.Accent:Theme.BorderStrong);
            if(Checked)Glyphs.Draw(g,Glyph.Check,new RectangleF(x+Theme.S(3),y+Theme.S(3),size-Theme.S(6),size-Theme.S(6)),Color.White);
            if(Focused)ControlPaint.DrawFocusRectangle(g,ClientRectangle);
        }
    }
    internal static class DeliveryChannelIcons
    {
        public static void Paint(Graphics g,string channel,Rectangle rect)
        {
            var state=g.Save();g.TranslateTransform(rect.X,rect.Y);g.ScaleTransform(rect.Width/32f,rect.Height/32f);
            Color color=channel=="bale"?Color.FromArgb(31,171,88):Color.FromArgb(0,151,225);
            using(var brush=new SolidBrush(color))using(var white=new SolidBrush(Color.White))using(var pen=new Pen(color,2))
            {
                if(channel=="email"){g.DrawRectangle(pen,2,6,28,20);g.DrawLines(pen,new[]{new Point(3,7),new Point(16,17),new Point(29,7)});}
                else if(channel=="telegram"){g.FillEllipse(brush,0,0,32,32);g.FillPolygon(white,new[]{new PointF(6,14),new PointF(26,6),new PointF(22,26),new PointF(15,20),new PointF(11,24),new PointF(12,17)});using(var line=new Pen(color,1.4f))g.DrawLine(line,12,18,23,9);}
                else{g.FillEllipse(brush,1,0,30,28);g.FillPolygon(brush,new[]{new Point(6,23),new Point(4,32),new Point(16,26)});using(var check=new Pen(Color.White,3.2f)){check.StartCap=System.Drawing.Drawing2D.LineCap.Round;check.EndCap=System.Drawing.Drawing2D.LineCap.Round;g.DrawLines(check,new[]{new Point(9,13),new Point(14,18),new Point(23,9)});}}
            }
            g.Restore(state);
        }
    }

}
