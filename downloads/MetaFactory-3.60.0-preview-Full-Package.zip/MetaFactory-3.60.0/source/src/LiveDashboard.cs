using System;
using System.Collections.Generic;
using System.Linq;
namespace MTManager
{
    // Immutable-by-contract projection for one accepted heartbeat. Never a manual-run success receipt.
    internal sealed class LiveDashboardData
    {
        internal LiveMonitorTarget Target;
        internal LiveFeedSnapshot Feed;
        internal AccountJournal Journal;
        internal PanelView Today;
        internal string HistoryKey;
        internal DateTime ReceivedUtc { get { return Feed.HeartbeatUtc; } }
        internal bool Matches(Instance copy, Account account, DateTime utc)
        { return Target != null && Target.Matches(copy, account) && utc >= ReceivedUtc.AddSeconds(-5) && utc <= ReceivedUtc.AddSeconds(LiveFeedReader.StaleSeconds); }
    }
    internal sealed class LiveDashboardProjectionCache
    {
        AccountJournal history;
        string run, positionKey="";
        long revision;
        DateTime day;
        PanelView today;
        internal int Builds { get; private set; }
        internal LiveDashboardData Update(LiveMonitorTarget target, LiveFeedSnapshot feed, LiveReportSummary metrics)
        {
            if(feed == null || feed.Status!=LiveFeedStatus.Live || feed.History == null || metrics == null || !metrics.HistoryReady || !metrics.TodayKnown || !feed.History.GmtOffset.HasValue) return null;
            DateTime serverNow=DateTime.SpecifyKind(feed.HeartbeatUtc.AddSeconds(feed.History.GmtOffset.Value),DateTimeKind.Unspecified);
            var positions=feed.Positions.Select(p=>new JournalOpen {Ticket=p.Ticket,Symbol=p.Symbol,Buy=p.Buy,Volume=p.Volume,Open=p.Open,
                OpenPrice=p.OpenPrice,Sl=p.Sl,Tp=p.Tp,Profit=p.Profit,Swap=p.Swap,SlEntry=p.SlEntry,Price=p.Price,
                Commission=feed.Platform=="MT5" ? 0 : p.Commission}).ToList();
            var current=feed.History.WithCurrent(feed.Balance,feed.Equity,feed.Margin,feed.FreeMargin,feed.Credit,serverNow,positions);
            string positionsKey=string.Join("|",positions.Select(p=>p.Ticket+":"+p.Symbol+":"+p.Open.Ticks+":"+p.Volume.ToString("R",System.Globalization.CultureInfo.InvariantCulture)+":"+p.OpenPrice.ToString("R",System.Globalization.CultureInfo.InvariantCulture)+":"+p.Sl.ToString("R",System.Globalization.CultureInfo.InvariantCulture)+":"+p.Tp.ToString("R",System.Globalization.CultureInfo.InvariantCulture)+":"+p.Commission.ToString("R",System.Globalization.CultureInfo.InvariantCulture)));
            if(positionKey!=positionsKey || !object.ReferenceEquals(history,feed.History) || run!=feed.RunId || revision!=feed.HistoryRevision || day!=serverNow.Date)
            {
                positionKey=positionsKey;history=feed.History;run=feed.RunId;revision=feed.HistoryRevision;day=serverNow.Date;
                today=LiveDashboardMath.Build(current,ServerDays.Range(PanelRange.Today,day));Builds++;
            }
            if(today==null)return null;
            return new LiveDashboardData {Target=target.Snapshot(),Feed=feed,Journal=current,Today=today.WithCurrent(current),
                HistoryKey=feed.RunId+":"+feed.HistoryRevision+":"+day.Ticks+":"+positionsKey};
        }
    }
    internal static class LiveDashboardMath
    {
        internal static PanelView Build(AccountJournal journal, ReportRange range)
        {
            if(journal==null || journal.Exported<range.From)return null;
            var panel=PanelMath.Build(journal,range,new TradeLimits());
            if(journal.Platform!="MT5")return panel;
            // Live MT5 totals follow the actual realization day, including partial closes and today's entry costs.
            double net;int exits;
            if(journal.From>range.From || !Realized(journal,range.From,range.To,out net,out exits))return null;
            panel.ClosedNet=net;panel.Closed=exits;
            double balance=journal.FullHistory.Where(e=>e.Time<range.From).Sum(e=>e.Net);
            panel.StartBalance=balance;panel.ReturnPct=balance>0?net/balance*100:double.NaN;
            panel.HistoryNote=Lang.T("زنده: جمع سود بر پایهٔ بخش‌های بسته‌شده و هزینه‌های ثبت‌شده در این بازه است؛ ردیف‌های معاملات MT5 بر اساس پوزیشن تجمیع می‌شوند.",
                "Live: realized totals use exits and costs booked in this range; MT5 trade rows aggregate by position.");
            foreach(var d in panel.Days)
            {
                double dayNet;int dayExits;
                if(d.Day>=range.From && d.Day<range.To && Realized(journal,d.Day,d.Day.AddDays(1),out dayNet,out dayExits))
                    d.Net=dayNet+(panel.ReachesNow?panel.Trades.Where(p=>!p.Closed && p.Day==d.Day).Sum(p=>p.Net):0);
            }
            return panel;
        }
        internal static bool Realized(AccountJournal journal, DateTime from, DateTime to, out double net, out int exits)
        {
            net=0;exits=0;
            if(!journal.FullHistoryValid)return false;
            var deals=new Dictionary<long,JournalDeal>();
            foreach(var d in journal.Deals.Where(d=>d.Time>=from && d.Time<to && Trading(d.Type)))
            {if(deals.ContainsKey(d.Ticket))return false;deals.Add(d.Ticket,d);}
            int matched=0;
            foreach(var e in journal.FullHistory.Where(e=>e.Time>=from && e.Time<to && Trading(e.Type)))
            {
                JournalDeal d;
                if(!deals.TryGetValue(e.Ticket,out d) || d.Type!=e.Type || Math.Abs((d.Time-e.Time).TotalSeconds)>=1 ||
                    double.IsNaN(d.Profit+d.Commission+d.Swap+d.Fee) || double.IsInfinity(d.Profit+d.Commission+d.Swap+d.Fee) ||
                    Math.Abs(e.Net-(d.Profit+d.Commission+d.Swap+d.Fee))>0.000001)return false;
                net+=e.Net;matched++;
                if((d.Type==0 || d.Type==1) && (d.Entry==1 || d.Entry==2 || d.Entry==3))exits++;
            }
            return matched==deals.Count && !double.IsNaN(net) && !double.IsInfinity(net);
        }
        static bool Trading(int type) { return type!=2 && type!=3 && type!=5 && type!=6; }
    }
}
