using System;
using System.Collections.Generic;

namespace MTManager
{
    /// <summary>Separate live presentation. Position P/L is not added to account equity or balance.</summary>
    public sealed class LiveReportSummary
    {
        public bool IsLive, HistoryReady, TodayKnown, PositionNetKnown;
        public DateTime ServerDay;
        public int TodayClosedCount, PositionCount, NoSlCount;
        public double TodayClosedNet = double.NaN, FloatingProfitSwap = double.NaN, PositionNet = double.NaN, AccountDdPct = double.NaN;
        public string Currency = "", TodayReason = "", TodayCountLabel = "", AccountDdBasis = "";
    }

    /// <summary>Owned by one background feed worker. Full-curve DD is calculated only when the immutable baseline changes.</summary>
    public sealed class LiveReportSummaryCache
    {
        AccountJournal history;
        string run;
        long revision;
        DateTime day = DateTime.MinValue;
        double dd = double.NaN, closedNet = double.NaN;
        string ddBasis = "";
        int closedCount;
        bool todayKnown;
        string todayReason = "";
        public int HistoryCalculations { get; private set; }

        public LiveReportSummary Update(LiveFeedSnapshot feed, DateTime utcNow)
        {
            var result = new LiveReportSummary();
            if (feed == null || !feed.IsLive) return result;
            result.IsLive = true; result.Currency = feed.Currency;
            bool mt5 = string.Equals(feed.Platform, "MT5", StringComparison.OrdinalIgnoreCase);
            result.TodayCountLabel = mt5 ? Lang.T("معاملهٔ خروج", "closing deals") : Lang.T("سفارش بسته", "closed orders");
            result.PositionCount = feed.Positions.Count;
            result.FloatingProfitSwap = 0;
            double net = 0;
            foreach (LivePosition position in feed.Positions)
            {
                result.FloatingProfitSwap += position.Profit + position.Swap;
                net += position.Net;
                // This is the stop currently protecting the position, not its original entry stop.
                if (position.Sl <= 0) result.NoSlCount++;
            }
            if (!Finite(result.FloatingProfitSwap)) result.FloatingProfitSwap = double.NaN;
            AccountJournal current = feed.History;
            result.HistoryReady = current != null && current.Complete && current.FullHistoryValid;
            result.PositionNetKnown = result.HistoryReady && Finite(net);
            if (result.PositionNetKnown) result.PositionNet = net;
            if (!result.HistoryReady)
            {
                result.TodayReason = Lang.T("تاریخچهٔ مطابق دادهٔ زنده هنوز آماده نیست.", "History matching the current live snapshot is not ready.");
                return result;
            }
            bool changed = !object.ReferenceEquals(history, current) || run != feed.RunId || revision != feed.HistoryRevision;
            if (changed)
            {
                history = current; run = feed.RunId; revision = feed.HistoryRevision;
                var view = new PanelView(); PanelMath.AccountDrawdown(current, view);
                dd = view.AccountDdPct; ddBasis = view.AccountDdBasis; HistoryCalculations++;
                day = DateTime.MinValue;
            }
            result.AccountDdPct = dd; result.AccountDdBasis = ddBasis;
            if (!current.GmtOffset.HasValue)
            {
                result.TodayReason = Lang.T("ساعت سرور مشخص نیست؛ نتیجهٔ امروز نامشخص است.", "Broker clock offset is unknown; today's result is unavailable.");
                return result;
            }
            DateTime serverDay = ServerDays.Now(current, utcNow).Date;
            if (day != serverDay)
            {
                day = serverDay; closedCount = 0; closedNet = double.NaN; todayKnown = false;
                todayReason = Lang.T("تاریخچه هنوز روز جاری سرور را پوشش نمی‌دهد.", "History does not yet cover the current broker day.");
                // A previous-day baseline cannot imply zero trades after midnight, even if balance is unchanged.
                if (current.From <= day && current.Exported.Date == day)
                {
                    double total = 0; DateTime end = day.AddDays(1);
                    bool valid = true;
                    if (mt5)
                    {
                        // Full-curve J proves every realized balance movement; D provides exit/reversal classification.
                        // Matching both prevents a partial deal display window from silently producing a zero daily result.
                        var deals = new Dictionary<long, JournalDeal>();
                        foreach (JournalDeal deal in current.Deals)
                            if (deal.Time >= day && deal.Time < end && TradingMovement(deal.Type))
                            { if (deals.ContainsKey(deal.Ticket)) valid = false; else deals.Add(deal.Ticket, deal); }
                        int matched = 0;
                        foreach (JournalBalanceEvent item in current.FullHistory)
                        {
                            if (item.Time < day || item.Time >= end || !TradingMovement(item.Type)) continue;
                            JournalDeal deal;
                            if (!deals.TryGetValue(item.Ticket, out deal) || deal.Type != item.Type
                                || Math.Abs((item.Time - deal.Time).TotalSeconds) >= 1
                                || !Finite(deal.Profit + deal.Commission + deal.Swap + deal.Fee)
                                || Math.Abs(item.Net - (deal.Profit + deal.Commission + deal.Swap + deal.Fee)) > 0.000001)
                            { valid = false; continue; }
                            matched++; total += item.Net;
                            if ((deal.Type == 0 || deal.Type == 1) && (deal.Entry == 1 || deal.Entry == 2 || deal.Entry == 3)) closedCount++;
                        }
                        valid = valid && matched == deals.Count;
                    }
                    else
                    {
                        foreach (JournalTrade trade in current.Trades)
                            if (trade.Close >= day && trade.Close < end) { closedCount++; total += trade.Net; }
                    }
                    if (valid && Finite(total))
                    {
                        closedNet = total; todayKnown = true;
                        todayReason = mt5 ? Lang.T("سود/زیان تحقق‌یافتهٔ روز سرور بر پایهٔ هر دیل؛ شامل خروج جزئی، خروج معکوس و کارمزد ورود ثبت‌شده در همین روز. تعداد، دیل‌های خروج است؛ واریز/برداشت و اعتبار حذف شده‌اند.",
                            "Realized trading result by broker-day deal timestamp, including partial closes, reversals and entry fees booked today. Count is closing deals; external cash and credit excluded.")
                            : Lang.T("نتیجهٔ سفارش‌های بسته‌شده در روز سرور، با کارمزد و سواپ؛ واریز/برداشت و اعتبار حذف شده‌اند.",
                                "Result of orders closed on the broker day including commission and swap; external cash and credit excluded.");
                    }
                    else todayReason = Lang.T("جزئیات دیل‌های امروز هنوز با تاریخچهٔ کامل تطبیق ندارد.", "Today's deal details do not yet match the complete history proof.");
                }
            }
            result.ServerDay = day; result.TodayKnown = todayKnown; result.TodayClosedCount = closedCount;
            result.TodayClosedNet = closedNet; result.TodayReason = todayReason;
            return result;
        }
        static bool TradingMovement(int type) { return type != 2 && type != 3 && type != 5 && type != 6; }
        static bool Finite(double value) { return !double.IsNaN(value) && !double.IsInfinity(value); }
    }
}
