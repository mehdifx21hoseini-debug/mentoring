using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace MTManager
{
    public sealed class LiveMonitorTarget
    {
        public string CopyName { get; set; }
        public string Directory { get; set; }
        public string Name { get; set; }
        public string Login { get; set; }
        public string Server { get; set; }
        public string Platform { get; set; }
        public string Token { get; set; }
        public string Guide { get; set; }
        public LiveMonitorTarget Snapshot() { return (LiveMonitorTarget)MemberwiseClone(); }
        public bool Matches(Instance copy, Account account)
        {
            return copy != null && account != null && string.Equals(CopyName, copy.Name, StringComparison.OrdinalIgnoreCase)
                && string.Equals(Directory, copy.Dir, StringComparison.OrdinalIgnoreCase) && Platform == copy.Kind.ToString()
                && Login == (account.Login ?? "").Trim() && string.Equals(Server, (account.Server ?? "").Trim(), StringComparison.OrdinalIgnoreCase);
        }
        public static LiveMonitorTarget Create(Instance copy, Account account)
        {
            return new LiveMonitorTarget { CopyName = copy.Name, Directory = copy.Dir, Name = account.Trader, Login = (account.Login ?? "").Trim(),
                Server = (account.Server ?? "").Trim(), Platform = copy.Kind.ToString(), Token = Guid.NewGuid().ToString("N") };
        }
        internal bool Valid
        {
            get { return !string.IsNullOrWhiteSpace(CopyName) && !string.IsNullOrWhiteSpace(Directory) && !string.IsNullOrWhiteSpace(Login)
                && !string.IsNullOrWhiteSpace(Server) && (Platform == "MT4" || Platform == "MT5") && Token != null && Token.Length == 32
                && Token.All(c => c >= '0' && c <= '9' || c >= 'a' && c <= 'f'); }
        }
        public string SnapshotPath { get { return Path.Combine(Directory, Platform == "MT4" ? "MQL4" : "MQL5", "Files", "MetaFactoryLive", Token, "snapshot.txt"); } }
    }

    public static class LiveMonitorStore
    {
        public static string FilePath { get { return Path.Combine(AppPaths.DataDir, "live-monitor.json"); } }
        const int Limit = 1024 * 1024;
        public static List<LiveMonitorTarget> Load(out string problem)
        {
            problem = null;
            try
            {
                if (!File.Exists(FilePath)) return new List<LiveMonitorTarget>();
                if (new FileInfo(FilePath).Length > Limit) throw new InvalidDataException();
                var values = new JavaScriptSerializer { MaxJsonLength = Limit, RecursionLimit = 6 }.Deserialize<List<LiveMonitorTarget>>(File.ReadAllText(FilePath));
                if (values == null || values.Count > 2000 || values.Any(v => v == null || !v.Valid)
                    || values.Select(v => v.CopyName).Distinct(StringComparer.OrdinalIgnoreCase).Count() != values.Count) throw new InvalidDataException();
                return values;
            }
            catch { problem = Lang.T("تنظیمات پایش زنده خوانده نشد؛ دوباره آماده‌سازی کنید.", "Live settings could not be read; prepare the reporters again."); return new List<LiveMonitorTarget>(); }
        }
        public static void Save(IEnumerable<LiveMonitorTarget> targets)
        {
            var values = targets.Select(t => t.Snapshot()).ToList();
            if (values.Count > 2000 || values.Any(v => !v.Valid) || values.Select(v => v.CopyName).Distinct(StringComparer.OrdinalIgnoreCase).Count() != values.Count)
                throw new InvalidDataException("Invalid live monitoring targets.");
            string json = new JavaScriptSerializer { MaxJsonLength = Limit }.Serialize(values);
            if (System.Text.Encoding.UTF8.GetByteCount(json) > Limit) throw new InvalidDataException("Live monitoring settings are too large.");
            TextUtil.WriteLinesAtomically(FilePath, new[] { json });
        }
    }

    internal sealed class LiveMonitorCandidate
    {
        public Instance Copy;
        public Account Account;
    }
    internal sealed class LiveMonitorView
    {
        public string CopyName, Name, Login, Platform, State, Balance, Equity, Positions, Updated, History, Detail, Floating, NoSl, Today, Drawdown;
        public DateTime LiveUntilUtc;
        internal LiveMonitorTarget Target;
        internal LiveFeedSnapshot Feed;
        internal LiveDashboardData Dashboard;
        internal LiveMonitorView VisibleAt(DateTime utcNow)
        {
            if (LiveUntilUtc == DateTime.MinValue || utcNow <= LiveUntilUtc) return this;
            var value = (LiveMonitorView)MemberwiseClone();
            value.Feed=null;value.Dashboard=null;
            value.State = Lang.T("دادهٔ زنده نرسیده", "Stale heartbeat");
            value.Balance = value.Equity = value.Positions = value.History = value.Floating = value.NoSl = value.Today = value.Drawdown = "—";
            value.Detail = Lang.T("دادهٔ تازه در مهلت مقرر نرسیده؛ مقادیر قبلی زنده نیستند.", "No new heartbeat arrived in time; earlier values are not live.");
            return value;
        }
        public string Signature { get { return string.Join("\u001f", new[] { Name, Login, Platform, State, Balance, Equity, Positions, Updated, History, Detail, Floating, NoSl, Today, Drawdown }); } }
    }

    sealed partial class MainForm
    {
        LiveMonitorDialog liveMonitorDialog;
        void ShowLiveMonitoring()
        {
            if (liveMonitorDialog != null && !liveMonitorDialog.IsDisposed) { liveMonitorDialog.Show(); liveMonitorDialog.Activate(); return; }
            liveMonitorDialog = new LiveMonitorDialog(settings, () => LiveCandidates(copies), () => LiveCandidates(Selected()));
            liveMonitorDialog.FormClosed += (s, e) => liveMonitorDialog = null;
            liveMonitorDialog.Show(this);
        }
        List<LiveMonitorCandidate> LiveCandidates(IEnumerable<Instance> source)
        {
            return source.Where(copy=>!LaunchComparison.IsPlain(copy.Name)).Select(copy => new LiveMonitorCandidate { Copy = new Instance { Name = copy.Name, Kind = copy.Kind, Dir = copy.Dir }, Account = accounts.Get(copy.Name) })
                .Where(c => c.Account != null && c.Account.HasLogin).ToList();
        }
        void ShutdownLiveMonitoring()
        {
            LiveAutoStart.StopSymbolProbe();
            dashboardController.Dispose();
            if (liveMonitorDialog != null && !liveMonitorDialog.IsDisposed) liveMonitorDialog.Close();
            liveMonitorDialog = null;
        }
    }
}

namespace MTManager
{
    /// <summary>Only reads files belonging to explicitly prepared, already-open student copies. No terminal launch or report-cache writes.</summary>
    internal sealed class LiveMonitorController : IDisposable
    {
        readonly object gate = new object();
        readonly Dictionary<string, LiveFeedReader> readers = new Dictionary<string, LiveFeedReader>(StringComparer.OrdinalIgnoreCase);
        readonly Func<HashSet<string>> openPaths;
        readonly Func<LiveMonitorTarget, DateTime, Func<bool>, LiveFeedSnapshot> read;
        List<LiveMonitorView> ready = new List<LiveMonitorView>();
        int polling;
        volatile int generation;
        readonly bool checkProcessGeneration;
        readonly bool projectDashboard;
        readonly Dictionary<string,LiveDashboardProjectionCache> projections=new Dictionary<string,LiveDashboardProjectionCache>(StringComparer.OrdinalIgnoreCase);
        readonly Dictionary<string,string> savedBaselines=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
        readonly Dictionary<string, DateTime> processStarts = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        readonly Dictionary<string, LiveReportSummaryCache> summaries = new Dictionary<string, LiveReportSummaryCache>(StringComparer.OrdinalIgnoreCase);
        volatile bool enabled, disposed;
        internal bool Enabled { get { return enabled; } }
        internal bool Polling { get { return Interlocked.CompareExchange(ref polling, 0, 0) != 0; } }
        internal LiveMonitorController(Func<HashSet<string>> open = null, Func<LiveMonitorTarget, DateTime, Func<bool>, LiveFeedSnapshot> sample = null, bool dashboard = false)
        {
            projectDashboard=dashboard;
            checkProcessGeneration = open == null;
            openPaths = open ?? ReadOpenPaths;
            read = sample ?? Read;
        }
        internal static HashSet<string> OpenPaths()
        {
            var running = Processes.Running();
            try { return new HashSet<string>(running.Keys, StringComparer.OrdinalIgnoreCase); }
            finally { foreach (var process in running.Values) process.Dispose(); }
        }
        HashSet<string> ReadOpenPaths()
        {
            var running = Processes.Running(); processStarts.Clear();
            try
            {
                foreach (var pair in running) try { processStarts[pair.Key] = pair.Value.StartTime.ToUniversalTime(); } catch { }
                return new HashSet<string>(running.Keys, StringComparer.OrdinalIgnoreCase);
            }
            finally { foreach (var process in running.Values) process.Dispose(); }
        }
        LiveFeedSnapshot Read(LiveMonitorTarget target, DateTime utcNow, Func<bool> cancelled)
        {
            string key = target.CopyName + "\n" + target.Token + "\n" + target.Directory;
            LiveFeedReader reader;
            if (!readers.TryGetValue(key, out reader))
            {
                reader = new LiveFeedReader(target.Platform == "MT4" ? Kind.MT4 : Kind.MT5, target.Login, target.Server, target.Token, Path.GetDirectoryName(target.SnapshotPath));
                readers[key] = reader;
            }
            return reader.Poll(utcNow, cancelled);
        }
        internal void Enable(bool value)
        {
            lock (gate) { enabled = value && !disposed; generation++; ready = new List<LiveMonitorView>(); }
        }
        internal List<LiveMonitorView> Snapshot()
        { lock (gate) return ready.Select(v => v.VisibleAt(DateTime.UtcNow)).ToList(); }
        internal void Poll(IList<LiveMonitorTarget> configured, IList<LiveMonitorCandidate> current)
        {
            if (!enabled || disposed || Interlocked.CompareExchange(ref polling, 1, 0) != 0) return;
            int run = generation;
            var targets = configured.Select(t => t.Snapshot()).ToList();
            var candidates = current.GroupBy(c => c.Copy.Name, StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            Task.Factory.StartNew(() => {
                var rows = new List<LiveMonitorView>();
                Func<bool> cancelled = () => disposed || !enabled || generation != run;
                try
                {
                    var readerKeys = new HashSet<string>(targets.Select(t => t.CopyName + "\n" + t.Token + "\n" + t.Directory), StringComparer.OrdinalIgnoreCase);
                    foreach (string key in readers.Keys.Where(k => !readerKeys.Contains(k)).ToList()) readers.Remove(key);
                    var summaryKeys = new HashSet<string>(targets.Select(t => t.CopyName + "\n" + t.Token), StringComparer.OrdinalIgnoreCase);
                    foreach (string key in summaries.Keys.Where(k => !summaryKeys.Contains(k)).ToList()) summaries.Remove(key);
                    foreach(string key in projections.Keys.Where(k=>!summaryKeys.Contains(k)).ToList()){projections.Remove(key);savedBaselines.Remove(key);}
                    var open = openPaths();
                    foreach (var target in targets)
                    {
                        if (cancelled()) break;
                        var view = new LiveMonitorView { Target=target.Snapshot(), CopyName = target.CopyName, Name = target.Name, Login = target.Login, Platform = target.Platform,
                            Balance = "—", Equity = "—", Positions = "—", Updated = "—", History = "—", Detail = "", Floating = "—", NoSl = "—", Today = "—", Drawdown = "—" };
                        LiveMonitorCandidate candidate;
                        if (!candidates.TryGetValue(target.CopyName, out candidate) || !target.Matches(candidate.Copy, candidate.Account))
                        {
                            view.State = Lang.T("نیاز به آماده‌سازی", "Prepare again");
                            view.Detail = Lang.T("حساب یا مسیر نسخه تغییر کرده؛ دوباره آماده‌سازی کنید و گزارش‌خوان جدید را روی نمودار تازه وصل کنید.", "The account or copy path changed. Prepare again and attach the new reporter to a new chart.");
                        }
                        else if (!open.Contains(candidate.Copy.Exe))
                        {
                            view.State = Lang.T("متاتریدر بسته است", "Terminal closed");
                            view.Detail = Lang.T("پایش زنده متاتریدر را خودکار باز نمی‌کند.", "Live monitoring does not open terminals automatically.");
                        }
                        else
                        {
                            try
                            {
                                view.Name = candidate.Account.Trader;
                                LiveFeedSnapshot sample = read(target, DateTime.UtcNow, cancelled);
                                DateTime processStart;
                                if (sample != null && sample.IsLive && checkProcessGeneration && (!processStarts.TryGetValue(candidate.Copy.Exe, out processStart) || sample.HeartbeatUtc < processStart.AddSeconds(-1)))
                                    sample = new LiveFeedSnapshot(LiveFeedStatus.Waiting,"waiting-for-heartbeat-from-current-process",target.Platform,target.Login,target.Server,null,null);
                                if (sample == null) { view.State = Lang.T("منتظر گزارش‌خوان", "Waiting for reporter"); }
                                else
                                {
                                    view.Feed=sample;
                                    view.State = StateText(sample.Status);
                                    view.Detail = sample.Reason ?? "";
                                    if(!sample.IsLive) view.Detail += "\r\n" + LiveAutoStart.InitStatus(candidate.Copy);
                                    if (sample.HeartbeatUtc > DateTime.MinValue) view.Updated = sample.HeartbeatUtc.ToLocalTime().ToString("HH:mm:ss", CultureInfo.InvariantCulture)
                                        + " · " + Math.Max(0, (int)(DateTime.UtcNow - sample.HeartbeatUtc).TotalSeconds).ToString(CultureInfo.InvariantCulture) + "s";
                                    if (sample.IsLive)
                                    {
                                        view.LiveUntilUtc = sample.HeartbeatUtc.AddSeconds(LiveFeedReader.StaleSeconds);
                                        string summaryKey = target.CopyName + "\n" + target.Token;
                                        LiveReportSummaryCache cache;
                                        if (!summaries.TryGetValue(summaryKey, out cache)) summaries[summaryKey] = cache = new LiveReportSummaryCache();
                                        LiveReportSummary metrics = cache.Update(sample, DateTime.UtcNow);
                                        if(projectDashboard)
                                        {
                                            try
                                            {
                                                LiveDashboardProjectionCache projector;
                                                if(!projections.TryGetValue(summaryKey,out projector))projections[summaryKey]=projector=new LiveDashboardProjectionCache();
                                                view.Dashboard=projector.Update(target,sample,metrics);
                                                if(view.Dashboard!=null && !cancelled())
                                                {
                                                    string baselineKey=sample.RunId+":"+sample.HistoryRevision;string saved;
                                                    if(!savedBaselines.TryGetValue(summaryKey,out saved) || saved!=baselineKey)
                                                    {
                                                        // A baseline keeps its actual native collection timestamp, never this pulse time.
                                                        JournalCache.SaveLiveBaseline(sample.History);savedBaselines[summaryKey]=baselineKey;
                                                    }
                                                }
                                            }
                                            catch(Exception error){Log.Write("live dashboard "+target.CopyName+": "+error.GetType().Name+" "+error.Message);}
                                        }

                                        view.Floating = Amount(metrics.FloatingProfitSwap, sample.Currency); view.NoSl = metrics.NoSlCount.ToString(CultureInfo.InvariantCulture);
                                        view.Today = metrics.TodayKnown ? metrics.TodayClosedCount.ToString(CultureInfo.InvariantCulture) + " · " + Amount(metrics.TodayClosedNet, sample.Currency) : Lang.T("هنوز تأیید نشده", "Not confirmed yet");
                                        view.Drawdown = double.IsNaN(metrics.AccountDdPct) || double.IsInfinity(metrics.AccountDdPct) ? "—" : metrics.AccountDdPct.ToString("0.00", CultureInfo.InvariantCulture) + "%";
                                        view.Balance = Amount(sample.Balance, sample.Currency); view.Equity = Amount(sample.Equity, sample.Currency);
                                        view.Positions = sample.Positions.Count.ToString(CultureInfo.InvariantCulture);
                                        view.History = sample.History == null ? Lang.T("در حال همگام‌سازی", "Synchronizing")
                                            : Lang.T("تاریخچه آماده · نسخهٔ ", "History ready · revision ") + sample.HistoryRevision.ToString(CultureInfo.InvariantCulture);
                                        view.Detail += "\r\n" + Lang.T("مارجین: ", "Margin: ") + Amount(sample.Margin, sample.Currency)
                                            + " · " + Lang.T("آزاد: ", "Free: ") + Amount(sample.FreeMargin, sample.Currency)
                                            + "\r\n" + Lang.T("سود/زیان شناور + سواپ (بدون کمیسیون): ", "Floating P/L + swap (commission excluded): ") + view.Floating
                                            + " · " + Lang.T("بدون حد ضرر: ", "Without stop loss: ") + view.NoSl
                                            + "\r\n" + Lang.T("نتیجهٔ تحقق‌یافتهٔ امروز: ", "Today's realized result: ") + view.Today + " (" + metrics.TodayCountLabel + ")"
                                            + " · " + Lang.T("افت بالانس کل حساب: ", "Full account balance drawdown: ") + view.Drawdown
                                            + (string.IsNullOrEmpty(metrics.TodayReason) ? "" : "\r\n" + metrics.TodayReason);
                                        if (sample.Positions.Count > 0)
                                            view.Detail += "\r\n" + string.Join("\r\n", sample.Positions.Take(100).Select(p => p.Symbol + " · " + p.Volume.ToString("0.########", CultureInfo.InvariantCulture)));
                                    }
                                }
                            }
                            catch (OperationCanceledException) { break; }
                            catch { view.State = Lang.T("خوانده نشد", "Unreadable"); view.Detail = Lang.T("فایل پایش این حساب قابل خواندن نبود؛ دادهٔ قبلی زنده نمایش داده نمی‌شود.", "This account's live file could not be read. Earlier values are not displayed as live."); }
                        }
                        rows.Add(view);
                        // Publish completed accounts while another baseline is still being parsed.
                        lock(gate) if(!cancelled())
                        {
                            var done=new HashSet<string>(rows.Select(v=>v.CopyName),StringComparer.OrdinalIgnoreCase);
                            var configuredNames=new HashSet<string>(targets.Select(t=>t.CopyName),StringComparer.OrdinalIgnoreCase);
                            ready=rows.Concat(ready.Where(v=>configuredNames.Contains(v.CopyName) && !done.Contains(v.CopyName))).ToList();
                        }

                    }
                    lock (gate) if (!cancelled()) ready = rows;
                }
                catch
                {
                    lock (gate) if (!cancelled()) ready = targets.Select(t => new LiveMonitorView { CopyName = t.CopyName, Name = t.Name, Login = t.Login, Platform = t.Platform,
                        State = Lang.T("وضعیت در دسترس نیست", "Status unavailable"), Balance = "—", Equity = "—", Positions = "—", Updated = "—", History = "—", Floating = "—", NoSl = "—", Today = "—", Drawdown = "—",
                        Detail = Lang.T("تشخیص متاتریدرهای باز ممکن نشد؛ مقادیر قبلی زنده نیستند.", "Open terminals could not be verified; previous values are not live.") }).ToList();
                }
                finally { Interlocked.Exchange(ref polling, 0); }
            });
        }
        static string Amount(double value, string currency)
        { return double.IsNaN(value) || double.IsInfinity(value) ? "—" : value.ToString("N2", CultureInfo.InvariantCulture) + " " + currency; }
        internal static string StateText(LiveFeedStatus state)
        {
            switch (state)
            {
                case LiveFeedStatus.Live: return Lang.T("زنده · متصل", "Live · connected");
                case LiveFeedStatus.HistoryPending: return Lang.T("زنده · تاریخچه در حال آماده‌سازی", "Live · history updating");
                case LiveFeedStatus.Disconnected: return Lang.T("اتصال قطع است", "Disconnected");
                case LiveFeedStatus.IdentityMismatch: return Lang.T("حساب مطابقت ندارد", "Account mismatch");
                case LiveFeedStatus.Stopped: return Lang.T("گزارش‌خوان متوقف است", "Reporter stopped");
                case LiveFeedStatus.Stale: return Lang.T("دادهٔ زنده نرسیده", "Stale heartbeat");
                case LiveFeedStatus.Invalid: return Lang.T("داده نامعتبر است", "Invalid data");
                default: return Lang.T("منتظر گزارش‌خوان", "Waiting for reporter");
            }
        }
        public void Dispose() { lock (gate) { disposed = true; enabled = false; generation++; ready.Clear(); } }
    }
}
