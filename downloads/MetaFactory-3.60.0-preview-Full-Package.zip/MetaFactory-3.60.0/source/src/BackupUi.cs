using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MTManager
{
    // ================================================================== 3.24: the windows of backup and restore (approved mockup)

    /// <summary>A path written left to right, and a button to choose it (a folder, or a backup file).</summary>
    sealed class PathField : FlowLayoutPanel
    {
        public readonly TextBox Box;
        public event Action Chosen;

        public PathField(int width, bool file, string title)
        {
            AutoSize = true;
            WrapContents = false;
            Margin = Padding.Empty;
            Box = new TextBox { Width = Theme.S(width), RightToLeft = RightToLeft.No, Margin = Theme.Pad(0, 2, 0, 0) };
            var pick = new ModernButton(file ? Lang.T("انتخاب…", "Choose…") : Lang.T("تغییر…", "Change…"), ButtonKind.Secondary, file ? Glyph.Doc : Glyph.Folder, Glyph.None, true) { Margin = Theme.Pad(8, 0, 0, 0) };
            pick.Click += (s, e) =>
            {
                if (file)
                {
                    using (var ofd = new OpenFileDialog { Filter = Lang.T("فایل پشتیبان MetaFactory|*", "MetaFactory backup file|*") + AutoBackup.Extension + Lang.T("|همه‌ی فایل‌ها|*.*", "|All files|*.*"), Title = title })
                    {
                        try { if (File.Exists(Box.Text)) ofd.InitialDirectory = Path.GetDirectoryName(Box.Text); } catch { }
                        if (ofd.ShowDialog(FindForm()) != DialogResult.OK) return;
                        Box.Text = ofd.FileName;
                    }
                }
                else
                {
                    using (var fbd = new FolderBrowserDialog { Description = title, ShowNewFolderButton = true })
                    {
                        if (Directory.Exists(Box.Text)) fbd.SelectedPath = Box.Text;
                        if (fbd.ShowDialog(FindForm()) != DialogResult.OK) return;
                        Box.Text = fbd.SelectedPath;
                    }
                }
                if (Chosen != null) Chosen();
            };
            Controls.Add(Box);
            Controls.Add(pick);
        }

        public string Value { get { return Box.Text.Trim(); } set { Box.Text = value ?? ""; } }
    }

    /// <summary>«پشتیبان‌گیری» (3.24.1: the compact one approved): how much goes in the file, its password, where it goes, and the daily backup.</summary>
    sealed class BackupDialog : FormDialog
    {
        public const int MinPassword = 6;
        readonly TextBox pw1 = new TextBox { Width = Theme.S(260), RightToLeft = RightToLeft.No, UseSystemPasswordChar = true };
        readonly TextBox pw2 = new TextBox { Width = Theme.S(260), RightToLeft = RightToLeft.No, UseSystemPasswordChar = true };
        readonly PathField where = new PathField(260, false, Lang.T("پوشه‌ی فایل‌های پشتیبان (بهتر: فلش، دیسک دیگر یا پوشه‌ی Google Drive / OneDrive)", "Folder for the backup files (better: a USB stick, another disk or a Google Drive / OneDrive folder)"));
        readonly CheckBox auto = new CheckBox { AutoSize = true, Checked = true, Text = Lang.T("پشتیبان خودکار روزانه", "Daily automatic backup") };

        public string Password { get; private set; }
        public string Folder { get; private set; }
        public bool Auto { get; private set; }

        public static string DefaultFolder()
        {
            try { return Path.Combine(Path.GetPathRoot(Settings.DefaultBase()), "MetaFactory Backup"); }
            catch { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "MetaFactory Backup"); }
        }

        public BackupDialog(BackupData d, Settings s)
            : base(Lang.T("پشتیبان‌گیری", "Backup"), Fa.N(d.Students.Count) + Lang.T(" دانشجو", " students") + (d.Folders.Count > 0 ? Lang.T("، ", ", ") + Fa.N(d.Folders.Count) + Lang.T(" پوشه", " folders") : "") + Lang.T(" و گزارش‌ها در یک فایل.", " and reports in one file."))
        {
            string saved = Secret.Unprotect(s.BackupPasswordEnc ?? "");
            if (!string.IsNullOrEmpty(saved)) { pw1.Text = saved; pw2.Text = saved; }
            Row(Lang.T("رمز فایل", "File password"), pw1);
            Row(Lang.T("تکرار رمز", "Repeat password"), pw2);
            where.Value = string.IsNullOrWhiteSpace(s.BackupDir) ? DefaultFolder() : s.BackupDir;
            Row(Lang.T("جای ذخیره", "Save in"), where);
            auto.Checked = s.BackupAuto;
            auto.Margin = Theme.Pad(0, 6, 0, 0);
            Wide(auto);
            int noPassword = d.Students.Count(x => x.NoPassword);
            if (noPassword > 0) Wide(Theme.Label(Lang.T("رمز ", "The password of ") + Fa.N(noPassword) + Lang.T(" دانشجو روی این کامپیوتر خوانده نشد؛ بدون رمز در فایل می‌روند.", " students could not be read on this computer; they go into the file without a password."), 400, Theme.Small, Theme.Warn));
            Wide(Theme.Label(Lang.T("بدون رمز، فایل باز نمی‌شود.", "Without the password the file cannot be opened."), 400, Theme.Small, Theme.Muted));
            Button ok = AddButton(Lang.T("ساختن فایل پشتیبان", "Make backup file"), Save, true);
            Button cancel = AddButton(Lang.T("انصراف", "Cancel"), (x, e) => Close(DialogResult.Cancel));
            Finish();
            AcceptButton = ok;
            CancelButton = cancel;
            Shown += (x, e) => pw1.Focus();
        }

        void Save(object sender, EventArgs e)
        {
            if (pw1.Text.Length < MinPassword) { Ui.Message(this, Lang.T("رمز فایل باید دست‌کم ", "The file password must be at least ") + Fa.N(MinPassword) + Lang.T(" حرف باشد.", " characters."), MessageBoxIcon.Warning); pw1.Focus(); return; }
            if (pw1.Text != pw2.Text) { Ui.Message(this, Lang.T("رمز و تکرار آن یکی نیستند.", "The password and its repeat do not match."), MessageBoxIcon.Warning); pw2.Focus(); return; }
            string dir = where.Value;
            if (dir.Length == 0) { Ui.Message(this, Lang.T("جای ذخیره‌ی فایل را انتخاب کنید.", "Choose where to save the file."), MessageBoxIcon.Warning); return; }
            try { Directory.CreateDirectory(dir); }
            catch (Exception ex) { Ui.Message(this, Lang.T("در این پوشه نمی‌شود نوشت: ", "Cannot write in this folder: ") + ex.Message, MessageBoxIcon.Warning); return; }
            Password = pw1.Text;
            Folder = dir;
            Auto = auto.Checked;
            Close(DialogResult.OK);
        }

#if SNAPSHOT
        public void Preview(string password, string dir) { pw1.Text = pw2.Text = password; where.Value = dir; }
#endif
    }

    /// <summary>«بازگردانی از پشتیبان» (3.24.1: the compact one approved): the file and its password, one line of what is in it, a warning
    /// only when a MetaTrader is missing, where the copies are made and, only when there are students here already, whether a student
    /// in both takes the file's data. Nothing here is removed.</summary>
    sealed class RestoreDialog : FormDialog
    {
        readonly Settings settings;
        readonly AccountStore accounts;
        readonly PathField file = new PathField(260, true, Lang.T("فایل پشتیبان MetaFactory", "MetaFactory backup file"));
        readonly TextBox pw = new TextBox { Width = Theme.S(190), RightToLeft = RightToLeft.No, UseSystemPasswordChar = true };
        readonly Label info, warn;
        readonly FolderField folder;
        readonly RadioButton add = new RadioButton { AutoSize = true, Checked = true, Text = Lang.T("فقط دانشجوهای تازه اضافه شوند", "Add new students only") };
        readonly RadioButton update = new RadioButton { AutoSize = true, Text = Lang.T("دانشجوهای مشترک هم از روی فایل به‌روز شوند", "Also update students that are already here from the file") };
        readonly Button go;

        public BackupData Data { get; private set; }
        public RestorePlan Plan { get; private set; }
        public string Password { get; private set; }
        public string Folder { get { return folder.Value; } }

        public RestoreDialog(Settings s, AccountStore a)
            : base(Lang.T("بازگردانی از پشتیبان", "Restore from backup"))
        {
            settings = s;
            accounts = a;
            Row(Lang.T("فایل", "File"), file);
            var line = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = Padding.Empty };
            line.Controls.Add(pw);
            var open = new ModernButton(Lang.T("باز کردن", "Open"), ButtonKind.Secondary, Glyph.None, Glyph.None, true) { Margin = Theme.Pad(8, 0, 0, 0) };
            open.Click += (x, e) => Open();
            line.Controls.Add(open);
            Row(Lang.T("رمز فایل", "File password"), line);
            info = Theme.Label("", 420, Theme.Font, Theme.Ok);
            info.Visible = false;
            Wide(info);
            warn = Theme.Label("", 420, Theme.Small, Theme.Warn);
            warn.Visible = false;
            Wide(warn);
            folder = new FolderField(s, 230);
            Row(Lang.T("نسخه‌ها در", "Copies in"), folder);
            if (a.All.Any(x => x.HasLogin))
            {
                add.Margin = Theme.Pad(0, 6, 0, 0);
                Wide(add);
                Wide(update);
                add.CheckedChanged += (x, e) => Replan();
            }
            go = AddButton(Lang.T("بازگردانی", "Restore"), Go, true);
            go.Enabled = false;
            Button cancel = AddButton(Lang.T("انصراف", "Cancel"), (x, e) => Close(DialogResult.Cancel));
            Finish();
            AcceptButton = go;
            CancelButton = cancel;
            file.Chosen += () => pw.Focus();
            pw.KeyDown += (x, e) => { if (e.KeyCode == Keys.Enter) { Open(); e.Handled = e.SuppressKeyPress = true; } };
            Shown += (x, e) => { if (file.Value.Length == 0) file.Box.Focus(); else pw.Focus(); };
        }

        void Open()
        {
            Data = null;
            go.Enabled = false;
            warn.Visible = false;
            string path = file.Value;
            if (!File.Exists(path)) { Say(Lang.T("فایل پیدا نشد؛ «انتخاب…» را بزنید.", "File not found; press “Choose…”."), true); return; }
            Cursor = Cursors.WaitCursor;
            try
            {
                Data = BackupFormat.Open(File.ReadAllBytes(path), pw.Text);
                Password = pw.Text;
            }
            catch (BackupException e) { Say(e.Message, true); return; }
            catch (Exception e) { Say(Lang.T("فایل خوانده نشد: ", "The file could not be read: ") + e.Message, true); return; }
            finally { Cursor = Cursors.Default; }
            Say(Fa.N(Data.Students.Count) + Lang.T(" دانشجو، ", " students, ") + Fa.N(Data.Folders.Count) + Lang.T(" پوشه · ساخته‌شده ", " folders · made ") + Gd.Date(Data.Created), false);
            Replan();
        }

        void Say(string text, bool bad)
        {
            info.Text = text;
            info.ForeColor = bad ? Theme.Bad : Theme.Ok;
            info.Visible = true;
        }

        void Replan()
        {
            if (Data == null) return;
            Plan = Restore.Plan(Data, accounts.All, update.Checked);
            // A warning only when a MetaTrader is missing for some of the students to be added.
            int other = 0, none = 0;
            foreach (BackupStudent b in Plan.Add)
            {
                bool exact;
                string source = ServerCatalog.InstallFor(string.Equals(b.Kind, "MT4", StringComparison.OrdinalIgnoreCase) ? Kind.MT4 : Kind.MT5, b.Server, settings, out exact);
                if (source == null) none++;
                else if (!exact) other++;
            }
            var lines = new List<string>();
            if (other > 0) lines.Add(Lang.T("متاتریدرِ بروکرِ ", "The broker's MetaTrader of ") + Fa.N(other) + Lang.T(" دانشجو روی این کامپیوتر نصب نیست.", " students is not installed on this computer."));
            if (none > 0) lines.Add(Lang.T("برای ", "For ") + Fa.N(none) + Lang.T(" دانشجو MT4 یا MT5 اصلاً نصب نیست؛ این بار اضافه نمی‌شوند.", " students MT4 or MT5 is not installed at all; they are not added this time."));
            warn.Text = string.Join("\n", lines);
            warn.Visible = lines.Count > 0;
            // Those without any MetaTrader here are not added this time, so they are not counted on the button.
            int n = Plan.Add.Count - none + Plan.Update.Count;
            go.Text = n > 0 ? Lang.T("بازگردانی ", "Restore ") + Fa.N(n) + Lang.T(" دانشجو", " students") : Data.Folders.Count > 0 ? Lang.T("بازگردانی پوشه‌ها و گزارش‌ها", "Restore folders and reports") : Lang.T("چیزی برای بازگردانی نیست", "Nothing to restore");
            go.Enabled = n > 0 || Data.Folders.Count > 0;
        }

        void Go(object sender, EventArgs e)
        {
            if (Data == null || Plan == null) return;
            if (folder.Value.Length == 0) { Ui.Message(this, Lang.T("پوشه‌ی ساخت نسخه‌ها را انتخاب کنید.", "Choose the folder where the copies are made."), MessageBoxIcon.Warning); return; }
            try { CopyMaker.CheckFolder(folder.Value); }
            catch (Exception ex) { Ui.Error(this, ex); return; }
            Close(DialogResult.OK);
        }

#if SNAPSHOT
        /// <summary>Opens the sample file, then shows Windows paths in place of the screenshots' own folders.</summary>
        public void Preview(string path, string password, string shownFile, string shownFolder)
        {
            file.Value = path;
            pw.Text = password;
            Open();
            file.Value = shownFile;
            folder.Box.Value = shownFolder;
        }
#endif
    }
}
