// MetaFactory Live 1.00 - read-only observer on a dedicated, user-approved chart.
// Never sends, modifies or closes trades, switches accounts, or replaces another EA.
// May repair the symbol of its own dedicated observer chart after account connection.
// Timer snapshots are bounded; full history is rebuilt only after changes/bootstrap.
// HistorySelect can block the terminal API: no heartbeat guarantee during that call.
#property strict
#property copyright "MetaFactory"
#property version "1.06"
input string SessionToken = "";
input string ExpectedLogin = "";
input string ExpectedServer = "";
input string FromDate = "";
string WorkToken, WorkLogin, WorkServer, WorkFrom, OutFile, rootPath, runId;
long sequence = 0, revision = 0, exportRevision = 0;
bool sessionOwned=false;
string ownerKey="",beatKey="";
double ownerId=0;
uint leasePulseAt=0;
const int LeaseSeconds=30;
string BeatName(double id){return "MF.LiveBeat."+WorkToken+"."+DoubleToString(id,0);}
bool RecentOwner(double id)
{
   string key=BeatName(id);if(!GlobalVariableCheck(key))return false;
   double age=(double)TimeLocal()-GlobalVariableGet(key);
   return age>=-5 && age<=LeaseSeconds;
}
bool RefreshLease()
{
   if(!sessionOwned || !GlobalVariableCheck(ownerKey) || GlobalVariableGet(ownerKey)!=ownerId){sessionOwned=false;return false;}
   if(GlobalVariableSet(beatKey,(double)TimeLocal())==0){sessionOwned=false;return false;}
   leasePulseAt=GetTickCount();
   if(GlobalVariableGet(ownerKey)!=ownerId){sessionOwned=false;return false;}
   return true;
}
bool AcquireLease()
{
   sessionOwned=false;
   ownerKey="MF.LiveOwner."+WorkToken;
   long chart=ChartID()%4503599627370495;if(chart<0)chart=-chart;ownerId=(double)(chart+1);
   beatKey=BeatName(ownerId);
   // Temp creation never overwrites an existing lease. Claims use compare-and-swap.
   GlobalVariableTemp(ownerKey);GlobalVariableTemp(beatKey);
   if(!GlobalVariableCheck(ownerKey) || !GlobalVariableCheck(beatKey))return InitProblem("lease-create",GetLastError());
   double previous=GlobalVariableGet(ownerKey);
   if(previous!=0 && previous!=ownerId && RecentOwner(previous))return InitProblem("observer-already-active");
   if(GlobalVariableSet(beatKey,(double)TimeLocal())==0)return InitProblem("lease-heartbeat",GetLastError());
   if(!GlobalVariableSetOnCondition(ownerKey,ownerId,previous))return InitProblem("lease-claim-retry",GetLastError());
   // If the prior owner renewed during our claim, return the lease before publishing anything.
   if(previous!=0 && previous!=ownerId && RecentOwner(previous))
   {GlobalVariableSetOnCondition(ownerKey,previous,ownerId);return InitProblem("observer-renewed-during-claim");}
   sessionOwned=true;return RefreshLease();
}

uint bootTick = 0, lastPoll = 0, stableSince = 0, lastHistoryCheck = 0, recoveryStarted = 0, reconcileInterval = 60000;
bool backedOff = false;
string previousLightSignal = "";
bool dirty = true, wasConnected = false, writeOk = true, exportTrusted = false;
string liveState = "bootstrap", stableSignature = "", exportedSignature = "", previousOpenKey = "", previousDay = "";
uint historyHash1 = 2166136261, historyHash2 = 5381;
string N(double value) { return DoubleToString(value, 8); }
string T(datetime value) { return IntegerToString((long)value); }
string Clean(string value) { StringReplace(value,"\t"," "); StringReplace(value,"\r"," "); StringReplace(value,"\n"," "); return value; }
bool SameText(string a, string b) { StringToLower(a); StringToLower(b); return a == b; }
void Line(int h, string value)
{
   Pulse("write");
   if(!sessionOwned){writeOk=false;return;}
   if(!writeOk)return;
   if(FileTell(h)+(ulong)((StringLen(value)+2)*2)>67108864){writeOk=false;return;}
   if(FileWriteString(h,value+"\r\n")==0)writeOk=false;
}
void Step(string ignored) {}
void Pulse(string ignored, bool force = false) { if(sessionOwned && (force || GetTickCount()-leasePulseAt>=1000) && !RefreshLease())writeOk=false; }
void ReportState(string ignored, bool force = false) {}
void HashReset() { historyHash1 = 2166136261; historyHash2 = 5381; }
void HashText(string value)
{
   Pulse("hash");
   for(int j=0;j<StringLen(value);j++) { uint c=(uint)StringGetCharacter(value,j); historyHash1=(historyHash1^c)*16777619; historyHash2=historyHash2*33+c; }
   historyHash1=(historyHash1^10)*16777619; historyHash2=historyHash2*33+10;
}
string initProblem="";
uint retryInitAt=0;
bool InitProblem(string stage,int error=0)
{
   string message=stage+" error="+IntegerToString(error);
   if(message!=initProblem){Print("MetaFactory Live init: ",message);initProblem=message;}
   FolderCreate("MetaFactoryLive");
   int h=FileOpen("MetaFactoryLive\\init-status.txt",FILE_WRITE|FILE_TXT|FILE_UNICODE|FILE_SHARE_READ);
   if(h!=INVALID_HANDLE){FileWriteString(h,"MLINIT\t1\r\n"+T(TimeGMT())+"\r\n"+message+"\r\n");FileClose(h);}
   return false;
}
bool ValidToken()
{
   if(StringLen(WorkToken)!=32 || StringLen(WorkLogin)==0 || StringLen(WorkServer)==0 || StringLen(WorkServer)>256)return false;
   for(int i=0;i<32;i++){ushort c=StringGetCharacter(WorkToken,i);if(!((c>='0'&&c<='9')||(c>='a'&&c<='f')||(c>='A'&&c<='F')))return false;}
   for(int i=0;i<StringLen(WorkLogin);i++){ushort c=StringGetCharacter(WorkLogin,i);if(c<'0'||c>'9')return false;}
   return StringToInteger(WorkLogin)>0 && Clean(WorkServer)==WorkServer;
}
bool ResolveSession()
{
   WorkToken=SessionToken;WorkLogin=ExpectedLogin;WorkServer=ExpectedServer;WorkFrom=FromDate;
   // Never replace partially specified or invalid explicit inputs with another account's binding.
   if(WorkToken=="" && WorkLogin=="" && WorkServer=="")
   {
      ResetLastError();
      int h=FileOpen("MetaFactoryLive\\bootstrap.txt",FILE_READ|FILE_TXT|FILE_UNICODE|FILE_SHARE_READ);
      if(h==INVALID_HANDLE)return InitProblem("bootstrap-open",GetLastError());
      if(FileSize(h)>2048){FileClose(h);return InitProblem("bootstrap-size");}
      string magic=FileReadString(h);
      WorkToken=FileReadString(h);WorkLogin=FileReadString(h);WorkServer=FileReadString(h);
      string extra="";while(!FileIsEnding(h)){string line=FileReadString(h);if(line!="")extra=line;}
      FileClose(h);
      if(magic!="MLBOOT\t1" || extra!="")return InitProblem("bootstrap-format");
   }
   if(!ValidToken())return InitProblem("session-inputs-invalid");
   StringToLower(WorkToken);return true;
}
bool ExpectedAccount() { return WorkLogin==IntegerToString(Login()) && SameText(WorkServer,Server()); }
string Header()
{
   return "MTR\t2\t"+Platform()+"\t"+IntegerToString(TerminalInfoInteger(TERMINAL_BUILD))+"\t"+ReportVersion()+"\r\nQ\t"+WorkToken
      +"\r\nLIVE\t1\t"+WorkToken+"\t"+runId+"\t"+IntegerToString(exportRevision);
}
bool Finish(int h, string tmp)
{
   if(FileSize(h)>67108864) writeOk=false;
   FileClose(h);
   if(!writeOk) { FileDelete(tmp); return false; }
   if(!RefreshLease()){FileDelete(tmp);return false;}
   return FileMove(tmp,0,OutFile,FILE_REWRITE);
}
string Offset()
{
   long d=(long)(ServerNow()-TimeGMT()), r=(long)MathRound(d/1800.0)*1800;
   return MathAbs(d-r)>300 || MathAbs(r)>14*3600 ? "" : IntegerToString(r);
}
datetime base;

// Complete current positions only. Pending orders are intentionally not positions.
// The key excludes changing market prices/profit, so ticks never trigger full history.

#define FAR_DATE D'2100.01.01 00:00'
string Platform(){return "MT5";} string ReportVersion(){return "1.26";}
long Login(){return AccountInfoInteger(ACCOUNT_LOGIN);} string Server(){return AccountInfoString(ACCOUNT_SERVER);}
bool Connected(){return (bool)TerminalInfoInteger(TERMINAL_CONNECTED);} double Balance(){return AccountInfoDouble(ACCOUNT_BALANCE);}
datetime ServerNow(){return (datetime)MathMax(TimeTradeServer(),TimeCurrent());}
void AskAllHistory(){}
double sumAll=0,sumBonus=0; int dealCount=0; bool fullHistoryStable=true;
bool AddUp()
{
   if(!HistorySelect(0,FAR_DATE)) return false;
   HashReset(); sumAll=0; sumBonus=0; dealCount=HistoryDealsTotal();
   for(int i=0;i<dealCount;i++)
   {
      ulong d=HistoryDealGetTicket(i); if(d==0) return false;
      long type=0,stamp=0; double profit=0,commission=0,fee=0,swap=0;
      if(!HistoryDealGetInteger(d,DEAL_TYPE,type)||!HistoryDealGetInteger(d,DEAL_TIME_MSC,stamp)||!HistoryDealGetDouble(d,DEAL_PROFIT,profit)||!HistoryDealGetDouble(d,DEAL_COMMISSION,commission)||!HistoryDealGetDouble(d,DEAL_FEE,fee)||!HistoryDealGetDouble(d,DEAL_SWAP,swap)) return false;
      ulong order=(ulong)HistoryDealGetInteger(d,DEAL_ORDER);double entrySl=-1;
      if(order>0 && !HistoryOrderGetDouble(order,ORDER_SL,entrySl))entrySl=-1;
      double value=profit+commission+fee+swap; if(!MathIsValidNumber(value)) return false;
      if(type!=DEAL_TYPE_CREDIT){sumAll+=value;if(type==DEAL_TYPE_BONUS)sumBonus+=value;}
      HashText(IntegerToString(d)+"|"+IntegerToString(type)+"|"+IntegerToString(stamp)+"|"+N(profit)+"|"+N(commission)+"|"+N(fee)+"|"+N(swap)+"|"+HistoryDealGetString(d,DEAL_SYMBOL)+"|"+IntegerToString(HistoryDealGetInteger(d,DEAL_POSITION_ID))+"|"+IntegerToString(HistoryDealGetInteger(d,DEAL_ENTRY))+"|"+N(HistoryDealGetDouble(d,DEAL_VOLUME))+"|"+N(HistoryDealGetDouble(d,DEAL_PRICE))+"|"+N(HistoryDealGetDouble(d,DEAL_SL))+"|"+N(HistoryDealGetDouble(d,DEAL_TP))+"|"+HistoryDealGetString(d,DEAL_COMMENT)+"|"+N(entrySl));
   }
   return dealCount==HistoryDealsTotal() && MathIsValidNumber(sumAll) && MathIsValidNumber(sumBonus);
}
bool AddsUp(){double tolerance=MathMax(0.02,MathAbs(Balance())*0.000001);return MathAbs(sumAll-Balance())<=tolerance || MathAbs(sumAll-sumBonus-Balance())<=tolerance;}
bool ScanHistory(){return AddUp();}
int HistoryCount(){return HistoryDealsTotal();}
int ScannedCount(){return dealCount;}
bool HistoryTrusted(){return AddsUp();}
string Currency(){return AccountInfoString(ACCOUNT_CURRENCY);}
double Equity(){return AccountInfoDouble(ACCOUNT_EQUITY);} double Margin(){return AccountInfoDouble(ACCOUNT_MARGIN);}
double FreeMargin(){return AccountInfoDouble(ACCOUNT_MARGIN_FREE);} double Credit(){return AccountInfoDouble(ACCOUNT_CREDIT);}
long     pid[];           // position ids, sorted
string   pSym[];
bool     pBuy[], pIn[];
double   pInVol[], pInValue[], pOutVol[], pOutValue[], pCost[], pSwap[], pProfit[], pSlEntry[], pSlFinal[], pTp[];
datetime pOpen[], pClose[];
string   pComment[];

int Find(long id)
{
   int lo = 0, hi = ArraySize(pid) - 1;
   while(lo <= hi)
   {
      int mid = (lo + hi) / 2;
      if(pid[mid] == id) return mid;
      if(pid[mid] < id) lo = mid + 1; else hi = mid - 1;
   }
   return -1;
}

void Positions()
{
   Pulse("positions", true);
   // The ids of every position that has a buy or sell deal, once each.
   long all[];
   int n = 0;
   ArrayResize(all, dealCount);
   for(int i = 0; i < dealCount; i++)
   {
      if(i % 256 == 0) Pulse("positions");
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(type != DEAL_TYPE_BUY && type != DEAL_TYPE_SELL) continue;
      all[n++] = HistoryDealGetInteger(d, DEAL_POSITION_ID);
   }
   ArrayResize(all, n);
   if(n > 1) ArraySort(all);
   int u = 0;
   ArrayResize(pid, n);
   for(int i = 0; i < n; i++) if(u == 0 || all[i] != pid[u - 1]) pid[u++] = all[i];
   ArrayResize(pid, u);
   ArrayResize(pSym, u); ArrayResize(pBuy, u); ArrayResize(pIn, u); ArrayResize(pInVol, u); ArrayResize(pInValue, u); ArrayResize(pOutVol, u);
   ArrayResize(pOutValue, u); ArrayResize(pCost, u); ArrayResize(pSwap, u); ArrayResize(pProfit, u); ArrayResize(pSlEntry, u); ArrayResize(pSlFinal, u);
   ArrayResize(pTp, u); ArrayResize(pOpen, u); ArrayResize(pClose, u); ArrayResize(pComment, u);
   for(int k = 0; k < u; k++)
   {
      pSym[k] = ""; pBuy[k] = true; pIn[k] = false; pInVol[k] = 0; pInValue[k] = 0; pOutVol[k] = 0; pOutValue[k] = 0; pCost[k] = 0; pSwap[k] = 0;
      pProfit[k] = 0; pSlEntry[k] = 0; pSlFinal[k] = 0; pTp[k] = 0; pOpen[k] = 0; pClose[k] = 0; pComment[k] = "";
   }
   for(int i = 0; i < dealCount; i++)
   {
      if(i % 256 == 0) Pulse("positions");
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(type != DEAL_TYPE_BUY && type != DEAL_TYPE_SELL) continue;
      int k = Find(HistoryDealGetInteger(d, DEAL_POSITION_ID));
      if(k < 0) continue;
      long entry = HistoryDealGetInteger(d, DEAL_ENTRY);
      datetime t = (datetime)HistoryDealGetInteger(d, DEAL_TIME);
      double vol = HistoryDealGetDouble(d, DEAL_VOLUME), price = HistoryDealGetDouble(d, DEAL_PRICE);
      pCost[k] += HistoryDealGetDouble(d, DEAL_COMMISSION) + HistoryDealGetDouble(d, DEAL_FEE);
      pSwap[k] += HistoryDealGetDouble(d, DEAL_SWAP);
      pProfit[k] += HistoryDealGetDouble(d, DEAL_PROFIT);
      if(entry == DEAL_ENTRY_IN)
      {
         if(!pIn[k])
         {
            pIn[k] = true;
            pSym[k] = HistoryDealGetString(d, DEAL_SYMBOL);
            pBuy[k] = type == DEAL_TYPE_BUY;
            pOpen[k] = t;
            pComment[k] = Clean(HistoryDealGetString(d, DEAL_COMMENT));
            ulong order = (ulong)HistoryDealGetInteger(d, DEAL_ORDER);
            pSlEntry[k] = -1;
            if(order > 0 && !HistoryOrderGetDouble(order, ORDER_SL, pSlEntry[k])) pSlEntry[k] = -1;
         }
         pInVol[k] += vol;
         pInValue[k] += vol * price;
      }
      else
      {
         // DEAL_ENTRY_OUT, OUT_BY, and INOUT (a netting account turned round): the volume that left the position.
         if(pSym[k] == "") { pSym[k] = HistoryDealGetString(d, DEAL_SYMBOL); pBuy[k] = type == DEAL_TYPE_SELL; }
         // A netting account turned round (INOUT): only the part that closed the position left it.
         double closing = entry == DEAL_ENTRY_INOUT ? MathMax(0.0, MathMin(vol, pInVol[k] - pOutVol[k])) : vol;
         pOutVol[k] += closing;
         pOutValue[k] += closing * price;
         if(t > pClose[k]) pClose[k] = t;
         pSlFinal[k] = HistoryDealGetDouble(d, DEAL_SL);
         pTp[k] = HistoryDealGetDouble(d, DEAL_TP);
      }
   }
}


bool OpenLines(string &rows[],string &key)
{
   ArrayResize(rows,0);key="";int total=PositionsTotal();if(total>10000)return false;
   for(int i=0;i<total;i++)
   {
      ulong ticket=PositionGetTicket(i);if(ticket==0)return false;
      long id=0,kind=0,opened=0;double volume=0,price=0,sl=0,tp=0,profit=0,swap=0,current=0;
      if(!PositionGetInteger(POSITION_IDENTIFIER,id)||!PositionGetInteger(POSITION_TYPE,kind)||!PositionGetInteger(POSITION_TIME,opened)||!PositionGetDouble(POSITION_VOLUME,volume)||!PositionGetDouble(POSITION_PRICE_OPEN,price)||!PositionGetDouble(POSITION_SL,sl)||!PositionGetDouble(POSITION_TP,tp)||!PositionGetDouble(POSITION_PROFIT,profit)||!PositionGetDouble(POSITION_SWAP,swap)||!PositionGetDouble(POSITION_PRICE_CURRENT,current))return false;
      if(id<=0 || opened<=0 || !MathIsValidNumber(profit+swap+price+current+volume+sl+tp))return false;
      string symbol=PositionGetString(POSITION_SYMBOL);int k=Find(id);
      double entry=k>=0&&pIn[k]?pSlEntry[k]:-1;
      double cost=k>=0&&pOutVol[k]<=0?pCost[k]:0;
      key+=IntegerToString(id)+":"+N(volume)+":"+N(price)+":"+N(sl)+":"+N(tp)+":"+N(swap)+";";
      int n=ArraySize(rows);ArrayResize(rows,n+1);
      rows[n]="O\t"+IntegerToString(id)+"\t"+Clean(symbol)+"\t"+(kind==POSITION_TYPE_BUY?"0":"1")+"\t"+N(volume)+"\t"+IntegerToString(opened)+"\t"+N(price)+"\t"+N(sl)+"\t"+N(tp)+"\t"+N(profit)+"\t"+N(swap)+"\t"+N(entry)+"\t"+N(current)+"\t"+N(cost);
   }
   return total==PositionsTotal();
}
void OnTradeTransaction(const MqlTradeTransaction &transaction,const MqlTradeRequest &request,const MqlTradeResult &result)
{
   // Notification only: no trading request is ever submitted by this EA.
   if(transaction.type==TRADE_TRANSACTION_DEAL_ADD || transaction.type==TRADE_TRANSACTION_DEAL_UPDATE || transaction.type==TRADE_TRANSACTION_DEAL_DELETE || transaction.type==TRADE_TRANSACTION_HISTORY_ADD || transaction.type==TRADE_TRANSACTION_HISTORY_UPDATE || transaction.type==TRADE_TRANSACTION_HISTORY_DELETE || transaction.type==TRADE_TRANSACTION_POSITION)
   {dirty=true;backedOff=false;recoveryStarted=GetTickCount();}
}
// Runs only for a changed baseline, never on ordinary one-second price snapshots.
// Verify the source again before publication so same-count broker corrections cannot
// combine an older position reconstruction with a newer balance chronology.
bool ValidateExport(uint expectedHash1,uint expectedHash2,int expectedCount,double expectedSum,double expectedBalance)
{
   if(!ExpectedAccount() || !Connected() || IsStopped() || !ScanHistory())return false;
   string rows[],key="";
   double tolerance=MathMax(0.02,MathAbs(expectedBalance)*0.000001);
   return historyHash1==expectedHash1 && historyHash2==expectedHash2 && ScannedCount()==expectedCount
      && MathAbs(sumAll-expectedSum)<0.0000001 && MathAbs(Balance()-expectedBalance)<=tolerance
      && HistoryTrusted() && OpenLines(rows,key) && key==previousOpenKey
      && ExpectedAccount() && Connected() && !IsStopped();
}

bool ExportReport()
{
   uint sourceHash1=historyHash1,sourceHash2=historyHash2;
   int sourceCount=ScannedCount();double sourceSum=sumAll;
   bool addsUp = AddsUp();
   double snapshotBalance = AccountInfoDouble(ACCOUNT_BALANCE);
   double curveTolerance = MathMax(0.02, MathAbs(snapshotBalance) * 0.000001);
   bool bonusExcluded = MathAbs(sumAll - snapshotBalance) > curveTolerance && MathAbs(sumAll - sumBonus - snapshotBalance) <= curveTolerance;
   Positions();

   // Now: the server's clock, and never before the last deal (the last price can be old after a quiet spell).
   datetime now = (datetime)MathMax(TimeTradeServer(), TimeCurrent());
   datetime lastTrade = 0, firstSeen = 0;
   for(int i = 0; i < dealCount; i++)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      datetime t = (datetime)HistoryDealGetInteger(d, DEAL_TIME);
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(t > now) now = t;
      if(firstSeen == 0 || t < firstSeen) firstSeen = t;
      if((type == DEAL_TYPE_BUY || type == DEAL_TYPE_SELL) && t > lastTrade) lastTrade = t;
   }
   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong p = PositionGetTicket(i);
      if(p == 0) continue;
      datetime t = (datetime)PositionGetInteger(POSITION_TIME);
      if(t > now) now = t;
      if(t > lastTrade) lastTrade = t;
   }
   base = StringToTime(WorkFrom);
   if(base <= 0) base = now - 7 * 86400;
   string tmp = OutFile + "."+runId+".part";
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) { Print("MTManagerReport: cannot write ", tmp); return false; }
   Step("writing");
   Pulse("writing", true);
   Line(h, Header());
   Line(h, "A\t" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "\t" + Clean(AccountInfoString(ACCOUNT_SERVER)) + "\t" + AccountInfoString(ACCOUNT_CURRENCY) + "\t" +
           N(snapshotBalance) + "\t" + N(AccountInfoDouble(ACCOUNT_EQUITY)) + "\t" + T(now) + "\t" + T(base) + "\t" + Clean(AccountInfoString(ACCOUNT_COMPANY)) + "\t" +
           Offset() + "\t" + IntegerToString(AccountInfoInteger(ACCOUNT_LEVERAGE)) + "\t" + N(AccountInfoDouble(ACCOUNT_MARGIN)) + "\t" + N(AccountInfoDouble(ACCOUNT_MARGIN_FREE)) + "\t" +
           N(AccountInfoDouble(ACCOUNT_CREDIT)));
   // H: whether the history adds up to the balance, the sum, the balance and the number of deals.
   Line(h, "H\t" + (addsUp ? "1" : "0") + "\t" + N(sumAll) + "\t" + N(snapshotBalance) + "\t" + IntegerToString(dealCount));
   // L: the last trade of the whole history (a deal or a position opened) and the first record of the account.
   Line(h, "L\t" + T(lastTrade) + "\t" + T(firstSeen));
   int records = 0, curveCount = 0, curveSeen = 0;
   double curveSum = 0;
   bool curveScanOk = fullHistoryStable;

   // Money in and out since the first day: time, amount, comment, deal type (2 balance, 3 credit, 4 charge, 5 correction, 6 bonus...).
   for(int i = 0; i < dealCount; i++)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) { curveScanOk = false; continue; }
      curveSeen++;
      long type = 0, eventTimeMs = 0;
      double profit = 0, commission = 0, fee = 0, swap = 0;
      bool fieldsOk = HistoryDealGetInteger(d, DEAL_TYPE, type) && HistoryDealGetInteger(d, DEAL_TIME_MSC, eventTimeMs)
         && HistoryDealGetDouble(d, DEAL_PROFIT, profit) && HistoryDealGetDouble(d, DEAL_COMMISSION, commission)
         && HistoryDealGetDouble(d, DEAL_FEE, fee) && HistoryDealGetDouble(d, DEAL_SWAP, swap);
      double net = profit + commission + fee + swap;
      if(!fieldsOk || (long)d <= 0 || eventTimeMs <= 0 || !MathIsValidNumber(net)) curveScanOk = false;
      else if(type != DEAL_TYPE_CREDIT && !(bonusExcluded && type == DEAL_TYPE_BONUS))
      {
         // J includes opening commissions, partial closes and all cash adjustments,
         // including records before WorkFrom. Credit is outside account balance.
         Line(h, "J\t" + IntegerToString(eventTimeMs) + "\t" + IntegerToString(d) + "\t" + IntegerToString(type) + "\t" + N(net));
         curveCount++; records++; curveSum += net;
      }
      // Daily validation joins J balance events to D deal classifications, never T aggregates.
      datetime detailTime=(datetime)(eventTimeMs/1000);
      bool dailyMovement=type!=DEAL_TYPE_BALANCE && type!=DEAL_TYPE_CREDIT && type!=DEAL_TYPE_CORRECTION && type!=DEAL_TYPE_BONUS;
      if(dailyMovement && detailTime>=base)
      {
         long detailOrder=0,detailEntry=0,detailPosition=0;double detailVolume=0,detailPrice=0;string detailSymbol="",detailComment="";
         bool detailOk=fieldsOk && HistoryDealGetInteger(d,DEAL_ORDER,detailOrder) && HistoryDealGetInteger(d,DEAL_ENTRY,detailEntry)
            && HistoryDealGetInteger(d,DEAL_POSITION_ID,detailPosition) && HistoryDealGetDouble(d,DEAL_VOLUME,detailVolume)
            && HistoryDealGetDouble(d,DEAL_PRICE,detailPrice) && HistoryDealGetString(d,DEAL_SYMBOL,detailSymbol)
            && HistoryDealGetString(d,DEAL_COMMENT,detailComment) && MathIsValidNumber(detailVolume) && MathIsValidNumber(detailPrice);
         if(!detailOk)curveScanOk=false;
         else
         {
            Line(h,"D\t"+IntegerToString(d)+"\t"+IntegerToString(detailOrder)+"\t"+T(detailTime)+"\t"+IntegerToString(type)+"\t"+IntegerToString(detailEntry)+"\t"+Clean(detailSymbol)+"\t"+N(detailVolume)+"\t"+N(detailPrice)+"\t"+N(commission)+"\t"+N(fee)+"\t"+N(swap)+"\t"+N(profit)+"\t"+IntegerToString(detailPosition)+"\t"+Clean(detailComment));
            // D is an extension row; END counts only J/T/O/B, as the MTR reader specifies.
         }
      }
      if(type == DEAL_TYPE_BUY || type == DEAL_TYPE_SELL) continue;
      if(type == DEAL_TYPE_BUY_CANCELED || type == DEAL_TYPE_SELL_CANCELED) continue;
      datetime t = (datetime)HistoryDealGetInteger(d, DEAL_TIME);
      if(t < base) continue;
      double amount = HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_COMMISSION) + HistoryDealGetDouble(d, DEAL_FEE) + HistoryDealGetDouble(d, DEAL_SWAP);
      Line(h, "B\t" + T(t) + "\t" + N(amount) + "\t" + Clean(HistoryDealGetString(d, DEAL_COMMENT)) + "\t" + IntegerToString(type));
      records++;
   }

   // Positions still open, by id: a position partly closed is written as its closed part (T) and its open rest (O).
   long openIds[];
   int positions = PositionsTotal();
   ArrayResize(openIds, positions);
   int openCount = 0;
   for(int i = 0; i < positions && openCount < ArraySize(openIds); i++)
   {
      ulong p = PositionGetTicket(i);
      if(p == 0) continue;
      openIds[openCount++] = PositionGetInteger(POSITION_IDENTIFIER);
   }
   ArrayResize(openIds, openCount);

   // Whole-account PF proof uses the already-built full-history position aggregates.
   // Open/partly open positions are excluded; full entry and exit costs belong to closed positions.
   double pfGain=0, pfLoss=0, pfTradingNet=0;
   int pfCount=0; bool pfReady=true;
   for(int k=0;k<ArraySize(pid);k++)
   {
      if(k%256==0) Pulse("writing");
      double positionNet=pProfit[k]+pCost[k]+pSwap[k];
      pfTradingNet+=positionNet;
      bool pfOpen=false;
      for(int i=0;i<openCount && !pfOpen;i++) pfOpen=openIds[i]==pid[k];
      if(pfOpen || pOutVol[k]<=0) continue;
      if(!pIn[k]) pfReady=false;
      double rounded=NormalizeDouble(positionNet,2);
      if(rounded>0)pfGain+=rounded;else if(rounded<0)pfLoss-=rounded;
      pfCount++;
   }
   if(pfReady) Line(h,"PF\t1\t"+IntegerToString(pfCount)+"\t"+N(pfGain)+"\t"+N(pfLoss)+"\t"+N(pfTradingNet));

   // Each position with volume closed since the first day: its entry, its exits, and the Stop Loss of the order that opened it.
   for(int k = 0; k < ArraySize(pid); k++)
   {
      if(k % 256 == 0) Pulse("writing");
      if(pOutVol[k] <= 0 || pClose[k] < base) continue;
      bool stillOpen = false;
      for(int i = 0; i < openCount && !stillOpen; i++) stillOpen = openIds[i] == pid[k];
      double volume = pOutVol[k];
      double openPrice = pInVol[k] > 0 ? pInValue[k] / pInVol[k] : 0;
      datetime open = pIn[k] ? pOpen[k] : pClose[k];
      Line(h, "T\t" + IntegerToString(pid[k]) + "\t" + pSym[k] + "\t" + (pBuy[k] ? "0" : "1") + "\t" + N(volume) + "\t" + T(open) + "\t" + N(openPrice) + "\t" +
              T(pClose[k]) + "\t" + N(pOutValue[k] / pOutVol[k]) + "\t" + N(pIn[k] ? pSlEntry[k] : -1) + "\t" + N(pSlFinal[k]) + "\t" + N(pTp[k]) + "\t" +
              N(pCost[k]) + "\t" + N(pSwap[k]) + "\t" + N(pProfit[k]) + "\t" + pComment[k] + (stillOpen ? " [part]" : ""));
      records++;
   }
   // Positions still open.
   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong p = PositionGetTicket(i);
      if(p == 0) continue;
      string symbol = PositionGetString(POSITION_SYMBOL);
      bool buy = PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY;
      double volume = PositionGetDouble(POSITION_VOLUME), openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      datetime open = (datetime)PositionGetInteger(POSITION_TIME);
      long id = PositionGetInteger(POSITION_IDENTIFIER);
      double sl = PositionGetDouble(POSITION_SL), tp = PositionGetDouble(POSITION_TP), profit = PositionGetDouble(POSITION_PROFIT), swap = PositionGetDouble(POSITION_SWAP);
      int k = Find(id);
      double slEntry = k >= 0 && pIn[k] ? pSlEntry[k] : -1;
      Line(h, "O\t" + IntegerToString(id) + "\t" + symbol + "\t" + (buy ? "0" : "1") + "\t" + N(volume) + "\t" + T(open) + "\t" + N(openPrice) + "\t" + N(sl) + "\t" + N(tp) + "\t" +
              N(profit) + "\t" + N(swap) + "\t" + N(slEntry) + "\t" + N(PositionGetDouble(POSITION_PRICE_CURRENT)) + "\t" +
              N(k >= 0 && pOutVol[k] <= 0 ? pCost[k] : 0));   // the entry's commission (a part-closed one's went with its closed part)
      records++;
   }
   Step("writing");
   curveScanOk = curveScanOk && curveSeen == dealCount && HistoryDealsTotal() == dealCount && !IsStopped() && TerminalInfoInteger(TERMINAL_CONNECTED) && ExpectedAccount()
      && MathIsValidNumber(curveSum) && MathIsValidNumber(snapshotBalance) && MathAbs(AccountInfoDouble(ACCOUNT_BALANCE) - snapshotBalance) <= curveTolerance;
   bool curveReconciled = curveScanOk && addsUp && MathAbs(curveSum - snapshotBalance) <= curveTolerance;
   // JC v1: J count, sum, snapshot balance, reconciled, scan OK, all-history requested, bonus excluded.
   // AddUp always uses HistorySelect(0,FAR_DATE); a successful selection is required above.
   Line(h, "JC\t1\t" + IntegerToString(curveCount) + "\t" + N(curveSum) + "\t" + N(snapshotBalance) + "\t" + (curveReconciled ? "1" : "0")
      + "\t" + (curveScanOk ? "1" : "0") + "\t1\t" + (bonusExcluded ? "1" : "0"));
   Line(h, "M\ttrades-only");
   Line(h, "END\t" + IntegerToString(records));
   if(IsStopped() || !ExpectedAccount()) { FileClose(h); FileDelete(tmp); return false; }
   exportTrusted=curveReconciled;
   if(!exportTrusted || !writeOk || !ValidateExport(sourceHash1,sourceHash2,sourceCount,sourceSum,snapshotBalance)){FileClose(h);FileDelete(tmp);return false;}
   bool finished = Finish(h, tmp);
   Pulse(finished ? "done" : "write-failed", true);
   return finished;
}


int observedCount=-1;
double observedBalance=0,observedCredit=0;
bool WriteSnapshot(string forcedState="")
{
   if(!RefreshLease())return false;
   long snapshotLogin=Login();string snapshotServer=Server();
   bool identity=ExpectedAccount(), connected=Connected()&&identity;
   string state=forcedState!=""?forcedState:(!identity?"identity-mismatch":(!connected?"disconnected":liveState));
   string rows[],key="";
   bool readOk=!connected || OpenLines(rows,key);
   if(connected && readOk && forcedState=="" && state=="ready" && (dirty || key!=previousOpenKey || HistoryCount()!=observedCount || Balance()!=observedBalance || Credit()!=observedCredit))
   {dirty=true;liveState="history-pending";state=liveState;}
   double balance=identity?Balance():0,equity=identity?Equity():0,margin=identity?Margin():0,free=identity?FreeMargin():0,credit=identity?Credit():0;
   if(!readOk || !MathIsValidNumber(balance+equity+margin+free+credit)){ArrayResize(rows,0);state="error";connected=false;balance=0;equity=0;margin=0;free=0;credit=0;}
   long estimatedBytes=2048;
   for(int i=0;i<ArraySize(rows);i++)estimatedBytes+=(StringLen(rows[i])+2)*2;
   if(estimatedBytes>2097152){ArrayResize(rows,0);state="error";connected=false;}
   if(Login()!=snapshotLogin || Server()!=snapshotServer || (identity && !ExpectedAccount()))return false;
   string path=rootPath+"\\snapshot.txt",tmp=path+"."+runId+".part";
   ResetLastError();
   int h=FileOpen(tmp,FILE_WRITE|FILE_TXT|FILE_UNICODE);if(h==INVALID_HANDLE)return InitProblem("snapshot-open",GetLastError());
   writeOk=true;
   Line(h,"MLIVE\t1\t"+Platform());Line(h,"Q\t"+WorkToken);
   Line(h,"R\t"+runId+"\t"+IntegerToString(++sequence)+"\t"+T(TimeGMT()));
   Line(h,"A\t"+IntegerToString(Login())+"\t"+Clean(Server())+"\t"+Clean(identity?Currency():""));
   Line(h,"S\t"+(connected?"1":"0")+"\t"+state);
   Line(h,"V\t"+N(balance)+"\t"+N(equity)+"\t"+N(margin)+"\t"+N(free)+"\t"+N(credit));
   Line(h,"H\t"+IntegerToString(revision)+"\t"+IntegerToString(revision%2));
   for(int i=0;i<ArraySize(rows);i++)Line(h,rows[i]);
   Line(h,"END\t"+IntegerToString(ArraySize(rows)));FileClose(h);
   if(!writeOk || Login()!=snapshotLogin || Server()!=snapshotServer || (connected && !Connected()) || (identity && !ExpectedAccount())){FileDelete(tmp);return false;}
   if(!RefreshLease()){FileDelete(tmp);return false;}
   ResetLastError();
   if(!FileMove(tmp,0,path,FILE_REWRITE))
   {
      // A sharing violation must not destroy the last complete frame. Publish the same closed
      // temporary frame to a second bounded slot; the reader still validates identity/history/freshness.
      ResetLastError();
      if(FileMove(tmp,0,path+".fallback",FILE_REWRITE)){if(initProblem!="snapshot-publish-fallback error=0")InitProblem("snapshot-publish-fallback");return true;}
      int error=GetLastError();FileDelete(tmp);return InitProblem("snapshot-publish",error);
   }
   if(initProblem=="snapshot-publish-fallback error=0")InitProblem("snapshot-publish-recovered");
   return true;
}
void PollHistory()
{
   uint tick=GetTickCount();
   if(recoveryStarted!=0 && tick-recoveryStarted>=60000)backedOff=true;
   if(lastPoll!=0 && tick-lastPoll<(uint)(backedOff?30000:2000))return;
   lastPoll=tick;
   if(!ExpectedAccount() || !Connected())return;
   if(recoveryStarted==0)recoveryStarted=tick;
   bool scanned=ScanHistory();lastHistoryCheck=GetTickCount();
   if(!scanned || !Connected() || !ExpectedAccount()) {stableSignature="";stableSince=GetTickCount();liveState="history-unconfirmed";dirty=true;return;}
   string signature=IntegerToString(ScannedCount())+":"+N(sumAll)+":"+N(Balance())+":"+IntegerToString((long)historyHash1)+":"+IntegerToString((long)historyHash2)+":"+previousOpenKey+":"+previousDay;
   observedCount=HistoryCount();observedBalance=Balance();observedCredit=Credit();
   if(signature!=stableSignature){stableSignature=signature;stableSince=GetTickCount();liveState="history-pending";dirty=true;return;}
   if(!HistoryTrusted()){liveState="history-unconfirmed";dirty=true;if(GetTickCount()-recoveryStarted>=30000)backedOff=true;return;}
   if(GetTickCount()-stableSince<2000 || GetTickCount()-bootTick<(uint)(ScannedCount()==0?8000:3000)){liveState="history-pending";dirty=true;return;}
   if(signature==exportedSignature && revision>0){dirty=false;backedOff=false;recoveryStarted=0;liveState="ready";return;}
   exportRevision=revision+1;
   OutFile=rootPath+"\\history-"+IntegerToString(exportRevision%2)+".txt";
   writeOk=true;exportTrusted=false;
   bool published=ExportReport();
   if(published && exportTrusted && ExpectedAccount() && Connected())
   {revision=exportRevision;exportedSignature=signature;dirty=false;backedOff=false;recoveryStarted=0;liveState="ready";}
   else{dirty=true;liveState="history-unconfirmed";}
}
bool BeginLiveSession()
{
   if(!ResolveSession())return false;
   rootPath="MetaFactoryLive\\"+WorkToken;
   FolderCreate("MetaFactoryLive");FolderCreate(rootPath);
   if(!AcquireLease())return false;
   string genKey="MF.LiveGen."+WorkToken;GlobalVariableTemp(genKey);
   long generation=(long)GlobalVariableGet(genKey);
   if(generation<0 || generation>=4503599627370495)generation=0;
   GlobalVariableSet(genKey,(double)(generation+1));
   sequence=0;revision=0;exportRevision=0;dirty=true;wasConnected=false;
   stableSignature="";exportedSignature="";previousLightSignal="";previousOpenKey="";previousDay="";lastPoll=0;lastHistoryCheck=0;liveState="bootstrap";
   bootTick=GetTickCount();recoveryStarted=bootTick;
   runId=IntegerToString((long)TimeGMT())+"-"+IntegerToString((long)bootTick)+"-"+IntegerToString(ChartID())+"-"+IntegerToString(generation+1);
   HashReset();HashText(WorkToken);reconcileInterval=60000+historyHash1%15000;
   initProblem="";Print("MetaFactory Live init: session-ready; waiting for matching account connection");
   InitProblem("session-ready");
   WriteSnapshot();return true;
}
uint symbolRepairAt=0;
int selectedSymbolCursor=0,allSymbolCursor=0;
bool ReadableDisplaySymbol(string symbol)
{
   MqlTick tick;
   return symbol!="" && SymbolInfoTick(symbol,tick) && tick.time>0 && (tick.bid>0 || tick.ask>0 || tick.last>0);
}
bool RepairDisplaySymbol()
{
   // Reporting uses account data and the timer, never waits for a chart tick.
   if(ReadableDisplaySymbol(ChartSymbol(0)))return false;
   uint now=GetTickCount();if(symbolRepairAt!=0 && now-symbolRepairAt<5000)return false;symbolRepairAt=now;
   int selected=SymbolsTotal(true);
   for(int n=0;n<MathMin(32,selected);n++)
   {
      string symbol=SymbolName(selectedSymbolCursor++%selected,true);
      if(ReadableDisplaySymbol(symbol) && ChartSetSymbolPeriod(0,symbol,PERIOD_M1))
      {Print("MetaFactory display symbol repaired: ",symbol);return true;}
   }
   // Only four new subscriptions per attempt, not a subscription to the whole broker catalogue.
   int all=SymbolsTotal(false);
   for(int n=0;n<MathMin(4,all);n++)
   {
      string symbol=SymbolName(allSymbolCursor++%all,false);
      if(symbol=="")continue;
      if(!SymbolSelect(symbol,true))continue;
      if(ReadableDisplaySymbol(symbol) && ChartSetSymbolPeriod(0,symbol,PERIOD_M1))
      {Print("MetaFactory display symbol repaired: ",symbol);return true;}
   }
   return false;
}
int OnInit()
{
   Print("MetaFactory Live init: data-path=",TerminalInfoString(TERMINAL_DATA_PATH));
   ResetLastError();
   if(!EventSetTimer(1)){InitProblem("timer-create",GetLastError());return INIT_FAILED;}
   // A binding/lock error is not a terminal-fatal OnInit failure. Retry without closing/restarting it.
   BeginLiveSession();retryInitAt=GetTickCount();return INIT_SUCCEEDED;
}
void OnDeinit(const int reason)
{
   EventKillTimer();
   if(sessionOwned && RefreshLease()){WriteSnapshot("stopped");GlobalVariableSetOnCondition(ownerKey,0,ownerId);}
   sessionOwned=false;if(beatKey!="")GlobalVariableDel(beatKey);
}
void OnTimer()
{
   if(!RefreshLease())
   {if(GetTickCount()-retryInitAt>=5000){retryInitAt=GetTickCount();BeginLiveSession();}return;}
   bool active=ExpectedAccount()&&Connected();
   if(!active)
   {wasConnected=false;dirty=true;stableSignature="";liveState=ExpectedAccount()?"disconnected":"identity-mismatch";WriteSnapshot();return;}
   if(RepairDisplaySymbol())return;
   if(!wasConnected){wasConnected=true;dirty=true;backedOff=false;recoveryStarted=GetTickCount();stableSignature="";liveState="bootstrap";AskAllHistory();lastPoll=0;}
   string rows[],key="";
   if(!OpenLines(rows,key)){liveState="error";WriteSnapshot();return;}
   if(liveState=="error")liveState=revision>0&&!dirty?"ready":"history-pending";
   string day=TimeToString(ServerNow(),TIME_DATE);
   string lightSignal=key+"|"+day+"|"+IntegerToString(HistoryCount())+"|"+N(Balance())+"|"+N(Credit());
   if(lightSignal!=previousLightSignal)
   {dirty=true;backedOff=false;recoveryStarted=GetTickCount();previousLightSignal=lightSignal;previousOpenKey=key;previousDay=day;}
   if(dirty && liveState=="ready")liveState="history-pending";
   WriteSnapshot();
   if(dirty || GetTickCount()-lastHistoryCheck>=reconcileInterval)
   {long before=revision;string beforeState=liveState;PollHistory();if(revision!=before || liveState!=beforeState)WriteSnapshot();}
}
