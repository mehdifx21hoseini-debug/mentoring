"""Read-only, single-request MetaTrader IPC check. Credentials only arrive on stdin."""
import json
import sys


def readable_symbol(request, api):
    """Query only the freshly authenticated account; never submit trading operations.

    Last valid quotes are acceptable over market closures. The caller imposes the
    process-wide deadline, including any blocking native history call.
    """
    import math
    import time

    def positive(value):
        try:
            return math.isfinite(float(value)) and float(value) > 0
        except (ValueError, TypeError):
            return False

    def safe_name(name):
        return (isinstance(name, str) and 0 < len(name) <= 40
                and not any(ord(c) < 32 or 127 <= ord(c) <= 159 or c in '<>' for c in name))

    symbols = api.symbols_get() or ()
    catalogue_deadline = time.monotonic() + 3
    while not symbols and time.monotonic() < catalogue_deadline:
        time.sleep(0.2)
        symbols = api.symbols_get() or ()
    preferred = request.get('preferred')
    hints = request.get('candidates') or []
    hints = [n for n in hints if safe_name(n)][:200]
    priorities = {name: i for i, name in enumerate(hints)}
    if safe_name(preferred):
        priorities.setdefault(preferred, len(priorities))
    stats = dict(catalogue_count=len(symbols), attempted=0, no_quote=0, no_bars=0, bad_bars=0, disabled=0)
    stats['disabled'] = sum(getattr(s, 'trade_mode', 0) == api.SYMBOL_TRADE_MODE_DISABLED for s in symbols)
    symbols = sorted((s for s in symbols if safe_name(s.name)
                      and getattr(s, 'trade_mode', 0) != api.SYMBOL_TRADE_MODE_DISABLED),
                     key=lambda s: (priorities.get(s.name, 1000),
                                    not (positive(getattr(s, 'bid', 0)) and positive(getattr(s, 'ask', 0))),
                                    not getattr(s, 'select', False),
                                    not bool(getattr(s, 'currency_base', '')), s.name))
    tried = set()
    for info in symbols:
        if info.name in tried:
            continue
        if len(tried) >= 64:
            break
        tried.add(info.name)
        stats['attempted'] += 1
        try:
            if not api.symbol_select(info.name, True):
                stats['no_quote'] += 1
                continue
            tick = api.symbol_info_tick(info.name)
            if (not tick or not positive(tick.bid) or not positive(tick.ask)
                    or not 0 <= time.time() - tick.time <= 7 * 86400):
                stats['no_quote'] += 1
                continue
            bars = api.copy_rates_from_pos(info.name, api.TIMEFRAME_M1, 0, 2)
            if bars is None or len(bars) == 0:
                stats['no_bars'] += 1
                continue
            last = bars[-1]
            if not positive(last['close']) or not 0 <= time.time() - int(last['time']) <= 7 * 86400:
                stats['bad_bars'] += 1
                continue
            stats.update(symbol_status='ready', symbol=info.name, bar_count=len(bars),
                         last_close=float(last['close']), bid=float(tick.bid), ask=float(tick.ask), tick_time=int(tick.time))
            return stats
        except Exception:
            stats['no_bars'] += 1
    stats['symbol_status'] = 'unavailable'
    return stats


def check(request, api):
    reply = {key: request[key] for key in ('token', 'login', 'server')}
    reply.update(state='unconfirmed', reason='No conclusive connection response.')
    try:
        timeout = max(1000, min(60000, int(request['timeout'])))
        init_args = dict(portable=True, timeout=timeout)
        if request.get('action') == 'symbols':
            # Authenticate from the first SDK connection. Starting an anonymous
            # terminal first can display the account-creation wizard and block IPC.
            init_args.update(login=int(request['login']), password=request['password'], server=request['server'])
        if not api.initialize(request['terminal'], **init_args):
            reply['reason'] = 'Could not initialize the private MetaTrader terminal.'
            return reply
        # A fresh explicit acknowledgement is mandatory; cached account_info alone is insufficient.
        if not api.login(int(request['login']), password=request['password'], server=request['server'], timeout=timeout):
            error = api.last_error()
            reply['state'] = 'rejected' if error and error[0] == -6 else 'unconfirmed'
            reply['reason'] = 'Account/password rejected.' if reply['state'] == 'rejected' else 'Broker connection was not confirmed.'
            return reply
        account = api.account_info()
        terminal = api.terminal_info()
        if (account and terminal and terminal.connected
                and int(account.login) == int(request['login'])
                and str(account.server).strip().casefold() == request['server'].strip().casefold()):
            reply.update(state='connected', reason='Fresh login acknowledged by MetaTrader IPC.')
            if request.get('action') == 'symbols':
                reply.update(readable_symbol(request, api))
        else:
            reply['reason'] = 'The connected account or server did not match the request.'
        return reply
    except Exception:
        reply['reason'] = 'MetaTrader IPC check could not be completed.'
        return reply
    finally:
        try:
            api.shutdown()
        except Exception:
            pass


def serve(input_stream, output_stream, api=None, persistent=False):
    if api is None:
        try:
            import MetaTrader5 as api
        except Exception:
            api = None
    for raw in input_stream:
        request = json.loads(raw)
        if api is None:
            response = {key: request[key] for key in ('token', 'login', 'server')}
            response.update(state='unavailable', reason='The bundled Windows 64-bit MetaTrader IPC runtime could not load.')
        else:
            response = check(request, api)
        print(json.dumps(response), file=output_stream, flush=True)
        if not persistent:
            break


def main():
    serve(sys.stdin, sys.stdout, persistent='--serve' in sys.argv[1:])


if __name__ == '__main__':
    main()
