#property strict
// Read-only login probe: no trading, DLL imports, history downloads or market ticks required.
input string ExpectedLogin="";
input string ExpectedServer="";
input string Token="";
input string OutFile="";
void OnStart()
{
   if(StringLen(Token)!=32 || StringLen(OutFile)==0) return;
   string expected=ExpectedServer;
   StringToLower(expected);
   uint began=GetTickCount();
   while(!IsStopped() && GetTickCount()-began<60000)
   {
      string server=AccountServer();
      string compared=server;
      StringToLower(compared);
      if(IsConnected() && (long)AccountNumber()==StringToInteger(ExpectedLogin) && compared==expected)
      {
         int file=FileOpen(OutFile,FILE_WRITE|FILE_TXT|FILE_UNICODE);
         if(file!=INVALID_HANDLE)
         {
            FileWriteString(file,"MTMLOGIN\t1\t"+Token+"\t"+IntegerToString(AccountNumber())+"\t"+server+"\tconnected\r\n");
            FileFlush(file);
            FileClose(file);
         }
         return;
      }
      Sleep(100);
   }
}
