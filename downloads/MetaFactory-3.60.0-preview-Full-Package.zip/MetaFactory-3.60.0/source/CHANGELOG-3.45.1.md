# MetaFactory 3.45.1

- Shorten the drawdown line in daily, selected-account, copied/saved and scheduled text reports to “Overall DD: <percentage>” / «دراودان کلی: <درصد>».
- Use the same concise title in the report card; remove its explanatory subtitle.
- Keep the calculation basis in the existing hover explanation. Unknown values stay unknown.
- No drawdown calculation, native reporter, history retrieval or terminal concurrency changes.

Validation:1944 existing checks passed,0 failed; one existing Python-dependent chart test skipped. Assembly/PE versions and embedded installer payload verified. Native sources identical to3.45.0.
