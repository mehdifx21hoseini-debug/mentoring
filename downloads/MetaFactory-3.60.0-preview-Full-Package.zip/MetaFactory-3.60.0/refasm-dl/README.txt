Download Microsoft.NETFramework.ReferenceAssemblies.net45 1.0.3 from NuGet into x45/. Build source/build.sh with Mono mcs and llvm-rc. Broker terminals and MetaEditor are not bundled.
