using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace MTManager
{
    // ================================================================== text files MetaTrader writes

    public static class TextFiles
    {
        /// <summary>The text of a file the terminal may be writing at this moment; null when missing or unreadable.</summary>
        public static string ReadText(string path)
        {
            try
            {
                if (!File.Exists(path)) return null;
                using (var f = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                {
                    var b = new byte[f.Length];
                    int read = 0;
                    while (read < b.Length)
                    {
                        int n = f.Read(b, read, b.Length - read);
                        if (n <= 0) break;
                        read += n;
                    }
                    return Decode(b);
                }
            }
            catch { return null; }
        }

        /// <summary>MetaTrader writes Unicode text files as UTF-16, with or without a byte-order mark.</summary>
        public static string Decode(byte[] b)
        {
            int skip;
            return Detect(b, out skip).GetString(b, skip, b.Length - skip);
        }

        /// <summary>How a file is written: UTF-16 (with or without its mark), UTF-8 with its mark, or one byte per character.
        /// The last is read as Latin-1, which gives every byte back unchanged when the text is written again.</summary>
        public static Encoding Detect(byte[] b, out int skip)
        {
            skip = 0;
            if (b.Length >= 2 && b[0] == 0xFF && b[1] == 0xFE) { skip = 2; return Encoding.Unicode; }
            if (b.Length >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF) { skip = 3; return Encoding.UTF8; }
            if (b.Length >= 2 && b[0] != 0 && b[1] == 0) return Encoding.Unicode;
            return Bytes;
        }

        /// <summary>Latin-1: one character per byte, both ways.</summary>
        public static readonly Encoding Bytes = Encoding.GetEncoding(28591);

        /// <summary>Text read with Detect, back to bytes the same way (with the same mark, if it had one).</summary>
        public static byte[] Encode(string text, byte[] original)
        {
            int skip;
            Encoding enc = Detect(original, out skip);
            byte[] body = enc.GetBytes(text);
            var all = new byte[skip + body.Length];
            Array.Copy(original, all, skip);
            Array.Copy(body, 0, all, skip, body.Length);
            return all;
        }
    }

    // ================================================================== 3.19.2: Gregorian dates for the trade report

    /// <summary>The trade report's and statements' dates are Gregorian, as MetaTrader writes them: "2026.11.07" (and "2026-11-07" in a
    /// file name); short labels name the month in Persian ("۷ نوامبر"). The program's own windows keep the Persian calendar (Fa).</summary>
    public static class Gd
    {
        static string[] Months { get { return new[] { Lang.T("ژانویه", "January"), Lang.T("فوریه", "February"), Lang.T("مارس", "March"), Lang.T("آوریل", "April"), Lang.T("مه", "May"), Lang.T("ژوئن", "June"), Lang.T("ژوئیه", "July"), Lang.T("اوت", "August"), Lang.T("سپتامبر", "September"), Lang.T("اکتبر", "October"), Lang.T("نوامبر", "November"), Lang.T("دسامبر", "December") }; } }
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        public static string Date(DateTime d) { return d.Year < 1900 ? "—" : d.ToString("yyyy.MM.dd", Inv); }

        public static string At(DateTime d) { return d.Year < 1900 ? "—" : d.ToString("yyyy.MM.dd HH:mm", Inv); }

        /// <summary>For a file name: "2026-11-07".</summary>
        public static string File(DateTime d) { return d.ToString("yyyy-MM-dd", Inv); }

        /// <summary>"۷ نوامبر".</summary>
        public static string DayMonth(DateTime d) { return Fa.N(d.Day) + " " + Months[d.Month - 1]; }

        /// <summary>"نوامبر ۲۰۲۶".</summary>
        public static string Month(DateTime d) { return Months[d.Month - 1] + " " + Fa.N(d.Year); }

        /// <summary>"2026.11.07", "2026-11-7" or "2026/11/07", in Latin or Persian digits; null when it is not a Gregorian date
        /// (a Persian year such as 1405 is not taken for one).</summary>
        public static DateTime? Parse(string text)
        {
            string s = TextUtil.LatinDigits((text ?? "").Trim()).Replace('-', '/').Replace('.', '/');
            string[] p = s.Split('/');
            int y, m, dd;
            if (p.Length != 3 || !int.TryParse(p[0], out y) || !int.TryParse(p[1], out m) || !int.TryParse(p[2], out dd)) return null;
            if (y < 1990 || y > 2100 || m < 1 || m > 12 || dd < 1 || dd > DateTime.DaysInMonth(y, m)) return null;
            return new DateTime(y, m, dd);
        }
    }

    // ================================================================== Persian text for dates and numbers

    public static class Fa
    {
        static string[] Months { get { return new[] { Lang.T("فروردین", "Farvardin"), Lang.T("اردیبهشت", "Ordibehesht"), Lang.T("خرداد", "Khordad"), Lang.T("تیر", "Tir"), Lang.T("مرداد", "Mordad"), Lang.T("شهریور", "Shahrivar"), Lang.T("مهر", "Mehr"), Lang.T("آبان", "Aban"), Lang.T("آذر", "Azar"), Lang.T("دی", "Dey"), Lang.T("بهمن", "Bahman"), Lang.T("اسفند", "Esfand") }; } }
        static readonly PersianCalendar Pc = new PersianCalendar();
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        public static string N(long n) { return TextUtil.PersianDigits(n.ToString(Inv)); }

        public static string Month(int year, int month) { return Months[Math.Max(1, Math.Min(12, month)) - 1] + " " + N(year); }

        public static string Date(DateTime d)
        {
            if (d.Year < 1900) return "—";
            // 3.27: English: the Gregorian date, as everywhere else in the program.
            if (Lang.En) return d.ToString("yyyy.MM.dd", Inv);
            return N(Pc.GetDayOfMonth(d)) + " " + Months[Pc.GetMonth(d) - 1] + " " + N(Pc.GetYear(d));
        }

        public static string At(DateTime d)
        {
            if (d.Year < 1900) return "—";
            return Date(d) + Lang.T("، ", ", ") + TextUtil.PersianDigits(d.ToString("HH:mm", Inv));
        }

        /// <summary>"همین حالا", "۴۰ ثانیه پیش", "۳ دقیقه پیش", …</summary>
        public static string Ago(DateTime then, DateTime now)
        {
            if (then.Year < 1900) return "—";
            TimeSpan d = now - then;
            if (d.TotalSeconds < 10) return Lang.T("همین حالا", "Just now");
            if (d.TotalSeconds < 60) return N((long)d.TotalSeconds) + Lang.T(" ثانیه پیش", " s ago");
            if (d.TotalMinutes < 60) return N((long)d.TotalMinutes) + Lang.T(" دقیقه پیش", " min ago");
            if (d.TotalHours < 24) return N((long)d.TotalHours) + Lang.T(" ساعت پیش", " h ago");
            return N((long)d.TotalDays) + Lang.T(" روز پیش", " d ago");
        }

        public static string Span(TimeSpan d)
        {
            if (d.TotalMinutes < 1) return N((long)Math.Max(0, d.TotalSeconds)) + Lang.T(" ثانیه", " seconds");
            if (d.TotalHours < 1) return N((long)d.TotalMinutes) + Lang.T(" دقیقه", " min");
            if (d.TotalDays < 1) return N((long)d.TotalHours) + Lang.T(" ساعت", " h");
            return N((long)d.TotalDays) + Lang.T(" روز", " d");
        }

        /// <summary>Money with Latin digits and thousands separators, the way traders read it in MetaTrader.</summary>
        public static string Money(double v) { return v.ToString("#,##0.00", Inv); }

        public static string Signed(double v) { return (v > 0 ? "+" : "") + Money(v); }

        public static string Lots(double v) { return v.ToString("0.##", Inv) + Lang.T(" لات", " lots"); }

        public static string Pct(double v) { return v.ToString("0.#", Inv) + Lang.T("٪", "%"); }
    }

    // ================================================================== charts: a light start for investor copies

    /// <summary>The copy's chart profile: kept to one chart for investor copies and copies without an account,
    /// the rest saved aside in the copy and restorable. Every chart is a group of windows, and Windows has room for only so many at once.</summary>
    public static class ChartProfile
    {
        static string[] Roots(Instance i)
        {
            // Current MT5 keeps profiles under MQL5\Profiles; some installs also carry an older Profiles folder at the top.
            return i.Kind == Kind.MT5
                ? new[] { Path.Combine(i.Dir, "MQL5", "Profiles", "Charts"), Path.Combine(i.Dir, "Profiles", "Charts") }
                : new[] { Path.Combine(i.Dir, "profiles") };
        }

        /// <summary>The Default profile folder: the one that has charts, the current MT5 place first.</summary>
        public static string DefaultDir(Instance i)
        {
            string[] dirs = Roots(i).Select(r => Path.Combine(r, i.Kind == Kind.MT5 ? "Default" : "default")).ToArray();
            return dirs.FirstOrDefault(d => Charts(d).Length > 0) ?? dirs.FirstOrDefault(Directory.Exists) ?? dirs[0];
        }

        public static string BackupDir(Instance i) { return Path.Combine(i.Dir, "MTManager-backup", "charts"); }

        static string[] Charts(string dir)
        {
            try { return Directory.Exists(dir) ? Directory.GetFiles(dir, "*.chr").OrderBy(f => f, StringComparer.OrdinalIgnoreCase).ToArray() : new string[0]; }
            catch { return new string[0]; }
        }

        /// <summary>Every saved chart of the copy: those of each profile and those set aside.</summary>
        public static List<string> AllCharts(Instance i)
        {
            var list = new List<string>();
            foreach (string root in Roots(i))
            {
                try
                {
                    if (!Directory.Exists(root)) continue;
                    foreach (string dir in Directory.GetDirectories(root)) list.AddRange(Charts(dir));
                }
                catch { }
            }
            list.AddRange(Charts(BackupDir(i)));
            return list;
        }

        static string Free(string dir, string name)
        {
            string dest = Path.Combine(dir, name);
            for (int n = 1; File.Exists(dest); n++) dest = Path.Combine(dir, Path.GetFileNameWithoutExtension(name) + "-" + n + ".chr");
            return dest;
        }

        /// <summary>The profile without any chart that investor copies open with (3.17): the terminal loads no chart at all.</summary>
        public const string EmptyName = "Empty";

        static string MainRoot(Instance i) { return Roots(i)[0]; }

        static string Mt4LastProfile(Instance i) { return Path.Combine(i.Dir, "profiles", "lastprofile.ini"); }

        /// <summary>Makes the copy open with no chart: an empty profile beside its own (whose charts stay as they are).
        /// MT5 is told by the start file (ProfileLast); MT4 keeps the name of the profile to open in profiles\lastprofile.ini.
        /// A chart the terminal saved into the empty profile is set aside; in a report copy (discard, 3.19) it is the script's chart
        /// of the last run, the program's own, and is dropped so nothing piles up.</summary>
        public static void UseEmpty(Instance i, bool discard = false)
        {
            string dir = Path.Combine(MainRoot(i), EmptyName);
            Directory.CreateDirectory(dir);
            foreach (string chart in Charts(dir))
            {
                if (discard) File.Delete(chart);
                else
                {
                    string backup = Path.Combine(i.Dir, "MTManager-backup", "charts");
                    Directory.CreateDirectory(backup);
                    File.Move(chart, Free(backup, Path.GetFileName(chart)));
                }
            }
            if (i.Kind == Kind.MT4)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(Mt4LastProfile(i)));
                File.WriteAllText(Mt4LastProfile(i), EmptyName, Encoding.ASCII);
            }
        }

        /// <summary>Back to the copy's own profile after it was opened empty; true when it had been (MT5 then needs ProfileLast=Default).</summary>
        public static bool LeaveEmpty(Instance i)
        {
            bool used = Directory.Exists(Path.Combine(MainRoot(i), EmptyName));
            if (i.Kind == Kind.MT4)
            {
                string last = Mt4LastProfile(i);
                try
                {
                    if (File.Exists(last) && string.Equals(File.ReadAllText(last).Trim(), EmptyName, StringComparison.OrdinalIgnoreCase))
                        File.WriteAllText(last, "default", Encoding.ASCII);
                }
                catch (Exception e) { Log.Write("profile of " + i.Name + ": " + e.Message); }
            }
            return used;
        }

        /// <summary>Keeps one chart; the others go to MTManager-backup in the copy, never overwriting.
        /// A profile left without any chart gets one of those set aside back, so the terminal never opens empty.</summary>
        public static void MakeLight(Instance i)
        {
            string[] charts = Charts(DefaultDir(i));
            if (charts.Length == 0) { RestoreOne(i); return; }
            if (charts.Length == 1) return;
            string kept = charts[0];
            string backup = BackupDir(i);
            Directory.CreateDirectory(backup);
            int moved = 0;
            foreach (string f in charts.Skip(1))
            {
                try
                {
                    File.Move(f, Free(backup, Path.GetFileName(f)));
                    moved++;
                }
                catch (Exception e) { Log.Write("light profile " + i.Name + ": " + e.Message); }
            }
            Log.Write("light profile for " + i.Name + ": kept " + Path.GetFileName(kept) + ", set aside " + moved);
        }

        /// <summary>The first chart set aside, back into the Default profile. False when none was set aside.</summary>
        public static bool RestoreOne(Instance i)
        {
            string first = Charts(BackupDir(i)).FirstOrDefault();
            if (first == null) return false;
            string dir = DefaultDir(i);
            try
            {
                Directory.CreateDirectory(dir);
                File.Move(first, Free(dir, Path.GetFileName(first)));
                Log.Write("light profile for " + i.Name + ": it had no chart, " + Path.GetFileName(first) + " came back");
                return true;
            }
            catch (Exception e)
            {
                Log.Write("restore one chart " + i.Name + ": " + e.Message);
                return false;
            }
        }

        /// <summary>Puts the saved charts back, each under a free chartNN name.</summary>
        public static int Restore(Instance i)
        {
            string dir = DefaultDir(i);
            int n = 0;
            foreach (string f in Charts(BackupDir(i)))
            {
                try
                {
                    Directory.CreateDirectory(dir);
                    string dest = Path.Combine(dir, Path.GetFileName(f));
                    for (int k = 1; File.Exists(dest); k++) dest = Path.Combine(dir, "chart" + k.ToString("00", CultureInfo.InvariantCulture) + ".chr");
                    File.Move(f, dest);
                    n++;
                }
                catch (Exception e) { Log.Write("restore charts " + i.Name + ": " + e.Message); }
            }
            return n;
        }
    }

    // ================================================================== the expert of earlier versions, taken out

    /// <summary>Versions before 3.12 put a read-only expert ("MTManagerMonitor") into investor copies, on one of their charts.
    /// It is no longer used. Before such a copy starts, the expert's file and its place on the chart are taken away
    /// (the chart itself stays), so the terminal starts without it. What it wrote (its Files\MTManager folder) is left
    /// for the cleanup tool, where the user decides.</summary>
    public static class OldMonitor
    {
        public const string Name = "MTManagerMonitor";

        public static string Binary(Instance i) { return Path.Combine(i.Dir, Kinds.Mql(i.Kind), "Experts", Name + (i.Kind == Kind.MT5 ? ".ex5" : ".ex4")); }

        public static string DataFolder(Instance i) { return Path.Combine(i.Dir, Kinds.Mql(i.Kind), "Files", "MTManager"); }

        /// <summary>Where the expert was built, under a copies folder.</summary>
        public static string WorkDir(string baseDir) { return Path.Combine(baseDir, "_MTManager", "monitor"); }

        /// <summary>A chart's text without the block that runs this expert ("&lt;expert&gt; name=MTManagerMonitor … &lt;/expert&gt;");
        /// everything else, other experts included, stays exactly as it was.</summary>
        public static string WithoutExpert(string text, out bool changed)
        {
            changed = false;
            var sb = new StringBuilder(text.Length);
            var block = new StringBuilder();
            bool inBlock = false, ours = false;
            int pos = 0;
            while (pos < text.Length)
            {
                int nl = text.IndexOf('\n', pos);
                int end = nl < 0 ? text.Length : nl + 1;
                string line = text.Substring(pos, end - pos);
                string t = line.Trim();
                pos = end;
                if (!inBlock && string.Equals(t, "<expert>", StringComparison.OrdinalIgnoreCase))
                {
                    inBlock = true;
                    ours = false;
                    block.Clear().Append(line);
                    continue;
                }
                if (!inBlock) { sb.Append(line); continue; }
                block.Append(line);
                if (t.StartsWith("name=", StringComparison.OrdinalIgnoreCase) && string.Equals(t.Substring(5).Trim(), Name, StringComparison.OrdinalIgnoreCase)) ours = true;
                if (string.Equals(t, "</expert>", StringComparison.OrdinalIgnoreCase))
                {
                    inBlock = false;
                    if (ours) changed = true; else sb.Append(block);
                }
            }
            if (inBlock) sb.Append(block);  // a block without its end: left as it was
            return sb.ToString();
        }

        /// <summary>Takes the expert out of a copy that is not running. Returns how many files changed.</summary>
        public static int Remove(Instance i)
        {
            int n = 0;
            string bin = Binary(i);
            try
            {
                if (File.Exists(bin)) { File.Delete(bin); n++; }
            }
            catch (Exception e) { Log.Write("old monitor file " + i.Name + ": " + e.Message); }
            foreach (string chr in ChartProfile.AllCharts(i))
            {
                try
                {
                    byte[] b = File.ReadAllBytes(chr);
                    bool changed;
                    string text = WithoutExpert(TextFiles.Decode(b), out changed);
                    if (!changed) continue;
                    File.WriteAllBytes(chr, TextFiles.Encode(text, b));
                    n++;
                }
                catch (Exception e) { Log.Write("old monitor chart " + i.Name + ": " + e.Message); }
            }
            if (n > 0) Log.Write("old monitor taken out of " + i.Name + " (" + n + " files)");
            return n;
        }
    }

    // ================================================================== servers: what this computer knows, and MetaQuotes' public list

    public static class ServerCatalog
    {
        /// <summary>The list MetaTrader's own web terminal uses. Not a documented service: if MetaQuotes changes it,
        /// the program keeps working with the servers it knows locally and the last list it saved.</summary>
        public const string OnlineUrl = "https://metatraderweb.app/trade/servers?version={0}&all=1";
        public const int CacheDays = 7;

        static string CacheFile(Kind k) { return Path.Combine(AppPaths.DataDir, "servers-" + k + ".txt"); }

        public static string Broker(string server)
        {
            server = (server ?? "").Trim();
            int dash = server.LastIndexOf('-');
            return dash > 0 ? server.Substring(0, dash) : server;
        }

        /// <summary>Lower-case letters and digits only, so "WM Markets", "wm-markets" and "WMMarkets" compare equal.</summary>
        public static string Norm(string s)
        {
            var sb = new StringBuilder();
            foreach (char ch in TextUtil.LatinDigits(s ?? "").ToLowerInvariant()) if (char.IsLetterOrDigit(ch)) sb.Append(ch);
            return sb.ToString();
        }

        /// <summary>Servers the MetaTraders on this computer already know: MT4 keeps one .srv file per server;
        /// MT5 keeps a folder per server it has connected to; plus every server already typed into this program.</summary>
        public static List<string> Local(Kind k, Settings s, AccountStore store)
        {
            var names = new List<string>();
            var dirs = new List<string>(Installs.Find(k, s));
            foreach (string d in dirs.ToList())
            {
                string data = Installs.FindDataFolder(d);
                if (data != null) dirs.Add(data);
            }
            dirs.AddRange(Installs.Copies(s).Where(c => c.Kind == k).Select(c => c.Dir));
            foreach (string d in dirs.Distinct(StringComparer.OrdinalIgnoreCase))
            {
                try
                {
                    if (k == Kind.MT4)
                    {
                        string cfg = Path.Combine(d, "config");
                        if (Directory.Exists(cfg)) names.AddRange(Directory.GetFiles(cfg, "*.srv").Select(Path.GetFileNameWithoutExtension));
                    }
                    else
                    {
                        string bases = Path.Combine(d, "Bases");
                        if (Directory.Exists(bases))
                            names.AddRange(Directory.GetDirectories(bases).Select(Path.GetFileName)
                                .Where(n => n.IndexOf('-') > 0 && !n.Equals("Default", StringComparison.OrdinalIgnoreCase)));
                    }
                }
                catch { }
            }
            if (store != null)
            {
                var kinds = Installs.Copies(s).ToDictionary(c => c.Name, c => c.Kind, StringComparer.OrdinalIgnoreCase);
                foreach (Account a in store.All)
                {
                    Kind ak;
                    if (!string.IsNullOrWhiteSpace(a.Server) && (!kinds.TryGetValue(a.Instance, out ak) || ak == k)) names.Add(a.Server.Trim());
                }
            }
            return names.Where(n => n.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(n => n, StringComparer.OrdinalIgnoreCase).ToList();
        }

        /// <summary>The last list saved from MetaQuotes (empty when never fetched).</summary>
        public static List<string> Online(Kind k)
        {
            try { return File.Exists(CacheFile(k)) ? File.ReadAllLines(CacheFile(k)).Where(l => l.Length > 0).ToList() : new List<string>(); }
            catch { return new List<string>(); }
        }

        public static bool Fresh(Kind k)
        {
            try { return File.Exists(CacheFile(k)) && (DateTime.Now - File.GetLastWriteTime(CacheFile(k))).TotalDays < CacheDays; }
            catch { return false; }
        }

        /// <summary>Downloads the public list (only server names come back; nothing about the user is sent).</summary>
        static readonly object refreshing = new object();

        public static int Refresh(Kind k)
        {
            // One download at a time; a second request for the same list waits and then finds it fresh.
            lock (refreshing)
            {
                if (Fresh(k)) return Online(k).Count;
                return Download(k);
            }
        }

        static int Download(Kind k)
        {
            System.Net.ServicePointManager.SecurityProtocol |= System.Net.SecurityProtocolType.Tls12;
            var req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(string.Format(CultureInfo.InvariantCulture, OnlineUrl, k == Kind.MT5 ? 5 : 4));
            req.Timeout = 20000;
            req.ReadWriteTimeout = 20000;
            req.UserAgent = "MT Manager";
            req.AutomaticDecompression = System.Net.DecompressionMethods.GZip | System.Net.DecompressionMethods.Deflate;
            string json;
            using (var resp = req.GetResponse())
            using (var r = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) json = r.ReadToEnd();
            List<string> list = ParseList(json, k == Kind.MT5 ? "mt5" : "mt4");
            if (list.Count < 10) throw new InvalidOperationException("the list came back empty");
            string temp = CacheFile(k) + ".tmp";
            File.WriteAllLines(temp, list, Encoding.UTF8);
            if (File.Exists(CacheFile(k))) File.Delete(CacheFile(k));
            File.Move(temp, CacheFile(k));
            Log.Write("server list " + k + ": " + list.Count + " servers");
            return list.Count;
        }

        /// <summary>The string array under one key of {"mt5":["A-Live","B-Demo",…]}.</summary>
        public static List<string> ParseList(string json, string key)
        {
            var list = new List<string>();
            int at = json.IndexOf("\"" + key + "\"", StringComparison.Ordinal);
            if (at < 0) return list;
            int open = json.IndexOf('[', at), close = open < 0 ? -1 : json.IndexOf(']', open);
            if (open < 0 || close < 0) return list;
            string body = json.Substring(open + 1, close - open - 1);
            foreach (System.Text.RegularExpressions.Match m in System.Text.RegularExpressions.Regex.Matches(body, "\"((?:[^\"\\\\]|\\\\.)*)\""))
            {
                string v = System.Text.RegularExpressions.Regex.Unescape(m.Groups[1].Value).Trim();
                if (v.Length > 0) list.Add(v);
            }
            return list.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        /// <summary>Servers whose name contains what was typed, ignoring case, spaces and dashes; starting matches first.</summary>
        public static List<string> Search(IEnumerable<string> all, string query, int max = 300)
        {
            string q = Norm(query);
            IEnumerable<string> items = all.Distinct(StringComparer.OrdinalIgnoreCase);
            if (q.Length == 0) return items.Take(max).ToList();
            return items.Select(x => new { x, n = Norm(x) }).Where(x => x.n.Contains(q))
                .OrderBy(x => x.n.StartsWith(q) ? 0 : 1).ThenBy(x => x.x, StringComparer.OrdinalIgnoreCase)
                .Take(max).Select(x => x.x).ToList();
        }

        /// <summary>The installed MetaTrader of this server's broker: its copies carry the broker's servers.
        /// Falls back to any installed one of the kind (sure = false).</summary>
        public static string InstallFor(Kind k, string server, Settings s, out bool sure)
        {
            sure = false;
            List<string> installs = Installs.Find(k, s);
            if (installs.Count == 0) return null;
            if (k == Kind.MT4)
                foreach (string d in installs)
                    if (File.Exists(Path.Combine(d, "config", server + ".srv"))) { sure = true; return d; }
            string broker = Norm(Broker(server));
            if (broker.Length >= 3)
            {
                foreach (string d in installs)
                {
                    string name = Norm(Path.GetFileName(d.TrimEnd('\\', '/')));
                    if (name.Contains(broker)) { sure = true; return d; }
                }
                foreach (string d in installs)
                {
                    string data = Installs.FindDataFolder(d);
                    foreach (string root in new[] { d, data })
                    {
                        if (root == null) continue;
                        string bases = Path.Combine(root, "Bases");
                        try
                        {
                            if (Directory.Exists(bases) && Directory.GetDirectories(bases).Any(x => Norm(Broker(Path.GetFileName(x))) == broker)) { sure = true; return d; }
                        }
                        catch { }
                    }
                }
            }
            return installs[0];
        }
    }

    // ================================================================== did the terminal log in?

    public enum Login { Waiting, Connected, WrongLogin, NoServer, NoConnection }

    public sealed class LoginResult
    {
        public Login State;
        public string Detail = "";
    }

    /// <summary>MetaTrader closing itself to put a new build in place (its LiveUpdate), as its journal tells it:
    /// "LiveUpdate: updater - started for portable", "... try to close terminal", "... elevated updater start failed".
    /// A download alone ("LiveUpdate 'mt5clwide64' downloaded") does not close anything and does not count.
    /// 3.27.3: newer MT5 builds write instead: LiveUpdate start "...\liveupdate\terminal64.exe" /update /path:"..." /portable.</summary>
    public static class SelfUpdate
    {
        public static bool InLines(IEnumerable<string> lines)
        {
            foreach (string line in lines)
            {
                int k = line.IndexOf("LiveUpdate", StringComparison.OrdinalIgnoreCase);
                if (k < 0) continue;
                string rest = line.Substring(k + "LiveUpdate".Length).ToLowerInvariant();
                if (rest.Contains("updater") || rest.Contains("close terminal") || rest.Contains("restart") || rest.Contains(" /update")) return true;
            }
            return false;
        }

        /// <summary>Whether the copy's journal shows such an update since the given time.</summary>
        public static bool Since(Instance i, DateTime since)
        {
            try { return InLines(ConnectionCheck.JournalSince(i, since)); }
            catch { return false; }
        }
    }

    /// <summary>Reads what the terminal itself reports in its journal (logs\yyyyMMdd.log).</summary>
    public static class ConnectionCheck
    {
        public static string JournalFile(Instance i, DateTime day) { return Path.Combine(i.Dir, "logs", day.ToString("yyyyMMdd", CultureInfo.InvariantCulture) + ".log"); }

        /// <summary>Journal lines written since the given time (the journal stores the time of day only).</summary>
        public static List<string> JournalSince(Instance i, DateTime since) { return JournalSince(i, since, DateTime.Now); }

        public static List<string> JournalSince(Instance i, DateTime since, DateTime now)
        {
            var list = new List<string>();
            // A check that runs past midnight continues in the next day's journal.
            for (DateTime day = since.Date; day <= now.Date; day = day.AddDays(1))
            {
                string text = TextFiles.ReadText(JournalFile(i, day));
                if (text == null) continue;
                list.AddRange(After(text.Split('\n'), day == since.Date ? since.TimeOfDay.Subtract(TimeSpan.FromSeconds(2)) : TimeSpan.Zero));
            }
            return list;
        }

        /// <summary>The journal lines written since a time, read from the end of the file only (the last bytes):
        /// quick enough to look every second while a terminal starts.</summary>
        public static List<string> JournalTail(Instance i, DateTime since, int maxBytes = 64 * 1024)
        {
            var list = new List<string>();
            for (DateTime day = since.Date; day <= DateTime.Now.Date; day = day.AddDays(1))
            {
                string path = JournalFile(i, day);
                try
                {
                    if (!File.Exists(path)) continue;
                    using (var f = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                    {
                        var head = new byte[2];
                        int got = f.Read(head, 0, 2);
                        bool wide = got == 2 && ((head[0] == 0xFF && head[1] == 0xFE) || (head[0] != 0 && head[1] == 0));
                        long start = Math.Max(got == 2 && head[0] == 0xFF && head[1] == 0xFE ? 2 : 0, f.Length - maxBytes);
                        if (wide && start % 2 == 1) start++;
                        f.Seek(start, SeekOrigin.Begin);
                        var b = new byte[f.Length - start];
                        int read = 0;
                        while (read < b.Length) { int n = f.Read(b, read, b.Length - read); if (n <= 0) break; read += n; }
                        string text = (wide ? Encoding.Unicode : TextFiles.Bytes).GetString(b, 0, wide ? read - read % 2 : read);
                        string[] lines = text.Split('\n');
                        // The first line may be cut in the middle when the end only was read.
                        IEnumerable<string> whole = start > 2 ? lines.Skip(1) : lines;
                        list.AddRange(After(whole, day == since.Date ? since.TimeOfDay.Subtract(TimeSpan.FromSeconds(2)) : TimeSpan.Zero));
                    }
                }
                catch { }
            }
            return list;
        }

        static readonly System.Text.RegularExpressions.Regex ClockTime = new System.Text.RegularExpressions.Regex(@"(?<![0-9])([0-9]{2}):([0-9]{2}):([0-9]{2})");

        /// <summary>The journal lines stamped at or after a time of day (the journal stores the time of day only).</summary>
        public static IEnumerable<string> After(IEnumerable<string> lines, TimeSpan from)
        {
            foreach (string raw in lines)
            {
                string line = raw.TrimEnd('\r');
                System.Text.RegularExpressions.Match m = ClockTime.Match(line);
                if (!m.Success) continue;
                var t = new TimeSpan(int.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture), int.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture), int.Parse(m.Groups[3].Value, CultureInfo.InvariantCulture));
                if (t >= from) yield return line;
            }
        }

        /// <summary>The login outcome found in journal lines, newest wins; Waiting when nothing decisive yet.</summary>
        public static LoginResult FromJournal(IEnumerable<string> lines, string login)
        {
            var r = new LoginResult { State = Login.Waiting };
            foreach (string line in lines)
            {
                string l = line.ToLowerInvariant();
                string number = TextUtil.LatinDigits((login ?? "").Trim()).TrimStart('0');
                bool ours = number.Length == 0 || System.Text.RegularExpressions.Regex.IsMatch(l, @"(?<![0-9])0*" + System.Text.RegularExpressions.Regex.Escape(number) + @"(?![0-9])");
                var owner = System.Text.RegularExpressions.Regex.Match(l, "[\"']([0-9]+)[\"']\\s*:");
                if (owner.Success && number.Length > 0 && owner.Groups[1].Value.TrimStart('0') != number) continue;
                if (!ours && !l.Contains("server")) continue;
                // Order matters: "authorization on X failed (No connection)" is a network problem, not a wrong password.
                if (l.Contains("invalid account") || l.Contains("invalid password") || l.Contains("account disabled"))
                    r = new LoginResult { State = Login.WrongLogin, Detail = line.Trim() };
                else if (l.Contains("not found") || l.Contains("invalid server") || l.Contains("unknown server"))
                    r = new LoginResult { State = Login.NoServer, Detail = line.Trim() };
                else if (l.Contains("no connection") || l.Contains("connection failed") || l.Contains("common error") || l.Contains("timeout") ||
                         (ours && l.Contains("connection") && l.Contains("lost")))
                    r = new LoginResult { State = Login.NoConnection, Detail = line.Trim() };
                else if (ours && (l.Contains("authoriz") || l.Contains("authoris") || l.Contains("login")) && l.Contains("failed"))
                    r = new LoginResult { State = Login.WrongLogin, Detail = line.Trim() };
                else if (ours && System.Text.RegularExpressions.Regex.IsMatch(l, @"\b(?:authori[sz]ed\s+on|login(?:\s+datacenter)?\s+on|logged\s+in|login\s+succeeded)\b"))
                    r = new LoginResult { State = Login.Connected, Detail = line.Trim() };
            }
            return r;
        }

        /// <summary>The login outcome since a time, from the terminal's own journal.</summary>
        public static LoginResult Probe(Instance i, Account acc, DateTime since)
        {
            return FromJournal(JournalSince(i, since), acc != null ? acc.Login : "");
        }
    }

    // ================================================================== 3.22.4: why a terminal closed right after it started

    public enum EarlyKind { Unknown, WrongLogin, NoServer, NoConnection, Config, Updated, LoggedIn }

    /// <summary>What a terminal's own journal says about why it closed right after it started.</summary>
    public sealed class EarlyReason
    {
        public EarlyKind Kind;
        /// <summary>The journal line that tells it (empty when nothing did).</summary>
        public string Line = "";
        /// <summary>The last journal lines of that start, for «بررسی سیستم».</summary>
        public List<string> Tail = new List<string>();

        /// <summary>On the row, after «باز نشد»/«بسته شد».</summary>
        public string Short
        {
            get
            {
                switch (Kind)
                {
                    case EarlyKind.WrongLogin: return Lang.T("رمز یا حساب اشتباه", "Wrong login");
                    case EarlyKind.NoServer: return Lang.T("سرور پیدا نشد", "Server not found");
                    case EarlyKind.NoConnection: return Lang.T("بدون اتصال", "No connection");
                    case EarlyKind.Config: return Lang.T("باز نشد: فایل شروع", "Did not open: start file");
                    case EarlyKind.Updated: return Lang.T("بسته شد: به‌روزرسانی", "Closed: update");
                    case EarlyKind.LoggedIn: return Lang.T("وارد شد، بسته شد", "Signed in, then closed");
                    default: return Lang.T("باز نشد", "Did not open");
                }
            }
        }

        /// <summary>In plain words, with what to do.</summary>
        public string Text
        {
            get
            {
                switch (Kind)
                {
                    case EarlyKind.WrongLogin: return Lang.T("سرور ورود را نپذیرفت: شماره حساب یا رمز اینوستور درست نیست، یا حساب مال متاتریدر دیگری است (۴ به‌جای ۵ یا برعکس). از «⋯» ← «حساب و رمز…» درستش کنید.", "The server refused the login: the account number or investor password is wrong, or the account belongs to the other MetaTrader (4 instead of 5 or the reverse). Fix it from “⋯” → “Account and password…”.");
                    case EarlyKind.NoServer: return Lang.T("متاتریدر این سرور را نمی‌شناسد. در خود متاتریدر از File ← Open an Account اسم بروکر را جستجو کنید، یا متاتریدرِ همان بروکر را یک بار نصب کنید.", "MetaTrader does not know this server. In MetaTrader itself search the broker's name under File → Open an Account, or install that broker's MetaTrader once.");
                    case EarlyKind.NoConnection: return Lang.T("متاتریدر به سرور وصل نشد: اینترنت این کامپیوتر، یا اسم سرور را بررسی کنید.", "MetaTrader could not reach the server: check this computer's internet or the server name.");
                    case EarlyKind.Config: return Lang.T("متاتریدر فایل شروع (mtm-start.ini) را نخواند. یک بار دیگر از برنامه بازش کنید.", "MetaTrader did not read the start file (mtm-start.ini). Open it once more from the program.");
                    case EarlyKind.Updated: return Lang.T("متاتریدر برای به‌روز کردن خودش بسته شد. اگر ویندوز برای «Client Terminal» اجازه خواست «Yes» بزنید؛ بعد خودش دوباره باز و وصل می‌شود. اگر باز نشد، یک بار دیگر از برنامه بازش کنید.", "MetaTrader closed to update itself. If Windows asks permission for “Client Terminal”, press “Yes”; it then opens and signs in again by itself. If it does not, open it once more from the program.");
                    case EarlyKind.LoggedIn: return Lang.T("حساب وارد شد و بعد متاتریدر بسته شد (با دست، یا خطای خود متاتریدر).", "The account signed in and then MetaTrader closed (by hand, or an error of MetaTrader itself).");
                    default: return Lang.T("متاتریدر در گزارش خودش دلیلی ننوشت. اگر آن را با دست نبستید، از «⋯» ← «بررسی اتصال» دوباره امتحان کنید.", "MetaTrader wrote no reason in its log. If you did not close it by hand, try again from “⋯” → “Check connection”.");
                }
            }
        }

        /// <summary>For the program's log.</summary>
        public string En
        {
            get
            {
                string k = Kind == EarlyKind.Unknown ? "nothing in its journal says why" : Kind == EarlyKind.WrongLogin ? "wrong account or investor password"
                         : Kind == EarlyKind.NoServer ? "server not known" : Kind == EarlyKind.NoConnection ? "no connection to the server"
                         : Kind == EarlyKind.Config ? "start file not read" : Kind == EarlyKind.Updated ? "it updated itself" : "logged in, then closed";
                return k + (Line.Length > 0 ? " (journal: " + Line + ")" : "");
            }
        }
    }

    public static class EarlyClose
    {
        /// <summary>The reason in journal lines of one start (oldest first): a refused login or an unknown server first, then MetaTrader's
        /// own update, no connection, a start file not read, and last a login that worked.</summary>
        public static EarlyReason Explain(IList<string> lines, string login)
        {
            lines = lines ?? new List<string>();
            var r = new EarlyReason { Tail = lines.Skip(Math.Max(0, lines.Count - 12)).Select(x => TextUtil.OneLine(x)).Where(x => x.Length > 0).ToList() };
            LoginResult l = ConnectionCheck.FromJournal(lines, login);
            Func<Func<string, bool>, string> last = test => lines.LastOrDefault(x => test(x.ToLowerInvariant()));
            string update = last(x => x.Contains("liveupdate") && (x.Contains("close terminal") || x.Contains("updater") || x.Contains("downloaded") || x.Contains(" /update")));
            string config = last(x => x.Contains("cannot load config") || x.Contains("config") && x.Contains("not found"));
            if (l.State == Login.WrongLogin) { r.Kind = EarlyKind.WrongLogin; r.Line = l.Detail; }
            else if (l.State == Login.NoServer) { r.Kind = EarlyKind.NoServer; r.Line = l.Detail; }
            else if (update != null) { r.Kind = EarlyKind.Updated; r.Line = update; }
            else if (l.State == Login.NoConnection) { r.Kind = EarlyKind.NoConnection; r.Line = l.Detail; }
            else if (config != null) { r.Kind = EarlyKind.Config; r.Line = config; }
            else if (l.State == Login.Connected) { r.Kind = EarlyKind.LoggedIn; r.Line = l.Detail; }
            r.Line = TextUtil.OneLine(r.Line ?? "");
            if (r.Line.Length > 200) r.Line = r.Line.Substring(0, 200) + "…";
            return r;
        }

        /// <summary>From a copy's journal since it was started.</summary>
        public static EarlyReason Of(Instance i, Account a, DateTime since)
        {
            return Explain(ConnectionCheck.JournalTail(i, since), a != null ? a.Login : "");
        }
    }

    /// <summary>Follows a running terminal's journal as it grows and keeps the latest login outcome.
    /// Only what was added since the last look is read, so many copies can be followed every few seconds.</summary>
    public sealed class LoginWatch
    {
        const int FirstReadMax = 4 * 1024 * 1024;
        string path, carry = "", login;
        long offset;
        Encoding encoding;
        DateTime since;
        bool sessionOnly;
        public bool JournalSeen { get; private set; }
        public string ReadProblem { get; private set; }
        public string ObservedPath { get { return path; } }
        LoginResult authentication = new LoginResult { State = Login.Waiting };

        /// <summary>Capture BEFORE starting this terminal. Only new bytes can confirm this run, regardless of journal clock zone.</summary>
        public void BeginSession(Instance copy, string account, DateTime started)
        {
            login = account; since = started; path = ConnectionCheck.JournalFile(copy, started);
            offset = 0; carry = ""; encoding = null; sessionOnly = true; JournalSeen = false; ReadProblem = null;
            Result = new LoginResult { State = Login.Waiting };
            authentication = new LoginResult { State = Login.Waiting };
            try
            {
                using (var f = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                {
                    var head = new byte[Math.Min(256, (int)Math.Min(int.MaxValue, f.Length))];
                    f.Read(head, 0, head.Length);
                    int skip;
                    encoding = TextFiles.Detect(head, out skip);
                    offset = f.Length;
                    if (offset < 2) { offset = 0; encoding = null; }
                    if (encoding == Encoding.Unicode && offset % 2 == 1) offset--;
                    JournalSeen = true;
                }
            }
            catch (FileNotFoundException) { }
            catch (DirectoryNotFoundException) { }
            catch (Exception e) { sessionOnly = false; ReadProblem = e.GetType().Name; }
        }

        IEnumerable<string> CurrentLines(string text, DateTime now)
        {
            string[] lines = text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            TimeSpan from = now.Date == since.Date ? since.TimeOfDay.Subtract(TimeSpan.FromSeconds(2)) : TimeSpan.Zero;
            return sessionOnly ? lines : ConnectionCheck.After(lines, from);
        }

        void Consume(IEnumerable<string> lines, string account)
        {
            foreach (string line in lines)
            {
                LoginResult next = ConnectionCheck.FromJournal(new[] { line }, account);
                if (next.State == Login.Waiting) continue;
                Result = next;
                if (next.State == Login.Connected || next.State == Login.WrongLogin) authentication = next;
            }
        }

        /// <summary>Only call after the producing process has exited: EOF then completes a final line without a newline.</summary>
        public LoginResult CompleteClosed(Instance copy, string account, DateTime started, DateTime now)
        {
            Update(copy, account, started, now);
            if (carry.Length > 0)
            {
                Consume(CurrentLines(carry, now), account);
                carry = "";
            }
            // A deliberate close can add a disconnect after the successful login. Verify whether this run authenticated,
            // while preserving a later explicit account/password rejection. This is not a live connection indicator.
            return authentication.State != Login.Waiting ? authentication : Result;
        }

        /// <summary>Whether this scoped login attempt authenticated, even if a later transport disconnect was logged.
        /// This is not a live connection indicator. A later explicit rejection or invalid server still wins.</summary>
        public LoginResult AttemptResult { get { return Result.State == Login.NoServer ? Result : authentication.State != Login.Waiting ? authentication : Result; } }

        public LoginResult Result = new LoginResult { State = Login.Waiting };

        public LoginResult Update(Instance i, string login, DateTime since, DateTime now)
        {
            if (login != this.login || since != this.since)
            {
                this.login = login;
                this.since = since;
                path = null;
                sessionOnly = false; JournalSeen = false; ReadProblem = null;
                authentication = new LoginResult { State = Login.Waiting };
                Result = new LoginResult { State = Login.Waiting };
            }
            string file = ConnectionCheck.JournalFile(i, now);
            if (file != path)
            {
                // A new day starts a new journal; the outcome so far stays until the new one says otherwise.
                path = file;
                offset = 0;
                carry = "";
                encoding = null;
            }
            try
            {
                var info = new FileInfo(path);
                if (!info.Exists) { JournalSeen = false; return Result; }
                JournalSeen = true;
                if (info.Length < offset) { offset = 0; carry = ""; encoding = null; }
                if (info.Length == offset) return Result;
                byte[] data;
                using (var f = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                {
                    bool skipped = false;
                    if (offset == 0 && encoding == null)
                    {
                        // The encoding is told by the start of the file.
                        var head = new byte[Math.Min(256, (int)Math.Min(int.MaxValue, f.Length))];
                        int got = f.Read(head, 0, head.Length);
                        if (got < 2 || (got == 2 && head[0] == 0xEF && head[1] == 0xBB)) return Result;
                        int skip;
                        encoding = TextFiles.Detect(head.Take(got).ToArray(), out skip);
                        offset = skip;
                        // A long journal: the login is near its end (the terminal was started not long ago).
                        if (f.Length - offset > FirstReadMax) { offset = f.Length - FirstReadMax; skipped = true; }
                        if (encoding == Encoding.Unicode && offset % 2 == 1) offset++;
                    }
                    f.Seek(offset, SeekOrigin.Begin);
                    long n = f.Length - offset;
                    if (encoding == Encoding.Unicode) n -= n % 2;  // half a character waits for the next look
                    data = new byte[n];
                    int read = 0;
                    while (read < data.Length) { int k = f.Read(data, read, data.Length - read); if (k <= 0) break; read += k; }
                    offset += read;
                    string text = carry + encoding.GetString(data, 0, read);
                    if (skipped) { int first = text.IndexOf('\n'); text = first >= 0 ? text.Substring(first + 1) : ""; }
                    int last = text.LastIndexOfAny(new[] { '\r', '\n' });
                    if (last < 0) { carry = text; return Result; }
                    carry = text.Substring(last + 1);
                    Consume(CurrentLines(text.Substring(0, last), now), login);
                    ReadProblem = null;
                }
            }
            catch (Exception e) { ReadProblem = e.GetType().Name; Log.Write("journal " + i.Name + ": " + e.GetType().Name); }
            return Result;
        }
    }
}
