using System;using System.Collections.Generic;using System.Globalization;using System.IO;using System.Linq;using System.Text;using System.Text.RegularExpressions;using System.Diagnostics;
namespace MTManager
{
    public static class StudentNameLatin
    {
        static readonly Dictionary<string,string> Names=new Dictionary<string,string>(StringComparer.Ordinal){
            {"علی","Ali"},{"رضا","Reza"},{"محمد","Mohammad"},{"حسین","Hossein"},{"حسن","Hasan"},{"مهدی","Mehdi"},{"سارا","Sara"},{"زهرا","Zahra"},{"نازیلا","Nazila"},{"بردیا","Bardia"},{"ملینا","Melina"},{"شیخ","Sheikh"},{"زاده","Zadeh"},{"معالی","Maali"},{"مجلسی","Majlesi"},{"رضایی","Rezaei"},{"عبدالهی","Abdollahi"},{"عبداللهی","Abdollahi"},{"مبینا","Mobina"},{"دشتی","Dashti"},{"جاویدشریفی","Javidsharifi"},{"امیر","Amir"},{"فاطمه","Fatemeh"},{"احمد","Ahmad"},{"رنجبر","Ranjbar"},{"فرهاد","Farhad"},{"طاهره","Tahereh"},{"عزت","Ezzat"}};
        public static bool Persian(string s){return Regex.IsMatch(s??"","[\u0600-\u06ff]");}
        public static string Convert(string text)
        {
            text=TextUtil.OneLine(text??"").Replace('ي','ی').Replace('ك','ک').Replace('\u200c',' ');
            var words=new List<string>();foreach(string word in text.Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries))
            {
                string known;if(Names.TryGetValue(word,out known)){words.Add(known);continue;}if(!Persian(word)){words.Add(word);continue;}
                var b=new StringBuilder();foreach(char c in word){switch(c){case 'ا':case 'آ':b.Append("a");break;case 'ب':b.Append("b");break;case 'پ':b.Append("p");break;case 'ت':case 'ط':b.Append("t");break;case 'ث':case 'س':case 'ص':b.Append("s");break;case 'ج':b.Append("j");break;case 'چ':b.Append("ch");break;case 'ح':case 'ه':case 'ة':b.Append("h");break;case 'خ':b.Append("kh");break;case 'د':b.Append("d");break;case 'ذ':case 'ز':case 'ض':case 'ظ':b.Append("z");break;case 'ر':b.Append("r");break;case 'ژ':b.Append("zh");break;case 'ش':b.Append("sh");break;case 'ع':case 'ء':case 'ئ':case 'أ':case 'إ':b.Append("a");break;case 'غ':case 'ق':b.Append("gh");break;case 'ف':b.Append("f");break;case 'ک':b.Append("k");break;case 'گ':b.Append("g");break;case 'ل':b.Append("l");break;case 'م':b.Append("m");break;case 'ن':b.Append("n");break;case 'و':case 'ؤ':b.Append("o");break;case 'ی':case 'ى':b.Append("i");break;default:if(c<128)b.Append(c);break;}}
                string value=b.ToString();words.Add(value.Length==0?word:char.ToUpperInvariant(value[0])+value.Substring(1));
            }return string.Join(" ",words);
        }
    }
    public static class ImportServerPlan
    {
        public const int MaximumCandidates=5;
        public static string BrokerAlias(string text)
        {
            string n=ServerCatalog.Norm(text);return new[]{"wmmarkets","wmmarket","windsor","windsorbrokers","windsorbroker","windزور","ویندزور","ویندزوربروکر","ویندزوربروکرز","ویندزورمارکت","معتمد","محتمد","معتبر","بروکرمعتبر"}.Contains(n)?"WMMarkets":(text??"").Trim();
        }
        public static bool Ambiguous(string server){return Regex.IsMatch(server??"",@"(?i)-(real|live)$");}
        public static List<string> Candidates(Kind kind,string broker,string type,IEnumerable<string> known,IEnumerable<string> preferred=null)
        {
            broker=BrokerAlias(broker);string key=ServerCatalog.Norm(broker);bool demo=type=="demo";
            Func<string,bool> match=s=>ServerCatalog.Norm(ServerCatalog.Broker(s))==key&&(demo?Regex.IsMatch(s,@"(?i)-demo\d*$"):Regex.IsMatch(s,@"(?i)-(real|live)\d*$"));
            var available=(known??new string[0]).Where(Safe).Where(match).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            // User-approved WMMarkets defaults are candidates only, never connection evidence.
            if(key=="wmmarkets"&&available.Count==0){if(demo)available.Add(kind==Kind.MT4?"WMMarkets-DEMO":"WMMarkets-Demo");else{available.Add(kind==Kind.MT4?"WMMarkets-REAL":"WMMarkets-Real1");foreach(string suffix in new[]{"Real","Real1","Real2","Real3","Real4"})if(!available.Contains("WMMarkets-"+suffix,StringComparer.OrdinalIgnoreCase))available.Add("WMMarkets-"+suffix);}}
            return (preferred??new string[0]).Where(s=>available.Contains(s,StringComparer.OrdinalIgnoreCase)).Concat(available).Distinct(StringComparer.OrdinalIgnoreCase).Take(MaximumCandidates).ToList();
        }
        public static bool Safe(string value){return !string.IsNullOrWhiteSpace(value)&&value.Length<=120&&!value.Any(c=>char.IsControl(c)||c=='|'||c=='/'||c=='\\'||c=='=');}
        static readonly object Gate=new object();
        static string HintFile{get{return Path.Combine(AppPaths.DataDir,"import-server-hints.txt");}}
        public static List<string> Remembered(Kind kind){lock(Gate){try{return File.ReadAllLines(HintFile).Where(s=>s.StartsWith(kind+"\t",StringComparison.Ordinal)).Select(s=>s.Substring(4)).Where(Safe).Take(100).ToList();}catch{return new List<string>();}}}
        public static void Remember(Kind kind,string server){if(!Safe(server))return;lock(Gate){try{var all=File.Exists(HintFile)?File.ReadAllLines(HintFile).Take(199).ToList():new List<string>();string value=kind+"\t"+server;all.RemoveAll(s=>string.Equals(s,value,StringComparison.OrdinalIgnoreCase));all.Insert(0,value);TextUtil.WriteLinesAtomically(HintFile,all);}catch{Log.Write("import server preference could not be saved");}}}
        public static ImportConnection Verify(Account job,IAccountVerifier verifier,int milliseconds,Func<bool> cancel,Action<string> stage)
        {
            var options=(job.ImportServers??"").Split('|').Where(Safe).Distinct(StringComparer.OrdinalIgnoreCase).Take(MaximumCandidates).ToList();
            if(options.Count==0)return verifier.Verify(job,milliseconds,cancel,stage);
            var watch=Stopwatch.StartNew();var attempts=new List<string>();
            foreach(string server in options)
            {
                if(cancel())throw new OperationCanceledException();if(watch.ElapsedMilliseconds>=90000)break;
                Account attempt=job.Snapshot();attempt.Server=server;attempt.ImportServers="";
                stage(Lang.T("بررسی سرور ","Checking server ")+server+" ("+(attempts.Count+1)+"/"+options.Count+")");
                ImportConnection result;
                try{result=verifier.Verify(attempt,Math.Min(15000,(int)(90000-watch.ElapsedMilliseconds)),()=>cancel()||watch.ElapsedMilliseconds>=90000,s=>stage(server+": "+s));}
                catch(OperationCanceledException){if(cancel())throw;break;}
                catch(Exception error){result=new ImportConnection{Reason=Lang.T("بررسی این سرور کامل نشد: ","Server check did not complete: ")+error.GetType().Name+" · "+TextUtil.OneLine(error.Message??"")};}
                if(cancel())throw new OperationCanceledException();
                if(result!=null&&result.Connected){result.VerifiedServer=server;result.Reason=Lang.T("ورود تأیید شد؛ سرور: ","Login verified; server: ")+server;return result;}
                string detail=result==null?"":TextUtil.OneLine(result.Reason??"");if(detail.Length>240)detail=detail.Substring(0,240);
                attempts.Add(server+": "+(result!=null&&result.State==Login.WrongLogin?Lang.T("ورود رد شد","login rejected"):Lang.T("تأیید نشد","unconfirmed"))+(detail.Length>0?" ("+detail+")":""));
                if(result!=null&&!result.Retryable&&result.State!=Login.WrongLogin)break;
            }
            return new ImportConnection{Retryable=false,Reason=Lang.T("هیچ سروری ورود را تأیید نکرد. شماره حساب، رمز اینوستور و سرور دقیق را از دانشجو بخواهید. ","No server confirmed login. Ask for the account number, investor password and exact server. ")+string.Join("; ",attempts)};
        }
    }
    public static class TextStudentImport
    {
        sealed class Draft{public StudentImportRow Row=new StudentImportRow();public string Broker="",Type="",Problem="";public bool Any{get{return Row.Name.Length+Row.Login.Length+Row.Investor.Length+Row.Master.Length+Broker.Length+Row.Server.Length+Row.Platform.Length>0;}}}
        static readonly Regex Field=new Regex(@"^(?<key>Investor(?:\s*Password)?|Read[ -]?only(?:\s*Password)?|رمز\s*اینوستور|اینوستور|Master\s*Password|Master(?=\s*[:：=])|رمز\s*مستر|مستر|Password|رمز|Account\s*(?:Number|No\.?|Login)|Login|Account(?=\s*[:：=])|شماره\s*حساب|Name|Full\s*Name|نام(?:\s*و\s*نام\s*خانوادگی)?|Server(?:\s*Name)?|سرور|Broker(?:\s*Name)?|بروکر|Account\s*Type|نوع\s*حساب|Platform|متاتریدر|پلتفرم|Folder|پوشه)\s*(?:[:：=]\s*|\s+)(?<value>.+)$",RegexOptions.IgnoreCase);
        static string Digits(string s){return Regex.Replace(TextUtil.LatinDigits(s??""),@"[\s,٬]","");}
        static string Clean(string line){return Regex.Replace(line.Trim(),@"^(?:[✅☑✔✓🔹🔸•]+\s*|[-*]\s+)","");}
        public static List<StudentImportRow> Parse(string text,bool latin,IEnumerable<string> existing,Func<Kind,IEnumerable<string>> known=null)
        {
            if((text??"").Length>1024*1024)throw new UserMessage("Text input is too large (maximum 1 MB).");
            var drafts=new List<Draft>();var d=new Draft();int lineNo=0;Action flush=()=>{if(d.Any){drafts.Add(d);d=new Draft();}if(drafts.Count>1000)throw new UserMessage("At most 1000 accounts per import.");};
            foreach(string raw in (text??"").Replace("\r","").Split('\n'))
            {
                lineNo++;string line=Clean(raw);if(line.Length==0)continue;Match field=Field.Match(line);
                if(field.Success)
                {
                    string key=ServerCatalog.Norm(field.Groups["key"].Value),v=field.Groups["value"].Value.Trim();
                    bool login=key=="account"||key=="login"||key.StartsWith("accountnumber")||key=="accountno"||key=="accountlogin"||key=="شمارهحساب";
                    bool name=key=="name"||key=="fullname"||key.StartsWith("نام");
                    if((login&&d.Row.Login.Length>0)||(name&&d.Row.Login.Length>0)){flush();}
                    if(d.Row.Line==0)d.Row.Line=lineNo;
                    if(login)d.Row.Login=Digits(v);else if(name)d.Row.Name=v;
                    else if(key.StartsWith("investor")||key.StartsWith("readonly")||key.Contains("اینوستور"))d.Row.Investor=v;
                    else if(key.StartsWith("master")||key.Contains("مستر"))d.Row.Master=v;
                    else if(key=="password"||key=="رمز")d.Row.Investor=v;
                    else if(key.StartsWith("server")||key=="سرور")d.Row.Server=v;
                    else if(key.StartsWith("broker")||key=="بروکر")d.Broker=v;
                    else if(key=="accounttype"||key=="نوعحساب")d.Type=Type(v);
                    else if(key=="folder"||key=="پوشه")d.Row.Folder=v;
                    else d.Row.Platform=TextUtil.LatinDigits(v)=="4"?"MT4":TextUtil.LatinDigits(v)=="5"?"MT5":Platform(v);
                    continue;
                }
                // Telegram/WhatsApp sender lines and academy banners are not account names.
                if(line.EndsWith(":",StringComparison.Ordinal)||line.Contains("منتورینگ")||line.Contains("منتورينگ")||line.Contains("آکادمی")||line.Contains("آكادمى")||Regex.IsMatch(line,@"^\[?\d{1,2}[:/]\d{2}.*\]:"))continue;
                string platform=Platform(line);if(platform.Length>0){if(d.Row.Platform.Length>0&&d.Row.Login.Length>0)flush();d.Row.Platform=platform;continue;}
                string type=Type(line);if(type.Length>0){d.Type=type;continue;}
                if(line.IndexOf('-')>0&&Regex.IsMatch(line,@"(?i)-(demo|real|live)\d*$")){d.Row.Server=line;continue;}
                if(ImportServerPlan.BrokerAlias(line)=="WMMarkets"||Regex.IsMatch(line,@"(?i)\b(markets?|brokers?)\b")){d.Broker=line;continue;}
                if(d.Row.Name.Length>0&&d.Row.Login.Length==0&&d.Row.Investor.Length==0&&Regex.IsMatch(line,@"[A-Za-z]")&&Regex.IsMatch(line,@"[0-9]")){d.Row.Investor=line;continue;}
                if(d.Row.Platform.Length>0&&d.Row.Name.Length>0&&(d.Row.Login.Length>0||d.Row.Investor.Length>0||d.Row.Master.Length>0)&&!Regex.IsMatch(line,@"[0-9]")&&line.Contains(" ")){flush();d.Row.Name=line;d.Row.Line=lineNo;continue;}
                string number=Digits(line);
                if(Regex.IsMatch(number,@"^\d{1,20}$")&&d.Row.Login.Length==0){d.Row.Login=number;if(d.Row.Line==0)d.Row.Line=lineNo;continue;}
                if(d.Row.Name.Length==0){d.Row.Name=line;if(d.Row.Line==0)d.Row.Line=lineNo;continue;}
                if(d.Row.Login.Length>0&&d.Row.Investor.Length==0&&d.Row.Master.Length==0){d.Row.Investor=line;continue;}
                if(d.Row.Platform.Length>0&&d.Row.Login.Length>0){flush();d.Row.Name=line;d.Row.Line=lineNo;continue;}
                if(d.Row.Login.Length==0&&d.Row.Investor.Length==0&&d.Row.Master.Length==0){d.Row.Name=line;continue;}
                d.Problem=Lang.T("متن اضافه یا مبهم؛ اطلاعات این ردیف را بازبینی کنید.","Additional ambiguous text; review this row.");
            }
            flush();if(drafts.Count==0)throw new UserMessage(Lang.T("اطلاعات حسابی در متن پیدا نشد.","No account information found in the text."));
            foreach(var item in drafts)
            {
                var r=item.Row;r.OriginalName=r.Name;if(latin&&StudentNameLatin.Persian(r.Name))r.Name=StudentNameLatin.Convert(r.Name);
                r.Mode=r.Investor.Length>0?"investor":r.Master.Length>0?"master":"investor";
                r.InputProblem=item.Problem;
                if(r.Server.Length==0||ImportServerPlan.Ambiguous(r.Server))
                {
                    if(r.Server.Length>0){item.Broker=ServerCatalog.Broker(r.Server);item.Type=Regex.IsMatch(r.Server,@"(?i)-demo")?"demo":"real";}
                    var kind=r.Platform=="MT4"?Kind.MT4:Kind.MT5;
                    if(item.Broker.Length>0&&item.Type.Length>0&&r.Platform.Length>0)
                    {var options=ImportServerPlan.Candidates(kind,item.Broker,item.Type,known==null?new string[0]:known(kind),ImportServerPlan.Remembered(kind));if(options.Count>0){r.Server=options[0];r.ImportServers=string.Join("|",options);}else r.InputProblem=Lang.T("سرور این بروکر پیدا نشد؛ سرور کامل را وارد کنید یا فهرست سرورها را تازه کنید.","Broker servers not found; enter the full server or refresh the catalogue.");}
                }
            }
            return Revalidate(drafts.Select(x=>x.Row),existing);
        }
        static string Type(string v){v=ServerCatalog.Norm(v);return v=="demo"||v=="دمو"||v=="آزمایشی"?"demo":v=="real"||v=="live"||v=="ریل"||v=="ریال"||v=="واقعی"?"real":"";}
        static string Platform(string v){v=ServerCatalog.Norm(v);return v=="mt4"||v=="metatrader4"||v=="متاتریدر4"?"MT4":v=="mt5"||v=="metatrader5"||v=="متاتریدر5"?"MT5":"";}
        public static List<StudentImportRow> Revalidate(IEnumerable<StudentImportRow> input,IEnumerable<string> existing)
        {
            var list=input.ToList();var sheet=new List<SheetRow>();var h=new SheetRow();for(int c=0;c<StudentImport.Headers.Length;c++)h.Cells[c]=StudentImport.Headers[c];h.Cells[8]="NeedsLoginCorrection";sheet.Add(h);
            foreach(var r in list){var row=new SheetRow{Number=r.Line,Problem=r.InputProblem};string[] values={r.Name,r.Platform,r.Login,r.Server,r.Investor,r.Folder,r.Mode,r.Master};for(int c=0;c<values.Length;c++)row.Cells[c]=values[c];row.Cells[8]=r.LoginNeedsCorrection?"1":"";sheet.Add(row);}
            var validated=StudentImport.Plan(sheet,existing);
            for(int i=0;i<list.Count;i++){var a=list[i];var b=validated[i];a.Name=b.Name;a.Login=b.Login;a.Server=b.Server;a.Platform=b.Platform;a.Kind=b.Kind;a.Mode=b.Mode;a.State=b.State;a.Reason=b.Reason;if(a.State==ImportState.Ready&&a.ImportServers.Length>0)a.Reason=Lang.T("سرور پیشنهادی؛ تأیید اتصال لازم است (", "Suggested server; login verification required (")+a.ImportServers.Split('|').Length+")";}
            // Conflicting credentials for the same number must not silently choose a winner.
            foreach(var group in list.Where(r=>r.Login.Length>0).GroupBy(r=>StudentImport.Key(r.Kind,r.Login,r.Server)).Where(g=>g.Count()>1))
            {if(group.Select(r=>r.Server+"\t"+r.Platform+"\t"+r.Mode+"\t"+r.Investor+"\t"+r.Master).Distinct(StringComparer.Ordinal).Count()>1)foreach(var r in group){r.State=ImportState.Invalid;r.Reason=Lang.T("اطلاعات متناقض برای یک شماره حساب؛ اصلاح کنید.","Conflicting details for one account number; edit before adding.");}}
            return list;
        }
        public static string CorrectionText(IEnumerable<StudentImportRow> rows)
        {
            var output=new List<string>();foreach(var r in rows.Where(x=>x.State==ImportState.Invalid||x.State==ImportState.Failed||x.State==ImportState.Unconfirmed||x.State==ImportState.Cancelled))
            {
                output.Add(string.Join(" · ",new[]{TextUtil.OneLine(r.Name),TextUtil.OneLine(r.Login)}.Where(value=>!string.IsNullOrWhiteSpace(value))));
            }return string.Join("\r\n",output);
        }
    }
}
