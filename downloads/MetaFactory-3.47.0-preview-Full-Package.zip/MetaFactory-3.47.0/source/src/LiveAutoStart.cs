using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
namespace MTManager
{
    // Invoked only by explicit manual Run, while the managed terminal is closed.
    public static class LiveAutoStart
    {
        static readonly object gate = new object();
        public static List<string> Prepare(Instance copy, Settings settings, Account account)
        {
            if (account == null || !account.HasLogin) return new List<string>();
            lock (gate)
            {
                string problem; var targets = LiveMonitorStore.Load(out problem);
                if (problem != null) throw new UserMessage(problem);
                var target = targets.FirstOrDefault(t => t.Matches(copy, account)) ?? LiveMonitorTarget.Create(copy, account);
                var deployment = LiveReporter.Prepare(settings, copy, account, target.Token);
                string presetDir = copy.Kind == Kind.MT4 ? Path.Combine(copy.Dir, "presets") : Path.Combine(copy.Dir, "MQL5", "Profiles", "Presets");
                Directory.CreateDirectory(presetDir);
                string presetName = "MetaFactoryLive-" + target.Token + ".set";
                string preset = Path.Combine(presetDir, presetName);
                string content = LiveReporter.PresetText(account, target.Token);
                Encoding encoding = copy.Kind == Kind.MT4 ? Encoding.Default : Encoding.Unicode;
                if (File.Exists(preset) && File.ReadAllText(preset, encoding) != content)
                    throw new UserMessage("Live startup preset differs; existing file was preserved.");
                if (!File.Exists(preset)) File.WriteAllText(preset, content, encoding);
                WriteBootstrap(copy, account, target.Token);
                target.Guide = Lang.T("گزارش‌خوان با تنظیمات شروع خودکار آماده شد. پس از اجرا، پایش زنده را باز کنید؛ دریافت پیام تازه ملاک فعال‌شدن است.", "Reporter prepared for automatic startup. Open Live monitoring after Run; a fresh heartbeat confirms activation.");
                targets.RemoveAll(t => string.Equals(t.CopyName, copy.Name, StringComparison.OrdinalIgnoreCase)); targets.Add(target); LiveMonitorStore.Save(targets);
                string symbol = null;
                foreach (string chart in ChartProfile.AllCharts(copy))
                { symbol = ReportLaunch.ChartSymbol(TextFiles.ReadText(chart)); if (symbol != null) break; }
                symbol = symbol ?? "EURUSD";
                string expertRoot = Path.Combine(copy.Dir, Kinds.Mql(copy.Kind), "Experts") + Path.DirectorySeparatorChar;
                string relative = deployment.ExpertPath.Substring(expertRoot.Length);
                relative = relative.Substring(0, relative.Length - 4).Replace('/', '\\');
                var chartTexts = ChartProfile.AllCharts(copy).Select(TextFiles.ReadText).ToList();
                string period = FreePeriod(chartTexts, symbol, target.Token);
                return Lines(copy.Kind, relative, presetName, symbol, period);
            }
        }
        public static string InitStatus(Instance copy)
        {
            try
            {
                string path=Path.Combine(copy.Dir,Kinds.Mql(copy.Kind),"Files","MetaFactoryLive","init-status.txt");
                var info=new FileInfo(path);
                if(!info.Exists || info.Length>4096)return "";
                return info.LastWriteTimeUtc.ToString("u")+" "+TextFiles.ReadText(path);
            }
            catch { return ""; }
        }
        public static string Diagnostics(IEnumerable<Instance> copies)
        {
            var rows=new List<string>();
            foreach(var copy in copies.Take(500))
            {
                string status=InitStatus(copy);
                var lines=new List<string>();
                foreach(DateTime day in new[]{DateTime.Today.AddDays(-1),DateTime.Today})
                    lines.AddRange(ReportDiagnostics.Tail(ReportTrace.ProgramsLog(copy,day),day,day)
                        .Where(l=>l.IndexOf("MTManagerLive",StringComparison.OrdinalIgnoreCase)>=0 || l.IndexOf("MetaFactory Live",StringComparison.OrdinalIgnoreCase)>=0));
                if(status.Length==0 && lines.Count==0)continue;
                rows.Add(copy.Name+" [startup diagnostics; not proof of a fresh live feed]");
                if(status.Length>0)rows.Add(status);
                rows.AddRange(lines.Skip(Math.Max(0,lines.Count-10)));
            }
            return "\r\n— Live observer initialization —\r\n"+string.Join("\r\n",rows)+"\r\n";
        }
        public static string BootstrapText(Account account, string token)
        {
            LiveReporter.PresetText(account, token); // same strict identity validation as presets
            return "MLBOOT\t1\r\n" + LiveReporter.ValidateToken(token) + "\r\n" + long.Parse(account.Login.Trim()).ToString(System.Globalization.CultureInfo.InvariantCulture) + "\r\n" + account.Server.Trim() + "\r\n";
        }
        public static void WriteBootstrap(Instance copy, Account account, string token)
        {
            string directory = Path.Combine(copy.Dir, Kinds.Mql(copy.Kind), "Files", "MetaFactoryLive");
            Directory.CreateDirectory(directory);
            string path = Path.Combine(directory, "bootstrap.txt"), temp = path + ".tmp-" + Guid.NewGuid().ToString("N");
            try
            {
                File.WriteAllText(temp, BootstrapText(account, token), Encoding.Unicode);
                if (File.Exists(path)) File.Replace(temp, path, null); else File.Move(temp, path);
            }
            finally { if(File.Exists(temp)) File.Delete(temp); }
        }
        public static string FreePeriod(IEnumerable<string> charts, string symbol, string token)
        {
            var occupied = new HashSet<int>();
            foreach (string text in charts)
            {
                if (!string.Equals(ReportLaunch.ChartSymbol(text), symbol, StringComparison.OrdinalIgnoreCase)) continue;
                var match = System.Text.RegularExpressions.Regex.Match(text ?? "", @"(?im)^period=(\d+)\s*$");
                int period;
                if (!match.Success)
                {
                    var size = System.Text.RegularExpressions.Regex.Match(text ?? "", @"(?im)^period_size=(\d+)\s*$");
                    var type = System.Text.RegularExpressions.Regex.Match(text ?? "", @"(?im)^period_type=(\d+)\s*$");
                    int n, unit;
                    if (size.Success && type.Success && int.TryParse(size.Groups[1].Value,out n) && int.TryParse(type.Groups[1].Value,out unit))
                    { int[] factors = {1,60,1440,10080,43200}; if(unit>=0 && unit<factors.Length && n>0 && n<=43200) { occupied.Add(n*factors[unit]); continue; } }
                }
                if (!match.Success || !int.TryParse(match.Groups[1].Value, out period))
                    throw new UserMessage("Cannot identify an existing chart timeframe; automatic live attachment stopped to preserve its EA.");
                if ((text ?? "").Contains("MTManagerLive") && (text ?? "").Contains(token)) return period.ToString();
                occupied.Add(period);
            }
            foreach (int period in new[] { 1, 5, 15, 30, 60, 240, 1440, 10080, 43200 })
                if (!occupied.Contains(period)) return period.ToString();
            throw new UserMessage("No separate chart timeframe is available for the live observer; existing EAs were preserved.");
        }
        public static List<string> Lines(Kind kind, string expert, string preset, string symbol, string period = "1")
        {
            foreach (string value in new[] { expert, preset, symbol, period })
                if (string.IsNullOrWhiteSpace(value) || value.Any(char.IsControl)) throw new ArgumentException("Invalid live startup parameter.");
            var lines = new List<string>();
            if (kind == Kind.MT5) lines.Add("[StartUp]");
            lines.Add("Expert=" + expert); lines.Add("ExpertParameters=" + preset);
            lines.Add("Symbol=" + symbol); int minutes = int.Parse(period);
            string frame = minutes < 60 ? "M" + minutes : minutes < 1440 ? "H" + (minutes / 60) : minutes == 1440 ? "D1" : minutes == 10080 ? "W1" : "MN1";
            lines.Add("Period=" + (kind == Kind.MT5 ? frame : period));
            lines.Add(kind == Kind.MT5 ? "ShutdownTerminal=0" : "ShutdownTerminal=false");
            return lines;
        }
    }
}
