using System;
using System.Linq;
namespace MTManager { static partial class Tests {
static void LiveAutoStartChecks() {
 var bootstrapAccount=new Account {Login="12345",Server="Synthetic-Demo"};
 string token=new string('a',32), binding=LiveAutoStart.BootstrapText(bootstrapAccount,token);
 Check(binding=="MLBOOT\t1\r\n"+token+"\r\n12345\r\nSynthetic-Demo\r\n","fallback binding has exact bounded account-specific UTF16 text schema");
 var bootstrapCopy=new Instance {Name="MT4-bootstrap",Kind=Kind.MT4,Dir=Dir("live-bootstrap")};
 LiveAutoStart.WriteBootstrap(bootstrapCopy,bootstrapAccount,token);
 string bootstrapPath=System.IO.Path.Combine(bootstrapCopy.Dir,"MQL4","Files","MetaFactoryLive","bootstrap.txt");
 Equal(binding,System.IO.File.ReadAllText(bootstrapPath,System.Text.Encoding.Unicode),"atomic bootstrap is readable in native FILE_UNICODE form");
 bootstrapAccount.Login="67890";LiveAutoStart.WriteBootstrap(bootstrapCopy,bootstrapAccount,new string('b',32));
 Check(System.IO.File.ReadAllText(bootstrapPath).Contains("67890")&&!System.IO.File.ReadAllText(bootstrapPath).Contains(token),"closed-copy binding update replaces previous account atomically");
 Throws<UserMessage>(()=>LiveAutoStart.BootstrapText(new Account{Login="123",Server="Demo\nOther=bad"},token),"bootstrap server cannot inject extra binding lines");
 foreach(Kind nativeKind in new[]{Kind.MT4,Kind.MT5}) {
  string source=LiveReporter.SourceText(nativeKind);
  Check(source.Contains("bool ResolveSession()") && source.Contains("MLBOOT\\t1") && source.Contains("WorkToken==\"\" && WorkLogin==\"\" && WorkServer==\"\""),"native fallback only applies to wholly absent explicit inputs for "+nativeKind);
  Check(source.Contains("session-generation-write") && source.Contains("FileReadLong(ownerHandle)==generation+1") && !source.Contains("FileWriteLong(ownerHandle,generation+1)!=8"),"native lock generation uses persisted readback proof for "+nativeKind);
  Check(source.Contains("retryInitAt>=5000") && source.Contains("BeginLiveSession();retryInitAt=GetTickCount();return INIT_SUCCEEDED;"),"recoverable native session failure keeps terminal initialized and retries for "+nativeKind);
 }

 Equal("5",LiveAutoStart.FreePeriod(new[]{"symbol=EURUSD\nperiod=1\n<expert>OtherEA</expert>"},"EURUSD",new string('a',32)),"automatic observer chooses separate timeframe from existing EA chart");
 Equal("1",LiveAutoStart.FreePeriod(new[]{"symbol=EURUSD\nperiod=1\nMTManagerLive\n"+new string('a',32)},"EURUSD",new string('a',32)),"same account live chart can be reused");
 foreach (Kind kind in new[] { Kind.MT4, Kind.MT5 }) {
  var lines = LiveAutoStart.Lines(kind, @"MetaFactoryLive\version\MTManagerLive", "session.set", "EURUSD.m");
  Check(lines.Contains(@"Expert=MetaFactoryLive\version\MTManagerLive") && lines.Contains("ExpertParameters=session.set"), "automatic live startup binds independent EA and preset for " + kind);
  Check(lines.Contains("Symbol=EURUSD.m"), "automatic startup keeps broker symbol suffix for " + kind);
  Check(!lines.Any(x => x.StartsWith("Script=") || x.StartsWith("AllowLiveTrading=") || x.StartsWith("ExpertsTrades=") || x.StartsWith("ExpertsDllImport=")), "live auto startup does not change terminal trading/DLL permissions for " + kind);
  Check(kind != Kind.MT4 || lines.Contains("ShutdownTerminal=false"),"MT4 auto-run explicitly disables startup terminal shutdown");
  Check(kind != Kind.MT5 || lines.First()=="[StartUp]" && lines.Contains("ShutdownTerminal=0"), "MT5 live startup stays open");
 }
 Throws<ArgumentException>(() => LiveAutoStart.Lines(Kind.MT4,"EA\nExpert=bad","s.set","EURUSD"), "automatic EA setting rejects newline injection");
 Check(LiveAutoStart.Prepare(new Instance(),new Settings(),null).Count==0,"copies without stored account do not attempt live compilation");
}
}}
