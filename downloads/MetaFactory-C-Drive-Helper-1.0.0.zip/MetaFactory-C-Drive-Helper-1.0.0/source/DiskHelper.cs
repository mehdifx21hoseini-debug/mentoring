using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Reflection;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace MetaFactoryDiskHelper
{
    public sealed class LargeFile
    {
        public string Path;
        public long Bytes;
    }
    public sealed class ScanResult
    {
        public string Root, StopReason = "Completed";
        public long Bytes, Files;
        public int Skipped, Links;
        public readonly List<LargeFile> Largest = new List<LargeFile>();
    }
    public static class Scanner
    {
        // Metadata only. No file contents, directory links, registry writes or deletion.
        public static ScanResult Scan(string root, int seconds, long maxFiles, long minimum,
            int top, ISet<string> exclusions, Func<bool> cancel, Action<long> progress)
        {
            var result = new ScanResult { Root = root };
            var clock = Stopwatch.StartNew();
            var pending = new Stack<string>();
            var visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            pending.Push(root);
            while (pending.Count > 0)
            {
                if (Stop(result, clock, seconds, maxFiles, cancel)) break;
                string dir = pending.Pop();
                if (!visited.Add(dir) || (exclusions != null && exclusions.Contains(dir.TrimEnd('\\', '/')))) continue;
                IEnumerator<FileSystemInfo> entries = null;
                try
                {
                    var info = new DirectoryInfo(dir);
                    if (!info.Exists) { result.Skipped++; continue; }
                    if ((info.Attributes & FileAttributes.ReparsePoint) != 0) { result.Links++; continue; }
                    entries = info.EnumerateFileSystemInfos().GetEnumerator();
                    while (true)
                    {
                        if (Stop(result, clock, seconds, maxFiles, cancel)) break;
                        if (!entries.MoveNext()) break;
                        var item = entries.Current;
                        try
                        {
                            if ((item.Attributes & FileAttributes.ReparsePoint) != 0) { result.Links++; continue; }
                            if ((item.Attributes & FileAttributes.Directory) != 0) { pending.Push(item.FullName); continue; }
                            long size = ((FileInfo)item).Length;
                            result.Files++; result.Bytes += size;
                            if (size >= minimum)
                            {
                                result.Largest.Add(new LargeFile { Path = item.FullName, Bytes = size });
                                if (result.Largest.Count > top * 2) Trim(result, top);
                            }
                            if (progress != null && result.Files % 1000 == 0) progress(result.Files);
                        }
                        catch (IOException) { result.Skipped++; }
                        catch (UnauthorizedAccessException) { result.Skipped++; }
                        catch (System.Security.SecurityException) { result.Skipped++; }
                    }
                }
                catch (IOException) { result.Skipped++; }
                catch (UnauthorizedAccessException) { result.Skipped++; }
                catch (System.Security.SecurityException) { result.Skipped++; }
                finally { if (entries != null) entries.Dispose(); }
                if (result.StopReason != "Completed") break;
            }
            Trim(result, top);
            return result;
        }
        static bool Stop(ScanResult r, Stopwatch clock, int seconds, long limit, Func<bool> cancel)
        {
            if (cancel != null && cancel()) { r.StopReason = "Stopped by user (partial results)"; return true; }
            if (clock.Elapsed.TotalSeconds >= seconds) { r.StopReason = "Time limit (partial results)"; return true; }
            if (r.Files >= limit) { r.StopReason = "File-count limit (partial results)"; return true; }
            return false;
        }
        static void Trim(ScanResult r, int top)
        {
            var keep = r.Largest.OrderByDescending(f => f.Bytes).ThenBy(f => f.Path, StringComparer.OrdinalIgnoreCase).Take(top).ToList();
            r.Largest.Clear(); r.Largest.AddRange(keep);
        }
    }
    public static class Program
    {
        static readonly StringBuilder Report = new StringBuilder();
        static string Size(long bytes) { return (bytes / 1073741824.0).ToString("0.00", CultureInfo.InvariantCulture) + " GB"; }
        static void Say(string text) { Console.WriteLine(text); Report.AppendLine(text); }
        static void Space()
        {
            try { var c = new DriveInfo("C:\\"); Say("C: FREE " + Size(c.AvailableFreeSpace) + " / TOTAL " + Size(c.TotalSize)); }
            catch (Exception e) { Say("Cannot read C: space: " + e.Message); }
        }
        static bool Cancel()
        {
            try { return Console.KeyAvailable && Console.ReadKey(true).Key == ConsoleKey.Escape; }
            catch (InvalidOperationException) { return false; }
        }
        static bool OnC(string path) { return !string.IsNullOrWhiteSpace(path) && path.StartsWith("C:\\", StringComparison.OrdinalIgnoreCase); }
        static string Label(string path)
        {
            string p = path.ToLowerInvariant();
            if (p.StartsWith("c:\\windows\\") || p.StartsWith("c:\\program files") || p.StartsWith("c:\\programdata\\")) return "SYSTEM / APP DATA - review through Windows or the app";
            string name = System.IO.Path.GetFileName(p);
            if (name == "pagefile.sys" || name == "hiberfil.sys" || name == "swapfile.sys" || name.StartsWith("$")) return "WINDOWS-MANAGED - do not delete manually";
            if (p.Contains("\\sandbox\\") || p.Contains("metatrader") || p.Contains("metaquotes") || p.Contains("metafactory") || p.Contains("mt manager")) return "APP / TRADING DATA - do not delete without review";
            if (p.Contains("\\appdata\\")) return "APP DATA - may be needed by installed apps";
            return "REVIEW ONLY - size does not mean this file is unnecessary";
        }
        static void Show(ScanResult r)
        {
            Say("\n" + r.Root);
            Say("Observed file sizes: " + Size(r.Bytes) + " | Files: " + r.Files + " | " + r.StopReason);
            Say("Skipped/unreadable entries: " + r.Skipped + " | Links not followed: " + r.Links);
            foreach (var f in r.Largest) Say("  " + Size(f.Bytes) + "  " + f.Path + "\n    " + Label(f.Path));
        }
        static void QuickScan()
        {
            Say("\nQUICK FOLDER SCAN - read only; Escape stops scanning.");
            Say("Each folder has a 15-second budget. Sizes are observed file lengths, not guaranteed reclaimable space.");
            string user = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var paths = new[] {
                Path.Combine(local, "Temp"), Path.Combine(user, "Downloads"),
                Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
                Environment.GetFolderPath(Environment.SpecialFolder.MyVideos),
                @"C:\Windows\Temp", @"C:\Sandbox", @"C:\ProgramData\MetaQuotes"
            };
            foreach (string path in paths.Where(OnC).Distinct(StringComparer.OrdinalIgnoreCase))
            {
                if (!Directory.Exists(path)) continue;
                Console.WriteLine("Scanning " + path + " ...");
                var scan = Scanner.Scan(path, 15, 100000, 100L * 1024 * 1024, 8, null, Cancel, null);
                Show(scan);
                if (scan.StopReason.StartsWith("Stopped")) break;
            }
            Say("Folder totals may overlap; do not add them together. No files were deleted.");
        }
        static void LargeScan()
        {
            Say("\nLARGE FILE SCAN - read only; up to 2 minutes; Escape stops.");
            Say("Windows, Program Files and Recycle Bin contents are excluded. Hidden app/user data is included where readable.");
            var exclude = new HashSet<string>(new[] { @"C:\Windows", @"C:\Program Files", @"C:\Program Files (x86)", @"C:\$Recycle.Bin", @"C:\System Volume Information" }, StringComparer.OrdinalIgnoreCase);
            var r = Scanner.Scan(@"C:\", 120, 300000, 250L * 1024 * 1024, 30, exclude, Cancel,
                count => { Console.Write("\rFiles examined: " + count + "       "); });
            Console.WriteLine(); Show(r);
            Say("This is not a deletion list. No files were deleted.");
        }
        static void Launch(string exe, string args)
        {
            try
            {
                using (var process = Process.Start(new ProcessStartInfo(exe, args) { UseShellExecute = true })) { }
                Console.WriteLine("Windows tool opened. Review its choices and confirm inside Windows.");
            }
            catch (Exception e) { Console.WriteLine("Could not open Windows tool: " + e.Message); }
        }
        static void Save()
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            if (string.IsNullOrEmpty(desktop)) { Console.WriteLine("Desktop is unavailable."); return; }
            string target = Path.Combine(desktop, "C-Disk-Report-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 6) + ".txt");
            try
            {
                using (var stream = new FileStream(target, FileMode.CreateNew, FileAccess.Write))
                using (var writer = new StreamWriter(stream, new UTF8Encoding(true))) writer.Write(Report.ToString());
                Console.WriteLine("Saved: " + target);
                Console.WriteLine("This report includes personal file paths. Nothing is uploaded automatically.");
            }
            catch (Exception e) { Console.WriteLine("Could not save report: " + e.Message); }
        }
        [STAThread] public static int Main()
        {
            if (Environment.OSVersion.Platform != PlatformID.Win32NT) { Console.WriteLine("Use this helper on Windows 10/11."); return 1; }
            Console.Title = "MetaFactory C Drive Helper 1.0.0";
            Say("MetaFactory C Drive Helper 1.0.0 | " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            Say("READ-ONLY SCANS. This helper has no file-deletion command.");
            Say("Deletion is handled only by the Windows cleanup dialog, with your choices.");
            while (true)
            {
                Space();
                Console.WriteLine("\n1  Quick folder sizes (read only)\n2  Largest files on C: (read only)\n3  Windows Disk Cleanup for C:\n4  Windows Storage settings\n5  Save report to Desktop\n6  Installed apps (manual review)\n0  Exit");
                Console.Write("Choose 0-6: ");
                string choice = Console.ReadLine();
                if (choice == null || choice.Trim() == "0") return 0;
                try
                {
                    switch (choice.Trim())
                    {
                        case "1": QuickScan(); break;
                        case "2": LargeScan(); break;
                        case "3": Launch(Path.Combine(Environment.SystemDirectory, "cleanmgr.exe"), "/d C"); break;
                        case "4": Launch("ms-settings:storagesense", ""); break;
                        case "5": Save(); break;
                        case "6": Launch(Path.Combine(Environment.SystemDirectory, "control.exe"), "appwiz.cpl"); break;
                        default: Console.WriteLine("Enter a number from 0 to 6."); break;
                    }
                }
                catch (Exception e) { Console.WriteLine("Operation did not complete: " + e.Message); }
            }
        }
    }
}
