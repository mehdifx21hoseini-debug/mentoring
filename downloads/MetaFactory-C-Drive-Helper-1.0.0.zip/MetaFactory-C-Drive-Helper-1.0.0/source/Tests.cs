using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using MetaFactoryDiskHelper;
class HelperTests
{
    static int checks;
    static void Check(bool ok, string why) { checks++; if (!ok) throw new Exception(why); }
    static int Main(string[] args)
    {
        string root = args[0];
        var before = Directory.GetFiles(root, "*", SearchOption.TopDirectoryOnly).ToDictionary(p => p, File.ReadAllBytes);
        var a = Scanner.Scan(root, 10, 10000, 0, 2, null, () => false, null);
        Check(a.StopReason == "Completed", "normal scan completes");
        Check(a.Files == 4 && a.Bytes == 110, "sizes reflect only actual files, never followed symlink contents");
        Check(a.Links == 2, "file and directory symlinks are both skipped");
        Check(a.Largest.Count == 2 && a.Largest[0].Bytes == 50 && a.Largest[1].Bytes == 30, "bounded list sorted descending");
        var exclusion = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { Path.Combine(root, "sub") };
        var b = Scanner.Scan(root, 10, 10000, 0, 9, exclusion, () => false, null);
        Check(b.Files == 3 && b.Bytes == 60, "explicit excluded folders never traversed");
        var c = Scanner.Scan(root, 10, 1, 0, 9, null, () => false, null);
        Check(c.Files == 1 && c.StopReason.Contains("partial"), "file count budget yields clearly partial results");
        var d = Scanner.Scan(root, 0, 10000, 0, 9, null, () => false, null);
        Check(d.Files == 0 && d.StopReason.Contains("Time limit"), "time budget respected");
        var e = Scanner.Scan(root, 10, 10000, 0, 9, null, () => true, null);
        Check(e.Files == 0 && e.StopReason.Contains("Stopped by user"), "cancel stops without deletion");
        var f = Scanner.Scan(Path.Combine(root, "absent"), 10, 100, 0, 9, null, null, null);
        Check(f.Skipped == 1 && f.Files == 0, "missing folder handled without failure");
        var g = Scanner.Scan(root, 10, 10000, 31, 9, null, null, null);
        Check(g.Largest.Count == 1 && g.Largest[0].Bytes == 50, "minimum file size applied");
        foreach (var file in before) Check(File.ReadAllBytes(file.Key).SequenceEqual(file.Value), "file content unchanged");
        Check(File.ReadAllBytes(Path.Combine(root, "sub", "d.bin")).Length == 50, "nested file unchanged");
        Check(Directory.GetFiles(root).Length == before.Count, "no files created or removed by scans");
        Console.WriteLine("PASS " + checks + " read-only scan checks"); return 0;
    }
}
