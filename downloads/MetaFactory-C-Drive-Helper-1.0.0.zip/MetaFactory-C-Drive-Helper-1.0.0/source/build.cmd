@echo off
cd /d "%~dp0"
"%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe" /nologo /optimize+ /out:C-Drive-Helper.exe DiskHelper.cs
pause
