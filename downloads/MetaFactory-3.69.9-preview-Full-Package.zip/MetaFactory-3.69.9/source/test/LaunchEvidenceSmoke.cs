using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Diagnostics;using System.Reflection;using System.Threading;using System.Web.Script.Serialization;using MTManager;
class LaunchEvidenceSmoke
{
 static int checks;static void Check(bool ok,string why){if(!ok)throw new Exception(why);checks++;Console.WriteLine("PASS "+why);}
 static Dictionary<string,object>[] Read(string path){var json=new JavaScriptSerializer();return File.ReadAllLines(path).Where(x=>!string.IsNullOrWhiteSpace(x)).Select(x=>json.Deserialize<Dictionary<string,object>>(x)).ToArray();}
 static void WaitFor(string path,string kind){var clock=Stopwatch.StartNew();while(clock.ElapsedMilliseconds<10000){LaunchEvidence.Flush();if(File.Exists(path)&&Read(path).Any(x=>(string)x["event"]==kind))return;Thread.Sleep(50);}throw new Exception("missing "+kind);}
 static int Main()
 {
  string root=Path.Combine(Path.GetTempPath(),"mf-evidence-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=root;Process helper=null;
  try
  {
   var settings=new Settings{BaseDir=Path.Combine(root,"copies"),DelaySeconds=0};var copy=new Instance{Name="MT5-synthetic",Kind=Kind.MT5,Dir=Path.Combine(settings.BaseDir,"MT5-synthetic")};Directory.CreateDirectory(copy.Dir);File.WriteAllText(copy.Exe,"synthetic never executed");
   string[] filtered=LaunchEvidence.FilterOperational(new[]{"Terminal failed to create window","password=PRIVATE_CANARY terminal error","account 123 login failed","Investor PRIVATE_CANARY error","session token=PRIVATE_CANARY terminal failed","ignored price message"});
   Check(filtered.SequenceEqual(new[]{"Terminal failed to create window"}),"operational filtering excludes credential and authorization records");
   File.WriteAllText(Path.Combine(root,"heap-backup-20261127-000000.txt"),"SharedSection=1024,65536,512");
   LaunchEvidence.BeginBatch(new[]{copy},settings);WaitFor(LaunchEvidence.CurrentPath,"desktop_heap_backups");Check(File.ReadAllText(LaunchEvidence.CurrentPath).Contains("65536"),"prior heap backup numeric evidence is captured without applying it");LaunchEvidence.Request(copy);helper=Process.Start(new ProcessStartInfo("/bin/sleep","120"){UseShellExecute=false});LaunchEvidence.Started(helper,copy.Name);
   LaunchEvidence.Sample(copy.Name,helper.Id,"handles=4",new LaunchCapacityDiagnostics.ResourceSnapshot(),false,null);
   LaunchEvidence.UserStop(new[]{"MT5-not-started"},true);LaunchEvidence.CloseRequested(helper.Id,"manual-close");
   LaunchEvidence.GuiFailure(new System.ComponentModel.Win32Exception(8,"synthetic window error"));
   var logDir=Path.Combine(copy.Dir,"logs");Directory.CreateDirectory(logDir);string prefix="0\t"+DateTime.Now.ToString("HH:mm:ss.fff")+"\t";
   File.WriteAllText(Path.Combine(logDir,DateTime.Now.ToString("yyyyMMdd")+".log"),prefix+"Terminal failed to allocate window\r\n"+prefix+"password=PRIVATE_CANARY terminal failed\r\n",System.Text.Encoding.Unicode);
   LaunchEvidence.Sample(copy.Name,helper.Id,"handles=4",new LaunchCapacityDiagnostics.ResourceSnapshot(),true,10053);
   string path=LaunchEvidence.CurrentPath;WaitFor(path,"native_journal");var rows=Read(path);
   Check(rows.Any(x=>(string)x["event"]=="process_created")&&rows.Any(x=>(string)x["event"]=="process_exited"),"creation and exit have separate events");
   Check(rows.Any(x=>(string)x["event"]=="user_stopped_queue")&&rows.Any(x=>(string)x["event"]=="close_requested"),"queue cancellation and process-close request remain distinct");
   Check(rows.Any(x=>(string)x["event"]=="gui_creation_failed"&&((string)x["error_codes"]).Contains("native-code=8")),"original native error8 is preserved");
   string text=File.ReadAllText(path);Check(!text.Contains("PRIVATE_CANARY"),"native journal credentials never reach trace");Check(text.Contains("Terminal failed to allocate window"),"scoped native operational evidence is retained");
   Check(text.Contains("unknown")&&!text.Contains("cause known"),"unavailable resource values and unexplained exits are not invented");Check(!helper.HasExited,"monitor never terminates observed process");
   var sample=rows.Single(x=>(string)x["event"]=="process_created");Check((string)sample["process_start_utc"]!="unknown","PID events carry creation time to guard against reuse");
   long[] seq=rows.Select(x=>Convert.ToInt64(x["sequence"])).ToArray();Check(seq.SequenceEqual(seq.OrderBy(x=>x).Distinct()),"written event order has monotonic sequence identifiers");
   LaunchEvidence.Started(helper,copy.Name,101);LaunchEvidence.Sample(copy.Name,helper.Id,"old process",new LaunchCapacityDiagnostics.ResourceSnapshot(),true,77,100);LaunchEvidence.Flush();
   rows=Read(path);Check(rows.Any(x=>(string)x["event"]=="stale_process_observation")&&!rows.Any(x=>(string)x["event"]=="process_exited"&&Convert.ToInt32(x["exit_code"])==77),"stale watcher identity cannot report the exit of a newer process binding");
   // Stress only the storage boundary, independent of native terminal execution.
   var emit=typeof(LaunchEvidence).GetMethod("Event",BindingFlags.Static|BindingFlags.NonPublic);
   for(int i=0;i<44;i++)emit.Invoke(null,new object[]{"synthetic_sample",new Dictionary<string,object>{{"payload",new string('x',65536)}},true,null});
   LaunchEvidence.UserStop(new[]{"MT5-cancelled-after-budget"},false);LaunchEvidence.Flush();text=File.ReadAllText(path);
   Check(text.Contains("sample_budget_reached")&&text.Contains("MT5-cancelled-after-budget"),"sample budget cannot consume the critical-event reserve");Check(new FileInfo(path).Length<=4*1024*1024,"trace has a bounded per-run footprint");
   var tracked=Enumerable.Range(1,83).ToArray();var seen=Enumerable.Range(1,20).ToArray();
   var health=LaunchEvidence.WindowHealth(tracked,seen,seen.Take(16).ToArray(),new[]{3},true,false);
   Check(((int[])health["tracked_pids_without_top_window"]).Length==63,"health distinguishes83processes from20window PIDs and16visible PIDs");
   var failed=LaunchEvidence.WindowHealth(tracked,seen,seen,new int[0],false,false);
   Check(((int[])failed["tracked_pids_without_top_window"]).Length==0,"failed enumeration never declares63missing windows");
   for(int i=0;i<80;i++)emit.Invoke(null,new object[]{"window_health",LaunchEvidence.WindowHealth(tracked,seen,seen,new int[0],true,false),false,null});
   LaunchEvidence.Flush();rows=Read(path);
   Check(rows.Count(x=>(string)x["event"]=="window_health")==80,"compact health continues for80intervals after detailed sample budget fills");
   Check(new FileInfo(path).Length<4*1024*1024,"continued compact health respects total storage boundary");
   var background=typeof(LaunchEvidence).GetMethod("Background",BindingFlags.Static|BindingFlags.NonPublic);int completed=0;
   using(var release=new ManualResetEvent(false))
   {
    Action blocked=()=>{release.WaitOne();Interlocked.Increment(ref completed);};
    for(int i=0;i<83;i++)background.Invoke(null,new object[]{blocked});
    release.Set();var wait=Stopwatch.StartNew();while(Volatile.Read(ref completed)<83&&wait.ElapsedMilliseconds<10000)Thread.Sleep(20);
    Check(completed==83,"83simultaneous background captures queue and finish instead of dropping beyond4workers");
   }
   LaunchEvidence.BeginBatch(new[]{copy},settings);LaunchEvidence.Flush();Check(File.Exists(Path.Combine(root,"launch-evidence-previous.txt")),"previous complete run is retained separately");
   string other=Path.Combine(root,"foreign");Directory.CreateDirectory(other);File.WriteAllText(Path.Combine(other,"launch-evidence.txt"),"USER_OWNED_FILE");AppPaths.DataDirOverride=other;
   LaunchEvidence.BeginBatch(new[]{copy},settings);LaunchEvidence.Request(copy);LaunchEvidence.Flush();
   Check(File.ReadAllText(Path.Combine(other,"launch-evidence.txt"))=="USER_OWNED_FILE","unknown file ownership never permits overwriting or appending");
   bool threw=false;try{LaunchEvidence.Observe(()=>{throw new IOException("synthetic unavailable diagnostics");});}catch{threw=true;}Check(!threw,"diagnostic failures cannot escape into the launch path");
   Console.WriteLine("LAUNCH EVIDENCE PASS "+checks+" (synthetic process/logs, no Windows capacity claim)");return 0;
  }
  catch(Exception e){Console.Error.WriteLine(e);return 1;}
  finally{LaunchEvidence.Flush();if(helper!=null){try{if(!helper.HasExited){helper.Kill();helper.WaitForExit();}helper.Dispose();}catch{}}try{Directory.Delete(root,true);}catch{}}
 }
}
