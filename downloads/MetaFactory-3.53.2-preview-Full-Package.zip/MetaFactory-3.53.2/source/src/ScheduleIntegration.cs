using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace MTManager
{
    sealed partial class MainForm
    {
        readonly Timer scheduleTimer = new Timer { Interval = 15000 };
        ScheduleOptions scheduleOptions;
        ScheduleLedger scheduleLedger;
        ScheduledBatch scheduledBatch;
        bool scheduleStarting;
        volatile bool scheduleCancel;
        sealed class ScheduledBatch
        {
            public ScheduleOptions Options;
            public DateTime StartedUtc;
            public List<Instance> Copies;
            public Dictionary<string, Account> Accounts;
            public readonly Dictionary<string, AccountJournal> Journals = new Dictionary<string, AccountJournal>(StringComparer.OrdinalIgnoreCase);
        }
        string ScheduleStatus { get { return scheduleLedger == null ? "" : scheduleLedger.Error ?? (scheduleLedger.State.StartedUtc == DateTime.MinValue ? "" : scheduleLedger.State.StartedUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) + "\r\n") + scheduleLedger.State.Status; } }
        void InitializeSchedule()
        {
            if (scheduleLedger != null) return;
            scheduleOptions = ScheduleStore.Load();
            scheduleLedger = new ScheduleLedger(Path.Combine(AppPaths.DataDir, "schedule-run.json"));
            scheduleTimer.Tick += (s, e) => ScheduleTick();
            scheduleTimer.Start();
            FormClosed += (s, e) => { scheduleCancel = true; scheduleTimer.Stop(); scheduleTimer.Dispose(); };
        }
        void EditSchedule(){EditSettingsPage(true);}
        void SaveScheduleOptions(ScheduleOptions value)
        {
            ScheduleStore.Save(value);
            scheduleOptions=value;
            SetStatus(Lang.T("تنظیمات زمان‌بندی ذخیره شد؛ اجرا بر اساس ساعت همین ویندوز است.","Schedule saved; execution uses this Windows computer's local clock."));
        }
        void ShowScheduledReport()
        {
            string path = Path.Combine(AppPaths.DataDir, "scheduled-last-report.txt");
            string body = ScheduleStatus + "\r\n\r\n" + (File.Exists(path) ? File.ReadAllText(path) : Lang.T("هنوز گزارشی آماده نشده است.", "No report has been prepared yet."));
            using (var dialog = new TextDialog(Lang.T("آخرین گزارش خودکار", "Last automated report"), body, false)) dialog.ShowDialog(this);
        }
        bool ScheduleIdle { get { return !appClosing && !busy && !preparingCopy && !isolateManualReports && pending.Count == 0 && report == null && readQueue.Count == 0 && startQueue.Count == 0 && scheduledBatch == null; } }
        void ScheduleTick()
        {
            if (scheduleOptions == null || scheduleLedger == null || !ScheduleIdle || !scheduleLedger.Due(scheduleOptions, DateTime.Now)) return;
            BeginScheduled(false);
        }
        void RunScheduledNow() { if (scheduleOptions == null) InitializeSchedule(); BeginScheduled(true); }
        void BeginScheduled(bool manual)
        {
            if (!ScheduleIdle) { if (manual) SetStatus(Lang.T("گزارش یا اجرای دیگری در جریان است؛ پس از پایان دوباره بزنید.", "Another run is active; try again when it finishes.")); return; }
            string problem = ScheduledDelivery.Validate(scheduleOptions);
            if (problem != null || scheduleLedger.Error != null)
            {
                if (manual) Ui.Message(this, problem ?? scheduleLedger.Error, MessageBoxIcon.Warning);
                else SetStatus(problem ?? scheduleLedger.Error);
                return;
            }
            try
            {
                var options = new JavaScriptSerializer().Deserialize<ScheduleOptions>(new JavaScriptSerializer().Serialize(scheduleOptions));
                scheduleLedger.Begin(options, DateTime.Now, DateTime.UtcNow);
                Kind? kind = options.Platform == "MT4" ? (Kind?)Kind.MT4 : options.Platform == "MT5" ? (Kind?)Kind.MT5 : null;
                var selected = copies.Where(c => !kind.HasValue || c.Kind == kind.Value)
                    .Where(c => { var a = accounts.Get(c.Name); return a != null && a.HasLogin; }).ToList();
                if (selected.Count == 0) { ScheduleEnd("skipped", Lang.T("حسابی برای گزارش خودکار وجود ندارد؛ چیزی ارسال نشد.", "No accounts in this scope; nothing sent.")); return; }
                string admission = ReportRunner.NativeAdmissionProblem(settings, selected);
                if (admission != null) { ScheduleEnd("blocked", Lang.T("گزارش خودکار شروع نشد: ", "Scheduled report not started: ") + admission); return; }
                scheduledBatch = new ScheduledBatch { Options = options, StartedUtc = DateTime.UtcNow, Copies = selected,
                    Accounts = selected.ToDictionary(c => c.Name, c => accounts.Get(c.Name).Snapshot(), StringComparer.OrdinalIgnoreCase) };
                scheduleCancel = false;
                scheduleStarting = true;
                // Include yesterday's UTC boundary, so server-day selection remains correct across time zones/midnight.
                try { Read(selected.Select(c => c.Name), DateTime.UtcNow.Date.AddDays(-1)); }
                finally { scheduleStarting = false; }
                if (report == null && readQueue.Count == 0) ScheduleEnd("failed", Lang.T("گزارش‌خوان شروع نشد؛ چیزی ارسال نشد.", "Report reader did not start; nothing sent."));
            }
            catch (Exception e) { ScheduleEnd("failed", Lang.T("اجرای خودکار ناموفق: ", "Automated run failed: ") + e.GetType().Name); }
        }
        void ScheduleEnd(string phase, string status)
        {
            scheduledBatch = null;
            try { if (scheduleLedger != null) scheduleLedger.Set(phase, status); }
            catch { status = scheduleLedger.Error; }
            if (!appClosing) SetStatus(status);
        }
        void CaptureScheduledJournal(ReportJob job, ReportRow row)
        {
            if (scheduledBatch == null || row.Cached || row.Cancelled || row.Error != null || row.Journal == null || !row.Journal.Complete) return;
            Account expected;
            if (!scheduledBatch.Accounts.TryGetValue(job.Copy.Name, out expected) || expected.CredentialKey != job.Account.CredentialKey) return;
            try
            {
                // Preserve the actual fresh result even if writing the shared journal cache failed.
                var snapshot = JournalFile.Parse(JournalFile.Write(row.Journal));
                if (snapshot != null && snapshot.Complete) scheduledBatch.Journals[job.Copy.Name] = snapshot;
            }
            catch { /* No cached substitute: the outgoing message will explicitly mark this account unavailable. */ }
        }
        void CompleteScheduledReport()
        {
            if (scheduledBatch == null || scheduleStarting || appClosing) return;
            var batch = scheduledBatch;
            if (reportResults.Stopping || scheduleCancel)
            { ScheduleEnd("stopped", Lang.T("گزارش خودکار متوقف شد؛ چیزی ارسال نشد.", "Automated report stopped; nothing sent.")); return; }
            try
            {
                var results = reportResults.Rows.ToDictionary(r => r.Copy, StringComparer.OrdinalIgnoreCase);
                var text = new StringBuilder();
                text.AppendLine("MetaFactory scheduled report");
                text.AppendLine("Started UTC: " + batch.StartedUtc.ToString("u", CultureInfo.InvariantCulture));
                text.AppendLine(reportResults.Counts());
                text.AppendLine("Collection time: " + reportResults.ElapsedText);
                text.AppendLine("Each account uses its broker's calendar day at the start of this run. Failed/cached reads have no financial figures below.");
                int n = 0;
                foreach (var copy in batch.Copies)
                {
                    n++; Account a = batch.Accounts[copy.Name], current = accounts.Get(copy.Name);
                    ReportResultEntry result; results.TryGetValue(copy.Name, out result);
                    text.AppendLine();
                    string name = string.IsNullOrWhiteSpace(a.Trader) ? copy.Name : a.Trader;
                    bool identity = current != null && current.CredentialKey == a.CredentialKey;
                    AccountJournal journal = null;
                    if (identity && result != null && result.State == "read") batch.Journals.TryGetValue(copy.Name, out journal);
                    bool valid = journal != null && journal.Login == a.Login && string.Equals(journal.Server, a.Server, StringComparison.OrdinalIgnoreCase)
                        && string.Equals(journal.Platform, copy.Kind.ToString(), StringComparison.OrdinalIgnoreCase);
                    if (!valid)
                    {
                        text.AppendLine(n + ". " + name + " | " + a.Login + " | " + a.Server);
                        text.AppendLine("NOT FRESH: " + (!identity ? "Account settings changed during the run." : result == null ? "No result." : result.State == "read" ? "Fresh report snapshot unavailable or account mismatch." : ReportRunSummary.Status(result.State)));
                        if (identity && result != null && !string.IsNullOrWhiteSpace(result.Reason))
                            text.AppendLine("Reason: " + result.Reason.Substring(0, Math.Min(2000, result.Reason.Length)));
                        continue;
                    }
                    try
                    {
                    var range = ServerDays.Range(PanelRange.Today, ServerDays.Now(journal, batch.StartedUtc).Date);
                    text.AppendLine(ReportText.Heading(range));
                    if (!journal.GmtOffset.HasValue) text.AppendLine("DAY BASIS ASSUMED: broker UTC offset unavailable; New York + 7 fallback.");
                    var view = PanelMath.Build(journal, range, Limits);
                    text.AppendLine("Server: " + a.Server + " | Read at server time: " + journal.Exported.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
                    if (!string.IsNullOrEmpty(view.HistoryNote)) text.AppendLine("History note: " + view.HistoryNote);
                    text.AppendLine(ReportText.Student(new TextEntry { Number = n, Name = name, Login = a.Login, View = view }, TextParts.All));
                    }
                    catch (Exception e) { text.AppendLine("REPORT DETAILS UNAVAILABLE: " + name + " | " + a.Login + " | " + e.GetType().Name); }
                }
                string body = text.ToString();
                TextUtil.WriteLinesAtomically(Path.Combine(AppPaths.DataDir, "scheduled-last-report.txt"), new[] { body });
                scheduleLedger.Set("sending", reportResults.Counts() + "\r\n" + Lang.T("در حال ارسال به مقصدهای انتخاب‌شده…", "Sending to selected destinations…"));
                string subject = "MetaFactory report " + batch.StartedUtc.ToLocalTime().ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                var worker = new System.Threading.Thread(() =>
                {
                    string status; bool success;
                    try
                    {
                        var outcomes = ScheduledDelivery.Send(batch.Options, subject, body, () => scheduleCancel);
                        success = outcomes.Count > 0 && outcomes.All(o => o.Success);
                        status = string.Join("\r\n", outcomes.Select(o => o.Channel + ": " + (o.Success ? Lang.T("پذیرفته شد", "ACCEPTED") : o.Uncertain ? Lang.T("نتیجه نامشخص", "UNCERTAIN") : Lang.T("ناموفق", "FAILED")) + " — " + o.Detail));
                    }
                    catch (Exception e) { success = false; status = "Delivery failed: " + e.GetType().Name; }
                    try { BeginInvoke((Action)(() => { if (scheduledBatch == batch && !appClosing) ScheduleEnd(success ? "sent" : "delivery-failed", status); })); }
                    catch { /* State remains 'sending': after restart it is explicitly uncertain, never resent automatically. */ }
                }) { IsBackground = true, Name = "scheduled-delivery" };
                worker.Start();
            }
            catch (Exception e) { ScheduleEnd("failed", Lang.T("تهیه یا ذخیرهٔ گزارش ناموفق؛ ارسال انجام نشد: ", "Report preparation/storage failed; nothing sent: ") + e.GetType().Name); }
        }
    }
}
