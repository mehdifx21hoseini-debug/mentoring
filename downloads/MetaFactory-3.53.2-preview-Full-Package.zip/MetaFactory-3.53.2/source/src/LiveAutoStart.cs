using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
namespace MTManager
{
    // Invoked only by explicit manual Run, while the managed terminal is closed.
    public static class LiveAutoStart
    {
        static readonly object gate = new object();
        static DirectAccountVerifier symbolProbe;
        static string probeBase,probeServer;
        static volatile bool stopProbe;
        static DateTime probeUsed;
        static readonly System.Threading.Timer probeIdle=new System.Threading.Timer(delegate {
            if(!System.Threading.Monitor.TryEnter(gate))return;
            try { if(symbolProbe!=null && (DateTime.UtcNow-probeUsed).TotalSeconds>30)ReleaseProbe(); }
            catch(Exception e){Log.Write("symbol probe cleanup: "+e.GetType().Name);}
            finally{System.Threading.Monitor.Exit(gate);}
        },null,10000,10000);
        static void ReleaseProbe(){if(symbolProbe!=null)symbolProbe.Dispose();symbolProbe=null;probeBase=null;probeServer=null;}
        public static void StopSymbolProbe()
        {
            stopProbe=true;
            System.Threading.Tasks.Task.Run(delegate {lock(gate){ReleaseProbe();}});
        }
        static string AccountSymbol(Settings settings,Instance copy,Account account,string preferred,string[] candidates)
        {
            if(symbolProbe!=null && (probeBase!=settings.BaseDir || !string.Equals(probeServer,account.Server,StringComparison.OrdinalIgnoreCase)))ReleaseProbe();
            if(symbolProbe==null){symbolProbe=new DirectAccountVerifier(settings,901,copy.Dir);probeBase=settings.BaseDir;probeServer=account.Server;}
            var proof=account.Snapshot();proof.Platform="MT5";proof.VerifyToken=Guid.NewGuid().ToString("N");
            try
            {
                var result=symbolProbe.VerifySymbols(proof,8000,()=>stopProbe,delegate{},preferred,candidates);
                if(result!=null && result.Connected && result.ValidatedSymbol!=null)return result.ValidatedSymbol;
                if(result!=null)throw new UserMessage(result.Reason.Length>0?result.Reason:"symbol-unavailable");
                throw new UserMessage(Lang.T("نماد قابل خواندن برای همین حساب تأیید نشد؛ اتصال، نمادها و به‌روزرسانی MT5 را بررسی و دوباره اجرا کنید.","No readable symbol was confirmed for this account. Check its connection, symbols and MT5 update, then Run again."));
            }
            finally{probeUsed=DateTime.UtcNow;}
        }
        public static List<string> Prepare(Instance copy, Settings settings, Account account)
        {
            if (account == null || !account.HasLogin) return new List<string>();
            lock (gate)
            {
                if(stopProbe)throw new OperationCanceledException();
                string problem; var targets = LiveMonitorStore.Load(out problem);
                if (problem != null) throw new UserMessage(problem);
                string preferred=null;
                if(copy.Kind==Kind.MT5)
                {
                    foreach(string chart in ChartProfile.AllCharts(copy))
                    {preferred=ReportLaunch.ChartSymbol(TextFiles.ReadText(chart));if(preferred!=null)break;}
                    var candidates=ReportLaunch.KnownSymbols(copy,account.Server).Where(SafeSymbol).Distinct(StringComparer.OrdinalIgnoreCase).Take(200).ToArray();
                    string recent=OwnRecentSymbol(copy,account,targets,DateTime.UtcNow);
                    if(recent!=null && SafeSymbol(preferred) && candidates.Contains(preferred,StringComparer.OrdinalIgnoreCase))recent=preferred;
                    preferred=StartupHint(recent,preferred,candidates);
                    WriteSymbolCheck(copy,"local-startup-hint","No private terminal/probe on the launch path; native timer validates/replaces the display symbol after connection. | symbol="+preferred);

                }
                var target = targets.FirstOrDefault(t => t.Matches(copy, account)) ?? LiveMonitorTarget.Create(copy, account);
                var deployment = LiveReporter.Prepare(settings, copy, account, target.Token);
                string presetName = "MetaFactoryLive-" + target.Token + ".set";
                string content = LiveReporter.PresetText(account, target.Token);
                foreach(string preset in StartupPresetPaths(copy,presetName))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(preset));
                    Encoding encoding=copy.Kind==Kind.MT4?Encoding.Default:Encoding.Unicode;
                    if(File.Exists(preset) && File.ReadAllText(preset,encoding)!=content)
                        throw new UserMessage("Live startup preset differs; existing file was preserved.");
                    if(!File.Exists(preset))File.WriteAllText(preset,content,encoding);
                }
                WriteBootstrap(copy, account, target.Token);
                target.Guide = Lang.T("گزارش‌خوان با تنظیمات شروع خودکار آماده شد. پس از اجرا، ستون امروز خودکار به‌روز می‌شود؛ دریافت پیام تازه ملاک فعال‌شدن است.", "Reporter prepared for automatic startup. The Today column updates after Run; a fresh heartbeat confirms activation.");
                targets.RemoveAll(t => string.Equals(t.CopyName, copy.Name, StringComparison.OrdinalIgnoreCase)); targets.Add(target); LiveMonitorStore.Save(targets);
                var retired=LiveObserverMigration.RetireClosed(copy);
                string symbol = retired.Symbol;
                foreach (string chart in symbol==null?ChartProfile.AllCharts(copy):new List<string>())
                { symbol = ReportLaunch.ChartSymbol(TextFiles.ReadText(chart)); if (symbol != null) break; }
                symbol = symbol ?? "EURUSD";
                if(copy.Kind==Kind.MT5)symbol=preferred; // Exact-account proof or explicitly unverified own-cache hint; never a peer's symbol.
                string relative=LiveObserverMigration.FlatAlias(copy,deployment);
                var chartTexts = ChartProfile.AllCharts(copy).Select(TextFiles.ReadText).ToList();
                bool separate=retired.Period!=null && !chartTexts.Any(t=>string.Equals(ReportLaunch.ChartSymbol(t),symbol,StringComparison.OrdinalIgnoreCase) && LiveObserverMigration.PeriodOf(t)==retired.Period && t.IndexOf("<expert>",StringComparison.OrdinalIgnoreCase)>=0);
                string period = copy.Kind==Kind.MT5 ? "1" : separate ? retired.Period : FreePeriod(chartTexts, symbol, target.Token);
                if (copy.Kind == Kind.MT4) EnsureMt4Chart(copy, symbol, period);
                else EnsureMt5Profile(copy);
                var startup=Lines(copy.Kind, relative, presetName, symbol, period);
                string plan=Path.Combine(copy.Dir,Kinds.Mql(copy.Kind),"Files","MetaFactoryLive","launch-plan.txt");
                TextUtil.WriteLinesAtomically(plan,new[]{"MLPLAN\t1",DateTime.UtcNow.ToString("u"),"Platform="+copy.Kind,"ExpertRoot="+Path.Combine(copy.Dir,Kinds.Mql(copy.Kind),"Experts")}.Concat(startup));
                return startup;
            }
        }
        // Recent successful same-account startup is a cache hint, not current financial data.
        public static string OwnRecentSymbol(Instance copy,Account account,IEnumerable<LiveMonitorTarget> targets,DateTime utc)
        {
            foreach(var target in targets.Where(t=>t!=null && t.Matches(copy,account)))
            try
            {
                var frame=LiveFeedReader.Parse(ReadSymbolProof(target.SnapshotPath,Encoding.Unicode));
                if(frame==null || frame.Platform!="MT5" || frame.Token!=target.Token || frame.Login!=target.Login ||
                   !string.Equals(frame.Server,target.Server,StringComparison.OrdinalIgnoreCase) || !frame.Connected || frame.Revision<=0 ||
                   (frame.State!="ready" && frame.State!="stopped") || (utc-frame.Heartbeat).TotalHours>24 || (frame.Heartbeat-utc).TotalSeconds>5)continue;
                string path=Path.Combine(copy.Dir,"MQL5","Files","MetaFactoryLive","launch-plan.txt");
                if(File.GetLastWriteTimeUtc(path)>frame.Heartbeat)continue;
                string plan=ReadSymbolProof(path,Encoding.UTF8);
                if(plan==null || !plan.StartsWith("MLPLAN\t1") || !plan.Split('\n').Any(l=>l.Trim()=="Platform=MT5"))continue;
                string line=plan.Split('\n').Select(l=>l.Trim()).FirstOrDefault(l=>l.StartsWith("Symbol=",StringComparison.Ordinal));
                if(line!=null && SafeSymbol(line.Substring(7)))return line.Substring(7);
            }
            catch(IOException){}catch(UnauthorizedAccessException){}
            return null;
        }
        public static string StartupHint(string recent,string preferred,IEnumerable<string> candidates)
        {
            if(SafeSymbol(recent))return recent;
            var own=candidates.Where(SafeSymbol).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            if(SafeSymbol(preferred) && own.Contains(preferred,StringComparer.OrdinalIgnoreCase))return preferred;
            return own.FirstOrDefault() ?? (SafeSymbol(preferred)?preferred:"EURUSD");
        }
        public static string ChooseMt5StartupSymbol(Func<string> probe,string recent,string preferred,IEnumerable<string> candidates,Action<string,string> status)
        {
            if(SafeSymbol(recent)){status("recent-account-hint",recent);return recent;}
            try
            {
                string chosen=probe();
                if(!SafeSymbol(chosen))throw new InvalidDataException("symbol-unavailable");
                status("verified",chosen);return chosen;
            }
            catch(OperationCanceledException){throw;}
            catch(Exception e)
            {
                if(e is OutOfMemoryException)throw;
                string chosen=FallbackSymbol(preferred,candidates);
                status(chosen==null?"terminal-only":"unverified-fallback",e.GetType().Name+": "+e.Message+" | symbol="+(chosen??"none"));
                return chosen;
            }
        }
        public static bool SafeSymbol(string symbol)
        {return !string.IsNullOrWhiteSpace(symbol) && symbol.Length<=40 && !symbol.Any(char.IsControl) && !symbol.Contains("<") && !symbol.Contains(">");}
        // Cached names are hints only. They are never used as a fresh Live proof.
        public static string FallbackSymbol(string preferred,IEnumerable<string> ownSymbols)
        {
            var known=ownSymbols.Where(SafeSymbol).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            return known.FirstOrDefault(s=>!string.Equals(s,preferred,StringComparison.OrdinalIgnoreCase)) ?? known.FirstOrDefault();
        }
        static void WriteSymbolCheck(Instance copy,string state,string detail)
        {
            try{
                string path=Path.Combine(copy.Dir,"MQL5","Files","MetaFactoryLive","symbol-check.txt");
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                if(detail!=null && detail.Length>1800)detail=detail.Substring(0,1800);
                TextUtil.WriteLinesAtomically(path,new[]{DateTime.UtcNow.ToString("u"),"Status="+state,TextUtil.OneLine(detail??"")});
            }catch(IOException){}catch(UnauthorizedAccessException){}
        }
        public static string[] StartupPresetPaths(Instance copy,string name)
        {
            if(Path.GetFileName(name)!=name || name.IndexOfAny(new[]{'/', '\\'})>=0 || name.Any(char.IsControl))throw new ArgumentException("Invalid preset name.");
            return copy.Kind==Kind.MT4 ? new[]{Path.Combine(copy.Dir,"presets",name)}
                : new[]{Path.Combine(copy.Dir,"MQL5","Presets",name),Path.Combine(copy.Dir,"MQL5","Profiles","Presets",name)};
        }
        // A current ready observer is stronger startup evidence than an old history directory.
        // Read only small proofs, with delete-sharing so snapshot publication is never held open.
        static string ReadSymbolProof(string path,Encoding encoding)
        {
            using(var file=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))
            {
                if(file.Length==0 || file.Length>8192)return null;
                using(var reader=new StreamReader(file,encoding,true))return reader.ReadToEnd();
            }
        }
        public static string Mt5LiveSymbol(IEnumerable<LiveMonitorTarget> targets,string server,DateTime utc)
        {
            foreach(var target in targets.Where(t=>t!=null && t.Valid && t.Platform=="MT5" && string.Equals(t.Server,server,StringComparison.OrdinalIgnoreCase)).Take(200))
            {
                try
                {
                    var frame=LiveFeedReader.Parse(ReadSymbolProof(target.SnapshotPath,Encoding.Unicode));
                    if(frame==null || frame.Platform!="MT5" || frame.Token!=target.Token || frame.Login!=target.Login ||
                       !string.Equals(frame.Server,server,StringComparison.OrdinalIgnoreCase) || !frame.Connected || frame.State!="ready" || frame.Revision<=0 ||
                       (utc-frame.Heartbeat).TotalSeconds>LiveFeedReader.StaleSeconds || (frame.Heartbeat-utc).TotalSeconds>LiveFeedReader.FutureSeconds)continue;
                    string plan=Path.Combine(target.Directory,"MQL5","Files","MetaFactoryLive","launch-plan.txt");
                    if(File.GetLastWriteTimeUtc(plan)>frame.Heartbeat)continue;
                    string text=ReadSymbolProof(plan,Encoding.UTF8);
                    if(text==null || !text.StartsWith("MLPLAN\t1") || !text.Split('\n').Any(x=>x.Trim()=="Platform=MT5"))continue;
                    string symbol=text.Split('\n').Select(x=>x.Trim()).FirstOrDefault(x=>x.StartsWith("Symbol=",StringComparison.Ordinal));
                    if(symbol==null)continue;symbol=symbol.Substring(7);
                    if(symbol.Length==0 || symbol.Length>40 || symbol.Any(char.IsControl) || symbol.Contains("<") || symbol.Contains(">"))continue;
                    return symbol;
                }
                catch(IOException){}catch(UnauthorizedAccessException){}
            }
            return null;
        }
        public static List<string> Mt5KnownSymbols(Settings settings,Instance copy,string server)
        {
            var known=ReportLaunch.KnownSymbols(copy,server);
            if(known.Count>0)return known;
            string reports=ReportLaunch.ReportRoot(settings.BaseDir);
            if(Directory.Exists(reports))foreach(string dir in Directory.GetDirectories(reports).Take(200))
                known.AddRange(ReportLaunch.KnownSymbols(new Instance{Kind=Kind.MT5,Dir=dir},server));
            if(known.Count==0)
            {
                bool sure;string install=ServerCatalog.InstallFor(Kind.MT5,server,settings,out sure);
                if(install!=null)foreach(string dir in PortableServers.Roots(install))
                    known.AddRange(ReportLaunch.KnownSymbols(new Instance{Kind=Kind.MT5,Dir=dir},server));
            }
            return known.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }
        public static string Mt5Symbol(string preferred,System.Collections.Generic.IList<string> known)
        {return ReportLaunch.PickSymbol(preferred,known)??preferred??"EURUSD";}
        public static void EnsureMt5Profile(Instance copy)
        {
            if(copy.Kind!=Kind.MT5)return;
            string dir=Path.Combine(copy.Dir,"MQL5","Profiles","Charts",Launcher.LiveMt5ProfileName);
            if(Directory.Exists(dir) && Directory.EnumerateFileSystemEntries(dir).Any())
            {
                string backup=Path.Combine(copy.Dir,"MTManager-backup","mt5-live-profile");Directory.CreateDirectory(backup);
                Directory.Move(dir,Path.Combine(backup,DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N")));
            }
            Directory.CreateDirectory(dir);
        }
        public const string Mt4ProfileName = "MetaFactoryLiveOnly";
        // StartUp Expert+Symbol creates the observer chart. A preloaded chart would be a duplicate.
        // Only the private profile is reset; every previous file is moved intact into a backup.
        public static void EnsureMt4Chart(Instance copy, string symbol, string period)
        {
            if (copy.Kind != Kind.MT4) return;
            if (string.IsNullOrWhiteSpace(symbol) || symbol.Any(char.IsControl) || symbol.Contains("<") || symbol.Contains(">"))
                throw new ArgumentException("Invalid observer chart symbol.");
            int minutes;
            if (!int.TryParse(period, out minutes) || !new[] {1,5,15,30,60,240,1440,10080,43200}.Contains(minutes))
                throw new ArgumentException("Invalid observer chart timeframe.");
            string profiles=Path.Combine(copy.Dir,"profiles"), last=Path.Combine(profiles,"lastprofile.ini");
            string selected=Path.Combine(profiles,Mt4ProfileName);
            Directory.CreateDirectory(profiles);
            string backupRoot=Path.Combine(copy.Dir,"MTManager-backup","single-live-profile");
            if(Directory.Exists(selected) && Directory.EnumerateFileSystemEntries(selected).Any())
            {
                Directory.CreateDirectory(backupRoot);
                Directory.Move(selected,Path.Combine(backupRoot,DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N")));
            }
            Directory.CreateDirectory(selected);
            if(File.Exists(last) && File.ReadAllText(last).Trim()!=Mt4ProfileName)
            {
                Directory.CreateDirectory(backupRoot);
                File.Copy(last,Path.Combine(backupRoot,"lastprofile-"+Guid.NewGuid().ToString("N")+".ini.bak"),false);
            }
            string temp=last+".live-"+Guid.NewGuid().ToString("N");
            try { File.WriteAllText(temp,Mt4ProfileName,Encoding.ASCII);
                if(File.Exists(last))File.Replace(temp,last,null);else File.Move(temp,last); }
            finally { if(File.Exists(temp))File.Delete(temp); }
        }
        public static string InitStatus(Instance copy)
        {
            try
            {
                string path=Path.Combine(copy.Dir,Kinds.Mql(copy.Kind),"Files","MetaFactoryLive","init-status.txt");
                var info=new FileInfo(path);
                if(!info.Exists || info.Length>4096)return "";
                return info.LastWriteTimeUtc.ToString("u")+" "+TextFiles.ReadText(path);
            }
            catch { return ""; }
        }
        internal static string SnapshotTransportDiagnostic(string path,LiveMonitorTarget binding)
        {
            try
            {
                var info=new FileInfo(path);if(!info.Exists)return "Transport "+Path.GetFileName(path)+": missing";
                string prefix="Transport "+Path.GetFileName(path)+": bytes="+info.Length+" UTC="+info.LastWriteTimeUtc.ToString("u");
                if(info.Length>8192)return prefix+"; frame details omitted (diagnostic size bound)";
                var frame=LiveFeedReader.Parse(ReadSymbolProof(path,Encoding.Unicode));
                if(frame==null)return prefix+"; incomplete/invalid frame (not financial proof)";
                bool matches=binding!=null && frame.Token==binding.Token && frame.Login==binding.Login && frame.Platform==binding.Platform && string.Equals(frame.Server,binding.Server,StringComparison.OrdinalIgnoreCase);
                return prefix+"; state="+frame.State+" connected="+frame.Connected+" binding-match="+matches+" sequence="+frame.Sequence+" history-revision="+frame.Revision+" heartbeat-age-seconds="+(DateTime.UtcNow-frame.Heartbeat).TotalSeconds.ToString("0.0",System.Globalization.CultureInfo.InvariantCulture)+" (transport only; not financial proof)";
            }
            catch(Exception e){return "Transport "+Path.GetFileName(path)+": unavailable "+e.GetType().Name;}
        }
        public static string Diagnostics(IEnumerable<Instance> copies)
        {
            var rows=new List<string>();string storeProblem;var bindings=LiveMonitorStore.Load(out storeProblem);
            foreach(var copy in copies.Take(500))
            {
                string status=InitStatus(copy);
                if(copy.Kind==Kind.MT5)
                {
                    string check=Path.Combine(copy.Dir,"MQL5","Files","MetaFactoryLive","symbol-check.txt");
                    try{if(File.Exists(check) && new FileInfo(check).Length<=4096)rows.Add(copy.Name+" symbol preparation: "+TextFiles.ReadText(check));}catch(IOException){}catch(UnauthorizedAccessException){}
                }
                var lines=new List<string>();
                foreach(DateTime day in new[]{DateTime.Today.AddDays(-1),DateTime.Today})
                    lines.AddRange(ReportDiagnostics.Tail(ReportTrace.ProgramsLog(copy,day),day,day)
                        .Where(l=>l.IndexOf("MTManagerLive",StringComparison.OrdinalIgnoreCase)>=0 || l.IndexOf("MF_Live_",StringComparison.OrdinalIgnoreCase)>=0 || l.IndexOf("MetaFactory Live",StringComparison.OrdinalIgnoreCase)>=0));
                foreach(DateTime day in new[]{DateTime.Today.AddDays(-1),DateTime.Today})
                    lines.AddRange(ReportDiagnostics.Tail(ConnectionCheck.JournalFile(copy,day),day,day)
                        .Where(l=>l.IndexOf("expert",StringComparison.OrdinalIgnoreCase)>=0 || l.IndexOf("MF_Live_",StringComparison.OrdinalIgnoreCase)>=0 || l.IndexOf("MTManagerLive",StringComparison.OrdinalIgnoreCase)>=0 || l.IndexOf("Data Folder",StringComparison.OrdinalIgnoreCase)>=0 || l.IndexOf("config",StringComparison.OrdinalIgnoreCase)>=0).Select(l=>"Terminal: "+l));
                string dataRoot=Path.Combine(copy.Dir,Kinds.Mql(copy.Kind),"Files","MetaFactoryLive");
                string bootstrap=Path.Combine(dataRoot,"bootstrap.txt");
                if(status.Length==0 && lines.Count==0 && !File.Exists(bootstrap))continue;
                rows.Add("Expected Files root: "+dataRoot+" | bootstrap="+File.Exists(bootstrap));
                var binding=bindings.FirstOrDefault(t=>t.CopyName.Equals(copy.Name,StringComparison.OrdinalIgnoreCase));
                if(binding!=null){var active=new FileInfo(binding.SnapshotPath);rows.Add("Active session snapshot: "+binding.SnapshotPath+" | "+(active.Exists?active.Length+" bytes UTC="+active.LastWriteTimeUtc.ToString("u"):"missing"));rows.Add(SnapshotTransportDiagnostic(binding.SnapshotPath,binding));rows.Add(SnapshotTransportDiagnostic(binding.SnapshotPath+".fallback",binding));}
                if(Directory.Exists(dataRoot))foreach(string directory in Directory.GetDirectories(dataRoot).Take(4))
                {string snapshot=Path.Combine(directory,"snapshot.txt");var info=new FileInfo(snapshot);rows.Add("Snapshot "+Path.GetFileName(directory)+": "+(info.Exists?info.Length+" bytes UTC="+info.LastWriteTimeUtc.ToString("u"):"missing"));}
                rows.Add(copy.Name+" [startup diagnostics; not proof of a fresh live feed]");
                if(status.Length>0)rows.Add(status);
                string plan=Path.Combine(dataRoot,"launch-plan.txt");
                if(File.Exists(plan) && new FileInfo(plan).Length<=8192)rows.Add("Startup plan (no password): "+TextFiles.ReadText(plan));
                rows.AddRange(lines.Skip(Math.Max(0,lines.Count-20)));
            }
            return "\r\n— Live observer initialization —\r\n"+string.Join("\r\n",rows)+"\r\n";
        }
        public static string BootstrapText(Account account, string token)
        {
            LiveReporter.PresetText(account, token); // same strict identity validation as presets
            return "MLBOOT\t1\r\n" + LiveReporter.ValidateToken(token) + "\r\n" + long.Parse(account.Login.Trim()).ToString(System.Globalization.CultureInfo.InvariantCulture) + "\r\n" + account.Server.Trim() + "\r\n";
        }
        public static void WriteBootstrap(Instance copy, Account account, string token)
        {
            string directory = Path.Combine(copy.Dir, Kinds.Mql(copy.Kind), "Files", "MetaFactoryLive");
            Directory.CreateDirectory(directory);
            string path = Path.Combine(directory, "bootstrap.txt"), temp = path + ".tmp-" + Guid.NewGuid().ToString("N");
            try
            {
                File.WriteAllText(temp, BootstrapText(account, token), Encoding.Unicode);
                if (File.Exists(path)) File.Replace(temp, path, null); else File.Move(temp, path);
            }
            finally { if(File.Exists(temp)) File.Delete(temp); }
        }
        public static string FreePeriod(IEnumerable<string> charts, string symbol, string token)
        {
            var occupied = new HashSet<int>();
            foreach (string text in charts)
            {
                if (!string.Equals(ReportLaunch.ChartSymbol(text), symbol, StringComparison.OrdinalIgnoreCase)) continue;
                var match = System.Text.RegularExpressions.Regex.Match(text ?? "", @"(?im)^period=(\d+)\s*$");
                int period;
                if (!match.Success)
                {
                    var size = System.Text.RegularExpressions.Regex.Match(text ?? "", @"(?im)^period_size=(\d+)\s*$");
                    var type = System.Text.RegularExpressions.Regex.Match(text ?? "", @"(?im)^period_type=(\d+)\s*$");
                    int n, unit;
                    if (size.Success && type.Success && int.TryParse(size.Groups[1].Value,out n) && int.TryParse(type.Groups[1].Value,out unit))
                    { int[] factors = {1,60,1440,10080,43200}; if(unit>=0 && unit<factors.Length && n>0 && n<=43200) { occupied.Add(n*factors[unit]); continue; } }
                }
                if (!match.Success || !int.TryParse(match.Groups[1].Value, out period))
                    throw new UserMessage("Cannot identify an existing chart timeframe; automatic live attachment stopped to preserve its EA.");
                if ((text ?? "").Contains("MTManagerLive") && (text ?? "").Contains(token)) return period.ToString();
                occupied.Add(period);
            }
            foreach (int period in new[] { 1, 5, 15, 30, 60, 240, 1440, 10080, 43200 })
                if (!occupied.Contains(period)) return period.ToString();
            throw new UserMessage("No separate chart timeframe is available for the live observer; existing EAs were preserved.");
        }
        public static List<string> Lines(Kind kind, string expert, string preset, string symbol, string period = "1")
        {
            foreach (string value in new[] { expert, preset, symbol, period })
                if (string.IsNullOrWhiteSpace(value) || value.Any(char.IsControl)) throw new ArgumentException("Invalid live startup parameter.");
            var lines = new List<string>();
            if (kind == Kind.MT5) { lines.Add("[Experts]"); lines.Add("AllowLiveTrading=0"); lines.Add("[StartUp]"); }
            else lines.Add("ExpertsDllImport=true"); // MT4 All History requires DLL; trading permissions unchanged
            lines.Add("Expert=" + expert); lines.Add("ExpertParameters=" + preset);
            lines.Add("Symbol=" + symbol); int minutes = int.Parse(period);
            string frame = minutes < 60 ? "M" + minutes : minutes < 1440 ? "H" + (minutes / 60) : minutes == 1440 ? "D1" : minutes == 10080 ? "W1" : "MN1";
            lines.Add("Period=" + (kind == Kind.MT5 ? frame : period));
            lines.Add(kind == Kind.MT5 ? "ShutdownTerminal=0" : "ShutdownTerminal=false");
            return lines;
        }
    }
}
