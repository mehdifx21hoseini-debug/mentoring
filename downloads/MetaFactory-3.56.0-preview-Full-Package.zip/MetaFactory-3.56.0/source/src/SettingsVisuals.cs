using System;using System.IO;using System.Linq;using System.Drawing;using System.Windows.Forms;
namespace MTManager
{
    sealed class SettingsToggle : CheckBox
    {
        public SettingsToggle(){AutoSize=false;Size=new Size(Theme.S(310),Theme.S(32));SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);AccessibleRole=AccessibleRole.CheckButton;Cursor=Cursors.Hand;}
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent==null?Theme.Surface:Parent.BackColor);e.Graphics.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            int size=Theme.S(20),x=Lang.En?Theme.S(4):Width-Theme.S(24),y=(Height-size)/2;
            var box=new Rectangle(x,y,size,size);Theme.Box(e.Graphics,box,Theme.Sf(4),Checked?Theme.Accent:Theme.Surface,Enabled?(Checked?Theme.Accent:Theme.BorderStrong):Theme.Border);
            if(Checked)Glyphs.Draw(e.Graphics,Glyph.Check,new RectangleF(x+Theme.S(3),y+Theme.S(3),size-Theme.S(6),size-Theme.S(6)),Color.White);
            var label=Lang.En?new Rectangle(box.Right+Theme.S(8),0,Math.Max(0,Width-box.Right-Theme.S(12)),Height):new Rectangle(Theme.S(4),0,Math.Max(0,box.Left-Theme.S(12)),Height);
            Theme.Line(e.Graphics,Text,Font,label,Enabled?Theme.Text:Theme.Muted);
            if(Focused)ControlPaint.DrawFocusRectangle(e.Graphics,new Rectangle(0,0,Width-1,Height-1));
        }
    }
    sealed class SilverCategoryTab : ModernButton
    {
        internal SilverCategoryTab(string text):base(text,ButtonKind.Subtle){}
        protected override void OnPaint(PaintEventArgs e){e.Graphics.Clear(Theme.Surface);bool on=Kind==ButtonKind.Primary;Theme.Line(e.Graphics,Text,on?Theme.Bold:Theme.Font,ClientRectangle,on?Theme.Accent:Theme.Muted,true);if(on)using(var pen=new Pen(Theme.Accent,Theme.S(2)))e.Graphics.DrawLine(pen,Theme.S(8),Height-Theme.S(2),Width-Theme.S(8),Height-Theme.S(2));if(Focused)ControlPaint.DrawFocusRectangle(e.Graphics,Rectangle.Inflate(ClientRectangle,-3,-3));}
    }
    sealed class SettingsDialog : Form
    {
        readonly Settings settings;
        readonly TextBox folder = new TextBox { Width = Theme.S(320), RightToLeft = RightToLeft.No };
        readonly Stepper delay = new Stepper(0, 120);
        readonly DropBox reportAtOnce = new DropBox(330) { PickOnly = true, Margin = Padding.Empty };
        readonly CheckBox normalRights = new SettingsToggle { Text = Lang.T("اجرای عادی متاتریدر، بدون درخواست دسترسی مدیر", "Run MetaTrader at current privilege level"), AutoSize = false };
        readonly CheckBox pauseMt5Updates = new SettingsToggle { Text = Lang.T("اجرای MT5 بدون به‌روزرسانی خودکار", "Run MT5 without automatic updates"), AutoSize = false };
        readonly CheckBox sandboxOverflow = new SettingsToggle { Text = Lang.T("اجرای MT4های اضافی با Sandboxie نصب‌شده", "Use installed Sandboxie for additional MT4 copies"), AutoSize = false };
        readonly CheckBox minimized = new SettingsToggle { Text = Lang.T("نسخه‌ها کوچک‌شده باز شوند", "Start the copies minimized"), AutoSize = false };
        readonly CheckBox light = new SettingsToggle { Text = Lang.T("حالت سبک: اخبار خاموش؛ چارت‌های MT5 حداکثر ۵۰۰ کندل", "Light mode: news off; MT5 charts limited to 500 candles"), AutoSize = false };
        readonly CheckBox autostart = new SettingsToggle { Text = Lang.T("بعد از روشن شدن ویندوز، همه‌ی نسخه‌ها خودشان باز شوند (برای VPS)", "When Windows starts, all copies open by themselves (for a VPS)"), AutoSize = false };
        readonly DropBox startCharts = new DropBox(330) { PickOnly = true, Margin = Padding.Empty };
        // 3.27 (CHANGE-019): the program's language; the window is made again when it changes.
        readonly DropBox language = new DropBox(330) { PickOnly = true, Margin = Padding.Empty };
        static readonly string[] ChartModeList = { ChartModes.Empty, ChartModes.One, ChartModes.All };
        readonly CheckBox lowPriority = new SettingsToggle { Text = Lang.T("متاتریدرهای پشت صحنه با اولویت پایین‌تر اجرا شوند", "Run background MetaTraders at a lower priority"), AutoSize = false };
        readonly CheckBox trimMemory = new SettingsToggle { Text = Lang.T("حافظهٔ متاتریدرهای کوچک‌شدهٔ بدون پایش زنده به ویندوز برگردد", "Return memory of minimized MetaTraders without live monitoring to Windows"), AutoSize = false };


        readonly Panel pageHost=new Panel{Dock=DockStyle.Fill};
        readonly Panel[] pages=new Panel[2];
        readonly ModernButton[] pageButtons=new ModernButton[2];
        readonly ScheduleDialog deliveryEditor;
        readonly Action<ScheduleOptions> saveDelivery;
        readonly Label saveError=new Label{AutoSize=true,ForeColor=Theme.Bad};
        public ScheduleOptions DeliveryOptions {get;private set;}
        public bool SettingsApplied {get;private set;}
        internal int SelectedPage {get;private set;}
        public SettingsDialog(Settings settings):this(settings,null,null,null,false){}
        public SettingsDialog(Settings settings,ScheduleOptions delivery,string deliveryStatus,Action<ScheduleOptions> onSaveDelivery,bool initialDelivery)
        {
            this.settings=settings;saveDelivery=onSaveDelivery;
            Text=Lang.T("تنظیمات","Settings");Font=Theme.Font;ForeColor=Theme.Text;BackColor=Theme.Surface;
            RightToLeft=Theme.Dir;RightToLeftLayout=false;FormBorderStyle=FormBorderStyle.FixedDialog;
            MaximizeBox=false;MinimizeBox=false;ShowIcon=false;ShowInTaskbar=false;StartPosition=FormStartPosition.CenterParent;
            ClientSize=new Size(Theme.S(760),Theme.S(560));AutoSize=false;Theme.Window(this);
            folder.Text=settings.BaseDir;folder.Width=Theme.S(275);
            delay.Value=Math.Max(0,Math.Min(120,settings.DelaySeconds));minimized.Checked=settings.Minimized;
            normalRights.Checked=settings.NormalTerminalRights;sandboxOverflow.Checked=settings.SandboxieOverflow;pauseMt5Updates.Checked=settings.PauseMt5Updates;
            startCharts.SetItems(new[]{Lang.T("بدون چارت (سبک‌ترین)","No charts (lightest)"),Lang.T("یک چارت","One chart"),Lang.T("همهٔ چارت‌ها","All charts")});
            startCharts.SelectedIndex=Math.Max(0,Array.IndexOf(ChartModeList,settings.StartCharts));
            lowPriority.Checked=settings.LowPriority;trimMemory.Checked=settings.TrimMemory;light.Checked=settings.Light;autostart.Checked=settings.AutoStart;
            language.SetItems(new[]{"فارسی (راست‌چین)","English (left to right)"});language.SelectedIndex=settings.Language=="en"?1:0;
            int auto=ReportParallel.Auto(Environment.ProcessorCount,Checks.TotalRamMb(),Checks.FreeRamMb());
            reportAtOnce.SetItems(new[]{Lang.T("خودکار (ظرفیت فعلی: ","Automatic (current capacity: ")+Fa.N(auto)+Lang.T(" هم‌زمان)"," at a time)"),Lang.T("یکی‌یکی","one by one"),Lang.T("حداکثر ۲ هم‌زمان","Up to 2 at a time"),Lang.T("حداکثر ۳ هم‌زمان","Up to 3 at a time"),Lang.T("حداکثر ۴ هم‌زمان","Up to 4 at a time")});
            reportAtOnce.SelectedIndex=ReportParallel.Clamp(settings.ReportAtOnce);
            deliveryEditor=new ScheduleDialog(delivery,deliveryStatus);
            var layout=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Padding=Padding.Empty,Margin=Padding.Empty,RightToLeft=RightToLeft.No};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,Theme.S(54)));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,Theme.S(62)));
            var heading=Theme.GraphiteHeader(Lang.T("تنظیمات","Settings"));heading.Dock=DockStyle.Fill;layout.Controls.Add(heading,0,0);
            var workspace=new Panel{Dock=DockStyle.Fill,Margin=Padding.Empty,BackColor=Theme.Surface};
            var navigation=new FlowLayoutPanel{Dock=DockStyle.Top,Height=Theme.S(52),FlowDirection=Lang.En?FlowDirection.LeftToRight:FlowDirection.RightToLeft,WrapContents=false,Padding=Theme.Pad(18,4),Margin=Padding.Empty,BackColor=Theme.Surface};
            string[] titles={Lang.T("عمومی و اجرا","General and running"),Lang.T("ربات‌ها و ارسال","Bots and delivery")};
            for(int k=0;k<2;k++){int index=k;var button=new SilverCategoryTab(titles[k]);button.Click+=(sender,args)=>ShowPage(index);button.MinimumSize=new Size(Theme.S(170),Theme.S(36));button.Margin=Theme.Pad(4,2);pageButtons[k]=button;navigation.Controls.Add(button);}
            pageHost.Dock=DockStyle.Fill;pageHost.Padding=Theme.Pad(24,8,24,4);workspace.Controls.Add(pageHost);workspace.Controls.Add(navigation);layout.Controls.Add(workspace,0,1);
            for(int k=0;k<2;k++){pages[k]=new Panel{Dock=DockStyle.None,AutoScroll=true,Padding=Theme.Pad(4,4,4,4),BackColor=Theme.Surface};pageHost.Controls.Add(pages[k]);}
            var general=FormRows(pages[0]);var folderLine=new TableLayoutPanel{AutoSize=false,Height=Theme.S(42),Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=Padding.Empty,RightToLeft=RightToLeft.No};folderLine.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));folderLine.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(96)));folder.Dock=DockStyle.Fill;folder.Margin=Padding.Empty;folderLine.Controls.Add(folder,0,0);
            var browse=new ModernButton(Lang.T("انتخاب…","Choose…"),ButtonKind.Secondary,Glyph.Folder,Glyph.None,true){Dock=DockStyle.Fill,Margin=Theme.Pad(4,0,0,0)};browse.Click+=Browse;folderLine.Controls.Add(browse,1,0);
            var seconds=new FlowLayoutPanel{AutoSize=true,WrapContents=false,Margin=Padding.Empty,RightToLeft=RightToLeft.No};seconds.Controls.Add(delay);seconds.Controls.Add(Theme.Label(Lang.T("ثانیه","seconds"),0,Theme.Small,Theme.Muted));
            FormRow(general,Lang.T("پوشهٔ نسخه‌ها","Copies folder"),folderLine);FormRow(general,Lang.T("زبان","Language"),language);FormRow(general,Lang.T("فاصلهٔ اجرا","Start interval"),seconds);FormRow(general,Lang.T("خواندن هم‌زمان","Concurrent reports"),reportAtOnce);FormRow(general,Lang.T("چارت نسخه‌ها","Investor-copy charts"),startCharts);
            var options=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=false,Height=Theme.S(124),ColumnCount=2,RowCount=4,RightToLeft=Theme.Dir,Margin=Padding.Empty,Padding=Theme.Pad(0,3)};
            options.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));options.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));
            var checks=new[]{autostart,minimized,light,lowPriority,pauseMt5Updates,sandboxOverflow,normalRights,trimMemory};
            var checkTitles=new[]{Lang.T("اجرای همه با ویندوز","Start all with Windows"),Lang.T("باز شدن کوچک‌شده","Start minimized"),Lang.T("حالت سبک","Light mode"),Lang.T("اولویت کمتر پردازنده","Lower process priority"),Lang.T("MT5 بدون به‌روزرسانی خودکار","Pause MT5 automatic updates"),Lang.T("MT4 اضافه با Sandboxie","Extra MT4 via Sandboxie"),Lang.T("اجرا با دسترسی فعلی ویندوز","Use current Windows privileges"),Lang.T("آزادسازی حافظهٔ نسخه‌های بدون پایش","Reclaim idle terminal memory")};
            for(int i=0;i<4;i++)options.RowStyles.Add(new RowStyle(SizeType.Percent,25));
            for(int i=0;i<checks.Length;i++){checks[i].AccessibleDescription=checks[i].Text;checks[i].Text=checkTitles[i];checks[i].AccessibleName=checkTitles[i];checks[i].Dock=DockStyle.Fill;checks[i].Margin=Theme.Pad(2,0,4,0);options.Controls.Add(checks[i],i%2,i/2);}
            int optionsRow=general.RowCount++;general.RowStyles.Add(new RowStyle(SizeType.AutoSize));general.Controls.Add(options,0,optionsRow);general.SetColumnSpan(options,2);
            var content=deliveryEditor.EditorContent;content.Dock=DockStyle.Fill;pages[1].Controls.Add(content);
            saveError.Font=Theme.Small;saveError.Visible=false;saveError.MaximumSize=new Size(Theme.S(660),0);saveError.Dock=DockStyle.Bottom;pageHost.Controls.Add(saveError);saveError.BringToFront();
            var footer=new ButtonRow{Dock=DockStyle.Fill};var ok=footer.Add(new ModernButton(Lang.T("ذخیره تغییرات","Save changes"),Save,ButtonKind.Primary));var cancel=footer.Add(new ModernButton(Lang.T("انصراف","Cancel"),(sender,args)=>{DialogResult=DialogResult.Cancel;Close();}));layout.Controls.Add(footer,0,2);
            AcceptButton=ok;CancelButton=cancel;Controls.Add(layout);pageHost.Layout+=(sender,args)=>FitSettingsPages();Theme.StyleInputs(this);ShowPage(initialDelivery?1:0);FitSettingsPages();
        }
        bool sizingPages;
        void FitSettingsPages(){if(sizingPages)return;sizingPages=true;try{int width=Math.Max(1,Math.Min(Theme.S(800),pageHost.ClientSize.Width-pageHost.Padding.Horizontal));int height=Math.Max(1,pageHost.ClientSize.Height-pageHost.Padding.Vertical-(saveError.Visible?saveError.Height:0));var bounds=new Rectangle(Math.Max(0,(pageHost.ClientSize.Width-width)/2),pageHost.Padding.Top,width,height);foreach(var page in pages)if(page!=null&&page.Bounds!=bounds)page.Bounds=bounds;}finally{sizingPages=false;}}
        static TableLayoutPanel FormRows(Panel parent)
        {
            var table=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=2,GrowStyle=TableLayoutPanelGrowStyle.AddRows,RightToLeft=Theme.Dir,Margin=Padding.Empty,Padding=Padding.Empty};
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,43));table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,57));parent.Controls.Add(table);return table;
        }
        static void FormRow(TableLayoutPanel table,string title,Control control)
        {
            int row=table.RowCount++;table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var label=Theme.Label(title,0,Theme.Font,Theme.Text);label.AutoSize=true;label.MaximumSize=new Size(Theme.S(280),0);label.Anchor=AnchorStyles.Left|AnchorStyles.Right;label.Margin=Theme.Pad(4,2,8,2);
            control.Margin=Theme.Pad(6,1,4,1);control.Anchor=AnchorStyles.Left|AnchorStyles.Right;
            if(control is CheckBox){control.Anchor=Lang.En?AnchorStyles.Right:AnchorStyles.Left;control.AccessibleName=control.Text;}
            table.Controls.Add(label,0,row);table.Controls.Add(control,1,row);
        }
        internal void ShowPage(int index)
        {
            index=Math.Max(0,Math.Min(1,index));SelectedPage=index;
            for(int k=0;k<2;k++){pages[k].Visible=k==index;pageButtons[k].Kind=k==index?ButtonKind.Primary:ButtonKind.Subtle;}
            pages[index].BringToFront();if(saveError.Visible)saveError.BringToFront();
        }
        protected override void OnShown(EventArgs e)
        {
            var area=Screen.FromControl(this).WorkingArea;Size=new Size(Math.Min(Width,area.Width-20),Math.Min(Height,area.Height-20));base.OnShown(e);
        }
        internal void SetBotStatus(Func<string,string> provider){deliveryEditor.SetBotStatus(provider);}
        protected override void Dispose(bool disposing){if(disposing)deliveryEditor.Dispose();base.Dispose(disposing);}
        void Browse(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog { Description = Lang.T("پوشه‌ای برای نسخه‌ها (نه داخل Program Files)", "A folder for the copies (not inside Program Files)") })
            {
                if (Directory.Exists(folder.Text)) fbd.SelectedPath = folder.Text;
                if (fbd.ShowDialog(this) == DialogResult.OK) folder.Text = fbd.SelectedPath;
            }
        }

        void Save(object sender, EventArgs e)
        {
            ScheduleOptions candidate=null;
            if(deliveryEditor.IsDirty && !deliveryEditor.TryCollect(out candidate)){ShowPage(1);return;}
            string dir = folder.Text.Trim().Trim('"').TrimEnd('\\');
            if (dir.Length == 0) { Ui.Message(this, Lang.T("یک پوشه انتخاب کنید.", "Choose a folder."), MessageBoxIcon.Warning); return; }
            if (dir.IndexOf("Program Files", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                Ui.Message(this, Lang.T("داخل Program Files نه: نسخه‌ها باید بتوانند در پوشه‌ی خودشان بنویسند.", "Not inside Program Files: the copies must be able to write in their own folder."), MessageBoxIcon.Warning);
                return;
            }
            if (dir.Length <= 2) dir += @"\MetaTrader";  // a drive root gets its own folder
            if (!Checks.CanWrite(dir)) { Ui.Message(this, Lang.T("در این پوشه نمی‌شود نوشت. پوشه‌ی دیگری انتخاب کنید.", "Cannot write in this folder. Choose another folder."), MessageBoxIcon.Warning); return; }
            try { AutoStart.Set(autostart.Checked, Application.ExecutablePath); }
            catch (Exception ex) { Ui.Error(this, ex); return; }
            settings.UseFolder(dir);  // the folder used before stays listed, with its copies
            settings.Language = language.SelectedIndex == 1 ? "en" : "fa";
            settings.DelaySeconds = delay.Value;
            settings.ReportAtOnce = Math.Max(0, reportAtOnce.SelectedIndex);
            settings.Minimized = minimized.Checked;
            settings.NormalTerminalRights = normalRights.Checked;
            settings.SandboxieOverflow = sandboxOverflow.Checked;
            settings.PauseMt5Updates = pauseMt5Updates.Checked;
            if(!settings.PauseMt5Updates)Mt5UpdatePolicy.RestoreAll();
            settings.Light = light.Checked;
            settings.AutoStart = autostart.Checked;
            settings.StartCharts = ChartModeList[Math.Max(0, startCharts.SelectedIndex)];
            settings.LightCharts = settings.StartCharts != ChartModes.All;
            settings.LowPriority = lowPriority.Checked;
            settings.TrimMemory = trimMemory.Checked;
            try
            {
                settings.Save();SettingsApplied=true;
                if(candidate!=null && saveDelivery!=null)saveDelivery(candidate);
                DeliveryOptions=candidate;
                DialogResult=DialogResult.OK;Close();
            }
            catch(Exception error)
            {
                saveError.Text=SettingsApplied?Lang.T("تنظیمات عمومی ذخیره شد؛ ذخیرهٔ ارسال کامل نشد: ","General settings saved; delivery could not be saved: ")+error.Message:error.Message;
                saveError.Visible=true;
            }
        }
    }
}
