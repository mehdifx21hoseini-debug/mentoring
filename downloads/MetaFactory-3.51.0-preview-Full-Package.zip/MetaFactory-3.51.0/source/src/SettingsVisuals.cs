using System;using System.IO;using System.Linq;using System.Drawing;using System.Windows.Forms;
namespace MTManager
{
    sealed class SettingsToggle : CheckBox
    {
        public SettingsToggle(){AutoSize=false;Size=new Size(Theme.S(48),Theme.S(30));SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);AccessibleRole=AccessibleRole.CheckButton;Cursor=Cursors.Hand;}
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent==null?Theme.Surface:Parent.BackColor);e.Graphics.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            var track=new Rectangle(Theme.S(2),Theme.S(5),Theme.S(42),Theme.S(23));
            Theme.Box(e.Graphics,track,Theme.Sf(11),Enabled?(Checked?Theme.Accent:Color.FromArgb(188,193,201)):Color.FromArgb(220,223,228),Color.Transparent);
            using(var brush=new SolidBrush(Color.White))e.Graphics.FillEllipse(brush,Checked?track.Right-Theme.S(21):track.X+Theme.S(2),track.Y+Theme.S(2),Theme.S(19),Theme.S(19));
            if(Focused)ControlPaint.DrawFocusRectangle(e.Graphics,new Rectangle(0,0,Width-1,Height-1));
        }
    }
    sealed class SettingsDialog : Form
    {
        readonly Settings settings;
        readonly TextBox folder = new TextBox { Width = Theme.S(320), RightToLeft = RightToLeft.No };
        readonly Stepper delay = new Stepper(0, 120);
        readonly DropBox reportAtOnce = new DropBox(330) { PickOnly = true, Margin = Padding.Empty };
        readonly CheckBox normalRights = new SettingsToggle { Text = Lang.T("اجرای عادی متاتریدر، بدون درخواست دسترسی مدیر", "Run MetaTrader at current privilege level"), AutoSize = false };
        readonly CheckBox pauseMt5Updates = new SettingsToggle { Text = Lang.T("اجرای MT5 بدون به‌روزرسانی خودکار", "Run MT5 without automatic updates"), AutoSize = false };
        readonly CheckBox sandboxOverflow = new SettingsToggle { Text = Lang.T("اجرای MT4های اضافی با Sandboxie نصب‌شده", "Use installed Sandboxie for additional MT4 copies"), AutoSize = false };
        readonly CheckBox minimized = new SettingsToggle { Text = Lang.T("نسخه‌ها کوچک‌شده باز شوند", "Start the copies minimized"), AutoSize = false };
        readonly CheckBox light = new SettingsToggle { Text = Lang.T("حالت سبک: اخبار خاموش؛ چارت‌های MT5 حداکثر ۵۰۰ کندل", "Light mode: news off; MT5 charts limited to 500 candles"), AutoSize = false };
        readonly CheckBox autostart = new SettingsToggle { Text = Lang.T("بعد از روشن شدن ویندوز، همه‌ی نسخه‌ها خودشان باز شوند (برای VPS)", "When Windows starts, all copies open by themselves (for a VPS)"), AutoSize = false };
        readonly DropBox startCharts = new DropBox(330) { PickOnly = true, Margin = Padding.Empty };
        // 3.27 (CHANGE-019): the program's language; the window is made again when it changes.
        readonly DropBox language = new DropBox(330) { PickOnly = true, Margin = Padding.Empty };
        static readonly string[] ChartModeList = { ChartModes.Empty, ChartModes.One, ChartModes.All };
        readonly CheckBox lowPriority = new SettingsToggle { Text = Lang.T("متاتریدرهای پشت صحنه با اولویت پایین‌تر اجرا شوند", "Run background MetaTraders at a lower priority"), AutoSize = false };
        readonly CheckBox trimMemory = new SettingsToggle { Text = Lang.T("حافظهٔ متاتریدرهای کوچک‌شدهٔ بدون پایش زنده به ویندوز برگردد", "Return memory of minimized MetaTraders without live monitoring to Windows"), AutoSize = false };


        readonly Panel pageHost=new Panel{Dock=DockStyle.Fill};
        readonly Panel[] pages=new Panel[4];
        readonly ModernButton[] pageButtons=new ModernButton[4];
        readonly ScheduleDialog deliveryEditor;
        readonly Action<ScheduleOptions> saveDelivery;
        readonly Label saveError=new Label{AutoSize=true,ForeColor=Theme.Bad};
        public ScheduleOptions DeliveryOptions {get;private set;}
        public bool SettingsApplied {get;private set;}
        internal int SelectedPage {get;private set;}
        public SettingsDialog(Settings settings):this(settings,null,null,null,false){}
        public SettingsDialog(Settings settings,ScheduleOptions delivery,string deliveryStatus,Action<ScheduleOptions> onSaveDelivery,bool initialDelivery)
        {
            this.settings=settings;saveDelivery=onSaveDelivery;
            Text=Lang.T("تنظیمات","Settings");Font=Theme.Font;ForeColor=Theme.Text;BackColor=Theme.Surface;
            RightToLeft=Theme.Dir;RightToLeftLayout=false;FormBorderStyle=FormBorderStyle.FixedDialog;
            MaximizeBox=false;MinimizeBox=false;ShowIcon=false;ShowInTaskbar=false;StartPosition=FormStartPosition.CenterParent;
            ClientSize=new Size(Theme.S(720),Theme.S(510));AutoSize=false;Theme.Window(this);
            folder.Text=settings.BaseDir;folder.Width=Theme.S(275);
            delay.Value=Math.Max(0,Math.Min(120,settings.DelaySeconds));minimized.Checked=settings.Minimized;
            normalRights.Checked=settings.NormalTerminalRights;sandboxOverflow.Checked=settings.SandboxieOverflow;pauseMt5Updates.Checked=settings.PauseMt5Updates;
            startCharts.SetItems(new[]{Lang.T("بدون چارت (سبک‌ترین)","No charts (lightest)"),Lang.T("یک چارت","One chart"),Lang.T("همهٔ چارت‌ها","All charts")});
            startCharts.SelectedIndex=Math.Max(0,Array.IndexOf(ChartModeList,settings.StartCharts));
            lowPriority.Checked=settings.LowPriority;trimMemory.Checked=settings.TrimMemory;light.Checked=settings.Light;autostart.Checked=settings.AutoStart;
            language.SetItems(new[]{"فارسی (راست‌چین)","English (left to right)"});language.SelectedIndex=settings.Language=="en"?1:0;
            int auto=ReportParallel.Auto(Environment.ProcessorCount,Checks.TotalRamMb(),Checks.FreeRamMb());
            reportAtOnce.SetItems(new[]{Lang.T("خودکار (ظرفیت فعلی: ","Automatic (current capacity: ")+Fa.N(auto)+Lang.T(" هم‌زمان)"," at a time)"),Lang.T("یکی‌یکی","one by one"),Lang.T("حداکثر ۲ هم‌زمان","Up to 2 at a time"),Lang.T("حداکثر ۳ هم‌زمان","Up to 3 at a time"),Lang.T("حداکثر ۴ هم‌زمان","Up to 4 at a time")});
            reportAtOnce.SelectedIndex=ReportParallel.Clamp(settings.ReportAtOnce);
            deliveryEditor=new ScheduleDialog(delivery,deliveryStatus);
            var layout=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=4,Padding=Theme.Pad(20,8,20,8),RightToLeft=RightToLeft.No};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,Theme.S(44)));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,Theme.S(44)));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,Theme.S(58)));
            var heading=Theme.Label(Lang.T("تنظیمات","Settings"),0,Theme.Heading,Theme.Text);heading.Dock=DockStyle.Fill;heading.TextAlign=Lang.En?ContentAlignment.MiddleLeft:ContentAlignment.MiddleRight;layout.Controls.Add(heading,0,0);
            var tabs=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=4,RowCount=1,Margin=Padding.Empty,RightToLeft=Theme.Dir};
            string[] titles={Lang.T("عمومی","General"),Lang.T("اجرا","Running"),Lang.T("ارسال و زمان‌بندی","Delivery"),Lang.T("پیشرفته","Advanced")};
            for(int k=0;k<4;k++){int index=k;tabs.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,25));var button=new ModernButton(titles[k],(sender,args)=>ShowPage(index),ButtonKind.Secondary);button.Dock=DockStyle.Fill;button.Margin=Theme.Pad(2,2);pageButtons[k]=button;tabs.Controls.Add(button,k,0);}
            layout.Controls.Add(tabs,0,1);layout.Controls.Add(pageHost,0,2);
            for(int k=0;k<4;k++){pages[k]=new Panel{Dock=DockStyle.Fill,AutoScroll=true,Padding=Theme.Pad(4,10,4,4),BackColor=Theme.Surface};pageHost.Controls.Add(pages[k]);}
            var general=FormRows(pages[0]);var folderLine=new FlowLayoutPanel{AutoSize=false,Height=Theme.S(36),Dock=DockStyle.Fill,WrapContents=false,Margin=Padding.Empty,RightToLeft=RightToLeft.No};folderLine.Controls.Add(folder);
            var browse=new ModernButton(Lang.T("انتخاب…","Choose…"),ButtonKind.Secondary,Glyph.Folder,Glyph.None,true){Margin=Theme.Pad(5,0,0,0)};browse.Click+=Browse;folderLine.Controls.Add(browse);
            FormRow(general,Lang.T("پوشهٔ نسخه‌ها","Copies folder"),folderLine);FormRow(general,Lang.T("زبان","Language"),language);FormRow(general,Lang.T("اجرای خودکار با ویندوز","Start with Windows"),autostart);
            var running=FormRows(pages[1]);var seconds=new FlowLayoutPanel{AutoSize=true,WrapContents=false,Margin=Padding.Empty,RightToLeft=RightToLeft.No};seconds.Controls.Add(delay);seconds.Controls.Add(Theme.Label(Lang.T("ثانیه","seconds"),0,Theme.Small,Theme.Muted));
            FormRow(running,Lang.T("فاصلهٔ اجرای نسخه‌ها","Start interval"),seconds);FormRow(running,Lang.T("باز شدن کوچک‌شده","Start minimized"),minimized);FormRow(running,Lang.T("حالت سبک","Light mode"),light);FormRow(running,Lang.T("اولویت کمتر پردازنده","Lower process priority"),lowPriority);FormRow(running,Lang.T("MT5 بدون به‌روزرسانی خودکار","MT5 without automatic updates"),pauseMt5Updates);
            var more=new LinkLabel{Text=Lang.T("گزینه‌های بیشتر…","More options…"),AutoSize=true,LinkColor=Theme.Accent,Margin=Theme.Pad(0,12,0,0)};more.LinkClicked+=(sender,args)=>ShowPage(3);FormRow(running,"",more);
            var content=deliveryEditor.EditorContent;content.Dock=DockStyle.Fill;pages[2].Controls.Add(content);
            var advanced=FormRows(pages[3]);FormRow(advanced,Lang.T("خواندن هم‌زمان گزارش","Concurrent reports"),reportAtOnce);FormRow(advanced,Lang.T("چارت نسخه‌های اینوستور","Investor-copy charts"),startCharts);FormRow(advanced,Lang.T("اجرای MT4های اضافه با Sandboxie","Additional MT4 via Sandboxie"),sandboxOverflow);FormRow(advanced,Lang.T("دسترسی فعلی ویندوز","Current Windows privilege"),normalRights);FormRow(advanced,Lang.T("آزادسازی حافظهٔ نسخه‌های بدون پایش","Reclaim memory without live monitoring"),trimMemory);
            saveError.Font=Theme.Small;saveError.Visible=false;saveError.MaximumSize=new Size(Theme.S(660),0);saveError.Dock=DockStyle.Bottom;pageHost.Controls.Add(saveError);saveError.BringToFront();
            var footer=new ButtonRow{Dock=DockStyle.Fill};var ok=footer.Add(new ModernButton(Lang.T("ذخیره تغییرات","Save changes"),Save,ButtonKind.Primary));var cancel=footer.Add(new ModernButton(Lang.T("انصراف","Cancel"),(sender,args)=>{DialogResult=DialogResult.Cancel;Close();}));layout.Controls.Add(footer,0,3);
            AcceptButton=ok;CancelButton=cancel;Controls.Add(layout);Theme.StyleInputs(this);ShowPage(initialDelivery?2:1);
        }
        static TableLayoutPanel FormRows(Panel parent)
        {
            var table=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=2,GrowStyle=TableLayoutPanelGrowStyle.AddRows,RightToLeft=Theme.Dir,Margin=Padding.Empty,Padding=Padding.Empty};
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,43));table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,57));parent.Controls.Add(table);return table;
        }
        static void FormRow(TableLayoutPanel table,string title,Control control)
        {
            int row=table.RowCount++;table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var label=Theme.Label(title,0,Theme.Font,Theme.Text);label.AutoSize=true;label.MaximumSize=new Size(Theme.S(280),0);label.Anchor=AnchorStyles.Left|AnchorStyles.Right;label.Margin=Theme.Pad(4,12,8,10);
            control.Margin=Theme.Pad(6,5,4,5);control.Anchor=AnchorStyles.Left|AnchorStyles.Right;
            if(control is CheckBox){control.Anchor=Lang.En?AnchorStyles.Right:AnchorStyles.Left;control.AccessibleName=control.Text;}
            table.Controls.Add(label,0,row);table.Controls.Add(control,1,row);
        }
        internal void ShowPage(int index)
        {
            index=Math.Max(0,Math.Min(3,index));SelectedPage=index;
            for(int k=0;k<4;k++){pages[k].Visible=k==index;pageButtons[k].Kind=k==index?ButtonKind.Primary:ButtonKind.Secondary;}
            pages[index].BringToFront();if(saveError.Visible)saveError.BringToFront();
        }
        protected override void OnShown(EventArgs e)
        {
            var area=Screen.FromControl(this).WorkingArea;Size=new Size(Math.Min(Width,area.Width-20),Math.Min(Height,area.Height-20));base.OnShown(e);
        }
        protected override void Dispose(bool disposing){if(disposing)deliveryEditor.Dispose();base.Dispose(disposing);}
        void Browse(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog { Description = Lang.T("پوشه‌ای برای نسخه‌ها (نه داخل Program Files)", "A folder for the copies (not inside Program Files)") })
            {
                if (Directory.Exists(folder.Text)) fbd.SelectedPath = folder.Text;
                if (fbd.ShowDialog(this) == DialogResult.OK) folder.Text = fbd.SelectedPath;
            }
        }

        void Save(object sender, EventArgs e)
        {
            ScheduleOptions candidate=null;
            if(deliveryEditor.IsDirty && !deliveryEditor.TryCollect(out candidate)){ShowPage(2);return;}
            string dir = folder.Text.Trim().Trim('"').TrimEnd('\\');
            if (dir.Length == 0) { Ui.Message(this, Lang.T("یک پوشه انتخاب کنید.", "Choose a folder."), MessageBoxIcon.Warning); return; }
            if (dir.IndexOf("Program Files", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                Ui.Message(this, Lang.T("داخل Program Files نه: نسخه‌ها باید بتوانند در پوشه‌ی خودشان بنویسند.", "Not inside Program Files: the copies must be able to write in their own folder."), MessageBoxIcon.Warning);
                return;
            }
            if (dir.Length <= 2) dir += @"\MetaTrader";  // a drive root gets its own folder
            if (!Checks.CanWrite(dir)) { Ui.Message(this, Lang.T("در این پوشه نمی‌شود نوشت. پوشه‌ی دیگری انتخاب کنید.", "Cannot write in this folder. Choose another folder."), MessageBoxIcon.Warning); return; }
            try { AutoStart.Set(autostart.Checked, Application.ExecutablePath); }
            catch (Exception ex) { Ui.Error(this, ex); return; }
            settings.UseFolder(dir);  // the folder used before stays listed, with its copies
            settings.Language = language.SelectedIndex == 1 ? "en" : "fa";
            settings.DelaySeconds = delay.Value;
            settings.ReportAtOnce = Math.Max(0, reportAtOnce.SelectedIndex);
            settings.Minimized = minimized.Checked;
            settings.NormalTerminalRights = normalRights.Checked;
            settings.SandboxieOverflow = sandboxOverflow.Checked;
            settings.PauseMt5Updates = pauseMt5Updates.Checked;
            if(!settings.PauseMt5Updates)Mt5UpdatePolicy.RestoreAll();
            settings.Light = light.Checked;
            settings.AutoStart = autostart.Checked;
            settings.StartCharts = ChartModeList[Math.Max(0, startCharts.SelectedIndex)];
            settings.LightCharts = settings.StartCharts != ChartModes.All;
            settings.LowPriority = lowPriority.Checked;
            settings.TrimMemory = trimMemory.Checked;
            try
            {
                settings.Save();SettingsApplied=true;
                if(candidate!=null && saveDelivery!=null)saveDelivery(candidate);
                DeliveryOptions=candidate;
                DialogResult=DialogResult.OK;Close();
            }
            catch(Exception error)
            {
                saveError.Text=SettingsApplied?Lang.T("تنظیمات عمومی ذخیره شد؛ ذخیرهٔ ارسال کامل نشد: ","General settings saved; delivery could not be saved: ")+error.Message:error.Message;
                saveError.Visible=true;
            }
        }
    }
}
