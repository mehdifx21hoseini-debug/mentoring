using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MTManager
{
    internal static class ReportTextBrowse
    {
        static string SearchText(string value)
        {
            return TextUtil.LatinDigits(value ?? "").Replace('ي', 'ی').Replace('ك', 'ک').Replace('\u200c', ' ');
        }
        static double ReturnOf(TextEntry entry)
        {
            double value = entry == null || entry.View == null ? double.NaN : entry.View.ReturnPct;
            return double.IsInfinity(value) ? double.NaN : value;
        }
        // Return original indices: filtering/sorting never changes checkbox identity or entry numbering.
        public static List<int> Indices(IList<TextEntry> entries, string query, int sort)
        {
            string[] words = SearchText(query).Split((char[])null, StringSplitOptions.RemoveEmptyEntries);
            IEnumerable<int> found = Enumerable.Range(0, entries.Count).Where(k => entries[k] != null && words.All(word =>
                SearchText((entries[k].Name ?? "") + " " + (entries[k].Login ?? "")).IndexOf(word, StringComparison.OrdinalIgnoreCase) >= 0));
            if (sort == 1 || sort == 2)
                found = found.OrderBy(k => double.IsNaN(ReturnOf(entries[k])) ? 1 : 0)
                    .ThenBy(k => double.IsNaN(ReturnOf(entries[k])) ? 0 : (sort == 1 ? -ReturnOf(entries[k]) : ReturnOf(entries[k])))
                    .ThenBy(k => k);
            return found.ToList();
        }
    }

    // ================================================================== 3.25: «متن گزارش» (approved mockup)

    /// <summary>What «متن گزارش» needs from the main window: the students ticked, their numbers for a range, who was not read today, and
    /// reading those again.</summary>
    sealed class ReportTextSource
    {
        public List<string> Names = new List<string>();
        /// <summary>The range on the clock of the first student's server (the date on top of the text).</summary>
        public Func<PanelRange, DateTime, DateTime, ReportRange> RangeOf;
        public Func<PanelRange, DateTime, DateTime, List<TextEntry>> Entries;
        /// <summary>The names of those whose history was not read today (or never).</summary>
        public Func<List<string>> NotReadToday;
        /// <summary>3.25.1: when the oldest of them was read; null when one was never read.</summary>
        public Func<DateTime?> StaleSince;
        /// <summary>How many of them are being read now or wait for it.</summary>
        public Func<int> Reading;
        /// <summary>Reads those not read today, back to the range's first day.</summary>
        public Action<PanelRange, DateTime, DateTime> ReadNow;
        /// <summary>Changes when any of their histories is read again, so the text is made again.</summary>
        public Func<string> Fingerprint;
        /// <summary>3.26 (CHANGE-018): for each of Names, when it was read if that was more than an hour ago («دیروز ۱۳:۲۸», «خوانده نشده»);
        /// empty when it is fresh.</summary>
        public Func<List<string>> StaleNotes;
    }

    /// <summary>A row of choices like the report page's «امروز | دیروز | …»: the first at the right, the chosen one blue.</summary>
    sealed class SegmentBar : Control
    {
        readonly string[] items;
        readonly int[] widths;
        int selected, hover = -1;
        public event Action Changed;

        public SegmentBar(params string[] items)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            this.items = items;
            Font = Theme.Font;
            Cursor = Cursors.Hand;
            TabStop = true;
            AccessibleRole = AccessibleRole.PageTabList;
            widths = items.Select(t => Theme.Measure(t, Theme.Bold).Width + Theme.S(22)).ToArray();
            Size = new Size(widths.Sum() + 1, Theme.S(30));
        }

        public int Selected
        {
            get { return selected; }
            set { if (value != selected && value >= 0 && value < items.Length) { selected = value; Invalidate(); } }
        }

        Rectangle Box(int k)
        {
            int x = Width - 1;
            for (int i = 0; i <= k; i++) x -= widths[i];
            // 3.27: the first at the start: the right in Persian, the left in English.
            return Theme.Flip(new Rectangle(x, 0, widths[k], Height - 1), 0, Width - 1);
        }

        int At(Point p)
        {
            for (int k = 0; k < items.Length; k++) if (Box(k).Contains(p)) return k;
            return -1;
        }

        void Choose(int k)
        {
            if (k < 0 || k >= items.Length || k == selected) return;
            selected = k;
            Invalidate();
            if (Changed != null) Changed();
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent != null ? Parent.BackColor : Theme.Surface);
            Theme.Box(g, new Rectangle(0, 0, Width - 1, Height - 1), Theme.Sf(6), Theme.Surface, Theme.BorderStrong);
            for (int k = 0; k < items.Length; k++)
            {
                Rectangle r = Box(k);
                if (k == selected) Theme.Box(g, Rectangle.Inflate(r, -1, -1), Theme.Sf(5), Theme.Accent, Color.Transparent);
                else if (k == hover) Theme.Box(g, Rectangle.Inflate(r, -1, -1), Theme.Sf(5), Theme.Hover, Color.Transparent);
                if (k > 0 && k != selected && k - 1 != selected)
                    using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, Lang.En ? r.Left : r.Right, Theme.S(7), Lang.En ? r.Left : r.Right, Height - Theme.S(8));
                Theme.Line(g, items[k], k == selected ? Theme.Bold : Theme.Font, r, k == selected ? Theme.OnAccent : Theme.Text, true);
            }
            if (Focused && ShowFocusCues)
                using (var pen = new Pen(Theme.Accent) { DashStyle = System.Drawing.Drawing2D.DashStyle.Dot })
                    g.DrawRectangle(pen, Rectangle.Inflate(Box(selected), -3, -3));
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int k = At(e.Location);
            if (k != hover) { hover = k; Invalidate(); }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e) { hover = -1; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            if (e.Button == MouseButtons.Left) { Focus(); Choose(At(e.Location)); }
        }

        protected override bool IsInputKey(Keys keyData) { return keyData == Keys.Left || keyData == Keys.Right || base.IsInputKey(keyData); }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            // Right to left: the next choice is on the left (3.27: on the right in English).
            if (e.KeyCode == (Lang.En ? Keys.Right : Keys.Left)) { Choose(selected + 1); e.Handled = true; }
            else if (e.KeyCode == (Lang.En ? Keys.Left : Keys.Right)) { Choose(selected - 1); e.Handled = true; }
            base.OnKeyDown(e);
        }

        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
    }

    /// <summary>3.26 (CHANGE-018, approved): one student in the window's list: a tick (in the text or not), the name, an orange label
    /// when the report is old, and a small button that copies this student's text alone.</summary>
    sealed class RosterRow : Control
    {
        bool on = true, hover, hoverCopy;
        string tag = "";
        public event EventHandler Toggled, CopyClicked;

        public RosterRow(string name)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            Text = name;
            Font = Theme.Font;
            Height = Theme.S(28);
            Cursor = Cursors.Hand;
            TabStop = true;
            AccessibleRole = AccessibleRole.CheckButton;
            AccessibleName = name;
        }

        public bool On { get { return on; } set { if (on != value) { on = value; Invalidate(); } } }
        public string Tag2 { get { return tag; } set { value = value ?? ""; if (tag != value) { tag = value; Invalidate(); } } }

        /// <summary>At the row's end: the left in Persian, the right in English (3.27).</summary>
        Rectangle CopyRect { get { return Theme.Flip(new Rectangle(Theme.S(4), (Height - Theme.S(24)) / 2, Theme.S(24), Theme.S(24)), 0, Width); } }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(hover ? Theme.Mix(Theme.Hover, Theme.Surface, 0.5f) : Theme.Surface);
            using (var pen = new Pen(Theme.Mix(Theme.Border, Theme.Surface, 0.5f))) g.DrawLine(pen, 0, Height - 1, Width, Height - 1);
            int box = Theme.S(16), x = Width - Theme.S(9) - box;
            Rectangle cr = ClientRectangle;
            Theme.TickBox(g, Theme.Flip(new Rectangle(x, (Height - box) / 2, box, box), cr), on ? 2 : 0, hover && !hoverCopy);
            Rectangle c = CopyRect;
            Rectangle cd = Theme.Flip(c, cr);
            if (hoverCopy) Theme.Box(g, c, Theme.Sf(4), Theme.Hover, Color.Transparent);
            int a = Theme.S(14);
            Glyphs.Draw(g, Glyph.Copies, new RectangleF(c.X + (c.Width - a) / 2f, c.Y + (c.Height - a) / 2f, a, a), hoverCopy ? Theme.Text : Theme.Muted);
            int right = x - Theme.S(8), left = cd.Right + Theme.S(6);
            if (tag.Length > 0)
            {
                int tw = Theme.Measure(tag, Theme.Small).Width + Theme.S(14), th = Theme.S(18);
                var t = new Rectangle(left, (Height - th) / 2, tw, th);
                Rectangle tf = Theme.Flip(t, cr);
                Theme.Box(g, tf, Theme.Square ? 0 : th / 2f, Theme.WarnSoft, Color.Transparent);
                Theme.Line(g, tag, Theme.Small, tf, Theme.Warn, true);
                left = t.Right + Theme.S(6);
            }
            Theme.Line(g, Text, Font, Theme.Flip(Rectangle.FromLTRB(left, 0, right, Height), cr), on ? Theme.Text : Theme.Faint);
            if (!on)
            {
                int w = Math.Min(right - left, Theme.Measure(Text, Font).Width);
                Rectangle sl = Theme.Flip(new Rectangle(right - w, 0, w, Height), cr);
                using (var pen = new Pen(Theme.Faint)) g.DrawLine(pen, sl.Left, Height / 2, sl.Right, Height / 2);
            }
            if (Focused && ShowFocusCues) ControlPaint.DrawFocusRectangle(g, new Rectangle(1, 1, Width - 2, Height - 3));
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            bool c = CopyRect.Contains(e.Location);
            if (!hover || c != hoverCopy) { hover = true; hoverCopy = c; Invalidate(); }
        }

        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); hover = hoverCopy = false; Invalidate(); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            if (e.Button != MouseButtons.Left) return;
            Focus();
            if (CopyRect.Contains(e.Location)) { if (CopyClicked != null) CopyClicked(this, EventArgs.Empty); return; }
            On = !on;
            if (Toggled != null) Toggled(this, EventArgs.Empty);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (e.KeyCode == Keys.Space) { On = !on; if (Toggled != null) Toggled(this, EventArgs.Empty); e.Handled = true; }
        }

        protected override void OnGotFocus(EventArgs e) { base.OnGotFocus(e); Invalidate(); }
        protected override void OnLostFocus(EventArgs e) { base.OnLostFocus(e); Invalidate(); }
    }

    /// <summary>3.25 (approved mockup): the ticked students' text for one range: the range and the parts on the right, a warning when someone
    /// was not read today (with «اول خوانده شوند»), the text itself, and «کپی همه». The ticks and the range are remembered.</summary>
    sealed class ReportTextDialog : Form
    {
        static string Copied { get { return Lang.T("✓ کپی شد. در تلگرام یا واتس‌اپ Ctrl+V بزنید.", "✓ Copied. Press Ctrl+V in Telegram or WhatsApp."); } }
        static readonly PanelRange[] Kinds = { PanelRange.Today, PanelRange.Yesterday, PanelRange.Week, PanelRange.Month, PanelRange.Custom };
        static string[] WeekDays { get { return new[] { Lang.T("یکشنبه", "Sunday"), Lang.T("دوشنبه", "Monday"), Lang.T("سه‌شنبه", "Tuesday"), Lang.T("چهارشنبه", "Wednesday"), Lang.T("پنجشنبه", "Thursday"), Lang.T("جمعه", "Friday"), Lang.T("شنبه", "Saturday") }; } }
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        readonly ReportTextSource src;
        readonly Settings settings;
        readonly SegmentBar range = new SegmentBar(Lang.T("امروز", "Today"), Lang.T("دیروز", "Yesterday"), Lang.T("این هفته", "This week"), Lang.T("این ماه", "This month"), Lang.T("بازه…", "Range…"));
        readonly Label dateLine;
        readonly FlowLayoutPanel customRow;
        readonly TextBox fromBox = DateBox(), toBox = DateBox();
        readonly List<KeyValuePair<TextParts, CheckBox>> ticks = new List<KeyValuePair<TextParts, CheckBox>>();
        readonly Panel warn;
        readonly Label warnText;
        readonly ModernButton readNow;
        readonly RichTextBox box;
        readonly Panel head;
        Control infoRow;
        string infoText = "";
        Color infoColor = Theme.Muted;
        readonly List<RosterRow> roster = new List<RosterRow>();
        readonly SearchBox search = new SearchBox(Lang.T("جستجوی نام یا شماره حساب", "Search name or account"), 300);
        readonly ComboBox sort = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
        readonly Panel rosterPanel;
        readonly Label matchCount;
        readonly Button copyButton, saveButton;
        List<int> visibleIndices = new List<int>();
        List<TextEntry> lastEntries = new List<TextEntry>();
        ReportRange lastRange;
        readonly Timer poll = new Timer { Interval = 1000 };
        readonly ToolTip tips = new ToolTip { InitialDelay = 500, ShowAlways = true };
        bool setting;

        /// <summary>3.26 (CHANGE-018): the twelve parts in three groups, with short names (the whole description is each tick's tip).</summary>
        static KeyValuePair<string, KeyValuePair<TextParts, string>[]>[] Groups { get { return new KeyValuePair<string, KeyValuePair<TextParts, string>[]>[] {
            G(Lang.T("سربرگ", "Header"), P(TextParts.Date, Lang.T("تاریخ گزارش", "Report date")), P(TextParts.Name, Lang.T("نام و شماره حساب", "Name & account")), P(TextParts.Balance, Lang.T("بالانس", "Balance"))),
            G(Lang.T("معامله‌ها", "Trades"), P(TextParts.Trades, Lang.T("معامله‌های بسته", "Closed trades")), P(TextParts.Open, Lang.T("معامله‌های باز", "Open trades")), P(TextParts.Sl, Lang.T("حد ضرر (SL)", "Stop loss (SL)"))),
            G(Lang.T("اعداد", "Numbers"), P(TextParts.Net, "NET"), P(TextParts.Lots, "LOTS"), P(TextParts.Count, Lang.T("تعداد و W/L", "Trades & W/L")), P(TextParts.Dd, "D/D"),
              P(TextParts.Return, "Return"), P(TextParts.Zero, "Zero P/L")),
        }; } }

        static KeyValuePair<TextParts, string> P(TextParts t, string name) { return new KeyValuePair<TextParts, string>(t, name); }
        static KeyValuePair<string, KeyValuePair<TextParts, string>[]> G(string title, params KeyValuePair<TextParts, string>[] items)
        {
            return new KeyValuePair<string, KeyValuePair<TextParts, string>[]>(title, items);
        }
        DateTime customFrom, customTo;
        string text = "", note = "", info = "", fingerprint;
        int readingWas = -1;

        static TextBox DateBox()
        {
            return new TextBox { Width = Theme.S(92), RightToLeft = RightToLeft.No, TextAlign = HorizontalAlignment.Center, MaxLength = 10, Margin = Theme.Pad(0, 2, 6, 2) };
        }

        public ReportTextDialog(ReportTextSource src, Settings settings, DateTime customFrom, DateTime customTo)
        {
            this.src = src;
            this.settings = settings;
            this.customFrom = customFrom;
            this.customTo = customTo;
            Text = Lang.T("متن گزارش", "Report text");
            Font = Theme.Font;
            BackColor = Theme.Surface;
            ForeColor = Theme.Text;
            RightToLeft = Theme.Dir;
            RightToLeftLayout = false;
            ShowInTaskbar = false;
            ShowIcon = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;
            Rectangle area = Screen.PrimaryScreen.WorkingArea;
            ClientSize = new Size(Math.Min(Theme.S(900), area.Width - Theme.S(40)), Math.Min(Theme.S(660), area.Height - Theme.S(50)));
            MinimumSize = new Size(Math.Min(Theme.S(760), area.Width - Theme.S(20)), Math.Min(Theme.S(500), area.Height - Theme.S(20)));
            Theme.Window(this);

            // 3.26 (CHANGE-018, approved): under the title only how many are in the text; the names are in the list on the right.
            head = new Panel { Dock = DockStyle.Top, Height = Theme.S(66), BackColor = Theme.BandBack };
            head.Paint += (s, e) =>
            {
                Theme.Line(e.Graphics, Lang.T("متن گزارش", "Report text"), Theme.Heading, new Rectangle(Theme.S(22), Theme.S(10), head.Width - Theme.S(44), Theme.S(32)), Theme.BandText);
                Theme.Line(e.Graphics, Fa.N(Included().Count) + Lang.T(" از ", " of ") + Fa.N(roster.Count) + Lang.T(" دانشجو در متن", " students in the text"), Theme.Small,
                           new Rectangle(Theme.S(22), Theme.S(40), head.Width - Theme.S(44), Theme.S(22)), Theme.BandSub);
            };

            // The right side: the range, the students, the parts.
            var side = new FlowLayoutPanel
            {
                Dock = Lang.En ? DockStyle.Left : DockStyle.Right, Width = Theme.S(340), FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true,
                Padding = Lang.En ? Theme.Pad(22, 2, 8, 8) : Theme.Pad(8, 2, 22, 8), BackColor = Theme.Surface,
            };
            side.Controls.Add(Caption(Lang.T("بازه", "Range")));
            range.Margin = Theme.Pad(0, 0, 0, 4);
            side.Controls.Add(range);
            dateLine = Theme.Label("", 300, Theme.Small, Theme.Muted);
            dateLine.Margin = Theme.Pad(0, 2, 0, 4);
            side.Controls.Add(dateLine);
            customRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = Theme.Pad(0, 0, 0, 6), Visible = false };
            customRow.Controls.Add(new Label { Text = Lang.T("از", "from"), AutoSize = true, Margin = Theme.Pad(0, 6, 6, 0) });
            customRow.Controls.Add(fromBox);
            customRow.Controls.Add(new Label { Text = Lang.T("تا", "to"), AutoSize = true, Margin = Theme.Pad(0, 6, 6, 0) });
            customRow.Controls.Add(toBox);
            var show = new ModernButton(Lang.T("نمایش", "Show"), ButtonKind.Secondary, Glyph.None, Glyph.None, true) { Margin = Theme.Pad(0, 0, 0, 0) };
            show.Click += (s, e) => ApplyCustom();
            customRow.Controls.Add(show);
            side.Controls.Add(customRow);
            fromBox.Text = customFrom.ToString("yyyy.MM.dd", Inv);
            toBox.Text = customTo.ToString("yyyy.MM.dd", Inv);
            KeyEventHandler enter = (s, e) => { if (e.KeyCode == Keys.Enter) { ApplyCustom(); e.Handled = e.SuppressKeyPress = true; } };
            fromBox.KeyDown += enter;
            toBox.KeyDown += enter;

            int inner = Theme.S(300);
            // The students: a tick for each (not kept: every time all of them), an orange label when old, copy one alone.
            side.Controls.Add(CaptionWithLinks(Lang.T("دانشجوها", "Students"), inner, new KeyValuePair<string, Action>(Lang.T("همه", "All"), () => SetRoster(true)),
                                               new KeyValuePair<string, Action>(Lang.T("هیچ‌کدام", "None"), () => SetRoster(false))));
            search.Margin = Theme.Pad(0, 0, 0, 5);
            search.Box.AccessibleName = Lang.T("جستجوی نام یا شماره حساب", "Search name or account");
            side.Controls.Add(search);
            sort.Width = inner;
            sort.Font = Theme.Font;
            sort.Margin = Theme.Pad(0, 0, 0, 3);
            sort.AccessibleName = Lang.T("مرتب‌سازی بازده حساب در بازه", "Sort account return in the selected range");
            sort.Items.AddRange(new object[] { Lang.T("ترتیب اولیه", "Original order"), Lang.T("بازده حساب: بیشترین به کمترین", "Account return: highest first"), Lang.T("بازده حساب: کمترین به بیشترین", "Account return: lowest first") });
            sort.SelectedIndex = 0;
            side.Controls.Add(sort);
            matchCount = Theme.Label("", 300, Theme.Small, Theme.Muted);
            matchCount.Margin = Theme.Pad(0, 0, 0, 4);
            side.Controls.Add(matchCount);
            tips.SetToolTip(search, Lang.T("جستجو فقط متن و فهرست نمایش‌داده‌شده را محدود می‌کند؛ تیک‌ها حفظ می‌شوند. Ctrl+F", "Search filters the displayed list and text; checkboxes are preserved. Ctrl+F"));
            tips.SetToolTip(sort, Lang.T("براساس Return در بازهٔ انتخاب‌شده؛ حساب‌های بدون مقدار معتبر در انتها هستند.", "Uses Return for the selected range; accounts without a valid value appear last."));
            var list = rosterPanel = new Panel { Width = inner, AutoScroll = true, BackColor = Theme.Surface, Margin = Theme.Pad(0, 0, 0, 6), Padding = Padding.Empty };
            list.Paint += (s, e) => { using (var pen = new Pen(Theme.Border)) e.Graphics.DrawRectangle(pen, 0, 0, list.Width - 1, list.Height - 1); };
            for (int k = src.Names.Count - 1; k >= 0; k--)
            {
                var row = new RosterRow(src.Names[k]);
                int index = k;
                row.Toggled += (s, e) => { Rebuild(false); head.Invalidate(); };
                row.CopyClicked += (s, e) => CopyOne(index);
                tips.SetToolTip(row, Lang.T("تیک: در متن بیاید · دکمه‌ی کپی کنار اسم: متن همین یک نفر", "Tick: in the text · copy button next to the name: this one student's text"));
                list.Controls.Add(row);
                roster.Insert(0, row);
            }
            list.Height = Math.Min(5, Math.Max(1, roster.Count)) * Theme.S(28) + 2;
            side.Controls.Add(list);
            list.SizeChanged += (s, e) => LayoutRoster();

            // The parts: the same twelve ticks, in three groups of two columns.
            side.Controls.Add(CaptionWithLinks(Lang.T("در متن بیاید", "In the text"), inner, new KeyValuePair<string, Action>(Lang.T("همه", "All"), () => SetParts(TextParts.All))));
            TextParts kept = ReportText.Parse(settings.ReportParts);
            Func<TextParts, string> longName = t => ReportText.Names.First(x => x.Key == t).Value;
            foreach (KeyValuePair<string, KeyValuePair<TextParts, string>[]> group in Groups)
            {
                Label g = Theme.Label(group.Key, 0, Theme.Small, Theme.Muted);
                g.Margin = Padding.Empty;
                side.Controls.Add(g);
                var grid = new TableLayoutPanel { ColumnCount = 2, AutoSize = true, Width = inner, Margin = Theme.Pad(0, 0, 0, 2), Padding = Padding.Empty };
                grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, inner / 2));
                grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, inner / 2));
                foreach (KeyValuePair<TextParts, string> p in group.Value)
                {
                    var c = new CheckBox { Text = p.Value, AutoSize = false, Size = new Size(inner / 2 - Theme.S(4), Theme.S(23)), Checked = (kept & p.Key) != 0, Margin = Padding.Empty, UseMnemonic = false };
                    c.CheckedChanged += (s, e) => { if (setting) return; Remember(); Rebuild(false); };
                    tips.SetToolTip(c, longName(p.Key));
                    ticks.Add(new KeyValuePair<TextParts, CheckBox>(p.Key, c));
                    grid.Controls.Add(c);
                }
                side.Controls.Add(grid);
            }
            Label keep = Theme.Label(Lang.T("تیک‌ها برای دفعه‌ی بعد یادش می‌ماند.", "The ticks are remembered for next time."), 300, Theme.Small, Theme.Muted);
            keep.Margin = Theme.Pad(0, 4, 0, 0);
            side.Controls.Add(keep);

            // The text, with the warning above it: a soft frame, a little larger letters, the names in the program's Persian font;
            // long lines go on to the next (no sideways bar). Only how it is shown: what is copied is the same text.
            Font mono = DayTextDialog.Mono();
            box = new RichTextBox
            {
                ReadOnly = true, WordWrap = true, ScrollBars = RichTextBoxScrollBars.Vertical, RightToLeft = RightToLeft.No, DetectUrls = false,
                Dock = DockStyle.Fill, Font = new Font(mono.FontFamily, mono.SizeInPoints + 0.5f, FontStyle.Regular, GraphicsUnit.Point),
                BackColor = Theme.Alt, ForeColor = Theme.Text, BorderStyle = BorderStyle.None,
            };
            var frame = new Panel { Dock = DockStyle.Fill, Padding = Theme.Pad(10, 8, 4, 8), BackColor = Theme.Alt };
            frame.Paint += (s, e) => Theme.Box(e.Graphics, new Rectangle(0, 0, frame.Width - 1, frame.Height - 1), Theme.Sf(6), Color.Transparent, Theme.Border);
            frame.Controls.Add(box);
            // Fonts given before the box has its window are lost: once it has one, the names are made bold again.
            box.HandleCreated += (s, e) => { if (shownEntries != null) BeginInvoke((Action)(() => ShowText(shownEntries))); };
            warn = new Panel { Dock = DockStyle.Top, Height = Theme.S(44), BackColor = Theme.WarnSoft, Padding = Theme.Pad(10, 7, 10, 7), Visible = false };
            warn.Paint += (s, e) => { using (var pen = new Pen(Theme.WarnLine)) e.Graphics.DrawRectangle(pen, 0, 0, warn.Width - 1, warn.Height - 1); };
            warnText = new Label { Dock = DockStyle.Fill, TextAlign = Lang.En ? ContentAlignment.MiddleLeft : ContentAlignment.MiddleRight, ForeColor = Theme.Text, BackColor = Theme.WarnSoft, UseMnemonic = false, AutoEllipsis = true };
            readNow = new ModernButton(Lang.T("به‌روزرسانی", "Refresh"), ButtonKind.Secondary, Glyph.Refresh, Glyph.None, true) { Dock = Lang.En ? DockStyle.Right : DockStyle.Left };
            readNow.Click += (s, e) => { DateTime a, b; Custom(out a, out b); src.ReadNow(Kinds[range.Selected], a, b); Rebuild(); };
            warn.Controls.Add(warnText);
            warn.Controls.Add(readNow);
            var gap = new Panel { Dock = DockStyle.Top, Height = Theme.S(10), BackColor = Theme.Surface };
            var main = new Panel { Dock = DockStyle.Fill, Padding = Lang.En ? Theme.Pad(10, 2, 22, 10) : Theme.Pad(22, 2, 10, 10), BackColor = Theme.Surface };
            main.Controls.Add(frame);
            main.Controls.Add(gap);
            main.Controls.Add(warn);
            var buttons = new ButtonRow { Dock = DockStyle.Bottom };
            Button copy = copyButton = buttons.Add(new ModernButton(Lang.T("کپی متن", "Copy text"), ButtonKind.Primary) { MinimumSize = new Size(Theme.S(100), 0) });
            copy.Click += Copy;
            saveButton = buttons.Add(new ModernButton(Lang.T("ذخیرهٔ متن", "Save text"), ButtonKind.Secondary) { MinimumSize = new Size(Theme.S(100), 0) });
            saveButton.Click += (s, e) => SaveText();
            Button close = buttons.Add(new ModernButton(Lang.T("بستن", "Close"), ButtonKind.Secondary) { MinimumSize = new Size(Theme.S(96), 0) });
            close.Click += (s, e) => Close();
            buttons.AutoSize = false;
            buttons.Height = buttons.GetPreferredSize(Size.Empty).Height;
            // «۳ دانشجو · ۵۱ خط» (or «کپی شد») beside «کپی همه».
            // «۳ دانشجو · ۵۱ خط» (or «کپی شد») drawn beside «کپی همه».
            infoRow = buttons;
            buttons.Paint += (s, e) =>
            {
                if (infoText.Length == 0) return;
                Font f = infoColor == Theme.Ok ? Theme.SmallBold : Theme.Small;
                int tw0 = Theme.Measure(infoText, f).Width + Theme.S(6);
                // 3.27: beside the buttons: after them in Persian (at the left), before them in English.
                int x = Lang.En ? Math.Min(copy.Left, close.Left) - Theme.S(12) - tw0 : Math.Max(copy.Right, close.Right) + Theme.S(12);
                int w = Lang.En ? tw0 : Math.Min(tw0, Math.Max(0, buttons.Width - x - Theme.S(20)));
                Theme.Line(e.Graphics, infoText, f, new Rectangle(Math.Max(Theme.S(20), x), 0, w, buttons.Height), infoColor);
            };

            // 3.25.1 (approved): the right column as wide as what is in it on this computer, the text box gives way a little.
            int sideW = side.Controls.Cast<Control>().Select(c => c.GetPreferredSize(Size.Empty).Width + c.Margin.Horizontal).DefaultIfEmpty(0).Max();
            sideW = Math.Max(sideW, customRow.GetPreferredSize(Size.Empty).Width + customRow.Margin.Horizontal);
            side.Width = Math.Max(Theme.S(320), sideW + side.Padding.Horizontal + SystemInformation.VerticalScrollBarWidth);
            ClientSize = new Size(Math.Min(side.Width + Theme.S(590), area.Width - Theme.S(40)), ClientSize.Height);
            Controls.Add(main);
            Controls.Add(side);
            Controls.Add(head);
            Controls.Add(buttons);
            // Wholly on the screen, wherever its owner is.
            EventHandler onScreen = (s, e) =>
            {
                Rectangle wa = Screen.FromControl(this).WorkingArea;
                var spot = new Point(Math.Max(wa.Left, Math.Min(Left, wa.Right - Width)), Math.Max(wa.Top, Math.Min(Top, wa.Bottom - Height)));
                if (spot != Location) Location = spot;
            };
            Load += onScreen;
            Shown += onScreen;
            AcceptButton = copy;
            CancelButton = close;

            int at = Array.IndexOf(Kinds, ParseKind(settings.ReportRange));
            range.Selected = at < 0 ? 0 : at;
            range.Changed += () => { customRow.Visible = Kinds[range.Selected] == PanelRange.Custom; Remember(); Rebuild(); };
            search.Box.TextChanged += (s, e) => Rebuild(false);
            sort.SelectedIndexChanged += (s, e) => Rebuild(false);
            customRow.Visible = Kinds[range.Selected] == PanelRange.Custom;
            Rebuild();
            poll.Tick += (s, e) => Poll();
            Shown += (s, e) => { poll.Start(); copy.Focus(); };
            FormClosed += (s, e) => poll.Stop();
        }

        /// <summary>A caption with small links at the other end («همه»، «هیچ‌کدام»).</summary>
        static Control CaptionWithLinks(string t, int width, params KeyValuePair<string, Action>[] links)
        {
            var row = new Panel { Width = width, Height = Theme.S(26), Margin = Theme.Pad(0, 2, 0, 2), BackColor = Theme.Surface };
            Label cap = Caption(t);
            cap.Margin = Padding.Empty;
            cap.Location = new Point(Lang.En ? 0 : width - cap.PreferredWidth, Theme.S(4));
            row.Controls.Add(cap);
            int x = 0;
            // 3.27: in English the first link stays first (left of the others).
            foreach (KeyValuePair<string, Action> l in Lang.En ? links.Reverse() : links)
            {
                LinkLabel link = Art.Link(l.Key);
                link.Font = Theme.Small;
                link.AutoSize = true;
                Action act = l.Value;
                link.LinkClicked += (s, e) => act();
                link.Location = new Point(Lang.En ? width - x - link.PreferredWidth : x, Theme.S(6));
                row.Controls.Add(link);
                x += link.PreferredWidth + Theme.S(8);
            }
            return row;
        }

        List<int> Included()
        {
            return visibleIndices.Where(k => k < roster.Count && roster[k].On).ToList();
        }

        void SetRoster(bool on)
        {
            foreach (int k in visibleIndices) if (k < roster.Count) roster[k].On = on;
            Rebuild(false);
            head.Invalidate();
        }

        void SetParts(TextParts parts)
        {
            setting = true;
            try { foreach (KeyValuePair<TextParts, CheckBox> t in ticks) t.Value.Checked = (parts & t.Key) != 0; }
            finally { setting = false; }
            Remember();
            Rebuild(false);
        }

        void LayoutRoster()
        {
            if (rosterPanel == null) return;
            rosterPanel.SuspendLayout();
            try
            {
                var shown = new HashSet<int>(visibleIndices);
                for (int k = 0; k < roster.Count; k++) roster[k].Visible = shown.Contains(k);
                int rowHeight = Theme.S(28);
                // Rows already include the painted one-pixel border. Use the outer panel width
                // so scrollbar creation cannot leave an earlier, wider row behind its gutter.
                int width = rosterPanel.Width - 2 - (visibleIndices.Count > 5 ? SystemInformation.VerticalScrollBarWidth : 0);
                for (int n = 0; n < visibleIndices.Count; n++)
                {
                    int k = visibleIndices[n];
                    if (k < roster.Count) roster[k].Bounds = new Rectangle(1, 1 + n * rowHeight + rosterPanel.AutoScrollPosition.Y, Math.Max(1, width), rowHeight);
                }
                rosterPanel.AutoScrollMinSize = new Size(0, visibleIndices.Count * rowHeight + 2);
            }
            finally { rosterPanel.ResumeLayout(); }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.F)) { search.Box.Focus(); search.Box.SelectAll(); return true; }
            if (keyData == Keys.Escape && search.Box.Focused && search.Box.Text.Length > 0) { search.Box.Clear(); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        /// <summary>The text of one student alone (with the date on top when that part is ticked), to send to them.</summary>
        void CopyOne(int k)
        {
            if (k < 0 || k >= lastEntries.Count) return;
            string one = ReportText.Make(lastRange, new[] { lastEntries[k] }, Parts());
            try { Clipboard.SetDataObject(one, true, 5, 100); }
            catch (Exception ex)
            {
                Log.Write("report text copy: " + ex.Message);
                Ui.Message(this, Lang.T("کلیپ‌بورد ویندوز دست برنامه‌ی دیگری است. چند لحظه بعد دوباره امتحان کنید.", "The Windows clipboard is held by another program. Try again in a moment."), MessageBoxIcon.Warning);
                return;
            }
            ShowInfo(Lang.T("✓ متن «", "✓ The text of “") + src.Names[k] + Lang.T("» کپی شد. در تلگرام یا واتس‌اپ Ctrl+V بزنید.", "” was copied. Press Ctrl+V in Telegram or WhatsApp."), Theme.Ok);
        }

        void ShowInfo(string t, Color c)
        {
            infoText = t ?? "";
            infoColor = c;
            if (infoRow != null) infoRow.Invalidate();
        }

        static Label Caption(string t)
        {
            return new Label { Text = t, Font = Theme.Bold, ForeColor = Theme.LabelColor, AutoSize = true, Margin = Theme.Pad(0, 4, 0, 6), UseMnemonic = false };
        }

        static PanelRange ParseKind(string s)
        {
            PanelRange k;
            return Enum.TryParse(s ?? "", out k) && Array.IndexOf(Kinds, k) >= 0 ? k : PanelRange.Today;
        }

        TextParts Parts()
        {
            TextParts p = TextParts.None;
            foreach (KeyValuePair<TextParts, CheckBox> t in ticks) if (t.Value.Checked) p |= t.Key;
            return p;
        }

        void Remember()
        {
            settings.ReportParts = ((int)Parts()).ToString(Inv);
            settings.ReportRange = Kinds[range.Selected].ToString();
            try { settings.Save(); } catch (Exception e) { Log.Write("settings: " + e.Message); }
        }

        /// <summary>The two dates of «بازه…» as last applied.</summary>
        void Custom(out DateTime from, out DateTime to) { from = customFrom; to = customTo; }

        void ApplyCustom()
        {
            DateTime? a = Gd.Parse(fromBox.Text), b = Gd.Parse(toBox.Text);
            if (a == null || b == null)
            {
                Ui.Message(this, Lang.T("تاریخ‌ها را میلادی و به شکل 2026.11.01 بنویسید.", "Write the dates in the Gregorian calendar, like 2026.11.01."), MessageBoxIcon.Warning);
                return;
            }
            customFrom = a.Value;
            customTo = b.Value;
            Rebuild();
        }

        string RangeLine(PanelRange kind, ReportRange r)
        {
            string day = WeekDays[(int)r.From.DayOfWeek] + " " + r.From.ToString("yyyy.MM.dd", Inv);
            DateTime last = r.To > r.From ? r.To.AddTicks(-1).Date : r.From.Date;
            switch (kind)
            {
                case PanelRange.Today: return day + Lang.T(" · از شروع روز کارگزار تا الان", " · from the broker's day start to now");
                case PanelRange.Yesterday: return day + Lang.T(" · روز معاملاتی قبل", " · the previous trading day");
                case PanelRange.Week: return Lang.T("این هفته: از ", "This week: from ") + day + Lang.T(" تا الان", " to now");
                case PanelRange.Month: return Lang.T("این ماه: از ", "This month: from ") + r.From.ToString("yyyy.MM.dd", Inv) + Lang.T(" تا الان", " to now");
                default: return Lang.T("از ", "From ") + r.From.ToString("yyyy.MM.dd", Inv) + Lang.T(" تا ", " up to ") + last.ToString("yyyy.MM.dd", Inv);
            }
        }

        /// <summary>Makes the text again (a tick, the range, or a history read again) and says who still needs reading.</summary>
        void Rebuild(bool reload = true)
        {
            PanelRange kind = Kinds[range.Selected];
            DateTime a, b;
            Custom(out a, out b);
            ReportRange r = src.RangeOf(kind, a, b);
            dateLine.Text = RangeLine(kind, r);
            List<TextEntry> all = reload ? src.Entries(kind, a, b) : lastEntries;
            lastEntries = all;
            lastRange = r;
            List<int> next = ReportTextBrowse.Indices(all, search.Box.Text, sort.SelectedIndex).Where(k => k < roster.Count).ToList();
            if (!next.SequenceEqual(visibleIndices)) rosterPanel.AutoScrollPosition = Point.Empty;
            visibleIndices = next;
            rosterPanel.Height = Math.Min(5, Math.Max(1, visibleIndices.Count)) * Theme.S(28) + 2;
            LayoutRoster();
            // 3.26 (CHANGE-018): only those ticked in the list on the right.
            List<int> on = Included();
            List<TextEntry> entries = on.Where(k => k < all.Count).Select(k => all[k]).ToList();
            text = entries.Count == 0 ? "" : ReportText.Make(r, entries, Parts());
            matchCount.Text = visibleIndices.Count == 0 ? Lang.T("نتیجه‌ای پیدا نشد.", "No matches found.")
                : Fa.N(visibleIndices.Count) + Lang.T(" از ", " of ") + Fa.N(roster.Count) + Lang.T(" دانشجو · ", " students · ") + Fa.N(entries.Count) + Lang.T(" انتخاب‌شده", " selected");
            copyButton.Enabled = saveButton.Enabled = entries.Count > 0 && text.Length > 0;
            head.Invalidate();
            int top = box.SelectionStart;
            ShowText(entries);
            box.SelectionStart = Math.Min(top, box.TextLength);
            box.SelectionLength = 0;
            int lines = text.Length == 0 ? 0 : text.Split('\n').Length;
            info = Fa.N(entries.Count) + Lang.T(" دانشجو · ", " students · ") + Fa.N(lines) + Lang.T(" خط", " lines");
            note = "";
            ShowInfo(info, Theme.Muted);
            fingerprint = src.Fingerprint();
            List<string> notes = src.StaleNotes != null ? src.StaleNotes() : null;
            for (int k = 0; k < roster.Count; k++) roster[k].Tag2 = notes != null && k < notes.Count ? notes[k] : "";
            ShowWarning();
        }

        /// <summary>The text in the box, each student's name line in the program's Persian font, bold (only how it is shown).</summary>
        List<TextEntry> shownEntries;

        void ShowText(List<TextEntry> entries)
        {
            shownEntries = entries;
            box.SuspendLayout();
            box.Text = entries.Count == 0 ? (visibleIndices.Count == 0 ? Lang.T("نتیجه‌ای پیدا نشد. نام یا شمارهٔ حساب دیگری جستجو کنید.", "No matches found. Search for another name or account.")
                : Lang.T("برای نمایش متن گزارش، یک دانشجو را انتخاب کنید.", "Select a student to show report text.")) : text;
            box.SelectAll();
            box.SelectionFont = box.Font;
            if ((Parts() & TextParts.Name) != 0)
                foreach (TextEntry e in entries)
                {
                    string line = e.Number.ToString(Inv) + ". " + (e.Name ?? "").Trim();
                    int at = box.Find(line, 0, RichTextBoxFinds.MatchCase);
                    while (at >= 0)
                    {
                        box.Select(at, line.Length);
                        box.SelectionFont = nameFont;
                        int next = at + line.Length;
                        at = next < box.TextLength ? box.Find(line, next, RichTextBoxFinds.MatchCase) : -1;
                    }
                }
            box.Select(0, 0);
            box.ResumeLayout();
        }

        readonly Font nameFont = new Font(Theme.Bold.FontFamily, Theme.Bold.SizeInPoints + 0.5f, Theme.Bold.Style, GraphicsUnit.Point);

        void ShowWarning()
        {
            int reading = src.Reading();
            readingWas = reading;
            List<string> stale = src.NotReadToday();
            if (reading > 0)
            {
                warnText.Text = Lang.T("در حال خواندن… ", "Reading… ") + Fa.N(reading) + Lang.T(" نفر مانده. متن خودش به‌روز می‌شود.", " left. The text updates by itself.");
                readNow.Enabled = false;
                warn.Visible = true;
            }
            else if (stale.Count > 0)
            {
                DateTime? since = src.StaleSince();
                warnText.Text = since.HasValue
                    ? Lang.T("گزارش ", "The report of ") + Fa.N(stale.Count) + Lang.T(" نفر مال ", " students is from ") + PanelMath.Ago(since.Value, DateTime.Now) + Lang.T(" است. برای دقت، دوباره به‌روزرسانی کنید.", ". Refresh for accuracy.")
                    : Lang.T("اطلاعات ", "The data of ") + Fa.N(stale.Count) + Lang.T(" نفر هنوز خوانده نشده: ", " students is not read yet: ") + string.Join(Lang.T("، ", ", "), stale.Take(4)) + (stale.Count > 4 ? Lang.T("، …", ", …") : "");
                readNow.Enabled = true;
                warn.Visible = true;
            }
            else warn.Visible = false;
        }

        /// <summary>Every second: a history read again makes the text again; the reading's progress shows in the warning.</summary>
        void Poll()
        {
            try
            {
                if (src.Fingerprint() != fingerprint) { Rebuild(); return; }
                if (src.Reading() != readingWas) ShowWarning();
            }
            catch (Exception e) { Log.Write("report text: " + e.Message); }
        }

        void Copy(object sender, EventArgs e)
        {
            if (text.Length == 0) return;
            try { Clipboard.SetDataObject(text, true, 5, 100); }
            catch (Exception ex)
            {
                Log.Write("report text copy: " + ex.Message);
                Ui.Message(this, Lang.T("کلیپ‌بورد ویندوز دست برنامه‌ی دیگری است. چند لحظه بعد دوباره «کپی همه» را بزنید.", "The Windows clipboard is held by another program. Press “Copy all” again in a moment."), MessageBoxIcon.Warning);
                return;
            }
            note = Copied;
            ShowInfo(note, Theme.Ok);
        }

        void SaveText()
        {
            if (text.Length == 0) return;
            using (var dialog = new SaveFileDialog { Filter = "Text (*.txt)|*.txt", DefaultExt = "txt", AddExtension = true, FileName = "MetaFactory-report-" + lastRange.From.ToString("yyyy-MM-dd", Inv) + ".txt" })
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                try { File.WriteAllText(dialog.FileName, text, new UTF8Encoding(true)); ShowInfo(Lang.T("✓ متن نمایش‌داده‌شده ذخیره شد.", "✓ Displayed report text saved."), Theme.Ok); }
                catch (Exception ex) { Log.Write("report text save: " + ex.Message); Ui.Message(this, Lang.T("ذخیرهٔ متن انجام نشد. مسیر دیگری انتخاب کنید.", "Could not save the text. Choose another location."), MessageBoxIcon.Warning); }
            }
        }

#if SNAPSHOT
        public void Preview(int rangeIndex, TextParts off)
        {
            foreach (KeyValuePair<TextParts, CheckBox> t in ticks) if ((off & t.Key) != 0) t.Value.Checked = false;
            range.Selected = rangeIndex;
            customRow.Visible = Kinds[range.Selected] == PanelRange.Custom;
            Rebuild();
        }
#endif
    }
}
