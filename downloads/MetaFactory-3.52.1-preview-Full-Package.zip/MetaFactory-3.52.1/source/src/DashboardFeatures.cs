using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Windows.Forms;

namespace MTManager
{
    public enum ServerCategory { Demo, Real, Unknown }
    public static class ServerCategories
    {
        public static ServerCategory Of(string server)
        {
            string s = server ?? "";
            bool demo = Regex.IsMatch(s, @"(^|[-_.\s])(?:mt[45])?(demo|trial|practice)[0-9]*($|[-_.\s])", RegexOptions.IgnoreCase);
            bool real = Regex.IsMatch(s, @"(^|[-_.\s])(?:mt[45])?(real|live)[0-9]*($|[-_.\s])", RegexOptions.IgnoreCase);
            return demo == real ? ServerCategory.Unknown : demo ? ServerCategory.Demo : ServerCategory.Real;
        }
    }
    static class DashboardSort
    {
        public static readonly string[] Columns = { "Trader", "Copy", "Login", "Server", "Folders", "Today", "Status" };
        public static int Number(string a, string b)
        {
            a = TextUtil.LatinDigits(a ?? "").TrimStart('0'); b = TextUtil.LatinDigits(b ?? "").TrimStart('0');
            int length = a.Length.CompareTo(b.Length); return length != 0 ? length : string.CompareOrdinal(a, b);
        }
        static int Text(string a, string b)
        { return CultureInfo.GetCultureInfo(Lang.En ? "en-US" : "fa-IR").CompareInfo.Compare(a ?? "", b ?? "", CompareOptions.IgnoreCase); }
        public static int Natural(string a, string b)
        {
            var left = Regex.Matches(TextUtil.LatinDigits(a ?? ""), @"\d+|\D+").Cast<Match>().Select(m => m.Value).ToArray();
            var right = Regex.Matches(TextUtil.LatinDigits(b ?? ""), @"\d+|\D+").Cast<Match>().Select(m => m.Value).ToArray();
            for (int n = 0; n < Math.Min(left.Length, right.Length); n++)
            {
                int result = char.IsDigit(left[n][0]) && char.IsDigit(right[n][0]) ? Number(left[n], right[n]) : Text(left[n], right[n]);
                if (result != 0) return result;
            }
            return left.Length.CompareTo(right.Length);
        }
        static int Status(CopyRow row)
        {
            switch (row.State)
            {
                case RowState.Active: return 0;
                case RowState.Inactive: return 1;
                case RowState.Pending: return 2;
                case RowState.Warn: return 3;
                case RowState.Bad: return 4;
                case RowState.On: return 5;
                case RowState.Open: return 6;
                default: return 7;
            }
        }
        static int Compare(CopyRow a, CopyRow b, string column, int direction)
        {
            int result = 0;
            switch (column)
            {
                case "Trader": result = Text(a.Trader, b.Trader); break;
                case "Copy": result = Text(a.Kind, b.Kind); if (result == 0) result = Natural(a.Name, b.Name); break;
                case "Login":
                    if (a.Login.Length == 0 || b.Login.Length == 0) return a.Login.Length == b.Login.Length ? 0 : a.Login.Length == 0 ? 1 : -1;
                    result = Number(a.Login, b.Login); break;
                case "Server":
                    ServerCategory sa = ServerCategories.Of(a.Server), sb = ServerCategories.Of(b.Server);
                    if (sa == ServerCategory.Unknown || sb == ServerCategory.Unknown) { if (sa != sb) return sa == ServerCategory.Unknown ? 1 : -1; }
                    else if (sa != sb) return direction * sa.CompareTo(sb);
                    result = Natural(a.Server, b.Server); break;
                case "Folders": result = Text(string.Join(" | ", a.Folders.OrderBy(x => x)), string.Join(" | ", b.Folders.OrderBy(x => x))); break;
                case "Today":
                    if (!a.TodayNet.HasValue || !b.TodayNet.HasValue) return a.TodayNet.HasValue == b.TodayNet.HasValue ? 0 : a.TodayNet.HasValue ? -1 : 1;
                    // Actual trades precede no-trade reports in either direction. In the
                    // Today header's profit-first mode, breakeven follows gains and losses.
                    if (a.TodayHasTrades != b.TodayHasTrades) return a.TodayHasTrades ? -1 : 1;
                    if (direction < 0 && a.TodayHasTrades)
                    {
                        bool az = Math.Round(a.TodayNet.Value, 2) == 0, bz = Math.Round(b.TodayNet.Value, 2) == 0;
                        if (az != bz) return az ? 1 : -1;
                    }
                    result = a.TodayNet.Value.CompareTo(b.TodayNet.Value); break;
                case "Status": result = Status(a).CompareTo(Status(b)); break;
            }
            return direction * Math.Sign(result);
        }
        public static List<CopyRow> Apply(IEnumerable<CopyRow> source, string column, int direction)
        {
            var list = source.ToList();
            if (direction == 0 || !Columns.Contains(column)) return list;
            // LINQ OrderBy is stable: equal values retain the user's underlying order.
            return list.OrderBy(r => r, Comparer<CopyRow>.Create((a, b) => Compare(a, b, column, direction))).ToList();
        }
    }
    /// <summary>Equal work per student; starting/reading are known phase milestones, not elapsed-time predictions.</summary>
    public sealed class ReportWorkProgress
    {
        readonly Dictionary<string, double> phases = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        readonly HashSet<string> finished = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        readonly HashSet<string> failed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public bool Cancelled { get; private set; }
        public int Total { get { return phases.Count; } }
        public int Done { get { return finished.Count; } }
        public int Failed { get { return failed.Count; } }
        public bool Complete { get { return Total > 0 && Done == Total && !Cancelled; } }
        public double Fraction { get { return Total == 0 ? 0 : phases.Values.Sum() / Total; } }
        public void Begin() { phases.Clear(); finished.Clear(); failed.Clear(); Cancelled = false; }
        public void Add(string name) { if (!phases.ContainsKey(name)) phases[name] = 0; }
        public void Update(string name, StepState state)
        {
            if (Cancelled || !phases.ContainsKey(name) || finished.Contains(name)) return;
            if (state == StepState.Done || state == StepState.Failed || state == StepState.Skipped)
            { phases[name] = 1; finished.Add(name); if (state == StepState.Failed) failed.Add(name); }
            else phases[name] = Math.Max(phases[name], state == StepState.Starting ? 0.1 : state == StepState.Reading ? 0.55 : 0);
        }
        public void Cancel() { Cancelled = true; }
    }
    sealed class ReportProgressStrip : Control
    {
        readonly Timer animation = new Timer { Interval = 30 };
        readonly Timer elapsedTimer = new Timer { Interval = 1000 };
        ReportRunSummary currentSummary;
        double value, target;
        string caption = "", counter = "";
        readonly ModernButton stopButton;
        public event Action StopRequested;
        public ReportProgressStrip()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Height = Theme.S(68); TabStop = false; BackColor = Theme.Page;
            stopButton = new ModernButton(Lang.T("توقف گزارش‌گیری", "Stop reports"), (s, e) => { var action = StopRequested; if (action != null) action(); }, ButtonKind.Danger);
            Controls.Add(stopButton);
            Resize += (s, e) => { int x = Lang.En ? Width - Theme.S(164) : Theme.S(24); stopButton.SetBounds(x, Theme.S(1), Theme.S(140), Theme.S(28)); };
            elapsedTimer.Tick += (s, e) => { UpdateCaption(); Invalidate(); if (currentSummary == null || currentSummary.Finished) elapsedTimer.Stop(); };
            animation.Tick += (s, e) => { double step = Math.Max(0.006, Math.Abs(target - value) * 0.2); value = Math.Abs(target - value) <= step ? target : value + Math.Sign(target - value) * step; Invalidate(); if (value == target) animation.Stop(); };
        }
        public void Set(ReportWorkProgress progress, bool reset = false) { Set(progress, null, reset); }
        public void Set(ReportWorkProgress progress, ReportRunSummary summary, bool reset = false)
        {
            currentSummary = summary;
            Visible = progress.Total > 0; target = progress.Fraction;
            if (reset) value = 0;
            caption = progress.Cancelled ? Lang.T("گزارش‌گیری متوقف شد", "Report reading stopped") : progress.Complete ? Lang.T("گزارش‌گیری پایان یافت", "Report reading finished") : Lang.T("در حال دریافت گزارش‌ها", "Reading reports");
            counter = Fa.N(progress.Done) + Lang.T(" از ", " of ") + Fa.N(progress.Total) + Lang.T(" بررسی شد", " processed") + " · " + Fa.N(target >= 1 ? 100 : Math.Min(99, (int)Math.Floor(target * 100))) + Lang.T("٪", "%") + (progress.Failed > 0 ? " · " + Fa.N(progress.Failed) + Lang.T(" ناموفق", " failed") : "");
            if (summary != null) { counter = summary.Counts(); UpdateCaption(); }
            if (Visible && summary != null && !summary.Finished) elapsedTimer.Start(); else elapsedTimer.Stop();
            stopButton.Enabled = summary == null ? !progress.Complete && !progress.Cancelled : !summary.Finished && !summary.Stopping;
            stopButton.Visible = stopButton.Enabled;
            animation.Start(); Invalidate();
        }
        public void SetLaunch(LaunchWorkProgress progress,bool reset=false)
        {
            currentSummary=null;elapsedTimer.Stop();Visible=progress.Total>0;
            target=progress.Fraction;if(reset)value=0;
            caption=progress.Stopping?Lang.T("در حال توقف؛ نسخهٔ در حال آماده‌سازی تمام می‌شود…","Stopping; current preparation is finishing…")
                :progress.Stopped?Lang.T("ادامهٔ صف اجرا متوقف شد","Launch queue stopped")
                :progress.Finished?Lang.T("صف شروع اجرا پایان یافت","Launch dispatch finished")
                :Lang.T("در حال باز کردن متاتریدرها","Opening MetaTraders");
            counter=Fa.N(progress.Done)+Lang.T(" از "," of ")+Fa.N(progress.Total)+Lang.T(" پردازش شد"," processed")+" · "+Fa.N((int)(progress.Fraction*100))+Lang.T("٪","%")
                +" · "+Fa.N(progress.Failed)+Lang.T(" ناموفق"," failed")+(progress.Skipped>0?" · "+Fa.N(progress.Skipped)+Lang.T(" لغوشده"," cancelled"):"")+" · "+Fa.N(progress.Remaining)+Lang.T(" باقی‌مانده"," remaining")
                +(string.IsNullOrEmpty(progress.Detail)?"":" · "+progress.Detail);
            stopButton.Text=Lang.T("توقف اجرا","Stop launching");stopButton.Enabled=!progress.Finished&&!progress.Stopped;stopButton.Visible=stopButton.Enabled;
            AccessibleName=caption+". "+counter;animation.Start();Invalidate();
        }
        void UpdateCaption()
        {
            if (currentSummary == null) return;
            caption = currentSummary.Finished
                ? (currentSummary.Stopping ? Lang.T("گزارش‌گیری متوقف شد", "Report reading stopped") : Lang.T("گزارش‌گیری پایان یافت", "Report reading finished"))
                : currentSummary.Stopping ? Lang.T("در حال توقف گزارش‌گیری…", "Stopping report reading…") : Lang.T("در حال دریافت گزارش‌ها", "Reading reports");
            caption += Lang.T(" · زمان: ", " · Time: ") + currentSummary.ElapsedText;
            AccessibleName = caption + ". " + counter;
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor); int margin = Theme.S(24);
            var text = new Rectangle(margin, Theme.S(2), Math.Max(0, Width - margin * 2), Theme.S(22));
            var right = new Rectangle(text.X + text.Width / 2, text.Y, text.Width / 2, text.Height);
            var left = new Rectangle(text.X, Theme.S(31), text.Width, Theme.S(20));
            Theme.Line(e.Graphics, caption, Theme.Small, Theme.Flip(right, text), Theme.Text);
            TextRenderer.DrawText(e.Graphics, counter, Theme.Small, Theme.Flip(left, text), Theme.Muted, TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding | (Lang.En ? TextFormatFlags.Right : TextFormatFlags.Left | TextFormatFlags.RightToLeft));
            var track = new Rectangle(margin, Theme.S(57), Math.Max(0, Width - margin * 2), Theme.S(6));
            if (track.Width <= 0) return;
            Theme.Box(e.Graphics, track, Theme.Sf(3), Theme.Border, Color.Transparent);
            int filled = Math.Max(0, Math.Min(track.Width, (int)Math.Round(track.Width * value)));
            if (filled > 0) Theme.Box(e.Graphics, new Rectangle(Lang.En ? track.X : track.Right - filled, track.Y, filled, track.Height), Theme.Sf(3), Color.FromArgb(66,71,81), Color.Transparent);
        }
        protected override void Dispose(bool disposing) { if (disposing) { animation.Dispose(); elapsedTimer.Dispose(); } base.Dispose(disposing); }
    }
}
