using System;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;

namespace MTManager
{
    sealed class VerificationQueueDialog : Form
    {
        readonly DataGridView grid = new DataGridView();
        readonly Label summary = new Label();
        readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer { Interval = 1000 };
        readonly AccountStore accounts;
        readonly ImportCoordinator imports;
        public VerificationQueueDialog(AccountStore accounts, ImportCoordinator imports)
        {
            this.accounts = accounts; this.imports = imports;
            Text = Lang.T("بررسی اتصال دانشجوها", "Student connection checks"); Font = Theme.Font; BackColor = Theme.Page; ForeColor = Theme.Text;
            StartPosition = FormStartPosition.CenterParent; Size = new Size(Theme.S(1000), Theme.S(600)); RightToLeft = Theme.Dir;
            Theme.Window(this);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 4, ColumnCount = 1, Padding = Theme.Pad(20, 16) };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,Theme.S(54)));var heading=Theme.GraphiteHeader(Text);heading.Dock=DockStyle.Fill;layout.Controls.Add(heading,0,0);
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, Theme.S(50))); layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, Theme.S(60)));
            summary.Dock = DockStyle.Fill; summary.TextAlign = Lang.En ? ContentAlignment.MiddleLeft : ContentAlignment.MiddleRight; layout.Controls.Add(summary, 0, 1);
            grid.Dock = DockStyle.Fill; grid.ReadOnly = true; grid.AllowUserToAddRows = false; grid.AllowUserToDeleteRows = false; grid.RowHeadersVisible = false; grid.BackgroundColor = Theme.Surface; grid.BorderStyle = BorderStyle.None; grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; grid.RightToLeft = Theme.Dir;
            grid.Font = Theme.Font; grid.EnableHeadersVisualStyles = false; grid.ColumnHeadersDefaultCellStyle.BackColor = Theme.Footer; grid.ColumnHeadersDefaultCellStyle.ForeColor = Theme.Text;
            grid.DefaultCellStyle.BackColor = Theme.Surface; grid.DefaultCellStyle.ForeColor = Theme.Text; grid.DefaultCellStyle.SelectionBackColor = Theme.AccentSoft; grid.DefaultCellStyle.SelectionForeColor = Theme.Text;
            foreach (string title in new[] { Lang.T("دانشجو", "Student"), Lang.T("حساب", "Account"), Lang.T("سرور", "Server"), Lang.T("وضعیت", "Status"), Lang.T("توضیحات", "Details") }) grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = title, SortMode = DataGridViewColumnSortMode.NotSortable });
            grid.Columns[4].FillWeight = 230; grid.RowTemplate.Height = Theme.S(42); layout.Controls.Add(grid, 0, 2);
            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, FlowDirection = Lang.En ? FlowDirection.LeftToRight : FlowDirection.RightToLeft };
            buttons.Controls.Add(new ModernButton(Lang.T("توقف", "Pause"), (s, e) => Guard(() => imports.Pause()), ButtonKind.Secondary));
            buttons.Controls.Add(new ModernButton(Lang.T("ادامه", "Resume"), (s, e) => Guard(() => imports.Resume(false)), ButtonKind.Primary));
            buttons.Controls.Add(new ModernButton(Lang.T("تلاش دوبارهٔ ناموفق‌ها", "Retry unsuccessful"), (s, e) => Guard(() => imports.Resume(true)), ButtonKind.Secondary));
            buttons.Controls.Add(new ModernButton(Lang.T("خروجی نتیجه", "Export results"), (s, e) => Export(), ButtonKind.Secondary));
            buttons.Controls.Add(new ModernButton(Lang.T("بستن", "Close"), (s, e) => Close(), ButtonKind.Subtle));
            layout.Controls.Add(buttons, 0, 3); Controls.Add(layout); timer.Tick += (s, e) => RefreshRows();
            Shown += (s, e) => { RefreshRows(); timer.Start(); }; FormClosed += (s, e) => timer.Dispose();
        }
        void Guard(Action action) { try { action(); RefreshRows(); } catch (Exception e) { Ui.Error(this, e); } }
        void RefreshRows()
        {
            string selected = grid.CurrentRow == null ? "" : Convert.ToString(grid.CurrentRow.Tag);
            int scroll = Math.Max(0, grid.FirstDisplayedScrollingRowIndex);
            var rows = accounts.All.Where(a => a.VerifyState.Length > 0).OrderBy(a => a.Instance).ToArray();
            grid.SuspendLayout(); grid.Rows.Clear();
            foreach (Account a in rows)
            {
                int n = grid.Rows.Add(a.Trader, a.Login, a.Server, ImportCoordinator.Status(a.VerifyState), a.VerifyReason);
                grid.Rows[n].Tag = a.Instance; grid.Rows[n].Cells[4].ToolTipText = a.VerifyReason;
                grid.Rows[n].Cells[3].Style.ForeColor = a.VerifyState == "connected" ? Theme.Ok : a.VerifyState == "rejected" ? Theme.Bad : Theme.Accent;
                if (a.Instance == selected) grid.CurrentCell = grid.Rows[n].Cells[0];
            }
            if (grid.Rows.Count > scroll) grid.FirstDisplayedScrollingRowIndex = scroll;
            grid.ResumeLayout();
            summary.Text = rows.Length + Lang.T(" حساب · تأییدشده: ", " accounts · verified: ") + rows.Count(a => a.VerifyState == "connected") + Lang.T(" · بررسی پس‌زمینه ", " · background checks ") + (imports.Paused ? Lang.T("متوقف است", "paused") : Lang.T("فعال است", "active"));
        }
        void Export()
        {
            using (var d = new SaveFileDialog { Filter = "Excel (*.xlsx)|*.xlsx", FileName = "MetaFactory-connection-results.xlsx" })
                if (d.ShowDialog(this) == DialogResult.OK) Guard(() => imports.Export(d.FileName));
        }
    }
}
