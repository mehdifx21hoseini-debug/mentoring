using System;
using System.Linq;
using System.Threading.Tasks;

namespace MTManager
{
    static partial class Tests
    {
        static ReportResourceSnapshot AdaptiveResources(long now, ulong free = 2200, double cpu = 40)
        { return new ReportResourceSnapshot { Processors = 4, TotalMb = 8075, FreeMb = free, CpuPercent = cpu, MonotonicMs = now }; }
        static ReportAdaptiveAdmission.Lease AdaptiveEnter(ReportAdaptiveAdmission policy, int slot, long now, ulong free = 2200)
        {
            ReportAdaptiveAdmission.Lease lease;
            Check(policy.TryEnter(slot, AdaptiveResources(now, free), out lease), "adaptive test report admitted on slot " + slot);
            return lease;
        }
        static ReportAdaptiveAdmission AdaptiveSeed(bool mt4 = true, int ceiling = 3)
        {
            var policy = new ReportAdaptiveAdmission(1, ceiling, mt4);
            AdaptiveEnter(policy, 1, 0).Complete(true, 10000, mt4 ? 150UL : 600UL, AdaptiveResources(10000, 3000));
            AdaptiveEnter(policy, 1, 10000, 3000).Complete(true, 10000, mt4 ? 150UL : 600UL, AdaptiveResources(20000, 3000));
            ReportAdaptiveAdmission.Lease lease;
            Check(!policy.TryEnter(2, AdaptiveResources(20000, 3000), out lease), "two measured outcomes begin stability window rather than immediate promotion");
            Check(policy.TryEnter(2, AdaptiveResources(22000, 3000), out lease), "second worker follows sustained low pressure");
            lease.Dispose(); return policy;
        }
        static ReportAdaptiveAdmission AdaptiveThirdTrial()
        {
            ReportAdaptiveAdmission policy = AdaptiveSeed();
            for (int n = 0; n < 3; n++)
            {
                long at = 22000 + n * 10000;
                var first = AdaptiveEnter(policy, 1, at); var second = AdaptiveEnter(policy, 2, at);
                first.Complete(true, 10000, 150, AdaptiveResources(at + 10000));
                second.Complete(true, 10000, 150, AdaptiveResources(at + 10000));
            }
            ReportAdaptiveAdmission.Lease lease;
            Check(!policy.TryEnter(3, AdaptiveResources(52000), out lease), "six concurrent fresh reports begin third-worker stability window");
            Check(policy.TryEnter(3, AdaptiveResources(54000), out lease), "third-worker bounded trial begins only after stable useful two-worker samples");
            lease.Dispose(); return policy;
        }
        static void ReportAdaptiveChecks()
        {
            var settings = new Settings(); var low = AdaptiveResources(0);
            Equal(3, ReportAdaptivePolicy.Ceiling(settings, Enumerable.Repeat(Kind.MT4, 10), 1, low), "low-RAM MT4 candidate ceiling is three, not immediate three starts");
            Equal(2, ReportAdaptivePolicy.Ceiling(settings, Enumerable.Repeat(Kind.MT5, 10), 1, low), "low-RAM MT5 has shared ceiling two");
            Equal(2, ReportAdaptivePolicy.Ceiling(settings, new[] { Kind.MT4, Kind.MT5, Kind.MT4 }, 1, low), "mixed platforms share one two-worker pilot ceiling");
            Equal(1, ReportAdaptivePolicy.Ceiling(new Settings { ReportAtOnce = 1 }, Enumerable.Repeat(Kind.MT4, 10), 4, low), "explicit serial setting wins over resource capacity");
            Equal(2, ReportAdaptivePolicy.Ceiling(new Settings { ReportAtOnce = 2 }, Enumerable.Repeat(Kind.MT4, 10), 1, low), "explicit two-worker maximum prevents third trial");
            Equal(4, ReportAdaptivePolicy.Ceiling(settings, Enumerable.Repeat(Kind.MT5, 10), 4, new ReportResourceSnapshot { Processors = 8, TotalMb = 16000, FreeMb = 6000 }), "strong-machine four-worker baseline remains available");
            Equal(1, ReportAdaptivePolicy.Ceiling(settings, new[] { Kind.MT4 }, 1, low), "single-account batches stay serial");
            Equal(1, ReportAdaptivePolicy.Ceiling(settings, Enumerable.Repeat(Kind.MT4, 10), 1, AdaptiveResources(0, 1000)), "low free RAM prevents provisioning extra pilot slots");

            var unmeasured = new ReportAdaptiveAdmission(1, 2, false);
            AdaptiveEnter(unmeasured, 1, 0).Complete(true, 1000, 0, AdaptiveResources(1000));
            AdaptiveEnter(unmeasured, 1, 1000).Complete(true, 1000, 0, AdaptiveResources(2000));
            ReportAdaptiveAdmission.Lease held;
            Check(!unmeasured.TryEnter(2, AdaptiveResources(5000), out held), "unmeasured MT5 helper bundle cannot authorize promotion");
            var unknown = AdaptiveSeed(); unknown.ObserveBundle(1, false, 0, 0, 22000);
            var one = AdaptiveEnter(unknown, 1, 22000); unknown.ObserveBundle(1, false, 0, 0, 22000);
            Check(!unknown.TryEnter(3, AdaptiveResources(40000, 2200, -1), out held), "unknown CPU and bundle samples cannot promote third worker"); one.Dispose();

            var pressure = AdaptiveSeed();
            Check(!pressure.TryEnter(2, AdaptiveResources(23000, 2200, 95), out held), "high CPU pauses new admissions");
            Equal(1, pressure.Limit, "CPU pressure reduces promoted capacity without aborting readers");
            Check(!pressure.TryEnter(2, AdaptiveResources(25000, 2200, -1), out held), "unknown CPU does not permit repromotion");
            Check(!pressure.TryEnter(2, AdaptiveResources(27000), out held), "recovery starts another stability window");
            Check(pressure.TryEnter(2, AdaptiveResources(29000), out held), "stable recovery permits second worker again"); held.Dispose();

            var budget = new ReportAdaptiveAdmission(2, 2, false);
            var firstBudget = AdaptiveEnter(budget, 1, 0, 2200);
            Check(!budget.TryEnter(2, AdaptiveResources(0, 1800), out held), "unstarted first bundle reserves memory before native process registration");
            budget.NativeReserved(1);
            var handed = AdaptiveResources(0, 2200); handed.PendingGrowthMb = 512;
            Check(budget.TryEnter(2, handed, out held), "native budget handoff does not count first startup growth twice");
            Equal(2, budget.Active, "shared admission owns both report leases");
            held.Dispose(); budget.NativeReleased(1);
            Check(!budget.TryEnter(2, AdaptiveResources(0, 1800), out held), "failed native launch restores controller startup reservation");
            firstBudget.Dispose(); Equal(0, budget.Active, "cancellation disposal releases lease without a report outcome");
            firstBudget.Dispose(); Equal(0, budget.Active, "lease disposal is idempotent");

            var atomic = new ReportAdaptiveAdmission(1, 1, true); int admitted = 0;
            Parallel.For(0, 20, n => { ReportAdaptiveAdmission.Lease item; if (atomic.TryEnter(1, AdaptiveResources(0), out item)) System.Threading.Interlocked.Increment(ref admitted); });
            Equal(1, admitted, "concurrent admissions cannot overbook a worker slot");

            var trial = AdaptiveThirdTrial();
            Check(trial.ThirdTrial && trial.Limit == 3, "third slot is an explicit bounded observation trial");
            for (int n = 0; n < 2; n++)
            {
                long now = 54000 + n * 10000;
                var a = AdaptiveEnter(trial, 1, now); var b = AdaptiveEnter(trial, 2, now); var c = AdaptiveEnter(trial, 3, now);
                a.Complete(true, 10000, 150, AdaptiveResources(now + 10000));
                b.Complete(true, 10000, 150, AdaptiveResources(now + 10000));
                c.Complete(true, 10000, 150, AdaptiveResources(now + 10000));
            }
            Check(trial.Limit == 3 && !trial.ThirdTrial && !trial.ThirdRejected, "observed throughput improvement retains third worker without changing report validity");
            var late = AdaptiveEnter(trial, 1, 74000); late.Complete(false, 5000, 150, AdaptiveResources(79000));
            Check(trial.Limit == 2 && trial.ThirdRejected, "unsuccessful report during retained concurrency rolls future claims back to two");
            Check(!trial.TryEnter(3, AdaptiveResources(100000), out held), "rejected third-worker trial does not oscillate back within same batch");

            var slower = AdaptiveThirdTrial();
            for (int n = 0; n < 2; n++)
            {
                long now = 54000 + n * 18000;
                var a = AdaptiveEnter(slower, 1, now); var b = AdaptiveEnter(slower, 2, now);
                ReportAdaptiveAdmission.Lease c; bool third = slower.TryEnter(3, AdaptiveResources(now), out c);
                a.Complete(true, 18000, 150, AdaptiveResources(now + 18000));
                b.Complete(true, 18000, 150, AdaptiveResources(now + 18000));
                if (third) c.Complete(true, 18000, 150, AdaptiveResources(now + 18000));
            }
            Check(slower.Limit == 2 && slower.ThirdRejected, "higher observed report latency rolls back even if all reports remain valid");

            var bounded = AdaptiveThirdTrial(); var running = AdaptiveEnter(bounded, 3, 54000);
            Check(!bounded.TryEnter(3, AdaptiveResources(115000), out held), "an occupied slot cannot be acquired twice");
            ReportAdaptiveAdmission.Lease other; bounded.TryEnter(1, AdaptiveResources(115000), out other);
            Check(bounded.Limit == 2 && bounded.ThirdRejected && bounded.Active >= 1, "trial times out without killing a still-running report");
            running.Complete(true, 62000, 150, AdaptiveResources(116000)); if (other != null) other.Dispose();
            Equal(0, bounded.Active, "late completion from previous generation releases safely after rollback");
        }
    }
}
