using System;
using System.Collections.Generic;
using System.Linq;

namespace MTManager
{
    internal static class ReportAdaptivePolicy
    {
        // This is a ceiling, not permission to start that many workers immediately.
        public static int Ceiling(Settings settings, IEnumerable<Kind> kinds, int baseline, ReportResourceSnapshot resources)
        {
            Kind[] all = kinds.ToArray();
            int requested = settings.ReportAtOnce > 0 ? ReportParallel.Clamp(settings.ReportAtOnce) : ReportParallel.Max;
            int limit = Math.Max(1, Math.Min(requested, baseline));
            if (requested > 1 && all.Length > 1 && resources.Processors >= 4 && resources.TotalMb >= 7500
                && resources.FreeMb >= LaunchMemoryPolicy.Reserve(resources.TotalMb) + 768)
                limit = Math.Max(limit, Math.Min(requested, all.All(k => k == Kind.MT4) ? 3 : 2));
            return Math.Max(1, Math.Min(limit, Math.Max(1, all.Length)));
        }
    }

    /// <summary>
    /// One shared admission budget for all platforms. A lease is acquired before an account is claimed.
    /// Resource or trial rollback changes future admission only; it never aborts an active report.
    /// Throughput comparisons describe observed windows, not a controlled causal benchmark.
    /// </summary>
    internal sealed class ReportAdaptiveAdmission
    {
        sealed class Bundle { public bool Known; public ulong Current, Peak; public long At; }
        sealed class Window
        {
            public long Since, DurationTotal;
            public int Fresh, Failed;
            public double Mean { get { return Fresh == 0 ? 0 : (double)DurationTotal / Fresh; } }
            public double Rate(long now) { return Fresh * 60000.0 / Math.Max(1, now - Since); }
        }
        readonly object gate = new object();
        readonly Dictionary<int, Lease> active = new Dictionary<int, Lease>();
        readonly Dictionary<int, Bundle> bundles = new Dictionary<int, Bundle>();
        readonly Dictionary<int, ulong> nativeReservations = new Dictionary<int, ulong>();
        readonly bool mt4Only;
        readonly int initial, ceiling;
        int limit, generation, measuredFresh;
        ulong peak;
        long stableSince = -1;
        bool thirdTrial, thirdAccepted, thirdRejected;
        double baselineRate, baselineMean;
        Window window;
        string reason = "initial capacity";
        public ReportAdaptiveAdmission(int initial, int ceiling, bool mt4Only)
        {
            this.ceiling = Math.Max(1, Math.Min(ReportParallel.Max, ceiling));
            this.initial = Math.Max(1, Math.Min(initial, this.ceiling));
            limit = this.initial; this.mt4Only = mt4Only;
        }
        public int Limit { get { lock (gate) return limit; } }
        public int Ceiling { get { return ceiling; } }
        public int Active { get { lock (gate) return active.Count; } }
        public string Reason { get { lock (gate) return reason; } }
        public bool ThirdTrial { get { lock (gate) return thirdTrial; } }
        public bool ThirdRejected { get { lock (gate) return thirdRejected; } }

        public void ObserveBundle(int slot, bool known, ulong currentMb, ulong peakMb, long nowMs)
        {
            lock (gate)
            {
                Bundle value;
                if (!bundles.TryGetValue(slot, out value)) bundles[slot] = value = new Bundle();
                value.Known = known; value.Current = known ? currentMb : 0; value.At = nowMs;
                if (known) { value.Peak = Math.Max(value.Peak, peakMb); peak = Math.Max(peak, peakMb); }
            }
        }

        // Handoff prevents counting the same startup growth here and in ReportStartBudget.
        // The native reservation must include the estimated complete owned worker bundle.
        public void ObserveNativeReservation(int slot, ulong requiredMb)
        { lock (gate) { if (requiredMb == 0) nativeReservations.Remove(slot); else nativeReservations[slot] = requiredMb; } }
        public void NativeReserved(int slot) { lock (gate) nativeReservations[slot] = Required; }
        public void NativeReleased(int slot) { ObserveNativeReservation(slot, 0); }

        ulong Required { get { return LaunchMemoryPolicy.Required(mt4Only ? Kind.MT4 : Kind.MT5, peak); } }
        ulong Current(int slot, long now)
        {
            Bundle value;
            return bundles.TryGetValue(slot, out value) && value.Known && now >= value.At && now - value.At <= 1500 ? value.Current : 0;
        }
        ulong Growth(int slot, long now)
        {
            ulong reserved; nativeReservations.TryGetValue(slot, out reserved);
            // Global PendingGrowthMb already owns the native reservation's outstanding growth,
            // including a retained idle MT5 terminal. Reserve only the uncovered bundle growth.
            // This also covers helper growth above an older, smaller native reservation.
            ulong covered = Math.Max(Current(slot, now), reserved), required = Required;
            return covered >= required ? 0 : required - covered;
        }
        bool Room(int slot, ReportResourceSnapshot resources)
        {
            ulong pending = resources.PendingGrowthMb;
            foreach (Lease lease in active.Values) pending += Growth(lease.Slot, resources.MonotonicMs);
            ulong needed = LaunchMemoryPolicy.Reserve(resources.TotalMb) + pending + Growth(slot, resources.MonotonicMs) + 256;
            return resources.TotalMb > 0 && resources.FreeMb >= needed;
        }
        bool KnownActiveBundles()
        {
            foreach (int slot in active.Keys) { Bundle value; if (bundles.TryGetValue(slot, out value) && !value.Known) return false; }
            return true;
        }
        void SetLimit(int next, long now, string why)
        {
            next = Math.Max(1, Math.Min(ceiling, next));
            if (limit != next)
            {
                limit = next; generation++; stableSince = -1;
                window = next == 2 || next == 3 ? new Window { Since = now } : null;
            }
            reason = why;
        }
        void RejectThird(long now, string why)
        {
            thirdRejected = true; thirdTrial = thirdAccepted = false;
            SetLimit(2, now, why);
        }
        void EvaluateTrial(long now)
        {
            if ((!thirdTrial && !thirdAccepted) || window == null) return;
            long elapsed = Math.Max(0, now - window.Since);
            if (window.Failed > 0) { RejectThird(now, "third worker rolled back: unsuccessful report in observation window"); return; }
            if (window.Fresh >= 3 && window.Mean > baselineMean * 1.5)
            { RejectThird(now, "third worker rolled back: observed report latency increased"); return; }
            if (window.Fresh >= 6 && elapsed >= 20000)
            {
                double rate = window.Rate(now);
                if (thirdTrial)
                {
                    if (rate < baselineRate * 1.05 || window.Mean > baselineMean * 1.35)
                    { RejectThird(now, "third worker rolled back: trial did not show useful fresh-report throughput"); return; }
                    thirdTrial = false; thirdAccepted = true;
                    reason = "third worker retained: observed throughput improved without latency or failure regression";
                }
                else if (rate < baselineRate * 0.9 || window.Mean > baselineMean * 1.5)
                { RejectThird(now, "third worker rolled back: sustained fresh-report throughput regressed"); return; }
                window = new Window { Since = now };
            }
            else if (elapsed >= 60000)
                RejectThird(now, "third worker rolled back: bounded observation window lacked useful completed reports");
        }
        void ObserveResources(ReportResourceSnapshot resources)
        {
            EvaluateTrial(resources.MonotonicMs);
            if (resources.CpuPercent > 90)
            {
                if (thirdTrial || thirdAccepted) RejectThird(resources.MonotonicMs, "third worker rolled back: CPU pressure");
                else if (limit > initial) SetLimit(initial, resources.MonotonicMs, "adaptive capacity reduced: CPU pressure");
                stableSince = -1; reason = "new reports paused: CPU pressure";
            }
        }
        public bool TryEnter(int slot, ReportResourceSnapshot resources, out Lease lease)
        {
            lock (gate)
            {
                lease = null;
                if (slot < 1 || slot > ceiling || active.ContainsKey(slot)) return false;
                ObserveResources(resources);
                if (resources.CpuPercent > 90) return false;
                if (!Room(slot, resources))
                {
                    // A parked speculative slot must not demote useful existing concurrency merely
                    // because there is no RAM for an additional worker beyond the current limit.
                    if (slot <= limit && active.Count < limit)
                    {
                        if (thirdTrial || thirdAccepted) RejectThird(resources.MonotonicMs, "third worker rolled back: RAM pressure");
                        else if (limit > initial) SetLimit(initial, resources.MonotonicMs, "adaptive capacity reduced: RAM pressure");
                    }
                    stableSince = -1; reason = "new reports paused: reserved RAM headroom"; return false;
                }
                if (limit < ceiling && measuredFresh >= 2 && resources.CpuPercent >= 0 && resources.CpuPercent <= 75 && KnownActiveBundles())
                {
                    bool ready = limit == 1 || limit == 2 && mt4Only && !thirdRejected && window != null
                        && window.Fresh >= 6 && window.Failed == 0 && resources.MonotonicMs - window.Since >= 15000;
                    if (ready)
                    {
                        if (stableSince < 0) stableSince = resources.MonotonicMs;
                        if (resources.MonotonicMs - stableSince >= 2000)
                        {
                            if (limit == 2)
                            {
                                baselineRate = window.Rate(resources.MonotonicMs); baselineMean = window.Mean;
                                thirdTrial = true;
                                SetLimit(3, resources.MonotonicMs, "bounded third-worker trial after six fresh two-worker reports");
                            }
                            else SetLimit(2, resources.MonotonicMs, "second worker enabled after two measured fresh reports and stable resources");
                        }
                    }
                    else stableSince = -1;
                }
                else if (resources.CpuPercent < 0 || resources.CpuPercent > 75 || !KnownActiveBundles()) stableSince = -1;
                if (slot > limit || active.Count >= limit) return false;
                lease = new Lease(this, slot, generation, limit, resources.MonotonicMs); active.Add(slot, lease);
                foreach (Lease running in active.Values) running.ConcurrentObserved = Math.Max(running.ConcurrentObserved, active.Count);
                if (window == null && limit == 2) window = new Window { Since = resources.MonotonicMs };
                return true;
            }
        }
        void Release(Lease lease, bool completed, bool fresh, long durationMs, ulong peakBundleMb, ReportResourceSnapshot resources)
        {
            lock (gate)
            {
                Lease current;
                if (!active.TryGetValue(lease.Slot, out current) || !object.ReferenceEquals(current, lease)) return;
                active.Remove(lease.Slot);
                if (!completed) return;
                if (fresh && peakBundleMb > 0) { measuredFresh++; peak = Math.Max(peak, peakBundleMb); }
                if (lease.Generation == generation && window != null)
                {
                    if (fresh && (limit != 2 || lease.ConcurrentObserved >= 2)) { window.Fresh++; window.DurationTotal += Math.Max(1, durationMs); }
                    else if (!fresh) window.Failed++;
                }
                ObserveResources(resources);
            }
        }
        public sealed class Lease : IDisposable
        {
            readonly ReportAdaptiveAdmission owner;
            internal readonly int Slot, Generation;
            internal readonly int StartedLimit;
            internal readonly long StartedAt;
            internal int ConcurrentObserved;
            internal Lease(ReportAdaptiveAdmission owner, int slot, int generation, int limit, long now)
            { this.owner = owner; Slot = slot; Generation = generation; StartedLimit = limit; StartedAt = now; }
            public void Complete(bool fresh, long durationMs, ulong peakBundleMb, ReportResourceSnapshot resources)
            { owner.Release(this, true, fresh, durationMs, peakBundleMb, resources); }
            public void Dispose() { owner.Release(this, false, false, 0, 0, null); }
        }
    }
}
