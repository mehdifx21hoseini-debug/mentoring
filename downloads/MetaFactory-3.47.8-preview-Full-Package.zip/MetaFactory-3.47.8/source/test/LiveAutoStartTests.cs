using System;
using System.Linq;
namespace MTManager { static partial class Tests {
static void LiveAutoStartChecks() {
 DateTime proofNow=DateTime.UtcNow;proofNow=proofNow.AddTicks(-(proofNow.Ticks%TimeSpan.TicksPerSecond));
 var proofCopy=new Instance{Name="MT5-proof",Kind=Kind.MT5,Dir=Dir("mt5-symbol-proof")};
 var proofAccount=new Account{Login="123",Server="Broker-Demo"};var proofTarget=LiveMonitorTarget.Create(proofCopy,proofAccount);proofTarget.Token=FeedToken;
 System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(proofTarget.SnapshotPath));
 string proofPlan=System.IO.Path.Combine(proofCopy.Dir,"MQL5","Files","MetaFactoryLive","launch-plan.txt");
 System.IO.File.WriteAllText(proofPlan,"MLPLAN\t1\nPlatform=MT5\nSymbol=XAUUSD@\n");System.IO.File.SetLastWriteTimeUtc(proofPlan,proofNow.AddSeconds(-5));
 System.IO.File.WriteAllText(proofTarget.SnapshotPath,FeedFrame(proofNow),System.Text.Encoding.Unicode);
 Equal("XAUUSD@",LiveAutoStart.Mt5LiveSymbol(new[]{proofTarget},"Broker-Demo",proofNow),"fresh ready same-server observer startup symbol overrides stale historical symbol");
 Equal(null,LiveAutoStart.Mt5LiveSymbol(new[]{proofTarget},"Other-Real",proofNow),"live symbol is never shared across servers");
 Equal(null,LiveAutoStart.Mt5LiveSymbol(new[]{proofTarget},"Broker-Demo",proofNow.AddSeconds(11)),"stale observer cannot certify startup symbol");
 System.IO.File.WriteAllText(proofTarget.SnapshotPath,FeedFrame(proofNow,state:"bootstrap",revision:0),System.Text.Encoding.Unicode);
 Equal(null,LiveAutoStart.Mt5LiveSymbol(new[]{proofTarget},"Broker-Demo",proofNow),"unready observer cannot certify symbol");
 System.IO.File.WriteAllText(proofTarget.SnapshotPath,FeedFrame(proofNow).Replace(FeedToken,new string('f',32)),System.Text.Encoding.Unicode);
 Equal(null,LiveAutoStart.Mt5LiveSymbol(new[]{proofTarget},"Broker-Demo",proofNow),"wrong-session frame cannot certify symbol");
 System.IO.File.WriteAllText(proofTarget.SnapshotPath,FeedFrame(proofNow),System.Text.Encoding.Unicode);System.IO.File.SetLastWriteTimeUtc(proofPlan,proofNow.AddSeconds(1));
 Equal(null,LiveAutoStart.Mt5LiveSymbol(new[]{proofTarget},"Broker-Demo",proofNow),"newer launch plan cannot inherit previous ready snapshot proof");

 var symbolSettings=new Settings{BaseDir=Dir("mt5-known-fallback")};
 string symbolRoot=ReportLaunch.ReportRoot(symbolSettings.BaseDir);
 System.IO.Directory.CreateDirectory(System.IO.Path.Combine(symbolRoot,"worker","Bases","Same-Demo","history","XAUUSD@"));
 System.IO.Directory.CreateDirectory(System.IO.Path.Combine(symbolRoot,"worker","Bases","Other-Real","history","GBPUSD.bad"));
 var missingSymbols=new Instance{Kind=Kind.MT5,Dir=Dir("mt5-empty-symbols")};
 var sharedSymbols=LiveAutoStart.Mt5KnownSymbols(symbolSettings,missingSymbols,"Same-Demo");
 Check(sharedSymbols.Contains("XAUUSD@") && !sharedSymbols.Contains("GBPUSD.bad"),"empty MT5 copy reuses only same-server known symbols");
 Equal("XAUUSD@",LiveAutoStart.Mt5Symbol("GBPUSD",sharedSymbols),"stale symbol replaced with known same-server fallback");

 var restartCopy=new Instance{Name="MT5-restart",Kind=Kind.MT5,Dir=Dir("mt5-restart")};var restartAccounts=new AccountStore();
 var originalStart=Launcher.WriteStartFile(restartCopy,new Settings{Light=true},restartAccounts,true);
 string originalPath=originalStart.StartFile;
 var observerLines=LiveAutoStart.Lines(Kind.MT5,"MF_Live_demo","session.set","XAUUSD@");
 System.IO.File.Delete(originalPath);
 Launcher.RestoreMt5LiveStart(restartCopy,new Settings{Light=true},restartAccounts,originalPath,observerLines);
 string restored=System.IO.File.ReadAllText(originalPath);
 Check(restored.Contains("ProfileLast="+Launcher.LiveMt5ProfileName) && restored.Contains("Expert=MF_Live_demo") && restored.Contains("ExpertParameters=session.set") && restored.Contains("Symbol=XAUUSD@"),"self-update restores complete EA context to exact original MT5 config path");
 Check(restored.Contains("AllowLiveTrading=0"),"MT5 live restart leaves algorithmic trading disabled");
 Equal(1,System.IO.Directory.GetFiles(restartCopy.Dir,"mtm-live-start-*.ini").Length,"restore leaves no extra credential configuration behind");
 Throws<ArgumentException>(()=>Launcher.RestoreMt5LiveStart(restartCopy,new Settings(),restartAccounts,System.IO.Path.Combine(restartCopy.Dir,"mtm-start.ini"),observerLines),"restart cannot overwrite unrelated configuration");
 var keep=new PendingStart{Path=originalPath,Time=DateTime.Now,WaitForConfigRead=true,KeepForRestart=true};
 Equal(null,keep.Ready(keep.Time.AddSeconds(100)),"MT5 retains acknowledged configuration for updater grace period");
 Equal("time",keep.Ready(keep.Time.AddSeconds(PendingStart.ProtectedSeconds)),"MT5 updater retention remains bounded");
 Launcher.DeleteStartFile(originalPath);

 var presetCopy=new Instance{Name="MT5-presets",Kind=Kind.MT5,Dir=Dir("mt5-startup-presets")};
 var presetPaths=LiveAutoStart.StartupPresetPaths(presetCopy,"MetaFactoryLive-session.set");
 Equal(2,presetPaths.Length,"MT5 startup preset supplied to both native lookup locations");
 Check(presetPaths.Any(x=>x.EndsWith(System.IO.Path.Combine("MQL5","Presets","MetaFactoryLive-session.set"))) && presetPaths.Any(x=>x.EndsWith(System.IO.Path.Combine("Profiles","Presets","MetaFactoryLive-session.set"))),"MT5 preset filename exactly matches startup reference");
 Equal("EURUSD@",LiveAutoStart.Mt5Symbol("GBPUSD",new[]{"EURUSD@","XAUUSD@"}),"MT5 replaces stale chart symbol with broker-known suffix");
 Equal("GBPUSD@",LiveAutoStart.Mt5Symbol("GBPUSD@",new[]{"EURUSD@","GBPUSD@"}),"MT5 preserves existing broker-valid symbol");
 LiveAutoStart.EnsureMt5Profile(presetCopy);
 string mt5Profile=System.IO.Path.Combine(presetCopy.Dir,"MQL5","Profiles","Charts",Launcher.LiveMt5ProfileName);
 System.IO.File.WriteAllText(System.IO.Path.Combine(mt5Profile,"chart01.chr"),"prior MT5 observer");LiveAutoStart.EnsureMt5Profile(presetCopy);
 Equal(0,System.IO.Directory.GetFiles(mt5Profile).Length,"MT5 private profile starts empty for one startup EA chart");
 Check(System.IO.Directory.GetFiles(System.IO.Path.Combine(presetCopy.Dir,"MTManager-backup","mt5-live-profile"),"chart01.chr",System.IO.SearchOption.AllDirectories).Any(x=>System.IO.File.ReadAllText(x)=="prior MT5 observer"),"MT5 previous private chart backed up intact");
 var mt5Start=Launcher.WriteStartFile(presetCopy,new Settings{Light=true},new AccountStore(),true);
 string mt5Config=System.IO.File.ReadAllText(mt5Start.StartFile);
 Check(mt5Start.WaitForConfigRead && mt5Config.Contains("ProfileLast="+Launcher.LiveMt5ProfileName),"MT5 live launch selects private profile and retains startup until acknowledgement");
 Check(PendingStart.ConfigAcknowledged("Startup successfully initialized from start config "+System.IO.Path.GetFileName(mt5Start.StartFile),mt5Start.StartFile),"MT5 positive native startup acknowledgement accepted");
 Check(!PendingStart.ConfigAcknowledged("cannot load config "+System.IO.Path.GetFileName(mt5Start.StartFile),mt5Start.StartFile),"MT5 failure is not an acknowledgement");
 Launcher.DeleteStartFile(mt5Start.StartFile);

 string mt4Recovery=LiveReporter.SourceText(Kind.MT4);
 Check(mt4Recovery.Contains("timer-fallback-awaiting-tick") && mt4Recovery.Contains("void OnTick()"),"MT4 observer retains attachment and uses tick fallback after timer failure");
 Check(!mt4Recovery.Contains("InitProblem(\"timer-create\",GetLastError());return INIT_FAILED;"),"MT4 timer failure no longer detaches observer");
 Check(mt4Recovery.Contains("now-timerRetryAt>=5000") && mt4Recovery.Contains("now-fallbackPollAt<1000"),"MT4 recovery and fallback work stay bounded");
 Check(!LiveReporter.SourceText(Kind.MT5).Contains("timer-fallback-awaiting-tick"),"MT5 lifecycle unchanged by MT4 recovery");

 var emptyCopy=new Instance{Name="MT4-single-live",Kind=Kind.MT4,Dir=Dir("mt4-single-live")};
 string profileRoot=System.IO.Path.Combine(emptyCopy.Dir,"profiles");System.IO.Directory.CreateDirectory(profileRoot);
 string userDir=System.IO.Path.Combine(profileRoot,"UserProfile");System.IO.Directory.CreateDirectory(userDir);
 string userChart=System.IO.Path.Combine(userDir,"chart01.chr");System.IO.File.WriteAllText(userChart,"<expert>MyOtherEA</expert>");
 string lastProfile=System.IO.Path.Combine(profileRoot,"lastprofile.ini");System.IO.File.WriteAllText(lastProfile,"UserProfile");
 LiveAutoStart.EnsureMt4Chart(emptyCopy,"EURUSD.m","5");
 string singleDir=System.IO.Path.Combine(profileRoot,LiveAutoStart.Mt4ProfileName);
 Equal(LiveAutoStart.Mt4ProfileName,System.IO.File.ReadAllText(lastProfile),"MT4 selects private startup-only profile");
 Equal(0,System.IO.Directory.GetFiles(singleDir,"*.chr").Length,"no preloaded chart duplicates startup Expert chart");
 Equal("<expert>MyOtherEA</expert>",System.IO.File.ReadAllText(userChart),"user EA chart preserved in original profile");
 string saved=System.IO.Path.Combine(singleDir,"chart01.chr");System.IO.File.WriteAllText(saved,"saved observer bytes");
 System.IO.File.WriteAllText(System.IO.Path.Combine(singleDir,"chart02.chr"),"extra saved chart bytes");
 LiveAutoStart.EnsureMt4Chart(emptyCopy,"EURUSD.m","5");
 Equal(0,System.IO.Directory.GetFileSystemEntries(singleDir).Length,"relaunch resets only private profile instead of restoring extra charts");
 string backup=System.IO.Path.Combine(emptyCopy.Dir,"MTManager-backup","single-live-profile");
 string[] backups=System.IO.Directory.GetDirectories(backup);
 Equal(1,backups.Length,"previous private profile backed up once");
 Equal("saved observer bytes",System.IO.File.ReadAllText(System.IO.Path.Combine(backups[0],"chart01.chr")),"saved observer profile backup preserves exact bytes");
 Equal("extra saved chart bytes",System.IO.File.ReadAllText(System.IO.Path.Combine(backups[0],"chart02.chr")),"extra private chart is backed up, not deleted");
 LiveAutoStart.EnsureMt4Chart(emptyCopy,"EURUSD.m","5");
 Equal(1,System.IO.Directory.GetDirectories(backup).Length,"empty private profile creates no redundant chart backups");
 var startResult=Launcher.WriteStartFile(emptyCopy,new Settings{Light=true,StartCharts=ChartModes.Empty},new AccountStore(),true);
 Equal(LiveAutoStart.Mt4ProfileName,System.IO.File.ReadAllText(lastProfile),"live launch keeps private profile despite empty/light settings");
 Launcher.DeleteStartFile(startResult.StartFile);
 Check(System.IO.File.ReadAllBytes(lastProfile)[0]==(byte)'M',"MT4 profile selector remains ASCII without BOM");
 Throws<ArgumentException>(()=>LiveAutoStart.EnsureMt4Chart(emptyCopy,"EURUSD\nperiod=60","1"),"single-chart startup rejects injected symbol");
 var mt5NoTouch=new Instance{Kind=Kind.MT5,Dir=Dir("mt5-single-unchanged")};LiveAutoStart.EnsureMt4Chart(mt5NoTouch,"EURUSD","1");
 Check(!System.IO.Directory.Exists(System.IO.Path.Combine(mt5NoTouch.Dir,"profiles")),"MT5 profile preparation unchanged");
 Equal(null,PendingStart.ProtectedReady(11,false),"MT4 retains startup beyond old ten-second deadline");
 Equal(null,PendingStart.ProtectedReady(120,false),"MT4 allows slow bootstrap without configuration acknowledgement");
 Equal(null,PendingStart.ProtectedReady(180,false),"slow MT4 startup retains settings past three minutes");
 Equal("time",PendingStart.ProtectedReady(PendingStart.ProtectedSeconds,false),"MT4 credential retention has bounded deadline");
 Equal("journal",PendingStart.ProtectedReady(2,true),"MT4 removes startup immediately after acknowledgement");
 Check(PendingStart.ConfigAcknowledged("Started with configuration file 'mtm-live-start-abc.ini'","/tmp/mtm-live-start-abc.ini"),"exact startup configuration acknowledgement accepted");
 Check(!PendingStart.ConfigAcknowledged("cannot load configuration file mtm-live-start-abc.ini","/tmp/mtm-live-start-abc.ini"),"configuration failure does not delete startup early");
 Check(!PendingStart.ConfigAcknowledged("Started with configuration file mtm-live-start-old.ini","/tmp/mtm-live-start-abc.ini"),"previous run acknowledgement cannot delete new startup");
 var protectedPending=new PendingStart {Time=DateTime.Now,WaitForConfigRead=true};
 Equal(null,protectedPending.Ready(protectedPending.Time.AddSeconds(90)),"missing parent process does not delete protected configuration");

 var bootstrapAccount=new Account {Login="12345",Server="Synthetic-Demo"};
 string token=new string('a',32), binding=LiveAutoStart.BootstrapText(bootstrapAccount,token);
 Check(binding=="MLBOOT\t1\r\n"+token+"\r\n12345\r\nSynthetic-Demo\r\n","fallback binding has exact bounded account-specific UTF16 text schema");
 var bootstrapCopy=new Instance {Name="MT4-bootstrap",Kind=Kind.MT4,Dir=Dir("live-bootstrap")};
 LiveAutoStart.WriteBootstrap(bootstrapCopy,bootstrapAccount,token);
 string bootstrapPath=System.IO.Path.Combine(bootstrapCopy.Dir,"MQL4","Files","MetaFactoryLive","bootstrap.txt");
 Equal(binding,System.IO.File.ReadAllText(bootstrapPath,System.Text.Encoding.Unicode),"atomic bootstrap is readable in native FILE_UNICODE form");
 bootstrapAccount.Login="67890";LiveAutoStart.WriteBootstrap(bootstrapCopy,bootstrapAccount,new string('b',32));
 Check(System.IO.File.ReadAllText(bootstrapPath).Contains("67890")&&!System.IO.File.ReadAllText(bootstrapPath).Contains(token),"closed-copy binding update replaces previous account atomically");
 Throws<UserMessage>(()=>LiveAutoStart.BootstrapText(new Account{Login="123",Server="Demo\nOther=bad"},token),"bootstrap server cannot inject extra binding lines");
 foreach(Kind nativeKind in new[]{Kind.MT4,Kind.MT5}) {
  string source=LiveReporter.SourceText(nativeKind);
  Check(source.Contains("bool ResolveSession()") && source.Contains("MLBOOT\\t1") && source.Contains("WorkToken==\"\" && WorkLogin==\"\" && WorkServer==\"\""),"native fallback only applies to wholly absent explicit inputs for "+nativeKind);
  Check(source.Contains("GlobalVariableSetOnCondition(ownerKey,ownerId,previous)") && source.Contains("observer-renewed-during-claim") && source.Contains("if(!RefreshLease()){FileDelete(tmp);return false;}"),"native atomic lease handles renewal races and rechecks ownership before publishing for "+nativeKind);
  Check(source.Contains("retryInitAt>=5000") && source.Contains("BeginLiveSession();retryInitAt=GetTickCount();") && source.Contains("return INIT_SUCCEEDED;"),"recoverable native session failure keeps terminal initialized and retries for "+nativeKind);
 }

 Equal("5",LiveAutoStart.FreePeriod(new[]{"symbol=EURUSD\nperiod=1\n<expert>OtherEA</expert>"},"EURUSD",new string('a',32)),"automatic observer chooses separate timeframe from existing EA chart");
 Equal("1",LiveAutoStart.FreePeriod(new[]{"symbol=EURUSD\nperiod=1\nMTManagerLive\n"+new string('a',32)},"EURUSD",new string('a',32)),"same account live chart can be reused");
 foreach (Kind kind in new[] { Kind.MT4, Kind.MT5 }) {
  var lines = LiveAutoStart.Lines(kind, @"MetaFactoryLive\version\MTManagerLive", "session.set", "EURUSD.m");
  Check(lines.Contains(@"Expert=MetaFactoryLive\version\MTManagerLive") && lines.Contains("ExpertParameters=session.set"), "automatic live startup binds independent EA and preset for " + kind);
  Check(lines.Contains("Symbol=EURUSD.m"), "automatic startup keeps broker symbol suffix for " + kind);
  Check(!lines.Any(x => x.StartsWith("Script=") || (kind==Kind.MT4 && x.StartsWith("AllowLiveTrading=")) || x.StartsWith("ExpertsTrades=")), "live auto startup does not change trading permissions for " + kind);
  Check(kind != Kind.MT4 || lines.Contains("ExpertsDllImport=true"),"MT4 live startup enables history DLL access");
  Check(kind != Kind.MT5 || !lines.Any(x=>x.StartsWith("ExpertsDllImport=")),"MT5 DLL policy unchanged");
  Check(kind != Kind.MT4 || lines.Contains("ShutdownTerminal=false"),"MT4 auto-run explicitly disables startup terminal shutdown");
  Check(kind != Kind.MT5 || lines.First()=="[Experts]" && lines.Contains("AllowLiveTrading=0") && lines.Contains("[StartUp]") && lines.Contains("ShutdownTerminal=0"), "MT5 live startup stays open");
 }
 Throws<ArgumentException>(() => LiveAutoStart.Lines(Kind.MT4,"EA\nExpert=bad","s.set","EURUSD"), "automatic EA setting rejects newline injection");
 Check(LiveAutoStart.Prepare(new Instance(),new Settings(),null).Count==0,"copies without stored account do not attempt live compilation");
}
}}
