using System;
using System.Collections.Generic;
using System.Linq;
namespace MTManager
{
    sealed partial class MainForm
    {
        readonly LiveMonitorController dashboardController=new LiveMonitorController(dashboard:true);
        readonly Dictionary<string,LiveMonitorView> dashboardRows=new Dictionary<string,LiveMonitorView>(StringComparer.OrdinalIgnoreCase);
        readonly Dictionary<string,LiveDashboardData> dashboardLast=new Dictionary<string,LiveDashboardData>(StringComparer.OrdinalIgnoreCase);
        readonly Dictionary<string,Tuple<string,PanelView>> dashboardPanels=new Dictionary<string,Tuple<string,PanelView>>(StringComparer.OrdinalIgnoreCase);
        string dashboardKey="";
        bool DashboardTick()
        {
            if(appClosing)return false;
            if(!dashboardController.Enabled)dashboardController.Enable(true);
            var views=dashboardController.Snapshot();
            string key=string.Join("|",views.Select(v=>v.CopyName+":"+v.Signature+":"+(v.Feed==null?"":v.Feed.Version)));
            bool changed=key!=dashboardKey;dashboardKey=key;dashboardRows.Clear();
            foreach(var view in views)
            {
                dashboardRows[view.CopyName]=view;
                var observed=copies.FirstOrDefault(c=>c.Name.Equals(view.CopyName,StringComparison.OrdinalIgnoreCase));var account=observed==null?null:accounts.Get(observed.Name);
                if(observed!=null && account!=null && view.Dashboard!=null && view.Feed!=null && view.Dashboard.Matches(observed,account,DateTime.UtcNow))LaunchComparison.Fresh(observed,account,view.Feed.HeartbeatUtc);
                if(view.Dashboard!=null)dashboardLast[view.CopyName]=view.Dashboard;
            }
            foreach(string name in dashboardLast.Keys.Where(n=>!copies.Any(c=>c.Name.Equals(n,StringComparison.OrdinalIgnoreCase))).ToList())dashboardLast.Remove(name);
            string problem;var targets=LiveMonitorStore.Load(out problem);
            dashboardController.Poll(targets,LiveCandidates(copies));
            return changed;
        }
        Student DashboardStudent(Instance copy,Account account,Student manual)
        {
            if(LaunchComparison.IsPlain(copy.Name)){var ordinary=manual.Snapshot();ordinary.LiveCurrent=false;ordinary.LivePending=false;ordinary.LiveData=null;ordinary.LiveFeed=null;ordinary.LiveNotice=Lang.T("اجرای عادی؛ گزارش زنده خاموش است","Ordinary launch; live reporting is off");return ordinary;}
            LiveMonitorView view;dashboardRows.TryGetValue(copy.Name,out view);
            if(view!=null && (view.Target==null || !view.Target.Matches(copy,account)))view=null;
            LiveDashboardData data=view==null?null:view.Dashboard;
            bool current=data!=null && data.Matches(copy,account,DateTime.UtcNow);
            if(!current) {dashboardLast.TryGetValue(copy.Name,out data);if(data!=null && !data.Target.Matches(copy,account))data=null;}
            if(data!=null && manual.Journal!=null && manual.Journal.Platform==copy.Kind.ToString() && manual.Journal.Login==account.Login.Trim()
                && string.Equals(manual.Journal.Server,account.Server,StringComparison.OrdinalIgnoreCase) && manual.Journal.Exported>data.Journal.Exported)
            {data=null;current=false;}
            if(view==null && data==null)return null;
            var result=manual.Snapshot();
            result.LiveCurrent=current;result.LiveData=data;
            result.LiveFeed=view==null?null:view.Feed;
            result.LivePending=!current && result.LiveFeed!=null && result.LiveFeed.IsLive && DateTime.UtcNow<=result.LiveFeed.HeartbeatUtc.AddSeconds(LiveFeedReader.StaleSeconds);
            result.LiveNotice=current?Lang.T("گزارش زندهٔ تأییدشده", "Verified live report")
                :view==null?Lang.T("دریافت زنده متوقف است؛ آخرین گزارش تأییدشده نمایش داده می‌شود.","Live reception stopped; showing the last verified report.")
                :view.State+" · "+view.History+Lang.T("؛ نمایش آخرین گزارش تأییدشده", "; showing the last verified report");
            if(data!=null)
            {
                result.Journal=data.Journal;result.Today=data.Today;result.TodayFor=ServerToday(data.Journal);
                result.FileTime=data.ReceivedUtc.ToLocalTime();result.Key=account.Login.Trim()+"@"+account.Server.Trim();result.Loaded=true;
                result.Activity=ActivityRule.Of(data.Journal,result.TodayFor);
                if(current)result.Error=null;
            }
            return result;
        }
        PanelView StudentPanel(Student student,ReportRange range)
        {
            if(student.LiveData==null)return student.Journal==null?null:PanelMath.Build(student.Journal,range,Limits);
            var data=student.LiveData;
            if(data.Today.Range.From==range.From && data.Today.Range.To==range.To)return data.Today;
            string key=data.Target.CopyName+"|"+range.From.Ticks+"|"+range.To.Ticks;
            Tuple<string,PanelView> cached;
            if(!dashboardPanels.TryGetValue(key,out cached) || cached.Item1!=data.HistoryKey)
            {
                cached=Tuple.Create(data.HistoryKey,LiveDashboardMath.Build(data.Journal,range));
                if(dashboardPanels.Count>200)dashboardPanels.Clear();
                dashboardPanels[key]=cached;
            }
            return cached.Item2==null?null:cached.Item2.WithCurrent(data.Journal);
        }
    }
}
