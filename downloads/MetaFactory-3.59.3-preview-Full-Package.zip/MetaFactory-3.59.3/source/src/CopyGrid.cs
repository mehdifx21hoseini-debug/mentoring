using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MTManager
{
    /// <summary>3.21: Active and Inactive are the student's trading (a trade within 14 trading days or not), shown while closed.</summary>
    public enum RowState { Off, On, Open, Pending, Warn, Bad, Active, Inactive }

    /// <summary>What one row of the list shows: the copy, its account and whether its MetaTrader is open and logged in.</summary>
    sealed class CopyRow
    {
        public string Name = "", Kind = "", Trader = "", Login = "", Server = "", Status = "";
        public RowState State;
        public bool HasAccount, Running, MasterLogin;
        public int ReviewOpen;
        public bool AnyRunning { get { return Running||ReviewOpen>0; } }
        public double? TodayNet;
        public string AccountBalance="Balance —",AccountDrawdown="Overall DD —",AccountInfoTip="";
        public DateTime LastTradeUtc=DateTime.MinValue;public bool TradeOpen,PreviousReport,TodayLive;public int? TodayClosedCount,TodayOpenCount;
        public bool TodayHasTrades;
        /// <summary>3.21: whether the student still trades (for the tabs and the counts; also while MetaTrader is open).</summary>
        public Activity Activity;
        /// <summary>Ticked in the list's first column: the group that "run" and "close" act on.</summary>
        public bool Checked;
        /// <summary>The names of the folders the copy is in (it can be in several).</summary>
        public string[] Folders = new string[0];
        /// <summary>3.21, the «امروز» column: the day in a few words ("3 trades · +$38.20 · 1 No SL"), with the money's sign
        /// (TodayTone), whether a trade had no Stop Loss, and under it when it was read; or that it is being read, was not read,
        /// or could not be.</summary>
        public string TodayText = "", TodayAgo = "";
        /// <summary>3.26 (CHANGE-003): the whole message behind a shortened «امروز» text, for its tip; empty when there is none.</summary>
        public string TodayTip = "";
        public int TodayTone;
        public bool TodayNoSl, TodayBusy, TodayFailed, TodayNone;
        /// <summary>The report is open under this row.</summary>
        public bool Expanded;
        public bool HasNote; public string NoteRevision="";

        public string Key
        {
            get
            {
                return string.Join("\u0001", new[] { Name, Kind, Trader, Login, Server, Status, MasterLogin ? "M" : "", TodayNet.HasValue ? TodayNet.Value.ToString(CultureInfo.InvariantCulture) : "", ReviewOpen.ToString(), State.ToString(), HasAccount ? "1" : "0", Running ? "1" : "0", Checked ? "1" : "0",
                                                     string.Join("\u0002", Folders), TodayText, TodayTip, TodayAgo, TodayTone.ToString(), TodayHasTrades ? "1" : "0", TodayNoSl ? "1" : "0", TodayBusy ? "1" : "0",
                                                     TodayFailed ? "1" : "0", TodayNone ? "1" : "0", Expanded ? "1" : "0", HasNote?"1":"0", NoteRevision,AccountBalance,AccountDrawdown,AccountInfoTip,LastTradeUtc.Ticks.ToString(CultureInfo.InvariantCulture),TradeOpen?"1":"0",PreviousReport?"1":"0",TodayLive?"1":"0",TodayClosedCount.HasValue?TodayClosedCount.Value.ToString(CultureInfo.InvariantCulture):"?",TodayOpenCount.HasValue?TodayOpenCount.Value.ToString(CultureInfo.InvariantCulture):"?" });
            }
        }
    }

    enum RowPart { None, Open, More, Check, Name, Note }

    /// <summary>The ticked copies of the list, by name. They stay ticked while the view or the search changes.</summary>
    sealed class Ticked
    {
        readonly HashSet<string> names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        public int Count { get { return names.Count; } }

        public bool Has(string name) { return names.Contains(name); }

        public void Toggle(string name) { if (!names.Remove(name)) names.Add(name); }

        public void Clear() { names.Clear(); }

        /// <summary>The header's box: when all the rows shown are ticked it unticks them, otherwise it ticks them all.</summary>
        public void ToggleAll(IEnumerable<string> shown)
        {
            List<string> list = shown.ToList();
            if (list.Count > 0 && list.All(names.Contains)) foreach (string n in list) names.Remove(n);
            else foreach (string n in list) names.Add(n);
        }

        /// <summary>Copies that are gone (removed) leave the choice.</summary>
        public void Keep(IEnumerable<string> existing)
        {
            var all = new HashSet<string>(existing, StringComparer.OrdinalIgnoreCase);
            names.RemoveWhere(n => !all.Contains(n));
        }

        /// <summary>The header's box for the rows shown: 0 none ticked, 1 some, 2 all.</summary>
        public int State(IEnumerable<string> shown)
        {
            List<string> list = shown.ToList();
            int n = list.Count(names.Contains);
            return n == 0 ? 0 : n == list.Count ? 2 : 1;
        }
    }

    /// <summary>The list of copies, painted like a Windows 11 list: roomy rows, thin dividers, no grid lines,
    /// and on each row a "باز کردن متاتریدر" button and a "⋯" button for everything else.</summary>
    sealed class CopyGrid : DataGridView
    {
        // 3.27.2: a property, so the headers follow a language change made while the program runs.
        static string[][] Spec { get { return new[]
        {
            // 3.26 (CHANGE-001): «نسخه» gives room to the name, the server and the folders; «عمل‌ها» (CHANGE-002) is narrower and fixed.
            new[] { "Check", "", "4" }, new[] { "Ordinal", "#", "36" }, new[] { "Trader", Lang.T("دانشجو", "Student"), "180" }, new[] { "Copy", Lang.T("نسخه", "Copy"), "78" }, new[] { "Login", Lang.T("شماره حساب", "Account"), "102" },
            new[] { "Server", Lang.T("سرور", "Server"), "118" }, new[] { "Folders", Lang.T("پوشه‌ها", "Folders"), "130" }, new[] { "Today", Lang.T("امروز", "Today"), "200" }, new[] { "Freshness", Lang.T("اطلاعات حساب","Account information"), "200" }, new[] { "Status", Lang.T("وضعیت", "Status"), "120" }, new[] { "Action", "", "130" },
        }; } }

        public static readonly Color SelBack = Color.FromArgb(0xF2, 0xF7, 0xFD), HoverBack = Color.FromArgb(0xF8, 0xF8, 0xF8), Divider = Color.FromArgb(0xE1, 0xE5, 0xEB),
            HeadBack = Color.FromArgb(0x29, 0x2D, 0x33), HeadLine = Color.FromArgb(0x45, 0x4A, 0x52),
            HeadText = Color.FromArgb(0xF2, 0xF4, 0xF7), HeadActive = Color.FromArgb(0x9B, 0xC7, 0xFF),
            OkDot = Color.FromArgb(0x13, 0xA1, 0x0E), WarnDot = Color.FromArgb(0xC2, 0x7C, 0x0E);
        static Color OffDot { get { return Theme.Mix(Theme.Faint, Theme.Surface, 0.2f); } }

        public event Action<CopyRow> OpenClicked;
        /// <summary>3.24.2: the student's name was clicked (only the name, not the rest of the row) or Enter pressed: the student's page opens.</summary>
        public event Action<CopyRow> RowClicked;
        public event Action<CopyRow> NoteClicked;

        /// <summary>3.21: the report under a row (one at a time): the panel, the copy it is under and how tall it is.</summary>
        public ReportPanel Detail;
        public string ExpandedName;
        public int DetailHeight;
        public int BaseHeight { get { return RowTemplate.Height; } }
        /// <summary>A row's box was clicked (or Space pressed on the row).</summary>
        public event Action<CopyRow> CheckClicked;
        /// <summary>The box in the column title was clicked.</summary>
        public event Action CheckAllClicked;

        public string HeaderSortColumn = "";
        public int HeaderSortDirection;
        public event Action<string> HeaderSortClicked;
        public void CycleHeaderSort(string column)
        {
            if (column=="Freshness"||!DashboardSort.Columns.Contains(column)) return;
            if (column == "Today")
            {
                bool turnOn = HeaderSortColumn != "TradeCount" || HeaderSortDirection == 0;
                HeaderSortColumn = turnOn ? "TradeCount" : ""; HeaderSortDirection = turnOn ? -1 : 0;
            }
            else if (HeaderSortColumn != column) { HeaderSortColumn = column; HeaderSortDirection = 1; }
            else if (HeaderSortDirection == 1) HeaderSortDirection = -1;
            else { HeaderSortColumn = ""; HeaderSortDirection = 0; }
            Invalidate(); var clicked = HeaderSortClicked; if (clicked != null) clicked(column);
        }
        int headerCheck;
        /// <summary>The box in the column title: 0 none of the rows shown is ticked, 1 some, 2 all.</summary>
        public int HeaderCheck
        {
            get { return headerCheck; }
            set { if (headerCheck != value) { headerCheck = value; InvalidateCell(Columns["Check"].Index, -1); } }
        }
        /// <summary>The row's menu, at a point on the screen.</summary>
        public event Action<CopyRow, Point> MenuWanted;

        /// <summary>Shown in the empty list (when the search finds nothing).</summary>
        public string EmptyText;

        int hoverRow = -1;
        RowPart hoverPart;

        public CopyGrid()
        {
            DoubleBuffered = true;
            BorderStyle = BorderStyle.None;
            CellBorderStyle = DataGridViewCellBorderStyle.None;
            ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            RowHeadersVisible = false;
            AllowUserToAddRows = false;
            AllowUserToDeleteRows = false;
            AllowUserToResizeRows = false;
            AllowUserToResizeColumns = false;
            AllowUserToOrderColumns = false;
            ReadOnly = true;
            SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            // One row is marked at a time; several are chosen with the boxes of the first column.
            MultiSelect = false;
            StandardTab = true;
            ShowCellToolTips = false;
            BackgroundColor = Theme.Surface;
            GridColor = Divider;
            EnableHeadersVisualStyles = false;
            ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            ColumnHeadersHeight = Theme.S(36);
            RowTemplate.Height = Theme.S(42);
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            // The columns always fit the width: never a sideways scroll bar.
            ScrollBars = ScrollBars.Vertical;
            Font = Theme.Font;
            DefaultCellStyle.BackColor = Theme.Surface;
            DefaultCellStyle.ForeColor = Theme.Text;
            DefaultCellStyle.SelectionBackColor = SelBack;
            DefaultCellStyle.SelectionForeColor = Theme.Text;
            ColumnHeadersDefaultCellStyle.BackColor = HeadBack;
            ColumnHeadersDefaultCellStyle.ForeColor = HeadText;
            // The grid itself runs left to right with its columns in reverse order, so the first one is on the right.
            // (In right-to-left mode, Windows leaves one-pixel gaps between cells that nothing paints: dark lines.)
            RightToLeft = RightToLeft.No;
            // 3.27: in English the first column is at the left.
            IEnumerable<string[]> order = Lang.En ? Spec : Spec.Reverse();
            foreach (string[] c in order)
            {
                var col = new DataGridViewTextBoxColumn
                {
                    Name = c[0], HeaderText = c[1], FillWeight = float.Parse(c[2], CultureInfo.InvariantCulture),
                    SortMode = DataGridViewColumnSortMode.NotSortable, MinimumWidth = Theme.S(60),
                };
                Columns.Add(col);
            }
            Columns["Login"].MinimumWidth = Theme.S(112);
            Columns["Copy"].MinimumWidth = Theme.S(84);
            DataGridViewColumn check = Columns["Check"];
            check.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            check.MinimumWidth = Theme.S(44);
            check.Width = Theme.S(44);
            check.Resizable = DataGridViewTriState.False;
            DataGridViewColumn action = Columns["Action"];
            action.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            action.MinimumWidth = Theme.S(132);
            action.Width = Theme.S(132);
            action.Resizable = DataGridViewTriState.False;
            Columns["Trader"].MinimumWidth = Theme.S(130);
            Columns["Status"].MinimumWidth = Theme.S(150);  // 3.22.4: room for «رمز یا حساب اشتباه» and the like
            Columns["Today"].MinimumWidth = Theme.S(200);
            Columns["Server"].MinimumWidth = Theme.S(110);
            Columns["Copy"].MinimumWidth = Theme.S(70);
            Columns["Login"].MinimumWidth = Theme.S(90);
            Columns["Folders"].MinimumWidth = Theme.S(110);
            Columns["Folders"].Visible=false;
            Columns["Ordinal"].AutoSizeMode=DataGridViewAutoSizeColumnMode.None;
            Columns["Ordinal"].MinimumWidth=Theme.S(36);Columns["Ordinal"].Width=Theme.S(36);
            Columns["Ordinal"].Resizable=DataGridViewTriState.False;
            Columns["Ordinal"].HeaderCell.ToolTipText=Lang.T("شمارهٔ ردیف در فهرست فعلی","Row number in the current view");
            Columns["Check"].Width=Columns["Check"].MinimumWidth=Theme.S(30);
            Columns["Action"].Width=Columns["Action"].MinimumWidth=Theme.S(120);
            RefineColumns();
            tip = new ToolTip { InitialDelay = 400, ReshowDelay = 100, AutoPopDelay = 15000, ShowAlways = true };
        }

        readonly ToolTip tip;
        string tipText = "";


        protected override void Dispose(bool disposing)
        {
            if (disposing) tip.Dispose();
            base.Dispose(disposing);
        }

        public CopyRow RowAt(int index) { return index >= 0 && index < Rows.Count ? Rows[index].Tag as CopyRow : null; }

        /// <summary>Puts a row's data in place; the cells also get the text, for copying (Ctrl+C) and screen readers.</summary>
        public void SetRow(int index, CopyRow r)
        {
            DataGridViewRow row = Rows[index];
            row.Cells["Ordinal"].Value=Fa.N(index+1);
            var old = row.Tag as CopyRow;
            if (old != null && old.Key == r.Key) return;
            row.Tag = r;
            row.Cells["Check"].Value = r.Checked ? Lang.T("انتخاب‌شده", "Selected") : "";
            row.Cells["Trader"].Value = r.Trader;
            row.Cells["Copy"].Value = r.Kind + " " + r.Name;
            row.Cells["Login"].Value = r.Login;
            row.Cells["Server"].Value = r.Server;
            row.Cells["Status"].Value = r.Status;row.Cells["Status"].ToolTipText=r.Status;
            row.Cells["Action"].ToolTipText=Lang.T("باز کردن/نمایش نسخهٔ زنده؛ نمایش بررسی از مدیریت صفحهٔ دانشجو است.","Open/show the live copy; chart review is in the student page Manage menu.");
            row.Cells["Folders"].Value = string.Join(Lang.T("، ", ", "), r.Folders);
            row.Cells["Today"].Value = r.TodayText+(string.IsNullOrEmpty(r.TodayAgo)?"":"\n"+r.TodayAgo);
            row.Cells["Freshness"].Value=r.HasAccount?r.AccountBalance+"\n"+r.AccountDrawdown:"";row.Cells["Freshness"].ToolTipText=r.AccountInfoTip;
            row.Cells["Action"].Value = r.Running ? Lang.T("نمایش متاتریدر", "Show MetaTrader") : Lang.T("باز کردن متاتریدر", "Open MetaTrader");
            int want = r.Expanded && Detail != null ? BaseHeight + DetailHeight : BaseHeight;
            if (row.Height != want) row.Height = want;
            InvalidateRow(index);
            PlaceDetail();
        }

        /// <summary>The panel sits in the lower part of its row, and goes with it as the list scrolls; hidden when its row is not shown.</summary>
        public void PlaceDetail()
        {
            if (Detail == null) return;
            int k = -1;
            if (ExpandedName != null)
                for (int n = 0; n < Rows.Count; n++)
                {
                    CopyRow r = RowAt(n);
                    if (r != null && r.Expanded && string.Equals(r.Name, ExpandedName, StringComparison.OrdinalIgnoreCase)) { k = n; break; }
                }
            Rectangle rect = k >= 0 ? GetRowDisplayRectangle(k, false) : Rectangle.Empty;
            if (k < 0 || rect.Height <= 0 || Rows[k].Height <= BaseHeight)
            {
                if (Detail.Visible) Detail.Visible = false;
                return;
            }
            var b = new Rectangle(0, rect.Y + BaseHeight, DisplayRectangle.Width, DetailHeight);
            if (Detail.Bounds != b) Detail.Bounds = b;
            if (!Detail.Visible) Detail.Visible = true;
        }

        protected override void OnScroll(ScrollEventArgs e) { base.OnScroll(e); PlaceDetail(); }
        protected override void OnSizeChanged(EventArgs e) { base.OnSizeChanged(e); RefineColumns(); PlaceDetail(); }
        void RefineColumns()
        {
            if(!Columns.Contains("Freshness"))return;bool compact=ClientSize.Width<Theme.S(1120),narrow=ClientSize.Width<Theme.S(940);
            Columns["Freshness"].Visible=true;Columns["Freshness"].MinimumWidth=Theme.S(narrow?156:compact?164:180);
            Columns["Today"].MinimumWidth=Theme.S(narrow?154:compact?168:190);
            Columns["Trader"].MinimumWidth=Theme.S(narrow?100:compact?112:150);
            Columns["Login"].MinimumWidth=Theme.S(narrow?74:compact?78:84);
            Columns["Server"].MinimumWidth=Theme.S(narrow?88:compact?96:116);
            Columns["Status"].MinimumWidth=Theme.S(narrow?76:compact?84:100);
            Columns["Copy"].MinimumWidth=Math.Max(Theme.S(narrow?66:compact?70:74),Theme.Measure("MT5-100",Theme.CopyFont).Width+Theme.S(30));
            Columns["Action"].Width=Columns["Action"].MinimumWidth=Math.Max(Theme.S(narrow?100:compact?112:120),Theme.Measure(Lang.T("باز کردن","Open"),Theme.Small).Width+Theme.S(narrow?66:72));
        }

        protected override void OnRowHeightChanged(DataGridViewRowEventArgs e) { base.OnRowHeightChanged(e); PlaceDetail(); }

        public List<CopyRow> SelectedCopies { get { return SelectedRows.Cast<DataGridViewRow>().Select(r => r.Tag as CopyRow).Where(r => r != null).ToList(); } }

        // ------------------------------------------------------------- painting

        static Rectangle Inner(Rectangle cell) { return new Rectangle(cell.X + Theme.S(8), cell.Y, Math.Max(0, cell.Width - Theme.S(16)), cell.Height); }

        /// <summary>3.26 (CHANGE-002): short words on a small button.</summary>
        static string OpenText(CopyRow r) { return r.Running ? Lang.T("نمایش", "Show") : Lang.T("باز کردن", "Open"); }

        /// <summary>Where the two buttons sit in the action cell: "⋯" at the reading end (left), the main button next to it.</summary>
        void ActionRects(Rectangle cell, CopyRow r, out Rectangle open, out Rectangle more)
        {
            if (cell.Height > BaseHeight) cell.Height = BaseHeight;
            int h = Theme.S(26), y = cell.Y + (cell.Height - h) / 2;
            more = new Rectangle(cell.X + Theme.S(8), y, Theme.S(28), h);
            int w = Theme.Measure(OpenText(r), Theme.Small).Width + Theme.S(10) * 2 + Theme.S(12) + Theme.S(6);
            open = new Rectangle(more.Right + Theme.S(6), y, w, h);
            // 3.27: English: «···» at the row's end (right), the button before it.
            more = Theme.Flip(more, cell);
            open = Theme.Flip(open, cell);
        }

        protected override void OnCellPainting(DataGridViewCellPaintingEventArgs e)
        {
            base.OnCellPainting(e);
            if (e.ColumnIndex < 0) return;
            e.Handled = true;
            Graphics g = e.Graphics;
            Rectangle cell = e.CellBounds;
            string col = Columns[e.ColumnIndex].Name;
            if (e.RowIndex < 0)
            {
                using (var b = new SolidBrush(HeadBack)) g.FillRectangle(b, cell.X, cell.Y, cell.Width + 1, cell.Height);
                if (col == "Check") PaintBox(g, cell, headerCheck, false);
                else
                {
                    Rectangle title = Inner(cell);
                    bool sorted = (HeaderSortColumn==col||col=="Today"&&HeaderSortColumn=="TradeCount")&&HeaderSortDirection!=0;
                    if (sorted)
                    {
                        int width = Theme.S(14), x = Lang.En ? title.Right - width / 2 : title.Left + width / 2;
                        int y = title.Top + title.Height / 2, radius = Theme.S(3);
                        var triangle = HeaderSortDirection == 1
                            ? new[] { new Point(x, y - radius), new Point(x - radius, y + radius), new Point(x + radius, y + radius) }
                            : new[] { new Point(x - radius, y - radius), new Point(x + radius, y - radius), new Point(x, y + radius) };
                        using (var brush = new SolidBrush(HeadActive)) g.FillPolygon(brush, triangle);
                        if (!Lang.En) title.X += width;
                        title.Width = Math.Max(0, title.Width - width);
                    }
                    Theme.Line(g, Columns[e.ColumnIndex].HeaderText, Theme.SmallBold, title, sorted ? HeadActive : HeadText);
                }
                using (var pen = new Pen(HeadLine)) g.DrawLine(pen, cell.Left, cell.Bottom - 1, cell.Right, cell.Bottom - 1);
                // A short separator between column titles keeps the columns readable as a table.
                if (Lang.En ? col != "Status" && col != "Action" && col != "Check" : col != "Trader" && col != "Action" && col != "Check")
                    using (var pen = new Pen(HeadLine)) g.DrawLine(pen, cell.Right - 1, cell.Top + Theme.S(10), cell.Right - 1, cell.Bottom - Theme.S(10));
                return;
            }
            CopyRow r = RowAt(e.RowIndex);
            bool sel = Rows[e.RowIndex].Selected;
            // An open report takes the lower part of its row: the cells keep the top part, as tall as any other row.
            if (cell.Height > BaseHeight) cell = new Rectangle(cell.X, cell.Y, cell.Width, BaseHeight);
            using (var b = new SolidBrush(RowBack(e.RowIndex))) g.FillRectangle(b, cell.X, cell.Y, cell.Width + 1, cell.Height);
            using (var pen = new Pen(Divider)) g.DrawLine(pen, cell.Left, cell.Bottom - 1, cell.Right + 1, cell.Bottom - 1);
            if (r == null) return;
            Rectangle inner = Inner(cell);
            switch (col)
            {
                case "Check":
                    // The marked row has an accent bar at its start (the right edge).
                    if (sel) using (var b = new SolidBrush(Theme.Accent)) g.FillRectangle(b, Lang.En ? cell.Left : cell.Right - Theme.S(3), cell.Top, Theme.S(3), cell.Height - 1);
                    PaintBox(g, cell, r.Checked ? 2 : 0, e.RowIndex == hoverRow && hoverPart == RowPart.Check);
                    break;
                case "Ordinal":
                    Theme.Line(g,Fa.N(e.RowIndex+1),Theme.Small,cell,Theme.Muted,true);
                    break;
                case "Trader":
                    {
                        var nameBox=inner;
                        {var note=NoteRect(e.RowIndex,r);Glyphs.Draw(g,Glyph.NoteEdit,note,r.HasNote?Theme.Accent:Theme.Muted);if(Lang.En)nameBox.Width=Math.Max(1,note.Left-Theme.S(6)-nameBox.Left);else{nameBox.X=note.Right+Theme.S(6);nameBox.Width=Math.Max(1,inner.Right-nameBox.X);}}
                        bool over=e.RowIndex==hoverRow&&hoverPart==RowPart.Name;
                        Theme.Line(g,r.Trader,r.HasAccount?Theme.Bold:Theme.Font,nameBox,over?Theme.Accent:r.HasAccount?Theme.Text:Theme.Faint);
                    }
                    break;
                case "Copy":
                    {
                        // 3.23 (approved): one badge, the copy's name, which says its platform too ("MT4-01").
                        Size t = Theme.Measure(r.Name, Theme.CopyFont);
                        int bw = Math.Min(inner.Width, t.Width + Theme.S(14)), bh = Theme.S(20);
                        var badge = Theme.Flip(new Rectangle(inner.Right - bw, cell.Y + (cell.Height - bh) / 2, bw, bh), inner);
                        Theme.Box(g, badge, Theme.Sf(3), Color.FromArgb(0xEE, 0xEF, 0xF1), Color.Transparent);
                        Theme.Line(g, r.Name, Theme.CopyFont, badge, Theme.Mix(Theme.Text, Theme.Muted, 0.35f), true);
                    }
                    break;
                case "Login":
                    if (r.MasterLogin)
                    {
                        int badge = Theme.S(16);
                        var mark = new Rectangle(inner.Right - badge, inner.Top + (inner.Height - badge) / 2, badge, badge);
                        Theme.Box(g, mark, Theme.Sf(3), Theme.WarnSoft, Color.Transparent);
                        Theme.Line(g, "M", Theme.SmallBold, mark, Theme.Warn, true);
                        inner.Width = Math.Max(0, inner.Width - badge - Theme.S(4));
                    }
                    Ltr(g, r.Login, inner);
                    break;
                case "Server":
                    Ltr(g, r.Server, inner,Theme.ServerFont);
                    break;
                case "Status":
                    PaintStatus(g, r, inner);
                    break;
                case "Today":
                    PaintToday(g, r, inner, false);
                    break;
                case "Freshness":
                    if(r.HasAccount){int line=Theme.S(18),top=inner.Y+(inner.Height-2*line)/2;
                        TextRenderer.DrawText(g,r.AccountBalance,Theme.SmallBold,new Rectangle(inner.X,top,inner.Width,line),Theme.Text,TextFormatFlags.Left|TextFormatFlags.SingleLine|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPadding);
                        TextRenderer.DrawText(g,r.AccountDrawdown,Theme.Small,new Rectangle(inner.X,top+line,inner.Width,line),Theme.Muted,TextFormatFlags.Left|TextFormatFlags.SingleLine|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPadding);}
                    break;
                case "Folders":
                    PaintFolders(g, r, inner);
                    break;
                case "Action":
                    PaintActions(g, r, cell, e.RowIndex);
                    break;
            }
        }

        /// <summary>A number or a server name, left to right at the right of its cell; one too long for it starts at the left and ends
        /// in "…" (right-aligned, its start would be cut off).</summary>
        static void Ltr(Graphics g, string text, Rectangle r,Font font=null)
        {
            font=font??Theme.Font;
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis;
            bool fits = TextRenderer.MeasureText(text ?? "", font, Size.Empty, f).Width <= r.Width;
            // 3.27: English: at the start (left) like the rest.
            TextRenderer.DrawText(g, text ?? "", font, r, Theme.Text, f | (fits && !Lang.En ? TextFormatFlags.Right : TextFormatFlags.Left));
        }

        Color RowBack(int row)
        {
            return row%2==0 ? Theme.Surface : Color.FromArgb(241,243,246);
        }

        static readonly Color CheckedBack = Color.FromArgb(0xF7, 0xFA, 0xFE);

        /// <summary>A square box in the middle of the cell: empty, a dash (some), or filled with a tick (all / this one).</summary>
        static void PaintBox(Graphics g, Rectangle cell, int state, bool hover)
        {
            int size = Theme.S(16);
            Theme.TickBox(g, new Rectangle(cell.X + (cell.Width - size) / 2, cell.Y + (cell.Height - size) / 2, size, size), state, hover);
        }

        /// <summary>The whole row first, so no gap between cells can show through.</summary>
        protected override void OnRowPrePaint(DataGridViewRowPrePaintEventArgs e)
        {
            base.OnRowPrePaint(e);
            using (var b = new SolidBrush(RowBack(e.RowIndex))) e.Graphics.FillRectangle(b, e.RowBounds);
        }

        // 3.17: white capsules with a thin frame and gently rounded corners, like the folder row above the list.
        static Color TagBack { get { return Theme.Surface; } }
        static Color TagLine { get { return Theme.BorderStrong; } }
        static Color TagText { get { return Theme.LabelColor; } }
        static float TagRadius { get { return Theme.Square ? 0 : Theme.Sf(6); } }

        /// <summary>The copy's folders as small labels from the right; what does not fit becomes "+N".</summary>
        static void PaintFolders(Graphics g, CopyRow r, Rectangle inner)
        {
            if (r.Folders.Length == 0) return;
            int h = Theme.S(20), y = inner.Y + (inner.Height - h) / 2, x = inner.Right, gap = Theme.S(4), pad = Theme.S(8);
            for (int k = 0; k < r.Folders.Length; k++)
            {
                string t = r.Folders[k];
                int w = Theme.Measure(t, Theme.Small).Width + pad * 2;
                int left = r.Folders.Length - k - 1;
                int moreW = left > 0 ? Theme.Measure("+" + Fa.N(left), Theme.Small).Width + pad * 2 + gap : 0;
                bool fits = x - w - moreW >= inner.X;
                if (!fits)
                {
                    string m = "+" + Fa.N(r.Folders.Length - k);
                    int mw = Theme.Measure(m, Theme.Small).Width + pad * 2;
                    if (k == 0)
                    {
                        // Not even one fits whole: the first, shortened, then the rest as "+N".
                        w = Math.Max(Theme.S(30), inner.Width - (r.Folders.Length > 1 ? mw + gap : 0));
                        var b0 = Theme.Flip(new Rectangle(x - w, y, w, h), inner);
                        Theme.Box(g, b0, TagRadius, TagBack, TagLine);
                        // 3.26 (CHANGE-001): shortened from its end with "…" (centred, it was cut on both sides).
                        Theme.Line(g, t, Theme.Small, new Rectangle(b0.X + pad / 2, b0.Y, b0.Width - pad, b0.Height), TagText);
                        x -= w + gap;
                        if (r.Folders.Length == 1) return;
                        m = "+" + Fa.N(r.Folders.Length - 1);
                        mw = Theme.Measure(m, Theme.Small).Width + pad * 2;
                    }
                    var mb = Theme.Flip(new Rectangle(x - mw, y, mw, h), inner);
                    Theme.Box(g, mb, TagRadius, Theme.Surface, TagLine);
                    Theme.Line(g, m, Theme.Small, mb, Theme.Muted, true);
                    return;
                }
                var b = Theme.Flip(new Rectangle(x - w, y, w, h), inner);
                Theme.Box(g, b, TagRadius, TagBack, TagLine);
                Theme.Line(g, t, Theme.Small, b, TagText, true);
                x -= w + gap;
            }
        }

        /// <summary>3.21: the «امروز» cell: the day in a few words (left to right, the money green or red, "No SL" red) at the right,
        /// and when it was read under it; or that it is being read, was not read, or could not be.</summary>
        static void PaintToday(Graphics g, CopyRow r, Rectangle inner, bool separateFreshness)
        {
            if (!r.HasAccount) return;
            int line = Theme.S(18), top = inner.Y + (inner.Height - line * (separateFreshness?1:2)) / 2;
            if (r.TodayBusy)
            {
                int dot = Theme.S(10);
                var d = Theme.Flip(new RectangleF(inner.Right - dot, inner.Y + (inner.Height - dot) / 2f, dot, dot), inner);
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using (var pen = new Pen(Theme.Accent, Math.Max(1.4f, Theme.Sf(1.6f)))) g.DrawArc(pen, d.X + 0.5f, d.Y + 0.5f, d.Width - 1, d.Height - 1, -90, 270);
                Theme.Line(g, !separateFreshness && r.TodayAgo.Length > 0 ? r.TodayAgo : Lang.T("در حال خواندن…", "Reading…"), Theme.Small, Theme.Flip(new Rectangle(inner.X, inner.Y, inner.Width - dot - Theme.S(7), inner.Height), inner), Theme.Accent);
                return;
            }
            if (r.TodayNone)
            {
                Theme.Line(g, r.TodayText, Theme.Small, new Rectangle(inner.X, top, inner.Width, line), r.TodayFailed ? Theme.Bad : Theme.Faint);
                if (!separateFreshness && r.TodayAgo.Length > 0) PaintReportAge(g,r,new Rectangle(inner.X,top+line,inner.Width,line));
                return;
            }
            // Each compact closed/open segment keeps its own profit/loss colour.
            // Clip to the cell; the tooltip preserves the full text and its measurement basis.
            string[] parts = r.TodayText.Split(new[] { " · " }, StringSplitOptions.None);
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter;
            int gap = Theme.S(15), total = parts.Sum(p => TextRenderer.MeasureText(p, Theme.Small, Size.Empty, f).Width) + Math.Max(0, parts.Length - 1) * gap;
            int x = Lang.En ? inner.X : Math.Max(inner.X, inner.Right - total);
            for (int k = 0; k < parts.Length && x < inner.Right; k++)
            {
                if (k > 0)
                {
                    TextRenderer.DrawText(g, "·", Theme.Small, new Rectangle(x, top, Math.Min(gap, inner.Right - x), line), Theme.Faint, f | TextFormatFlags.HorizontalCenter);
                    x += gap;
                }
                if (x >= inner.Right) break;
                string amount = parts[k].StartsWith("O/", StringComparison.Ordinal) ? parts[k].Substring(2) : parts[k];
                Color c = amount.StartsWith("-", StringComparison.Ordinal) ? Theme.Bad : amount.StartsWith("+", StringComparison.Ordinal) ? Theme.Ok : Theme.Text;
                int w = TextRenderer.MeasureText(parts[k], Theme.Small, Size.Empty, f).Width;
                TextRenderer.DrawText(g, parts[k], Theme.Small, new Rectangle(x, top, Math.Min(w + 1, inner.Right - x), line), c, f | TextFormatFlags.EndEllipsis);
                x += w;
            }
            if (!separateFreshness && r.TodayAgo.Length > 0) PaintReportAge(g,r,new Rectangle(inner.X,top+line,inner.Width,line));
        }

        static void PaintReportAge(Graphics g,CopyRow row,Rectangle area)
        {
            string live=Lang.T("زنده","Live");
            if(row.TodayLive&&!row.PreviousReport&&row.TodayAgo.StartsWith(live+" · ",StringComparison.Ordinal))
            {
                int dot=Theme.S(5),gap=Theme.S(5),labelWidth=Theme.Measure(live,Theme.SmallBold).Width;
                int used=dot+gap+labelWidth+Theme.S(5);
                if(area.Width>used+Theme.S(20))
                {
                    Color green=Color.FromArgb(35,132,91);
                    Func<Rectangle,Rectangle> orient=r=>Lang.En?r:new Rectangle(area.Left+area.Right-r.Right,r.Y,r.Width,r.Height);
                    var d=orient(new Rectangle(area.X,area.Y+(area.Height-dot)/2,dot,dot));
                    using(var brush=new SolidBrush(green))g.FillEllipse(brush,d);
                    var labelArea=orient(new Rectangle(area.X+dot+gap,area.Y,labelWidth,area.Height));
                    Theme.Line(g,live,Theme.SmallBold,labelArea,green);
                    var rest=orient(new Rectangle(area.X+used,area.Y,area.Width-used,area.Height));
                    Theme.Line(g,"· "+row.TodayAgo.Substring(live.Length+3),Theme.Small,rest,Theme.Faint);
                    return;
                }
            }
            if(!row.PreviousReport){Theme.Line(g,row.TodayAgo,Theme.Small,area,Theme.Faint);return;}
            string label=Lang.T("گزارش قبلی","Previous");int width=Math.Min(area.Width,Theme.Measure(label,Theme.Small).Width+Theme.S(10));
            var badge=Theme.Flip(new Rectangle(area.X,area.Y,width,area.Height),area);
            Theme.Box(g,badge,Theme.Sf(3),Color.FromArgb(251,243,224),Color.Transparent);Theme.Line(g,label,Theme.Small,badge,Color.FromArgb(143,100,27),true);
            var remaining=Theme.Flip(new Rectangle(area.X+width+Theme.S(4),area.Y,Math.Max(0,area.Width-width-Theme.S(4)),area.Height),area);Theme.Line(g,row.TodayAgo,Theme.Small,remaining,Theme.Faint);
        }

        /// <summary>3.26 (CHANGE-004): the state as a small label with a pale background and its dot inside.</summary>
        void PaintStatus(Graphics g, CopyRow r, Rectangle inner)
        {
            if(r.ReviewOpen>0)
            {
                int height=Theme.S(18),top=inner.Y+(inner.Height-height*2)/2;
                Theme.Line(g,Lang.T(r.Running?"زنده باز":"زنده بسته",r.Running?"Live open":"Live closed"),Theme.Small,new Rectangle(inner.X,top,inner.Width,height),r.Running?Theme.Text:Theme.Bad,true);
                Theme.Line(g,Lang.T("بررسی باز","Review open")+(r.ReviewOpen>1?" · "+Fa.N(r.ReviewOpen):""),Theme.Small,new Rectangle(inner.X,top+height,inner.Width,height),Theme.Accent,true);
                return;
            }

            Color back, text, dotColor;
            switch (r.State)
            {
                case RowState.On: back = Color.FromArgb(0xE6, 0xF4, 0xE6); text = Color.FromArgb(0x0E, 0x6E, 0x0B); dotColor = OkDot; break;
                case RowState.Open: back = Color.FromArgb(0xEC, 0xF7, 0xEC); text = Color.FromArgb(0x2F, 0x6B, 0x2D); dotColor = Theme.Mix(OkDot, Color.White, 0.35f); break;
                case RowState.Bad: back = Color.FromArgb(0xFD, 0xE7, 0xE7); text = Theme.Bad; dotColor = Theme.Bad; break;
                case RowState.Warn: back = Color.FromArgb(0xFD, 0xF1, 0xDC); text = Color.FromArgb(0x8A, 0x55, 0x00); dotColor = WarnDot; break;
                case RowState.Active: back = Theme.AccentSoft; text = Theme.Accent; dotColor = Theme.Accent; break;
                default: back = Color.FromArgb(0xF0, 0xF0, 0xF0); text = Theme.Muted; dotColor = OffDot; break;
            }
            int dot = Theme.S(7), padIn = Theme.S(9), gap = Theme.S(6), h = Theme.S(22);
            Font font = Theme.SmallBold;
            int w = Math.Min(inner.Width, Theme.Measure(r.Status ?? "", font).Width + padIn * 2 + dot + gap);
            var chip = Theme.Flip(new Rectangle(inner.Right - w, inner.Y + (inner.Height - h) / 2, w, h), inner);
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Theme.Box(g, chip, Theme.Square ? 0 : h / 2f, back, Color.Transparent);
            var dd = new RectangleF(chip.Right - padIn - dot, chip.Y + (chip.Height - dot) / 2f, dot, dot);
            var d = Theme.Flip(dd, chip);
            if (r.State == RowState.Pending)
                using (var pen = new Pen(Theme.Accent, Math.Max(1.4f, Theme.Sf(1.5f)))) g.DrawArc(pen, d.X - 1, d.Y - 1, d.Width + 1, d.Height + 1, -90, 270);
            else
                using (var b = new SolidBrush(dotColor)) g.FillEllipse(b, d);
            Theme.Line(g, r.Status, font, Theme.Flip(new Rectangle(chip.X + padIn, chip.Y, Math.Max(0, (int)dd.X - gap - chip.X - padIn), chip.Height), chip), text);
        }

        void PaintActions(Graphics g, CopyRow r, Rectangle cell, int row)
        {
            Rectangle open, more;
            ActionRects(cell, r, out open, out more);
            bool hoverOpen = row == hoverRow && hoverPart == RowPart.Open, hoverMore = row == hoverRow && hoverPart == RowPart.More;
            // 3.26 (CHANGE-002): a small white button on every row; blue (the main one) only on the marked row or the row under the mouse.
            bool strong = Rows[row].Selected || row == hoverRow;
            Color fill, border, fore, glyph;
            if(r.Running)
            {
                fill=Color.FromArgb(47,51,58);
                border=fill;fore=glyph=Color.White;
            }
            else if (strong)
            {
                fill = hoverOpen ? Color.FromArgb(36,99,181) : Color.FromArgb(47,112,200);
                border = fill;
                fore = glyph = Theme.OnAccent;
            }
            else
            {
                fill = Theme.Surface;
                border = Theme.BorderStrong;
                fore = Theme.Text;
                glyph = Theme.Muted;
            }
            Theme.Box(g, open, Theme.Sf(4), fill, border);
            int icon = Theme.S(11);
            var ir = new RectangleF(open.Right - Theme.S(10) - icon, open.Y + (open.Height - icon) / 2f, icon, icon);
            Glyphs.Draw(g, r.Running ? Glyph.Window : Glyph.Play, Theme.Flip(ir, open), glyph);
            Theme.Line(g, OpenText(r), Theme.Small, Theme.Flip(new Rectangle(open.X + Theme.S(8), open.Y, (int)ir.X - Theme.S(6) - open.X - Theme.S(8), open.Height), open), fore);
            if (hoverMore) Theme.Box(g, more, Theme.Sf(4), Theme.Mix(Theme.Hover, Color.Black, 0.04f), Color.Transparent);
            int m = Theme.S(15);
            Glyphs.Draw(g, Glyph.More, new RectangleF(more.X + (more.Width - m) / 2f, more.Y + (more.Height - m) / 2f, m, m), Theme.Muted);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Rows.Count == 0 && !string.IsNullOrEmpty(EmptyText))
                Theme.Line(e.Graphics, EmptyText, Theme.Font, new Rectangle(0, ColumnHeadersHeight + Theme.S(24), Width, Theme.S(30)), Theme.Muted, true);
        }

        // ------------------------------------------------------------- mouse and keys

        RowPart PartAt(Point p, out int row)
        {
            HitTestInfo h = HitTest(p.X, p.Y);
            row = h.Type == DataGridViewHitTestType.Cell ? h.RowIndex : -1;
            CopyRow r = RowAt(row);
            // The whole first cell is the box: easy to hit.
            if (row >= 0 && r != null && h.ColumnIndex == Columns["Check"].Index) return RowPart.Check;
            if (row >= 0 && r != null && h.ColumnIndex == Columns["Trader"].Index) return NoteRect(row,r).Contains(p)?RowPart.Note:NameRect(row,r).Contains(p)?RowPart.Name:RowPart.None;
            if (row < 0 || h.ColumnIndex != Columns["Action"].Index || r == null) return RowPart.None;
            Rectangle open, more;
            ActionRects(GetCellDisplayRectangle(h.ColumnIndex, row, false), RowAt(row), out open, out more);
            return open.Contains(p) ? RowPart.Open : more.Contains(p) ? RowPart.More : RowPart.None;
        }

        /// <summary>3.24.2: where the student's name is written in its row (with the small mark beside it): only there a click opens the
        /// student's page. A copy without an account has none.</summary>
        Rectangle NoteRect(int row,CopyRow r){if(r==null)return Rectangle.Empty;var cell=GetCellDisplayRectangle(Columns["Trader"].Index,row,false);int size=Theme.S(16);return new Rectangle(Lang.En?cell.Right-Theme.S(8)-size:cell.Left+Theme.S(8),cell.Top+(BaseHeight-size)/2,size,size);}
        Rectangle NameRect(int row,CopyRow r){if(r==null)return Rectangle.Empty;var cell=GetCellDisplayRectangle(Columns["Trader"].Index,row,false);cell.Height=Math.Min(cell.Height,BaseHeight);var inner=Inner(cell);{var note=NoteRect(row,r);if(Lang.En)inner.Width=Math.Max(1,note.Left-Theme.S(6)-inner.Left);else{inner.X=note.Right+Theme.S(6);inner.Width=Math.Max(1,cell.Right-Theme.S(8)-inner.X);}}return inner;}

        void SetHover(int row, RowPart part)
        {
            if (row == hoverRow && part == hoverPart) return;
            int old = hoverRow;
            hoverRow = row;
            hoverPart = part;
            if (old >= 0 && old < Rows.Count) InvalidateRow(old);
            if (row >= 0 && row < Rows.Count && row != old) InvalidateRow(row);
            else if (row >= 0 && row < Rows.Count) InvalidateRow(row);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            int row;
            RowPart part = PartAt(e.Location, out row);
            SetHover(row, part);
            HitTestInfo h = HitTest(e.X, e.Y);
            bool headBox = h.Type == DataGridViewHitTestType.ColumnHeader && h.ColumnIndex >= 0 && (h.ColumnIndex == Columns["Check"].Index || (Columns[h.ColumnIndex].Name!="Freshness"&&DashboardSort.Columns.Contains(Columns[h.ColumnIndex].Name)));
            Cursor want = part != RowPart.None || headBox ? Cursors.Hand : Cursors.Default;
            if (Cursor != want) Cursor = want;
            string t = TipAt(h);
            if (t != tipText)
            {
                tipText = t;
                tip.SetToolTip(this, t.Length > 0 ? t : null);
            }
        }

        /// <summary>3.26 (CHANGE-001/003): the whole text of a shortened server name or «امروز» line.</summary>
        string TipAt(HitTestInfo h)
        {
            if (h.Type == DataGridViewHitTestType.ColumnHeader && h.ColumnIndex >= 0 && Columns[h.ColumnIndex].Name == "Today")
                return Lang.T("کلیک: تعداد معاملات بسته‌شده، سپس باز؛ دوباره: ترتیب قبلی", "Click: closed-trade count, then open count; again: original order");
            if (h.Type == DataGridViewHitTestType.ColumnHeader && h.ColumnIndex >= 0 && (Columns[h.ColumnIndex].Name!="Freshness"&&DashboardSort.Columns.Contains(Columns[h.ColumnIndex].Name)))
                return Lang.T("کلیک: صعودی، دوباره: نزولی، بار سوم: ترتیب قبلی", "Click: ascending, again: descending, third click: original order");
            if (h.Type != DataGridViewHitTestType.Cell) return "";
            CopyRow r = RowAt(h.RowIndex);
            if (r == null) return "";
            string col = Columns[h.ColumnIndex].Name;
            Rectangle cell = GetCellDisplayRectangle(h.ColumnIndex, h.RowIndex, false);
            if (cell.Height > BaseHeight) cell.Height = BaseHeight;
            int room = Inner(cell).Width;
            if (col == "Login" && r.MasterLogin) return Lang.T("نوع ورود تنظیم‌شده: مستر", "Configured login mode: Master");
            if(col=="Copy")return r.Name;
            if (col == "Server")
                return Theme.Measure(r.Server ?? "", Theme.ServerFont).Width > room ? r.Server : "";
            if (col == "Freshness") return r.AccountInfoTip;
            if (col == "Today") return ""; // Requested: no long report tooltip over student rows.
            return "";
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            if (tipText.Length > 0) { tipText = ""; tip.SetToolTip(this, null); }
            SetHover(-1, RowPart.None);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            HitTestInfo h = HitTest(e.X, e.Y);
            if (e.Button == MouseButtons.Right && h.RowIndex >= 0 && !Rows[h.RowIndex].Selected)
            {
                ClearSelection();
                Rows[h.RowIndex].Selected = true;
                CurrentCell = Rows[h.RowIndex].Cells[Columns["Trader"].Index];
            }
            base.OnMouseDown(e);
        }

#if SNAPSHOT
        /// <summary>For the screenshots: the mouse on a row's name (-1: nowhere).</summary>
        public void PreviewNameHover(int row) { SetHover(row, row >= 0 ? RowPart.Name : RowPart.None); }
#endif

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            int row;
            RowPart part = PartAt(e.Location, out row);
            CopyRow r = RowAt(row);
            if (r == null) return;
            if (e.Button == MouseButtons.Right) { if (MenuWanted != null) MenuWanted(r, PointToScreen(e.Location)); return; }
            // A click below the cells of an open row is the report's own (it has its own control there).
            if (row >= 0 && e.Y >= GetRowDisplayRectangle(row, false).Y + BaseHeight) return;
            // 3.24.2: only the name opens the student's page; a click anywhere else in the row only marks it.
            if (part == RowPart.None) return;
            if(part==RowPart.Note){if(e.Button==MouseButtons.Left&&NoteClicked!=null)NoteClicked(r);return;}
            if (part == RowPart.Name) { if (e.Button == MouseButtons.Left && RowClicked != null) RowClicked(r); return; }
            if (part == RowPart.Check && CheckClicked != null) CheckClicked(r);
            else if (part == RowPart.Open && OpenClicked != null) OpenClicked(r);
            else if (part == RowPart.More && MenuWanted != null)
            {
                Rectangle open, more;
                ActionRects(GetCellDisplayRectangle(Columns["Action"].Index, row, false), r, out open, out more);
                MenuWanted(r, PointToScreen(new Point(more.Left, more.Bottom + Theme.S(2))));
            }
        }

        protected override void OnColumnHeaderMouseClick(DataGridViewCellMouseEventArgs e)
        {
            base.OnColumnHeaderMouseClick(e);
            if (e.Button == MouseButtons.Left && e.ColumnIndex == Columns["Check"].Index && CheckAllClicked != null) CheckAllClicked();
            else if (e.Button == MouseButtons.Left && e.ColumnIndex >= 0) CycleHeaderSort(Columns[e.ColumnIndex].Name);
        }

        // 3.21: a double click no longer opens MetaTrader (approved): a click on the name opens the report, MetaTrader opens from its button only.

        protected override bool ProcessDataGridViewKey(KeyEventArgs e)
        {
            CopyRow r = CurrentRow != null ? RowAt(CurrentRow.Index) : null;
            if (r != null && e.KeyCode == Keys.Enter && !e.Control && !e.Shift)
            {
                if (RowClicked != null) RowClicked(r);
                return true;
            }
            if (r != null && e.KeyCode == Keys.Space && !e.Control)
            {
                if (CheckClicked != null) CheckClicked(r);
                return true;
            }
            if (r != null && (e.KeyCode == Keys.Apps || (e.Shift && e.KeyCode == Keys.F10)))
            {
                Rectangle cell = GetCellDisplayRectangle(Columns["Action"].Index, CurrentRow.Index, false);
                if (MenuWanted != null) MenuWanted(r, PointToScreen(new Point(cell.Left + Theme.S(10), cell.Bottom)));
                return true;
            }
            return base.ProcessDataGridViewKey(e);
        }
    }
}
