using System;using System.Collections.Generic;using System.IO;using System.Linq;using System.Text;using System.Text.RegularExpressions;
namespace MTManager
{
    // Import-only discovery. Server catalogs are endpoint hints, never evidence of successful authentication.
    public static class ImportBrokerCatalog
    {
        const int PerFile=2*1024*1024,Total=8*1024*1024;
        static readonly Regex Name=new Regex(@"(?<![A-Za-z0-9_-])(?:WMMarkets|WindsorBrokers[0-9]*|Windsor)-(?:Demo|Real|Live)[0-9]*(?![A-Za-z0-9_-])",RegexOptions.IgnoreCase,TimeSpan.FromSeconds(1));
        public static string[] Extract(byte[] bytes)
        {
            if(bytes==null||bytes.Length>PerFile)return new string[0];var names=new List<string>();
            foreach(string text in new[]{Encoding.ASCII.GetString(bytes),Encoding.Unicode.GetString(bytes,0,bytes.Length-bytes.Length%2),bytes.Length>1?Encoding.Unicode.GetString(bytes,1,(bytes.Length-1)-(bytes.Length-1)%2):""})
                foreach(Match m in Name.Matches(text))if(ImportServerPlan.Safe(m.Value))names.Add(m.Value);
            return names.Distinct(StringComparer.OrdinalIgnoreCase).Take(512).ToArray();
        }
        static bool Unlinked(string path)
        {try{for(string p=Path.GetFullPath(path);!string.IsNullOrEmpty(p);p=Path.GetDirectoryName(p))if((File.Exists(p)||Directory.Exists(p))&&(File.GetAttributes(p)&FileAttributes.ReparsePoint)!=0)return false;return true;}catch{return false;}}
        static string[] Read(string root,ref int total)
        {
            try
            {
                string config=PortableServers.Subdirectory(root,"config");if(!Directory.Exists(config)||!Unlinked(config))return new string[0];
                string file=Directory.EnumerateFiles(config).Take(4096).FirstOrDefault(p=>Path.GetFileName(p).Equals("servers.dat",StringComparison.OrdinalIgnoreCase));
                if(file==null||!Unlinked(file))return new string[0];
                using(var stream=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))
                {
                    if(stream.Length>PerFile||stream.Length+total>Total)return new string[0];var bytes=new byte[(int)stream.Length];int offset=0;while(offset<bytes.Length){int got=stream.Read(bytes,offset,bytes.Length-offset);if(got==0)break;offset+=got;}total+=bytes.Length;return Extract(bytes);
                }
            }
            catch{return new string[0];}
        }
        public static List<string> Names(Kind kind,Settings settings,AccountStore accounts)
        {
            var names=ServerCatalog.Local(kind,settings,accounts).Concat(ServerCatalog.Online(kind)).ToList();int total=0;
            foreach(string install in Installs.Find(kind,settings).Take(8))foreach(string root in PortableServers.Roots(install).Take(2))names.AddRange(Read(root,ref total));
            return names.Distinct(StringComparer.OrdinalIgnoreCase).Take(4096).ToList();
        }
    }
}
