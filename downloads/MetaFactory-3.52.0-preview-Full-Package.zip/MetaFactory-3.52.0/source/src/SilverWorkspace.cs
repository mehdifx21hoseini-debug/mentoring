using System;using System.Collections.Generic;using System.Drawing;using System.Linq;using System.Windows.Forms;
namespace MTManager
{
    sealed class SilverNavButton : Button
    {
        readonly Glyph icon; bool selected;
        internal SilverNavButton(string title,Glyph glyph){Text=title;icon=glyph;FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;UseVisualStyleBackColor=false;Cursor=Cursors.Hand;Height=Theme.S(42);Font=Theme.Font;SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);}
        internal bool Selected{get{return selected;}set{selected=value;Invalidate();}}
        protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.Clear(Parent.BackColor);var box=new Rectangle(Theme.S(4),Theme.S(3),Width-Theme.S(8),Height-Theme.S(6));if(selected)Theme.Box(g,box,Theme.Sf(8),Color.FromArgb(65,70,80),Color.Transparent);var color=selected?Color.White:Enabled?Theme.Text:Theme.Faint;var iconBox=Theme.Flip(new Rectangle(box.Right-Theme.S(29),box.Y+Theme.S(9),Theme.S(17),Theme.S(17)),box);Glyphs.Draw(g,icon,iconBox,color);var titleBox=Theme.Flip(new Rectangle(box.X+Theme.S(10),box.Y,Math.Max(1,box.Width-Theme.S(45)),box.Height),box);Theme.Line(g,Text,selected?Theme.Bold:Theme.Font,titleBox,color);if(Focused)ControlPaint.DrawFocusRectangle(g,Rectangle.Inflate(box,-2,-2));}
    }
    sealed class SilverInspector : Panel
    {
        internal CopyRow Row; internal event Action OpenTerminal,OpenReport,Edit;
        readonly ModernButton open,report,edit;
        internal SilverInspector(){Name="AccountInspector";BackColor=Theme.Surface;Width=Theme.S(230);Padding=Theme.Pad(14);SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);open=new ModernButton(Lang.T("باز کردن متاتریدر","Open MetaTrader"),(s,e)=>{if(OpenTerminal!=null)OpenTerminal();},ButtonKind.Primary);report=new ModernButton(Lang.T("مشاهده گزارش","View report"),(s,e)=>{if(OpenReport!=null)OpenReport();});edit=new ModernButton(Lang.T("ویرایش حساب","Edit account"),(s,e)=>{if(Edit!=null)Edit();},ButtonKind.Subtle);Controls.Add(open);Controls.Add(report);Controls.Add(edit);Resize+=(s,e)=>PlaceButtons();PlaceButtons();}
        void PlaceButtons(){int h=Theme.S(38),gap=Theme.S(8),bottom=Height-Theme.S(24);foreach(var b in new[]{edit,report,open}){b.Bounds=new Rectangle(Theme.S(14),bottom-h,Math.Max(1,Width-Theme.S(28)),h);bottom-=h+gap;}}
        internal void Set(CopyRow row){Row=row;open.Enabled=row!=null;report.Enabled=row!=null&&row.HasAccount;edit.Enabled=row!=null;open.Text=row!=null&&row.Running?Lang.T("نمایش متاتریدر","Show MetaTrader"):Lang.T("باز کردن متاتریدر","Open MetaTrader");PlaceButtons();Invalidate();}
        protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);var g=e.Graphics;var inner=Rectangle.Inflate(ClientRectangle,-Theme.S(15),-Theme.S(18));using(var p=new Pen(Theme.Border))g.DrawLine(p,Lang.En?0:Width-1,0,Lang.En?0:Width-1,Height);if(Row==null){Theme.Line(g,Lang.T("یک حساب انتخاب کنید","Select an account"),Theme.Font,inner,Theme.Muted,true);return;}int y=Theme.S(24),size=Theme.S(50);var av=new Rectangle((Width-size)/2,y,size,size);using(var b=new SolidBrush(Theme.AccentSoft))g.FillEllipse(b,av);string who=string.IsNullOrWhiteSpace(Row.Trader)?Row.Name:Row.Trader;string initials=string.Join("",who.Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries).Take(2).Select(x=>x.Substring(0,1)));Theme.Line(g,initials,Theme.Heading,av,Theme.Accent,true);y+=size+Theme.S(12);Theme.Line(g,who,Theme.Heading,new Rectangle(inner.X,y,inner.Width,Theme.S(32)),Theme.Text,true);y+=Theme.S(38);foreach(var item in new[]{Row.Login,Row.Server,Row.Name,Row.Status}){Theme.Line(g,item,Theme.Small,new Rectangle(inner.X,y,inner.Width,Theme.S(25)),Theme.Muted,true);y+=Theme.S(30);}using(var p=new Pen(Theme.Border))g.DrawLine(p,inner.X,y,inner.Right,y);y+=Theme.S(12);Theme.Line(g,Lang.T("آخرین گزارش","Last report"),Theme.SmallBold,new Rectangle(inner.X,y,inner.Width,Theme.S(24)),Theme.Text);y+=Theme.S(28);Theme.Line(g,Row.TodayAgo,Theme.Small,new Rectangle(inner.X,y,inner.Width,Theme.S(28)),Row.TodayFailed?Theme.Bad:Theme.Muted);}
    }
    sealed partial class MainForm
    {
        Panel silverShell,silverHost,silverAccounts; SilverInspector silverInspector; SettingsDialog silverSettings;
        readonly Dictionary<string,SilverNavButton> silverNavigation=new Dictionary<string,SilverNavButton>();
        readonly Dictionary<string,Form> silverPages=new Dictionary<string,Form>();
        string silverPage="accounts"; bool silverArranging,silverSwitching;
        void BuildSilverWorkspace()
        {
            silverShell=new Panel{Name="SilverWorkspace",Dock=DockStyle.Fill,BackColor=Theme.Page};
            var sidebar=new Panel{Name="WorkspaceNavigation",Dock=Lang.En?DockStyle.Left:DockStyle.Right,Width=Theme.S(164),BackColor=Color.FromArgb(240,242,247),Padding=Theme.Pad(8)};
            var brand=new Panel{Dock=DockStyle.Top,Height=Theme.S(70)};brand.Paint+=(s,e)=>{Theme.Line(e.Graphics,"M",Theme.Title,new Rectangle(Theme.S(5),Theme.S(16),Theme.S(25),Theme.S(34)),Theme.Accent,true);Theme.Line(e.Graphics,"MetaFactory",Theme.Bold,new Rectangle(Theme.S(32),Theme.S(16),brand.Width-Theme.S(36),Theme.S(34)),Theme.Text,true);};
            var nav=new FlowLayoutPanel{Dock=DockStyle.Top,Height=Theme.S(150),FlowDirection=FlowDirection.TopDown,WrapContents=false};
            var lower=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=Theme.S(154),FlowDirection=FlowDirection.TopDown,WrapContents=false};
            Action<string,string,Glyph,Action,bool> add=(key,title,glyph,action,bottom)=>{var button=new SilverNavButton(title,glyph){Width=Theme.S(148),Margin=Theme.Pad(0,3)};button.Click+=(s,e)=>Guard(action);silverNavigation[key]=button;(bottom?lower:nav).Controls.Add(button);if(key=="settings"||key=="tools"||key=="reports"||key=="folders")lockWhileBusy.Add(button);};
            add("accounts",Lang.T("حساب‌ها","Accounts"),Glyph.User,ShowSilverAccounts,false);
            add("reports",Lang.T("گزارش‌ها","Reports"),Glyph.Doc,ShowReportText,false);
            add("folders",Lang.T("پوشه‌ها","Folders"),Glyph.Folder,ShowSilverFolders,false);
            add("settings",Lang.T("تنظیمات","Settings"),Glyph.Gear,EditSettings,true);
            add("support",Lang.T("پشتیبانی","Support"),Glyph.Help,ShowSilverSupport,true);
            add("tools",Lang.T("ابزارها","Tools"),Glyph.More,()=>ShowUnder(toolsMenu,silverNavigation["tools"]),true);
            sidebar.Controls.Add(nav);sidebar.Controls.Add(brand);sidebar.Controls.Add(lower);
            silverHost=new Panel{Name="WorkspaceContent",Dock=DockStyle.Fill,BackColor=Theme.Surface};
            silverAccounts=new Panel{Name="AccountsWorkspace",Dock=DockStyle.Fill,BackColor=Theme.Page};
            silverAccounts.Controls.Add(body);silverAccounts.Controls.Add(band);body.Dock=DockStyle.Fill;band.Dock=DockStyle.Top;band.PrimaryCommand=newButton;
            silverInspector=new SilverInspector{Dock=Lang.En?DockStyle.Right:DockStyle.Left,Visible=false};silverInspector.OpenTerminal+=()=>Guard(()=>{if(silverInspector.Row!=null){var copy=Find(silverInspector.Row);if(copy!=null)OpenOrShow(copy);}});silverInspector.OpenReport+=()=>Guard(()=>OpenStudent(silverInspector.Row));silverInspector.Edit+=()=>Guard(()=>{if(silverInspector.Row!=null){var copy=Find(silverInspector.Row);if(copy!=null)EditAccountOf(copy);}});lockWhileBusy.Add(silverInspector);
            body.Controls.Add(silverInspector);silverInspector.BringToFront();card.BringToFront();
            grid.SelectionChanged+=(s,e)=>RefreshSilverInspector();body.Resize+=(s,e)=>RefreshSilverInspector();
            silverHost.Controls.Add(silverAccounts);silverShell.Controls.Add(silverHost);silverShell.Controls.Add(sidebar);Controls.Add(silverShell);silverShell.BringToFront();FormClosed+=(sender,args)=>{silverSwitching=true;foreach(var child in silverPages.Values.ToArray())if(!child.IsDisposed)child.Close();silverPages.Clear();};MarkSilverPage("accounts");band.PerformLayout();KeyDown+=(sender,args)=>{if(args.Control&&args.KeyCode==Keys.F)ShowSilverAccounts();};
        }
        void MarkSilverPage(string key){silverPage=key;foreach(var item in silverNavigation)item.Value.Selected=item.Key==key;}
        void ShowSilverControl(Control control,string key){silverSwitching=true;try{foreach(var stale in silverHost.Controls.OfType<ReportTextDialog>().Where(f=>f!=control).ToArray())stale.Close();foreach(Control c in silverHost.Controls)c.Visible=c==control;control.Visible=true;control.BringToFront();MarkSilverPage(key);}finally{silverSwitching=false;}}
        void ShowSilverAccounts(){if(silverAccounts==null)return;ShowSilverControl(silverAccounts,"accounts");RefreshSilverInspector();}
        void ShowSilverPage(Form form,string key)
        {
            Form existing;if(silverPages.TryGetValue(key,out existing)&&!existing.IsDisposed&&existing!=form){silverSwitching=true;try{existing.Close();}finally{silverSwitching=false;}}
            form.TopLevel=false;form.FormBorderStyle=FormBorderStyle.None;form.ShowInTaskbar=false;form.AutoSize=false;form.MinimumSize=Size.Empty;form.MaximumSize=Size.Empty;form.Dock=DockStyle.Fill;form.Margin=Padding.Empty;silverHost.Controls.Add(form);silverPages[key]=form;
            form.FormClosed+=(s,e)=>{Form active;if(silverPages.TryGetValue(key,out active)&&active==form)silverPages.Remove(key);if(!silverSwitching&&!IsDisposed&&!Disposing&&!appClosing&&silverPage==key)ShowSilverAccounts();};
            ShowSilverControl(form,key);form.Show();
        }
        void RefreshSilverInspector()
        {
            if(silverInspector==null||silverArranging)return;silverArranging=true;try{var row=grid.CurrentRow==null?null:grid.CurrentRow.Tag as CopyRow;silverInspector.Set(row);bool want=row!=null&&pageName==null&&body.Width>=Theme.S(960);if(silverInspector.Visible!=want)silverInspector.Visible=want;if(want&&grid.CurrentRow!=null&&!grid.CurrentRow.Selected)grid.CurrentRow.Selected=true;}finally{silverArranging=false;}
        }
        void ShowSilverInspector(CopyRow row){if(row==null)return;silverInspector.Set(row);RefreshSilverInspector();if(!silverInspector.Visible)OpenStudent(row);}
        void ShowSilverFolders()
        {
            Form cached;if(silverPages.TryGetValue("folders",out cached)&&!cached.IsDisposed){cached.Close();}
            var page=new Form{Text=Lang.T("پوشه‌ها","Folders"),BackColor=Theme.Surface,Font=Theme.Font};var list=new FlowLayoutPanel{Dock=DockStyle.Fill,AutoScroll=true,FlowDirection=FlowDirection.TopDown,WrapContents=false,Padding=Theme.Pad(28)};page.Controls.Add(list);list.Controls.Add(Theme.Label(page.Text,0,Theme.Title,Theme.Text));
            Action<string,string> folder=(key,title)=>{var button=new ModernButton(title,ButtonKind.Secondary,Glyph.Folder);button.MinimumSize=new Size(Theme.S(260),Theme.S(44));button.Margin=Theme.Pad(0,8);button.Click+=(s,e)=>{folderBar.Selected=key;ShowSilverAccounts();if(pageName!=null)CloseStudent();RefreshGrid(true);};list.Controls.Add(button);};folder(FolderBar.AllKey,FolderStore.AllTitle);folder(FolderBar.NoneKey,FolderStore.NoneTitle);foreach(var item in folders.All)folder("f:"+item.Id,item.Name+"  ·  "+Fa.N(folders.Count(item.Id,copies.Select(x=>x.Name))));var add=new ModernButton(Lang.T("پوشهٔ جدید","New folder"),(s,e)=>{NewFolder(null,false);page.Close();ShowSilverFolders();},ButtonKind.Primary,Glyph.Plus);list.Controls.Add(add);ShowSilverPage(page,"folders");
        }
        void ShowSilverSupport()
        {
            var page=new Form{Text=Lang.T("پشتیبانی","Support"),BackColor=Theme.Surface,Font=Theme.Font};var list=new FlowLayoutPanel{Dock=DockStyle.Fill,AutoScroll=true,FlowDirection=FlowDirection.TopDown,WrapContents=false,Padding=Theme.Pad(28)};page.Controls.Add(list);list.Controls.Add(Theme.Label(page.Text,0,Theme.Title,Theme.Text));
            Action<string,Action> add=(text,action)=>{var b=new ModernButton(text,(s,e)=>Guard(action)){Margin=Theme.Pad(0,8)};list.Controls.Add(b);};add(Lang.T("بررسی سیستم و عیب‌یابی","System check and diagnostics"),ShowReport);add(Lang.T("خروجی عیب‌یابی گزارش‌ها","Export report diagnostics"),ExportReportDiagnostics);add(Lang.T("راهنمای برنامه","Application help"),ShowHelp);ShowSilverPage(page,"support-home");MarkSilverPage("support");
        }
    }
}
