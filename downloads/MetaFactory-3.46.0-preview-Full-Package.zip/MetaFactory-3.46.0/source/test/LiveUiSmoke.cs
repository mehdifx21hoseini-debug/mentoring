using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using MTManager;
class LiveUiSmoke {
 static int checks;
 static void Check(bool ok,string text){if(!ok)throw new Exception(text);checks++;Console.WriteLine("PASS "+text);}
 static object Field(object o,string name){return o.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public).GetValue(o);}
 static void Put(object o,string name,object value){o.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public).SetValue(o,value);}
 static void Call(object o,string name,params object[] args){o.GetType().GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public).Invoke(o,args);}
 static object EmptyCandidates(Assembly app){Type t=typeof(List<>).MakeGenericType(app.GetType("MTManager.LiveMonitorCandidate"));object list=Activator.CreateInstance(t);return Expression.Lambda(typeof(Func<>).MakeGenericType(t),Expression.Constant(list,t)).Compile();}
 static object View(Assembly app,string copy,string name,string state,string balance,string history){var v=Activator.CreateInstance(app.GetType("MTManager.LiveMonitorView"));
  foreach(var pair in new[]{new[]{"CopyName",copy},new[]{"Name",name},new[]{"Login",copy=="MT5-01"?"20131967":"10750077"},new[]{"Platform",copy.StartsWith("MT5")?"MT5":"MT4"},new[]{"State",state},new[]{"Balance",balance},new[]{"Equity",balance=="—"?"—":"10,112.35 USD"},new[]{"Positions",balance=="—"?"—":"2"},new[]{"Floating",balance=="—"?"—":"112.35 USD"},new[]{"NoSl",balance=="—"?"—":"1"},new[]{"Today",balance=="—"?"—":"3 · 84.20 USD"},new[]{"Drawdown",balance=="—"?"—":"2.40%"},new[]{"Updated","10:24:35 · 1s"},new[]{"History",history},new[]{"Detail",Lang.En?"Floating P/L includes swap; commission excluded. Today's result uses the broker day.":"سود/زیان شناور شامل سواپ است؛ کمیسیون منظور نشده است. نتیجهٔ امروز با روز سرور محاسبه می‌شود."}})Put(v,pair[0],pair[1]);return v;}
 static void Pump(){for(int n=0;n<6;n++){Application.DoEvents();Thread.Sleep(30);}}
 [STAThread] static int Main(string[] args){try{
  Application.EnableVisualStyles();var app=typeof(Account).Assembly;app.GetType("MTManager.Theme").GetMethod("Init").Invoke(null,null);
  foreach(bool en in new[]{true,false}){Lang.En=en;AppPaths.DataDirOverride="/workspace/live-smoke-"+(en?"en":"fa");Directory.CreateDirectory(AppPaths.DataDirOverride);
   var target=LiveMonitorTarget.Create(new Instance{Name="MT5-01",Kind=Kind.MT5,Dir="/workspace/live-smoke-student"},new Account{Login="20131967",Server="WMMarkets-Demo",Trader="Milad Bahoo"});target.Guide="Saved instructions: use a NEW chart; load the supplied preset. Existing EAs remain unchanged.";LiveMonitorStore.Save(new[]{target});
   object candidates=EmptyCandidates(app);using(var form=(Form)Activator.CreateInstance(app.GetType("MTManager.LiveMonitorDialog"),BindingFlags.Instance|BindingFlags.NonPublic,null,new[]{(object)new Settings(),candidates,candidates},null)){
    form.StartPosition=FormStartPosition.Manual;form.Location=new Point(12,12);form.Show();Pump();((System.Windows.Forms.Timer)Field(form,"timer")).Stop();
    var grid=(DataGridView)Field(form,"grid");var enabled=(CheckBox)Field(form,"enabled");var detail=(TextBox)Field(form,"detail");
    Check(!enabled.Checked&&grid.Rows.Count==0,"live window opens disabled without old financial data");
    enabled.Checked=true;((System.Windows.Forms.Timer)Field(form,"timer")).Stop();Pump();
    Type rowsType=typeof(List<>).MakeGenericType(app.GetType("MTManager.LiveMonitorView"));IList rows=(IList)Activator.CreateInstance(rowsType);
    rows.Add(View(app,"MT5-01",en?"Milad Bahoo Sele Bani":"میلاد باهو سلی بانی",en?"Live · connected":"زنده · متصل","10,000.00 USD","History ready"));
    rows.Add(View(app,"MT4-07",en?"Javad Nojumi":"جواد نجومی",en?"Live · history updating":"زنده · تاریخچه در حال آماده‌سازی","10,000.00 USD","Synchronizing"));
    Put(rows[1], "Today", en ? "Not confirmed yet" : "هنوز تأیید نشده"); Put(rows[1], "Drawdown", "—");
    rows.Add(View(app,"MT5-03",en?"Mohammad Soleymani":"محمد سلیمانی",en?"Disconnected":"اتصال قطع است","—","—"));
    Call(form,"Apply",rows);Pump();Check(grid.Rows.Count==3,"live states render three independent account rows");
    var same=grid.Rows[0];grid.ClearSelection();grid.Rows[1].Selected=true;Call(form,"Apply",rows);Check(object.ReferenceEquals(same,grid.Rows[0])&&grid.Rows[1].Selected,"unchanged refresh preserves row objects and selection");
    ((Button)Field(form,"setupGuide")).PerformClick();Check(detail.Text.Contains("Saved instructions"),"saved attachment guide survives reopening monitor");Call(form,"Apply",rows);Check(detail.Text.Contains("Saved instructions"),"background row update does not overwrite preparation instructions");
    Put(Field(form,"controller"),"ready",rows);((Button)Field(form,"copySummary")).PerformClick();Check(Clipboard.ContainsText()&&Clipboard.GetText().Contains("20131967")&&Clipboard.GetText().Contains("84.20"),"copy live summary contains identity and financial summary");
    Check(grid.Top>=100&&grid.Bottom<=detail.Top+1&&detail.Bottom<=form.ClientSize.Height+1,"header grid and detail panels do not overlap");
    grid.ClearSelection();grid.Rows[0].Selected=true;Pump();
    using(var b=new Bitmap(form.Width,form.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(form.Location,Point.Empty,form.Size);b.Save("/workspace/MetaFactory-delivery/MetaFactory-3.46.0-live-"+(en?"en":"fa")+".png");}
    form.ClientSize=new Size(780,480);Pump();Check(grid.Height>30&&detail.Top>=grid.Bottom-1,"compact monitor retains a visible table and details");
    enabled.Checked=false;Check(grid.Rows.Count==0&&detail.Text.Length==0,"disabling immediately clears live rows and detail");
    form.Close();Pump();Check(!(bool)Field(Field(form,"controller"),"enabled"),"closing monitor disables controller");
   }
  }Console.WriteLine("LIVE UI PASS "+checks);return 0;
 }catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
