using System;using System.IO;using System.Text;using System.Linq;using System.Diagnostics;using System.Diagnostics.Eventing.Reader;using System.Collections.Generic;using System.Globalization;using System.Runtime.InteropServices;using System.Web.Script.Serialization;using System.Reflection;
[assembly:AssemblyTitle("MetaFactory Win32k Event Check")]
[assembly:AssemblyVersion("1.1.0.0")]
[assembly:AssemblyFileVersion("1.1.0.0")]
namespace MetaFactoryWin32kCheck
{
 public sealed class Row
 {
  public string Provider,TimeUtc,Description,DescriptionError;
  public int Id;public long? RecordId;public int? EventProcessId,EventThreadId;
 }
 public interface IReader:IDisposable{Row Next();}
 public sealed class WindowsReader:IReader
 {
  readonly EventLogReader reader;
  public WindowsReader(){reader=new EventLogReader(new EventLogQuery("System",PathType.LogName,"*[System[(EventID=243)]]"){ReverseDirection=true,TolerateQueryErrors=false});}
  public Row Next()
  {
   using(EventRecord e=reader.ReadEvent(TimeSpan.FromSeconds(2)))
   {
    if(e==null)return null;
    var row=new Row{Provider=e.ProviderName,Id=e.Id,RecordId=e.RecordId,TimeUtc=e.TimeCreated.HasValue?e.TimeCreated.Value.ToUniversalTime().ToString("o",CultureInfo.InvariantCulture):"unknown",EventProcessId=e.ProcessId,EventThreadId=e.ThreadId};
    // Fetch description only for the specific Windows provider/event under investigation.
    if(Collector.Relevant(row))try{string s=e.FormatDescription()??"";row.Description=s.Length<=2048?s:s.Substring(0,2048)+" [clipped]";}catch(Exception error){row.DescriptionError=error.GetType().Name;}
    return row;
   }
  }
  public void Dispose(){reader.Dispose();}
 }
 public enum AtomCategory { Other, MetaTraderName, MetaFactoryName, SandboxName, WinFormsName }
 public struct AtomReply { public bool HasName;public int Error;public AtomCategory Category; }
 public sealed class AtomResult
 {
  public int Scanned,NamedEntries,Unreadable,Capacity=16384;public bool Complete;
  public string ErrorType;
  public Dictionary<int,int> UnexpectedErrors=new Dictionary<int,int>();
  public Dictionary<string,int> KnownNameCategories=new Dictionary<string,int>();
  public string Method="Read-only GetClipboardFormatNameW enumeration C000-FFFF, as documented by Microsoft. No atom/format is created or deleted; clipboard contents are not read. Names discarded; only predefined category counts stored. Categories do not prove ownership or culprit. This is not free desktop heap.";
 }
 public static class AtomCensus
 {
  public static AtomResult Read(Func<int,AtomReply> lookup,int milliseconds=5000)
  {
   var r=new AtomResult();var clock=Stopwatch.StartNew();
   try
   {
    for(int id=0xC000;id<=0xFFFF&&clock.ElapsedMilliseconds<milliseconds;id++)
    {
     var value=lookup(id);r.Scanned++;
     if(value.HasName)
     {
      r.NamedEntries++;string category=value.Category.ToString();int count;r.KnownNameCategories.TryGetValue(category,out count);r.KnownNameCategories[category]=count+1;
     }
     else if(value.Error!=0&&value.Error!=6&&value.Error!=87)
     {r.Unreadable++;int count;r.UnexpectedErrors.TryGetValue(value.Error,out count);r.UnexpectedErrors[value.Error]=count+1;}
    }
   }
   catch(Exception e){r.ErrorType=e.GetType().Name;}
   r.Complete=r.Scanned==r.Capacity&&r.Unreadable==0&&r.ErrorType==null;return r;
  }
 }
 static class NativeAtoms
 {
  static readonly StringBuilder Buffer=new StringBuilder(256);
  [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern int GetClipboardFormatName(uint id,StringBuilder name,int capacity);
  [DllImport("kernel32.dll")]static extern void SetLastError(uint error);
  public static AtomReply Lookup(int id)
  {
   var name=Buffer;name.Clear();SetLastError(0);int n=GetClipboardFormatName((uint)id,name,name.Capacity);int error=n>0?0:Marshal.GetLastWin32Error();
   var value=new AtomReply{HasName=n>0,Error=error};
   if(n>0)
   {
    string text=name.ToString();
    if(text.IndexOf("MetaFactory",StringComparison.OrdinalIgnoreCase)>=0||text.IndexOf("MTManager",StringComparison.OrdinalIgnoreCase)>=0)value.Category=AtomCategory.MetaFactoryName;
    else if(text.IndexOf("MetaTrader",StringComparison.OrdinalIgnoreCase)>=0||text.IndexOf("MetaQuotes",StringComparison.OrdinalIgnoreCase)>=0)value.Category=AtomCategory.MetaTraderName;
    else if(text.IndexOf("Sandbox",StringComparison.OrdinalIgnoreCase)>=0||text.StartsWith("Sbie",StringComparison.OrdinalIgnoreCase))value.Category=AtomCategory.SandboxName;
    else if(text.StartsWith("WindowsForms",StringComparison.OrdinalIgnoreCase))value.Category=AtomCategory.WinFormsName;
   }
   return value;
  }
 }
 public sealed class Result
 {
  public string Schema="MF_WIN32K_EVENT_REPORT_1",Version="1.1.0",CapturedUtc,Status,ErrorType,HResult;
  public int? NativeError;
  public int Examined;public bool LimitReached,Completed;
  public AtomResult UserAtomCensus;
  public List<Row> Events=new List<Row>();
  public string Scope="Existing System-log Win32k event243 plus read-only user-atom census; no rerun/registry/process/window/network changes. At most256 matching-ID candidates/64Win32k events/10seconds; reads retained history, not just latest MetaFactory batch.";
  public string Interpretation="Presence must be checked against event time, process and session before attribution. Absence/limited access cannot rule out resource exhaustion. EventProcessId may identify the event writer, not the failing terminal; inspect the Windows description.";
 }
 public static class Collector
 {
  public static bool Relevant(Row r){return r!=null&&r.Id==243&&(string.Equals(r.Provider,"Win32k",StringComparison.OrdinalIgnoreCase)||string.Equals(r.Provider,"Microsoft-Windows-Win32k",StringComparison.OrdinalIgnoreCase));}
  public static Result Collect(Func<IReader> open)
  {
   var result=new Result{CapturedUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture)};var time=Stopwatch.StartNew();
   try
   {
    using(var reader=open())
    {
     while(result.Examined<256&&result.Events.Count<64&&time.Elapsed<TimeSpan.FromSeconds(10))
     {
      Row row=reader.Next();if(row==null){result.Completed=true;break;}result.Examined++;
      if(Relevant(row))result.Events.Add(row);
     }
    }
    result.LimitReached=!result.Completed;
    result.Status=result.Events.Count>0?"matching_events_found_check_time_and_session":"no_matching_event_in_available_scan_not_proof_of_absence";
   }
   catch(Exception error)
   {
    result.Status="event_log_read_failed_not_a_heap_diagnosis";result.ErrorType=error.GetType().Name;result.HResult="0x"+error.HResult.ToString("X8");
    var win=error as System.ComponentModel.Win32Exception;
    if(win!=null)result.NativeError=win.NativeErrorCode;

   }
   return result;
  }
  public static string Write(string directory,Result result)
  {
   Directory.CreateDirectory(directory);string path=Path.Combine(directory,"MetaFactory-Win32k-Events.txt"),previous=Path.Combine(directory,"MetaFactory-Win32k-Events-previous.txt");
   string content=new JavaScriptSerializer().Serialize(result)+"\r\n";
   if(Encoding.UTF8.GetByteCount(content)>256*1024)throw new IOException("Output exceeds diagnostic storage budget.");
   if(File.Exists(path))
   {
    if(!Owned(path)||File.Exists(previous)&&!Owned(previous))throw new IOException("Unknown file ownership; no file overwritten.");
    if(File.Exists(previous))File.Delete(previous);File.Move(path,previous);
   }
   File.WriteAllText(path,content,Encoding.UTF8);return path;
  }
  static bool Owned(string path){using(var f=new StreamReader(path,Encoding.UTF8,true)){char[] c=new char[256];int n=f.Read(c,0,c.Length);return new string(c,0,n).Contains("MF_WIN32K_EVENT_REPORT_1");}}
 }
 static class Program
 {
  [STAThread]static int Main()
  {
   try
   {
    if(Environment.OSVersion.Platform!=PlatformID.Win32NT)return 2;
    Result result=Collector.Collect(()=>new WindowsReader());
    result.UserAtomCensus=AtomCensus.Read(NativeAtoms.Lookup);
    try{Collector.Write(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),result);}
    catch{Collector.Write(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"MT Manager"),result);}
    return result.Status=="event_log_read_failed_not_a_heap_diagnosis"?1:0;
   }
   catch{return 3;}
  }
 }
}
