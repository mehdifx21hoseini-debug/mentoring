//+------------------------------------------------------------------+
//| MTManagerReport.mq5 - MT Manager                                  |
//| Reads the account's history once and writes it to a file, then   |
//| ends. Read-only: it never places, changes or closes an order, and |
//| imports no DLL. Run by MT Manager in its own report copy of       |
//| MetaTrader, with the investor (view-only) password.               |
//|                                                                  |
//| 1.21 (MetaFactory 3.34): trade-only export; no chart bars.         |
//| Previous 1.20 (MT Manager 3.21): the whole history is selected up to a     |
//| fixed far date (not up to the last price, which can be old); the  |
//| script waits until the history adds up to the account's balance   |
//| (H line); each position is built in one pass over its deals,      |
//| fees included, a part-closed position as its closed part; the     |
//| last trade of the whole history is written (L line).              |
//+------------------------------------------------------------------+
#property copyright "MT Manager"
#property version   "1.25"
#property description "Read-only history export for MT Manager"

input string FromDate = "";                    // first server day, yyyy.mm.dd
input string OutFile  = "MTManagerReport\\report.txt"; // under MQL5\Files

input string ExpectedLogin = "";
input string ExpectedServer = "";
input string RequestToken = "";
input bool ServeMode = false;
string WorkFrom, WorkLogin, WorkServer, WorkToken;
uint pulseStarted = 0, pulseLast = 0;
bool pulseWritten = false, selectionAnnounced = false;
bool SameText(string a, string b) { StringToLower(a); StringToLower(b); return a == b; }
bool ExpectedAccount()
{
   return (WorkLogin == "" || WorkLogin == IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN))) && (WorkServer == "" || SameText(WorkServer, AccountInfoString(ACCOUNT_SERVER)));
}

#define SCRIPT_VERSION "1.25"
// Every deal of the account is before this date.
#define FAR_DATE D'2100.01.01 00:00'

string N(double v) { return DoubleToString(v, 8); }
string T(datetime t) { return IntegerToString((long)t); }

void Line(int h, string s) { FileWriteString(h, s + "\r\n"); }

// A text as one field: no tab or line break in it.
string Clean(string s)
{
   string r = s;
   StringReplace(r, "\t", " ");
   StringReplace(r, "\r", " ");
   StringReplace(r, "\n", " ");
   return r;
}

// Bounded, request-matched progress only. This is never a report or proof that history is complete.
// A blocking native call (e.g. HistorySelect) also blocks this EA's timer; silence alone is not a hang verdict.
// Normal pulses are at most once per second; init/ready, first selection and completion are explicit milestones.
void Pulse(string stage, bool force = false)
{
   if(StringLen(WorkToken) != 32 || WorkLogin == "" || WorkServer == "") return;
   uint now = GetTickCount();
   if(!force && pulseWritten && now - pulseLast < 1000) return;
   string path = OutFile + ".pulse", tmp = path + ".part";
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) return;
   Line(h, "MTP\t1");
   Line(h, "Q\t" + WorkToken);
   Line(h, "A\t" + Clean(WorkLogin) + "\t" + Clean(WorkServer));
   Line(h, "S\t" + Clean(stage));
   Line(h, "T\t" + IntegerToString((long)TimeLocal()) + "\t" + IntegerToString((long)(now - pulseStarted)));
   Line(h, "C\t" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "\t" + Clean(AccountInfoString(ACCOUNT_SERVER)) + "\t" + (TerminalInfoInteger(TERMINAL_CONNECTED) ? "1" : "0"));
   Line(h, "END");
   FileClose(h);
   if(FileMove(tmp, 0, path, FILE_REWRITE)) { pulseLast = now; pulseWritten = true; }
}

// The server's clock less GMT, to the half hour, for the trading sessions. Anything that is not a whole half hour is left out.
string Offset()
{
   long d = (long)(TimeTradeServer() - TimeGMT());
   long r = (long)MathRound(d / 1800.0) * 1800;
   if(MathAbs(d - r) > 300 || MathAbs(r) > 14 * 3600) return "";
   return IntegerToString(r);
}

string Header() { return "MTR\t2\tMT5\t" + IntegerToString(TerminalInfoInteger(TERMINAL_BUILD)) + "\t" + SCRIPT_VERSION + "\r\nQ\t" + WorkToken; }

// Writes the file under a temporary name and renames it at the end: the program never reads half a file.
bool Finish(int h, string tmp)
{
   FileClose(h);
   FileDelete(OutFile);
   if(FileMove(tmp, 0, OutFile, FILE_REWRITE)) return true;
   Print("MTManagerReport: cannot finish ", OutFile);
   return false;
}

// Tells the program at once why nothing was read, instead of letting it wait.
void Fail(string why)
{
   Pulse("failed", true);
   Print("MTManagerReport: ", why);
   string tmp = OutFile + ".part";
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) return;
   Line(h, Header());
   Line(h, "ERR\t" + why);
   Finish(h, tmp);
}

// Where the script is, for the program: one line in a file beside the result ("start", "connected", "history 152", "bars EURUSD 2/5", "writing").
void Step(string what)
{
   int h = FileOpen(OutFile + ".step", FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) return;
   FileWriteString(h, what);
   FileClose(h);
}

// ------------------------------------------------------------------ the history adds up to the balance

double   sumAll = 0;      // every deal's profit, commission, fee and swap, credit left out
double   sumBonus = 0;    // the bonus deals among them (some servers keep bonus out of the balance)
int      dealCount = 0;
int      historyError = 0;
string   historyFailure = "";

bool AddUp()
{
   Pulse("history-select", !selectionAnnounced);
   selectionAnnounced = true;
   ResetLastError();
   if(!HistorySelect(0, FAR_DATE)) { historyError = GetLastError(); return false; }
   Pulse("history-selected");
   sumAll = 0; sumBonus = 0;
   dealCount = HistoryDealsTotal();
   for(int i = 0; i < dealCount; i++)
   {
      if(i % 256 == 0) Pulse("history-scan");
      ResetLastError();
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) { historyError = GetLastError(); return false; }
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(type == DEAL_TYPE_CREDIT) continue;
      double v = HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_COMMISSION) + HistoryDealGetDouble(d, DEAL_FEE) + HistoryDealGetDouble(d, DEAL_SWAP);
      sumAll += v;
      if(type == DEAL_TYPE_BONUS) sumBonus += v;
   }
   historyError = 0;
   return true;
}

bool AddsUp()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double tol = MathMax(0.02, MathAbs(balance) * 0.000001);
   return MathAbs(sumAll - balance) <= tol || MathAbs(sumAll - sumBonus - balance) <= tol;
}

// Waits until the terminal is connected and the whole history is there: it adds up to the balance and has stopped growing.
// A history that never adds up (the broker keeps only part of it) is taken once it has not grown for 15 seconds.
bool WaitForHistory()
{
   historyFailure = "";
   for(int k = 0; k < 120 && !IsStopped() && (!TerminalInfoInteger(TERMINAL_CONNECTED) || AccountInfoInteger(ACCOUNT_LOGIN) == 0 || !ExpectedAccount()); k++) { Pulse("await-account"); Sleep(500); }
   if(IsStopped() || !TerminalInfoInteger(TERMINAL_CONNECTED) || !ExpectedAccount()) { historyFailure = "not connected"; return false; }
   Step("connected");
   uint begun = GetTickCount(), still = GetTickCount();
   int last = -1; double lastSum = 0;
   uint failedSince = 0;
   while(!IsStopped() && GetTickCount() - begun < 90000)
   {
      if(!TerminalInfoInteger(TERMINAL_CONNECTED) || !ExpectedAccount()) { historyFailure = "history connection lost"; return false; }
      if(!AddUp())
      {
         // A failed selection is not an empty history. Preserve the error, retry briefly,
         // and restart the stability window only after a successful selection.
         if(failedSince == 0) failedSince = GetTickCount();
         historyFailure = "history read failed " + IntegerToString(historyError);
         Step("history-error " + IntegerToString(historyError));
         last = -1; still = GetTickCount();
         if(GetTickCount() - failedSince >= 15000) return false;
         Sleep(500);
         continue;
      }
      failedSince = 0;
      historyFailure = "";
      if(dealCount != last || MathAbs(sumAll - lastSum) > 0.0000001) { last = dealCount; lastSum = sumAll; still = GetTickCount(); Step("history " + IntegerToString(dealCount)); }
      uint quiet = GetTickCount() - still, waited = GetTickCount() - begun;
      bool empty = dealCount == 0 && AccountInfoDouble(ACCOUNT_BALANCE) == 0;
      if(AddsUp() && quiet >= 2000 && waited >= (uint)(empty ? 8000 : 3000)) return true;
      if(quiet >= 15000) return true;
      Pulse("history-stable-wait");
      Sleep(500);
   }
   if(historyFailure == "") historyFailure = "history not stable";
   return false;
}

// One bounded retry for an unreconciled complete-history selection. Never narrows the
// selection to WorkFrom, and never introduces another login or chart/bar download.
bool fullHistoryStable = true;
bool RetryFullHistory()
{
   fullHistoryStable = true;
   if(AddsUp()) return true;
   fullHistoryStable = false;
   Step("history-retry");
   uint begun = GetTickCount(), stable = begun;
   int last = -1; double lastSum = 0;
   bool selected = true;
   while(!IsStopped() && TerminalInfoInteger(TERMINAL_CONNECTED) && ExpectedAccount() && GetTickCount() - begun < 8000)
   {
      Pulse("history-stable-wait");
      selected = AddUp();
      if(!selected || dealCount != last || MathAbs(sumAll - lastSum) > 0.0000001)
      { last = dealCount; lastSum = sumAll; stable = GetTickCount(); }
      if(selected && AddsUp() && GetTickCount() - stable >= 2000 && GetTickCount() - begun >= 3000) { fullHistoryStable = true; return true; }
      Sleep(500);
   }
   if(IsStopped() || !TerminalInfoInteger(TERMINAL_CONNECTED) || !ExpectedAccount()) { historyFailure = "history connection lost"; return false; }
   return selected;
}

// ------------------------------------------------------------------ positions, one pass over the deals

long     pid[];           // position ids, sorted
string   pSym[];
bool     pBuy[], pIn[];
double   pInVol[], pInValue[], pOutVol[], pOutValue[], pCost[], pSwap[], pProfit[], pSlEntry[], pSlFinal[], pTp[];
datetime pOpen[], pClose[];
string   pComment[];

int Find(long id)
{
   int lo = 0, hi = ArraySize(pid) - 1;
   while(lo <= hi)
   {
      int mid = (lo + hi) / 2;
      if(pid[mid] == id) return mid;
      if(pid[mid] < id) lo = mid + 1; else hi = mid - 1;
   }
   return -1;
}

void Positions()
{
   Pulse("positions", true);
   // The ids of every position that has a buy or sell deal, once each.
   long all[];
   int n = 0;
   ArrayResize(all, dealCount);
   for(int i = 0; i < dealCount; i++)
   {
      if(i % 256 == 0) Pulse("positions");
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(type != DEAL_TYPE_BUY && type != DEAL_TYPE_SELL) continue;
      all[n++] = HistoryDealGetInteger(d, DEAL_POSITION_ID);
   }
   ArrayResize(all, n);
   if(n > 1) ArraySort(all);
   int u = 0;
   ArrayResize(pid, n);
   for(int i = 0; i < n; i++) if(u == 0 || all[i] != pid[u - 1]) pid[u++] = all[i];
   ArrayResize(pid, u);
   ArrayResize(pSym, u); ArrayResize(pBuy, u); ArrayResize(pIn, u); ArrayResize(pInVol, u); ArrayResize(pInValue, u); ArrayResize(pOutVol, u);
   ArrayResize(pOutValue, u); ArrayResize(pCost, u); ArrayResize(pSwap, u); ArrayResize(pProfit, u); ArrayResize(pSlEntry, u); ArrayResize(pSlFinal, u);
   ArrayResize(pTp, u); ArrayResize(pOpen, u); ArrayResize(pClose, u); ArrayResize(pComment, u);
   for(int k = 0; k < u; k++)
   {
      pSym[k] = ""; pBuy[k] = true; pIn[k] = false; pInVol[k] = 0; pInValue[k] = 0; pOutVol[k] = 0; pOutValue[k] = 0; pCost[k] = 0; pSwap[k] = 0;
      pProfit[k] = 0; pSlEntry[k] = 0; pSlFinal[k] = 0; pTp[k] = 0; pOpen[k] = 0; pClose[k] = 0; pComment[k] = "";
   }
   for(int i = 0; i < dealCount; i++)
   {
      if(i % 256 == 0) Pulse("positions");
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(type != DEAL_TYPE_BUY && type != DEAL_TYPE_SELL) continue;
      int k = Find(HistoryDealGetInteger(d, DEAL_POSITION_ID));
      if(k < 0) continue;
      long entry = HistoryDealGetInteger(d, DEAL_ENTRY);
      datetime t = (datetime)HistoryDealGetInteger(d, DEAL_TIME);
      double vol = HistoryDealGetDouble(d, DEAL_VOLUME), price = HistoryDealGetDouble(d, DEAL_PRICE);
      pCost[k] += HistoryDealGetDouble(d, DEAL_COMMISSION) + HistoryDealGetDouble(d, DEAL_FEE);
      pSwap[k] += HistoryDealGetDouble(d, DEAL_SWAP);
      pProfit[k] += HistoryDealGetDouble(d, DEAL_PROFIT);
      if(entry == DEAL_ENTRY_IN)
      {
         if(!pIn[k])
         {
            pIn[k] = true;
            pSym[k] = HistoryDealGetString(d, DEAL_SYMBOL);
            pBuy[k] = type == DEAL_TYPE_BUY;
            pOpen[k] = t;
            pComment[k] = Clean(HistoryDealGetString(d, DEAL_COMMENT));
            ulong order = (ulong)HistoryDealGetInteger(d, DEAL_ORDER);
            if(order > 0) pSlEntry[k] = HistoryOrderGetDouble(order, ORDER_SL);
         }
         pInVol[k] += vol;
         pInValue[k] += vol * price;
      }
      else
      {
         // DEAL_ENTRY_OUT, OUT_BY, and INOUT (a netting account turned round): the volume that left the position.
         if(pSym[k] == "") { pSym[k] = HistoryDealGetString(d, DEAL_SYMBOL); pBuy[k] = type == DEAL_TYPE_SELL; }
         // A netting account turned round (INOUT): only the part that closed the position left it.
         double closing = entry == DEAL_ENTRY_INOUT ? MathMax(0.0, MathMin(vol, pInVol[k] - pOutVol[k])) : vol;
         pOutVol[k] += closing;
         pOutValue[k] += closing * price;
         if(t > pClose[k]) pClose[k] = t;
         pSlFinal[k] = HistoryDealGetDouble(d, DEAL_SL);
         pTp[k] = HistoryDealGetDouble(d, DEAL_TP);
      }
   }
}

// Trade-only reports intentionally collect no chart bars or historical floating estimates.
datetime base;

// ------------------------------------------------------------------ the file

bool ExportReport()
{
   Pulse("start", true);
   Step("start");
   if(!WaitForHistory() || !ExpectedAccount()) { if(!IsStopped()) Fail(historyFailure == "" ? "not connected" : historyFailure); return false; }
   // The whole history is selected once more, now that it is all there; everything below reads this selection.
   if(!AddUp()) { if(!IsStopped()) Fail("history read failed " + IntegerToString(historyError)); return false; }
   if(!RetryFullHistory()) { if(!IsStopped()) Fail(historyFailure == "" ? "history read failed " + IntegerToString(historyError) : historyFailure); return false; }
   bool addsUp = AddsUp();
   double snapshotBalance = AccountInfoDouble(ACCOUNT_BALANCE);
   double curveTolerance = MathMax(0.02, MathAbs(snapshotBalance) * 0.000001);
   bool bonusExcluded = MathAbs(sumAll - snapshotBalance) > curveTolerance && MathAbs(sumAll - sumBonus - snapshotBalance) <= curveTolerance;
   Positions();

   // Now: the server's clock, and never before the last deal (the last price can be old after a quiet spell).
   datetime now = (datetime)MathMax(TimeTradeServer(), TimeCurrent());
   datetime lastTrade = 0, firstSeen = 0;
   for(int i = 0; i < dealCount; i++)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      datetime t = (datetime)HistoryDealGetInteger(d, DEAL_TIME);
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(t > now) now = t;
      if(firstSeen == 0 || t < firstSeen) firstSeen = t;
      if((type == DEAL_TYPE_BUY || type == DEAL_TYPE_SELL) && t > lastTrade) lastTrade = t;
   }
   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong p = PositionGetTicket(i);
      if(p == 0) continue;
      datetime t = (datetime)PositionGetInteger(POSITION_TIME);
      if(t > now) now = t;
      if(t > lastTrade) lastTrade = t;
   }
   base = StringToTime(WorkFrom);
   if(base <= 0) base = now - 7 * 86400;
   string tmp = OutFile + ".part";
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) { Print("MTManagerReport: cannot write ", tmp); return false; }
   Step("writing");
   Pulse("writing", true);
   Line(h, Header());
   Line(h, "A\t" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "\t" + Clean(AccountInfoString(ACCOUNT_SERVER)) + "\t" + AccountInfoString(ACCOUNT_CURRENCY) + "\t" +
           N(snapshotBalance) + "\t" + N(AccountInfoDouble(ACCOUNT_EQUITY)) + "\t" + T(now) + "\t" + T(base) + "\t" + Clean(AccountInfoString(ACCOUNT_COMPANY)) + "\t" +
           Offset() + "\t" + IntegerToString(AccountInfoInteger(ACCOUNT_LEVERAGE)) + "\t" + N(AccountInfoDouble(ACCOUNT_MARGIN)) + "\t" + N(AccountInfoDouble(ACCOUNT_MARGIN_FREE)) + "\t" +
           N(AccountInfoDouble(ACCOUNT_CREDIT)));
   // H: whether the history adds up to the balance, the sum, the balance and the number of deals.
   Line(h, "H\t" + (addsUp ? "1" : "0") + "\t" + N(sumAll) + "\t" + N(snapshotBalance) + "\t" + IntegerToString(dealCount));
   // L: the last trade of the whole history (a deal or a position opened) and the first record of the account.
   Line(h, "L\t" + T(lastTrade) + "\t" + T(firstSeen));
   int records = 0, curveCount = 0, curveSeen = 0;
   double curveSum = 0;
   bool curveScanOk = fullHistoryStable;

   // Money in and out since the first day: time, amount, comment, deal type (2 balance, 3 credit, 4 charge, 5 correction, 6 bonus...).
   for(int i = 0; i < dealCount; i++)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) { curveScanOk = false; continue; }
      curveSeen++;
      long type = 0, eventTimeMs = 0;
      double profit = 0, commission = 0, fee = 0, swap = 0;
      bool fieldsOk = HistoryDealGetInteger(d, DEAL_TYPE, type) && HistoryDealGetInteger(d, DEAL_TIME_MSC, eventTimeMs)
         && HistoryDealGetDouble(d, DEAL_PROFIT, profit) && HistoryDealGetDouble(d, DEAL_COMMISSION, commission)
         && HistoryDealGetDouble(d, DEAL_FEE, fee) && HistoryDealGetDouble(d, DEAL_SWAP, swap);
      double net = profit + commission + fee + swap;
      if(!fieldsOk || (long)d <= 0 || eventTimeMs <= 0 || !MathIsValidNumber(net)) curveScanOk = false;
      else if(type != DEAL_TYPE_CREDIT && !(bonusExcluded && type == DEAL_TYPE_BONUS))
      {
         // J includes opening commissions, partial closes and all cash adjustments,
         // including records before WorkFrom. Credit is outside account balance.
         Line(h, "J\t" + IntegerToString(eventTimeMs) + "\t" + IntegerToString(d) + "\t" + IntegerToString(type) + "\t" + N(net));
         curveCount++; records++; curveSum += net;
      }
      if(type == DEAL_TYPE_BUY || type == DEAL_TYPE_SELL) continue;
      if(type == DEAL_TYPE_BUY_CANCELED || type == DEAL_TYPE_SELL_CANCELED) continue;
      datetime t = (datetime)HistoryDealGetInteger(d, DEAL_TIME);
      if(t < base) continue;
      double amount = HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_COMMISSION) + HistoryDealGetDouble(d, DEAL_FEE) + HistoryDealGetDouble(d, DEAL_SWAP);
      Line(h, "B\t" + T(t) + "\t" + N(amount) + "\t" + Clean(HistoryDealGetString(d, DEAL_COMMENT)) + "\t" + IntegerToString(type));
      records++;
   }

   // Positions still open, by id: a position partly closed is written as its closed part (T) and its open rest (O).
   long openIds[];
   int positions = PositionsTotal();
   ArrayResize(openIds, positions);
   int openCount = 0;
   for(int i = 0; i < positions && openCount < ArraySize(openIds); i++)
   {
      ulong p = PositionGetTicket(i);
      if(p == 0) continue;
      openIds[openCount++] = PositionGetInteger(POSITION_IDENTIFIER);
   }
   ArrayResize(openIds, openCount);

   // Each position with volume closed since the first day: its entry, its exits, and the Stop Loss of the order that opened it.
   for(int k = 0; k < ArraySize(pid); k++)
   {
      if(k % 256 == 0) Pulse("writing");
      if(pOutVol[k] <= 0 || pClose[k] < base) continue;
      bool stillOpen = false;
      for(int i = 0; i < openCount && !stillOpen; i++) stillOpen = openIds[i] == pid[k];
      double volume = pOutVol[k];
      double openPrice = pInVol[k] > 0 ? pInValue[k] / pInVol[k] : 0;
      datetime open = pIn[k] ? pOpen[k] : pClose[k];
      Line(h, "T\t" + IntegerToString(pid[k]) + "\t" + pSym[k] + "\t" + (pBuy[k] ? "0" : "1") + "\t" + N(volume) + "\t" + T(open) + "\t" + N(openPrice) + "\t" +
              T(pClose[k]) + "\t" + N(pOutValue[k] / pOutVol[k]) + "\t" + N(pIn[k] ? pSlEntry[k] : -1) + "\t" + N(pSlFinal[k]) + "\t" + N(pTp[k]) + "\t" +
              N(pCost[k]) + "\t" + N(pSwap[k]) + "\t" + N(pProfit[k]) + "\t" + pComment[k] + (stillOpen ? " [part]" : ""));
      records++;
   }
   // Positions still open.
   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong p = PositionGetTicket(i);
      if(p == 0) continue;
      string symbol = PositionGetString(POSITION_SYMBOL);
      bool buy = PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY;
      double volume = PositionGetDouble(POSITION_VOLUME), openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      datetime open = (datetime)PositionGetInteger(POSITION_TIME);
      long id = PositionGetInteger(POSITION_IDENTIFIER);
      double sl = PositionGetDouble(POSITION_SL), tp = PositionGetDouble(POSITION_TP), profit = PositionGetDouble(POSITION_PROFIT), swap = PositionGetDouble(POSITION_SWAP);
      int k = Find(id);
      double slEntry = k >= 0 && pIn[k] ? pSlEntry[k] : -1;
      Line(h, "O\t" + IntegerToString(id) + "\t" + symbol + "\t" + (buy ? "0" : "1") + "\t" + N(volume) + "\t" + T(open) + "\t" + N(openPrice) + "\t" + N(sl) + "\t" + N(tp) + "\t" +
              N(profit) + "\t" + N(swap) + "\t" + N(slEntry) + "\t" + N(PositionGetDouble(POSITION_PRICE_CURRENT)) + "\t" +
              N(k >= 0 && pOutVol[k] <= 0 ? pCost[k] : 0));   // the entry's commission (a part-closed one's went with its closed part)
      records++;
   }
   Step("writing");
   curveScanOk = curveScanOk && curveSeen == dealCount && HistoryDealsTotal() == dealCount && !IsStopped() && TerminalInfoInteger(TERMINAL_CONNECTED) && ExpectedAccount()
      && MathIsValidNumber(curveSum) && MathIsValidNumber(snapshotBalance) && MathAbs(AccountInfoDouble(ACCOUNT_BALANCE) - snapshotBalance) <= curveTolerance;
   bool curveReconciled = curveScanOk && addsUp && MathAbs(curveSum - snapshotBalance) <= curveTolerance;
   // JC v1: J count, sum, snapshot balance, reconciled, scan OK, all-history requested, bonus excluded.
   // AddUp always uses HistorySelect(0,FAR_DATE); a successful selection is required above.
   Line(h, "JC\t1\t" + IntegerToString(curveCount) + "\t" + N(curveSum) + "\t" + N(snapshotBalance) + "\t" + (curveReconciled ? "1" : "0")
      + "\t" + (curveScanOk ? "1" : "0") + "\t1\t" + (bonusExcluded ? "1" : "0"));
   Line(h, "M\ttrades-only");
   Line(h, "END\t" + IntegerToString(records));
   if(IsStopped() || !ExpectedAccount()) { FileClose(h); FileDelete(tmp); return false; }
   bool finished = Finish(h, tmp);
   Pulse(finished ? "done" : "write-failed", true);
   return finished;
}

// Durable per-request command: account-change reinitialization must not consume unfinished work.
string lastHandledToken = "";
bool CompletedRequest(string token)
{
   if(!FileIsExist(OutFile)) return false;
   int h = FileOpen(OutFile, FILE_READ | FILE_TXT | FILE_UNICODE | FILE_SHARE_READ | FILE_SHARE_WRITE);
   if(h == INVALID_HANDLE) return false;
   string header = FileReadString(h), proof = FileReadString(h);
   FileClose(h);
   return StringFind(header, "MTR\t2\tMT5\t") == 0 && proof == "Q\t" + token;
}
bool ReadCommand()
{
   string file = "MTManagerReport\\request.txt";
   if(!FileIsExist(file)) return false;
   int h = FileOpen(file, FILE_READ | FILE_TXT | FILE_UNICODE | FILE_SHARE_READ | FILE_SHARE_WRITE);
   if(h == INVALID_HANDLE) return false;
   string token = FileReadString(h), login = FileReadString(h), server = FileReadString(h), from = FileReadString(h);
   FileClose(h);
   if(StringLen(token) != 32 || StringLen(login) == 0 || StringLen(server) == 0 || StringLen(from) == 0) return false;
   if(token != WorkToken) { pulseStarted = GetTickCount(); pulseWritten = false; selectionAnnounced = false; }
   WorkToken = token; WorkLogin = login; WorkServer = server; WorkFrom = from;
   return true;
}
bool LoadRequest()
{
   if(!ReadCommand() || WorkToken == lastHandledToken) return false;
   if(CompletedRequest(WorkToken)) { lastHandledToken = WorkToken; return false; }
   Pulse("await-account");
   return !IsStopped() && TerminalInfoInteger(TERMINAL_CONNECTED) && ExpectedAccount();
}
int OnInit()
{
   Print("MTManagerReport lifecycle: OnInit, build ", TerminalInfoInteger(TERMINAL_BUILD),
         ", chart ", _Symbol, ", period ", (int)_Period, ", data ", TerminalInfoString(TERMINAL_DATA_PATH), ", output ", OutFile);
   lastHandledToken = "";
   if(ReadCommand()) Pulse("init", true);
   ResetLastError();
   if(!EventSetMillisecondTimer(100)) { Print("MTManagerReport lifecycle: timer failed, error ", GetLastError()); Pulse("timer-failed", true); return INIT_FAILED; }
   Step("ready");
   Pulse("ready", true);
   return INIT_SUCCEEDED;
}
void OnDeinit(const int reason) { Print("MTManagerReport lifecycle: OnDeinit, reason ", reason); Pulse("deinit " + IntegerToString(reason), true); EventKillTimer(); }
void OnTimer()
{
   // The command is authoritative even when a broker build does not load ExpertParameters from the preset.
   if(!LoadRequest()) return;
   if(ExportReport()) lastHandledToken = WorkToken;
}
