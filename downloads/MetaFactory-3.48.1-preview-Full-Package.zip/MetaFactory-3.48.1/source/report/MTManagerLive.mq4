// MetaFactory Live 1.00 - read-only observer on a dedicated, user-approved chart.
// Never sends, modifies or closes trades, switches accounts, or replaces another EA.
// Timer snapshots are bounded; full history is rebuilt only after changes/bootstrap.
// HistorySelect can block the terminal API: no heartbeat guarantee during that call.
#property strict
#property copyright "MetaFactory"
#property version "1.03"
input string SessionToken = "";
input string ExpectedLogin = "";
input string ExpectedServer = "";
input string FromDate = "";
string WorkToken, WorkLogin, WorkServer, WorkFrom, OutFile, rootPath, runId;
long sequence = 0, revision = 0, exportRevision = 0;
bool sessionOwned=false;
string ownerKey="",beatKey="";
double ownerId=0;
uint leasePulseAt=0;
const int LeaseSeconds=30;
string BeatName(double id){return "MF.LiveBeat."+WorkToken+"."+DoubleToString(id,0);}
bool RecentOwner(double id)
{
   string key=BeatName(id);if(!GlobalVariableCheck(key))return false;
   double age=(double)TimeLocal()-GlobalVariableGet(key);
   return age>=-5 && age<=LeaseSeconds;
}
bool RefreshLease()
{
   if(!sessionOwned || !GlobalVariableCheck(ownerKey) || GlobalVariableGet(ownerKey)!=ownerId){sessionOwned=false;return false;}
   if(GlobalVariableSet(beatKey,(double)TimeLocal())==0){sessionOwned=false;return false;}
   leasePulseAt=GetTickCount();
   if(GlobalVariableGet(ownerKey)!=ownerId){sessionOwned=false;return false;}
   return true;
}
bool AcquireLease()
{
   sessionOwned=false;
   ownerKey="MF.LiveOwner."+WorkToken;
   long chart=ChartID()%4503599627370495;if(chart<0)chart=-chart;ownerId=(double)(chart+1);
   beatKey=BeatName(ownerId);
   // Temp creation never overwrites an existing lease. Claims use compare-and-swap.
   GlobalVariableTemp(ownerKey);GlobalVariableTemp(beatKey);
   if(!GlobalVariableCheck(ownerKey) || !GlobalVariableCheck(beatKey))return InitProblem("lease-create",GetLastError());
   double previous=GlobalVariableGet(ownerKey);
   if(previous!=0 && previous!=ownerId && RecentOwner(previous))return InitProblem("observer-already-active");
   if(GlobalVariableSet(beatKey,(double)TimeLocal())==0)return InitProblem("lease-heartbeat",GetLastError());
   if(!GlobalVariableSetOnCondition(ownerKey,ownerId,previous))return InitProblem("lease-claim-retry",GetLastError());
   // If the prior owner renewed during our claim, return the lease before publishing anything.
   if(previous!=0 && previous!=ownerId && RecentOwner(previous))
   {GlobalVariableSetOnCondition(ownerKey,previous,ownerId);return InitProblem("observer-renewed-during-claim");}
   sessionOwned=true;return RefreshLease();
}

uint bootTick = 0, lastPoll = 0, stableSince = 0, lastHistoryCheck = 0, recoveryStarted = 0, reconcileInterval = 60000;
bool backedOff = false;
string previousLightSignal = "";
bool dirty = true, wasConnected = false, writeOk = true, exportTrusted = false;
string liveState = "bootstrap", stableSignature = "", exportedSignature = "", previousOpenKey = "", previousDay = "";
uint historyHash1 = 2166136261, historyHash2 = 5381;
string N(double value) { return DoubleToString(value, 8); }
string T(datetime value) { return IntegerToString((long)value); }
string Clean(string value) { StringReplace(value,"\t"," "); StringReplace(value,"\r"," "); StringReplace(value,"\n"," "); return value; }
bool SameText(string a, string b) { StringToLower(a); StringToLower(b); return a == b; }
void Line(int h, string value)
{
   Pulse("write");
   if(!sessionOwned){writeOk=false;return;}
   if(!writeOk)return;
   if(FileTell(h)+(ulong)((StringLen(value)+2)*2)>67108864){writeOk=false;return;}
   if(FileWriteString(h,value+"\r\n")==0)writeOk=false;
}
void Step(string ignored) {}
void Pulse(string ignored, bool force = false) { if(sessionOwned && (force || GetTickCount()-leasePulseAt>=1000) && !RefreshLease())writeOk=false; }
void ReportState(string ignored, bool force = false) {}
void HashReset() { historyHash1 = 2166136261; historyHash2 = 5381; }
void HashText(string value)
{
   Pulse("hash");
   for(int j=0;j<StringLen(value);j++) { uint c=(uint)StringGetCharacter(value,j); historyHash1=(historyHash1^c)*16777619; historyHash2=historyHash2*33+c; }
   historyHash1=(historyHash1^10)*16777619; historyHash2=historyHash2*33+10;
}
string initProblem="";
uint retryInitAt=0;
bool InitProblem(string stage,int error=0)
{
   string message=stage+" error="+IntegerToString(error);
   if(message!=initProblem){Print("MetaFactory Live init: ",message);initProblem=message;}
   FolderCreate("MetaFactoryLive");
   int h=FileOpen("MetaFactoryLive\\init-status.txt",FILE_WRITE|FILE_TXT|FILE_UNICODE|FILE_SHARE_READ);
   if(h!=INVALID_HANDLE){FileWriteString(h,"MLINIT\t1\r\n"+T(TimeGMT())+"\r\n"+message+"\r\n");FileClose(h);}
   return false;
}
bool ValidToken()
{
   if(StringLen(WorkToken)!=32 || StringLen(WorkLogin)==0 || StringLen(WorkServer)==0 || StringLen(WorkServer)>256)return false;
   for(int i=0;i<32;i++){ushort c=StringGetCharacter(WorkToken,i);if(!((c>='0'&&c<='9')||(c>='a'&&c<='f')||(c>='A'&&c<='F')))return false;}
   for(int i=0;i<StringLen(WorkLogin);i++){ushort c=StringGetCharacter(WorkLogin,i);if(c<'0'||c>'9')return false;}
   return StringToInteger(WorkLogin)>0 && Clean(WorkServer)==WorkServer;
}
bool ResolveSession()
{
   WorkToken=SessionToken;WorkLogin=ExpectedLogin;WorkServer=ExpectedServer;WorkFrom=FromDate;
   // Never replace partially specified or invalid explicit inputs with another account's binding.
   if(WorkToken=="" && WorkLogin=="" && WorkServer=="")
   {
      ResetLastError();
      int h=FileOpen("MetaFactoryLive\\bootstrap.txt",FILE_READ|FILE_TXT|FILE_UNICODE|FILE_SHARE_READ);
      if(h==INVALID_HANDLE)return InitProblem("bootstrap-open",GetLastError());
      if(FileSize(h)>2048){FileClose(h);return InitProblem("bootstrap-size");}
      string magic=FileReadString(h);
      WorkToken=FileReadString(h);WorkLogin=FileReadString(h);WorkServer=FileReadString(h);
      string extra="";while(!FileIsEnding(h)){string line=FileReadString(h);if(line!="")extra=line;}
      FileClose(h);
      if(magic!="MLBOOT\t1" || extra!="")return InitProblem("bootstrap-format");
   }
   if(!ValidToken())return InitProblem("session-inputs-invalid");
   StringToLower(WorkToken);return true;
}
bool ExpectedAccount() { return WorkLogin==IntegerToString(Login()) && SameText(WorkServer,Server()); }
string Header()
{
   return "MTR\t2\t"+Platform()+"\t"+IntegerToString(TerminalInfoInteger(TERMINAL_BUILD))+"\t"+ReportVersion()+"\r\nQ\t"+WorkToken
      +"\r\nLIVE\t1\t"+WorkToken+"\t"+runId+"\t"+IntegerToString(exportRevision);
}
bool Finish(int h, string tmp)
{
   if(FileSize(h)>67108864) writeOk=false;
   FileClose(h);
   if(!writeOk) { FileDelete(tmp); return false; }
   if(!RefreshLease()){FileDelete(tmp);return false;}
   return FileMove(tmp,0,OutFile,FILE_REWRITE);
}
string Offset()
{
   long d=(long)(ServerNow()-TimeGMT()), r=(long)MathRound(d/1800.0)*1800;
   return MathAbs(d-r)>300 || MathAbs(r)>14*3600 ? "" : IntegerToString(r);
}
datetime base;

// Complete current positions only. Pending orders are intentionally not positions.
// The key excludes changing market prices/profit, so ticks never trigger full history.

#import "user32.dll"
int PostMessageW(int hWnd,int Msg,int wParam,int lParam);
int GetAncestor(int hWnd,int flags);
#import
string Platform(){return "MT4";} string ReportVersion(){return "1.23";}
long Login(){return AccountNumber();} string Server(){return AccountServer();}
bool Connected(){return IsConnected();} double Balance(){return AccountBalance();}
datetime ServerNow(){return TimeCurrent();}
bool posted=false, historyScanOk=false;
double sumAll=0; int histCount=0;
void AskAllHistory()
{
   if(!IsDllsAllowed()) return;
   int chart=(int)ChartGetInteger(0,CHART_WINDOW_HANDLE);
   if(chart==0) chart=WindowHandle(Symbol(),Period());
   if(chart==0) return;
   int window=GetAncestor(chart,2);
   if(window!=0) posted=PostMessageW(window,0x0111,33058,0)!=0 || posted;
}
void AddUp()
{
   HashReset(); sumAll=0; historyScanOk=true; histCount=OrdersHistoryTotal();
   for(int i=0;i<histCount;i++)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_HISTORY)){historyScanOk=false;continue;}
      int kind=OrderType();
      if(kind==OP_BUY || kind==OP_SELL) sumAll+=OrderProfit()+OrderCommission()+OrderSwap();
      else if(kind==6) sumAll+=OrderProfit();
      HashText(IntegerToString(OrderTicket())+"|"+IntegerToString(kind)+"|"+OrderSymbol()+"|"+T(OrderOpenTime())+"|"+T(OrderCloseTime())+"|"+N(OrderLots())+"|"+N(OrderOpenPrice())+"|"+N(OrderClosePrice())+"|"+N(OrderProfit())+"|"+N(OrderCommission())+"|"+N(OrderSwap())+"|"+N(OrderStopLoss())+"|"+N(OrderTakeProfit())+"|"+OrderComment());
   }
   historyScanOk=historyScanOk && histCount==OrdersHistoryTotal() && MathIsValidNumber(sumAll);
}
bool AddsUp(){return MathAbs(sumAll-Balance())<=MathMax(0.02,MathAbs(Balance())*0.000001);}
bool ScanHistory(){if(!posted)AskAllHistory();AddUp();return historyScanOk;}
int HistoryCount(){return OrdersHistoryTotal();}
int ScannedCount(){return histCount;}
bool HistoryTrusted(){return historyScanOk && posted && AddsUp();}
bool OpenLines(string &rows[],string &key)
{
   ArrayResize(rows,0); key=""; int total=OrdersTotal();
   if(total>10000) return false;
   for(int i=0;i<total;i++)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES)) return false;
      int kind=OrderType();
      key+=IntegerToString(OrderTicket())+":"+IntegerToString(kind)+":"+N(OrderLots())+":"+N(OrderOpenPrice())+":"+N(OrderStopLoss())+":"+N(OrderTakeProfit())+":"+N(OrderCommission())+":"+N(OrderSwap())+";";
      if(kind!=OP_BUY && kind!=OP_SELL) continue;
      if(OrderTicket()<=0 || !MathIsValidNumber(OrderProfit()+OrderSwap()+OrderCommission())) return false;
      int n=ArraySize(rows); ArrayResize(rows,n+1);
      rows[n]="O\t"+IntegerToString(OrderTicket())+"\t"+Clean(OrderSymbol())+"\t"+(kind==OP_BUY?"0":"1")+"\t"+N(OrderLots())+"\t"+T(OrderOpenTime())+"\t"+N(OrderOpenPrice())+"\t"+N(OrderStopLoss())+"\t"+N(OrderTakeProfit())+"\t"+N(OrderProfit())+"\t"+N(OrderSwap())+"\t-1\t"+N(OrderClosePrice())+"\t"+N(OrderCommission());
   }
   return total==OrdersTotal();
}
string Currency(){return AccountCurrency();}
double Equity(){return AccountEquity();} double Margin(){return AccountMargin();}
double FreeMargin(){return AccountFreeMargin();} double Credit(){return AccountCredit();}
// Runs only for a changed baseline, never on ordinary one-second price snapshots.
// Verify the source again before publication so same-count broker corrections cannot
// combine an older position reconstruction with a newer balance chronology.
bool ValidateExport(uint expectedHash1,uint expectedHash2,int expectedCount,double expectedSum,double expectedBalance)
{
   if(!ExpectedAccount() || !Connected() || IsStopped() || !ScanHistory())return false;
   string rows[],key="";
   double tolerance=MathMax(0.02,MathAbs(expectedBalance)*0.000001);
   return historyHash1==expectedHash1 && historyHash2==expectedHash2 && ScannedCount()==expectedCount
      && MathAbs(sumAll-expectedSum)<0.0000001 && MathAbs(Balance()-expectedBalance)<=tolerance
      && HistoryTrusted() && OpenLines(rows,key) && key==previousOpenKey
      && ExpectedAccount() && Connected() && !IsStopped();
}

bool ExportReport()
{
   uint sourceHash1=historyHash1,sourceHash2=historyHash2;
   int sourceCount=ScannedCount();double sourceSum=sumAll;
   bool fullHistoryStable=true;
   bool addsUp = historyScanOk && AddsUp();
   double snapshotBalance = AccountBalance();

   // Now: the server's clock, never before the last record (the last price can be old after a quiet spell).
   datetime now = TimeCurrent();
   datetime lastTrade = 0, firstSeen = 0;
   for(int i = 0; i < histCount; i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      int type = OrderType();
      datetime o = OrderOpenTime(), c = OrderCloseTime();
      if(c > now) now = c;
      if(o > now) now = o;
      if(type == OP_BUY || type == OP_SELL || type == 6)
         if(firstSeen == 0 || o < firstSeen) firstSeen = o;
      if((type == OP_BUY || type == OP_SELL) && c > lastTrade) lastTrade = c;
   }
   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      int type = OrderType();
      datetime o = OrderOpenTime();
      if(o > now) now = o;
      if((type == OP_BUY || type == OP_SELL) && o > lastTrade) lastTrade = o;
   }
   base = StrToTime(WorkFrom);
   if(base <= 0) base = now - 7 * 86400;
   string tmp = OutFile + "."+runId+".part";
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) { Print("MTManagerReport: cannot write ", tmp); return false; }
   Step("writing");
   ReportState("writing", true);
   Line(h, Header());
   Line(h, "A\t" + IntegerToString(AccountNumber()) + "\t" + Clean(AccountServer()) + "\t" + AccountCurrency() + "\t" + N(snapshotBalance) + "\t" + N(AccountEquity()) + "\t" +
           T(now) + "\t" + T(base) + "\t" + Clean(AccountCompany()) + "\t" + Offset() + "\t" + IntegerToString(AccountLeverage()) + "\t" + N(AccountMargin()) + "\t" +
           N(AccountFreeMargin()) + "\t" + N(AccountCredit()));
   // H: whether the history adds up to the balance, the sum, the balance, the number of history records, and whether "All History" was asked for.
   Line(h, "H\t" + (addsUp ? "1" : "0") + "\t" + N(sumAll) + "\t" + N(snapshotBalance) + "\t" + IntegerToString(histCount) + "\t" + (posted ? "1" : "0"));
   // L: the last trade of the whole history (closed, or an open position's entry) and the first record of the account.
   Line(h, "L\t" + T(lastTrade) + "\t" + T(firstSeen));
   int records = 0, curveCount = 0, curveSeen = 0;
   double curveSum = 0;
   bool curveScanOk = historyScanOk && fullHistoryStable;
   for(int i = 0; i < histCount; i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) { curveScanOk = false; continue; }
      curveSeen++;
      int type = OrderType();
      // J is compact ALL-history balance chronology, independent of WorkFrom/T/B filtering.
      // MT4 credit (7) and canceled pending orders do not change account balance.
      if(type == OP_BUY || type == OP_SELL || type == 6)
      {
         datetime eventTime = type == 6 ? OrderOpenTime() : OrderCloseTime();
         double net = type == 6 ? OrderProfit() : OrderProfit() + OrderCommission() + OrderSwap();
         if(eventTime <= 0 || OrderTicket() <= 0 || !MathIsValidNumber(net)) curveScanOk = false;
         else
         {
            Line(h, "J\t" + IntegerToString((long)eventTime * 1000) + "\t" + IntegerToString(OrderTicket()) + "\t" + IntegerToString(type == 6 ? 2 : type) + "\t" + N(net));
            curveCount++; records++; curveSum += net;
         }
      }
      // Money in and out: time, amount, comment, kind (2 balance, 3 credit: as MT5 numbers them).
      if(type == 6 || type == 7)
      {
         if(OrderOpenTime() < base) continue;
         Line(h, "B\t" + T(OrderOpenTime()) + "\t" + N(OrderProfit()) + "\t" + Clean(OrderComment()) + "\t" + (type == 6 ? "2" : "3"));
         records++;
         continue;
      }
      if(type != OP_BUY && type != OP_SELL) continue;
      if(OrderCloseTime() < base) continue;
      Line(h, "T\t" + IntegerToString(OrderTicket()) + "\t" + OrderSymbol() + "\t" + (type == OP_BUY ? "0" : "1") + "\t" + N(OrderLots()) + "\t" + T(OrderOpenTime()) + "\t" +
              N(OrderOpenPrice()) + "\t" + T(OrderCloseTime()) + "\t" + N(OrderClosePrice()) + "\t-1\t" + N(OrderStopLoss()) + "\t" + N(OrderTakeProfit()) + "\t" +
              N(OrderCommission()) + "\t" + N(OrderSwap()) + "\t" + N(OrderProfit()) + "\t" + Clean(OrderComment()));
      records++;
   }
   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      int type = OrderType();
      if(type != OP_BUY && type != OP_SELL) continue;
      Line(h, "O\t" + IntegerToString(OrderTicket()) + "\t" + OrderSymbol() + "\t" + (type == OP_BUY ? "0" : "1") + "\t" + N(OrderLots()) + "\t" + T(OrderOpenTime()) + "\t" +
              N(OrderOpenPrice()) + "\t" + N(OrderStopLoss()) + "\t" + N(OrderTakeProfit()) + "\t" + N(OrderProfit()) + "\t" + N(OrderSwap()) + "\t-1\t" +
              N(OrderClosePrice()) + "\t" + N(OrderCommission()));
      records++;
   }
   Step("writing");
   double curveTolerance = MathMax(0.02, MathAbs(snapshotBalance) * 0.000001);
   curveScanOk = curveScanOk && curveSeen == histCount && OrdersHistoryTotal() == histCount && !IsStopped() && IsConnected() && ExpectedAccount()
      && MathIsValidNumber(curveSum) && MathIsValidNumber(snapshotBalance) && MathAbs(AccountBalance() - snapshotBalance) <= curveTolerance;
   bool curveReconciled = curveScanOk && addsUp && MathAbs(curveSum - snapshotBalance) <= curveTolerance;
   // JC v1: J count, sum, snapshot balance, reconciled, scan OK, all-history requested, bonus excluded.
   Line(h, "JC\t1\t" + IntegerToString(curveCount) + "\t" + N(curveSum) + "\t" + N(snapshotBalance) + "\t" + (curveReconciled ? "1" : "0")
      + "\t" + (curveScanOk ? "1" : "0") + "\t" + (posted ? "1" : "0") + "\t0");
   Line(h, "M\ttrades-only");
   Line(h, "END\t" + IntegerToString(records));
   if(IsStopped() || !ExpectedAccount()) { FileClose(h); FileDelete(tmp); return false; }
   exportTrusted=curveReconciled && posted;
   if(!exportTrusted || !writeOk || !ValidateExport(sourceHash1,sourceHash2,sourceCount,sourceSum,snapshotBalance)){FileClose(h);FileDelete(tmp);return false;}
   bool finished = Finish(h, tmp);
   return finished;
}

int observedCount=-1;
double observedBalance=0,observedCredit=0;
bool WriteSnapshot(string forcedState="")
{
   if(!RefreshLease())return false;
   long snapshotLogin=Login();string snapshotServer=Server();
   bool identity=ExpectedAccount(), connected=Connected()&&identity;
   string state=forcedState!=""?forcedState:(!identity?"identity-mismatch":(!connected?"disconnected":liveState));
   string rows[],key="";
   bool readOk=!connected || OpenLines(rows,key);
   if(connected && readOk && forcedState=="" && state=="ready" && (dirty || key!=previousOpenKey || HistoryCount()!=observedCount || Balance()!=observedBalance || Credit()!=observedCredit))
   {dirty=true;liveState="history-pending";state=liveState;}
   double balance=identity?Balance():0,equity=identity?Equity():0,margin=identity?Margin():0,free=identity?FreeMargin():0,credit=identity?Credit():0;
   if(!readOk || !MathIsValidNumber(balance+equity+margin+free+credit)){ArrayResize(rows,0);state="error";connected=false;balance=0;equity=0;margin=0;free=0;credit=0;}
   long estimatedBytes=2048;
   for(int i=0;i<ArraySize(rows);i++)estimatedBytes+=(StringLen(rows[i])+2)*2;
   if(estimatedBytes>2097152){ArrayResize(rows,0);state="error";connected=false;}
   if(Login()!=snapshotLogin || Server()!=snapshotServer || (identity && !ExpectedAccount()))return false;
   string path=rootPath+"\\snapshot.txt",tmp=path+"."+runId+".part";
   ResetLastError();
   int h=FileOpen(tmp,FILE_WRITE|FILE_TXT|FILE_UNICODE);if(h==INVALID_HANDLE)return InitProblem("snapshot-open",GetLastError());
   writeOk=true;
   Line(h,"MLIVE\t1\t"+Platform());Line(h,"Q\t"+WorkToken);
   Line(h,"R\t"+runId+"\t"+IntegerToString(++sequence)+"\t"+T(TimeGMT()));
   Line(h,"A\t"+IntegerToString(Login())+"\t"+Clean(Server())+"\t"+Clean(identity?Currency():""));
   Line(h,"S\t"+(connected?"1":"0")+"\t"+state);
   Line(h,"V\t"+N(balance)+"\t"+N(equity)+"\t"+N(margin)+"\t"+N(free)+"\t"+N(credit));
   Line(h,"H\t"+IntegerToString(revision)+"\t"+IntegerToString(revision%2));
   for(int i=0;i<ArraySize(rows);i++)Line(h,rows[i]);
   Line(h,"END\t"+IntegerToString(ArraySize(rows)));FileClose(h);
   if(!writeOk || Login()!=snapshotLogin || Server()!=snapshotServer || (connected && !Connected()) || (identity && !ExpectedAccount())){FileDelete(tmp);return false;}
   if(!RefreshLease()){FileDelete(tmp);return false;}
   ResetLastError();
   if(!FileMove(tmp,0,path,FILE_REWRITE)){int error=GetLastError();FileDelete(tmp);return InitProblem("snapshot-publish",error);}
   return true;
}
void PollHistory()
{
   uint tick=GetTickCount();
   if(recoveryStarted!=0 && tick-recoveryStarted>=60000)backedOff=true;
   if(lastPoll!=0 && tick-lastPoll<(uint)(backedOff?30000:2000))return;
   lastPoll=tick;
   if(!ExpectedAccount() || !Connected())return;
   if(recoveryStarted==0)recoveryStarted=tick;
   bool scanned=ScanHistory();lastHistoryCheck=GetTickCount();
   if(!scanned || !Connected() || !ExpectedAccount()) {stableSignature="";stableSince=GetTickCount();liveState="history-unconfirmed";dirty=true;return;}
   string signature=IntegerToString(ScannedCount())+":"+N(sumAll)+":"+N(Balance())+":"+IntegerToString((long)historyHash1)+":"+IntegerToString((long)historyHash2)+":"+previousOpenKey+":"+previousDay;
   observedCount=HistoryCount();observedBalance=Balance();observedCredit=Credit();
   if(signature!=stableSignature){stableSignature=signature;stableSince=GetTickCount();liveState="history-pending";dirty=true;return;}
   if(!HistoryTrusted()){liveState="history-unconfirmed";dirty=true;if(GetTickCount()-recoveryStarted>=30000)backedOff=true;return;}
   if(GetTickCount()-stableSince<2000 || GetTickCount()-bootTick<(uint)(ScannedCount()==0?8000:3000)){liveState="history-pending";dirty=true;return;}
   if(signature==exportedSignature && revision>0){dirty=false;backedOff=false;recoveryStarted=0;liveState="ready";return;}
   exportRevision=revision+1;
   OutFile=rootPath+"\\history-"+IntegerToString(exportRevision%2)+".txt";
   writeOk=true;exportTrusted=false;
   bool published=ExportReport();
   if(published && exportTrusted && ExpectedAccount() && Connected())
   {revision=exportRevision;exportedSignature=signature;dirty=false;backedOff=false;recoveryStarted=0;liveState="ready";}
   else{dirty=true;liveState="history-unconfirmed";}
}
bool BeginLiveSession()
{
   if(!ResolveSession())return false;
   rootPath="MetaFactoryLive\\"+WorkToken;
   FolderCreate("MetaFactoryLive");FolderCreate(rootPath);
   if(!AcquireLease())return false;
   string genKey="MF.LiveGen."+WorkToken;GlobalVariableTemp(genKey);
   long generation=(long)GlobalVariableGet(genKey);
   if(generation<0 || generation>=4503599627370495)generation=0;
   GlobalVariableSet(genKey,(double)(generation+1));
   sequence=0;revision=0;exportRevision=0;dirty=true;wasConnected=false;
   stableSignature="";exportedSignature="";previousLightSignal="";previousOpenKey="";previousDay="";lastPoll=0;lastHistoryCheck=0;liveState="bootstrap";
   bootTick=GetTickCount();recoveryStarted=bootTick;
   runId=IntegerToString((long)TimeGMT())+"-"+IntegerToString((long)bootTick)+"-"+IntegerToString(ChartID())+"-"+IntegerToString(generation+1);
   HashReset();HashText(WorkToken);reconcileInterval=60000+historyHash1%15000;
   initProblem="";Print("MetaFactory Live init: session-ready; waiting for matching account connection");
   InitProblem("session-ready");
   WriteSnapshot();return true;
}
bool timerActive=false;
uint timerRetryAt=0, fallbackPollAt=0;
bool fallbackPolled=false;
int OnInit()
{
   Print("MetaFactory Live init: data-path=",TerminalInfoString(TERMINAL_DATA_PATH));
   ResetLastError();timerActive=EventSetTimer(1);int timerError=timerActive?0:GetLastError();
   timerRetryAt=GetTickCount();fallbackPollAt=0;fallbackPolled=false;
   // A failed timer must not detach the observer. Market ticks provide bounded recovery.
   BeginLiveSession();retryInitAt=GetTickCount();
   if(!timerActive)InitProblem("timer-fallback-awaiting-tick",timerError);
   return INIT_SUCCEEDED;
}
void OnDeinit(const int reason)
{
   EventKillTimer();timerActive=false;
   if(sessionOwned && RefreshLease()){WriteSnapshot("stopped");GlobalVariableSetOnCondition(ownerKey,0,ownerId);}
   sessionOwned=false;if(beatKey!="")GlobalVariableDel(beatKey);
}
void OnTimer()
{
   if(!RefreshLease())
   {if(GetTickCount()-retryInitAt>=5000){retryInitAt=GetTickCount();BeginLiveSession();}return;}
   bool active=ExpectedAccount()&&Connected();
   if(!active)
   {wasConnected=false;dirty=true;stableSignature="";liveState=ExpectedAccount()?"disconnected":"identity-mismatch";WriteSnapshot();return;}
   if(!wasConnected){wasConnected=true;dirty=true;backedOff=false;recoveryStarted=GetTickCount();stableSignature="";liveState="bootstrap";AskAllHistory();lastPoll=0;}
   string rows[],key="";
   if(!OpenLines(rows,key)){liveState="error";WriteSnapshot();return;}
   if(liveState=="error")liveState=revision>0&&!dirty?"ready":"history-pending";
   string day=TimeToString(ServerNow(),TIME_DATE);
   string lightSignal=key+"|"+day+"|"+IntegerToString(HistoryCount())+"|"+N(Balance())+"|"+N(Credit());
   if(lightSignal!=previousLightSignal)
   {dirty=true;backedOff=false;recoveryStarted=GetTickCount();previousLightSignal=lightSignal;previousOpenKey=key;previousDay=day;}
   if(dirty && liveState=="ready")liveState="history-pending";
   WriteSnapshot();
   if(dirty || GetTickCount()-lastHistoryCheck>=reconcileInterval)
   {long before=revision;string beforeState=liveState;PollHistory();if(revision!=before || liveState!=beforeState)WriteSnapshot();}
}

// MT4 only: ticks keep the observer usable while its timer is temporarily unavailable.
// No loop, Sleep, chart changes or trade calls; at most one recovery attempt per five seconds.
void OnTick()
{
   if(timerActive)return;
   uint now=GetTickCount();
   if(now-timerRetryAt>=5000)
   {
      timerRetryAt=now;ResetLastError();timerActive=EventSetTimer(1);
      if(timerActive){InitProblem("timer-recovered");OnTimer();return;}
   }
   if(fallbackPolled && now-fallbackPollAt<1000)return;
   fallbackPolled=true;fallbackPollAt=now;OnTimer();
}
