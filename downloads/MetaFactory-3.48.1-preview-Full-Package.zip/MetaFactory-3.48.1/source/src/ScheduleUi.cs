using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace MTManager
{
    /// <summary>Local schedule editor. Saving configures future deliveries; this dialog never sends a report.</summary>
    public sealed class ScheduleDialog : Form
    {
        readonly ScheduleOptions original;
        readonly Panel scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        readonly TableLayoutPanel body = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2, GrowStyle = TableLayoutPanelGrowStyle.AddRows };
        readonly CheckBox dailyEnabled = new CheckBox(), telegramEnabled = new CheckBox(), baleEnabled = new CheckBox(), emailEnabled = new CheckBox(), smtpSsl = new CheckBox();
        readonly TextBox time = Box(), telegramToken = Box(true), telegramChat = Box(), baleToken = Box(true), baleChat = Box();
        readonly TextBox smtpHost = Box(), smtpUser = Box(), smtpPassword = Box(true), emailFrom = Box(), emailTo = Box();
        readonly NumericUpDown smtpPort = new NumericUpDown { Minimum = 1, Maximum = 65535 };
        readonly ComboBox platform = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
        readonly Label error = new Label { AutoSize = true };
        readonly Button saveButton = new Button(), cancelButton = new Button();
        readonly List<Label> fullLabels = new List<Label>();
        readonly string telegramPlain, balePlain, smtpPlain;
        public ScheduleOptions Options { get; private set; }

        static TextBox Box(bool secret = false)
        { return new TextBox { UseSystemPasswordChar = secret, RightToLeft = RightToLeft.No, Dock = DockStyle.Fill }; }

        static ScheduleOptions Copy(ScheduleOptions value)
        {
            value = value ?? new ScheduleOptions();
            return new ScheduleOptions {
                Enabled = value.Enabled, Time = value.Time, Platform = value.Platform,
                TelegramEnabled = value.TelegramEnabled, TelegramTokenEnc = value.TelegramTokenEnc, TelegramChatId = value.TelegramChatId,
                BaleEnabled = value.BaleEnabled, BaleTokenEnc = value.BaleTokenEnc, BaleChatId = value.BaleChatId,
                EmailEnabled = value.EmailEnabled, SmtpHost = value.SmtpHost, SmtpPort = value.SmtpPort, SmtpSsl = value.SmtpSsl,
                SmtpUser = value.SmtpUser, SmtpPasswordEnc = value.SmtpPasswordEnc, EmailFrom = value.EmailFrom, EmailTo = value.EmailTo
            };
        }

        public ScheduleDialog(ScheduleOptions options, string lastStatus)
        {
            original = Copy(options); Options = Copy(original);
            Text = Lang.T("گزارش روزانه و ارسال خودکار", "Daily reports and automatic delivery");
            Font = Theme.Font; BackColor = Theme.Surface; ForeColor = Theme.Text;
            StartPosition = FormStartPosition.CenterParent; MinimizeBox = false;
            ClientSize = new Size(Theme.S(740), Theme.S(650)); MinimumSize = new Size(Theme.S(580), Theme.S(420));
            RightToLeft = Lang.En ? RightToLeft.No : RightToLeft.Yes;
            body.Padding = Theme.Pad(20, 12, 20, 20); body.Margin = Padding.Empty;
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Theme.S(190)));
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            scroll.Controls.Add(body); Controls.Add(scroll);
            var footer = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = Theme.S(64), Padding = Theme.Pad(16, 12),
                FlowDirection = Lang.En ? FlowDirection.RightToLeft : FlowDirection.LeftToRight, WrapContents = false, BackColor = Theme.Alt };
            saveButton.Text = Lang.T("ذخیره", "Save"); cancelButton.Text = Lang.T("انصراف", "Cancel");
            foreach (Button button in new[] { saveButton, cancelButton })
            {
                button.Size = new Size(Theme.S(112), Theme.S(36)); button.Font = Theme.Bold;
                button.FlatStyle = FlatStyle.Flat; button.FlatAppearance.BorderColor = Theme.BorderStrong;
                button.Margin = Theme.Pad(5, 0); button.BackColor = Theme.Surface; button.ForeColor = Theme.Text;
            }
            saveButton.BackColor = Theme.Accent; saveButton.ForeColor = Theme.OnAccent;
            saveButton.Click += SaveClicked; cancelButton.DialogResult = DialogResult.Cancel;
            footer.Controls.Add(saveButton); footer.Controls.Add(cancelButton); Controls.Add(footer);
            AcceptButton = saveButton; CancelButton = cancelButton;

            Full(Lang.T("این کامپیوتر باید روشن و بیدار باشد و MetaFactory در ساعت تعیین‌شده باز بماند. ساعت برنامه‌ریزی، ساعت محلی همین کامپیوتر است؛ روز معاملات با ساعت سرور بروکر محاسبه می‌شود.",
                "Keep this PC awake and MetaFactory running at the scheduled time. The schedule uses this PC's local clock; the trading day uses each broker's server clock."), Theme.Small, Theme.Muted);
            Full(Lang.T("گزارش همهٔ حساب‌های محدودهٔ انتخابی تهیه و به تمام کانال‌های تیک‌خورده ارسال می‌شود. با فعال‌کردن برنامهٔ روزانه، ارسال خودکار به مقصدهای زیر فعال می‌شود. ذخیرهٔ تنظیمات، گزارش را همین حالا ارسال نمی‌کند.",
                "All accounts in the selected platform scope are reported and sent to every checked channel. Enabling the daily schedule enables automatic delivery to the destinations below. Saving does not send a report now."), Theme.Small, Theme.Muted);
            Full(Lang.T("اگر ساعت گذشته باشد، پس از بازشدن برنامه یا پایان گزارش قبلی، گزارش همین روز یک‌بار اجرا می‌شود؛ روزهای گذشته جبران نمی‌شوند. فعال‌کردن برنامه پس از ساعت تعیین‌شده نیز آن را در بررسی بعدی زمان‌بندی اجرا می‌کند.",
                "If today's time has passed, the report runs once when the app opens or the previous report finishes; earlier days are skipped. Enabling an overdue schedule also starts it at the next schedule check."), Theme.Small, Theme.Muted);
            if (!string.IsNullOrWhiteSpace(lastStatus)) Full(Lang.T("آخرین وضعیت: ", "Last status: ") + lastStatus, Theme.Small, Theme.Muted);
            if (options != null && !string.IsNullOrEmpty(options.LoadError)) Full(options.LoadError, Theme.Small, Theme.Warn);
            error.ForeColor = Theme.Bad; error.Font = Theme.Small; error.Visible = false; Full(error);
            Check(dailyEnabled, Lang.T("گزارش و ارسال خودکار روزانه فعال باشد", "Enable daily reports and automatic delivery"), original.Enabled);
            time.Text = original.Time ?? "22:00"; time.MaxLength = 5;
            Row(Lang.T("ساعت محلی (HH:mm)", "Local time (HH:mm)"), time);
            platform.Items.AddRange(new object[] { Lang.T("همهٔ حساب‌ها", "All accounts"), "MT4", "MT5" });
            platform.SelectedIndex = string.Equals(original.Platform, "MT4", StringComparison.OrdinalIgnoreCase) ? 1 : string.Equals(original.Platform, "MT5", StringComparison.OrdinalIgnoreCase) ? 2 : 0;
            Row(Lang.T("محدودهٔ حساب‌ها", "Account scope"), platform);

            Section(Lang.T("بله", "Bale")); Check(baleEnabled, Lang.T("ارسال به بله", "Send to Bale"), original.BaleEnabled);
            balePlain = Secret.Unprotect(original.BaleTokenEnc); baleToken.Text = balePlain ?? ""; baleChat.Text = original.BaleChatId ?? "";
            Row(Lang.T("توکن ربات بله", "Bale bot token"), baleToken); Row(Lang.T("شناسهٔ گفتگو / Chat ID", "Chat ID"), baleChat);
            SecretNote(balePlain, original.BaleTokenEnc);
            EnableFields(baleEnabled, baleToken, baleChat);

            Section("Telegram"); Check(telegramEnabled, Lang.T("ارسال به تلگرام", "Send to Telegram"), original.TelegramEnabled);
            telegramPlain = Secret.Unprotect(original.TelegramTokenEnc); telegramToken.Text = telegramPlain ?? ""; telegramChat.Text = original.TelegramChatId ?? "";
            Row(Lang.T("توکن ربات تلگرام", "Telegram bot token"), telegramToken); Row(Lang.T("شناسهٔ گفتگو / Chat ID", "Chat ID"), telegramChat);
            SecretNote(telegramPlain, original.TelegramTokenEnc);
            EnableFields(telegramEnabled, telegramToken, telegramChat);

            Section(Lang.T("ایمیل", "Email")); Check(emailEnabled, Lang.T("ارسال ایمیل", "Send email"), original.EmailEnabled);
            smtpHost.Text = original.SmtpHost ?? ""; smtpPort.Value = Math.Max(1, Math.Min(65535, original.SmtpPort));
            smtpUser.Text = original.SmtpUser ?? ""; smtpPlain = Secret.Unprotect(original.SmtpPasswordEnc); smtpPassword.Text = smtpPlain ?? "";
            emailFrom.Text = original.EmailFrom ?? ""; emailTo.Text = original.EmailTo ?? "";
            Row(Lang.T("سرور SMTP", "SMTP server"), smtpHost); Row(Lang.T("پورت", "Port"), smtpPort);
            Check(smtpSsl, "TLS / STARTTLS", original.SmtpSsl);
            Row(Lang.T("نام کاربری SMTP", "SMTP username"), smtpUser); Row(Lang.T("رمز SMTP / رمز برنامه", "SMTP / app password"), smtpPassword);
            Row(Lang.T("ایمیل فرستنده", "From email"), emailFrom); Row(Lang.T("ایمیل گیرنده", "To email"), emailTo);
            SecretNote(smtpPlain, original.SmtpPasswordEnc);
            EnableFields(emailEnabled, smtpHost, smtpPort, smtpSsl, smtpUser, smtpPassword, emailFrom, emailTo);
            Full(Lang.T("توکن‌ها و رمزها رمزگذاری‌شده روی همین کامپیوتر ذخیره می‌شوند. مقدار ذخیره‌شده‌ای که ویرایش نکنید حفظ می‌شود.",
                "Tokens and passwords are stored encrypted on this PC. Stored values you do not edit are preserved."), Theme.Small, Theme.Muted);
            scroll.Resize += (s, e) => FitLabels(); FitLabels();
        }

        protected override void OnShown(EventArgs e)
        {
            Rectangle area = Screen.FromControl(this).WorkingArea;
            int width = Math.Max(1, area.Width - 20), height = Math.Max(1, area.Height - 20);
            MinimumSize = new Size(Math.Min(MinimumSize.Width, width), Math.Min(MinimumSize.Height, height));
            Size = new Size(Math.Min(Width, width), Math.Min(Height, height));
            Location = new Point(Math.Max(area.Left, Math.Min(Left, area.Right - Width)), Math.Max(area.Top, Math.Min(Top, area.Bottom - Height)));
            base.OnShown(e);
        }

        void Section(string text) { Full(text, Theme.Bold, Theme.Text); }
        void Full(string text, Font font, Color color)
        { Full(new Label { Text = text, Font = font, ForeColor = color, AutoSize = true }); }
        void Full(Label label)
        {
            label.Margin = Theme.Pad(0, 6, 0, 8); label.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            int row = body.RowCount++; body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            body.Controls.Add(label, 0, row); body.SetColumnSpan(label, 2); fullLabels.Add(label);
        }
        void Check(CheckBox control, string text, bool value)
        {
            control.Text = text; control.Checked = value; control.AutoSize = true; control.Margin = Theme.Pad(0, 7, 0, 9);
            int row = body.RowCount++; body.RowStyles.Add(new RowStyle(SizeType.AutoSize)); body.Controls.Add(control, 0, row); body.SetColumnSpan(control, 2);
        }
        void Row(string title, Control control)
        {
            int row = body.RowCount++; body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var label = new Label { Text = title, AutoSize = true, Anchor = AnchorStyles.Left | AnchorStyles.Right, Margin = Theme.Pad(0, 8, 10, 8) };
            control.Dock = DockStyle.Fill; control.Margin = Theme.Pad(0, 4, 0, 4); control.RightToLeft = RightToLeft.No;
            body.Controls.Add(label, 0, row); body.Controls.Add(control, 1, row);
        }
        void FitLabels()
        {
            int width = Math.Max(Theme.S(260), scroll.ClientSize.Width - body.Padding.Horizontal - SystemInformation.VerticalScrollBarWidth - Theme.S(4));
            foreach (Label label in fullLabels) label.MaximumSize = new Size(width, 0);
        }
        void SecretNote(string plain, string encrypted)
        {
            if (plain == null && !string.IsNullOrEmpty(encrypted))
                Full(Lang.T("رمز ذخیره‌شده با این کاربر ویندوز باز نمی‌شود؛ برای فعال‌کردن این کانال، مقدار جدید وارد کنید.",
                    "The stored secret cannot be opened by this Windows user; enter a replacement to enable this channel."), Theme.Small, Theme.Warn);
        }
        static void EnableFields(CheckBox enabled, params Control[] fields)
        {
            Action sync = () => { foreach (Control field in fields) field.Enabled = enabled.Checked; };
            enabled.CheckedChanged += (s, e) => sync(); sync();
        }
        static string ProtectedValue(TextBox field, string plain, string encrypted)
        { return field.Text == (plain ?? "") ? encrypted ?? "" : Secret.Protect(field.Text); }

        void SaveClicked(object sender, EventArgs e)
        {
            try
            {
                var candidate = Copy(original);
                candidate.Enabled = dailyEnabled.Checked; candidate.Time = TextUtil.LatinDigits(time.Text.Trim());
                candidate.Platform = platform.SelectedIndex == 1 ? "MT4" : platform.SelectedIndex == 2 ? "MT5" : "All";
                candidate.BaleEnabled = baleEnabled.Checked; candidate.BaleChatId = baleChat.Text.Trim(); candidate.BaleTokenEnc = ProtectedValue(baleToken, balePlain, original.BaleTokenEnc);
                candidate.TelegramEnabled = telegramEnabled.Checked; candidate.TelegramChatId = telegramChat.Text.Trim(); candidate.TelegramTokenEnc = ProtectedValue(telegramToken, telegramPlain, original.TelegramTokenEnc);
                candidate.EmailEnabled = emailEnabled.Checked; candidate.SmtpHost = smtpHost.Text.Trim(); candidate.SmtpPort = (int)smtpPort.Value; candidate.SmtpSsl = smtpSsl.Checked;
                candidate.SmtpUser = smtpUser.Text.Trim(); candidate.SmtpPasswordEnc = ProtectedValue(smtpPassword, smtpPlain, original.SmtpPasswordEnc);
                candidate.EmailFrom = emailFrom.Text.Trim(); candidate.EmailTo = emailTo.Text.Trim();
                // Disabling must remain possible even if a previously saved destination is no longer usable.
                string invalid = candidate.Enabled ? ScheduledDelivery.Validate(candidate) : ScheduledDelivery.StructureProblem(candidate);
                if (invalid != null) { error.Text = invalid; error.Visible = true; scroll.ScrollControlIntoView(error); return; }
                Options = candidate; DialogResult = DialogResult.OK; Close();
            }
            catch
            {
                error.Text = Lang.T("تنظیمات ذخیره نشد؛ رمزگذاری اطلاعات روی این کاربر ویندوز را بررسی کنید.", "Settings could not be saved; check credential encryption for this Windows user.");
                error.Visible = true; scroll.ScrollControlIntoView(error);
            }
        }
    }
}
