using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MTManager
{
    public interface IAccountVerifier : IDisposable
    {
        ImportConnection Verify(Account account, int milliseconds, Func<bool> cancel, Action<string> stage);
    }

    public interface IIdleAccountVerifier { void Idle(bool paused); }
    public static class VerificationReuse
    {
        public static bool CanReuse(Kind current, string currentServer, Kind next, string nextServer, bool ownedAlive)
        { return ownedAlive && current == Kind.MT5 && next == Kind.MT5 && string.Equals(currentServer, nextServer, StringComparison.OrdinalIgnoreCase); }
    }
    public static class VerificationParallel
    {
        public static int Auto(int processors, ulong totalMb, ulong freeMb)
        { return processors >= 2 && totalMb >= 6000 && freeMb >= 2500 ? 2 : 1; }
    }

    // Account metadata is the durable queue: no second credentials file and no plaintext password logs.
    public sealed class ImportCoordinator : IDisposable
    {
        readonly Settings settings;
        readonly AccountStore accounts;
        readonly FolderStore folders;
        readonly Func<int, IAccountVerifier> factory;
        readonly AutoResetEvent wake = new AutoResetEvent(false);
        readonly List<Task> workers = new List<Task>();
        readonly int capacity;
        volatile bool stopping, paused;
        public event Action Changed;
        public bool Paused { get { return paused; } }
        public ImportCoordinator(Settings settings, AccountStore accounts, FolderStore folders, Func<int, IAccountVerifier> factory = null, int capacity = 0)
        {
            this.settings = settings; this.accounts = accounts; this.folders = folders;
            this.factory = factory ?? (slot => new DirectAccountVerifier(settings, slot));
            this.capacity = capacity > 0 ? Math.Min(2, capacity) : VerificationParallel.Auto(Environment.ProcessorCount, Checks.TotalRamMb(), Checks.FreeRamMb());
            bool readable; AccountStore.Load(out readable); if (!readable) { paused = true; return; }
            // Recovery is explicit: an interrupted attempt cannot reuse a previous success token.
            lock (accounts.Sync)
            {
                bool dirty = false;
                foreach (Account a in accounts.All.Where(a => a.VerifyState == "checking"))
                { a.VerifyState = "queued"; a.VerifyToken = ""; a.VerifyPass = Math.Max(0, a.VerifyPass - 1); accounts.SetQueue(a); dirty = true; }
                if (dirty) accounts.Save();
            }
        }
        public void RecoverGroups()
        {
            var pending = accounts.All.Where(a => a.ImportGroup.Length > 0).ToArray();
            if (pending.Length == 0) return;
            foreach (Account a in pending)
            {
                Folder f = folders.Find(a.ImportGroup) ?? folders.Create(a.ImportGroup);
                folders.Add(f.Id, new[] { a.Instance });
            }
            folders.Save();
            lock (accounts.Sync) { foreach (Account a in pending) { Account fresh = accounts.Get(a.Instance); if (fresh != null) { fresh.ImportGroup = ""; accounts.SetQueue(fresh); } } accounts.Save(); }
        }
        public void Register(IEnumerable<StudentImportRow> rows, string defaultFolder, Func<bool> cancel, Action<StudentImportRow> progress)
        {
            bool readable; AccountStore.Load(out readable);
            if (!readable) throw new IOException("The accounts file is unreadable; existing data was preserved.");
            var staged = new List<KeyValuePair<StudentImportRow, Account>>();
            lock (accounts.Sync)
            {
                var reserved = new HashSet<string>(StudentDirectory.All(settings, accounts).Select(c => c.Name), StringComparer.OrdinalIgnoreCase);
                var indices = new Dictionary<Kind, int> { { Kind.MT4, CopyMaker.NextIndex(settings.AllFolders, "MT4") }, { Kind.MT5, CopyMaker.NextIndex(settings.AllFolders, "MT5") } };
                var seen = new HashSet<string>(accounts.All.Select(a => StudentImport.Key(StudentDirectory.KindOf(a), a.Login, a.Server)), StringComparer.OrdinalIgnoreCase);
                try
                {
                    foreach (StudentImportRow r in rows.Where(r => r.State == ImportState.Ready))
                    {
                        if (cancel()) { r.State = ImportState.Cancelled; progress(r); continue; }
                        if (!seen.Add(StudentImport.Key(r.Kind, r.Login, r.Server))) { r.State = ImportState.Duplicate; r.Reason = Lang.T("حساب قبلاً ثبت شده است.", "Account already registered."); progress(r); continue; }
                        string group = r.Folder.Length > 0 ? r.Folder : defaultFolder ?? "";
                        string problem = group.Length == 0 || folders.Find(group) != null ? null : folders.NameProblem(group);
                        if (problem != null) { r.State = ImportState.Invalid; r.Reason = problem; progress(r); continue; }
                        string name;
                        do { name = r.Kind + "-" + (indices[r.Kind]++).ToString("00"); } while (!reserved.Add(name));
                        var a = new Account { Instance = name, Trader = r.Name, Login = r.Login, Server = r.Server, Mode = r.Mode, InvestorEnc = Secret.Protect(r.Investor), MasterEnc = Secret.Protect(r.Master),
                            Platform = r.Platform, DeferredDir = Path.Combine(settings.BaseDir, name), VerifyState = "queued", ImportGroup = group };
                        accounts.SetQueue(a); staged.Add(new KeyValuePair<StudentImportRow, Account>(r, a));
                    }
                    if (staged.Count > 0) accounts.Save(); // One atomic commit for the entire batch.
                }
                catch { foreach (var pair in staged) accounts.Remove(pair.Value.Instance); throw; }
                foreach (var pair in staged)
                {
                    var r = pair.Key; r.Copy = pair.Value.Instance; r.Folder = pair.Value.ImportGroup; r.State = ImportState.Registered;
                    r.Reason = Lang.T("ثبت شد؛ بررسی اتصال در پس‌زمینه انجام می‌شود.", "Registered; connection will be checked in the background."); progress(r);
                }
            }
            // Grouping errors never hide already committed accounts; marker is retained for recovery.
            try { RecoverGroups(); }
            catch (Exception e) { Log.Write("import grouping recovery required: " + e.GetType().Name); }
            Notify(); wake.Set();
        }
        public void Start()
        {
            if (stopping || workers.Count > 0) return;
            for (int slot = 1; slot <= capacity; slot++)
            {
                int n = slot;
                workers.Add(Task.Factory.StartNew(() => Loop(n), CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default));
            }
        }
        Account Claim()
        {
            lock (accounts.Sync)
            {
                if (stopping || paused) return null;
                Account a = accounts.All.Where(x => (x.VerifyState == "queued" || x.VerifyState == "retry"))
                    .OrderBy(x => x.VerifyPass).ThenBy(x => x.Platform).ThenBy(x => x.Server).ThenBy(x => x.Instance).FirstOrDefault();
                if (a == null) return null;
                Account old = a.Snapshot();
                a.VerifyState = "checking"; a.VerifyToken = Guid.NewGuid().ToString("N"); a.VerifyPass++;
                a.VerifyReason = Lang.T("آماده‌سازی بررسی اتصال…", "Preparing connection check…"); accounts.SetQueue(a);
                try { accounts.Save(); } catch { accounts.SetQueue(old); throw; }
                return a;
            }
        }
        bool Cancelled(Account a)
        {
            if (paused || stopping) return true;
            Account current = accounts.Get(a.Instance);
            return current == null || current.VerifyToken != a.VerifyToken || current.CredentialKey != a.CredentialKey || current.VerifyState != "checking";
        }
        void Finish(Account job, ImportConnection result)
        {
            lock (accounts.Sync)
            {
                Account a = accounts.Get(job.Instance);
                if (a == null || a.VerifyToken != job.VerifyToken || a.CredentialKey != job.CredentialKey) return;
                a.VerifyToken = "";
                if (paused || stopping) { a.VerifyState = paused ? "paused" : "queued"; a.VerifyPass = Math.Max(0, a.VerifyPass - 1); }
                else
                {
                    a.VerifyState = result.Connected ? "connected" : result.State == Login.WrongLogin ? "rejected" : a.VerifyPass < 2 && result.Retryable ? "retry" : "unconfirmed";
                    a.VerifyReason = result.Reason ?? "";
                    foreach (string encrypted in new[] { a.InvestorEnc, a.MasterEnc })
                    {
                        string password = Secret.Unprotect(encrypted);
                        if (!string.IsNullOrEmpty(password)) a.VerifyReason = a.VerifyReason.Replace(password, "***");
                    }
                    a.VerifyUtc = a.VerifyState == "retry" ? "" : DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture);
                }
                Account previous = accounts.Get(a.Instance);
                accounts.SetQueue(a);
                try { accounts.Save(); } catch { accounts.SetQueue(previous); throw; }
            }
            Notify();
        }
        void Loop(int slot)
        {
            IAccountVerifier verifier = null;
            try
            {
                while (!stopping)
                {
                    Account job;
                    try { job = Claim(); }
                    catch (Exception e) { paused = true; Log.Write("verification queue paused: " + e.GetType().Name); Notify(); continue; }
                    if (job == null)
                    {
                        var idle = verifier as IIdleAccountVerifier;
                        if (idle != null) { try { idle.Idle(paused); } catch (Exception e) { Log.Write("verification idle cleanup: " + e.GetType().Name); } }
                        wake.WaitOne(500); continue;
                    }
                    Notify();
                    ImportConnection result;
                    try
                    {
                        if (verifier == null) verifier = factory(slot);
                        result = verifier.Verify(job, job.VerifyPass == 1 ? 15000 : 60000, () => Cancelled(job), text => {
                            lock (accounts.Sync)
                            {
                                Account current = accounts.Get(job.Instance);
                                if (current != null && current.VerifyToken == job.VerifyToken) { current.VerifyReason = text; accounts.SetQueue(current); }
                            }
                        });
                    }
                    catch (OperationCanceledException) { result = new ImportConnection(); }
                    catch (Exception e) { Log.Write("verification row: " + e.GetType().Name); result = new ImportConnection { Reason = Lang.T("بررسی این حساب کامل نشد؛ مسیر نصب و دسترسی بروکر را بررسی کنید.", "This account could not be checked; check the terminal installation and broker access.") }; }
                    try { Finish(job, result); }
                    catch (Exception e) { paused = true; Log.Write("verification save failed: " + e.GetType().Name); try { Pause(); } catch { } Notify(); }
                }
            }
            finally { if (verifier != null) verifier.Dispose(); }
        }
        public void Pause()
        {
            paused = true;
            lock (accounts.Sync)
            {
                foreach (Account a in accounts.All.Where(x => x.VerifyState == "queued" || x.VerifyState == "retry" || x.VerifyState == "checking"))
                { if (a.VerifyState == "checking") a.VerifyPass = Math.Max(0, a.VerifyPass - 1); a.VerifyState = "paused"; a.VerifyToken = ""; accounts.SetQueue(a); }
                accounts.Save();
            }
            Notify();
        }
        public void Recheck(string instance) { RecheckMany(new[] { instance }); }
        public void RecheckMany(IEnumerable<string> instances)
        {
            lock (accounts.Sync)
            {
                foreach (string instance in instances.Distinct(StringComparer.OrdinalIgnoreCase))
                {
                    Account a = accounts.Get(instance);
                    if (a == null) continue;
                    a.VerifyState = "queued"; a.VerifyToken = ""; a.VerifyPass = 0; a.VerifyUtc = ""; accounts.SetQueue(a);
                }
                accounts.Save(); paused = false;
            }
            Notify(); wake.Set();
        }
        public void Resume(bool retryFailed)
        {
            lock (accounts.Sync)
            {
                foreach (Account a in accounts.All.Where(x => x.VerifyState == "paused" || (retryFailed && (x.VerifyState == "rejected" || x.VerifyState == "unconfirmed"))))
                { a.VerifyState = "queued"; a.VerifyToken = ""; a.VerifyPass = 0; accounts.SetQueue(a); }
                accounts.Save(); paused = false;
            }
            Notify(); wake.Set();
        }
        public static string Status(string value)
        {
            switch (value)
            {
                case "queued": return Lang.T("در صف بررسی", "Queued");
                case "checking": return Lang.T("در حال بررسی", "Checking");
                case "retry": return Lang.T("در صف بررسی تکمیلی", "Deferred check");
                case "connected": return Lang.T("اتصال تأیید شد", "Login verified");
                case "rejected": return Lang.T("حساب یا رمز رد شد", "Credentials rejected");
                case "paused": return Lang.T("متوقف", "Paused");
                default: return Lang.T("نیاز به بررسی", "Needs review");
            }
        }
        public void Export(string path)
        {
            var rows = new List<string[]> { new[] { "Name", "Platform", "Login", "Server", "Status", "Reason", "VerifiedUtc" } };
            rows.AddRange(accounts.All.Where(a => a.VerifyState.Length > 0).Select(a => new[] { a.Trader, a.Platform, a.Login, a.Server, Status(a.VerifyState), a.VerifyReason, a.VerifyUtc }));
            Spreadsheet.Write(path, rows);
        }
        void Notify() { var changed = Changed; if (changed != null) { try { changed(); } catch { } } }
        public void Dispose()
        {
            stopping = true; wake.Set();
            try { if (Task.WaitAll(workers.ToArray(), 8000)) wake.Dispose(); } catch { }
        }
    }
}
