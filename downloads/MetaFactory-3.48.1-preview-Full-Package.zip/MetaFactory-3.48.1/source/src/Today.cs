using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace MTManager
{
    // ================================================================== 3.21: the report inside the program

    /// <summary>The ranges of the panel under a student's row.</summary>
    public enum PanelRange { Today, Yesterday, Week, Month, Custom }

    /// <summary>Days on the trading server's calendar, as MetaTrader itself counts them ("today" starts at 00:00 server time).</summary>
    public static class ServerDays
    {
        /// <summary>The server's clock now, for an account (its own offset from GMT when the script told it; otherwise the usual
        /// New York + 7: GMT+2 in winter, GMT+3 in summer).</summary>
        public static DateTime Now(AccountJournal j, DateTime utcNow) { return ServerClock.Of(j).FromGmt(utcNow); }

        public static bool Weekend(DateTime d) { return d.DayOfWeek == DayOfWeek.Saturday || d.DayOfWeek == DayOfWeek.Sunday; }

        /// <summary>The trading day before a day (Monday's is the Friday before).</summary>
        public static DateTime PreviousTradingDay(DateTime day)
        {
            DateTime d = day.Date.AddDays(-1);
            while (Weekend(d)) d = d.AddDays(-1);
            return d;
        }

        public static ReportRange Range(PanelRange kind, DateTime today, DateTime? from = null, DateTime? to = null)
        {
            DateTime d = today.Date;
            switch (kind)
            {
                case PanelRange.Today: return new ReportRange { Kind = RangeKind.Today, From = d, To = d.AddDays(1) };
                case PanelRange.Yesterday:
                    DateTime y = PreviousTradingDay(d);
                    return new ReportRange { Kind = RangeKind.Custom, From = y, To = y.AddDays(1) };
                case PanelRange.Week: return ReportRange.Of(RangeKind.ThisWeek, d);
                case PanelRange.Month: return ReportRange.Of(RangeKind.ThisMonth, d);
                default:
                    DateTime a = (from ?? d).Date, b = (to ?? d).Date;
                    if (b < a) { DateTime t = a; a = b; b = t; }
                    if (b > d) b = d;
                    if (a > b) a = b;
                    return new ReportRange { Kind = RangeKind.Custom, From = a, To = b.AddDays(1) };
            }
        }

        /// <summary>The first day a refresh reads when nothing is kept: what the panel's own choices need (this month, this week and
        /// the trading day before today).</summary>
        public static DateTime Window(DateTime today)
        {
            DateTime d = today.Date;
            DateTime[] all = { new DateTime(d.Year, d.Month, 1), ReportRange.WeekStart(d), PreviousTradingDay(d) };
            return all.Min();
        }

        /// <summary>Where a refresh starts reading: from the window (or an earlier day asked for) when the history kept on this
        /// computer does not cover it with the 3.21 script; otherwise only from the day of the last read, the rest being kept.</summary>
        public static DateTime ReadFrom(AccountJournal kept, DateTime today, DateTime? wanted = null)
        {
            DateTime need = Window(today);
            if (wanted.HasValue && wanted.Value.Date < need) need = wanted.Value.Date;
            if (!JournalCache.CoversTrusted(kept, need)) return need;
            DateTime last = kept.Exported.Date;
            return last < today.Date ? last : today.Date;
        }

        public static bool SingleDay(ReportRange r) { return (r.To - r.From).TotalDays <= 1.0001; }
    }

    /// <summary>One trade in the panel: closed in the range or opened in it, or still open.</summary>
    public sealed class PanelTrade
    {
        public long Ticket;
        public string Symbol = "";
        public bool Buy, Closed;
        public double Lots, Net, RiskPct = double.NaN;
        public DateTime Open, Close;
        public StopKind Stop;
        /// <summary>Open to close; for one still open, to the moment the history was read.</summary>
        public TimeSpan Hold;
        /// <summary>Opened in the range (counted for the Stop Loss and the risk); otherwise opened before it and closed in it.</summary>
        public bool OpenedInRange;
        /// <summary>Its place among the day's trades when beyond the daily limit (11th…); 0 otherwise.</summary>
        public int Over;
        internal PanelTrade Snapshot() { return (PanelTrade)MemberwiseClone(); }
        /// <summary>The server day it belongs to in the panel: the day it opened, or the day it closed when it opened before the range.</summary>
        public DateTime Day;
    }

    /// <summary>One day of a range of several days.</summary>
    public sealed class PanelDay
    {
        public DateTime Day;
        public int Trades, Entry, Late, NoSl, Mt4;
        public double Net, MaxRisk = double.NaN, DailyDdPct = double.NaN;
        internal PanelDay Snapshot() { return (PanelDay)MemberwiseClone(); }
    }

    /// <summary>What the panel shows for one student and one range.</summary>
    public sealed class PanelView
    {
        public ReportRange Range;
        public bool SingleDay, ReachesNow;
        public string Currency = "";
        public List<PanelTrade> Trades { get; private set; } = new List<PanelTrade>();
        public List<PanelDay> Days { get; private set; } = new List<PanelDay>();
        /// <summary>Trades closed in the range and positions shown open.</summary>
        public int Closed, Open;
        public double ClosedNet, Floating;
        public double Net { get { return ClosedNet + Floating; } }
        /// <summary>Risk in percent of the balance, of the trades opened in the range that had a Stop Loss on the losing side.</summary>
        public double AvgRisk = double.NaN, MaxRisk = double.NaN;
        public int RiskUnknown;
        /// <summary>Stop Loss of the trades opened in the range: on the entry order, put on later, none, MT4 (had one, when unknown).</summary>
        public int Opened, Entry, Late, NoSl, Mt4;
        public int WithStop { get { return Entry + Late + Mt4; } }
        /// <summary>How long the trades without a Stop Loss were in the market without one, together.</summary>
        public TimeSpan NoSlTime;
        /// <summary>The day's drawdown (one day) or the range's largest fall of the balance (several days), in percent.</summary>
        public double DdPct = double.NaN;
        /// <summary>Whole-history relative trading-balance drawdown. Requires the native full-history proof; never equity drawdown.</summary>
        public double AccountDdPct = double.NaN;
        public double AccountMaxDdMoney = double.NaN, AccountMaxDdPct = double.NaN, AccountRelativeDdMoney = double.NaN;
        public double AccountDdPeak = double.NaN, AccountDdTrough = double.NaN;
        public DateTime AccountDdPeakAt, AccountDdTroughAt;
        public DateTime AccountDdFrom, AccountDdTo;
        public bool AccountDdComplete;
        public string AccountDdBasis = "Full-history Relative DD unavailable; refresh required. Not equity drawdown.";
        public bool FloatingDisabled;
        public string DdLabel = "Daily DD";
        public double Balance;
        /// <summary>3.22.1: the balance when the range began, and the closed result against it in percent (NaN without a balance).</summary>
        public double StartBalance, ReturnPct = double.NaN;
        public readonly List<CoachFlag> Flags = new List<CoachFlag>();
        /// <summary>Why the numbers may not be whole (in Persian); null when they are.</summary>
        public string HistoryNote;
        /// <summary>When the history was read (server time).</summary>
        public DateTime ReadAt;
        internal PanelView WithCurrent(AccountJournal current)
        {
            var copy=(PanelView)MemberwiseClone(); copy.ReadAt=current.Exported;copy.Balance=current.Balance;
            var positions=current.Open.ToDictionary(o=>o.Ticket);
            copy.Trades=new List<PanelTrade>();var dayDelta=new Dictionary<DateTime,double>();
            copy.Floating=0;
            foreach(var original in Trades)
            {
                var trade=original.Snapshot();JournalOpen position;
                if(!trade.Closed && positions.TryGetValue(trade.Ticket,out position))
                {
                    trade.Net=position.Profit+position.Swap+position.Commission;trade.Hold=current.Exported-position.Open;
                    double delta;dayDelta.TryGetValue(trade.Day,out delta);dayDelta[trade.Day]=delta+trade.Net-original.Net;
                }
                if(!trade.Closed && copy.ReachesNow)copy.Floating+=trade.Net;
                copy.Trades.Add(trade);
            }
            copy.Days=Days.Select(d=>{var n=d.Snapshot();double delta;if(copy.ReachesNow && dayDelta.TryGetValue(n.Day,out delta))n.Net+=delta;return n;}).ToList();
            return copy;
        }
        public int TradeCount { get { return Trades.Count; } }
    }

    public static class PanelMath
    {
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        /// <summary>The panel for one range of a student's history kept on this computer.</summary>
        public static PanelView Build(AccountJournal j, ReportRange r, TradeLimits limits)
        {
            var v = new PanelView { Range = r, SingleDay = ServerDays.SingleDay(r), Balance = j.Balance, ReadAt = j.Exported, Currency = j.Currency ?? "", FloatingDisabled = j.FloatingDisabled };
            AccountDrawdown(j, v);
            limits = limits ?? new TradeLimits();
            JournalSummary s = JournalMath.Summarize(j, r.From, r.To, limits);
            v.StartBalance = s.StartBalance;
            v.ReturnPct = s.ReturnPct;
            CoachStats c = Coach.Analyze(j, s, r.From, r.To);
            // The range reaches the moment of the read (open positions and their floating result belong to it); a read from before the
            // range began says nothing of it.
            v.ReachesNow = r.To > j.Exported && r.From <= j.Exported;
            DateTime end = v.ReachesNow ? j.Exported.AddSeconds(1) : r.To;

            foreach (JournalTrade t in j.Trades)
            {
                bool closedIn = t.Close >= r.From && t.Close < end, openedIn = t.Open >= r.From && t.Open < end;
                if (!closedIn && !openedIn) continue;
                double risk;
                var p = new PanelTrade
                {
                    Ticket = t.Ticket, Symbol = t.Symbol, Buy = t.Buy, Closed = true, Lots = t.Volume, Net = t.Net, Open = t.Open, Close = t.Close,
                    Stop = Stops.Of(t.SlEntry, t.SlFinal), Hold = t.Close - t.Open, OpenedInRange = openedIn,
                    RiskPct = c.RiskByTicket.TryGetValue(t.Ticket, out risk) ? risk : ClosedRisk(j, t),
                };
                if (closedIn) { v.Closed++; v.ClosedNet += t.Net; }
                v.Trades.Add(p);
            }
            foreach (JournalOpen o in j.Open)
            {
                bool openedIn = o.Open >= r.From && o.Open < end;
                if (!v.ReachesNow && !openedIn) continue;
                var p = new PanelTrade
                {
                    Ticket = o.Ticket, Symbol = o.Symbol, Buy = o.Buy, Lots = o.Volume, Net = o.Profit + o.Swap + o.Commission, Open = o.Open,
                    Stop = o.Sl > 0 ? StopKind.Strict : StopKind.Unprotected, Hold = j.Exported - o.Open, OpenedInRange = openedIn, RiskPct = OpenRisk(o, j.Balance),
                };
                v.Open++;
                if (v.ReachesNow) v.Floating += p.Net;
                v.Trades.Add(p);
            }
            v.Trades.Sort((a, b) => a.Open != b.Open ? a.Open.CompareTo(b.Open) : a.Ticket.CompareTo(b.Ticket));

            var risks = new List<double>();
            foreach (PanelTrade p in v.Trades)
            {
                p.Day = p.OpenedInRange ? p.Open.Date : p.Close.Date;
                if (!p.OpenedInRange) continue;
                v.Opened++;
                switch (p.Stop)
                {
                    case StopKind.Strict: v.Entry++; break;
                    case StopKind.Delayed: v.Late++; break;
                    case StopKind.Mt4: v.Mt4++; break;
                    default: v.NoSl++; v.NoSlTime += p.Hold > TimeSpan.Zero ? p.Hold : TimeSpan.Zero; break;
                }
                if (double.IsNaN(p.RiskPct)) v.RiskUnknown++;
                else risks.Add(p.RiskPct);
            }
            if (risks.Count > 0) { v.AvgRisk = risks.Average(); v.MaxRisk = risks.Max(); }
            // Over the daily limit: the trades of a day after the limit, in the order opened.
            foreach (IGrouping<DateTime, PanelTrade> day in v.Trades.Where(p => p.OpenedInRange).GroupBy(p => p.Open.Date))
            {
                int n = 0;
                foreach (PanelTrade p in day.OrderBy(x => x.Open).ThenBy(x => x.Ticket)) { n++; if (n > limits.Daily) p.Over = n; }
            }

            if (v.SingleDay) { v.DdPct = s.MaxDailyDdPct; v.DdLabel = "Daily DD"; }
            else
            {
                v.DdPct = j.FloatingDisabled ? double.NaN : c.MaxDdPct;
                v.DdLabel = "Max DD";
                foreach (IGrouping<DateTime, PanelTrade> day in v.Trades.GroupBy(p => p.Day).OrderBy(g => g.Key))
                {
                    var d = new PanelDay { Day = day.Key, Trades = day.Count() };
                    foreach (PanelTrade p in day)
                    {
                        if (p.Closed && p.Close >= r.From && p.Close < end) d.Net += p.Net;
                        else if (!p.Closed && v.ReachesNow) d.Net += p.Net;
                        if (!p.OpenedInRange) continue;
                        if (p.Stop == StopKind.Strict) d.Entry++;
                        else if (p.Stop == StopKind.Delayed) d.Late++;
                        else if (p.Stop == StopKind.Mt4) d.Mt4++;
                        else d.NoSl++;
                        if (!double.IsNaN(p.RiskPct) && (double.IsNaN(d.MaxRisk) || p.RiskPct > d.MaxRisk)) d.MaxRisk = p.RiskPct;
                    }
                    JournalSummary ds = JournalMath.Summarize(j, day.Key, day.Key.AddDays(1), limits);
                    d.DailyDdPct = ds.MaxDailyDdPct;
                    v.Days.Add(d);
                }
            }
            v.Flags.AddRange(c.Flags);
            if (j.TrustedFrom > r.From)
                v.HistoryNote = Lang.T("این بازه را اسکریپت نسخه‌های قبل خوانده است؛ برای عددهای دقیق «به‌روزرسانی» را بزنید.", "This range was read by the script of an earlier version; press “Refresh” for exact numbers.");
            else if (j.HistoryChecked && !j.HistoryOk)
                v.HistoryNote = Lang.T("جمع تاریخچه با بالانس حساب نمی‌خواند (", "The history total does not match the account balance (") + Money(j.HistorySum, "") + Lang.T(" در برابر ", " vs ") + Money(j.HistoryBalance, "") +
                                Lang.T(")؛ کارگزار بخشی از تاریخچه‌ی قدیمی را نداده است.", "); the broker did not give part of the old history.");
            return v;
        }

        static bool Finite(double value) { return !double.IsNaN(value) && !double.IsInfinity(value); }

        /// <summary>The native MT4 statement's relative trading-balance curve: initial funding before the first trade,
        /// then realized trading results in close order. Later external cash/credit are not trading gains or losses.
        /// MT5 uses its full deal timeline, retaining entry fees and partial closes; native MT5 statement parity is not established.</summary>
        public static void AccountDrawdown(AccountJournal j, PanelView view)
        {
            view.AccountDdPct = view.AccountMaxDdMoney = view.AccountMaxDdPct = view.AccountRelativeDdMoney = double.NaN;
            view.AccountDdPeak = view.AccountDdTrough = double.NaN;
            view.AccountDdFrom = view.AccountDdTo = view.AccountDdPeakAt = view.AccountDdTroughAt = DateTime.MinValue;
            view.AccountDdComplete = false;
            view.AccountDdBasis = Lang.T("افت نسبی کل تاریخچه موجود نیست؛ به‌روزرسانی لازم است. این شاخص افت اکوئیتی نیست.",
                "Full-history Relative DD unavailable; refresh required. Not equity drawdown.");
            if (j == null || !j.Complete || !j.FullHistoryValid || !j.FullHistoryPresent || !j.FullHistoryReconciled || !j.FullHistoryScanOk) return;
            bool mt5 = string.Equals(j.Platform, "MT5", StringComparison.OrdinalIgnoreCase);
            if (!mt5 && !string.Equals(j.Platform, "MT4", StringComparison.OrdinalIgnoreCase)) return;
            var events = j.FullHistory.OrderBy(x => x.TimeMilliseconds).ThenBy(x => x.Ticket).ToList();
            if (events.Count != j.FullHistoryCount || events.Count == 0 || events.Any(x => !Finite(x.Net))) return;
            if (events.Select(x => x.Ticket).Distinct().Count() != events.Count) return;
            Func<JournalBalanceEvent, bool> credit = x => x.Type == JournalCash.CreditKind || j.FullHistoryBonusExcluded && x.Type == 6;
            Func<JournalBalanceEvent, bool> cash = x => x.Type == 2 || mt5 && (x.Type == 5 || x.Type == 6);
            // MT5 may charge a fee before its first buy/sell. Later funding must not be moved before that loss.
            int firstTrade = events.FindIndex(x => mt5 ? !credit(x) && !cash(x) : x.Type == 0 || x.Type == 1);
            int initialEnd = firstTrade < 0 ? events.Count : firstTrade;
            double initial = events.Take(initialEnd).Where(x => !credit(x) && cash(x)).Sum(x => x.Net);
            if (!Finite(initial) || initial <= 0) return;
            double balance = initial, peak = initial, relative = 0, relativeMoney = 0, maxMoney = 0, maxMoneyPct = 0;
            double relativePeak = initial, relativeTrough = initial;
            DateTime peakAt = events[0].Time, relativePeakAt = peakAt, relativeTroughAt = peakAt;
            foreach (JournalBalanceEvent item in events)
            {
                if (credit(item) || cash(item)) continue;
                if (!mt5 && item.Type != 0 && item.Type != 1) return;
                balance += item.Net;
                if (!Finite(balance)) return;
                if (balance > peak) { peak = balance; peakAt = item.Time; }
                double money = peak - balance, pct = money / peak * 100;
                if (!Finite(pct)) return;
                // Relative maximum and monetary maximum can occur on different trades.
                if (money > maxMoney) { maxMoney = money; maxMoneyPct = pct; }
                if (pct > relative)
                {
                    relative = pct; relativeMoney = money; relativePeak = peak; relativeTrough = balance;
                    relativePeakAt = peakAt; relativeTroughAt = item.Time;
                }
            }
            view.AccountDdPct = relative; view.AccountRelativeDdMoney = relativeMoney;
            view.AccountMaxDdMoney = maxMoney; view.AccountMaxDdPct = maxMoneyPct;
            view.AccountDdPeak = relativePeak; view.AccountDdTrough = relativeTrough;
            view.AccountDdPeakAt = relativePeakAt; view.AccountDdTroughAt = relativeTroughAt;
            view.AccountDdFrom = events[0].Time; view.AccountDdTo = j.Exported;
            view.AccountDdComplete = true;
            view.AccountDdBasis = Lang.T("افت نسبی بالانس معاملاتی؛ کل تاریخچهٔ گزارش‌شده", "Relative trading-balance DD; all reported history")
                + " · " + view.AccountDdFrom.ToString("yyyy.MM.dd", Inv) + "–" + j.Exported.ToString("yyyy.MM.dd", Inv)
                + (mt5 ? Lang.T("؛ سرمایهٔ اولیه پیش از اولین رویداد معاملاتی/کارمزد", "; funding before first trading/fee event")
                    : Lang.T("؛ سرمایهٔ اولیه پیش از اولین معامله", "; funding before first trade"))
                + Lang.T("؛ واریز/برداشت و اعتبار بعدی حذف می‌شود؛ نه افت اکوئیتی.",
                    "; later external cash/credit excluded; not equity drawdown.")
                + (mt5 ? Lang.T(" بر پایهٔ جزئیات معاملات MT5؛ تطابق با گزارش بومی MT5 هنوز آزموده نشده است.",
                    " MT5 deal-based; native MT5 statement parity not yet verified.") : "");
        }

        public static string DdText(PanelView v)
        { return Lang.T("دراودان کلی: ", "Overall DD: ") + AccountDdValue(v); }

        public static string AccountDdValue(PanelView v)
        { return Finite(v.AccountDdPct) ? v.AccountDdPct.ToString("0.##", Inv) + "%" : "—"; }

        public static string SummaryDetail(PanelView v)
        {
            return "Closed: " + Money(v.ClosedNet, v.Currency) + "; O = currently open positions, floating: " + (v.ReachesNow ? Money(v.Floating, v.Currency) : "unknown for this historical range")
                + ". " + DdText(v) + " · " + v.AccountDdBasis + ". Open-position SL reflects the current stop; closed-trade SL reflects recorded history.";
        }

        /// <summary>A closed trade's risk when the coach has none: a Stop Loss put on after the entry, measured at the one it closed with,
        /// against the balance when it opened. NaN without a Stop Loss on the losing side or when the price did not move.</summary>
        public static double ClosedRisk(AccountJournal j, JournalTrade t)
        {
            double sl = t.SlEntry > 0 ? t.SlEntry : t.SlFinal;
            if (sl <= 0) return double.NaN;
            bool lossSide = t.Buy ? sl < t.OpenPrice : sl > t.OpenPrice;
            double move = Math.Abs(t.ClosePrice - t.OpenPrice);
            if (!lossSide || move <= t.OpenPrice * 1e-9 || Math.Abs(t.Profit) < 0.005) return double.NaN;
            double balance = j.Balance - j.Trades.Where(x => x.Close > t.Open).Sum(x => x.Net) - j.Cash.Where(x => x.Time > t.Open).Sum(x => x.Amount);
            if (balance <= 0) return double.NaN;
            return Math.Abs(t.Profit) * Math.Abs(t.OpenPrice - sl) / move / balance * 100;
        }

        /// <summary>A position's risk in percent of the balance: the money at its Stop Loss (on the entry order, otherwise its current one),
        /// from its own floating result and the price's move. NaN without a Stop Loss on the losing side or when the price has not moved.</summary>
        public static double OpenRisk(JournalOpen o, double balance)
        {
            double sl = o.SlEntry > 0 ? o.SlEntry : o.Sl;
            if (sl <= 0 || balance <= 0 || o.Price <= 0) return double.NaN;
            bool lossSide = o.Buy ? sl < o.OpenPrice : sl > o.OpenPrice;
            if (!lossSide) return double.NaN;
            double move = Math.Abs(o.Price - o.OpenPrice);
            if (move <= o.OpenPrice * 1e-9 || Math.Abs(o.Profit) < 0.005) return double.NaN;
            return Math.Abs(o.Profit) * Math.Abs(o.OpenPrice - sl) / move / balance * 100;
        }

        static double C(double v) { double r = Math.Round(v, 2, MidpointRounding.AwayFromZero); return r == 0 ? 0 : r; }

        /// <summary>Money with its sign: "+$38.20", "-12.60 EUR" (no sign at zero).</summary>
        public static string Money(double v, string currency)
        {
            v = C(v);
            string sign = v > 0 ? "+" : v < 0 ? "-" : "";
            string n = Math.Abs(v).ToString("#,##0.00", Inv);
            string cur = (currency ?? "").Trim().ToUpperInvariant();
            if (cur == "USD" || cur == "USC" || cur.Length == 0) return sign + (cur == "USD" ? "$" : "") + n + (cur == "USC" ? " ¢" : "");
            return sign + n + " " + cur;
        }

        /// <summary>3.25: an amount without a plus sign (a balance): "$3,033.33", "-$12.00", "1,250.00 EUR".</summary>
        public static string Amount(double v, string currency) { return Money(v, currency).TrimStart('+'); }

        public static string Pct(double v) { return double.IsNaN(v) ? "—" : v.ToString("0.0", Inv) + "%"; }

        /// <summary>The list's «امروز» cell: "3 trades · +$38.20 · 1 No SL", or "No trades today".</summary>
        public static string Short(PanelView v)
        {
            if (v.TradeCount == 0) return "No trades today";
            string dd = "DD" + (Finite(v.AccountDdPct) ? (v.AccountDdPct > 0 ? "-" : "") + v.AccountDdPct.ToString("0.##", Inv) + "%" : "?");
            Func<IEnumerable<PanelTrade>, string> stop = trades => trades.Any(t => t.Stop == StopKind.Unprotected) ? "No SL" : "SL";
            var parts = new List<string>();
            var closed = v.Trades.Where(t => t.Closed && t.Close >= v.Range.From && t.Close < v.Range.To).ToList();
            var open = v.Trades.Where(t => !t.Closed).ToList();
            if (closed.Count > 0) parts.Add(CompactMoney(v.ClosedNet) + "/" + stop(closed) + "/" + dd);
            if (open.Count > 0) parts.Add("O/" + (v.ReachesNow ? CompactMoney(open.Sum(t => t.Net)) : "?") + "/" + stop(open) + "/" + dd);
            return parts.Count == 0 ? "No closed trades in range" : string.Join(" · ", parts);
        }

        static string CompactMoney(double value)
        { return !Finite(value) ? "?" : (C(value) > 0 ? "+" : "") + C(value).ToString("0.##", Inv); }

        /// <summary>How long ago, in Persian: «همین الان»، «۷ دقیقه پیش»، «۲ ساعت پیش»، «دیروز ۱۸:۲۰»، «2026.11.03».</summary>
        public static string Ago(DateTime then, DateTime now)
        {
            TimeSpan d = now - then;
            if (d < TimeSpan.FromMinutes(1)) return Lang.T("همین الان", "Just now");
            if (d < TimeSpan.FromHours(1)) return Fa.N((int)d.TotalMinutes) + Lang.T(" دقیقه پیش", " min ago");
            if (then.Date == now.Date) return Fa.N((int)d.TotalHours) + Lang.T(" ساعت پیش", " h ago");
            if (then.Date == now.Date.AddDays(-1)) return Lang.T("دیروز ", "Yesterday ") + TextUtil.PersianDigits(then.ToString("HH:mm", Inv));
            return Gd.Date(then);
        }
    }

    // ================================================================== 3.22.1: the day as text, to send

    /// <summary>One student's day in the coach's own message format (approved 2026.11.11, tidied 2026.11.12): the trades closed that day
    /// with the time each opened and closed, the day's numbers, the Stop Loss line (correct when every trade opened that day had one,
    /// put on with the order or after it; otherwise not correct, how many had none, and each of them with its times), the positions
    /// still open, and a rule under it.</summary>
    public static class DayText
    {
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
        const string NL = "\r\n";

        /// <summary>A time of the day shown; the date too when it is another day's.</summary>
        static string At(DateTime t, DateTime day) { return t.ToString(t.Date == day ? "HH:mm:ss" : "yyyy.MM.dd HH:mm:ss", Inv); }

        static string What(PanelTrade t) { return t.Symbol + (t.Buy ? " BUY" : " SELL"); }

        static string Lots(double v) { return v.ToString("0.00", Inv); }

        /// <summary>"09:14:05 → 09:51:00", or "13:05:00 → open" for one still open.</summary>
        static string Times(PanelTrade t, DateTime day) { return At(t.Open, day) + " → " + (t.Closed ? At(t.Close, day) : "open"); }

        static string Count(int n) { return n.ToString(Inv) + (n == 1 ? " trade" : " trades"); }

        static bool Closed(PanelTrade t, PanelView v) { return t.Closed && t.Close >= v.Range.From && t.Close < v.Range.To; }

        /// <summary>The text for one day (the range of a single day); number: the student's place in the list.</summary>
        public static string Make(int number, string name, string login, PanelView v)
        {
            DateTime day = v.Range.From.Date;
            var b = new StringBuilder();
            b.Append(number.ToString(Inv)).Append(". ").Append((name ?? "").Trim()).Append(NL);
            b.Append("MASTER Account: ").Append((login ?? "").Trim()).Append(NL).Append(NL);

            List<PanelTrade> closed = v.Trades.Where(t => Closed(t, v)).OrderBy(t => t.Open).ThenBy(t => t.Ticket).ToList();
            foreach (PanelTrade t in closed)
                b.Append(Times(t, day)).Append(" | ").Append(What(t)).Append(" | ").Append(Lots(t.Lots)).Append(" Lot | ").Append(PanelMath.Money(t.Net, v.Currency)).Append(NL);
            if (closed.Count == 0) b.Append("No closed trades").Append(NL);
            b.Append(NL);

            double net = closed.Sum(t => t.Net);
            int wins = closed.Count(t => Math.Round(t.Net, 2) > 0), losses = closed.Count(t => Math.Round(t.Net, 2) < 0);
            b.Append("MASTER NET: ").Append(PanelMath.Money(net, v.Currency)).Append(NL);
            b.Append("MASTER LOTS: ").Append(Lots(closed.Sum(t => t.Lots))).Append(NL);
            b.Append("MASTER Trades: ").Append(closed.Count.ToString(Inv)).Append(" | W/L: ").Append(wins.ToString(Inv)).Append(" / ").Append(losses.ToString(Inv)).Append(NL);
            b.Append("Zero P/L: ").Append((closed.Count - wins - losses).ToString(Inv)).Append(NL);
            if (!v.FloatingDisabled) b.Append("D/D: ").Append(PanelMath.Pct(v.DdPct)).Append(NL);
            b.Append(PanelMath.DdText(v)).Append(NL);
            b.Append("Return: ").Append(double.IsNaN(v.ReturnPct) ? "—" : (Math.Round(v.ReturnPct, 2) > 0 ? "+" : "") + Math.Round(v.ReturnPct, 2).ToString("0.00", Inv) + "%").Append(NL);
            b.Append(NL);

            // The Stop Loss of the trades opened this day (one opened before was counted on its own day). 3.22.2 (the coach's rule): a
            // Stop Loss put on after the entry is correct; only a trade that never had one is not.
            List<PanelTrade> opened = v.Trades.Where(t => t.OpenedInRange).ToList();
            List<PanelTrade> none = opened.Where(t => t.Stop == StopKind.Unprotected).ToList();
            if (opened.Count == 0) b.Append("SL: no trades opened").Append(NL);
            else if (none.Count == 0) b.Append("SL: correct | ").Append(Count(opened.Count)).Append(" with SL").Append(NL);
            else
            {
                b.Append("SL: not correct | ").Append(Count(none.Count)).Append(" without SL").Append(NL);
                foreach (PanelTrade t in none) b.Append("No SL: ").Append(Times(t, day)).Append(" | ").Append(What(t)).Append(NL);
            }

            // Still open, or (a day gone by) opened that day and closed after it.
            List<PanelTrade> open = v.Trades.Where(t => !t.Closed || (t.OpenedInRange && !Closed(t, v))).ToList();
            if (open.Count > 0) b.Append(NL);
            foreach (PanelTrade t in open)
            {
                b.Append("Open: ").Append(At(t.Open, day)).Append(" | ").Append(What(t)).Append(" | ").Append(Lots(t.Lots)).Append(" Lot | ").Append(PanelMath.Money(t.Net, v.Currency));
                b.Append(t.Closed ? " (closed " + At(t.Close, day) + ")" : " (floating)").Append(NL);
            }
            b.Append("------");
            return b.ToString();
        }
    }

    // ================================================================== 3.25: the report text of several students

    /// <summary>What «متن گزارش» puts in the text (approved mockup); the coach ticks them, and the ticks are remembered.</summary>
    [Flags]
    public enum TextParts
    {
        None = 0, Date = 1, Name = 2, Balance = 4, Trades = 8, Net = 16, Lots = 32, Count = 64, Zero = 128, Dd = 256, Return = 512, Sl = 1024, Open = 2048,
        All = 4095,
    }

    /// <summary>One student in a report text: their place in the list, name, account and the range's numbers (null: not read yet).</summary>
    public sealed class TextEntry
    {
        public int Number;
        public string Name, Login;
        public PanelView View;
    }

    /// <summary>3.25 (approved): the students one after another, each ended by a long rule as wide as a phone's message, for any range
    /// (one day, this week, this month, two dates). Only the parts ticked are written. «کپی متن روز» on a student's page stays DayText.Make.</summary>
    public static class ReportText
    {
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
        const string NL = "\r\n";
        public const string Rule = "━━━━━━━━━━━━━━━━━━━━";

        /// <summary>The parts and their Persian names, in the order of the window.</summary>
        public static KeyValuePair<TextParts, string>[] Names { get { return new KeyValuePair<TextParts, string>[] {
            new KeyValuePair<TextParts, string>(TextParts.Date, Lang.T("تاریخ گزارش (بالای متن)", "Report date (top of the text)")),
            new KeyValuePair<TextParts, string>(TextParts.Name, Lang.T("نام و شماره حساب", "Name & account")),
            new KeyValuePair<TextParts, string>(TextParts.Balance, Lang.T("بالانس", "Balance")),
            new KeyValuePair<TextParts, string>(TextParts.Trades, Lang.T("معامله‌ها (ساعت باز ← بسته، لات، سود/زیان)", "Trades (open → close time, lots, profit/loss)")),
            new KeyValuePair<TextParts, string>(TextParts.Net, "NET"),
            new KeyValuePair<TextParts, string>(TextParts.Lots, "LOTS"),
            new KeyValuePair<TextParts, string>(TextParts.Count, Lang.T("تعداد معامله و W/L", "Trade count and W/L")),
            new KeyValuePair<TextParts, string>(TextParts.Zero, "Zero P/L"),
            new KeyValuePair<TextParts, string>(TextParts.Dd, "D/D"),
            new KeyValuePair<TextParts, string>(TextParts.Return, "Return"),
            new KeyValuePair<TextParts, string>(TextParts.Sl, Lang.T("حد ضرر (SL) و معامله‌های بدون SL", "Stop loss (SL) and trades without SL")),
            new KeyValuePair<TextParts, string>(TextParts.Open, Lang.T("معامله‌های باز", "Open trades")),
        }; } }

        static string Day(DateTime d) { return d.ToString("ddd yyyy.MM.dd", Inv); }

        /// <summary>"Report: Thu 2026.11.12", or "Report: 2026.11.09 – 2026.11.12" for several days.</summary>
        public static string Heading(ReportRange r)
        {
            if (ServerDays.SingleDay(r)) return "Report: " + Day(r.From.Date);
            DateTime last = r.To > r.From ? r.To.AddTicks(-1).Date : r.From.Date;
            return "Report: " + r.From.ToString("yyyy.MM.dd", Inv) + " – " + last.ToString("yyyy.MM.dd", Inv);
        }

        /// <summary>A time in the text: one day's own times alone; over several days the date too (the close only when another day).</summary>
        static string At(DateTime t, DateTime? day) { return t.ToString(day.HasValue && t.Date == day.Value ? "HH:mm:ss" : "yyyy.MM.dd HH:mm:ss", Inv); }

        static string Times(PanelTrade t, DateTime? day)
        {
            return At(t.Open, day) + " → " + (t.Closed ? At(t.Close, day ?? t.Open.Date) : "open");
        }

        static string What(PanelTrade t) { return t.Symbol + (t.Buy ? " BUY" : " SELL"); }

        static string Lots(double v) { return v.ToString("0.00", Inv); }

        static string Count(int n) { return n.ToString(Inv) + (n == 1 ? " trade" : " trades"); }

        static bool Closed(PanelTrade t, PanelView v) { return t.Closed && t.Close >= v.Range.From && t.Close < v.Range.To; }

        /// <summary>One student's part of the text, ended by the rule; blocks are kept apart by one empty line.</summary>
        public static string Student(TextEntry e, TextParts parts)
        {
            var blocks = new List<string>();
            var head = new StringBuilder();
            if ((parts & TextParts.Name) != 0)
            {
                head.Append(e.Number.ToString(Inv)).Append(". ").Append((e.Name ?? "").Trim()).Append(NL);
                head.Append("MASTER Account: ").Append((e.Login ?? "").Trim()).Append(NL);
            }
            PanelView v = e.View;
            if (v == null)
            {
                head.Append("Not read yet").Append(NL);
                return head.ToString() + Rule;
            }
            if ((parts & TextParts.Balance) != 0) head.Append("Balance: ").Append(PanelMath.Amount(v.Balance, v.Currency)).Append(NL);
            if (head.Length > 0) blocks.Add(head.ToString());

            DateTime? day = v.SingleDay ? (DateTime?)v.Range.From.Date : null;
            List<PanelTrade> closed = v.Trades.Where(t => Closed(t, v)).OrderBy(t => t.Open).ThenBy(t => t.Ticket).ToList();
            if ((parts & TextParts.Trades) != 0)
            {
                var b = new StringBuilder();
                foreach (PanelTrade t in closed)
                    b.Append(Times(t, day)).Append(" | ").Append(What(t)).Append(" | ").Append(Lots(t.Lots)).Append(" Lot | ").Append(PanelMath.Money(t.Net, v.Currency)).Append(NL);
                if (closed.Count == 0) b.Append("No closed trades").Append(NL);
                blocks.Add(b.ToString());
            }

            var n = new StringBuilder();
            double net = closed.Sum(t => t.Net);
            int wins = closed.Count(t => Math.Round(t.Net, 2) > 0), losses = closed.Count(t => Math.Round(t.Net, 2) < 0);
            if ((parts & TextParts.Net) != 0) n.Append("MASTER NET: ").Append(PanelMath.Money(net, v.Currency)).Append(NL);
            if ((parts & TextParts.Lots) != 0) n.Append("MASTER LOTS: ").Append(Lots(closed.Sum(t => t.Lots))).Append(NL);
            if ((parts & TextParts.Count) != 0)
                n.Append("MASTER Trades: ").Append(closed.Count.ToString(Inv)).Append(" | W/L: ").Append(wins.ToString(Inv)).Append(" / ").Append(losses.ToString(Inv)).Append(NL);
            if ((parts & TextParts.Zero) != 0) n.Append("Zero P/L: ").Append((closed.Count - wins - losses).ToString(Inv)).Append(NL);
            // One day: that day's drawdown; several: the largest fall of the balance in them.
            if ((parts & TextParts.Dd) != 0)
            {
                if (!v.FloatingDisabled) n.Append(v.SingleDay ? "D/D: " : "Max D/D: ").Append(PanelMath.Pct(v.DdPct)).Append(NL);
                n.Append(PanelMath.DdText(v)).Append(NL);
            }
            if ((parts & TextParts.Return) != 0)
                n.Append("Return: ").Append(double.IsNaN(v.ReturnPct) ? "—" : (Math.Round(v.ReturnPct, 2) > 0 ? "+" : "") + Math.Round(v.ReturnPct, 2).ToString("0.00", Inv) + "%").Append(NL);
            if (n.Length > 0) blocks.Add(n.ToString());

            if ((parts & TextParts.Sl) != 0)
            {
                // The coach's rule (3.22.2): a Stop Loss put on after the entry is correct; only a trade that never had one is not.
                var b = new StringBuilder();
                List<PanelTrade> opened = v.Trades.Where(t => t.OpenedInRange).ToList();
                List<PanelTrade> none = opened.Where(t => t.Stop == StopKind.Unprotected).ToList();
                if (opened.Count == 0) b.Append("SL: no trades opened").Append(NL);
                else if (none.Count == 0) b.Append("SL: correct | ").Append(Count(opened.Count)).Append(" with SL").Append(NL);
                else
                {
                    b.Append("SL: not correct | ").Append(Count(none.Count)).Append(" without SL").Append(NL);
                    foreach (PanelTrade t in none) b.Append("No SL: ").Append(Times(t, day)).Append(" | ").Append(What(t)).Append(NL);
                }
                blocks.Add(b.ToString());
            }

            if ((parts & TextParts.Open) != 0)
            {
                List<PanelTrade> open = v.Trades.Where(t => !t.Closed || (t.OpenedInRange && !Closed(t, v))).ToList();
                if (open.Count > 0)
                {
                    var b = new StringBuilder();
                    foreach (PanelTrade t in open)
                    {
                        b.Append("Open: ").Append(At(t.Open, day)).Append(" | ").Append(What(t)).Append(" | ").Append(Lots(t.Lots)).Append(" Lot | ").Append(PanelMath.Money(t.Net, v.Currency));
                        b.Append(t.Closed ? " (closed " + At(t.Close, day ?? t.Open.Date) + ")" : " (floating)").Append(NL);
                    }
                    blocks.Add(b.ToString());
                }
            }
            return string.Join(NL, blocks) + Rule;
        }

        /// <summary>The whole text: the date (when ticked), then each student, an empty line between them.</summary>
        public static string Make(ReportRange r, IEnumerable<TextEntry> entries, TextParts parts)
        {
            var list = entries.Select(e => Student(e, parts)).ToList();
            string body = string.Join(NL + NL, list);
            return (parts & TextParts.Date) != 0 ? Heading(r) + NL + NL + body : body;
        }

        /// <summary>The ticks as kept in settings.ini (a number); nothing kept: all of them.</summary>
        public static TextParts Parse(string s)
        {
            int n;
            if (!int.TryParse((s ?? "").Trim(), NumberStyles.Integer, Inv, out n) || n <= 0) return TextParts.All;
            return (TextParts)(n & (int)TextParts.All);
        }
    }

    // ================================================================== the status column

    /// <summary>3.21: whether a student still trades, from the history the program read: inactive after more than 14 trading days
    /// (Monday to Friday) without a trade; unknown before the first read.</summary>
    public enum Activity { Unknown, Active, Inactive }

    public static class ActivityRule
    {
        public const int TradingDays = 14;

        /// <summary>The trading days after one day, up to and with another.</summary>
        public static int TradingDaysAfter(DateTime last, DateTime today)
        {
            int n = 0;
            for (DateTime d = last.Date.AddDays(1); d <= today.Date; d = d.AddDays(1)) if (!ServerDays.Weekend(d)) n++;
            return n;
        }

        public static Activity Of(AccountJournal j, DateTime today)
        {
            if (j == null) return Activity.Unknown;
            if (j.Open.Count > 0) return Activity.Active;
            DateTime last = j.LastTrade;
            foreach (JournalTrade t in j.Trades) if (t.Close > last) last = t.Close;
            // Never traded: counted from the account's first record (its first deposit).
            if (last == DateTime.MinValue) last = j.FirstSeen;
            if (last == DateTime.MinValue) return Activity.Unknown;
            return TradingDaysAfter(last, today) > TradingDays ? Activity.Inactive : Activity.Active;
        }
    }

    // ================================================================== reading again by itself

    /// <summary>3.21: a folder can have its students read again by itself every 15, 30 or 60 minutes, while the program is open.</summary>
    public static class AutoRefresh
    {
        public static readonly int[] Choices = { 0, 15, 30, 60 };
        public const string Key = "AutoRefresh";
        /// <summary>A round starts again no sooner than this after the last one ended (a long round never runs into the next).</summary>
        public static readonly TimeSpan Rest = TimeSpan.FromMinutes(5);
        /// <summary>Reading waits while the computer has less free memory than this.</summary>
        public const ulong MinFreeMb = 1500;

        public static int Clamp(int minutes) { return Choices.Contains(minutes) ? minutes : 0; }

        public static int Of(Folder f)
        {
            if (f == null) return 0;
            foreach (string e in f.Extra)
            {
                int eq = e.IndexOf('=');
                if (eq <= 0 || e.Substring(0, eq).Trim() != Key) continue;
                int m;
                if (int.TryParse(e.Substring(eq + 1).Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out m)) return Clamp(m);
            }
            return 0;
        }

        public static void Set(Folder f, int minutes)
        {
            f.Extra.RemoveAll(e => { int eq = e.IndexOf('='); return eq > 0 && e.Substring(0, eq).Trim() == Key; });
            minutes = Clamp(minutes);
            if (minutes > 0) f.Extra.Add(Key + "=" + minutes.ToString(CultureInfo.InvariantCulture));
        }

        /// <summary>When a folder's next round starts: its interval after the last one began, and never sooner than Rest after it ended.</summary>
        public static DateTime Next(DateTime lastStart, DateTime lastEnd, int minutes)
        {
            DateTime a = lastStart.AddMinutes(minutes), b = lastEnd + Rest;
            return a > b ? a : b;
        }

        public static string Text(int minutes) { return minutes <= 0 ? Lang.T("خاموش", "Off") : Lang.T("هر ", "Every ") + Fa.N(minutes) + Lang.T(" دقیقه", " min"); }
    }

    // ================================================================== the order of the list

    /// <summary>3.21: the order of the list's rows, set by dragging them; one copy name a line in %APPDATA%\MT Manager\order.txt
    /// (a file of its own: the data files and their version stay as they were). Copies not in it follow, by name.</summary>
    /// <summary>3.23: the ways «مرتب‌سازی» arranges the list.</summary>
    public enum ListSort { Mt4First, Mt5First, Name, Account }

    /// <summary>One copy in the list, for «مرتب‌سازی».</summary>
    public sealed class ListEntry
    {
        public string Name = "", Kind = "", Student = "", Login = "";
    }

    public static class ListOrder
    {
        public static string FilePath { get { return Path.Combine(AppPaths.DataDir, "order.txt"); } }

        public static List<string> Load()
        {
            try
            {
                if (!File.Exists(FilePath)) return new List<string>();
                return File.ReadAllLines(FilePath).Select(l => l.Trim()).Where(l => l.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            }
            catch (Exception e) { Log.Write("order: " + e.Message); return new List<string>(); }
        }

        public static void Save(IEnumerable<string> names)
        {
            Directory.CreateDirectory(AppPaths.DataDir);
            TextUtil.WriteLinesSafely(FilePath, names);
        }

        /// <summary>The copies in the saved order; those not in it after, in the order given (by name).</summary>
        public static List<T> Apply<T>(IEnumerable<T> items, Func<T, string> name, IList<string> order)
        {
            var at = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (int k = 0; k < order.Count; k++) if (!at.ContainsKey(order[k])) at[order[k]] = k;
            List<T> list = items.ToList();
            var index = new Dictionary<T, int>();
            for (int k = 0; k < list.Count; k++) index[list[k]] = k;
            return list.OrderBy(x => { int p; return at.TryGetValue(name(x), out p) ? p : order.Count + index[x]; }).ToList();
        }

        /// <summary>3.23: «مرتب‌سازی»: the whole list arranged once (the rows can be dragged again after). MT4 first or MT5 first keeps
        /// the order within each; by the student's name in the Persian alphabet (Latin names after, copies without an account last);
        /// by account number (none last). Ties keep the order they had.</summary>
        public static List<string> Arrange(IList<ListEntry> entries, ListSort how)
        {
            var list = entries.Select((e, k) => new { e, k }).ToList();
            IEnumerable<string> sorted;
            switch (how)
            {
                case ListSort.Mt4First:
                case ListSort.Mt5First:
                    string first = how == ListSort.Mt4First ? "MT4" : "MT5";
                    sorted = list.OrderBy(x => x.e.Kind == first ? 0 : 1).ThenBy(x => x.k).Select(x => x.e.Name);
                    break;
                case ListSort.Name:
                    sorted = list.OrderBy(x => x.e.Student.Trim().Length == 0 ? 1 : 0).ThenBy(x => NameKey(x.e.Student), KeyOrder.Instance)
                                 .ThenBy(x => x.k).Select(x => x.e.Name);
                    break;
                default:
                    sorted = list.OrderBy(x => AccountNumber(x.e.Login) < 0 ? 1 : 0).ThenBy(x => AccountNumber(x.e.Login)).ThenBy(x => x.k).Select(x => x.e.Name);
                    break;
            }
            return sorted.ToList();
        }

        const string Persian = "اآبپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی";

        /// <summary>A name as numbers in the order of the Persian alphabet (Arabic forms of the same letters count as them); then Latin
        /// letters, digits first; spaces part the words; anything else is left out.</summary>
        public static int[] NameKey(string name)
        {
            var key = new List<int>();
            foreach (char raw in (name ?? "").Trim())
            {
                char c = raw == 'ي' || raw == 'ى' || raw == 'ئ' ? 'ی' : raw == 'ك' ? 'ک' : raw == 'أ' || raw == 'إ' || raw == 'ٱ' ? 'ا' : raw == 'ة' ? 'ه' : raw == 'ؤ' ? 'و' : raw;
                int p = Persian.IndexOf(c);
                if (p >= 0) key.Add(100 + p);
                else if (c >= '0' && c <= '9') key.Add(10 + c - '0');
                else if (c >= '۰' && c <= '۹') key.Add(10 + c - '۰');
                else if (char.IsLetter(c) && c < 0x250) key.Add(200 + char.ToLowerInvariant(c));
                else if (c == ' ' && key.Count > 0 && key[key.Count - 1] != 0) key.Add(0);
            }
            return key.ToArray();
        }

        sealed class KeyOrder : IComparer<int[]>
        {
            public static readonly KeyOrder Instance = new KeyOrder();
            public int Compare(int[] a, int[] b)
            {
                for (int k = 0; k < Math.Min(a.Length, b.Length); k++) if (a[k] != b[k]) return a[k].CompareTo(b[k]);
                return a.Length.CompareTo(b.Length);
            }
        }

        static long AccountNumber(string login)
        {
            long n;
            string digits = new string(TextUtil.LatinDigits(login ?? "").Where(char.IsDigit).ToArray());
            return digits.Length > 0 && digits.Length <= 18 && long.TryParse(digits, NumberStyles.None, CultureInfo.InvariantCulture, out n) ? n : -1;
        }
    }
}

#if SNAPSHOT
namespace MTManager
{
    /// <summary>Made-up histories for the screenshots (no real person or account).</summary>
    public static class SampleJournals
    {
        static JournalTrade T(long id, string sym, bool buy, double lots, DateTime open, int minutes, double openPrice, double closePrice, double slEntry, double slFinal, double profit, double commission = 0)
        {
            return new JournalTrade
            {
                Ticket = id, Symbol = sym, Buy = buy, Volume = lots, Open = open, Close = open.AddMinutes(minutes), OpenPrice = openPrice, ClosePrice = closePrice,
                SlEntry = slEntry, SlFinal = slFinal, Profit = profit, Commission = commission,
            };
        }

        /// <summary>A student's month: a few trades a day with a Stop Loss on the order; today as given (todayKind: 0 none, 1 a quiet good
        /// day, 2 the approved mockup's day: a late Stop Loss, one without any after a loss, an open position); inactive: nothing for
        /// the last twenty trading days.</summary>
        public static AccountJournal Make(string login, string platform, double deposit, DateTime today, int seed, int todayKind, bool inactive)
        {
            var rnd = new Random(seed);
            DateTime now = today.AddHours(14).AddMinutes(22);
            var j = new AccountJournal { Platform = platform, Login = login, Server = "WMMarkets-Real1", Currency = "USD", From = today.AddDays(-40), Exported = now, Complete = true, GmtOffset = 7200, ScriptVersion = "1.20" };
            j.TrustedFrom = j.From;
            j.HistoryChecked = j.HistoryOk = true;
            j.Cash.Add(new JournalCash { Time = today.AddDays(-39).AddHours(10), Amount = deposit, Comment = "Deposit" });
            long id = 5100000 + seed * 1000;
            bool mt4 = platform == "MT4";
            int lastDay = inactive ? 28 : 1;
            for (int back = 38; back >= lastDay; back--)
            {
                DateTime d = today.AddDays(-back);
                if (ServerDays.Weekend(d)) continue;
                int n = rnd.Next(0, 4);
                for (int k = 0; k < n; k++)
                {
                    DateTime open = d.AddHours(9 + rnd.Next(0, 8)).AddMinutes(rnd.Next(0, 60));
                    bool buy = rnd.Next(2) == 0, gold = rnd.Next(3) == 0;
                    double lots = gold ? 0.1 : Math.Round(0.2 + rnd.Next(0, 4) * 0.1, 2);
                    double price = gold ? 2390 : 1.085, unit = gold ? 100 : 100000;
                    double move = (rnd.NextDouble() - 0.42) * (gold ? 6 : 0.0012);
                    double close = price + (buy ? move : -move);
                    double sl = Math.Round(buy ? price - (gold ? 3 : 0.001) : price + (gold ? 3 : 0.001), 5);
                    bool late = rnd.Next(12) == 0;
                    j.Trades.Add(T(id++, gold ? "XAUUSD" : "EURUSD", buy, lots, open, 15 + rnd.Next(0, 120), price, Math.Round(close, 5),
                                   mt4 ? -1 : late ? 0 : sl, sl, Math.Round(move * unit * lots, 2), mt4 ? 0 : -Math.Round(lots * 7, 2)));
                }
            }
            if (todayKind == 1)
            {
                j.Trades.Add(T(id++, "EURUSD", true, 0.3, today.AddHours(9).AddMinutes(40), 55, 1.08400, 1.08520, mt4 ? -1 : 1.08300, 1.08300, 36.0, mt4 ? 0 : -2.1));
                j.Trades.Add(T(id++, "XAUUSD", false, 0.1, today.AddHours(11).AddMinutes(5), 32, 2391.0, 2392.4, mt4 ? -1 : 2394.0, 2394.0, -14.0, mt4 ? 0 : -0.7));
            }
            else if (todayKind == 2)
            {
                // The approved mockup's day.
                j.Trades.Add(T(id++, "XAUUSD", true, 0.10, today.AddHours(9).AddMinutes(14), 37, 2390.00, 2393.10, 2387.10, 2387.10, 31.00));
                j.Trades.Add(T(id++, "EURUSD", false, 0.50, today.AddHours(10).AddMinutes(2), 3, 1.08500, 1.085252, 0, 1.08600, -12.60));
                j.Trades.Add(T(id++, "EURUSD", false, 0.50, today.AddHours(10).AddMinutes(9), 42, 1.08530, 1.08462, 0, 0, 34.00));
                j.Open.Add(new JournalOpen { Ticket = id++, Symbol = "GBPUSD", Buy = true, Volume = 0.30, Open = today.AddHours(13).AddMinutes(5), OpenPrice = 1.26500, Price = 1.26453, Sl = 1.26420, SlEntry = 1.26420, Profit = -14.10 });
            }
            j.Balance = Math.Round(deposit + j.Trades.Sum(t => t.Net), 2);
            j.Equity = j.Balance + j.Open.Sum(o => o.Profit + o.Swap);
            j.LastTrade = j.Trades.Count > 0 ? j.Trades.Max(t => t.Close) : DateTime.MinValue;
            foreach (JournalOpen o in j.Open) if (o.Open > j.LastTrade) j.LastTrade = o.Open;
            j.FirstSeen = j.Cash[0].Time;
            // A little floating loss while trades were open, for the drawdown.
            foreach (JournalTrade t in j.Trades.Where(x => x.Open >= today.AddDays(-10)))
                for (DateTime m = new DateTime(t.Open.Year, t.Open.Month, t.Open.Day, t.Open.Hour, t.Open.Minute, 0); m < t.Close; m = m.AddMinutes(5))
                {
                    double v;
                    j.Floating[m] = (j.Floating.TryGetValue(m, out v) ? v : 0) - Math.Abs(t.Profit) * 0.6;
                }
            return j;
        }
    }
}
#endif
