using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace MTManager
{
    // ================================================================== what the report script writes

    /// <summary>One balance event from the native reporter's whole selected history, independent of its trade-display window.</summary>
    public sealed class JournalBalanceEvent
    {
        public long TimeMilliseconds, Ticket;
        public int Type;
        public double Net;
        public DateTime Time { get { return new DateTime(1970, 1, 1).AddTicks(TimeMilliseconds * TimeSpan.TicksPerMillisecond); } }
        public JournalBalanceEvent Snapshot() { return (JournalBalanceEvent)MemberwiseClone(); }
    }

    /// <summary>One closed trade (MT5: one position, its partial closes added up; MT4: one order).</summary>
    public sealed class JournalTrade
    {
        public long Ticket;
        public string Symbol = "";
        public bool Buy;
        public double Volume;
        public DateTime Open, Close;
        public double OpenPrice, ClosePrice;
        /// <summary>The Stop Loss the trade was opened with; -1 when the platform does not keep it (MT4).</summary>
        public double SlEntry = -1;
        /// <summary>The Stop Loss at the close (MT4: the only one it keeps).</summary>
        public double SlFinal;
        public double Tp, Commission, Swap, Profit;
        public string Comment = "";
        public double Net { get { return Profit + Commission + Swap; } }
    }

    /// <summary>A position still open when the history was read.</summary>
    public sealed class JournalOpen
    {
        public long Ticket;
        public string Symbol = "";
        public bool Buy;
        public double Volume, OpenPrice, Sl, Tp, Profit, Swap;
        public DateTime Open;
        /// <summary>MT5 keeps the Stop Loss of the opening order; -1 when unknown.</summary>
        public double SlEntry = -1;
        /// <summary>3.21: the price when the history was read (0 in older files), and MT4's commission paid so far.</summary>
        public double Price, Commission;
    }

    /// <summary>Money in or out of the account: deposit, withdrawal, charge, correction. Not trading results.</summary>
    public sealed class JournalCash
    {
        public DateTime Time;
        public double Amount;
        public string Comment = "";
        /// <summary>3.21: the kind of money move as MT5 numbers deal types (2 balance, 3 credit, 4 charge, 5 correction, 6 bonus…;
        /// MT4: 2 balance, 3 credit). Credit is not in the balance: it is kept apart (AccountJournal.CreditMoves).</summary>
        public int Kind = 2;
        public const int CreditKind = 3;
    }

    /// <summary>3.18, for the statement: one MT5 deal of the range (entries, exits and money in or out alike).</summary>
    public sealed class JournalDeal
    {
        public long Ticket, Order, Position;
        public DateTime Time;
        /// <summary>MT5's ENUM_DEAL_TYPE (0 buy, 1 sell, 2 balance, 3 credit, …) and ENUM_DEAL_ENTRY (0 in, 1 out, 2 in/out, 3 out by).</summary>
        public int Type, Entry;
        public string Symbol = "", Comment = "";
        public double Volume, Price, Commission, Fee, Swap, Profit;
    }

    /// <summary>3.18, for the statement: an order of the range (MT5: every order; MT4: a pending order cancelled or expired), or one
    /// still waiting to be filled (Done is then empty).</summary>
    public sealed class JournalOrder
    {
        public long Ticket;
        public DateTime Setup, Done;
        /// <summary>The platform's own order type (MT5 ENUM_ORDER_TYPE, MT4 OP_*: the same numbers for the six usual ones) and state
        /// (MT5 ENUM_ORDER_STATE; -1 for MT4, which does not tell).</summary>
        public int Type, State = -1;
        public string Symbol = "", Comment = "";
        public double VolumeInitial, VolumeCurrent, Price, Sl, Tp;
    }

    /// <summary>One account's history as the report script read it, all times in the trading server's time.</summary>
    public sealed class AccountJournal
    {
        public string Platform = "", Login = "", Server = "", Currency = "", Company = "";
        public double Balance, Equity;
        /// <summary>When the script ran (server time) and from when it read.</summary>
        public DateTime Exported, From;
        public readonly List<JournalTrade> Trades = new List<JournalTrade>();
        public List<JournalOpen> Open { get; private set; } = new List<JournalOpen>();
        public readonly List<JournalCash> Cash = new List<JournalCash>();
        /// <summary>Per minute while any trade was open: the worst floating result of all of them in that minute
        /// (from the minute's high and low), in the account currency. The base of the approximate daily drawdown.</summary>
        public readonly SortedDictionary<DateTime, double> Floating = new SortedDictionary<DateTime, double>();
        /// <summary>The bars the drawdown was estimated from: "M1", or a coarser one when the terminal had no M1 history.</summary>
        public string FloatingBars = "M1";
        public const string TradesOnly = "trades-only";
        public bool FloatingDisabled { get { return FloatingBars == TradesOnly; } }
        public bool Complete;
        /// <summary>The trading server's clock less GMT when the script ran, in seconds; null when the script could not tell
        /// (MT4 over a weekend, or a file of 3.16 and before).</summary>
        public int? GmtOffset;
        /// <summary>3.18, for the statement: the account's leverage (0 when the file is older), margin, free margin and credit now.</summary>
        public int Leverage;
        public double Margin, FreeMargin, Credit;
        public readonly List<JournalDeal> Deals = new List<JournalDeal>();
        public readonly List<JournalOrder> Orders = new List<JournalOrder>();
        public readonly List<JournalOrder> Working = new List<JournalOrder>();
        /// <summary>Whether the file has what a statement needs beyond the trades (written by the 3.18 script or later).</summary>
        public bool HasStatementData { get { return Leverage > 0; } }
        /// <summary>3.21: credit given or taken back (not in the balance, so not among Cash).</summary>
        public readonly List<JournalCash> CreditMoves = new List<JournalCash>();
        /// <summary>3.21: the script's own version ("1.20"); empty for the scripts before it.</summary>
        public string ScriptVersion = "";
        public string RequestToken = "";
        /// <summary>3.21 (H line): the script added up the whole history; HistoryOk when it came to the balance (nothing missing).</summary>
        public bool HistoryChecked, HistoryOk;
        public double HistorySum, HistoryBalance;
        /// <summary>3.21 (L line): the last trade of the whole history (a deal, or an open position's entry) and the account's first record;
        /// DateTime.MinValue when there is none or the file is older.</summary>
        public DateTime LastTrade = DateTime.MinValue, FirstSeen = DateTime.MinValue;
        /// <summary>3.21: from when on the history was read by the 3.21 script (1.20) or later, which selects it to the end and checks
        /// it against the balance; DateTime.MaxValue when none of it was (the scripts before it could leave the last trades out).</summary>
        public DateTime TrustedFrom = DateTime.MaxValue;
        /// <summary>J/JC are a separate whole-selected-history proof. Old/windowed T/B/D rows never imply this coverage.</summary>
        public readonly List<JournalBalanceEvent> FullHistory = new List<JournalBalanceEvent>();
        public bool FullHistoryPresent, FullHistoryValid, FullHistoryReconciled, FullHistoryScanOk, FullHistoryRequested, FullHistoryBonusExcluded;
        public int FullHistoryCount;
        public double FullHistorySum, FullHistoryBalance;
        // Shares the validated, read-only history but owns its current-position list.
        internal AccountJournal WithCurrent(double balance, double equity, double margin, double free, double credit, DateTime exported, IEnumerable<JournalOpen> positions)
        {
            var copy=(AccountJournal)MemberwiseClone();
            copy.Open=new List<JournalOpen>(positions); copy.Balance=balance; copy.Equity=equity;
            copy.Margin=margin;copy.FreeMargin=free;copy.Credit=credit;copy.Exported=exported;
            return copy;
        }

    }

    /// <summary>Reads and writes the report script's file. One record per line, tab separated, invariant numbers,
    /// times as seconds since 1970 in server time:
    /// MTR version platform · A login server currency balance equity exported from company offset leverage margin free credit ·
    /// T closed trade · O open position · B cash · F minute worst-floating · M bars · D deal · R order · W working order ·
    /// J whole-history balance event · JC coverage proof · END count (T, O, B and J; legacy files without J remain readable).</summary>
    public static class JournalFile
    {
        public const int Version = 2;
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
        static readonly DateTime Epoch = new DateTime(1970, 1, 1);

        public static DateTime Time(string s)
        {
            long v;
            return long.TryParse(s, NumberStyles.Integer, Inv, out v) && v > 0 ? Epoch.AddSeconds(v) : DateTime.MinValue;
        }

        public static string Unix(DateTime t) { return ((long)(t - Epoch).TotalSeconds).ToString(Inv); }

        static double D(string s)
        {
            double v;
            return double.TryParse(s, NumberStyles.Float, Inv, out v) && !double.IsNaN(v) && !double.IsInfinity(v) ? v : 0;
        }

        static long L(string s)
        {
            long v;
            return long.TryParse(s, NumberStyles.Integer, Inv, out v) ? v : 0;
        }

        static string N(double v) { return v.ToString("R", Inv); }
        static bool FiniteNumber(string value, out double number)
        { return double.TryParse(value, NumberStyles.Float, Inv, out number) && !double.IsNaN(number) && !double.IsInfinity(number); }
        static bool Flag(string value) { return value == "0" || value == "1"; }

        /// <summary>Null when the text is not a report file at all; Complete is false when its END line is missing (cut short).</summary>
        public static AccountJournal Parse(string text)
        {
            if (string.IsNullOrEmpty(text)) return null;
            var j = new AccountJournal();
            bool header = false, sawV = false;
            int records = 0;
            bool curveBad = false, sawCurveCheck = false, sawEnd = false, balanceProof = false, historyProof = false, endProof = false;
            bool sawAccount = false, sawHistory = false, sawHeader = false;
            int curveRecords = 0, endRecords = -1;
            DateTime proofExported = DateTime.MinValue;
            var curveTickets = new HashSet<long>();
            foreach (string raw in text.Split('\n'))
            {
                string[] f = raw.TrimEnd('\r').Split('\t');
                if (f.Length == 0 || f[0].Length == 0) continue;
                switch (f[0])
                {
                    case "MTR":
                        if (sawHeader) curveBad = true;
                        sawHeader = true;
                        header = f.Length >= 3;
                        if (header) j.Platform = f[2];
                        if (f.Length > 4) j.ScriptVersion = f[4].Trim();
                        break;
                    case "H":
                        if (sawHistory) curveBad = true;
                        sawHistory = true;
                        if (f.Length < 4) break;
                        j.HistoryChecked = true;
                        j.HistoryOk = f[1] == "1";
                        j.HistorySum = D(f[2]);
                        j.HistoryBalance = D(f[3]);
                        double hs, hb;
                        historyProof = Flag(f[1]) && FiniteNumber(f[2], out hs) && FiniteNumber(f[3], out hb);
                        break;
                    case "V":
                        if (f.Length < 2) break;
                        sawV = true;
                        DateTime tf = Time(f[1]);
                        j.TrustedFrom = tf == DateTime.MinValue ? DateTime.MaxValue : tf;
                        break;
                    case "L":
                        if (f.Length < 3) break;
                        j.LastTrade = Time(f[1]);
                        j.FirstSeen = Time(f[2]);
                        break;
                    case "A":
                        if (sawAccount) curveBad = true;
                        sawAccount = true;
                        if (f.Length < 8) break;
                        j.Login = f[1]; j.Server = f[2]; j.Currency = f[3];
                        j.Balance = D(f[4]); j.Equity = D(f[5]); j.Exported = Time(f[6]); j.From = Time(f[7]);
                        proofExported = j.Exported;
                        double ab;
                        balanceProof = FiniteNumber(f[4], out ab);
                        if (f.Length > 8) j.Company = f[8];
                        long off;
                        if (f.Length > 9 && long.TryParse(f[9], NumberStyles.Integer, Inv, out off) && Math.Abs(off) <= 14 * 3600) j.GmtOffset = (int)off;
                        if (f.Length > 13)
                        {
                            long lev = L(f[10]);
                            j.Leverage = lev > 0 && lev <= 100000 ? (int)lev : 0;
                            j.Margin = D(f[11]); j.FreeMargin = D(f[12]); j.Credit = D(f[13]);
                        }
                        break;
                    case "J":
                        j.FullHistoryPresent = true; records++; curveRecords++;
                        long milliseconds, ticket; int eventType; double net;
                        if (sawEnd || f.Length != 5 || !long.TryParse(f[1], NumberStyles.None, Inv, out milliseconds)
                            || milliseconds <= 0 || milliseconds > 253402300799999L
                            || !long.TryParse(f[2], NumberStyles.None, Inv, out ticket) || ticket <= 0
                            || !int.TryParse(f[3], NumberStyles.None, Inv, out eventType) || eventType < 0 || eventType > 17 || eventType == JournalCash.CreditKind
                            || !FiniteNumber(f[4], out net) || !curveTickets.Add(ticket)) { curveBad = true; break; }
                        j.FullHistory.Add(new JournalBalanceEvent { TimeMilliseconds = milliseconds, Ticket = ticket, Type = eventType, Net = net });
                        break;
                    case "JC":
                        j.FullHistoryPresent = true;
                        if (sawCurveCheck || sawEnd) curveBad = true;
                        sawCurveCheck = true;
                        int curveCount; double curveSum, curveBalance;
                        if (f.Length != 9 || f[1] != "1" || !int.TryParse(f[2], NumberStyles.None, Inv, out curveCount) || curveCount < 0
                            || !FiniteNumber(f[3], out curveSum) || !FiniteNumber(f[4], out curveBalance)
                            || !Flag(f[5]) || !Flag(f[6]) || !Flag(f[7]) || !Flag(f[8])) { curveBad = true; break; }
                        j.FullHistoryCount = curveCount; j.FullHistorySum = curveSum; j.FullHistoryBalance = curveBalance;
                        j.FullHistoryReconciled = f[5] == "1"; j.FullHistoryScanOk = f[6] == "1";
                        j.FullHistoryRequested = f[7] == "1"; j.FullHistoryBonusExcluded = f[8] == "1";
                        break;
                    case "D":
                        if (f.Length < 15) break;
                        j.Deals.Add(new JournalDeal
                        {
                            Ticket = L(f[1]), Order = L(f[2]), Time = Time(f[3]), Type = (int)L(f[4]), Entry = (int)L(f[5]), Symbol = f[6],
                            Volume = D(f[7]), Price = D(f[8]), Commission = D(f[9]), Fee = D(f[10]), Swap = D(f[11]), Profit = D(f[12]),
                            Position = L(f[13]), Comment = f[14],
                        });
                        break;
                    case "R":
                        if (f.Length < 13) break;
                        j.Orders.Add(new JournalOrder
                        {
                            Ticket = L(f[1]), Setup = Time(f[2]), Symbol = f[3], Type = (int)L(f[4]), VolumeInitial = D(f[5]), VolumeCurrent = D(f[6]),
                            Price = D(f[7]), Sl = D(f[8]), Tp = D(f[9]), Done = Time(f[10]), State = (int)L(f[11]), Comment = f[12],
                        });
                        break;
                    case "W":
                        if (f.Length < 10) break;
                        j.Working.Add(new JournalOrder
                        {
                            Ticket = L(f[1]), Setup = Time(f[2]), Symbol = f[3], Type = (int)L(f[4]), VolumeInitial = D(f[5]), VolumeCurrent = D(f[5]),
                            Price = D(f[6]), Sl = D(f[7]), Tp = D(f[8]), Comment = f[9],
                        });
                        break;
                    case "T":
                        if (f.Length < 16) break;
                        j.Trades.Add(new JournalTrade
                        {
                            Ticket = L(f[1]), Symbol = f[2], Buy = f[3] == "0", Volume = D(f[4]),
                            Open = Time(f[5]), OpenPrice = D(f[6]), Close = Time(f[7]), ClosePrice = D(f[8]),
                            SlEntry = D(f[9]), SlFinal = D(f[10]), Tp = D(f[11]), Commission = D(f[12]), Swap = D(f[13]), Profit = D(f[14]),
                            Comment = f[15],
                        });
                        records++;
                        break;
                    case "O":
                        if (f.Length < 12) break;
                        j.Open.Add(new JournalOpen
                        {
                            Ticket = L(f[1]), Symbol = f[2], Buy = f[3] == "0", Volume = D(f[4]), Open = Time(f[5]), OpenPrice = D(f[6]),
                            Sl = D(f[7]), Tp = D(f[8]), Profit = D(f[9]), Swap = D(f[10]), SlEntry = D(f[11]),
                            Price = f.Length > 12 ? D(f[12]) : 0, Commission = f.Length > 13 ? D(f[13]) : 0,
                        });
                        records++;
                        break;
                    case "B":
                        if (f.Length < 3) break;
                        {
                            var c = new JournalCash { Time = Time(f[1]), Amount = D(f[2]), Comment = f.Length > 3 ? f[3] : "" };
                            long kind;
                            if (f.Length > 4 && long.TryParse(f[4], NumberStyles.Integer, Inv, out kind)) c.Kind = (int)kind;
                            (c.Kind == JournalCash.CreditKind ? j.CreditMoves : j.Cash).Add(c);
                        }
                        records++;
                        break;
                    case "Q":
                        if (f.Length >= 2) j.RequestToken = f[1];
                        break;
                    case "F":
                        if (f.Length < 3) break;
                        DateTime m = Time(f[1]);
                        if (m != DateTime.MinValue) j.Floating[m] = D(f[2]);
                        break;
                    case "M":
                        if (f.Length >= 2 && f[1].Length > 0) j.FloatingBars = f[1];
                        break;
                    case "END":
                        if (sawEnd) curveBad = true;
                        sawEnd = true;
                        endProof = f.Length == 2 && int.TryParse(f[1], NumberStyles.None, Inv, out endRecords);
                        j.Complete = header && L(f.Length > 1 ? f[1] : "") == records;
                        break;
                }
            }
            if (!header || j.Login.Length == 0) return null;
            if (sawEnd && endRecords != records) j.Complete = false;
            // The script's own file: all of it is from the 3.21 script when it says its version.
            if (!sawV && j.ScriptVersion.Length > 0) j.TrustedFrom = j.From;
            // 3.21: "now" is never before the last record (the scripts before 1.20 took it from the last price, which can be old,
            // and every trade after it was left out of the report).
            DateTime last = j.Exported;
            foreach (JournalTrade t in j.Trades) { if (t.Close > last) last = t.Close; }
            foreach (JournalOpen o in j.Open) { if (o.Open > last) last = o.Open; }
            foreach (JournalCash c in j.Cash) { if (c.Time > last) last = c.Time; }
            if (j.LastTrade > last) last = j.LastTrade;
            j.Exported = last;
            double curveTotal = j.FullHistory.Sum(x => x.Net);
            double tolerance = Math.Max(0.02, Math.Abs(j.Balance) * 0.000001);
            long exportMilliseconds = proofExported > Epoch ? (proofExported.Ticks - Epoch.Ticks) / TimeSpan.TicksPerMillisecond : 0;
            j.FullHistoryValid = j.Complete && endProof && sawCurveCheck && !curveBad && balanceProof && historyProof
                && (j.Platform == "MT4" || j.Platform == "MT5") && (!j.FullHistoryBonusExcluded || j.Platform == "MT5")
                && j.FullHistoryReconciled && j.FullHistoryScanOk && j.FullHistoryRequested && j.HistoryChecked && j.HistoryOk
                && curveRecords == j.FullHistoryCount && j.FullHistory.Count == curveRecords
                && !double.IsNaN(curveTotal) && !double.IsInfinity(curveTotal)
                && Math.Abs(curveTotal - j.FullHistorySum) <= tolerance && Math.Abs(j.FullHistorySum - j.FullHistoryBalance) <= tolerance
                && Math.Abs(j.FullHistoryBalance - j.Balance) <= tolerance && Math.Abs(j.HistoryBalance - j.Balance) <= tolerance
                && (j.FullHistoryBonusExcluded || Math.Abs(j.HistorySum - j.FullHistorySum) <= tolerance)
                && (!j.FullHistoryBonusExcluded || !j.FullHistory.Any(x => x.Type == 6))
                && j.FullHistory.All(x => x.TimeMilliseconds <= exportMilliseconds + 999);
            if (j.FloatingDisabled) j.Floating.Clear();
            return j;
        }

        /// <summary>The reason the script gives when it could read nothing ("ERR not connected"); null when it says none.</summary>
        public static string ErrorOf(string text)
        {
            if (string.IsNullOrEmpty(text) || !text.StartsWith("MTR\t", StringComparison.Ordinal)) return null;
            foreach (string raw in text.Split('\n'))
            {
                string l = raw.TrimEnd('\r');
                if (l.StartsWith("ERR\t", StringComparison.Ordinal)) return l.Substring(4).Trim();
            }
            return null;
        }

        public static string Write(AccountJournal j)
        {
            var sb = new StringBuilder();
            Action<string[]> line = f => sb.Append(string.Join("\t", f.Select(x => TextUtil.OneLine(x).Replace('\t', ' ')))).Append("\r\n");
            line(new[] { "MTR", Version.ToString(Inv), j.Platform, "", j.ScriptVersion });
            line(new[] { "A", j.Login, j.Server, j.Currency, N(j.Balance), N(j.Equity), Unix(j.Exported), Unix(j.From), j.Company,
                         j.GmtOffset.HasValue ? j.GmtOffset.Value.ToString(Inv) : "", j.Leverage.ToString(Inv), N(j.Margin), N(j.FreeMargin), N(j.Credit) });
            if (j.TrustedFrom != DateTime.MaxValue) line(new[] { "V", Unix(j.TrustedFrom) });
            if (j.HistoryChecked) line(new[] { "H", j.HistoryOk ? "1" : "0", N(j.HistorySum), N(j.HistoryBalance) });
            if (j.LastTrade > DateTime.MinValue || j.FirstSeen > DateTime.MinValue) line(new[] { "L", Unix(j.LastTrade), Unix(j.FirstSeen) });
            foreach (JournalBalanceEvent e in j.FullHistory)
                line(new[] { "J", e.TimeMilliseconds.ToString(Inv), e.Ticket.ToString(Inv), e.Type.ToString(Inv), N(e.Net) });
            if (j.FullHistoryPresent)
                line(new[] { "JC", "1", j.FullHistoryCount.ToString(Inv), N(j.FullHistorySum), N(j.FullHistoryBalance),
                    j.FullHistoryReconciled ? "1" : "0", j.FullHistoryScanOk && j.FullHistoryValid ? "1" : "0", j.FullHistoryRequested ? "1" : "0", j.FullHistoryBonusExcluded ? "1" : "0" });
            foreach (JournalTrade t in j.Trades)
                line(new[] { "T", t.Ticket.ToString(Inv), t.Symbol, t.Buy ? "0" : "1", N(t.Volume), Unix(t.Open), N(t.OpenPrice), Unix(t.Close), N(t.ClosePrice),
                             N(t.SlEntry), N(t.SlFinal), N(t.Tp), N(t.Commission), N(t.Swap), N(t.Profit), t.Comment });
            foreach (JournalOpen o in j.Open)
                line(new[] { "O", o.Ticket.ToString(Inv), o.Symbol, o.Buy ? "0" : "1", N(o.Volume), Unix(o.Open), N(o.OpenPrice), N(o.Sl), N(o.Tp), N(o.Profit), N(o.Swap), N(o.SlEntry),
                             N(o.Price), N(o.Commission) });
            foreach (JournalCash c in j.Cash.Concat(j.CreditMoves)) line(new[] { "B", Unix(c.Time), N(c.Amount), c.Comment, c.Kind.ToString(Inv) });
            foreach (JournalDeal d in j.Deals)
                line(new[] { "D", d.Ticket.ToString(Inv), d.Order.ToString(Inv), Unix(d.Time), d.Type.ToString(Inv), d.Entry.ToString(Inv), d.Symbol, N(d.Volume), N(d.Price),
                             N(d.Commission), N(d.Fee), N(d.Swap), N(d.Profit), d.Position.ToString(Inv), d.Comment });
            foreach (JournalOrder o in j.Orders)
                line(new[] { "R", o.Ticket.ToString(Inv), Unix(o.Setup), o.Symbol, o.Type.ToString(Inv), N(o.VolumeInitial), N(o.VolumeCurrent), N(o.Price), N(o.Sl), N(o.Tp),
                             Unix(o.Done), o.State.ToString(Inv), o.Comment });
            foreach (JournalOrder o in j.Working)
                line(new[] { "W", o.Ticket.ToString(Inv), Unix(o.Setup), o.Symbol, o.Type.ToString(Inv), N(o.VolumeCurrent), N(o.Price), N(o.Sl), N(o.Tp), o.Comment });
            line(new[] { "M", j.FloatingBars });
            foreach (KeyValuePair<DateTime, double> f in j.Floating) line(new[] { "F", Unix(f.Key), N(f.Value) });
            line(new[] { "END", (j.Trades.Count + j.Open.Count + j.Cash.Count + j.CreditMoves.Count + j.FullHistory.Count).ToString(Inv) });
            return sb.ToString();
        }
    }

    // ================================================================== kept on this computer between reports

    /// <summary>The last history read of each account, in %APPDATA%\MT Manager\journal (one file per account and server).
    /// Only on this computer; nothing is sent anywhere. A new read replaces the old one only when it is complete.</summary>
    public static class JournalCache
    {
        public static string Dir { get { return Path.Combine(AppPaths.DataDir, "journal"); } }

        public static string FileFor(string login, string server)
        {
            string name = TextUtil.OneLine(login) + "@" + TextUtil.OneLine(server);
            // What Windows does not allow in a file name, whatever system the program runs on.
            var sb = new StringBuilder(name.Length);
            foreach (char c in name) sb.Append(c < ' ' || "\\/:*?\"<>|".IndexOf(c) >= 0 ? '_' : c);
            name = sb.ToString();
            return Path.Combine(Dir, name + ".txt");
        }

        /// <summary>Keeps a complete read; returns false (and keeps the earlier one) for a read that was cut short.
        /// A read that starts later than the one kept is joined to it (see Merge), so a short report does not cut a longer history short.</summary>
        /// server: the account's server as the program has it (the key it is looked up by); the script's own name for it otherwise.
        static readonly object writeGate = new object();
        public static bool Save(AccountJournal j, string server = null)
        { lock(writeGate) return SaveCore(j,server); }
        internal static bool SaveLiveBaseline(AccountJournal j)
        {
            if(j==null || !j.Complete || !j.FullHistoryValid)return false;
            lock(writeGate)
            {
                var kept=Load(j.Login,j.Server);
                if(kept!=null && (kept.Exported>j.Exported || kept.Platform!=j.Platform))return false;
                return SaveCore(j);
            }
        }
        static bool SaveCore(AccountJournal j, string server = null)
        {
            if (j == null || !j.Complete) return false;
            Directory.CreateDirectory(Dir);
            string key = string.IsNullOrWhiteSpace(server) ? j.Server : server.Trim();
            AccountJournal kept = Merge(Load(j.Login, key), j);
            TextUtil.WriteLinesSafely(FileFor(j.Login, key), JournalFile.Write(kept).TrimEnd('\r', '\n').Split(new[] { "\r\n" }, StringSplitOptions.None));
            return true;
        }

        /// <summary>A new complete read joined to the one kept: the new one has everything from its first day on, the kept one
        /// adds what came before (trades closed, money paid and minutes before that day). Only when the kept one is complete,
        /// of the same account, starts earlier and reaches the new one's first day (no gap); otherwise the new read alone.</summary>
        public static AccountJournal Merge(AccountJournal kept, AccountJournal fresh)
        {
            if (fresh == null) return kept;
            if (!fresh.Complete) return fresh;
            if (kept == null || !kept.Complete || kept.Login != fresh.Login
                || !string.Equals(kept.Server, fresh.Server, StringComparison.OrdinalIgnoreCase)
                || !string.Equals(kept.Platform, fresh.Platform, StringComparison.OrdinalIgnoreCase)
                || kept.From >= fresh.From || kept.Exported < fresh.From) return fresh;
            var m = new AccountJournal
            {
                Platform = fresh.Platform, Login = fresh.Login, Server = fresh.Server, Currency = fresh.Currency, Company = fresh.Company,
                Balance = fresh.Balance, Equity = fresh.Equity, Exported = fresh.Exported, From = kept.From, Complete = true,
                GmtOffset = fresh.GmtOffset ?? kept.GmtOffset,
                FloatingBars = fresh.FloatingBars == "M1" ? kept.FloatingBars : fresh.FloatingBars,
                Leverage = fresh.Leverage > 0 ? fresh.Leverage : kept.Leverage, Margin = fresh.Margin, FreeMargin = fresh.FreeMargin, Credit = fresh.Credit,
                // The check and the last trade are about the whole history: the new read's hold.
                ScriptVersion = fresh.ScriptVersion,
                // Trusted from the kept read's start when it was trusted up to the new one; never when the new one is not.
                TrustedFrom = fresh.TrustedFrom == DateTime.MaxValue ? DateTime.MaxValue : kept.TrustedFrom <= fresh.From ? kept.TrustedFrom : fresh.TrustedFrom,
                HistoryChecked = fresh.HistoryChecked, HistoryOk = fresh.HistoryOk, HistorySum = fresh.HistorySum, HistoryBalance = fresh.HistoryBalance,
                LastTrade = fresh.LastTrade > kept.LastTrade ? fresh.LastTrade : kept.LastTrade,
                FirstSeen = fresh.FirstSeen > DateTime.MinValue ? fresh.FirstSeen : kept.FirstSeen,
                FullHistoryPresent = fresh.FullHistoryPresent, FullHistoryValid = fresh.FullHistoryValid,
                FullHistoryReconciled = fresh.FullHistoryReconciled, FullHistoryScanOk = fresh.FullHistoryScanOk,
                FullHistoryRequested = fresh.FullHistoryRequested, FullHistoryBonusExcluded = fresh.FullHistoryBonusExcluded,
                FullHistoryCount = fresh.FullHistoryCount, FullHistorySum = fresh.FullHistorySum, FullHistoryBalance = fresh.FullHistoryBalance,
            };
            m.FullHistory.AddRange(fresh.FullHistory.Select(e => e.Snapshot()));
            var deals = new HashSet<long>(fresh.Deals.Select(d => d.Ticket));
            m.Deals.AddRange(kept.Deals.Where(d => d.Time < fresh.From && !deals.Contains(d.Ticket)));
            m.Deals.AddRange(fresh.Deals);
            var orders = new HashSet<long>(fresh.Orders.Select(o => o.Ticket));
            m.Orders.AddRange(kept.Orders.Where(o => o.Setup < fresh.From && o.Done < fresh.From && !orders.Contains(o.Ticket)));
            m.Orders.AddRange(fresh.Orders);
            m.Working.AddRange(fresh.Working);
            var tickets = new HashSet<long>(fresh.Trades.Select(t => t.Ticket));
            m.Trades.AddRange(kept.Trades.Where(t => t.Close < fresh.From && !tickets.Contains(t.Ticket)));
            m.Trades.AddRange(fresh.Trades);
            m.Open.AddRange(fresh.Open);
            m.Cash.AddRange(kept.Cash.Where(c => c.Time < fresh.From));
            m.Cash.AddRange(fresh.Cash);
            m.CreditMoves.AddRange(kept.CreditMoves.Where(c => c.Time < fresh.From));
            m.CreditMoves.AddRange(fresh.CreditMoves);
            if (!fresh.FloatingDisabled)
            {
                foreach (KeyValuePair<DateTime, double> f in kept.Floating) if (f.Key < fresh.From) m.Floating[f.Key] = f.Value;
                foreach (KeyValuePair<DateTime, double> f in fresh.Floating) m.Floating[f.Key] = f.Value;
            }
            return m;
        }

        /// <summary>Whether a kept read covers a report from a day on (it began on that day or before).</summary>
        public static bool Covers(AccountJournal kept, DateTime from)
        {
            return kept != null && kept.Complete && kept.From > DateTime.MinValue && kept.From <= from;
        }

        /// <summary>3.21: whether a kept read covers a range from a day on with history read by the 3.21 script (see TrustedFrom).</summary>
        public static bool CoversTrusted(AccountJournal kept, DateTime from)
        {
            return Covers(kept, from) && kept.TrustedFrom <= from;
        }

        public static AccountJournal Load(string login, string server)
        {
            string path = FileFor(login, server);
            try { return File.Exists(path) ? JournalFile.Parse(File.ReadAllText(path, Encoding.UTF8)) : null; }
            catch (Exception e) { Log.Write("journal cache " + login + ": " + e.Message); return null; }
        }
    }

    // ================================================================== the range of a report

    public enum RangeKind { Today, ThisWeek, ThisMonth, Custom, AllHistory }

    /// <summary>A report's days, in the trading server's calendar: [From, To). Weeks start on Saturday (as in Iran; forex trades
    /// Monday to Friday, so this is the same trading week as one starting on Monday); months are calendar months.</summary>
    public sealed class ReportRange
    {
        public RangeKind Kind;
        public DateTime From, To;

        public static DateTime WeekStart(DateTime day)
        {
            int back = ((int)day.DayOfWeek - (int)DayOfWeek.Saturday + 7) % 7;
            return day.Date.AddDays(-back);
        }

        public static ReportRange Of(RangeKind kind, DateTime today, DateTime? from = null, DateTime? to = null)
        {
            DateTime d = today.Date;
            switch (kind)
            {
                case RangeKind.Today: return new ReportRange { Kind = kind, From = d, To = d.AddDays(1) };
                case RangeKind.ThisWeek: return new ReportRange { Kind = kind, From = WeekStart(d), To = d.AddDays(1) };
                case RangeKind.ThisMonth: return new ReportRange { Kind = kind, From = new DateTime(d.Year, d.Month, 1), To = d.AddDays(1) };
                case RangeKind.AllHistory: return new ReportRange { Kind = kind, From = AllFrom, To = d.AddDays(1) };
                default:
                    DateTime a = (from ?? d).Date, b = (to ?? d).Date;
                    if (b < a) { DateTime x = a; a = b; b = x; }
                    return new ReportRange { Kind = kind, From = a, To = b.AddDays(1) };
            }
        }

        public bool Contains(DateTime t) { return t >= From && t < To; }

        /// <summary>3.20: «همه‌ی تاریخچه» asks the script for everything from this day on (before any account of today).</summary>
        public static readonly DateTime AllFrom = new DateTime(2000, 1, 1);
        public bool IsAll { get { return Kind == RangeKind.AllHistory; } }

        /// <summary>The first day an account did anything in the range (a trade, money paid in or out); for «همه‌ی تاریخچه», where the
        /// range itself starts long before. DateTime.MaxValue when it did nothing.</summary>
        public static DateTime FirstActivity(AccountJournal j, DateTime from)
        {
            DateTime first = DateTime.MaxValue;
            foreach (JournalTrade t in j.Trades) if (t.Close >= from) { DateTime a = t.Open < from ? from : t.Open; if (a < first) first = a; }
            foreach (JournalCash c in j.Cash) if (c.Time >= from && c.Time < first) first = c.Time;
            foreach (JournalOpen o in j.Open) { DateTime a = o.Open < from ? from : o.Open; if (a < first) first = a; }
            return first;
        }

        public string Title
        {
            get
            {
                string days = Gd.Date(From) + (To.AddDays(-1) > From ? Lang.T(" تا ", " up to ") + Gd.Date(To.AddDays(-1)) : "");
                switch (Kind)
                {
                    case RangeKind.Today: return Lang.T("امروز (", "Today (") + days + ")";
                    case RangeKind.ThisWeek: return Lang.T("هفته‌ی جاری (", "This week (") + days + ")";
                    case RangeKind.ThisMonth: return Lang.T("ماه جاری (", "This month (") + days + ")";
                    case RangeKind.AllHistory: return Lang.T("همه‌ی تاریخچه (تا ", "All history (to ") + Gd.Date(To.AddDays(-1)) + ")";
                    default: return Lang.T("بازه‌ی دلخواه (", "Custom range (") + days + ")";
                }
            }
        }

    }

    // ================================================================== overtrading limits

    /// <summary>3.19: how many trades opened in a server day count as normal: ten, for every student. There is no weekly limit and
    /// nothing to set (the settings and folder limits of 3.15–3.18 are gone; a folder's old values stay in its line, unused).</summary>
    public sealed class TradeLimits
    {
        public const int DefaultDaily = 10;
        public int Daily = DefaultDaily;
    }

    // ================================================================== SLR 2.0 (3.19)

    /// <summary>How a trade was protected. Strict: a Stop Loss on the order (MT5). Delayed: none on the order, one by the close (MT5;
    /// how much later is not kept, so a second later counts too). Unprotected: none before it closed (or up to now). Mt4: a Stop
    /// Loss at the close, the only one MT4 keeps; when it was put on is unknown.</summary>
    public enum StopKind { Strict, Delayed, Unprotected, Mt4 }

    public static class Stops
    {
        /// <summary>slEntry: the Stop Loss on the order (0 none, below 0 unknown: MT4); later: the one at the close, or now when still open.</summary>
        public static StopKind Of(double slEntry, double later)
        {
            if (slEntry > 0) return StopKind.Strict;
            if (slEntry < 0) return later > 0 ? StopKind.Mt4 : StopKind.Unprotected;
            return later > 0 ? StopKind.Delayed : StopKind.Unprotected;
        }

        public static string Name(StopKind k)
        {
            switch (k)
            {
                case StopKind.Strict: return Lang.T("حد ضرر از ورود", "SL from entry");
                case StopKind.Delayed: return Lang.T("حد ضرر بعد از ورود", "SL after entry");
                case StopKind.Mt4: return Lang.T("حد ضرر داشت (MT4)", "Had SL (MT4)");
                default: return Lang.T("بدون حد ضرر", "No stop loss");
            }
        }

        public static string Key(StopKind k) { return k == StopKind.Strict ? "strict" : k == StopKind.Delayed ? "late" : k == StopKind.Mt4 ? "mt4" : "none"; }
    }

    // ================================================================== the numbers of a report

    public sealed class JournalSummary
    {
        public double StartBalance, EndBalance, Net, ReturnPct = double.NaN, Lots, Deposits, Withdrawals, Floating;
        public int Trades, OpenTrades;
        /// <summary>The largest drop within one server day below that day's starting balance, in money and percent of it.</summary>
        public double MaxDailyDd, MaxDailyDdPct;
        public DateTime MaxDdDay;
        /// <summary>A day's drawdown above this (in percent, as shown to two decimals) is marked red.</summary>
        public const double DdRedPct = 3;
        public bool DdRed { get { return Math.Round(MaxDailyDdPct, 2, MidpointRounding.AwayFromZero) > DdRedPct; } }
        public bool DdApprox = true;
        /// <summary>Trades opened in the range without a Stop Loss (MT5: at the entry; MT4: at the close, the only one it keeps).
        /// StopLater: of those, MT5 trades that had one when they closed (put on after the entry).</summary>
        public int NoStop, StopLater;
        /// <summary>3.19, SLR 2.0: MT5 trades with a Stop Loss on the order itself (Strict); MT4 trades whose last Stop Loss was there
        /// (when it was put on is not kept, so neither strict nor late can be told).</summary>
        public int StopAtEntry, StopMt4;
        /// <summary>Trades that never had a Stop Loss before they closed (or up to now, still open): Unprotected.</summary>
        public int Unprotected { get { return NoStop - StopLater; } }
        /// <summary>3.18: the trades opened in the range (closed or still open), the base of the share with a Stop Loss.</summary>
        public int Opened;
        /// <summary>3.18: the days whose drawdown was above DdRedPct.</summary>
        public int DdRedDays;
        public bool StopApprox;
        public int MaxPerDay, OverDays;
        /// <summary>3.19: the server days with more trades opened than the daily limit.</summary>
        public readonly List<DateTime> OverDayDates = new List<DateTime>();
        public TradeLimits Limits = new TradeLimits();
        /// <summary>3.17, the trades closed in the range: those that made money and lost it (net), and their averages (both as positive numbers).</summary>
        public int Wins, Losses;
        public double AvgWin, AvgLoss, TotalWin, TotalLoss;
        /// <summary>Average win ÷ average loss; NaN without a losing trade (nothing to divide by).</summary>
        public double RiskReward = double.NaN;
        /// <summary>Winning trades in percent of the trades closed; NaN without trades.</summary>
        public double WinRate = double.NaN;
        /// <summary>How long the trades closed in the range were open, on average; zero without trades.</summary>
        public TimeSpan AvgHold;

        public string SlrStatus { get { return NoStop == 0 ? "Correct" : "Not Correct [" + NoStop.ToString(CultureInfo.InvariantCulture) + "]"; } }
        public bool SlrOk { get { return NoStop == 0; } }
        public bool OverOk { get { return OverDays == 0; } }

        public string OverStatus { get { return OverOk ? Lang.T("عادی", "Normal") : Lang.T("اورترید: ", "Overtrading: ") + Fa.N(OverDays) + Lang.T(" روز (سقف ", " days (limit ") + Fa.N(Limits.Daily) + ")"; } }
    }

    public static class JournalMath
    {
        static bool InRange(DateTime t, DateTime from, DateTime to) { return t >= from && t < to; }

        /// <summary>The numbers of one account over a range [from, to) of server days.</summary>
        public static JournalSummary Summarize(AccountJournal j, DateTime from, DateTime to, TradeLimits limits)
        {
            var s = new JournalSummary { Limits = limits ?? new TradeLimits() };
            DateTime end = to > j.Exported && j.Exported > DateTime.MinValue ? j.Exported.AddSeconds(1) : to;
            // The balance now, less everything after the range began, is the balance at its start.
            double after = j.Trades.Where(t => t.Close >= from).Sum(t => t.Net) + j.Cash.Where(c => c.Time >= from).Sum(c => c.Amount);
            s.StartBalance = j.Balance - after;
            List<JournalTrade> closed = j.Trades.Where(t => InRange(t.Close, from, end)).OrderBy(t => t.Close).ToList();
            List<JournalCash> cash = j.Cash.Where(c => InRange(c.Time, from, end)).ToList();
            s.Trades = closed.Count;
            s.Net = closed.Sum(t => t.Net);
            s.Lots = closed.Sum(t => t.Volume);
            s.Deposits = cash.Where(c => c.Amount > 0).Sum(c => c.Amount);
            s.Withdrawals = -cash.Where(c => c.Amount < 0).Sum(c => c.Amount);
            s.EndBalance = s.StartBalance + s.Net + s.Deposits - s.Withdrawals;
            if (s.StartBalance > 0) s.ReturnPct = s.Net / s.StartBalance * 100;
            s.OpenTrades = j.Open.Count;
            s.Floating = j.Open.Sum(o => o.Profit + o.Swap);
            Outcomes(closed.Select(t => t.Net), s);
            if (closed.Count > 0) s.AvgHold = TimeSpan.FromSeconds(closed.Average(t => Math.Max(0, (t.Close - t.Open).TotalSeconds)));

            // Stop Loss: every trade opened in the range, closed or still open.
            var opened = closed.Where(t => InRange(t.Open, from, end)).Select(t => new { t.Open, t.SlEntry, Later = t.SlFinal })
                .Concat(j.Trades.Where(t => InRange(t.Open, from, end) && !InRange(t.Close, from, end)).Select(t => new { t.Open, t.SlEntry, Later = t.SlFinal }))
                .Concat(j.Open.Where(o => InRange(o.Open, from, end)).Select(o => new { o.Open, o.SlEntry, Later = o.Sl })).ToList();
            s.StopApprox = opened.Any(x => x.SlEntry < 0);
            s.Opened = opened.Count;
            foreach (var x in opened)
            {
                switch (Stops.Of(x.SlEntry, x.Later))
                {
                    case StopKind.Strict: s.StopAtEntry++; break;
                    case StopKind.Mt4: s.StopMt4++; break;
                    case StopKind.Delayed: s.NoStop++; s.StopLater++; break;
                    default: s.NoStop++; break;
                }
            }

            // Overtrading: trades opened per server day.
            List<IGrouping<DateTime, DateTime>> perDay = opened.Select(x => x.Open).GroupBy(t => t.Date).OrderBy(g => g.Key).ToList();
            s.MaxPerDay = perDay.Count == 0 ? 0 : perDay.Max(g => g.Count());
            s.OverDayDates.AddRange(perDay.Where(g => g.Count() > s.Limits.Daily).Select(g => g.Key));
            s.OverDays = s.OverDayDates.Count;

            DailyDrawdown(j, from, end, s);
            return s;
        }

        /// <summary>Wins and losses of closed trades (net, to the cent; a trade at exactly zero is neither): averages, ratio and rate.</summary>
        public static void Outcomes(IEnumerable<double> nets, JournalSummary s)
        {
            int n = 0;
            foreach (double raw in nets)
            {
                double v = Math.Round(raw, 2, MidpointRounding.AwayFromZero);
                n++;
                if (v > 0) { s.Wins++; s.TotalWin += v; }
                else if (v < 0) { s.Losses++; s.TotalLoss -= v; }
            }
            s.AvgWin = s.Wins > 0 ? s.TotalWin / s.Wins : 0;
            s.AvgLoss = s.Losses > 0 ? s.TotalLoss / s.Losses : 0;
            s.RiskReward = s.Losses > 0 ? s.AvgWin / s.AvgLoss : double.NaN;
            s.WinRate = n > 0 ? s.Wins * 100.0 / n : double.NaN;
        }

        /// <summary>For each server day: the starting balance, then the lowest the account came to that day, minute by minute:
        /// the balance of the trades closed before that minute plus the worst floating result of those open in it (from the minute's
        /// high and low, so an estimate), and the balance after each close. Money paid in or out that day does not count.</summary>
        static void DailyDrawdown(AccountJournal j, DateTime from, DateTime end, JournalSummary s)
        {
            if (j.FloatingDisabled) { s.MaxDailyDd = s.MaxDailyDdPct = double.NaN; s.DdApprox = false; return; }
            s.DdApprox = j.Floating.Count > 0 || j.Open.Count > 0;
            // 3.20: one pass, over the days that had a close or minutes with positions open only (a long range, or the whole
            // history, has many days without either, whose drawdown is nought).
            List<KeyValuePair<DateTime, double>> closes = j.Trades.Where(t => t.Close >= from && t.Close < end).Select(t => new KeyValuePair<DateTime, double>(t.Close, t.Net))
                .OrderBy(e => e.Key).ToList();
            List<KeyValuePair<DateTime, double>> cash = j.Cash.Where(c => c.Time >= from && c.Time < end).Select(c => new KeyValuePair<DateTime, double>(c.Time, c.Amount))
                .OrderBy(e => e.Key).ToList();
            List<KeyValuePair<DateTime, double>> minutes = j.Floating.Where(f => f.Key >= from && f.Key < end).ToList();
            var days = new SortedSet<DateTime>(closes.Select(e => e.Key.Date).Concat(minutes.Select(f => f.Key.Date)));
            int ci = 0, ki = 0, fi = 0;
            double before = s.StartBalance;
            foreach (DateTime day in days)
            {
                // The balance when the day began: the range's start, the trades closed and the money paid in or out before it.
                while (ci < closes.Count && closes[ci].Key < day) before += closes[ci++].Value;
                while (ki < cash.Count && cash[ki].Key < day) before += cash[ki++].Value;
                while (fi < minutes.Count && minutes[fi].Key < day) fi++;
                DateTime next = day.AddDays(1);
                double start = before, low = start, realized = 0;
                int k = ci;
                // The balance within the day, close by close, with the floating minutes between.
                for (; fi < minutes.Count && minutes[fi].Key < next; fi++)
                {
                    while (k < closes.Count && closes[k].Key < minutes[fi].Key)
                    {
                        realized += closes[k].Value;
                        low = Math.Min(low, start + realized);
                        k++;
                    }
                    low = Math.Min(low, start + realized + minutes[fi].Value);
                }
                for (; k < closes.Count && closes[k].Key < next; k++)
                {
                    realized += closes[k].Value;
                    low = Math.Min(low, start + realized);
                }
                double dd = Math.Max(0, start - low);
                double pct = start > 0 ? dd / start * 100 : 0;
                if (Math.Round(pct, 2, MidpointRounding.AwayFromZero) > JournalSummary.DdRedPct) s.DdRedDays++;
                if (pct > s.MaxDailyDdPct || (pct == s.MaxDailyDdPct && dd > s.MaxDailyDd)) { s.MaxDailyDd = dd; s.MaxDailyDdPct = pct; s.MaxDdDay = day; }
            }
        }

    }
}

namespace MTManager
{
    // ================================================================== trading sessions (3.17)

    public enum TradeSession { Unknown, Asia, London, Overlap, NewYork }

    /// <summary>The market session a trade was opened in, from its time in GMT: London and New York each from 08:00 to 17:00 of
    /// their own clock (with their summer time), both together the overlap, the rest of the day Asia/Sydney. In winter (GMT):
    /// London 08–13, overlap 13–17, New York 17–22, Asia 22–08; in summer an hour earlier.</summary>
    public static class TradeSessions
    {
        public static string Name(TradeSession s)
        {
            switch (s)
            {
                case TradeSession.Asia: return Lang.T("آسیا/سیدنی", "Asia/Sydney");
                case TradeSession.London: return Lang.T("لندن", "London");
                case TradeSession.Overlap: return Lang.T("لندن و نیویورک", "London & New York");
                case TradeSession.NewYork: return Lang.T("نیویورک", "New York");
                default: return "—";
            }
        }

        /// <summary>3.20: the session's name in English, as the report shows it.</summary>
        public static string En(TradeSession s)
        {
            switch (s)
            {
                case TradeSession.Asia: return "Asia";
                case TradeSession.London: return "London";
                case TradeSession.Overlap: return "London/NY";
                case TradeSession.NewYork: return "New York";
                default: return "—";
            }
        }

        public static string En(string key)
        {
            switch (key)
            {
                case "asia": return En(TradeSession.Asia);
                case "london": return En(TradeSession.London);
                case "overlap": return En(TradeSession.Overlap);
                case "ny": return En(TradeSession.NewYork);
                default: return "—";
            }
        }

        public static string Key(TradeSession s)
        {
            switch (s)
            {
                case TradeSession.Asia: return "asia";
                case TradeSession.London: return "london";
                case TradeSession.Overlap: return "overlap";
                case TradeSession.NewYork: return "ny";
                default: return "unknown";
            }
        }

        static DateTime LastSunday(int year, int month)
        {
            var d = new DateTime(year, month, DateTime.DaysInMonth(year, month));
            return d.AddDays(-(int)d.DayOfWeek);
        }

        static DateTime NthSunday(int year, int month, int n)
        {
            var d = new DateTime(year, month, 1);
            return d.AddDays((7 - (int)d.DayOfWeek) % 7 + 7 * (n - 1));
        }

        /// <summary>British summer time: from 01:00 GMT on the last Sunday of March to 01:00 GMT on the last Sunday of October.</summary>
        public static bool LondonSummer(DateTime gmt)
        {
            return gmt >= LastSunday(gmt.Year, 3).AddHours(1) && gmt < LastSunday(gmt.Year, 10).AddHours(1);
        }

        /// <summary>US daylight time: from 2:00 local on the second Sunday of March (07:00 GMT) to 2:00 local on the first Sunday
        /// of November (06:00 GMT).</summary>
        public static bool NewYorkSummer(DateTime gmt)
        {
            return gmt >= NthSunday(gmt.Year, 3, 2).AddHours(7) && gmt < NthSunday(gmt.Year, 11, 1).AddHours(6);
        }

        public static TradeSession Of(DateTime gmt)
        {
            double h = gmt.TimeOfDay.TotalHours;
            double london = (h + (LondonSummer(gmt) ? 1 : 0) + 24) % 24, ny = (h - (NewYorkSummer(gmt) ? 4 : 5) + 24) % 24;
            bool l = london >= 8 && london < 17, n = ny >= 8 && ny < 17;
            return l && n ? TradeSession.Overlap : l ? TradeSession.London : n ? TradeSession.NewYork : TradeSession.Asia;
        }
    }

    /// <summary>A trading server's clock turned to GMT. Most brokers keep New York time + 7 hours (GMT+2 in winter, GMT+3 in
    /// summer); when the measured offset is that one, each trade is turned with the summer time of its own day. Another
    /// measured offset is used as it is; without one, New York + 7 is assumed (and said so in the report).</summary>
    public sealed class ServerClock
    {
        public int? Fixed;
        public bool NewYorkPlus7, Assumed;

        public static ServerClock Of(AccountJournal j)
        {
            if (j == null || !j.GmtOffset.HasValue) return new ServerClock { NewYorkPlus7 = true, Assumed = true };
            int off = j.GmtOffset.Value;
            DateTime gmt = j.Exported.AddSeconds(-off);
            int ny7 = (TradeSessions.NewYorkSummer(gmt) ? 3 : 2) * 3600;
            return off == ny7 ? new ServerClock { NewYorkPlus7 = true } : new ServerClock { Fixed = off };
        }

        public DateTime ToGmt(DateTime server)
        {
            if (!NewYorkPlus7) return server.AddSeconds(-(Fixed ?? 0));
            DateTime summer = server.AddHours(-3);
            return TradeSessions.NewYorkSummer(summer) ? summer : server.AddHours(-2);
        }

        /// <summary>3.21: the server's clock at a moment in GMT (for "today" on the server's calendar).</summary>
        public DateTime FromGmt(DateTime gmt)
        {
            if (!NewYorkPlus7) return gmt.AddSeconds(Fixed ?? 0);
            return gmt.AddHours(TradeSessions.NewYorkSummer(gmt) ? 3 : 2);
        }
    }
}

namespace MTManager
{
    // ================================================================== starting a report copy

    /// <summary>How a report copy of MetaTrader is started for one account: the start file (the documented way: login, the script,
    /// its chart) and the script's parameters. The report copies are the program's own (under the copies folder, in _MTManager\report),
    /// never a student's copy, so the student's MetaTrader stays as it is.</summary>
    public static class ReportLaunch
    {
        public const string Script = "MTManagerReport", PresetName = "mtm-report.set", OutName = @"MTManagerReport\report.txt";
        /// <summary>The same name as a student copy's start file: deleted by the same rule (as soon as the terminal has read it).</summary>
        public const string StartFileName = Launcher.StartFileName;
        /// <summary>Bars a report copy may keep per chart: about ten weeks of minute bars, for the estimated drawdown.</summary>
        public const int MaxBars = 100000;
        /// <summary>How long the script may take to start (the terminal opening, logging in, opening the script's chart).</summary>
        public const int StartSeconds = 45;
        /// <summary>How long the script may stay at one step (a symbol's bars downloading) before it counts as stuck.</summary>
        public const int StallSeconds = 180;
        /// <summary>The longest one account may take altogether, however it goes.</summary>
        public const int MaxSeconds = 900;

        /// <summary>The script's progress file, beside its result: one line ("start", "connected", "deals 152", "bars EURUSD 2/5", "writing").</summary>
        public static string StepPath(Instance report) { return OutputPath(report) + ".step"; }

        /// <summary>The script's step in words, for the progress window.</summary>
        public static string StepText(string step)
        {
            string[] p = (step ?? "").Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (p.Length == 0) return null;
            switch (p[0])
            {
                case "ready": return Lang.T("گزارش‌خوان MT5 آماده است؛ منتظر اتصال حساب…", "MT5 reporter ready; waiting for account connection…");
                case "start": return Lang.T("اسکریپت شروع شد، در انتظار اتصال…", "Script started, waiting for connection…");
                case "connected": return Lang.T("وصل شد، در حال گرفتن تاریخچه…", "Connected, getting history…");
                case "history": return Lang.T("در حال گرفتن تاریخچه", "Getting history") + (p.Length > 1 ? " (" + TextUtil.PersianDigits(p[1]) + Lang.T(" ردیف)", " rows)") : "") + "…";
                case "history-error": return Lang.T("خواندن تاریخچهٔ MT5 خطا داد؛ در حال بررسی دوباره", "MT5 history read returned an error; checking again") + (p.Length > 1 ? " (" + p[1] + ")" : "") + "…";
                case "deals": return Lang.T("تاریخچه آمد", "History received") + (p.Length > 1 ? " (" + TextUtil.PersianDigits(p[1]) + Lang.T(" ردیف)", " rows)") : "") + "…";
                case "bars": return Lang.T("کندل‌های ", "Candles of ") + (p.Length > 1 ? p[1] : "") + (p.Length > 2 ? " (" + TextUtil.PersianDigits(p[2].Replace("/", Lang.T(" از ", " of "))) + ")" : "") + "…";
                case "writing": return Lang.T("در حال نوشتن…", "Writing…");
                default: return null;
            }
        }

        static readonly int[] Mt4Periods = { 43200, 10080, 1440, 240, 60, 30, 15, 5, 1 };

        /// <summary>How long MT5 may keep the script waiting for its chart once the account is connected (3.17.2). A chart on a
        /// symbol the broker does not have never synchronizes, and MT5 holds the script before it starts for minutes ("symbol
        /// synchronization timeout"); a symbol it has is ready in seconds.</summary>
        public static int SymbolWaitSeconds = 60;

        /// <summary>MT5 has put the script on its chart but not started it, and the account has been connected for longer than a
        /// symbol the broker has would take (or MT5 said "symbol synchronization timeout"): the chart is on a symbol the broker does
        /// not have. Never for MT4, nor once the script has written a step.</summary>
        public static bool HeldOnChart(Kind kind, string step, bool loaded, bool chartTimeout, DateTime? connectedAt, DateTime now)
        {
            if (kind != Kind.MT5 || !string.IsNullOrEmpty(step) || !loaded) return false;
            return chartTimeout || (connectedAt != null && (now - connectedAt.Value).TotalSeconds >= SymbolWaitSeconds);
        }

        static readonly string[] Majors = { "EURUSD", "XAUUSD", "GBPUSD", "USDJPY" };

        /// <summary>Symbols the broker has, from a copy's own folders. MT5: Bases\&lt;server&gt;\history\&lt;symbol&gt; (charts),
        /// Bases\&lt;server&gt;\ticks\&lt;symbol&gt; (the Market Watch, also in a copy without charts) and the majors as the broker
        /// names them in its symbol list (Bases\&lt;server&gt;\symbols). MT4: history\&lt;server&gt;\&lt;symbol&gt;&lt;period&gt;.hst.
        /// The script's chart must be one of these, or it does not open (MT4) or never starts (MT5).
        /// For MT5 with a server named: only that exact server's folder; absent means no known symbols, never another broker's.</summary>
        public static List<string> KnownSymbols(Instance copy, string serverName = null)
        {
            var list = new List<string>();
            try
            {
                if (copy.Kind == Kind.MT5)
                {
                    string bases = Path.Combine(copy.Dir, "Bases");
                    if (Directory.Exists(bases))
                    {
                        string[] servers = Directory.GetDirectories(bases);
                        string[] own = servers.Where(d => !string.IsNullOrWhiteSpace(serverName) && string.Equals(Path.GetFileName(d), serverName.Trim(), StringComparison.OrdinalIgnoreCase)).ToArray();
                        foreach (string serverDir in !string.IsNullOrWhiteSpace(serverName) ? own : servers)
                        {
                            foreach (string sub in new[] { "history", "ticks" })
                            {
                                string h = Path.Combine(serverDir, sub);
                                if (Directory.Exists(h)) list.AddRange(Directory.GetDirectories(h).Select(Path.GetFileName));
                            }
                            list.AddRange(SymbolListMajors(Path.Combine(serverDir, "symbols"), true));
                        }
                    }
                }
                else
                {
                    string history = Path.Combine(copy.Dir, "history");
                    if (Directory.Exists(history))
                        foreach (string server in Directory.GetDirectories(history))
                        {
                            list.AddRange(SymbolListMajors(Path.Combine(server, "symbols.raw")));
                            foreach (string f in Directory.GetFiles(server, "*.hst"))
                            {
                                string name = Path.GetFileNameWithoutExtension(f);
                                foreach (int period in Mt4Periods)
                                {
                                    string tail = period.ToString(CultureInfo.InvariantCulture);
                                    if (name.Length > tail.Length && name.EndsWith(tail, StringComparison.Ordinal)) { list.Add(name.Substring(0, name.Length - tail.Length)); break; }
                                }
                            }
                        }
                }
            }
            catch { }
            return list.Where(x => x.Length > 0 && x.Length <= 40).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        static bool SymbolChar(char c)
        {
            return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || "._@#!&+-~$".IndexOf(c) >= 0;
        }

        /// <summary>The majors as a broker names them ("EURUSD@", "XAUUSD.z"), read from MT5's symbol list files: only the four
        /// majors are looked for, so nothing else in those files is taken for a symbol. Nothing when the files are not there.</summary>
        public static List<string> SymbolListMajors(string symbolsDir, bool mt5Fast = false)
        {
            var found = new List<string>();
            try
            {
                if (!Directory.Exists(symbolsDir)) return found;
                foreach (string f in Directory.GetFiles(symbolsDir, "*.dat"))
                {
                    var info = new FileInfo(f);
                    if (info.Length == 0 || info.Length > 32 * 1024 * 1024) continue;
                    byte[] b = File.ReadAllBytes(f);
                    if (mt5Fast) { found.AddRange(Mt5SymbolNames(b)); continue; }
                    // UTF-16 (as MT5 keeps its names) and plain bytes.
                    foreach (bool wide in new[] { true, false })
                    {
                        int step = wide ? 2 : 1;
                        foreach (string major in Majors)
                            for (int i = 0; i + major.Length * step <= b.Length; i++)
                            {
                                if (!At(b, i, major, wide)) continue;
                                if (i >= step && SymbolChar(CharAt(b, i - step, wide))) continue;  // inside a longer word
                                var sb = new StringBuilder();
                                for (int j = i; j + step <= b.Length && sb.Length <= 31; j += step)
                                {
                                    char c = CharAt(b, j, wide);
                                    if (!SymbolChar(c)) break;
                                    sb.Append(c);
                                }
                                if (sb.Length <= 31) found.Add(sb.ToString());
                            }
                    }
                }
            }
            catch { }
            return found.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        // MT5-only: two byte passes instead of a full pass for each major and encoding.
        // Preserve the old ordering, suffix handling and binary word-boundary rules.
        public static List<string> Mt5SymbolNames(byte[] bytes)
        {
            var found = new List<string>();
            foreach (bool wide in new[] { true, false })
            {
                int step = wide ? 2 : 1;
                var buckets = Majors.Select(_ => new List<string>()).ToArray();
                for (int i = 0; i + 6 * step <= bytes.Length; i++)
                {
                    int major;
                    switch (bytes[i]) { case (byte)'E': major = 0; break; case (byte)'X': major = 1; break; case (byte)'G': major = 2; break; case (byte)'U': major = 3; break; default: continue; }
                    if (!At(bytes, i, Majors[major], wide) || i >= step && SymbolChar(CharAt(bytes, i - step, wide))) continue;
                    var name = new StringBuilder();
                    for (int j = i; j + step <= bytes.Length && name.Length <= 31; j += step)
                    {
                        char c = CharAt(bytes, j, wide);
                        if (!SymbolChar(c)) break;
                        name.Append(c);
                    }
                    if (name.Length <= 31) buckets[major].Add(name.ToString());
                }
                foreach (var bucket in buckets) found.AddRange(bucket);
            }
            return found.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        static char CharAt(byte[] b, int i, bool wide) { return wide ? (char)(b[i] | (b[i + 1] << 8)) : (char)b[i]; }

        static bool At(byte[] b, int i, string word, bool wide)
        {
            for (int k = 0; k < word.Length; k++)
            {
                int p = wide ? i + 2 * k : i + k;
                if (b[p] != (byte)word[k] || (wide && b[p + 1] != 0)) return false;
            }
            return true;
        }

        /// <summary>The chart for the script: the one asked for when the broker has it, otherwise EURUSD (with the broker's ending),
        /// then gold, then any. Symbols tried already in this run (MT5 kept the script waiting on them) are passed over; null when
        /// nothing is left to try.</summary>
        public static string PickSymbol(string wanted, IList<string> known, ICollection<string> tried = null)
        {
            Func<string, bool> fresh = s => tried == null || !tried.Any(t => string.Equals(t, s, StringComparison.OrdinalIgnoreCase));
            List<string> left = (known ?? new List<string>()).Where(fresh).ToList();
            if (left.Count == 0) return wanted != null && fresh(wanted) ? wanted : null;
            if (wanted != null && left.Any(k => string.Equals(k, wanted, StringComparison.OrdinalIgnoreCase))) return wanted;
            foreach (string major in Majors)
            {
                string exact = left.FirstOrDefault(k => string.Equals(k, major, StringComparison.OrdinalIgnoreCase));
                if (exact != null) return exact;
                string near = left.Where(k => k.StartsWith(major, StringComparison.OrdinalIgnoreCase)).OrderBy(k => k.Length).FirstOrDefault();
                if (near != null) return near;
            }
            return left.OrderBy(k => k, StringComparer.OrdinalIgnoreCase).First();
        }

        public static string ReportRoot(string baseDir) { return Path.Combine(baseDir, "_MTManager", "report"); }

        public static string PresetPath(Instance report) { return Path.Combine(report.Dir, Kinds.Mql(report.Kind), "Presets", PresetName); }

        /// <summary>Where the terminal may look for the script's inputs: MQL5\Presets; MT4 also its older presets folder.</summary>
        public static List<string> PresetPaths(Instance report)
        {
            var list = new List<string> { PresetPath(report) };
            if (report.Kind == Kind.MT4) list.Add(Path.Combine(report.Dir, "presets", PresetName));
            else list.Add(Path.Combine(report.Dir, "MQL5", "Profiles", "Presets", PresetName));
            return list;
        }

        public static string StartFile(Instance report) { return Path.Combine(report.Dir, StartFileName); }

        public static string OutputPath(Instance report) { return Path.Combine(report.Dir, Kinds.Mql(report.Kind), "Files", OutName); }

        /// <summary>The start file: the account with its investor password, not kept by the terminal (KeepPrivate off: a report copy
        /// logs into one account after another); the script on a minute chart; MT5 closes itself when the script ends.</summary>
        public static List<string> StartLines(Kind kind, Account acc, string password, string symbol)
        {
            var lines = new List<string>();
            string sym = string.IsNullOrWhiteSpace(symbol) ? "EURUSD" : TextUtil.OneLine(symbol);
            if (kind == Kind.MT5)
            {
                lines.Add("[Common]");
                lines.Add("Login=" + TextUtil.OneLine(acc.Login));
                lines.Add("Password=" + password);
                lines.Add("Server=" + TextUtil.OneLine(acc.Server));
                lines.Add("KeepPrivate=0");
                lines.Add("NewsEnable=0");
                // Read-only in every way: no trading and no DLL for anything run in the report copy.
                lines.Add("[Experts]");
                lines.Add("AllowLiveTrading=0");
                lines.Add("AllowDllImport=0");
                lines.Add("[Charts]");
                lines.Add("ProfileLast=" + ChartProfile.EmptyName);  // 3.19: no chart but the script's
                lines.Add("MaxBars=" + MaxBars);
                lines.Add("[StartUp]");
                lines.Add("Expert=" + Script);
                lines.Add("ExpertParameters=" + PresetName);
                lines.Add("Symbol=" + sym);
                lines.Add("Period=M1");
                lines.Add("ShutdownTerminal=0");
            }
            else
            {
                lines.Add("Login=" + TextUtil.OneLine(acc.Login));
                lines.Add("Password=" + password);
                lines.Add("Server=" + TextUtil.OneLine(acc.Server));
                lines.Add("KeepPrivate=false");
                lines.Add("NewsEnable=false");
                lines.Add("ExpertsTrades=false");
                // 3.21: the script asks MT4 for its whole account history with the history tab's own "All History" command,
                // through user32.dll (MT4 gives a program only what that tab shows). Trading stays off.
                lines.Add("ExpertsDllImport=true");
                lines.Add("Symbol=" + sym);
                lines.Add("Period=M1");
                lines.Add("Script=" + Script);
                lines.Add("ScriptParameters=" + PresetName);
            }
            return lines;
        }

        /// <summary>The symbol of a chart file ("symbol=EURUSD.m"), so the script's chart opens on a symbol the broker has.</summary>
        public static string ChartSymbol(string chartText)
        {
            foreach (string raw in (chartText ?? "").Split('\n'))
            {
                string l = raw.Trim();
                if (!l.StartsWith("symbol=", StringComparison.OrdinalIgnoreCase)) continue;
                string v = l.Substring(7).Trim();
                if (v.Length > 0 && v.Length <= 40 && v.All(c => c > ' ' && c < 127)) return v;
            }
            return null;
        }

        /// <summary>The script's inputs: the first server day of the range (it reads from there to now) and where it writes.</summary>
        public static List<string> Preset(DateTime from, Account account = null, string token = null, bool serve = false)
        {
            var lines = new List<string> { "FromDate=" + from.ToString("yyyy.MM.dd", CultureInfo.InvariantCulture), "OutFile=" + OutName };
            if (account != null) { lines.Add("ExpectedLogin=" + account.Login.Trim()); lines.Add("ExpectedServer=" + TextUtil.OneLine(account.Server)); lines.Add("RequestToken=" + token); }
            if (serve) lines.Add("ServeMode=true");
            return lines;
        }
    }
}
