using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace MTManager
{
    public sealed class ScheduleOptions
    {
        public bool Enabled { get; set; }
        public string Time { get; set; }
        public string Platform { get; set; }
        public bool TelegramEnabled { get; set; }
        public bool BaleEnabled { get; set; }
        public bool EmailEnabled { get; set; }
        public string TelegramTokenEnc { get; set; }
        public string TelegramChatId { get; set; }
        public string BaleTokenEnc { get; set; }
        public string BaleChatId { get; set; }
        public string SmtpHost { get; set; }
        public int SmtpPort { get; set; }
        public bool SmtpSsl { get; set; }
        public string SmtpUser { get; set; }
        public string SmtpPasswordEnc { get; set; }
        public string EmailFrom { get; set; }
        public string EmailTo { get; set; }
        [ScriptIgnore] public string LoadError { get; set; }
        public ScheduleOptions()
        {
            Time = "22:00"; Platform = "All"; SmtpPort = 587; SmtpSsl = true;
            TelegramTokenEnc = TelegramChatId = BaleTokenEnc = BaleChatId = SmtpHost = SmtpUser = SmtpPasswordEnc = EmailFrom = EmailTo = "";
        }
        public ScheduleOptions Snapshot()
        {
            return (ScheduleOptions)MemberwiseClone(); // Strings are immutable; there are no shared mutable collections.
        }
    }

    public static class ScheduleStore
    {
        static readonly object gate = new object();
        public static string FilePath { get { return Path.Combine(AppPaths.DataDir, "scheduled-delivery.json"); } }
        static ScheduleOptions Normalize(ScheduleOptions options)
        {
            var result = options.Snapshot();
            result.Time = TextUtil.LatinDigits((result.Time ?? "").Trim());
            string platform = (result.Platform ?? "").Trim();
            result.Platform = platform.Equals("all", StringComparison.OrdinalIgnoreCase) ? "All" : platform.ToUpperInvariant();
            result.TelegramChatId = (result.TelegramChatId ?? "").Trim(); result.BaleChatId = (result.BaleChatId ?? "").Trim();
            result.SmtpHost = (result.SmtpHost ?? "").Trim(); result.SmtpUser = (result.SmtpUser ?? "").Trim();
            result.EmailFrom = (result.EmailFrom ?? "").Trim(); result.EmailTo = (result.EmailTo ?? "").Trim();
            result.LoadError = null; return result;
        }
        public static ScheduleOptions Load()
        {
            lock (gate)
            {
                try
                {
                    if (!File.Exists(FilePath)) return new ScheduleOptions();
                    if (new FileInfo(FilePath).Length > 65536) throw new InvalidDataException();
                    var serializer = new JavaScriptSerializer { MaxJsonLength = 65536, RecursionLimit = 8 };
                    var value = serializer.Deserialize<ScheduleOptions>(File.ReadAllText(FilePath, Encoding.UTF8));
                    if (value == null) throw new InvalidDataException();
                    value = Normalize(value);
                    if (value.Enabled)
                    {
                        string problem = ScheduledDelivery.Validate(value);
                        if (problem != null) { value.Enabled = false; value.LoadError = Lang.T("زمان‌بندی غیرفعال شد: ", "Scheduling was disabled: ") + problem; }
                    }
                    return value;
                }
                catch
                {
                    // Never log the JSON or an exception that might contain a destination/secret.
                    return new ScheduleOptions { LoadError = Lang.T("تنظیمات زمان‌بندی قابل خواندن نیست؛ ارسال خودکار غیرفعال است.", "Scheduling settings could not be read; automatic sending is disabled.") };
                }
            }
        }
        public static void Save(ScheduleOptions options)
        {
            if (options == null) throw new ArgumentNullException("options");
            ScheduleOptions copy = Normalize(options);
            string problem = copy.Enabled ? ScheduledDelivery.Validate(copy) : ScheduledDelivery.StructureProblem(copy);
            if (problem != null) throw new ArgumentException(problem, "options");
            string json = new JavaScriptSerializer { MaxJsonLength = 65536 }.Serialize(copy);
            if (Encoding.UTF8.GetByteCount(json) + 5 > 65536) throw new ArgumentException(Lang.T("تنظیمات زمان‌بندی بیش از حد طولانی است.", "Scheduling settings are too long."));
            // The application backup uses an explicit allowlist. This file is deliberately separate
            // from portable settings/accounts and contains only current-user DPAPI secret ciphertext.
            lock (gate) TextUtil.WriteLinesAtomically(FilePath, new[] { json });
        }
    }

    public sealed class DeliveryOutcome
    {
        public string Channel { get; set; }
        public bool Success { get; set; }
        public string Detail { get; set; }
        public bool Uncertain { get; set; }
    }
    internal sealed class ScheduledDeliveryRequest
    {
        public string Channel, Subject, Body, FileName, BotToken, ChatId;
        public byte[] Document;
        public ScheduleOptions Options;
        public Uri Endpoint;
    }
    internal interface IScheduledDeliveryTransport
    {
        void Send(ScheduledDeliveryRequest request, Func<bool> cancel);
    }
    internal sealed class ScheduledDeliveryException : Exception
    {
        public readonly bool Uncertain;
        public ScheduledDeliveryException(string safeDetail, bool uncertain = false) : base(safeDetail) { Uncertain = uncertain; }
    }

    public static class ScheduledDelivery
    {
        internal const int TimeoutMilliseconds = 30000;
        internal const int MaximumDocumentBytes = 20 * 1024 * 1024;
        static readonly string[] Channels = { "Telegram", "Bale", "Email" };
        static bool Selected(ScheduleOptions options, string channel)
        { return channel == "Telegram" ? options.TelegramEnabled : channel == "Bale" ? options.BaleEnabled : options.EmailEnabled; }
        static bool ControlCharacters(string value) { return (value ?? "").Any(char.IsControl); }
        internal static string StructureProblem(ScheduleOptions options)
        {
            if (options == null) return Lang.T("تنظیمات زمان‌بندی موجود نیست.", "Scheduling settings are missing.");
            DateTime time;
            if (!DateTime.TryParseExact(TextUtil.LatinDigits((options.Time ?? "").Trim()), "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out time))
                return Lang.T("ساعت را به شکل 22:00 وارد کنید.", "Enter the time as HH:mm, for example 22:00.");
            if (!new[] { "All", "MT4", "MT5" }.Contains(options.Platform))
                return Lang.T("نوع حساب را همه، MT4 یا MT5 انتخاب کنید.", "Choose All, MT4 or MT5 accounts.");
            return null;
        }
        static string ChannelProblem(ScheduleOptions options, string channel)
        {
            if (channel == "Telegram" || channel == "Bale")
            {
                string token = Secret.Unprotect(channel == "Telegram" ? options.TelegramTokenEnc : options.BaleTokenEnc);
                if (string.IsNullOrWhiteSpace(token))
                    return channel + ": " + Lang.T("توکن ذخیره‌شده موجود نیست یا روی این کاربر ویندوز خوانده نمی‌شود؛ دوباره وارد کنید.", "The saved token is missing or cannot be decrypted for this Windows user; enter it again.");
                if (!Regex.IsMatch(token, @"\A[A-Za-z0-9:_-]{10,256}\z"))
                    return channel + ": " + Lang.T("قالب توکن ربات معتبر نیست.", "The bot token format is invalid.");
                string chat = (channel == "Telegram" ? options.TelegramChatId : options.BaleChatId) ?? "";
                if (!Regex.IsMatch(chat.Trim(), @"\A(?:-?[0-9]{1,24}|@[A-Za-z0-9_]{3,100})\z"))
                    return channel + ": " + Lang.T("شناسهٔ عددی گفتگو یا @نام‌کانال را وارد کنید.", "Enter the numeric chat ID or @channel name.");
                return null;
            }
            string host = (options.SmtpHost ?? "").Trim();
            if (host.Length == 0 || host.Length > 253 || ControlCharacters(host) || Uri.CheckHostName(host) == UriHostNameType.Unknown)
                return Lang.T("نام سرور SMTP معتبر نیست.", "The SMTP server name is invalid.");
            if (options.SmtpPort < 1 || options.SmtpPort > 65535)
                return Lang.T("پورت SMTP باید بین ۱ و ۶۵۵۳۵ باشد.", "SMTP port must be between 1 and 65535.");
            if (options.SmtpSsl && options.SmtpPort == 465)
                return Lang.T("برای ایمیل از STARTTLS و معمولاً پورت ۵۸۷ استفاده کنید؛ SSL مستقیم پورت ۴۶۵ پشتیبانی نمی‌شود.", "Use STARTTLS, usually port 587; implicit SSL on port 465 is not supported.");
            if (ControlCharacters(options.SmtpUser)) return Lang.T("نام کاربری SMTP معتبر نیست.", "The SMTP username is invalid.");
            if (!string.IsNullOrWhiteSpace(options.SmtpUser) && string.IsNullOrEmpty(Secret.Unprotect(options.SmtpPasswordEnc)))
                return Lang.T("رمز SMTP موجود نیست یا روی این کاربر ویندوز خوانده نمی‌شود؛ دوباره وارد کنید.", "The SMTP password is missing or cannot be decrypted for this Windows user; enter it again.");
            try
            {
                if (ControlCharacters(options.EmailFrom) || ControlCharacters(options.EmailTo)) throw new FormatException();
                new MailAddress(options.EmailFrom ?? "");
                var recipients = new MailAddressCollection(); recipients.Add((options.EmailTo ?? "").Replace(';', ','));
                if (recipients.Count == 0 || recipients.Count > 20) throw new FormatException();
            }
            catch { return Lang.T("نشانی فرستنده و گیرندهٔ ایمیل را بررسی کنید (حداکثر ۲۰ گیرنده).", "Check the sender and recipient email addresses (up to 20 recipients)."); }
            return null;
        }
        public static string Validate(ScheduleOptions options)
        {
            string problem = StructureProblem(options); if (problem != null) return problem;
            if (!Channels.Any(channel => Selected(options, channel)))
                return Lang.T("حداقل یک روش ارسال را انتخاب کنید.", "Select at least one delivery channel.");
            foreach (string channel in Channels.Where(channel => Selected(options, channel)))
            { problem = ChannelProblem(options, channel); if (problem != null) return problem; }
            return null;
        }
        internal static Uri Endpoint(string channel, string token)
        {
            if (channel != "Telegram" && channel != "Bale") throw new ArgumentException("Unknown bot channel.");
            if (token == null || !Regex.IsMatch(token, @"\A[A-Za-z0-9:_-]{10,256}\z")) throw new ArgumentException("Invalid bot token.");
            return new Uri((channel == "Telegram" ? "https://api.telegram.org/bot" : "https://tapi.bale.ai/bot") + token + "/sendDocument");
        }
        static string SubjectLine(string subject)
        {
            string value = new string((subject ?? "MetaFactory report").Select(c => char.IsControl(c) ? ' ' : c).ToArray()).Trim();
            if (value.Length == 0) value = "MetaFactory report";
            if (value.Length > 250) value = value.Substring(0, char.IsHighSurrogate(value[249]) ? 249 : 250);
            return value;
        }
        public static List<DeliveryOutcome> Send(ScheduleOptions options, string subject, string body, Func<bool> cancel)
        { return Send(options, subject, body, cancel, new ScheduledNetworkTransport()); }
        internal static List<DeliveryOutcome> Send(ScheduleOptions options, string subject, string body, Func<bool> cancel, IScheduledDeliveryTransport transport)
        {
            var results = new List<DeliveryOutcome>();
            // Explicit Send is also used by Run now while the daily timer is disabled.
            // Only the scheduler decides whether Enabled permits an automatic occurrence.
            if (options == null) return results;
            ScheduleOptions frozen = options.Snapshot();
            cancel = cancel ?? (() => false);
            string structure = StructureProblem(frozen);
            byte[] document = null;
            if (body == null) body = "";
            int bytes = Encoding.UTF8.GetByteCount(body);
            byte[] preamble = Encoding.UTF8.GetPreamble();
            if (bytes <= MaximumDocumentBytes - preamble.Length) document = preamble.Concat(Encoding.UTF8.GetBytes(body)).ToArray();
            foreach (string channel in Channels.Where(channel => Selected(frozen, channel)))
            {
                var outcome = new DeliveryOutcome { Channel = channel }; results.Add(outcome);
                if (cancel()) { outcome.Detail = Lang.T("پیش از ارسال لغو شد.", "Cancelled before sending."); continue; }
                string problem = structure ?? ChannelProblem(frozen, channel);
                if (problem != null) { outcome.Detail = problem; continue; }
                if (document == null) { outcome.Detail = Lang.T("متن گزارش از سقف ۲۰ مگابایت بزرگ‌تر است؛ چیزی ارسال نشد.", "The report exceeds the 20 MiB attachment limit; nothing was sent."); continue; }
                try
                {
                    var request = new ScheduledDeliveryRequest { Channel = channel, Options = frozen.Snapshot(), Subject = SubjectLine(subject), Body = body,
                        Document = document, FileName = "MetaFactory-report-" + DateTime.Now.ToString("yyyy-MM-dd-HHmm", CultureInfo.InvariantCulture) + ".txt" };
                    if (channel != "Email")
                    {
                        request.BotToken = Secret.Unprotect(channel == "Telegram" ? frozen.TelegramTokenEnc : frozen.BaleTokenEnc);
                        request.ChatId = (channel == "Telegram" ? frozen.TelegramChatId : frozen.BaleChatId).Trim();
                        request.Endpoint = Endpoint(channel, request.BotToken);
                    }
                    transport.Send(request, cancel);
                    outcome.Success = true;
                    outcome.Detail = Lang.T("سرویس، گزارش را برای ارسال پذیرفت.", "The service accepted the report for delivery.");
                }
                catch (ScheduledDeliveryException e) { outcome.Uncertain = e.Uncertain; outcome.Detail = e.Message; }
                catch (OperationCanceledException) { outcome.Detail = Lang.T("ارسال لغو شد؛ ممکن است سرویس آن را دریافت کرده باشد. ارسال خودکار تکرار نمی‌شود.", "Sending was cancelled; the service may already have received it. It will not be retried automatically."); outcome.Uncertain = true; }
                catch { outcome.Detail = Lang.T("نتیجهٔ ارسال مشخص نشد؛ برای جلوگیری از ارسال تکراری، خودکار تلاش مجدد نمی‌شود.", "Delivery could not be confirmed; automatic retry is disabled to avoid duplicates."); outcome.Uncertain = true; }
            }
            return results;
        }
    }

    internal sealed class ScheduledNetworkTransport : IScheduledDeliveryTransport
    {
        public void Send(ScheduledDeliveryRequest request, Func<bool> cancel)
        {
            if (cancel()) throw new OperationCanceledException();
            // .NET 4.5 defaults may otherwise negotiate legacy TLS. Certificate verification stays enabled.
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
            if (request.Channel == "Email") Email(request, cancel); else Bot(request, cancel);
        }
        internal static byte[] Multipart(ScheduledDeliveryRequest request, string boundary)
        {
            using (var stream = new MemoryStream())
            {
                Action<string> write = value => { byte[] encoded = Encoding.UTF8.GetBytes(value); stream.Write(encoded, 0, encoded.Length); };
                write("--" + boundary + "\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n" + request.ChatId + "\r\n");
                write("--" + boundary + "\r\nContent-Disposition: form-data; name=\"caption\"\r\n\r\n" + request.Subject + "\r\n");
                write("--" + boundary + "\r\nContent-Disposition: form-data; name=\"document\"; filename=\"" + request.FileName + "\"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n");
                stream.Write(request.Document, 0, request.Document.Length); write("\r\n--" + boundary + "--\r\n"); return stream.ToArray();
            }
        }
        static string Unconfirmed()
        { return Lang.T("پاسخ قطعی دریافت نشد؛ ممکن است گزارش ارسال شده باشد. برای جلوگیری از تکرار، خودکار تلاش مجدد نمی‌شود.", "No conclusive response was received; the report may have been sent. Automatic retry is disabled to avoid duplicates."); }
        internal static ScheduledDeliveryException HttpFailure(int status)
        {
            bool uncertain = status == 408 || status >= 500;
            return new ScheduledDeliveryException(uncertain ? Unconfirmed() + " HTTP " + status
                : Lang.T("سرویس درخواست را نپذیرفت؛ کد HTTP: ", "The service did not accept the request; HTTP status: ") + status, uncertain);
        }
        static void Bot(ScheduledDeliveryRequest data, Func<bool> cancel)
        {
            string boundary = "MetaFactory" + Guid.NewGuid().ToString("N"); byte[] payload = Multipart(data, boundary);
            var request = (HttpWebRequest)WebRequest.Create(data.Endpoint);
            request.Method = "POST"; request.AllowAutoRedirect = false; request.KeepAlive = false;
            request.ContentType = "multipart/form-data; boundary=" + boundary; request.ContentLength = payload.Length;
            request.Timeout = request.ReadWriteTimeout = ScheduledDelivery.TimeoutMilliseconds;
            request.AllowWriteStreamBuffering = false;
            var clock = Stopwatch.StartNew(); bool interrupted = false;
            using (var timer = new Timer(_ =>
            {
                bool stop; try { stop = cancel() || clock.ElapsedMilliseconds >= ScheduledDelivery.TimeoutMilliseconds; } catch { stop = true; }
                if (stop) { interrupted = true; try { request.Abort(); } catch { } }
            }, null, 0, 100))
            {
                try
                {
                    using (Stream output = request.GetRequestStream()) output.Write(payload, 0, payload.Length);
                    using (var response = (HttpWebResponse)request.GetResponse())
                    {
                        if ((int)response.StatusCode < 200 || (int)response.StatusCode >= 300)
                            throw HttpFailure((int)response.StatusCode);
                        using (var input = response.GetResponseStream())
                        using (var content = new MemoryStream())
                        {
                            byte[] buffer = new byte[4096]; int read;
                            while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                            { if (content.Length + read > 65536) throw new ScheduledDeliveryException(Unconfirmed(), true); content.Write(buffer, 0, read); }
                            Dictionary<string, object> reply;
                            try { reply = new JavaScriptSerializer { MaxJsonLength = 65536, RecursionLimit = 20 }.Deserialize<Dictionary<string, object>>(Encoding.UTF8.GetString(content.ToArray())); }
                            catch { throw new ScheduledDeliveryException(Unconfirmed(), true); }
                            object ok;
                            if (reply == null || !reply.TryGetValue("ok", out ok) || !(ok is bool)) throw new ScheduledDeliveryException(Unconfirmed(), true);
                            if (!(bool)ok) throw new ScheduledDeliveryException(Lang.T("سرویس ارسال را رد کرد؛ توکن، شناسهٔ گفتگو و دسترسی ربات را بررسی کنید.", "The service rejected delivery; check the token, chat ID and bot permissions."));
                        }
                    }
                }
                catch (WebException e)
                {
                    var response = e.Response as HttpWebResponse;
                    if (response != null) { int status = (int)response.StatusCode; response.Dispose(); throw HttpFailure(status); }
                    throw new ScheduledDeliveryException(Unconfirmed(), true);
                }
                catch (IOException) { throw new ScheduledDeliveryException(Unconfirmed(), true); }
                finally { if (interrupted) try { request.Abort(); } catch { } }
            }
        }
        static void Email(ScheduledDeliveryRequest data, Func<bool> cancel)
        {
            ScheduleOptions options = data.Options;
            using (var message = new MailMessage())
            using (var client = new SmtpClient(options.SmtpHost.Trim(), options.SmtpPort))
            {
                message.From = new MailAddress(options.EmailFrom); message.To.Add(options.EmailTo.Replace(';', ','));
                message.Subject = data.Subject; message.SubjectEncoding = Encoding.UTF8;
                message.Body = data.Body; message.BodyEncoding = Encoding.UTF8; message.IsBodyHtml = false;
                message.Attachments.Add(new Attachment(new MemoryStream(data.Document, false), data.FileName, "text/plain"));
                client.EnableSsl = options.SmtpSsl; client.UseDefaultCredentials = false; client.Timeout = ScheduledDelivery.TimeoutMilliseconds;
                if (!string.IsNullOrWhiteSpace(options.SmtpUser)) client.Credentials = new NetworkCredential(options.SmtpUser, Secret.Unprotect(options.SmtpPasswordEnc));
                var completion = new TaskCompletionSource<AsyncCompletedEventArgs>();
                SendCompletedEventHandler handler = (sender, result) => completion.TrySetResult(result);
                client.SendCompleted += handler;
                try
                {
                    client.SendAsync(message, null); var clock = Stopwatch.StartNew();
                    while (!completion.Task.Wait(100))
                        if (cancel() || clock.ElapsedMilliseconds >= ScheduledDelivery.TimeoutMilliseconds)
                        { client.SendAsyncCancel(); throw new ScheduledDeliveryException(Unconfirmed(), true); }
                    AsyncCompletedEventArgs result = completion.Task.Result;
                    if (result.Cancelled || result.Error != null) throw new ScheduledDeliveryException(Unconfirmed(), true);
                }
                catch (SmtpException) { throw new ScheduledDeliveryException(Unconfirmed(), true); }
                finally { client.SendCompleted -= handler; }
            }
        }
    }
}
