@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Watch-MetaFactory-Update.ps1"
echo.
pause
