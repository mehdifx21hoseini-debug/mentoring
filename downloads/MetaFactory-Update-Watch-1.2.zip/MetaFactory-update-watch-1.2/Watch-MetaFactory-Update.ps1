# MetaFactory Update Watch 1.2 -- no elevation, no updater execution, no settings changes.
$ErrorActionPreference = 'Stop'
$mfOutput = New-Object System.Collections.Generic.List[string]
function Mf-Line([string]$value) { $mfOutput.Add($value) }
function Mf-Try([string]$label, [scriptblock]$action) {
    try { & $action } catch { Mf-Line ($label + ': unavailable (' + $_.Exception.GetType().Name + ')') }
}
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class MfManifest {
 [DllImport("kernel32.dll")] [return:MarshalAs(UnmanagedType.Bool)] public static extern bool IsProcessorFeaturePresent(uint feature);
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern IntPtr LoadLibraryEx(string p, IntPtr f,uint flags);
 [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr FindResource(IntPtr m,IntPtr name,IntPtr type);
 [DllImport("kernel32.dll")] static extern IntPtr LoadResource(IntPtr m,IntPtr r);
 [DllImport("kernel32.dll")] static extern IntPtr LockResource(IntPtr r);
 [DllImport("kernel32.dll")] static extern uint SizeofResource(IntPtr m,IntPtr r);
 [DllImport("kernel32.dll")] static extern bool FreeLibrary(IntPtr m);
 public static string Read(string p) {
  IntPtr m=LoadLibraryEx(p,IntPtr.Zero,2); // AS_DATAFILE: never execute DLL/EXE initialization
  if(m==IntPtr.Zero)return "unavailable";
  try {for(int i=1;i<=3;i++) {
   IntPtr r=FindResource(m,new IntPtr(i),new IntPtr(24));if(r==IntPtr.Zero)continue;
   uint n=SizeofResource(m,r);if(n==0 || n>131072)return "invalid-size";
   IntPtr b=LockResource(LoadResource(m,r));if(b==IntPtr.Zero)return "unavailable";
   byte[] data=new byte[n];Marshal.Copy(b,data,0,(int)n);
   return n>1 && data[0]==255 && data[1]==254 ? Encoding.Unicode.GetString(data) : Encoding.UTF8.GetString(data);
  }return "absent";} finally {FreeLibrary(m);}
 }
}
'@
function Mf-File([string]$path) {
    Mf-Line ('File=' + $path)
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { Mf-Line 'present=False'; return }
    Mf-Try 'file evidence' {
        $item = Get-Item -LiteralPath $path
        Mf-Line ('size=' + $item.Length + '; last-write-UTC=' + $item.LastWriteTimeUtc.ToString('o'))
        Mf-Line ('description=' + $item.VersionInfo.FileDescription + '; version=' + $item.VersionInfo.FileVersion)
        Mf-Line 'sha256=not-computed-during-watch-to-limit-disk-load'
        $sig = Get-AuthenticodeSignature -LiteralPath $path
        Mf-Line ('signature-status=' + $sig.Status)
        if ($null -ne $sig.SignerCertificate) {
            Mf-Line ('signer=' + $sig.SignerCertificate.Subject)
            Mf-Line ('signer-thumbprint=' + $sig.SignerCertificate.Thumbprint)
        }
        $manifest = [MfManifest]::Read($path)
        $level = [regex]::Match($manifest, 'requestedExecutionLevel\s+[^>]*level\s*=\s*["'']([^"'']+)["'']')
        Mf-Line ('manifest-execution-level=' + $(if ($level.Success) { $level.Groups[1].Value } else { 'not-found' }))
        foreach ($hive in @('HKCU:','HKLM:')) {
            Mf-Try 'compatibility' {
                $reg = Get-Item -LiteralPath ($hive + '\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers')
                Mf-Line ($hive + ' compatibility=' + [string]$reg.GetValue($path,'none'))
            }
        }
        Mf-Try 'file access' {
            $acl = Get-Acl -LiteralPath $path
            Mf-Line ('owner=' + $acl.Owner + '; read-only=' + $item.IsReadOnly)
            foreach ($rule in $acl.Access) {
                Mf-Line ('acl=' + $rule.IdentityReference + '; rights=' + $rule.FileSystemRights + '; type=' + $rule.AccessControlType + '; inherited=' + $rule.IsInherited)
            }
        }
    }
}
Mf-Line 'MetaFactory Update Watch 1.2'
Mf-Line ('UTC=' + [DateTime]::UtcNow.ToString('o'))
Mf-Line 'Inspects own MetaQuotes cache directories for all MT5 copies; no fixed account-number filter. Does not launch/stop MetaTrader, request admin rights, or change UAC/registry/ACLs. No passwords/configuration contents collected. Temporary empty write-test files are removed.'
Mf-Try 'Windows' {
    Mf-Line ('OS=' + [Environment]::OSVersion.VersionString + '; 64bit=' + [Environment]::Is64BitOperatingSystem)
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    Mf-Line ('running-elevated=' + $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))
}
Mf-Try 'CPU capability' {
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    Mf-Line ('CPU=' + $cpu.Name + '; logical-processors=' + $cpu.NumberOfLogicalProcessors)
    Mf-Line ('OS-AVX-feature=' + [MfManifest]::IsProcessorFeaturePresent(39) + '; OS-AVX2-feature=' + [MfManifest]::IsProcessorFeaturePresent(40))
}
Mf-Try 'drive E' {
    $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='E:'"
    Mf-Line ('E filesystem=' + $disk.FileSystem + '; free-GB=' + [Math]::Round($disk.FreeSpace/1073741824,2))
}
$mfCache = Join-Path $env:APPDATA 'MetaQuotes\Terminal'
$mfSeen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach ($name in @('MT5-03','MT5-05')) {
    $dir = Join-Path 'E:\MetaTrader' $name
    Mf-Line ('--- Target=' + $dir + ' ---')
    if (-not (Test-Path -LiteralPath $dir -PathType Container)) { Mf-Line 'target-missing'; continue }
    Mf-Try 'directory access' {
        $probe = Join-Path $dir ('mf-write-check-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        $stream = $null
        try {
            $stream = New-Object IO.FileStream($probe,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None,4096,[IO.FileOptions]::DeleteOnClose)
            Mf-Line 'directory-current-user-write=True'
        } finally { if ($null -ne $stream) { $stream.Dispose() }; if (Test-Path -LiteralPath $probe) { Remove-Item -LiteralPath $probe -Force } }
    }
    Mf-File (Join-Path $dir 'terminal64.exe')
    Mf-Try 'own journal updater paths' {
        $logs = @(Get-ChildItem -LiteralPath (Join-Path $dir 'logs') -Filter '*.log' -File | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 2)
        foreach ($log in $logs) {
            foreach ($line in (Get-Content -LiteralPath $log.FullName -Tail 350)) {
                if ($line -notmatch 'LiveUpdate|updateadmin|cannot load config') { continue }
                # Keep only time, phase and paths; never output arbitrary terminal log/config contents.
                $time = [regex]::Match($line,'\d\d:\d\d:\d\d\.\d\d\d').Value
                if ($line -match 'cannot load config') { Mf-Line ('journal=' + $log.Name + '; time=' + $time + '; startup-config-missing=True'); continue }
                $match = [regex]::Match($line,'"([^"\r\n]+\\liveupdate\\terminal64\.exe)"',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
                if (-not $match.Success) { continue }
                $path = [IO.Path]::GetFullPath($match.Groups[1].Value)
                if (-not $path.StartsWith($mfCache + '\',[StringComparison]::OrdinalIgnoreCase)) { continue }
                $relative = $path.Substring($mfCache.Length+1)
                if ($relative -notmatch '^[0-9a-fA-F]{32}\\liveupdate\\terminal64\.exe$') { continue }
                Mf-Line ('journal=' + $log.Name + '; time=' + $time + '; updateadmin=' + ($line -match '/updateadmin'))
                if ($mfSeen.Add($path)) { Mf-File $path }
            }
        }
    }
}
# Exact target from user's expanded UAC screenshot; cache can disappear after update.
$mfExact = Join-Path $mfCache 'C5357C285E6755F83E975D3FF5055739\liveupdate\terminal64.exe'
if ($mfSeen.Add($mfExact)) { Mf-File $mfExact }
$mfDesktop = [Environment]::GetFolderPath('DesktopDirectory')
if (-not (Test-Path -LiteralPath $mfDesktop -PathType Container)) { $mfDesktop = $env:TEMP }
$mfReport = Join-Path $mfDesktop ('MetaFactory-Update-Watch-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt')
function Mf-Save { $mfOutput | Set-Content -LiteralPath $mfReport -Encoding UTF8 }
Mf-Line 'Watch window: up to 10 minutes. No updater execution, no elevation, no changes to installed programs. Cache capture is metadata only.'
Mf-Save
Write-Host ('Report saved: ' + $mfReport)
Write-Host 'Watching own MetaQuotes update caches for up to 10 minutes.'
Write-Host 'Keep this window open during the controlled group test.'
Write-Host 'The report updates automatically. Ctrl+C can stop the watcher.'
$mfDeadline = (Get-Date).AddMinutes(10)
$mfCaptured = @{}
$mfErrorsSeen = @{}
$mfCaptureCount = 0
$mfLoopCount = 0
$mfRootFailures = 0
$mfSeenCandidates = 0
Mf-Line ('watch-root=' + $mfCache)
Mf-Line 'watch-scope=up to 512 non-junction 32-hex MetaQuotes cache directories; any account, signature errors also recorded; max 24 captures; no executable copies or execution'
Mf-Save
Write-Host 'Watching ALL own MT5 updater caches. No account-number restriction.'
Write-Host 'Reopen only the three existing accounts that reproduced the prompt. Do not increase total running accounts.'
Write-Host 'If CAPTURED appears, the Desktop report is already updated. Ctrl+C can stop this tool.'
while ((Get-Date) -lt $mfDeadline -and $mfCaptureCount -lt 24) {
    $mfLoopCount++
    try {
        if (-not (Test-Path -LiteralPath $mfCache -PathType Container)) { throw 'MetaQuotes cache root missing' }
        $mfDirs = @(Get-ChildItem -LiteralPath $mfCache -Directory -ErrorAction Stop |
            Where-Object { $_.Name -match '^[0-9a-fA-F]{32}$' -and -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) } |
            Select-Object -First 512)
        foreach ($mfDir in $mfDirs) {
            $mfPath = Join-Path $mfDir.FullName 'liveupdate\terminal64.exe'
            if (-not (Test-Path -LiteralPath $mfPath -PathType Leaf)) { continue }
            try {
                $mfItem = Get-Item -LiteralPath $mfPath -ErrorAction Stop
                if ($mfItem.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
                if ($mfItem.Length -lt 4096) { continue }
                $mfStamp = $mfItem.Length.ToString() + ':' + $mfItem.LastWriteTimeUtc.Ticks.ToString()
                if ($mfCaptured[$mfPath] -eq $mfStamp) { continue }
                $mfSeenCandidates++
                Mf-Line ('--- Cache observed UTC=' + [DateTime]::UtcNow.ToString('o') + ' ---')
                Mf-Line ('candidate-path=' + $mfPath + '; bytes=' + $mfItem.Length)
                Mf-Try 'candidate signature' {
                    $mfSig = Get-AuthenticodeSignature -LiteralPath $mfPath
                    Mf-Line ('candidate-signature-status=' + $mfSig.Status)
                    if ($null -ne $mfSig.SignerCertificate) { Mf-Line ('candidate-signer=' + $mfSig.SignerCertificate.Subject) }
                }
                # Never silently discard a candidate just because trust verification fails.
                Mf-Try 'candidate manifest' {
                    $mfXml = [MfManifest]::Read($mfPath)
                    $mfLevel = [regex]::Match($mfXml, 'requestedExecutionLevel\s+[^>]*level\s*=\s*["'']([^"'']+)["'']')
                    Mf-Line ('candidate-manifest=' + $(if ($mfLevel.Success) { $mfLevel.Groups[1].Value } else { 'not-found' }))
                }
                Mf-File $mfPath
                $mfCaptured[$mfPath] = $mfStamp
                $mfCaptureCount++
                Mf-Line ('watch-capture-count=' + $mfCaptureCount)
                Mf-Save
                Write-Host ('CAPTURED: ' + $mfPath)
                Write-Host ('Report updated: ' + $mfReport)
                if ($mfCaptureCount -ge 24) { break }
            } catch {
                $mfErrorKey = $mfPath + ':' + $_.Exception.GetType().Name
                if (-not $mfErrorsSeen.ContainsKey($mfErrorKey)) {
                    $mfErrorsSeen[$mfErrorKey] = $true
                    Mf-Line ('candidate-read-error=' + $mfPath + '; type=' + $_.Exception.GetType().Name)
                    Mf-Save
                }
            }
        }
    } catch {
        $mfRootFailures++
        if ($mfRootFailures -eq 1) {
            Mf-Line ('watch-root-error=' + $_.Exception.GetType().Name)
            Mf-Save
            Write-Host 'Cache scan failed; the report records this failure.'
        }
    }
    if (($mfLoopCount % 10) -eq 0) {
        Mf-Line ('watch-status-UTC=' + [DateTime]::UtcNow.ToString('o') + '; loops=' + $mfLoopCount + '; captures=' + $mfCaptureCount + '; scan-errors=' + $mfRootFailures)
        Mf-Save
    }
    Start-Sleep -Seconds 3
}
Mf-Line ('watch-observed-candidates=' + $mfSeenCandidates)
Mf-Line ('watch-capture-count-final=' + $mfCaptureCount)
Mf-Line ('watch-scan-errors=' + $mfRootFailures)
Mf-Line ('watch-finished-UTC=' + [DateTime]::UtcNow.ToString('o'))
Mf-Save
Write-Host ('Finished. Send: ' + $mfReport)
Write-Host 'No update or UAC automation was performed.'
