using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MTManager
{
    static partial class Tests
    {
        static void ReportRunChecks()
        {
            var summary = new ReportRunSummary();
            for (int n = 0; n < 110; n++) summary.Add("s" + n, new Account { Trader = "Student " + n, Login = (1000 + n).ToString(), Server = "Broker-Demo" }, Kind.MT5);
            for (int n = 0; n < 70; n++) summary.Record("s" + n, new ReportRow { Journal = new AccountJournal() });
            for (int n = 70; n < 90; n++) summary.Record("s" + n, new ReportRow { Error = "connection failed" });
            summary.StopPending(); summary.End();
            Equal(110, summary.Total, "summary covers entire selected batch"); Equal(70, summary.Fresh, "summary reports seventy fresh successes");
            Equal(40, summary.Unread, "summary reports forty without a fresh report"); Equal(20, summary.Failed, "actual failures distinguished from unattempted accounts");
            Equal(20, summary.Stopped, "stopped unattempted accounts counted separately"); Equal(0, summary.Pending, "finished stopped summary has no hanging pending rows");
            Check(summary.Rows.Where(r => r.State == "failed").All(r => r.Reason == "connection failed"), "each failed account keeps its own reason");
            summary.Record("s0", new ReportRow { Journal = new AccountJournal() }); Equal(70, summary.Fresh, "repeated final callbacks do not double-count successes");
            summary.Begin(); summary.Add("cached", new Account { Login = "123" }, Kind.MT4);
            summary.Record("cached", new ReportRow { Journal = new AccountJournal(), Cached = true, Note = "earlier report; fresh connection failed" });
            Equal(0, summary.Fresh, "cached history is never counted as a fresh successful report"); Equal(1, summary.Cached, "cached history has its own result count");
            Equal(1, summary.Unread, "cached fallback still means the fresh report was not read");
            string file = Path.Combine(root, "report-results.xlsx"); summary.Export(file);
            Check(Spreadsheet.Read(file).Count == 2, "per-student report result exports to Excel");
            Check(Spreadsheet.Read(file)[1].Cells[6].Contains("fresh connection failed"), "Excel result includes the original per-row failure reason");
            Check(Installation.AppName == "MetaFactory" && Installation.LegacyAppNames.Contains("MT Manager") && Installation.LegacyAppNames.Contains("MTManager"), "installer migrates both English legacy desktop shortcut names");
            Check(LaunchMemoryPolicy.CanStart(8192, 4096, Kind.MT4, 200), "bulk launch proceeds with adequate free physical memory");
            Check(!LaunchMemoryPolicy.CanStart(8192, 800, Kind.MT4, 200), "bulk launch halts before exhausting physical memory");
            Check(!LaunchMemoryPolicy.CanStart(0, 0, Kind.MT5, 0), "unavailable memory measurement cannot trigger a blind bulk launch");
            Check(LaunchMemoryPolicy.Required(Kind.MT5, 1000) >= 1250, "launch guard adjusts to observed terminal peak with headroom");
            Check(LaunchMemoryPolicy.Reserve(131072) == 4096 && LaunchMemoryPolicy.Reserve(4096) >= 768, "launch policy reserves capacity for Windows on both small and large machines");
            Check(!LaunchMemoryPolicy.StartupTimedOut(10, false) && LaunchMemoryPolicy.StartupTimedOut(16, false) && !LaunchMemoryPolicy.StartupTimedOut(16, true), "bulk launch waits for a window but stops stalled startup");
            RetryAndCancelChecks();
            TradeOnlyReportChecks();
            ReportingSpeedChecks();
            Mt5StartupRecoveryChecks();
        }
        static void Mt5StartupRecoveryChecks()
        {
            var scoped = new List<Instance> { new Instance { Name = "four-a", Kind = Kind.MT4 }, new Instance { Name = "five-a", Kind = Kind.MT5 }, new Instance { Name = "four-b", Kind = Kind.MT4 } };
            Equal("four-a,four-b", string.Join(",", ReportScopes.Select(scoped, Kind.MT4).Select(i => i.Name)), "MT4-only report selection preserves exactly the supplied MT4 students");
            Equal("five-a", string.Join(",", ReportScopes.Select(scoped, Kind.MT5).Select(i => i.Name)), "MT5-only selection never queues MT4 students");
            Check(ReportScopes.Select(scoped, null).SequenceEqual(scoped) && ReportScopes.Select(scoped.Take(1), Kind.MT5).Count == 0, "all scope keeps original selection and never pulls accounts from outside that selection");
            Equal("8B41E4C3A75AAE7E8F255A11B3A23A683FF7B2B632A53A3B181A9EDAC2F2704F", ReportScript.Stamp(ReportScript.SourceText(Kind.MT4)), "MT4 reporter is byte-for-byte frozen at the user-approved version");
            string source = ReportScript.SourceText(Kind.MT5);
            int start = source.IndexOf("bool LoadRequest()", StringComparison.Ordinal), end = source.IndexOf("int OnInit()", start, StringComparison.Ordinal);
            string request = source.Substring(start, end - start);
            Check(!request.Contains("FileDelete(") && request.Contains("ExpectedAccount()") && request.Contains("TERMINAL_CONNECTED"), "MT5 cannot consume and lose a pending request before the requested account is ready");
            Check(source.Contains("if(!IsStopped()) Fail") && source.Contains("if(ExportReport()) lastHandledToken = WorkToken;"), "MT5 reinitialization is not published as a connection failure and only successful work is acknowledged");
            Check(source.Contains("bool CompletedRequest(string token)") && source.Contains("proof == \"Q\\t\" + token"), "MT5 restart replay is deduplicated using the actual request output");
            Check(!source.Contains("if(!ServeMode)") && source.Contains("Step(\"ready\");"), "MT5 dispatch no longer depends on a preset serving flag and reports initialization separately");
            DateTime day = new DateTime(2026, 11, 10); string token = new string('d', 32), file = Path.Combine(root, "mt5-startup-proof.txt");
            var a = new Account { Login = "777", Server = "Test-Demo" };
            var j = new AccountJournal { Login = "777", Server = "Test-Demo", Platform = "MT4", ScriptVersion = "1.22", Complete = true, From = day, Exported = day.AddHours(10), FloatingBars = AccountJournal.TradesOnly, HistoryChecked = true, HistoryOk = true };
            Action put = () => { string raw = JournalFile.Write(j); int first = raw.IndexOf("\r\n", StringComparison.Ordinal); File.WriteAllText(file, raw.Insert(first + 2, "Q\t" + token + "\r\n")); };
            put(); Check(ReportRunner.ReadOutput(file, a, day, token).Journal != null, "MT4 keeps its existing live protocol and acceptance behavior");
            j.Platform = "MT5"; put(); Check(ReportRunner.ReadOutput(file, a, day, token).Journal == null, "MT5's old startup protocol cannot be mistaken for the corrected reporter");
            j.ScriptVersion = "1.23"; put(); Check(ReportRunner.ReadOutput(file, a, day, token).Journal != null, "MT5 accepts the corrected fresh startup protocol");
        }
        static void ReportingSpeedChecks()
        {
            DateTime day = new DateTime(2026, 11, 10); string token = new string('a', 32);
            var account = new Account { Login = "888", Server = "Broker-Demo" };
            var journal = new AccountJournal { Login = "888", Server = account.Server, Currency = "USD", Platform = "MT5", Complete = true, ScriptVersion = "1.23", From = day, Exported = day.AddHours(20), FloatingBars = AccountJournal.TradesOnly, HistoryChecked = true, HistoryOk = true };
            string file = Path.Combine(root, "fresh-proof.txt");
            Action<string> put = proof => { string raw = JournalFile.Write(journal); int line = raw.IndexOf("\r\n", StringComparison.Ordinal); File.WriteAllText(file, raw.Insert(line + 2, "Q\t" + proof + "\r\n")); };
            put(token);
            Check(ReportRunner.ReadOutput(file, account, day, token).Journal != null, "production report requires the current request, account, server and reporter version");
            Check(ReportRunner.ReadOutput(file, account, day, new string('b', 32)) == null, "a previous request cannot satisfy a fresh report");
            account.Server = "Different-Server"; Check(ReportRunner.ReadOutput(file, account, day, token).Journal == null, "matching login on the wrong broker server is rejected"); account.Server = journal.Server;
            journal.ScriptVersion = "1.21"; put(token); Check(ReportRunner.ReadOutput(file, account, day, token).Journal == null, "old reporter output cannot silently pass as the current fast protocol");
            journal.ScriptVersion = "1.23"; journal.HistoryChecked = false; put(token); Check(ReportRunner.ReadOutput(file, account, day, token).Journal == null, "missing history readiness check is not accepted");
            journal.HistoryChecked = true; put(token);
            AccountJournal parsed = JournalFile.Parse(File.ReadAllText(file));
            Check(parsed.RequestToken == token && !JournalFile.Write(parsed).Contains("Q\t"), "live proof is parsed but never replayable from the saved history cache");
            var summary = new ReportRunSummary(); summary.Add("only", account, Kind.MT5);
            var row = new ReportRow { Journal = journal, Route = "MT5-warm-IPC+native", ReadMs = 500, TotalMs = 500 };
            summary.Record("only", row); row.TotalMs = 1500; summary.Record("only", row);
            Check(summary.Fresh == 1 && summary.Rows[0].ReadMs == 500 && summary.Rows[0].TotalMs == 1500, "cleanup timing updates without double-counting an early completed report");
            string output = Path.Combine(root, "timed-report.xlsx"); summary.Export(output);
            Check(Spreadsheet.Read(output)[1].Cells[9] == "MT5-warm-IPC+native" && Spreadsheet.Read(output)[1].Cells[11] == "1500", "Excel outcomes include route and actual read/total durations without credentials");
            var grouped = new List<ReportJob>();
            foreach (string server in new[] { "A", "B", "a", "B" }) grouped.Add(new ReportJob { Copy = new Instance { Kind = Kind.MT5 }, Account = new Account { Server = server } });
            Equal("0,2,1,3", string.Join(",", ReportRunner.Schedule(grouped, new[] { 0, 1, 2, 3 })), "same-server work is grouped stably to reduce terminal restarts");
            var firstReady = new ManualResetEvent(false); var finishCleanup = new ManualResetEvent(false);
            var job = new ReportJob { Index = 0, Name = "one", Copy = new Instance { Kind = Kind.MT4, Name = "one" }, Account = account };
            ReportRunner runner = null;
            runner = new ReportRunner(new Settings(), new List<ReportJob> { job }, new List<Instance>(), name => null, new ReportRange { From = day, To = day.AddDays(1) }, 1, (j, slot) => {
                var result = new ReportRow { Name = "one", Copy = "one" };
                runner.Commit(j, result, new ReportRunner.Outcome { Journal = journal });
                finishCleanup.WaitOne(3000); return result;
            });
            runner.ResultReady = (index, result) => firstReady.Set();
            var running = Task.Factory.StartNew(() => runner.Run());
            bool early = firstReady.WaitOne(2000); bool cleanupStillPending = !running.IsCompleted;
            finishCleanup.Set(); Check(running.Wait(2000), "report completion finishes after cleanup is released");
            Check(early && cleanupStillPending, "verified report is published before terminal cleanup finishes");
            firstReady.Dispose(); finishCleanup.Dispose();
            foreach (Kind kind in new[] { Kind.MT4, Kind.MT5 })
            {
                var preset = ReportLaunch.Preset(day, account, token, kind == Kind.MT5);
                Check(preset.Contains("ExpectedLogin=888") && preset.Contains("ExpectedServer=Broker-Demo") && preset.Contains("RequestToken=" + token), kind + " preset carries account and fresh request proof, never a password");
                string src = ReportScript.SourceText(kind);
                Check(src.Contains("ExpectedAccount()") && src.Contains("WorkToken") && src.Contains("lastSum"), kind + " reporter checks account identity and stable history values");
            }
            Check(ReportScript.SourceText(Kind.MT5).Contains("if(ExportReport()) lastHandledToken = WorkToken;") && ReportScript.SourceText(Kind.MT5).Contains("int OnInit()") && ReportScript.SourceText(Kind.MT5).Contains("void OnTimer()"), "MT5 resident reporter can export another native snapshot without restarting its script");
        }
        static void TradeOnlyReportChecks()
        {
            DateTime day = new DateTime(2026, 11, 10);
            foreach (string platform in new[] { "MT4", "MT5" })
            {
                var j = new AccountJournal { Platform = platform, Login = "5678", Server = "Test-Demo", Currency = "USD", From = day, Exported = day.AddHours(20), Balance = 1000, Equity = 1003, Complete = true, ScriptVersion = "1.21", FloatingBars = AccountJournal.TradesOnly };
                j.Trades.Add(new JournalTrade { Ticket = 1, Symbol = "EURUSD", Buy = true, Volume = 0.1, Open = day.AddHours(9), Close = day.AddHours(10), OpenPrice = 1.1, ClosePrice = 1.11, SlEntry = platform == "MT4" ? -1 : 0, SlFinal = 0, Tp = 1.12, Profit = 10, Commission = -0.2, Swap = -0.1 });
                j.Trades.Add(new JournalTrade { Ticket = 2, Symbol = "EURUSD", Buy = false, Volume = 0.2, Open = day.AddHours(11), Close = day.AddHours(12), OpenPrice = 1.11, ClosePrice = 1.12, SlEntry = platform == "MT4" ? -1 : 1.13, SlFinal = 1.13, Profit = -5 });
                j.Open.Add(new JournalOpen { Ticket = 3, Symbol = "XAUUSD", Buy = true, Volume = 0.1, Open = day.AddHours(14), OpenPrice = 2000, Price = 2003, SlEntry = platform == "MT4" ? -1 : 0, Sl = 0, Tp = 2010, Profit = 3 });
                j.Floating[day.AddHours(9)] = -100; // A stale candle estimate must never survive the trade-only marker.
                AccountJournal parsed = JournalFile.Parse(JournalFile.Write(j));
                Check(parsed.Complete && parsed.FloatingDisabled && parsed.Floating.Count == 0, platform + " trade-only file remains complete and drops stale candle estimates");
                Check(parsed.Trades.Count == 2 && parsed.Open.Count == 1 && Math.Abs(parsed.Trades[0].Net - 9.7) < 0.00001, platform + " trades, open positions, commissions and swaps survive trade-only export");
                Check(Stops.Of(parsed.Trades[0].SlEntry, parsed.Trades[0].SlFinal) == StopKind.Unprotected && Stops.Of(parsed.Trades[1].SlEntry, parsed.Trades[1].SlFinal) == (platform == "MT4" ? StopKind.Mt4 : StopKind.Strict), platform + " stop-loss classification needs no chart bars");
                var range = new ReportRange { From = day, To = day.AddDays(1) };
                JournalSummary stats = JournalMath.Summarize(parsed, range.From, range.To, new TradeLimits());
                Check(double.IsNaN(stats.MaxDailyDdPct) && !stats.DdRed, platform + " omitted historical drawdown is unknown, never zero or a violation");
                var view = PanelMath.Build(parsed, range, new TradeLimits());
                Check(view.FloatingDisabled && view.NoSl == 2 && view.TradeCount == 3 && double.IsNaN(view.DdPct), platform + " lightweight report still displays trades and No SL warnings");
                var old = new AccountJournal { Login = "5678", From = day.AddDays(-2), Exported = day.AddHours(1), Complete = true };
                old.Floating[day.AddDays(-1)] = -200;
                old.Trades.Add(new JournalTrade { Ticket = 4, Open = day.AddDays(-1), Close = day.AddDays(-1).AddHours(1), Profit = 7 });
                var merged = JournalCache.Merge(old, parsed);
                Check(merged.FloatingDisabled && merged.Floating.Count == 0 && merged.Trades.Count == 3, platform + " incremental merge preserves prior trades without resurrecting historical candle data");
                Check(!Coach.Analyze(merged, JournalMath.Summarize(merged, old.From, range.To, new TradeLimits()), old.From, range.To).EquityKnown, platform + " removed candle estimates do not appear as known equity drawdown");
            }
            var start5 = ReportLaunch.StartLines(Kind.MT5, new Account { Login = "1", Server = "S" }, "fake", "EURUSD");
            Check(start5.Contains("Expert=MTManagerReport") && start5.Contains("ExpertParameters=mtm-report.set") && start5.Contains("ShutdownTerminal=0") && !start5.Any(x => x.StartsWith("Script=")), "MT5 starts the read-only timer expert without script auto-shutdown");
            Check(ReportLaunch.PresetPaths(new Instance { Dir = "private", Kind = Kind.MT5 }).Any(x => x.Contains(Path.Combine("Profiles", "Presets"))), "MT5 expert inputs are deployed in its official Profiles/Presets location");
            var work = new System.Drawing.Rectangle(-1920, 0, 1920, 1080);
            var owner = new System.Drawing.Rectangle(-1850, 100, 300, 400);
            var row = new System.Drawing.Rectangle(-1850, 250, 300, 30);
            var child = new System.Drawing.Size(280, 350);
            var at = FluentMenuItem.Adjacent(owner, row, child, work, true);
            Check(at.X == owner.Right - 1 && at.Y == row.Top, "RTL submenu flips to adjacent right edge on a negative-coordinate monitor");
            owner.X = -500; row.X = -500;
            at = FluentMenuItem.Adjacent(owner, row, child, work, false);
            Check(at.X + child.Width == owner.Left + 1, "LTR submenu flips to adjacent left edge when there is no space on the right");
        }
        static void RetryAndCancelChecks()
        {
            var settings = new Settings { BaseDir = Dir("report-run-fakes") };
            var jobs = new List<ReportJob>();
            foreach (string name in new[] { "first", "second", "permanent", "always-transient" })
                jobs.Add(new ReportJob { Index = jobs.Count, Name = name, Copy = new Instance { Name = name, Kind = Kind.MT5, Dir = settings.BaseDir }, Account = new Account { Login = (100 + jobs.Count).ToString(), Server = "Broker-Demo" } });
            var sequence = new List<string>();
            var runner = new ReportRunner(settings, jobs, new List<Instance>(), name => null, new ReportRange { From = DateTime.Today.AddDays(-1), To = DateTime.Today }, 1,
                (job, slot) => {
                    sequence.Add(job.Copy.Name + ":" + job.Attempt);
                    if (job.Name == "first" && job.Attempt == 1 || job.Name == "always-transient") return new ReportRow { Copy = job.Copy.Name, Error = "temporary connection issue", Retryable = true };
                    if (job.Name == "permanent") return new ReportRow { Copy = job.Copy.Name, Error = "wrong password" };
                    return new ReportRow { Copy = job.Copy.Name, Journal = new AccountJournal() };
                });
            var results = runner.Run();
            Equal("first:1,second:1,permanent:1,always-transient:1,first:2,always-transient:2", string.Join(",", sequence), "one deferred retry runs only after all first-pass accounts");
            Check(results[0].Journal != null && results[0].Attempts == 2, "transient first failure can become a successful fresh report");
            Equal(1, results[2].Attempts, "permanent credential failures are not retried automatically");
            Equal(2, results[3].Attempts, "repeated transient failure stops after two passes");
            var started = new ManualResetEvent(false); ReportRunner cancellable = null;
            cancellable = new ReportRunner(settings, jobs, new List<Instance>(), name => null, new ReportRange { From = DateTime.Today.AddDays(-1), To = DateTime.Today }, 1,
                (job, slot) => { started.Set(); while (!cancellable.Stopping) Thread.Sleep(10); return new ReportRow { Copy = job.Copy.Name, Cancelled = true, Error = "stopped" }; });
            Task<List<ReportRow>> task = Task.Factory.StartNew(() => cancellable.Run());
            Check(started.WaitOne(2000), "cancellation test reaches the active report"); cancellable.EndNow();
            Check(task.Wait(2000), "stop ends the report batch without waiting for all accounts");
            Check(task.Result.All(r => r.Cancelled), "stopped accounts are not mislabeled as successful or authentication failures");
            Check(task.Result.Skip(1).All(r => r.Attempts == 0), "accounts skipped by stop have zero attempts"); started.Dispose();
            string source = Dir("report-cancel-copy-source"); Touch(Path.Combine(source, "terminal.exe"));
            var candidate = new Instance { Kind = Kind.MT4, Name = "candidate", Dir = source };
            Throws<OperationCanceledException>(() => ReportCopies.Prepare(settings, Kind.MT4, "Cancel-Demo", 9, () => candidate, () => true), "report copy preparation honors stop before deployment");
            Check(!File.Exists(ReportCopies.For(settings, Kind.MT4, "Cancel-Demo", 9).Exe), "cancelled provisioning never exposes a partial report executable");
        }
    }
}
