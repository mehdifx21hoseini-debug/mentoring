using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MTManager
{
    static partial class Tests
    {
        static void ReportRunChecks()
        {
            var summary = new ReportRunSummary();
            for (int n = 0; n < 110; n++) summary.Add("s" + n, new Account { Trader = "Student " + n, Login = (1000 + n).ToString(), Server = "Broker-Demo" }, Kind.MT5);
            for (int n = 0; n < 70; n++) summary.Record("s" + n, new ReportRow { Journal = new AccountJournal() });
            for (int n = 70; n < 90; n++) summary.Record("s" + n, new ReportRow { Error = "connection failed" });
            summary.StopPending(); summary.End();
            Equal(110, summary.Total, "summary covers entire selected batch"); Equal(70, summary.Fresh, "summary reports seventy fresh successes");
            Equal(40, summary.Unread, "summary reports forty without a fresh report"); Equal(20, summary.Failed, "actual failures distinguished from unattempted accounts");
            Equal(20, summary.Stopped, "stopped unattempted accounts counted separately"); Equal(0, summary.Pending, "finished stopped summary has no hanging pending rows");
            Check(summary.Rows.Where(r => r.State == "failed").All(r => r.Reason == "connection failed"), "each failed account keeps its own reason");
            summary.Record("s0", new ReportRow { Journal = new AccountJournal() }); Equal(70, summary.Fresh, "repeated final callbacks do not double-count successes");
            summary.Begin(); summary.Add("cached", new Account { Login = "123" }, Kind.MT4);
            summary.Record("cached", new ReportRow { Journal = new AccountJournal(), Cached = true, Note = "earlier report; fresh connection failed" });
            Equal(0, summary.Fresh, "cached history is never counted as a fresh successful report"); Equal(1, summary.Cached, "cached history has its own result count");
            Equal(1, summary.Unread, "cached fallback still means the fresh report was not read");
            string file = Path.Combine(root, "report-results.xlsx"); summary.Export(file);
            Check(Spreadsheet.Read(file).Count == 2, "per-student report result exports to Excel");
            Check(Spreadsheet.Read(file)[1].Cells[6].Contains("fresh connection failed"), "Excel result includes the original per-row failure reason");
            Check(Installation.AppName == "MetaFactory" && Installation.LegacyAppNames.Contains("MT Manager") && Installation.LegacyAppNames.Contains("MTManager"), "installer migrates both English legacy desktop shortcut names");
            Check(LaunchMemoryPolicy.CanStart(8192, 4096, Kind.MT4, 200), "bulk launch proceeds with adequate free physical memory");
            Check(!LaunchMemoryPolicy.CanStart(8192, 800, Kind.MT4, 200), "bulk launch halts before exhausting physical memory");
            Check(!LaunchMemoryPolicy.CanStart(0, 0, Kind.MT5, 0), "unavailable memory measurement cannot trigger a blind bulk launch");
            Check(LaunchMemoryPolicy.Required(Kind.MT5, 1000) >= 1250, "launch guard adjusts to observed terminal peak with headroom");
            Check(LaunchMemoryPolicy.Reserve(131072) == 4096 && LaunchMemoryPolicy.Reserve(4096) >= 768, "launch policy reserves capacity for Windows on both small and large machines");
            Check(!LaunchMemoryPolicy.StartupTimedOut(10, false) && LaunchMemoryPolicy.StartupTimedOut(16, false) && !LaunchMemoryPolicy.StartupTimedOut(16, true), "bulk launch waits for a window but stops stalled startup");
            RetryAndCancelChecks();
            TradeOnlyReportChecks();
        }
        static void TradeOnlyReportChecks()
        {
            DateTime day = new DateTime(2026, 11, 10);
            foreach (string platform in new[] { "MT4", "MT5" })
            {
                var j = new AccountJournal { Platform = platform, Login = "5678", Server = "Test-Demo", Currency = "USD", From = day, Exported = day.AddHours(20), Balance = 1000, Equity = 1003, Complete = true, ScriptVersion = "1.21", FloatingBars = AccountJournal.TradesOnly };
                j.Trades.Add(new JournalTrade { Ticket = 1, Symbol = "EURUSD", Buy = true, Volume = 0.1, Open = day.AddHours(9), Close = day.AddHours(10), OpenPrice = 1.1, ClosePrice = 1.11, SlEntry = platform == "MT4" ? -1 : 0, SlFinal = 0, Tp = 1.12, Profit = 10, Commission = -0.2, Swap = -0.1 });
                j.Trades.Add(new JournalTrade { Ticket = 2, Symbol = "EURUSD", Buy = false, Volume = 0.2, Open = day.AddHours(11), Close = day.AddHours(12), OpenPrice = 1.11, ClosePrice = 1.12, SlEntry = platform == "MT4" ? -1 : 1.13, SlFinal = 1.13, Profit = -5 });
                j.Open.Add(new JournalOpen { Ticket = 3, Symbol = "XAUUSD", Buy = true, Volume = 0.1, Open = day.AddHours(14), OpenPrice = 2000, Price = 2003, SlEntry = platform == "MT4" ? -1 : 0, Sl = 0, Tp = 2010, Profit = 3 });
                j.Floating[day.AddHours(9)] = -100; // A stale candle estimate must never survive the trade-only marker.
                AccountJournal parsed = JournalFile.Parse(JournalFile.Write(j));
                Check(parsed.Complete && parsed.FloatingDisabled && parsed.Floating.Count == 0, platform + " trade-only file remains complete and drops stale candle estimates");
                Check(parsed.Trades.Count == 2 && parsed.Open.Count == 1 && Math.Abs(parsed.Trades[0].Net - 9.7) < 0.00001, platform + " trades, open positions, commissions and swaps survive trade-only export");
                Check(Stops.Of(parsed.Trades[0].SlEntry, parsed.Trades[0].SlFinal) == StopKind.Unprotected && Stops.Of(parsed.Trades[1].SlEntry, parsed.Trades[1].SlFinal) == (platform == "MT4" ? StopKind.Mt4 : StopKind.Strict), platform + " stop-loss classification needs no chart bars");
                var range = new ReportRange { From = day, To = day.AddDays(1) };
                JournalSummary stats = JournalMath.Summarize(parsed, range.From, range.To, new TradeLimits());
                Check(double.IsNaN(stats.MaxDailyDdPct) && !stats.DdRed, platform + " omitted historical drawdown is unknown, never zero or a violation");
                var view = PanelMath.Build(parsed, range, new TradeLimits());
                Check(view.FloatingDisabled && view.NoSl == 2 && view.TradeCount == 3 && double.IsNaN(view.DdPct), platform + " lightweight report still displays trades and No SL warnings");
                var old = new AccountJournal { Login = "5678", From = day.AddDays(-2), Exported = day.AddHours(1), Complete = true };
                old.Floating[day.AddDays(-1)] = -200;
                old.Trades.Add(new JournalTrade { Ticket = 4, Open = day.AddDays(-1), Close = day.AddDays(-1).AddHours(1), Profit = 7 });
                var merged = JournalCache.Merge(old, parsed);
                Check(merged.FloatingDisabled && merged.Floating.Count == 0 && merged.Trades.Count == 3, platform + " incremental merge preserves prior trades without resurrecting historical candle data");
                Check(!Coach.Analyze(merged, JournalMath.Summarize(merged, old.From, range.To, new TradeLimits()), old.From, range.To).EquityKnown, platform + " removed candle estimates do not appear as known equity drawdown");
            }
            var work = new System.Drawing.Rectangle(-1920, 0, 1920, 1080);
            var owner = new System.Drawing.Rectangle(-1850, 100, 300, 400);
            var row = new System.Drawing.Rectangle(-1850, 250, 300, 30);
            var child = new System.Drawing.Size(280, 350);
            var at = FluentMenuItem.Adjacent(owner, row, child, work, true);
            Check(at.X == owner.Right - 1 && at.Y == row.Top, "RTL submenu flips to adjacent right edge on a negative-coordinate monitor");
            owner.X = -500; row.X = -500;
            at = FluentMenuItem.Adjacent(owner, row, child, work, false);
            Check(at.X + child.Width == owner.Left + 1, "LTR submenu flips to adjacent left edge when there is no space on the right");
        }
        static void RetryAndCancelChecks()
        {
            var settings = new Settings { BaseDir = Dir("report-run-fakes") };
            var jobs = new List<ReportJob>();
            foreach (string name in new[] { "first", "second", "permanent", "always-transient" })
                jobs.Add(new ReportJob { Index = jobs.Count, Name = name, Copy = new Instance { Name = name, Kind = Kind.MT5, Dir = settings.BaseDir }, Account = new Account { Login = (100 + jobs.Count).ToString(), Server = "Broker-Demo" } });
            var sequence = new List<string>();
            var runner = new ReportRunner(settings, jobs, new List<Instance>(), name => null, new ReportRange { From = DateTime.Today.AddDays(-1), To = DateTime.Today }, 1,
                (job, slot) => {
                    sequence.Add(job.Copy.Name + ":" + job.Attempt);
                    if (job.Name == "first" && job.Attempt == 1 || job.Name == "always-transient") return new ReportRow { Copy = job.Copy.Name, Error = "temporary connection issue", Retryable = true };
                    if (job.Name == "permanent") return new ReportRow { Copy = job.Copy.Name, Error = "wrong password" };
                    return new ReportRow { Copy = job.Copy.Name, Journal = new AccountJournal() };
                });
            var results = runner.Run();
            Equal("first:1,second:1,permanent:1,always-transient:1,first:2,always-transient:2", string.Join(",", sequence), "one deferred retry runs only after all first-pass accounts");
            Check(results[0].Journal != null && results[0].Attempts == 2, "transient first failure can become a successful fresh report");
            Equal(1, results[2].Attempts, "permanent credential failures are not retried automatically");
            Equal(2, results[3].Attempts, "repeated transient failure stops after two passes");
            var started = new ManualResetEvent(false); ReportRunner cancellable = null;
            cancellable = new ReportRunner(settings, jobs, new List<Instance>(), name => null, new ReportRange { From = DateTime.Today.AddDays(-1), To = DateTime.Today }, 1,
                (job, slot) => { started.Set(); while (!cancellable.Stopping) Thread.Sleep(10); return new ReportRow { Copy = job.Copy.Name, Cancelled = true, Error = "stopped" }; });
            Task<List<ReportRow>> task = Task.Factory.StartNew(() => cancellable.Run());
            Check(started.WaitOne(2000), "cancellation test reaches the active report"); cancellable.EndNow();
            Check(task.Wait(2000), "stop ends the report batch without waiting for all accounts");
            Check(task.Result.All(r => r.Cancelled), "stopped accounts are not mislabeled as successful or authentication failures");
            Check(task.Result.Skip(1).All(r => r.Attempts == 0), "accounts skipped by stop have zero attempts"); started.Dispose();
            string source = Dir("report-cancel-copy-source"); Touch(Path.Combine(source, "terminal.exe"));
            var candidate = new Instance { Kind = Kind.MT4, Name = "candidate", Dir = source };
            Throws<OperationCanceledException>(() => ReportCopies.Prepare(settings, Kind.MT4, "Cancel-Demo", 9, () => candidate, () => true), "report copy preparation honors stop before deployment");
            Check(!File.Exists(ReportCopies.For(settings, Kind.MT4, "Cancel-Demo", 9).Exe), "cancelled provisioning never exposes a partial report executable");
        }
    }
}
