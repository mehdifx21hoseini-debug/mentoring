using System;
using System.Globalization;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace MTManager
{
    /// <summary>Checks of everything that does not need Windows itself. Run with mono; exit code = failures.</summary>
    static partial class Tests
    {
        static int failures, passed;
        static string root;

        static void Check(bool ok, string what)
        {
            if (ok) { passed++; return; }
            failures++;
            Console.WriteLine("FAIL: " + what);
        }

        static void Equal<T>(T expected, T actual, string what)
        {
            Check(EqualityComparer<T>.Default.Equals(expected, actual), what + " (expected " + expected + ", got " + actual + ")");
        }

        static void Throws<TEx>(Action a, string what) where TEx : Exception
        {
            try { a(); Check(false, what + " (no exception)"); }
            catch (TEx) { passed++; }
            catch (Exception e) { Check(false, what + " (wrong exception " + e.GetType().Name + ": " + e.Message + ")"); }
        }

        static string Dir(params string[] parts)
        {
            string d = Path.Combine(new[] { root }.Concat(parts).ToArray());
            Directory.CreateDirectory(d);
            return d;
        }

        static void Touch(string path, string text = "x")
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, text);
        }

        static int Main()
        {
            root = Path.Combine(Path.GetTempPath(), "mtm-test-" + Guid.NewGuid().ToString("N"));
            AppPaths.DataDirOverride = Dir("appdata");
            try
            {
                Digits();
                SettingsRoundTrip();
                Secrets();
                AccountsRoundTrip();
                CopiesAndInstalls();
                LeanAndCleanup();
                TextAndDates();
                ChartsAndOldMonitor();
                StartFiles();
                HeapValue();
                CsvParsing();
                CsvImport();
                QuickChecks();
                ServerList();
                LoginCheck();
                BuildFolders();
                Pacing();
                MetaTraderUpdate();
                Mt4Cap();
                OwnedOnly();
                Passwords();
                StartFileCleanup();
                SchemaUpgrade();
                TickedRows();
                Closing();
                FolderGroups();
                FolderImport();
                JournalEngine();
                ReportCache();
                ReportCopyFiles();
                ReportRun();
                CoachingMetrics();
                ReportSteps();
                ReportChartRetry();
                StatementData();
                CoachNumbers();
                BehaviourRules();
                ExpectancyAndDrawdown();
                DrawdownAndEquity();
                AllHistory();
                ProcessSafety();
                ReadingAccuracy();
                InlineReport();
                DayTextFormat();
                ReportTextFormat();
                EarlyCloseReasons();
                ListArrange();
                BackupCore();
                BackupRoundTrip();
                BulkStudentImport();
                BulkImportCancellation();
                LoginConfirmationRegression();
                StudentDirectoryExport();
                FastImportCleanup();
                PreviousTerminalWait();
                Mt5BufferedConfirmation();
                BackgroundImportChecks();
                PortableServerChecks();
                DashboardMasterChecks();
                ReportRunChecks();
            }
            catch (Exception e)
            {
                failures++;
                Console.WriteLine("CRASH: " + e);
            }
            finally
            {
                try { Directory.Delete(root, true); } catch { }
            }
            Console.WriteLine(passed + " passed, " + failures + " failed");
            return failures;
        }

        sealed class FakeStudentImport : IStudentImportRuntime
        {
            public int Saves, Connections;
            public string FailLogin;
            public bool ThrowSave;
            public Action OnSave;
            public string Save(StudentImportRow row)
            {
                Saves++;
                if (ThrowSave) throw new IOException("cannot save " + row.Investor);
                if (OnSave != null) OnSave();
                return row.Kind + "-" + Saves;
            }
            public ImportConnection Connect(StudentImportRow row, Func<bool> cancel)
            {
                Connections++;
                return new ImportConnection { Connected = row.Login != FailLogin, State = row.Login == FailLogin ? Login.NoConnection : Login.Connected, Reason = row.Login == FailLogin ? "connection failed" : "confirmed" };
            }
        }

        static SheetRow ImportSheetRow(int number, params string[] values)
        {
            var r = new SheetRow { Number = number };
            for (int c = 0; c < values.Length; c++) r.Cells[c] = values[c];
            return r;
        }

        static void BulkStudentImport()
        {
            string path = Path.Combine(Dir("bulk-import"), "students.xlsx");
            StudentImport.Template(path);
            Check(Spreadsheet.Read(path)[0].Cells[0] == "Name", "real XLSX template opens with expected headers");
            var input = new List<SheetRow> {
                ImportSheetRow(1, StudentImport.Headers),
                ImportSheetRow(2, "علی", "MT5", "۰۰۱۲۳۴", "Broker-Demo", "readOnly#1", "Group"),
                ImportSheetRow(5, "duplicate", "5", "1234", "broker-demo", "different#1", ""),
                ImportSheetRow(6, "existing", "MT4", "888", "Broker-Demo", "readOnly#1", ""),
                ImportSheetRow(7, "", "MT5", "7E+19", "", "", ""),
                ImportSheetRow(8, "new", "MT4", "1234", "Broker-Demo", "readOnly#1", ""),
                ImportSheetRow(9, "bad password", "MT5", "999", "Broker-Demo", "has\nnewline", "")
            };
            var plan = StudentImport.Plan(input, new[] { StudentImport.Key(Kind.MT4, "888", "Broker-Demo") });
            Check(plan.Count == 6 && plan[0].State == ImportState.Ready && plan[0].Login == "001234", "Persian account digits normalized without dropping leading zeroes");
            Check(plan[1].State == ImportState.Duplicate && plan[2].State == ImportState.Duplicate, "duplicates in file and existing store are skipped, no overwrite");
            Check(plan[3].State == ImportState.Invalid && plan[3].Line == 7 && plan[3].Reason.Contains("؛"), "all missing data stays on its original Excel row with reasons");
            Check(plan[4].State == ImportState.Ready, "same number on different platform is a different account");
            Check(plan[5].State == ImportState.Invalid, "password line-break injection rejected");
            var fake = new FakeStudentImport { FailLogin = "1234" };
            StudentImport.Run(plan, fake, () => false, r => { });
            Check(fake.Saves == 2 && fake.Connections == 2, "only valid unique accounts are created and checked");
            Check(plan[0].State == ImportState.Connected && plan[4].State == ImportState.Failed && plan[4].Saved, "connected and failed login distinguishable; failed account remains saved");
            plan[4].State = ImportState.Ready; fake.FailLogin = null;
            StudentImport.Run(plan, fake, () => false, r => { });
            Check(fake.Saves == 2 && fake.Connections == 3 && plan[4].State == ImportState.Connected, "retry checks saved copy without adding another student");
            StudentImport.Export(path, plan);
            string text = string.Join("|", Spreadsheet.Read(path).SelectMany(r => r.Cells.Values));
            Check(text.Contains("001234") && !text.Contains("readOnly#1") && !text.Contains("different#1"), "result workbook preserves accounts and never includes passwords");
            var errors = StudentImport.Plan(new[] { input[0], ImportSheetRow(2, "save error", "MT5", "221", "Demo", "readOnly#1", "") }, new string[0]);
            StudentImport.Run(errors, new FakeStudentImport { ThrowSave = true }, () => false, r => { });
            Check(errors[0].State == ImportState.Failed && !errors[0].Saved && !errors[0].Reason.Contains("readOnly#1"), "save failure is per-row, not marked saved, and password redacted");
            var cancelled = StudentImport.Plan(new[] { input[0], ImportSheetRow(2, "one", "MT5", "1", "Demo", "readOnly#1", ""), ImportSheetRow(3, "two", "MT5", "2", "Demo", "readOnly#1", "") }, new string[0]);
            bool stop = false;
            var stopping = new FakeStudentImport { OnSave = () => stop = true };
            StudentImport.Run(cancelled, stopping, () => stop, r => { });
            Check(stopping.Saves == 1 && stopping.Connections == 0 && cancelled.All(r => r.State == ImportState.Cancelled), "stop after save prevents connection and subsequent creation");
            Check(cancelled[0].Saved && !cancelled[1].Saved, "cancelled rows distinguish saved from not attempted");
            var numeric = ImportSheetRow(2, "number", "MT5", "12345678901234560", "Demo", "readOnly#1", "");
            numeric.Numeric.Add(2);
            Check(StudentImport.Plan(new[] { input[0], numeric }, null)[0].State == ImportState.Invalid, "Excel-rounded long numeric account must be re-entered as text");
            numeric.Numeric.Clear();
            Check(StudentImport.Plan(new[] { input[0], numeric }, null)[0].State == ImportState.Ready, "long text account remains supported");
            Throws<UserMessage>(() => StudentImport.Plan(new[] { ImportSheetRow(1, "Name", "Login"), input[1] }, null), "missing required headers rejected");
            Throws<UserMessage>(() => StudentImport.Plan(new[] { ImportSheetRow(1, "Name", "Name", "Login", "Server", "Investor", "Platform"), input[1] }, null), "duplicate header rejected");
            Check(StudentImportRuntime.Describe(new LoginResult { State = Login.Connected }).Connected, "journal confirmation means connected");
            Check(!StudentImportRuntime.Describe(new LoginResult { State = Login.Waiting }).Connected, "running process or timeout never means connected");
            string ambiguous = StudentImportRuntime.Describe(new LoginResult { State = Login.WrongLogin, Detail = "authorization failed" }).Reason;
            Check(ambiguous.Contains("یا") || ambiguous.Contains("or"), "ambiguous authorization does not invent a password-only diagnosis");
            Check(!StudentImportRuntime.Describe(new LoginResult { State = Login.NoConnection }).Connected && !StudentImportRuntime.Describe(new LoginResult { State = Login.NoServer }).Connected, "network/server failures stay distinct from success");
            string fx = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "test", "fx");
            List<StudentImportRow> hundred = StudentImport.Read(Path.Combine(fx, "bulk-shared.xlsx"), null);
            Check(hundred.Count == 100 && hundred.All(r => r.State == ImportState.Ready), "100 students from independent Excel writer, shared strings and reordered columns");
            var hundredRuntime = new FakeStudentImport();
            StudentImport.Run(hundred, hundredRuntime, () => false, r => { });
            Check(hundredRuntime.Saves == 100 && hundredRuntime.Connections == 100 && hundred.All(r => r.State == ImportState.Connected), "100-row workflow executes every selected student");
            Check(StudentImport.Read(Path.Combine(fx, "bulk-formula.xlsx"), null).Any(r => r.State == ImportState.Invalid), "formula row is rejected without aborting the workbook");
            Throws<InvalidDataException>(() => Spreadsheet.Read(Path.Combine(fx, "bulk-formula.xlsx")), "strict workbook reader still rejects formulas");
            Spreadsheet.Write(path, new List<string[]> { StudentImport.Headers, new[] { "=HYPERLINK(\"https://example.invalid\")", "MT5", "002", "Demo", "readOnly#1", "" } });
            Check(StudentImport.Read(path, null)[0].Name.StartsWith("=HYPERLINK"), "exported strings are literal text, never executed Excel formulas");
            StudentImport.Template(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MetaFactory-students.xlsx"));
        }

        static void BulkImportCancellation()
        {
            string source = Dir("bulk-cancel-source"), target = Dir("bulk-cancel-target");
            string large = Path.Combine(source, "data.bin");
            File.WriteAllBytes(large, new byte[2 * 1024 * 1024]);
            int checks = 0;
            Throws<OperationCanceledException>(() => CopyMaker.CopyDir(source, target, false, () => ++checks > 5), "bulk copy can stop inside a file rather than waiting for the complete file");
            string partial = Path.Combine(target, "data.bin");
            Check(File.Exists(partial) && new FileInfo(partial).Length < new FileInfo(large).Length, "cancelled copy did not copy the entire large file");
            File.Delete(partial);
            Check(!File.Exists(partial), "cancelled copy closes the output handle");
            checks = 0;
            Throws<OperationCanceledException>(() => CopyMaker.FolderSize(source, false, () => ++checks > 1), "folder scan does not swallow cancellation");
            Throws<TimeoutException>(() => CopyMaker.FolderSize(source, false, () => { if (++checks > 0) throw new TimeoutException(); return false; }), "folder scan preserves preparation timeout");
            var release = new System.Threading.ManualResetEvent(false);
            try
            {
                Throws<TimeoutException>(() => StudentImportRuntime.FindWithDeadline(() => { release.WaitOne(); return "read-only discovery"; }, () => false, 40), "blocked read-only source discovery has a bounded wait");
                Throws<OperationCanceledException>(() => StudentImportRuntime.FindWithDeadline(() => { release.WaitOne(); return "read-only discovery"; }, () => true, 500), "source discovery can be cancelled");
            }
            finally { release.Set(); }
            Equal("source", StudentImportRuntime.FindWithDeadline(() => "source", () => false, 2000), "source discovery returns an available source");
            var row = new StudentImportRow { Name = "test", Login = "42", Investor = "test-only", Platform = "MT5", State = ImportState.Ready };
            var cancelled = new CancellingImportRuntime();
            StudentImport.Run(new[] { row }, cancelled, () => true, r => { });
            Check(row.State == ImportState.Cancelled && cancelled.Saves == 0, "stopped queue creates no accounts");
            row.State = ImportState.Ready;
            StudentImport.Run(new[] { row }, cancelled, () => false, r => { });
            Check(row.State == ImportState.Cancelled && !row.Saved, "cancellation during preparation is not mislabeled as login failure");
        }

        sealed class CancellingImportRuntime : IStudentImportRuntime
        {
            public int Saves;
            public string Save(StudentImportRow r) { Saves++; throw new OperationCanceledException(); }
            public ImportConnection Connect(StudentImportRow r, Func<bool> cancel) { throw new Exception("not reached"); }
        }

        static void LoginConfirmationRegression()
        {
            const string me = "51234567";
            Equal(Login.Connected, ConnectionCheck.FromJournal(new[] { "0\t10:00:01.000\t'51234567': login on WMMarkets-DEMO through Access Point" }, me).State, "MT4 direct login on format confirms login");
            Equal(Login.Waiting, ConnectionCheck.FromJournal(new[] { "0\t10:00:01.000\t'151234567': login datacenter on Other-Demo" }, me).State, "another account containing the expected digits must never confirm login");
            Equal(Login.Waiting, ConnectionCheck.FromJournal(new[] { "0\t10:00:01.000\t'9999': authorization on server failed (Invalid password)" }, me).State, "another account's failure with the word server cannot affect this account");
            Equal(Login.WrongLogin, ConnectionCheck.FromJournal(new[] { "0\t10:00:01.000\t'51234567': login on WMMarkets-DEMO failed (Invalid password)" }, me).State, "failed login on must not be accepted as success");
            Equal(Login.Waiting, ConnectionCheck.FromJournal(new[] { "0\t10:00:01.000\tNetwork connected to access server" }, me).State, "transport connection without account authorization is not proof");
            Equal(Login.Connected, ConnectionCheck.FromJournal(new[] { "'51234567': authorized on Server" }, "00051234567").State, "Excel text leading zeroes do not hide the actual account confirmation");
            var now = DateTime.Now;
            var copy = new Instance { Name = "MT4-session", Kind = Kind.MT4, Dir = Dir("login-session") };
            Directory.CreateDirectory(Path.Combine(copy.Dir, "logs"));
            string path = ConnectionCheck.JournalFile(copy, now);
            string old = "0\t" + now.ToString("HH:mm:ss") + "\t'51234567': login on WMMarkets-DEMO\r\n";
            File.WriteAllText(path, old, Encoding.ASCII);
            var watch = new LoginWatch(); watch.BeginSession(copy, me, now);
            Equal(Login.Waiting, watch.Update(copy, me, now, now).State, "baseline excludes an old confirmation even with exactly the same timestamp");
            // MetaTrader's journal clock may differ from the Windows clock; new byte position, not wall time, scopes this run.
            File.AppendAllText(path, "0\t00:00:01.000\t'51234567': login on WMMarkets-DEMO\r\n", Encoding.ASCII);
            Equal(Login.Connected, watch.Update(copy, me, now, now).State, "fresh session bytes confirm login despite a different journal clock");
            File.WriteAllText(path, "", Encoding.ASCII);
            watch = new LoginWatch(); watch.BeginSession(copy, me, now);
            Equal(Login.Waiting, watch.Update(copy, me, now, now).State, "connected UI with no written confirmation stays unknown");
            bool closed = false;
            ImportConnection flushed = StudentImportRuntime.ReadAfterClose(watch, copy, me, now, () => {
                closed = true;
                // Reproduce MT4 buffering: the line appears only when this process closes, without a final newline.
                File.AppendAllText(path, "0\t00:00:02.000\t'51234567': login on WMMarkets-DEMO", Encoding.ASCII);
            }, () => closed);
            Check(flushed.Connected && closed, "result is decided after close flushes the journal, including an EOF-terminated line");
            File.WriteAllText(path, "", Encoding.ASCII);
            watch = new LoginWatch(); watch.BeginSession(copy, me, now);
            File.AppendAllText(path, "0\t00:00:03.000\t'51234567': login on WMMarkets-DEMO", Encoding.ASCII);
            Equal(Login.Waiting, watch.Update(copy, me, now, now).State, "unterminated line from a still-running writer is not prematurely accepted");
            var notClosed = StudentImportRuntime.ReadAfterClose(watch, copy, me, now, () => { }, () => false);
            Check(!notClosed.Connected, "EOF cannot complete a message unless the producing process is known to have exited");
            Equal(ImportState.Unconfirmed, StudentImport.Outcome(StudentImportRuntime.Describe(new LoginResult { State = Login.Waiting }), false), "missing confirmation is not a failed login");
            Equal(ImportState.Failed, StudentImport.Outcome(StudentImportRuntime.Describe(new LoginResult { State = Login.WrongLogin }), false), "explicit authentication rejection remains failed");
            Equal(ImportState.Connected, StudentImport.Outcome(flushed, false), "confirmed post-close outcome is connected");
            Equal(ImportState.Cancelled, StudentImport.Outcome(flushed, true), "user stop remains distinct from failure");
            File.WriteAllText(path, "", Encoding.ASCII);
            watch = new LoginWatch(); watch.BeginSession(copy, me, now);
            byte[] u16 = Encoding.Unicode.GetPreamble().Concat(Encoding.Unicode.GetBytes("0\t00:00:04.000\t'51234567': login on WMMarkets-DEMO\r")).ToArray();
            File.WriteAllBytes(path, u16.Take(1).ToArray());
            Equal(Login.Waiting, watch.Update(copy, me, now, now).State, "partial UTF16 BOM waits for enough bytes");
            using (var file = new FileStream(path, FileMode.Append)) file.Write(u16, 1, u16.Length - 1);
            Equal(Login.Connected, watch.Update(copy, me, now, now).State, "UTF16 message with a CR-only terminator is read after a partial BOM");
            File.WriteAllText(path, "", Encoding.ASCII);
            watch = new LoginWatch(); watch.BeginSession(copy, me, now);
            var shutdown = StudentImportRuntime.ReadAfterClose(watch, copy, me, now, () => {
                File.AppendAllText(path, "0\t00:00:05.000\t'51234567': login on WMMarkets-DEMO\r\n0\t00:00:06.000\t'51234567': connection to WMMarkets-DEMO lost\r\n", Encoding.ASCII);
            }, () => true);
            Check(shutdown.Connected, "intentional shutdown disconnect does not erase a login that was confirmed during the checked run");
            Equal(Login.NoConnection, watch.Result.State, "live transport state still reflects the disconnect");
            Equal(Login.Connected, watch.AttemptResult.State, "initial authentication can be published immediately without waiting for history or teardown");
            File.WriteAllText(path, "", Encoding.ASCII);
            watch = new LoginWatch(); watch.BeginSession(copy, me, now);
            var rejected = StudentImportRuntime.ReadAfterClose(watch, copy, me, now, () => {
                File.AppendAllText(path, "0\t00:00:05.000\t'51234567': login on WMMarkets-DEMO\r\n0\t00:00:06.000\t'51234567': authorization on WMMarkets-DEMO failed (Invalid password)\r\n0\t00:00:07.000\t'51234567': connection to WMMarkets-DEMO lost\r\n", Encoding.ASCII);
            }, () => true);
            Check(!rejected.Connected && rejected.State == Login.WrongLogin, "an explicit later rejection remains failure even when disconnect is the final shutdown line");
            Equal(Login.WrongLogin, watch.AttemptResult.State, "later explicit rejection overrides the first confirmation in the fast path");
            watch.BeginSession(copy, me, now.AddSeconds(1));
            Equal(Login.Waiting, watch.AttemptResult.State, "retry cannot reuse an earlier session's initial authentication");
        }

        static void StudentDirectoryExport()
        {
            var accounts = new AccountStore();
            accounts.Set(new Account { Instance = "MT4-01", Trader = "=Literal name", Login = "00123456789012345678", Server = "Demo", Mode = "investor", InvestorEnc = Secret.Protect("sample-investor#1"), MasterEnc = Secret.Protect("sample-master#2") });
            accounts.Set(new Account { Instance = "MT5-missing", Trader = "Missing copy", Login = "0002", Server = "Other-Demo", InvestorEnc = "invalid ciphertext" });
            var copies = new[] { new Instance { Name = "MT4-01", Kind = Kind.MT4, Dir = "D:/Sample/MT4-01" }, new Instance { Name = "MT5-empty", Kind = Kind.MT5, Dir = "D:/Sample/MT5-empty" } };
            var folders = new FolderStore(); var first = folders.Create("First"); var second = folders.Create("Second");
            folders.Add(first.Id, new[] { "MT4-01" }); folders.Add(second.Id, new[] { "MT4-01" });
            var rows = StudentExport.Rows(copies, accounts, folders, true);
            Equal(4, rows.Count, "directory export includes accounts without copies and copies without accounts exactly once");
            var account = rows.Single(r => r[6] == "MT4-01");
            Equal("00123456789012345678", account[2], "export preserves account zeroes and all digits");
            Check(account[4] == "sample-investor#1" && account[9] == "sample-master#2", "explicit password export includes both saved account fields");
            Check(account[5] == "First" && account[10] == "First | Second", "export keeps all folder memberships and one import-compatible default");
            var missing = rows.Single(r => r[6] == "MT5-missing");
            Check(missing[4] == "" && missing[11] == "No" && missing[12].Contains("could not"), "unreadable secret and missing copy are explicit without exporting ciphertext");
            var without = StudentExport.Rows(copies, accounts, folders, false);
            Check(without.Skip(1).All(r => r[4] == "" && r[9] == "" && r[12] == "Excluded"), "password opt-out excludes every secret");
            string path = Path.Combine(Dir("directory-export"), "students.xlsx");
            StudentExport.Write(path, rows, true);
            var read = Spreadsheet.Read(path);
            Equal("=Literal name", read[1].Cells[0], "directory export writes formula-like names as literal text");
            Equal("00123456789012345678", read[1].Cells[2], "real XLSX keeps long account IDs as text");
            Equal(ImportState.Ready, StudentImport.Read(path, null)[0].State, "student export can be used by bulk import");
            StudentExport.Write(path, without, false);
            string text = string.Join("|", Spreadsheet.Read(path).SelectMany(r => r.Cells.Values));
            Check(!text.Contains("sample-investor#1") && !text.Contains("sample-master#2"), "overwriting workbook without passwords leaves no old secret data");
            Equal("00123456789012345678", accounts.Get("MT4-01").Login, "export never changes stored accounts");
        }

        static void FastImportCleanup()
        {
            Check(StudentImportRuntime.ShouldFlushEarly(Kind.MT4, 12, 3, Login.Waiting), "buffered MT4 may be checked early after its window is ready");
            Check(!StudentImportRuntime.ShouldFlushEarly(Kind.MT4, 11, 3, Login.Waiting), "do not interrupt the initial startup grace period");
            Check(!StudentImportRuntime.ShouldFlushEarly(Kind.MT4, 20, 2, Login.Waiting), "a newly visible or missing window does not trigger early close");
            Check(StudentImportRuntime.ShouldFlushEarly(Kind.MT5, 8, 3, Login.Waiting), "MT5 now checks its buffered authentication after the shorter startup grace");
            Check(!StudentImportRuntime.ShouldFlushEarly(Kind.MT5, 7, 3, Login.Waiting), "MT5 still gets its initial startup grace period");
            Check(!StudentImportRuntime.ShouldFlushEarly(Kind.MT5, 8, 2, Login.Waiting), "MT5 window alone cannot trigger an immediate recheck");
            Check(StudentImportRuntime.ShouldFlushEarly(Kind.MT5, 8, 3, Login.NoConnection), "MT5 can flush buffered authentication after an earlier transport warning");
            Check(!StudentImportRuntime.ShouldFlushEarly(Kind.MT5, 8, 3, Login.WrongLogin), "explicit MT5 password rejection is not delayed by an early recheck");
            Check(!StudentImportRuntime.ShouldFlushEarly(Kind.MT5, 8, 3, Login.Connected), "MT5 confirmed in the journal proceeds immediately");
            Check(StudentImportRuntime.ShouldFlushEarly(Kind.MT4, 20, 3, Login.NoConnection), "buffered authentication after a transport warning can also be checked early");
            Check(!StudentImportRuntime.ShouldFlushEarly(Kind.MT4, 20, 3, Login.Connected), "confirmed authentication returns immediately without an early recheck");
            using (var entered = new System.Threading.ManualResetEvent(false))
            using (var release = new System.Threading.ManualResetEvent(false))
            using (var cleanup = new ImportCleanup())
            {
                cleanup.Start(() => { entered.Set(); release.WaitOne(3000); return true; });
                try
                {
                    Check(entered.WaitOne(2000) && cleanup.Pending, "terminal teardown runs in the background without blocking result publication or next-row preparation");
                    Throws<InvalidOperationException>(() => cleanup.Start(() => true), "a second outstanding teardown cannot accumulate");
                }
                finally { release.Set(); }
                Check(cleanup.Drain() && !cleanup.Pending, "next terminal launch joins the previous teardown");
                cleanup.Start(() => false);
                Check(!cleanup.Drain(), "failed teardown blocks launching another terminal");
                cleanup.Start(() => { throw new IOException("synthetic cleanup failure"); });
                Check(!cleanup.Drain(), "teardown exceptions are observed and become a failed cleanup result");
                Check(cleanup.Drain(), "draining completed cleanup again is harmless");
            }
        }

        sealed class DelayedPreviousTerminal : IStudentImportRuntime
        {
            public readonly System.Threading.ManualResetEvent Released = new System.Threading.ManualResetEvent(false);
            public readonly System.Threading.ManualResetEvent Waiting = new System.Threading.ManualResetEvent(false);
            public int Saves, Connections;
            public string Save(StudentImportRow row) { return "MT5-wait-" + ++Saves; }
            public ImportConnection Connect(StudentImportRow row, Func<bool> cancel)
            {
                if (++Connections == 2)
                    StudentImportRuntime.WaitForRelease(() => !Released.WaitOne(0), cancel, () => Waiting.Set());
                return new ImportConnection { Connected = true, State = Login.Connected, Reason = "confirmed" };
            }
        }

        static List<StudentImportRow> WaitingRows()
        {
            return Enumerable.Range(1, 3).Select(n => new StudentImportRow { Line = n + 1, Name = "Student " + n, Login = n.ToString(), Server = "Demo", Kind = Kind.MT5, Platform = "MT5", State = ImportState.Ready }).ToList();
        }

        static void PreviousTerminalWait()
        {
            var runtime = new DelayedPreviousTerminal(); var rows = WaitingRows();
            var task = System.Threading.Tasks.Task.Factory.StartNew(() => StudentImport.Run(rows, runtime, () => false, r => { }));
            try
            {
                Check(runtime.Waiting.WaitOne(3000), "slow previous terminal produces a waiting state");
                Check(!task.IsCompleted && rows[0].State == ImportState.Connected && rows[1].State == ImportState.Checking && rows[2].State == ImportState.Ready,
                    "delayed shutdown never fails the waiting student or cascades failures into later rows");
                Equal(2, runtime.Saves, "next row may be prepared but later rows stay queued until the previous terminal closes");
            }
            finally { runtime.Released.Set(); }
            Check(task.Wait(3000) && rows.All(r => r.State == ImportState.Connected), "late previous shutdown automatically resumes and finishes all students without Retry");
            Check(runtime.Saves == 3 && runtime.Connections == 3, "automatic resume never recreates students or retries successful connections");
            runtime.Released.Dispose(); runtime.Waiting.Dispose();

            runtime = new DelayedPreviousTerminal(); rows = WaitingRows();
            using (var stop = new System.Threading.ManualResetEvent(false))
            {
                var cancelRuntime = runtime; var cancelRows = rows;
                task = System.Threading.Tasks.Task.Factory.StartNew(() => StudentImport.Run(cancelRows, cancelRuntime, () => stop.WaitOne(0), r => { }));
                try { Check(runtime.Waiting.WaitOne(3000), "indefinite shutdown wait remains cancellable"); }
                finally { stop.Set(); }
                Check(task.Wait(3000) && rows[0].State == ImportState.Connected && rows[1].State == ImportState.Cancelled && rows[2].State == ImportState.Cancelled,
                    "Stop preserves the confirmed student and cancels waiting/queued rows without false failures");
                Equal(2, runtime.Saves, "Stop while waiting prevents creation of later rows");
            }
            runtime.Released.Dispose(); runtime.Waiting.Dispose();
            int probes = 0;
            StudentImportRuntime.WaitForRelease(() => { probes++; return false; }, () => false, () => { throw new Exception("unexpected waiting"); });
            Equal(1, probes, "a terminal that closed just after an unsuccessful close attempt resumes immediately");
        }

        static void Mt5BufferedConfirmation()
        {
            DateTime now = DateTime.Now; string login = "9912345";
            var copy = new Instance { Name = "MT5-buffered", Kind = Kind.MT5, Dir = Dir("mt5-buffered") };
            Directory.CreateDirectory(Path.Combine(copy.Dir, "logs"));
            string file = ConnectionCheck.JournalFile(copy, now);
            string old = "0\t00:00:01.000\tNetwork\t'9912345': authorized on Broker-Demo\r\n";
            File.WriteAllText(file, old, Encoding.Unicode);
            var watch = new LoginWatch(); watch.BeginSession(copy, login, now);
            Equal(Login.Waiting, watch.Update(copy, login, now, now).State, "MT5 early check never accepts a previous run's authorization");
            bool exited = false;
            var connected = StudentImportRuntime.ReadAfterClose(watch, copy, login, now, () => {
                File.AppendAllText(file, "0\t00:00:08.000\tNetwork\t'9912345': authorized on Broker-Demo through Access Point", Encoding.Unicode);
                exited = true;
            }, () => exited);
            Check(connected.Connected, "MT5 UTF16 authorization flushed on close confirms without waiting for the journal's delayed write");
            watch.BeginSession(copy, login, now.AddSeconds(1));
            Equal(Login.Waiting, watch.AttemptResult.State, "inconclusive MT5 retry starts without any stale authentication");
            var rejected = StudentImportRuntime.ReadAfterClose(watch, copy, login, now.AddSeconds(1), () => {
                File.AppendAllText(file, "\r\n0\t00:00:09.000\tNetwork\t'9912345': authorization on Broker-Demo failed (Invalid password)\r\n", Encoding.Unicode);
            }, () => true);
            Check(!rejected.Connected && rejected.State == Login.WrongLogin, "MT5 early flush preserves actual password rejection");
            watch.BeginSession(copy, login, now.AddSeconds(2));
            var unknown = StudentImportRuntime.ReadAfterClose(watch, copy, login, now.AddSeconds(2), () => {
                File.AppendAllText(file, "0\t00:00:10.000\tNetwork\t'8812345': authorized on Broker-Demo\r\n", Encoding.Unicode);
            }, () => true);
            Equal(ImportState.Unconfirmed, StudentImport.Outcome(unknown, false), "another MT5 account's authorization leaves the initial check inconclusive, never successful or a password failure");
        }

        static void Digits()
        {
            Equal("12345", TextUtil.LatinDigits("۱۲۳۴۵"), "Persian digits");
            Equal("67", TextUtil.LatinDigits("٦٧"), "Arabic digits");
            Equal("a b c", TextUtil.OneLine("a\tb\r\nc"), "one line");
        }

        static void SettingsRoundTrip()
        {
            var s = new Settings { BaseDir = Dir("copies"), DelaySeconds = 12, Minimized = false, Light = true, AutoStart = true };
            s.Save();
            Settings r = Settings.Load();
            Equal(s.BaseDir, r.BaseDir, "settings folder");
            Equal(12, r.DelaySeconds, "settings delay");
            Equal(false, r.Minimized, "settings minimized");
            Equal(true, r.AutoStart, "settings autostart");
            Equal(ChartModes.Empty, new Settings().StartCharts, "investor copies start without charts by default (3.17)");
            foreach (string mode in new[] { ChartModes.One, ChartModes.All, ChartModes.Empty })
            {
                new Settings { BaseDir = Dir("copies"), StartCharts = mode }.Save();
                Equal(mode, Settings.Load().StartCharts, "chart setting kept: " + mode);
            }
            File.WriteAllText(AppPaths.SettingsFile, "BaseDir=" + Dir("copies") + "\r\nLightCharts=0\r\n");
            Equal(ChartModes.All, Settings.Load().StartCharts, "«one chart» off in an earlier version: all charts as before");
            File.WriteAllText(AppPaths.SettingsFile, "StartCharts=bogus\r\n");
            Equal(ChartModes.Empty, Settings.Load().StartCharts, "an unknown value: the default");
            // 3.27 (CHANGE-019): the language is kept; the words and digits follow it; anything else is Persian.
            Equal("fa", new Settings().Language, "Persian by default");
            new Settings { BaseDir = Dir("copies"), Language = "en" }.Save();
            Equal("en", Settings.Load().Language, "English kept");
            File.WriteAllText(AppPaths.SettingsFile, "Language=de\r\n");
            Equal("fa", Settings.Load().Language, "an unknown language: Persian");
            Equal("فهرست", Lang.T("فهرست", "List"), "Persian words by default");
            Equal("۱۲", Fa.N(12), "Persian digits by default");
            Lang.En = true;
            try
            {
                Equal("List", Lang.T("فهرست", "List"), "English words");
                Equal("12", Fa.N(12), "Latin digits in English");
                Equal("2026.11.13", Fa.Date(new DateTime(2026, 11, 13)), "Gregorian date in English");
                Equal(TextFormatFlags.Left, Theme.Start, "English starts at the left");
                Equal(new Rectangle(70, 0, 20, 10), Theme.Flip(new Rectangle(10, 0, 20, 10), 0, 100), "mirrored in English");
            }
            finally { Lang.En = false; }
            Equal(new Rectangle(10, 0, 20, 10), Theme.Flip(new Rectangle(10, 0, 20, 10), 0, 100), "the same in Persian");
            // 3.26 (CHANGE-005): the list's look is kept; anything else is the usual look.
            Equal("normal", new Settings().Density, "the usual list look by default");
            new Settings { BaseDir = Dir("copies"), Density = "compact" }.Save();
            Equal("compact", Settings.Load().Density, "compact look kept");
            File.WriteAllText(AppPaths.SettingsFile, "Density=huge\r\n");
            Equal("normal", Settings.Load().Density, "an unknown look: the usual one");
            // 3.26 (CHANGE-003): only the words shown in «امروز» are shorter; the whole message stays for the tip.
            Equal("ورود نشد: رمز یا حساب اشتباه", MainForm.ShortError("ورود نشد: رمز اینوستور یا شماره حساب اشتباه"), "short login error");
            Equal("خوانده نشد: پوشه پیدا نشد", MainForm.ShortError("پوشه پیدا نشد"), "other errors as before");
            s.Save();
        }

        static void Secrets()
        {
            string enc = Secret.Protect("P@ss word!");
            Check(enc.Length > 0 && !enc.Contains("P@ss"), "password is not stored as plain text");
            Equal("P@ss word!", Secret.Unprotect(enc), "password round trip");
            Equal("", Secret.Unprotect(""), "empty password");
            Equal(null, Secret.Unprotect("bm90IGVuY3J5cHRlZA=="), "foreign data reads as null");
        }

        static void AccountsRoundTrip()
        {
            var store = new AccountStore();
            store.Set(new Account { Instance = "MT5-01", Trader = "علی\tرضایی", Login = "1234567", Server = "Broker-Live", Mode = "investor", MasterEnc = Secret.Protect("m1"), InvestorEnc = Secret.Protect("i1") });
            store.Save();
            Check(!File.ReadAllText(AppPaths.AccountsFile).Contains("m1\t"), "accounts file holds no plain password");
            AccountStore r = AccountStore.Load();
            Account a = r.Get("mt5-01");
            Check(a != null, "account found case-insensitively");
            Equal("علی رضایی", a.Trader, "trader name kept, tab removed");
            Equal(true, a.IsInvestor, "mode kept");
            Equal("i1", a.PasswordForLogin(), "investor password used for investor mode");
            Equal(true, a.Readable, "passwords readable");
        }

        static void CopiesAndInstalls()
        {
            // A fake MT5 install, and its AppData folder as Windows would have it.
            string install = Dir("Program Files", "Broker MetaTrader 5");
            Touch(Path.Combine(install, "terminal64.exe"));
            Touch(Path.Combine(install, "config", "servers.dat"));
            Touch(Path.Combine(install, "logs", "20261030.log"));
            Touch(Path.Combine(install, "MQL5", "Experts", "Advisors", "ea.ex5"));
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string data = Path.Combine(appData, "MetaQuotes", "Terminal", "ABC123");
            Directory.CreateDirectory(data);
            File.WriteAllText(Path.Combine(data, "origin.txt"), install, Encoding.Unicode);
            Touch(Path.Combine(data, "MQL5", "Indicators", "mine.ex5"));
            Touch(Path.Combine(data, "MQL5", "Logs", "x.log"));
            Touch(Path.Combine(data, "templates", "light.tpl"));

            string mt4 = Dir("Program Files", "Broker MetaTrader 4");
            Touch(Path.Combine(mt4, "terminal.exe"));
            string mt4Data = Path.Combine(appData, "MetaQuotes", "Terminal", "DEF456");
            Directory.CreateDirectory(mt4Data);
            File.WriteAllText(Path.Combine(mt4Data, "origin.txt"), mt4, Encoding.Unicode);

            var s = new Settings { BaseDir = Dir("copies") };
            List<string> mt5Found = Installs.Find(Kind.MT5, s.BaseDir);
            Check(mt5Found.Any(f => f == install), "MT5 install found through its AppData folder");
            Check(!Installs.Find(Kind.MT4, s.BaseDir).Contains(install), "an MT5 is not listed as MT4");
            Check(Installs.Find(Kind.MT4, s.BaseDir).Contains(mt4), "MT4 install found");
            Equal(data, Installs.FindDataFolder(install), "data folder of the install");

            var progressed = new List<string>();
            List<string> made = CopyMaker.Create(new CreateRequest { Kind = Kind.MT5, Source = install, Count = 3, Prefix = "MT5", CopyData = true }, s, (n, t, name) => progressed.Add(name));
            Equal("MT5-01,MT5-02,MT5-03", string.Join(",", made), "copy names");
            Equal(3, progressed.Count, "progress reported for each copy");
            string c1 = Path.Combine(s.BaseDir, "MT5-01");
            Check(File.Exists(Path.Combine(c1, "terminal64.exe")), "terminal copied");
            Check(File.Exists(Path.Combine(c1, "config", "servers.dat")), "broker servers copied");
            Check(!Directory.Exists(Path.Combine(c1, "logs")), "logs not copied");
            Check(File.Exists(Path.Combine(c1, "MQL5", "Experts", "Advisors", "ea.ex5")), "install's own experts copied");
            Check(File.Exists(Path.Combine(c1, "MQL5", "Indicators", "mine.ex5")), "user's indicators copied from AppData");
            Check(!Directory.Exists(Path.Combine(c1, "MQL5", "Logs")), "AppData logs not copied");
            Check(File.Exists(Path.Combine(c1, "templates", "light.tpl")), "templates copied");

            List<string> more = CopyMaker.Create(new CreateRequest { Kind = Kind.MT5, Source = install, Count = 2, Prefix = "MT5", CopyData = false }, s, null);
            Equal("MT5-04,MT5-05", string.Join(",", more), "numbering continues");
            Check(!File.Exists(Path.Combine(s.BaseDir, "MT5-04", "MQL5", "Indicators", "mine.ex5")), "data copy is optional");
            Equal("Trader_A", CopyMaker.CleanPrefix(" Trader A ", Kind.MT4), "prefix cleaned");
            Equal("MT4", CopyMaker.CleanPrefix(" ", Kind.MT4), "empty prefix becomes the kind");

            List<Instance> copies = Installs.Copies(s.BaseDir);
            Equal(5, copies.Count, "copies listed");
            Check(copies.All(c => c.Kind == Kind.MT5), "copies are MT5");
            Check(Installs.Find(Kind.MT5, s.BaseDir).All(f => !f.StartsWith(s.BaseDir)), "copies are not offered as installs");

            Throws<UserMessage>(() => CopyMaker.Check(new CreateRequest { Kind = Kind.MT4, Source = install, Count = 1 }, s), "MT4 from an MT5 folder is refused");
            Throws<UserMessage>(() => CopyMaker.Check(new CreateRequest { Kind = Kind.MT5, Source = install, Count = 0 }, s), "zero copies refused");
            var pf = new Settings { BaseDir = Dir("Program Files", "copies") };
            Throws<UserMessage>(() => CopyMaker.Check(new CreateRequest { Kind = Kind.MT5, Source = install, Count = 1 }, pf), "copies inside Program Files refused");
        }

        static void LeanAndCleanup()
        {
            Check(Lean.IsExtraFile("MetaEditor64.exe") && Lean.IsExtraFile("metaeditor.exe"), "editor is extra");
            Check(Lean.IsExtraFile("metatester64.exe") && Lean.IsExtraFile("uninstall.exe"), "tester and uninstaller are extra");
            Check(Lean.IsExtraFile("MetaEditor64.part1.rar") && Lean.IsExtraFile("x.ZIP") && Lean.IsExtraFile("a.7z"), "archives are extra");
            Check(!Lean.IsExtraFile("terminal64.exe") && !Lean.IsExtraFile("terminal.exe") && !Lean.IsExtraFile("Terminal.ico"), "terminal is kept");
            Check(Lean.IsExtraDir("Tester") && Lean.IsExtraDir("tester") && !Lean.IsExtraDir("Config") && !Lean.IsExtraDir("Bases"), "only the tester folder is extra");

            // An install like the one in the user's screenshot.
            string install = Dir("Program Files", "Lean MT5");
            Touch(Path.Combine(install, "terminal64.exe"), new string('t', 4000));
            Touch(Path.Combine(install, "MetaEditor64.exe"), new string('e', 3000));
            Touch(Path.Combine(install, "metatester64.exe"), new string('m', 1000));
            Touch(Path.Combine(install, "uninstall.exe"));
            Touch(Path.Combine(install, "MetaEditor64.part1.rar"), new string('r', 2000));
            Touch(Path.Combine(install, "Config", "servers.dat"));
            Touch(Path.Combine(install, "Bases", "Default", "symbols.dat"));
            Touch(Path.Combine(install, "Profiles", "Charts", "Default", "chart01.chr"));
            Touch(Path.Combine(install, "Sounds", "ok.wav"));
            Touch(Path.Combine(install, "Tester", "cache.dat"), new string('c', 5000));
            Touch(Path.Combine(install, "MQL5", "Experts", "uninstall.exe"));  // deeper down nothing is filtered

            var s = new Settings { BaseDir = Dir("lean-copies") };
            CopyMaker.Create(new CreateRequest { Kind = Kind.MT5, Source = install, Count = 1, Prefix = "L", CopyData = false }, s, null);
            string c = Path.Combine(s.BaseDir, "L-01");
            Check(File.Exists(Path.Combine(c, "terminal64.exe")), "lean copy has the terminal");
            Check(File.Exists(Path.Combine(c, "Config", "servers.dat")), "lean copy has the broker servers");
            Check(File.Exists(Path.Combine(c, "Bases", "Default", "symbols.dat")) && File.Exists(Path.Combine(c, "Profiles", "Charts", "Default", "chart01.chr")), "lean copy has bases and profiles");
            Check(!File.Exists(Path.Combine(c, "MetaEditor64.exe")) && !File.Exists(Path.Combine(c, "metatester64.exe")) && !File.Exists(Path.Combine(c, "uninstall.exe")), "lean copy has no editor, tester or uninstaller");
            Check(!File.Exists(Path.Combine(c, "MetaEditor64.part1.rar")), "lean copy has no archives");
            Check(!Directory.Exists(Path.Combine(c, "Tester")), "lean copy has no tester data");
            Check(File.Exists(Path.Combine(c, "MQL5", "Experts", "uninstall.exe")), "only the top of the install is filtered");
            Check(CopyMaker.FolderSize(install, true) < CopyMaker.FolderSize(install) - 10000, "space estimate leaves the extras out");

            // An old, full copy: the cleanup finds the extras, sizes them, and leaves the rest.
            string full = Path.Combine(s.BaseDir, "Full-01");
            CopyMaker.CopyDir(install, full);
            Touch(Path.Combine(full, "logs", "20200101.log"));
            Touch(Path.Combine(full, "logs", "today.log"));
            File.SetLastWriteTime(Path.Combine(full, "logs", "20200101.log"), DateTime.Now.AddDays(-30));
            Touch(Path.Combine(full, "MQL5", "Logs", "20200101.log"));
            File.SetLastWriteTime(Path.Combine(full, "MQL5", "Logs", "20200101.log"), DateTime.Now.AddDays(-30));
            List<Instance> copies = Installs.Copies(s.BaseDir);
            Equal(2, copies.Count, "both copies listed");
            List<CleanupGroup> groups = Cleanup.Scan(copies, DateTime.Now);
            Func<string, CleanupGroup> g = id => groups.First(x => x.Id == id);
            Equal(3, g("tools").Paths.Count, "editor, tester and uninstaller of the full copy");
            Equal(4001L, g("tools").Size, "their size (3000 + 1000 + 1)");
            Equal(1, g("archives").Paths.Count, "the archive");
            Equal(1, g("tester").Paths.Count, "the tester folder");
            Equal(5000L, g("tester").Size, "tester size");
            Equal(2, g("logs").Paths.Count, "only logs older than a week");
            Check(g("tools").Paths.All(x => x.StartsWith(full)), "nothing found in the lean copy");
            Check(Cleanup.ToolBytes(copies) == 6001, "banner counts the extras (tools and archives)");
            Check(!groups.SelectMany(x => x.Paths).Any(x => x.EndsWith("terminal64.exe") || x.Contains("Config") || x.Contains("Bases")), "terminal, servers and bases are never offered");
            Equal(0, g("monitor").Paths.Count, "no old expert: nothing offered");

            // What the expert of earlier versions left: its file, its data folder, and where it was built.
            var fullInst = copies.First(x => x.Name == "Full-01");
            Touch(OldMonitor.Binary(fullInst), new string('b', 300));
            Touch(Path.Combine(OldMonitor.DataFolder(fullInst), "history.txt"), new string('h', 700));
            Touch(Path.Combine(OldMonitor.WorkDir(s.BaseDir), "MTManagerMonitor.ex5"), new string('w', 50));
            groups = Cleanup.Scan(copies, DateTime.Now, new[] { OldMonitor.WorkDir(s.BaseDir), OldMonitor.WorkDir(Dir("no-such-folder")) });
            Equal(3, g("monitor").Paths.Count, "old expert file, its data and its build folder");
            Equal(1050L, g("monitor").Size, "their size");
            Check(Cleanup.Scan(copies, DateTime.Now).First(x => x.Id == "monitor").Paths.Count == 2, "build folder only when asked for");
        }

        static void TextAndDates()
        {
            // Reading a file the terminal holds open for writing.
            string dir = Dir("textfiles");
            string path = Path.Combine(dir, "journal.log");
            File.WriteAllBytes(path, new byte[] { 0xFF, 0xFE }.Concat(Encoding.Unicode.GetBytes("NG\t0\t10:00:00.000\tTerminal\tstarted\r\n")).ToArray());
            using (new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite))
                Equal("NG\t0\t10:00:00.000\tTerminal\tstarted\r\n", TextFiles.ReadText(path), "file read while open elsewhere, without its mark");
            Check(TextFiles.ReadText(Path.Combine(dir, "none.txt")) == null, "missing file reads as null");
            Equal("abc", TextFiles.Decode(Encoding.Unicode.GetBytes("abc")), "UTF-16 without a mark");
            Equal("abc", TextFiles.Decode(new byte[] { 0xEF, 0xBB, 0xBF, 0x61, 0x62, 0x63 }), "UTF-8 with a mark");
            // Written back exactly as read: the mark, and every byte of a one-byte file (MT4's own code page).
            byte[] ansi = { 0x73, 0x79, 0x6D, 0x3D, 0xE9, 0xFC, 0x0D, 0x0A };
            Check(TextFiles.Encode(TextFiles.Decode(ansi), ansi).SequenceEqual(ansi), "one-byte file round trip, unchanged");
            byte[] wide = new byte[] { 0xFF, 0xFE }.Concat(Encoding.Unicode.GetBytes("symbol=EURUSD\r\n")).ToArray();
            Check(TextFiles.Encode(TextFiles.Decode(wide), wide).SequenceEqual(wide), "UTF-16 file round trip with its mark");

            var t0 = new DateTime(2026, 10, 31, 10, 0, 0);
            Equal("۹ آبان ۱۴۰۵", Fa.Date(new DateTime(2026, 10, 31)), "Persian date");
            Equal("۹ آبان ۱۴۰۵، ۱۴:۳۲", Fa.At(new DateTime(2026, 10, 31, 14, 32, 0)), "Persian date and time");
            Equal("۳ دقیقه پیش", Fa.Ago(t0, t0.AddMinutes(3).AddSeconds(5)), "minutes ago");
            Equal("همین حالا", Fa.Ago(t0, t0.AddSeconds(4)), "just now");
        }

        static byte[] Wide(string text) { return new byte[] { 0xFF, 0xFE }.Concat(Encoding.Unicode.GetBytes(text)).ToArray(); }

        /// <summary>One chart for investor copies and copies without an account; the expert of earlier versions taken out before the start.</summary>
        static void ChartsAndOldMonitor()
        {
            string copy = Dir("charts", "MT5-01");
            Touch(Path.Combine(copy, "terminal64.exe"));
            string prof = Path.Combine(copy, "MQL5", "Profiles", "Charts", "Default");
            Directory.CreateDirectory(prof);
            File.WriteAllBytes(Path.Combine(prof, "chart01.chr"), Wide("<chart>\r\nsymbol=EURUSD.m\r\nperiod_type=1\r\n</chart>\r\n"));
            File.WriteAllBytes(Path.Combine(prof, "chart02.chr"), Wide("<chart>\r\nsymbol=GBPUSD.m\r\n</chart>\r\n"));
            File.WriteAllBytes(Path.Combine(prof, "chart03.chr"), Wide("<chart>\r\nsymbol=XAUUSD.m\r\n</chart>\r\n"));
            var inst = new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = copy };
            Equal(prof, ChartProfile.DefaultDir(inst), "MT5 profile folder");
            ChartProfile.MakeLight(inst);
            Equal(1, Directory.GetFiles(prof, "*.chr").Length, "light: one chart left");
            Check(File.Exists(Path.Combine(prof, "chart01.chr")), "the first chart is the one kept");
            Equal(2, Directory.GetFiles(ChartProfile.BackupDir(inst), "*.chr").Length, "the others set aside");
            ChartProfile.MakeLight(inst);
            Equal(2, Directory.GetFiles(ChartProfile.BackupDir(inst), "*.chr").Length, "already light: nothing moves");
            // A profile left with no chart (the terminal was ended before it saved): one set aside comes back.
            File.Delete(Path.Combine(prof, "chart01.chr"));
            ChartProfile.MakeLight(inst);
            Equal(1, Directory.GetFiles(prof, "*.chr").Length, "an empty profile gets one chart back");
            Equal(1, Directory.GetFiles(ChartProfile.BackupDir(inst), "*.chr").Length, "one is still set aside");
            Equal(1, ChartProfile.Restore(inst), "charts restored");
            Equal(2, Directory.GetFiles(prof, "*.chr").Length, "all charts back under free names");
            Check(!ChartProfile.RestoreOne(inst), "nothing set aside: nothing to bring back");

            // The expert of earlier versions: its block goes, everything else of the chart stays byte for byte.
            const string mt5Chart = "<chart>\r\nid=1\r\nsymbol=EURUSD.m\r\nperiod_type=0\r\n<expert>\r\nname=MTManagerMonitor\r\npath=Experts\\MTManagerMonitor.ex5\r\nexpertmode=1\r\n<inputs>\r\n</inputs>\r\n</expert>\r\n<window>\r\nheight=100\r\n</window>\r\n</chart>\r\n";
            bool changed;
            Equal("<chart>\r\nid=1\r\nsymbol=EURUSD.m\r\nperiod_type=0\r\n<window>\r\nheight=100\r\n</window>\r\n</chart>\r\n", OldMonitor.WithoutExpert(mt5Chart, out changed), "MT5 chart without the old expert");
            Check(changed, "change reported");
            const string other = "<chart>\r\n<expert>\r\nname=MyOwnEA\r\nflags=343\r\n</expert>\r\n</chart>\r\n";
            Equal(other, OldMonitor.WithoutExpert(other, out changed), "another expert stays");
            Check(!changed, "nothing changed for another expert");
            Equal("<chart>\n<expert>\nname=MTManagerMonitor\n", OldMonitor.WithoutExpert("<chart>\n<expert>\nname=MTManagerMonitor\n", out changed), "a block without its end stays as it was");

            File.WriteAllBytes(Path.Combine(prof, "chart02.chr"), Wide(mt5Chart));
            string bin = OldMonitor.Binary(inst);
            Touch(bin);
            Touch(Path.Combine(OldMonitor.DataFolder(inst), "state.txt"));
            Equal(2, OldMonitor.Remove(inst), "expert file and its chart");
            Check(!File.Exists(bin), "expert file removed");
            byte[] after = File.ReadAllBytes(Path.Combine(prof, "chart02.chr"));
            Check(after[0] == 0xFF && after[1] == 0xFE && !TextFiles.Decode(after).Contains("MTManagerMonitor") && TextFiles.Decode(after).Contains("symbol=EURUSD.m"), "chart kept as UTF-16, without the expert");
            Check(File.Exists(Path.Combine(OldMonitor.DataFolder(inst), "state.txt")), "what the expert wrote is left for the cleanup tool");
            Equal(0, OldMonitor.Remove(inst), "nothing more to take out");

            // MT4: an ANSI chart in profiles\default, the expert file in MQL4\Experts.
            string copy4 = Dir("charts", "MT4-01");
            Touch(Path.Combine(copy4, "terminal.exe"));
            var mt4 = new Instance { Name = "MT4-01", Kind = Kind.MT4, Dir = copy4 };
            string prof4 = Path.Combine(copy4, "profiles", "default");
            Directory.CreateDirectory(prof4);
            byte[] chart4 = Encoding.ASCII.GetBytes("<chart>\r\nsymbol=EURUSD\r\nperiod=60\r\n<expert>\r\nname=MTManagerMonitor\r\nflags=275\r\nwindow_num=0\r\n<inputs>\r\n</inputs>\r\n</expert>\r\n</chart>\r\n");
            File.WriteAllBytes(Path.Combine(prof4, "chart01.chr"), chart4);
            Touch(OldMonitor.Binary(mt4));
            Check(OldMonitor.Binary(mt4).EndsWith(Path.Combine("MQL4", "Experts", "MTManagerMonitor.ex4")), "MT4 expert file place");

            // Start files: an investor copy is made ready (old expert out, one chart, Default profile on MT5); no expert lines.
            var investor = new Account { Instance = "MT5-01", Login = "51230001", Server = "WMMarkets-DEMO", Mode = "investor", InvestorEnc = Secret.Protect("v") };
            Equal("[Common]|Login=51230001|Password=v|Server=WMMarkets-DEMO|KeepPrivate=1|NewsEnable=0|[Charts]|MaxBars=500|ProfileLast=Default",
                  string.Join("|", Launcher.StartLines(Kind.MT5, investor, "v", true, "Default")), "MT5 investor start file (one chart)");
            Equal("[Common]|Login=51230001|Password=v|Server=WMMarkets-DEMO|KeepPrivate=1|[Charts]|ProfileLast=Default",
                  string.Join("|", Launcher.StartLines(Kind.MT5, investor, "v", false, "Default")), "Default profile without light mode");
            Equal("[Common]|Login=51230001|Password=v|Server=WMMarkets-DEMO|KeepPrivate=1|NewsEnable=0|[Charts]|MaxBars=500|ProfileLast=Empty",
                  string.Join("|", Launcher.StartLines(Kind.MT5, investor, "v", true, ChartProfile.EmptyName)), "MT5 investor start file without any chart (3.17)");
            var store = new AccountStore();
            store.Set(investor);
            store.Set(new Account { Instance = "MT4-01", Login = "2201450", Server = "WMMarkets-Real2", Mode = "investor", InvestorEnc = Secret.Protect("v") });
            var light = new Settings { BaseDir = Dir("charts"), Light = true, StartCharts = ChartModes.One };
            StartResult r5 = Launcher.WriteStartFile(inst, light, store);
            string text5 = TextFiles.ReadText(r5.StartFile);
            Check(text5.Contains("ProfileLast=Default") && !text5.Contains("Expert") && !text5.Contains("[StartUp]"), "MT5 start file: Default profile, no expert");
            Equal(1, Directory.GetFiles(prof, "*.chr").Length, "investor copy opens with one chart");
            StartResult r4 = Launcher.WriteStartFile(mt4, light, store);
            string text4 = TextFiles.ReadText(r4.StartFile);
            Check(!text4.Contains("Expert") && !text4.Contains("Symbol="), "MT4 start file without expert or extra chart");
            Check(!File.Exists(OldMonitor.Binary(mt4)), "MT4 expert file removed before the start");
            byte[] after4 = File.ReadAllBytes(Path.Combine(prof4, "chart01.chr"));
            Equal("<chart>\r\nsymbol=EURUSD\r\nperiod=60\r\n</chart>\r\n", Encoding.ASCII.GetString(after4), "MT4 chart without the expert, still one byte per character");

            // 3.17: opened with no chart at all, the copy's own charts left exactly as they are.
            var empty = new Settings { BaseDir = Dir("charts"), Light = true, StartCharts = ChartModes.Empty };
            string[] before5 = Directory.GetFiles(prof, "*.chr");
            string e5 = TextFiles.ReadText(Launcher.WriteStartFile(inst, empty, store).StartFile);
            string emptyDir = Path.Combine(copy, "MQL5", "Profiles", "Charts", "Empty");
            Check(e5.Contains("ProfileLast=Empty") && e5.Contains("MaxBars=500"), "MT5 opens the empty profile, 500 bars a chart");
            Check(Directory.Exists(emptyDir) && Directory.GetFiles(emptyDir).Length == 0, "an empty profile beside the copy's own");
            Check(Directory.GetFiles(prof, "*.chr").SequenceEqual(before5), "the copy's own charts stay where they are");
            Launcher.WriteStartFile(mt4, empty, store);
            string last4 = Path.Combine(mt4.Dir, "profiles", "lastprofile.ini");
            Check(File.Exists(last4) && File.ReadAllText(last4) == "Empty" && Directory.Exists(Path.Combine(mt4.Dir, "profiles", "Empty")), "MT4 is told by its lastprofile.ini");
            Launcher.WriteStartFile(mt4, light, store);
            Equal("default", File.ReadAllText(last4), "back to one chart: MT4 opens its own profile again");
            string a5 = TextFiles.ReadText(Launcher.WriteStartFile(inst, new Settings { BaseDir = Dir("charts"), Light = false, StartCharts = ChartModes.All }, store).StartFile);
            Check(a5.Contains("ProfileLast=Default"), "all charts after the empty start: MT5 is sent back to its own profile");
            Launcher.DeleteLeftovers(new[] { inst, mt4 });

            // A trading account's copy is never changed: charts and even an old expert file stay.
            string bare = Dir("charts", "MT5-02");
            string bareProf = Path.Combine(bare, "MQL5", "Profiles", "Charts", "Default");
            Directory.CreateDirectory(bareProf);
            for (int k = 1; k <= 4; k++) File.WriteAllBytes(Path.Combine(bareProf, "chart0" + k + ".chr"), Wide("<chart>\r\nsymbol=EURUSD\r\n</chart>\r\n"));
            var bareInst = new Instance { Name = "MT5-02", Kind = Kind.MT5, Dir = bare };
            var traders = new AccountStore();
            traders.Set(new Account { Instance = "MT5-02", Login = "77", Server = "Broker-Live", Mode = "master", MasterEnc = Secret.Protect("m") });
            Touch(OldMonitor.Binary(bareInst));
            StartResult rm = Launcher.WriteStartFile(bareInst, light, traders);
            Equal(4, Directory.GetFiles(bareProf, "*.chr").Length, "a trading account keeps all its charts");
            Check(File.Exists(OldMonitor.Binary(bareInst)), "a trading account's copy is not touched at all");
            Check(!TextFiles.ReadText(rm.StartFile).Contains("ProfileLast"), "a trading account keeps its own profile");
            // A copy without an account opens with one chart.
            Launcher.WriteStartFile(bareInst, light, new AccountStore());
            Equal(1, Directory.GetFiles(bareProf, "*.chr").Length, "no account: one chart left");
            foreach (string f in Directory.GetFiles(bare, Launcher.StartFileName)) File.Delete(f);
        }

        static void StartFiles()
        {
            var acc = new Account { Instance = "MT5-01", Login = "5550001", Server = "Broker-Live", Mode = "master", MasterEnc = Secret.Protect("secret1"), InvestorEnc = Secret.Protect("view1") };
            List<string> mt5 = Launcher.StartLines(Kind.MT5, acc, "secret1", true);
            Equal("[Common]|Login=5550001|Password=secret1|Server=Broker-Live|KeepPrivate=1|NewsEnable=0|[Charts]|MaxBars=500", string.Join("|", mt5), "MT5 start file");
            List<string> mt4 = Launcher.StartLines(Kind.MT4, acc, "view1", false);
            Equal("Login=5550001|Password=view1|Server=Broker-Live|KeepPrivate=true", string.Join("|", mt4), "MT4 start file has no sections");
            Equal("[Common]|NewsEnable=0|[Charts]|MaxBars=500", string.Join("|", Launcher.StartLines(Kind.MT5, null, null, true)), "light mode only");
            Equal("/portable /config:\"C:\\x\\mtm-start.ini\"", Launcher.Arguments(Kind.MT5, @"C:\x\mtm-start.ini"), "MT5 arguments");
            Equal("/portable \"C:\\x\\mtm-start.ini\"", Launcher.Arguments(Kind.MT4, @"C:\x\mtm-start.ini"), "MT4 arguments");
            Equal("/portable", Launcher.Arguments(Kind.MT4, null), "plain portable start");

            string dir = Dir("start", "MT5-01");
            var inst = new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = dir };
            var store = new AccountStore();
            acc.Mode = "investor";
            store.Set(acc);
            StartResult r = Launcher.WriteStartFile(inst, new Settings { Light = false }, store);
            byte[] bytes = File.ReadAllBytes(r.StartFile);
            Check(bytes.Length > 2 && bytes[0] == 0xFF && bytes[1] == 0xFE, "MT5 start file is UTF-16 with BOM");
            string text = Encoding.Unicode.GetString(bytes, 2, bytes.Length - 2);
            Check(text.Contains("Password=view1") && !text.Contains("secret1"), "investor mode logs in with the investor password");
            Equal(null, r.Warning, "no warning");
            Launcher.DeleteLeftovers(new[] { inst });
            Check(!File.Exists(r.StartFile), "leftover start file deleted");

            string fresh = Dir("start", "MT5-09");
            var none = Launcher.WriteStartFile(new Instance { Name = "MT5-09", Kind = Kind.MT5, Dir = fresh }, new Settings { Light = false, StartCharts = ChartModes.All }, store);
            Equal(null, none.StartFile, "no account, no light mode, all charts: no start file");
            var bare = Launcher.WriteStartFile(new Instance { Name = "MT5-09", Kind = Kind.MT5, Dir = fresh }, new Settings { Light = false, StartCharts = ChartModes.Empty }, store);
            Equal("[Common]|[Charts]|ProfileLast=Empty", string.Join("|", File.ReadAllLines(bare.StartFile, Encoding.Unicode)), "no account: a start file for the empty profile only, no password");
            Launcher.DeleteStartFile(bare.StartFile);
            store.Set(new Account { Instance = "MT5-09", Login = "1", Server = "S", Mode = "master", MasterEnc = "bm90IGVuY3J5cHRlZA==" });
            var foreign = Launcher.WriteStartFile(new Instance { Name = "MT5-09", Kind = Kind.MT5, Dir = dir }, new Settings { Light = false }, store);
            Check(foreign.Warning != null, "a password from another computer gives a warning");
        }

        static void HeapValue()
        {
            string raw = @"%SystemRoot%\system32\csrss.exe ObjectDirectory=\Windows SharedSection=1024,20480,768 Windows=On SubSystemType=Windows ServerDll=basesrv,1";
            Equal(20480, Heap.Interactive(raw) ?? 0, "current heap read");
            string next = Heap.WithInteractive(raw, 40960);
            Equal(raw.Replace("1024,20480,768", "1024,40960,768"), next, "only the middle number changes");
            Equal("a SharedSection=1024,65536 b", Heap.WithInteractive("a SharedSection=1024,20480 b", 65536), "two-number form");
            Throws<UserMessage>(() => Heap.WithInteractive("nothing here", 40960), "missing SharedSection refused");
        }

        static void CsvParsing()
        {
            Equal(',', Csv.Delimiter("Copy,Trader,Login"), "comma");
            Equal(';', Csv.Delimiter("Copy;Trader;Login"), "semicolon (Excel with Persian regional settings)");
            List<string[]> rows = Csv.Parse("a,\"b,c\",\"d \"\"q\"\"\"\r\n1,2,3\r\n", ',');
            Equal(2, rows.Count, "rows");
            Equal("b,c", rows[0][1], "quoted comma");
            Equal("d \"q\"", rows[0][2], "escaped quote");
            Equal("3", rows[1][2], "last field");
            string t = Csv.Template(new[] { new Instance { Name = "MT4-01", Kind = Kind.MT4, Dir = root } });
            Check(t.StartsWith("Copy,Trader,Login,Server,Password,Investor,Mode") && t.Contains("MT4-01,,,,,,"), "template");
        }

        static void CsvImport()
        {
            var copies = new List<Instance>();
            for (int i = 1; i <= 3; i++) copies.Add(new Instance { Name = "MT4-0" + i, Kind = Kind.MT4, Dir = root });
            var store = new AccountStore();
            store.Set(new Account { Instance = "MT4-01", Login = "1", Server = "S", MasterEnc = Secret.Protect("x") });
            string csv =
                "Copy,Trader,Login,Server,Password,Investor,Mode\r\n" +
                ",رضا,۱۱۱۲۲۲,Broker-Live,pw1,inv1,\r\n" +          // no copy: goes to MT4-02 (MT4-01 has an account)
                "MT4-01,سارا,333,Broker-Live,,inv3,investor\r\n" +   // replaces MT4-01, investor
                ",x,12a,Broker,p,,\r\n" +                            // bad login
                ",x,444,,p,,\r\n" +                                  // no server
                "MT4-09,x,555,S,p,,\r\n" +                           // unknown copy
                ",x,666,S,,,\r\n" +                                  // no password at all
                ",نفر سوم,777,S,,inv7,\r\n" +                        // investor only: goes to MT4-03
                ",نفر چهارم,888,S,p8,,\r\n" +                        // no copy left
                ",,,,,,\r\n";                                       // empty row ignored
            ImportResult r = Csv.Import("\uFEFF" + csv, copies, store);
            Equal(3, r.Added, "imported rows");
            Equal(5, r.Problems.Count, "problem rows");
            Account a2 = store.Get("MT4-02");
            Equal("111222", a2.Login, "Persian digits in login");
            Equal("master", a2.Mode, "mode from the master password");
            Equal("pw1", Secret.Unprotect(a2.MasterEnc), "master password stored");
            Equal("inv1", Secret.Unprotect(a2.InvestorEnc), "investor password stored");
            Equal("investor", store.Get("MT4-01").Mode, "explicit investor");
            Equal("سارا", store.Get("MT4-01").Trader, "trader replaced");
            Account a3 = store.Get("MT4-03");
            Equal("777", a3.Login, "investor-only row");
            Equal("investor", a3.Mode, "investor mode inferred");

            var persian = Csv.Import("نسخه;شماره حساب;سرور;رمز اصلی\r\nMT4-02;999;S;p\r\n", copies, store);
            Equal(1, persian.Added, "Persian headers and semicolons");
            Equal("999", store.Get("MT4-02").Login, "row by Persian header");
            Equal(1, Csv.Import("Name,Server\r\nx,y\r\n", copies, store).Problems.Count, "missing login column reported");
        }

        static void ServerList()
        {
            Equal("WMMarkets", ServerCatalog.Broker("WMMarkets-Real1"), "broker of a server");
            Equal("XMGlobal", ServerCatalog.Broker("XMGlobal-MT5 2"), "broker of a server with spaces");
            Equal("wmmarkets", ServerCatalog.Norm("WM Markets"), "spaces ignored");
            Equal(ServerCatalog.Norm("wm-markets"), ServerCatalog.Norm("WMMarkets"), "dashes and case ignored");

            List<string> parsed = ServerCatalog.ParseList("{\"mt5\":[\"WMMarkets-Demo\",\"A\\\"B-Live\",\"wmmarkets-demo\",\" \"],\"x\":[\"No-One\"]}", "mt5");
            Equal("WMMarkets-Demo|A\"B-Live", string.Join("|", parsed), "list parsed, escapes read, duplicates and blanks dropped");
            Equal(0, ServerCatalog.ParseList("{\"mt4\":[]}", "mt5").Count, "missing key gives an empty list");
            Equal(0, ServerCatalog.ParseList("<html>error</html>", "mt5").Count, "an error page gives an empty list");

            var all = new List<string> { "XWM-Live", "WMMarkets-Demo", "WMMarkets-Real1", "AlpariMT5-Demo", "Pepperstone-Edge01", "XMGlobal-MT5 2" };
            Equal("WMMarkets-Demo|WMMarkets-Real1", string.Join("|", ServerCatalog.Search(all, "wm markets")), "broker found the way it is written");
            Equal("WMMarkets-Demo|WMMarkets-Real1|XWM-Live", string.Join("|", ServerCatalog.Search(all, "WM")), "names starting with the text come first");
            Equal("AlpariMT5-Demo|XMGlobal-MT5 2", string.Join("|", ServerCatalog.Search(all, "mt5")), "text inside the name found");
            Equal("WMMarkets-Real1", string.Join("|", ServerCatalog.Search(all, "wmmarkets real۱")), "Persian digits in the search");
            Equal(2, ServerCatalog.Search(all, "", 2).Count, "empty search shows the start of the list");
            Equal(0, ServerCatalog.Search(all, "zzz").Count, "nothing found");

            // The real list saved from MetaQuotes while building this version, when it is next to the sources.
            string sample = Path.Combine("..", "research", "mq", "servers5.json");
            if (File.Exists(sample))
            {
                List<string> real = ServerCatalog.ParseList(File.ReadAllText(sample), "mt5");
                Check(real.Count > 1000, "real MetaQuotes list read (" + real.Count + ")");
                Check(ServerCatalog.Search(real, "wm markets").Contains("WMMarkets-Real1"), "WM Markets found in the real list");
            }

            // Which installed MetaTrader a new student's copy is made from.
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string wm = Dir("Program Files", "WM Markets MetaTrader 5");
            Touch(Path.Combine(wm, "terminal64.exe"));
            string other = Dir("Program Files", "Other MetaTrader 5");
            Touch(Path.Combine(other, "terminal64.exe"));
            string mt4 = Dir("Program Files", "Plain MetaTrader 4");
            Touch(Path.Combine(mt4, "terminal.exe"));
            Touch(Path.Combine(mt4, "config", "WMMarkets-Real2.srv"));
            var registered = new List<string>();
            foreach (string d in new[] { wm, other, mt4 })
            {
                string data = Path.Combine(appData, "MetaQuotes", "Terminal", "T" + Guid.NewGuid().ToString("N").Substring(0, 12));
                Directory.CreateDirectory(data);
                File.WriteAllText(Path.Combine(data, "origin.txt"), d, Encoding.Unicode);
                registered.Add(data);
            }
            try
            {
                var s = new Settings { BaseDir = Dir("copies-servers") };
                bool sure;
                Equal(wm, ServerCatalog.InstallFor(Kind.MT5, "WMMarkets-Real1", s, out sure), "the broker's own MetaTrader 5 is used");
                Check(sure, "found by the broker's name");
                Equal(mt4, ServerCatalog.InstallFor(Kind.MT4, "WMMarkets-Real2", s, out sure), "the MetaTrader 4 that has the server file is used");
                Check(sure, "found by the server file");
                string any = ServerCatalog.InstallFor(Kind.MT5, "NewBroker-Live", s, out sure);
                Check(any != null && !sure, "unknown broker falls back to an installed MetaTrader 5");

                Touch(Path.Combine(other, "Bases", "NewBroker-Live", "x.dat"));
                Equal(other, ServerCatalog.InstallFor(Kind.MT5, "NewBroker-Demo", s, out sure), "an install that already connected to the broker is used");
                Check(sure, "found by its Bases folder");

                var store = new AccountStore();
                store.Set(new Account { Instance = "MT5-77", Login = "1", Server = "Typed-Server", Mode = "investor" });
                List<string> local = ServerCatalog.Local(Kind.MT5, s, store);
                Check(local.Contains("NewBroker-Live"), "servers this computer connected to are listed");
                Check(local.Contains("Typed-Server"), "servers typed before are listed");
                Check(ServerCatalog.Local(Kind.MT4, s, null).Contains("WMMarkets-Real2"), "MT4 server files are listed");
            }
            finally
            {
                foreach (string d in registered) try { Directory.Delete(d, true); } catch { }
            }
        }

        static void LoginCheck()
        {
            const string me = "51234567";
            Func<string[], Login> state = ls => ConnectionCheck.FromJournal(ls, me).State;
            Equal(Login.Waiting, state(new string[0]), "nothing yet");
            Equal(Login.Connected, state(new[] { "NG\t0\t14:53:22.150\tNetwork\t'51234567': authorized on WMMarkets-Real1 through Access Point EU 2 (ping: 54.37 ms, build 4755)" }), "MT5 logged in");
            Equal(Login.WrongLogin, state(new[] { "LE\t0\t14:53:22.150\tNetwork\t'51234567': authorization on WMMarkets-Real1 failed (Invalid account)" }), "wrong number or password");
            Equal(Login.NoConnection, state(new[] { "LE\t0\t14:53:22.150\tNetwork\t'51234567': authorization on WMMarkets-Real1 failed (No connection)" }), "no connection is not a wrong password");
            Equal(Login.NoServer, state(new[] { "LE\t0\t14:53:22.150\tNetwork\t'51234567': server WMMarkets-Real9 not found" }), "unknown server");
            Equal(Login.Waiting, state(new[] { "NG\t0\t14:53:22.150\tNetwork\t'99999': authorized on Other-Live" }), "another account's line is ignored");
            Equal(Login.Connected, state(new[] { "'51234567': authorization on X failed (No connection)", "'51234567': authorized on X through Access Point" }), "the newest line wins");
            Equal(Login.Connected, state(new[] { "0\t14:53:22.150\t'51234567': login datacenter on WMMarkets-Real2 through Access Point #1 (ping: 45 ms)" }), "MT4 logged in");

            string dir = Dir("journal", "MT5-01");
            Dir("journal", "MT5-01", "logs");
            var inst = new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = dir };
            var since = new DateTime(2026, 10, 30, 23, 59, 50);
            File.WriteAllText(ConnectionCheck.JournalFile(inst, since), "LE\t0\t23:50:00.000\t'51234567': authorization on X failed (Invalid account)\r\nNG\t0\t23:59:55.000\tTerminal\tstarted\r\n", Encoding.Unicode);
            File.WriteAllText(ConnectionCheck.JournalFile(inst, since.AddDays(1)), "NG\t0\t00:00:03.000\tNetwork\t'51234567': authorized on X\r\n", Encoding.Unicode);
            List<string> lines = ConnectionCheck.JournalSince(inst, since, since.AddSeconds(20));
            Equal(2, lines.Count, "only lines written since the check started, across midnight");
            Equal(Login.Connected, ConnectionCheck.FromJournal(lines, me).State, "an old failure in the journal does not count");
            Equal(Login.NoConnection, state(new[] { "'51234567': authorized on X", "NG\t0\t15:00:01.000\tNetwork\t'51234567': connection to X lost" }), "a lost connection after the login");

            // Following a growing journal: only what was added is read, a line split between two looks is kept whole.
            string wdir = Dir("journal", "MT5-02");
            Dir("journal", "MT5-02", "logs");
            var w2 = new Instance { Name = "MT5-02", Kind = Kind.MT5, Dir = wdir };
            var now = new DateTime(2026, 10, 31, 10, 0, 30);
            string file = ConnectionCheck.JournalFile(w2, now);
            var watch = new LoginWatch();
            Equal(Login.Waiting, watch.Update(w2, me, now.AddSeconds(-30), now).State, "no journal yet");
            Func<string, byte[]> u16 = t => Encoding.Unicode.GetBytes(t);
            File.WriteAllBytes(file, new byte[] { 0xFF, 0xFE }.Concat(u16("LE\t0\t09:00:00.000\t'51234567': authorization on X failed (Invalid account)\r\nNG\t0\t10:00:05.000\tTerminal\tstarted\r\n")).ToArray());
            Equal(Login.Waiting, watch.Update(w2, me, now.AddSeconds(-30), now).State, "a failure from before this start does not count");
            using (var f = new FileStream(file, FileMode.Append)) { byte[] b = u16("NG\t0\t10:00:09.000\tNetwork\t'51234567': authoriz"); f.Write(b, 0, b.Length); }
            Equal(Login.Waiting, watch.Update(w2, me, now.AddSeconds(-30), now).State, "half a line waits");
            using (var f = new FileStream(file, FileMode.Append)) { byte[] b = u16("ed on WMMarkets-Real1 through Access Point\r\n"); f.Write(b, 0, b.Length); }
            Equal(Login.Connected, watch.Update(w2, me, now.AddSeconds(-30), now).State, "the completed line is read");
            Equal(Login.Connected, watch.Update(w2, me, now.AddSeconds(-30), now).State, "nothing new keeps the outcome");
            using (var f = new FileStream(file, FileMode.Append)) { byte[] b = u16("LE\t0\t10:02:00.000\tNetwork\t'51234567': authorization on WMMarkets-Real1 failed (Invalid account)\r\n"); f.Write(b, 0, b.Length); }
            Equal(Login.WrongLogin, watch.Update(w2, me, now.AddSeconds(-30), now).State, "a later failure wins");
            Equal(Login.Waiting, watch.Update(w2, "999", now.AddSeconds(-30), now).State, "another account starts over");

            // An ANSI journal (older MT4 builds).
            string adir = Dir("journal", "MT4-01");
            Dir("journal", "MT4-01", "logs");
            var w4 = new Instance { Name = "MT4-01", Kind = Kind.MT4, Dir = adir };
            File.WriteAllText(ConnectionCheck.JournalFile(w4, now), "0\t10:00:20.000\t'2201450': login datacenter on WMMarkets-Real2 through Access Point #1\r\n", Encoding.ASCII);
            Equal(Login.Connected, new LoginWatch().Update(w4, "2201450", now.AddSeconds(-30), now).State, "MT4 journal without BOM");
        }

        static void BuildFolders()
        {
            // Settings remember the folders, the default first.
            var s = new Settings { BaseDir = Dir("folders", "A"), LowPriority = false, TrimMemory = false };
            s.UseFolder(Dir("folders", "B"));
            Equal(Path.Combine(root, "folders", "B"), s.BaseDir, "the chosen folder is the default now");
            Equal(2, s.AllFolders.Count, "the folder used before stays");
            s.UseFolder(Dir("folders", "B") + "\\");
            Equal(2, s.AllFolders.Count, "the same folder is not added twice");
            s.Save();
            Settings r = Settings.Load();
            Equal(string.Join("|", s.AllFolders), string.Join("|", r.AllFolders), "folders saved and read back");
            Equal(false, r.LowPriority, "low priority setting saved");
            Equal(false, r.TrimMemory, "memory setting saved");
            Equal(true, new Settings().LowPriority && new Settings().TrimMemory, "both on by default");

            // Copies in both folders are listed; numbering continues over both, so a name is never used twice.
            string install = Dir("folders", "src", "Broker MetaTrader 5");
            Touch(Path.Combine(install, "terminal64.exe"));
            Touch(Path.Combine(install, "config", "servers.dat"));
            var reqA = new CreateRequest { Kind = Kind.MT5, Source = install, Count = 2, Prefix = "MT5", CopyData = false, Folder = Path.Combine(root, "folders", "A") };
            List<string> a = CopyMaker.Create(reqA, s, null);
            Equal("MT5-01,MT5-02", string.Join(",", a), "first copies in folder A");
            var reqB = new CreateRequest { Kind = Kind.MT5, Source = install, Count = 2, Prefix = "MT5", CopyData = false, Folder = s.BaseDir };
            List<string> b = CopyMaker.Create(reqB, s, null);
            Equal("MT5-03,MT5-04", string.Join(",", b), "numbers go on in folder B");
            Check(File.Exists(Path.Combine(s.BaseDir, "MT5-03", "terminal64.exe")), "made in the chosen folder");
            List<Instance> all = Installs.Copies(s);
            Equal("MT5-03,MT5-04,MT5-01,MT5-02", string.Join(",", all.Select(i => i.Name)), "copies of every folder, the default one first");
            Touch(Path.Combine(root, "folders", "A", "MT5-03", "terminal64.exe"));
            Equal(4, Installs.Copies(s).Count, "a name used twice is listed once");
            Check(!Installs.Find(Kind.MT5, s).Any(d => d.StartsWith(Path.Combine(root, "folders", "A"))), "copies in any folder are not offered as installs");

            Throws<UserMessage>(() => CopyMaker.CheckFolder(""), "an empty folder is refused");
            Throws<UserMessage>(() => CopyMaker.CheckFolder(Path.Combine(root, "Program Files", "x")), "Program Files is refused");
            Equal(Path.Combine(root, "folders", "C"), CopyMaker.CheckFolder(" \"" + Path.Combine(root, "folders", "C") + "/\" "), "quotes and the last slash are cleaned");
            Check(Directory.Exists(Path.Combine(root, "folders", "C")), "a new folder is made");
            var inside = new CreateRequest { Kind = Kind.MT5, Source = install, Count = 1, Folder = Path.Combine(install, "copies") };
            Throws<UserMessage>(() => CopyMaker.Check(inside, s), "not inside the MetaTrader that is copied");
        }

        static void Pacing()
        {
            Check(!StartPace.Ready(1, 5, false, true, 0), "never sooner than a moment after the one before");
            Check(StartPace.Ready(2.5, 5, false, true, 0.05), "up and settled: the next one starts before the delay");
            Check(!StartPace.Ready(3, 5, false, true, 0.8), "still busy: wait");
            Check(!StartPace.Ready(3, 5, false, false, 0), "no window yet: wait");
            Check(StartPace.Ready(5, 5, false, false, 0.9), "never later than the set delay");
            Check(StartPace.Ready(2, 10, true, false, 0), "it closed: go on");
            Check(StartPace.Ready(0, 0, false, false, 1), "no delay set: right away");
            string plain = string.Join("|", Launcher.StartLines(Kind.MT5, new Account { Login = "1", Server = "S", Mode = "investor" }, "p", false));
            Check(!plain.Contains("MaxBars") && !plain.Contains("[Charts]"), "without light mode the terminal keeps its own number of bars");
        }

        /// <summary>MetaTrader's own update: recognised from the journal; copies brought to the downloaded build before they start.</summary>
        static void MetaTraderUpdate()
        {
            // Lines from a real MT4 copy that closed itself to update (no to Windows' question, then yes).
            Check(SelfUpdate.InLines(new[] { "1\t07:54:36.012\tLiveUpdate: updater - elevated updater start failed [1223]", "0\t07:54:36.014\tLiveUpdate: updater - try to close terminal" }), "MT4 update, Windows' question answered no");
            Check(SelfUpdate.InLines(new[] { "0\t12:12:44.175\tLiveUpdate: updater - started for portable 'E:\\MetaTrader\\MT4-01'", "0\t12:12:44.176\tLiveUpdate: updater - start admin updater" }), "MT4 update, with administrator rights");
            Check(!SelfUpdate.InLines(new[] { "QK\t0\t11:00:04.881\tLiveUpdate\t'mt5clwide64' downloaded (43713 kb)", "PH\t0\t11:01:53.664\tLiveUpdate\tdownloaded successfully" }), "a download alone is no update");
            Check(!SelfUpdate.InLines(new[] { "0\t12:12:58.736\tLiveUpdate: update E:\\MetaTrader\\MT4-01\\MQL4 folder started" }), "the MQL4 folder step after the start is no closing");
            Check(!SelfUpdate.InLines(new[] { "0\t12:12:46.028\t'51230001': login on WMMarkets-DEMO through 203.0.113.10:443 (ping: n/a)" }), "a login is no update");
            // 3.27.3: newer MT5 builds start the updater with this line, then close (exit code 0).
            Check(SelfUpdate.InLines(new[] { "EJ\t0\t22:58:12.411\tLiveUpdate\tstart \"C:\\Users\\u\\AppData\\Roaming\\MetaQuotes\\Terminal\\1E0C2AA7\\liveupdate\\terminal64.exe\" /update /path:\"E:\\MetaTrader\\MT5-19\" /portable /config:\"E:\\MetaTrader\\MT5-19\\mtm-start.ini\"", "LF\t0\t22:58:12.829\tTerminal\texit with code 0" }), "MT5 update (newer builds: LiveUpdate start ... /update)");
            Check(EarlyClose.Explain(new[] { "LS\t0\t22:58:12.004\tStartup\tsuccessfully initialized from start config", "EJ\t0\t22:58:12.411\tLiveUpdate\tstart \"C:\\Users\\u\\AppData\\Roaming\\MetaQuotes\\Terminal\\1E0C2AA7\\liveupdate\\terminal64.exe\" /update /path:\"E:\\MetaTrader\\MT5-19\" /portable /config:\"E:\\MetaTrader\\MT5-19\\mtm-start.ini\"", "LF\t0\t22:58:12.829\tTerminal\texit with code 0" }, "20254979").Kind == EarlyKind.Updated,
                  "and an MT5 that closed right after it is explained as updating itself, not as no reason");

            string dir = Dir("journal", "MT4-09");
            Dir("journal", "MT4-09", "logs");
            var mt4 = new Instance { Name = "MT4-09", Kind = Kind.MT4, Dir = dir };
            DateTime start = DateTime.Today.AddHours(12).AddMinutes(12).AddSeconds(38);
            File.WriteAllText(ConnectionCheck.JournalFile(mt4, start),
                "0\t09:00:00.000\tLiveUpdate: updater - try to close terminal\r\n" +
                "0\t12:12:40.779\tStarted with configuration file 'E:\\MetaTrader\\MT4-09\\mtm-start.ini'\r\n", Encoding.Default);
            Check(!SelfUpdate.Since(mt4, start), "an update from an earlier start does not count");
            File.AppendAllText(ConnectionCheck.JournalFile(mt4, start), "0\t12:12:44.175\tLiveUpdate: updater - started for portable 'E:\\MetaTrader\\MT4-09'\r\n", Encoding.Default);
            Check(SelfUpdate.Since(mt4, start), "an update since this start counts");

            Version v1470 = new Version(4, 0, 0, 1470), v1492 = new Version(4, 0, 0, 1492);
            Check(TerminalUpdate.Newer(v1492, v1470), "newer build");
            Check(!TerminalUpdate.Newer(v1470, v1492), "older build is not put in place");
            Check(!TerminalUpdate.Newer(v1470, v1470), "same build");
            Check(!TerminalUpdate.Newer(new Version(5, 0, 0, 5830), v1470), "another program (MT5) is not put in place");
            Check(!TerminalUpdate.Newer(null, v1470) && !TerminalUpdate.Newer(v1492, null), "unknown versions do nothing");
            Check(TerminalUpdate.Allowed(null), "copy without account is brought up to date");
            Check(TerminalUpdate.Allowed(new Account { Login = "51230001", Server = "WMMarkets-DEMO", Mode = "investor" }), "investor copy is brought up to date");
            Check(!TerminalUpdate.Allowed(new Account { Login = "51230001", Server = "WMMarkets-DEMO", Mode = "master" }), "trading (master) copy is never changed");

            string fx = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "test", "fx");
            Equal(v1470, TerminalUpdate.FileVersion(Path.Combine(fx, "t1470.exe")), "version read from the file");
            Equal(null, TerminalUpdate.FileVersion(Path.Combine(fx, "t.cs")), "a file without version");
            // Real terminals are megabytes; a small file in the download folder is taken as half downloaded.
            Action<string, string> big = (from, to) =>
            {
                Directory.CreateDirectory(Path.GetDirectoryName(to));
                File.Copy(Path.Combine(fx, from), to, true);
                using (var f = new FileStream(to, FileMode.Append)) f.Write(new byte[1100000], 0, 1100000);
            };
            string cache = Dir("webinstall", "mt4clw");
            TerminalUpdate.CacheDirOverride = cache;
            try
            {
                string copy = Dir("update", "MT4-01"), lean = Dir("update", "MT4-02");
                var c1 = new Instance { Name = "MT4-01", Kind = Kind.MT4, Dir = copy };
                var c2 = new Instance { Name = "MT4-02", Kind = Kind.MT4, Dir = lean };
                big("t1470.exe", c1.Exe);
                big("t1470.exe", Path.Combine(copy, "metaeditor.exe"));
                big("t1470.exe", c2.Exe);
                Equal(null, TerminalUpdate.Apply(c1), "no download yet: nothing done");
                File.Copy(Path.Combine(fx, "t1492.exe"), Path.Combine(cache, "terminal.exe"), true);
                Equal(null, TerminalUpdate.Apply(c1), "a half-downloaded file is not used");
                big("t1492.exe", Path.Combine(cache, "terminal.exe"));
                big("t1492.exe", Path.Combine(cache, "metaeditor.exe"));
                Equal(v1492, TerminalUpdate.Pending(c1), "newer build waiting");
                Equal(v1492, TerminalUpdate.Apply(c1), "copy brought to the downloaded build");
                Equal(v1492, TerminalUpdate.FileVersion(c1.Exe), "terminal replaced");
                Equal(v1492, TerminalUpdate.FileVersion(Path.Combine(copy, "metaeditor.exe")), "editor replaced where the copy has it");
                Check(!File.Exists(c1.Exe + ".mtm-new"), "no temporary file left");
                Equal(null, TerminalUpdate.Apply(c1), "already up to date: nothing done");
                Equal(v1492, TerminalUpdate.Apply(c2), "lean copy brought up to date");
                Check(!File.Exists(Path.Combine(lean, "metaeditor.exe")), "lean copy stays without the editor");
                big("t1470.exe", Path.Combine(cache, "terminal.exe"));
                Equal(null, TerminalUpdate.Apply(c1), "an older download never replaces a newer copy");
                Equal(v1492, TerminalUpdate.FileVersion(c1.Exe), "newer copy untouched");
                var mt5 = new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = Dir("update", "MT5-01") };
                Equal(null, TerminalUpdate.CacheDir(Kind.MT5), "MT5 updates in its own way");
                Equal(null, TerminalUpdate.Apply(mt5), "MT5 left alone");
            }
            finally { TerminalUpdate.CacheDirOverride = null; }
        }

        /// <summary>MT4 keeps at most 32 open per Windows user.</summary>
        static void Mt4Cap()
        {
            Equal(32, new Settings().MaxMt4, "MT4 limit by default");
            var s = new Settings { BaseDir = Dir("cap"), MaxMt4 = 40 };
            s.Save();
            Equal(40, Settings.Load().MaxMt4, "MT4 limit saved");
            File.AppendAllText(AppPaths.SettingsFile, "MaxMt4=0\r\n");
            Equal(1, Settings.Load().MaxMt4, "MT4 limit never below one");
            File.AppendAllText(AppPaths.SettingsFile, "MaxMt4=abc\r\n");
            Equal(1, Settings.Load().MaxMt4, "unreadable MT4 limit keeps the last good value");
            new Settings { BaseDir = s.BaseDir }.Save();
            Equal(32, Settings.Load().MaxMt4, "settings saved before 3.9.3 read as 32");
            Check(Mt4Limit.Room(31, 32), "room for the 32nd");
            Check(!Mt4Limit.Room(32, 32), "no room for the 33rd");
            Check(!Mt4Limit.Room(5, 0), "a limit of 0 counts as 1");
            Check(Mt4Limit.Room(0, 0), "the first always opens");
            Check(Processes.Mt4InSession() >= 0, "MT4 count readable");
            // Settings of earlier versions carry "Watch=1": read without trouble, and gone when saved again.
            File.AppendAllText(AppPaths.SettingsFile, "Watch=1\r\n");
            Equal(s.BaseDir, Settings.Load().BaseDir, "an old setting is ignored");
            Settings.Load().Save();
            Check(!File.ReadAllText(AppPaths.SettingsFile).Contains("Watch="), "and not written again");
        }

        static void QuickChecks()
        {
            var s = new Settings { BaseDir = Dir("quick") };
            var store = new AccountStore();
            List<Issue> none = Checks.Quick(s, new List<Instance>(), store, 20480, false);
            Check(none.Any(i => i.Fix == Fix.Create), "no MetaTrader installed is reported");
            var many = Enumerable.Range(1, 12).Select(i => new Instance { Name = "MT4-" + i, Kind = Kind.MT4, Dir = root }).ToList();
            Check(Checks.Quick(s, many, store, 20480, true).Any(i => i.Fix == Fix.Heap), "low window limit is reported for many copies");
            Check(!Checks.Quick(s, many, store, 40960, true).Any(i => i.Fix == Fix.Heap), "raised window limit is not reported");
            store.Set(new Account { Instance = "MT4-1", Login = "1", Server = "S", MasterEnc = "bm90IGVuY3J5cHRlZA==" });
            Check(Checks.Quick(s, many, store, 40960, true).Any(i => i.Text.Contains("خوانده نمی‌شود")), "unreadable passwords are reported");
        }

        /// <summary>Only MetaTraders this program opened are closed: matched by process id and start time.</summary>
        static void OwnedOnly()
        {
            Equal(0, Owned.Parse(new[] { "", "x\ty\tz", "0\t5\tC:\\a\\terminal.exe", "12\t0\tC:\\a\\terminal.exe", "12\t99\t " }).Count, "bad lines are skipped");
            List<Owned.Entry> one = Owned.Parse(Owned.Format(new[] { new Owned.Entry { Pid = 12, Start = 131000000000000000, Exe = @"E:\MetaTrader\MT5-01\terminal64.exe" } }));
            Check(one.Count == 1 && one[0].Pid == 12 && one[0].Start == 131000000000000000 && one[0].Exe == @"E:\MetaTrader\MT5-01\terminal64.exe", "list round trip");

            DateTime now = new DateTime(2026, 11, 10, 10, 0, 0, DateTimeKind.Utc);
            long t = now.AddMinutes(-1).ToFileTimeUtc();
            const string a = @"E:\MetaTrader\MT5-01\terminal64.exe", b = @"E:\MetaTrader\MT5-02\terminal64.exe", c = @"D:\MetaTrader\MT4-01\terminal.exe";
            File.Delete(Owned.FilePath);
            Owned.Add(100, t, a);
            Owned.Add(200, t, b);
            Owned.Add(0, 0, c);  // a start time that could not be read: not recorded, so never closed
            var starts = new Dictionary<int, long> { { 100, t }, { 200, t }, { 300, t }, { 400, t } };
            Func<int, long> startOf = pid => { long v; return starts.TryGetValue(pid, out v) ? v : 0; };
            Func<string, long, bool> noUpdate = (exe, since) => false;
            var running = new Dictionary<string, int> { { a.ToLowerInvariant(), 100 }, { b.ToLowerInvariant(), 200 }, { c.ToLowerInvariant(), 300 },
                                                        { @"c:\program files\wm markets mt5\terminal64.exe", 400 } };
            HashSet<string> mine = Owned.Mine(running, startOf, noUpdate, now);
            Check(mine.Contains(a.ToLowerInvariant()) && mine.Contains(b.ToLowerInvariant()), "the two opened here");
            Check(!mine.Contains(c.ToLowerInvariant()), "a copy opened by hand is not ours");
            Check(!mine.Contains(@"c:\program files\wm markets mt5\terminal64.exe"), "the broker's own install is never ours");
            Equal(2, mine.Count, "nothing else");

            // MT5-02 closed and opened again by hand: its id may even come back, its start time does not.
            starts[200] = now.AddSeconds(-5).ToFileTimeUtc();
            Check(!Owned.Mine(running, startOf, noUpdate, now).Contains(b.ToLowerInvariant()), "same id, another start: not ours");
            starts[200] = t;
            Check(!Owned.Mine(running, startOf, noUpdate, now).Contains(b.ToLowerInvariant()), "and it stays forgotten");

            // MetaTrader's own update: the one opened here closes and MetaTrader starts it again a moment later.
            running[a.ToLowerInvariant()] = 500;
            starts[500] = now.AddSeconds(-20).ToFileTimeUtc();
            Check(!Owned.Mine(running, startOf, noUpdate, now).Contains(a.ToLowerInvariant()), "another run without an update in its journal: not ours");
            Owned.Add(100, t, a);
            Check(Owned.Mine(running, startOf, (exe, since) => exe == a && since == t, now).Contains(a.ToLowerInvariant()), "started again by MetaTrader's update: still ours");
            Check(Owned.Mine(running, startOf, noUpdate, now).Contains(a.ToLowerInvariant()), "and from then on by its new id");
            starts[600] = now.AddMinutes(30).ToFileTimeUtc();
            Owned.Add(100, t, a);
            running[a.ToLowerInvariant()] = 600;
            Check(!Owned.Mine(running, startOf, (exe, since) => true, now.AddMinutes(31)).Contains(a.ToLowerInvariant()), "long after the start it is not taken for the update");

            // Closed: kept for a while (an update may bring it back), then dropped.
            Owned.Add(100, t, a);
            running.Remove(a.ToLowerInvariant());
            Owned.Mine(running, startOf, noUpdate, now);
            Check(File.ReadAllText(Owned.FilePath).Contains(a), "closed a moment ago: still known");
            Owned.Mine(running, startOf, noUpdate, now.AddMinutes(20));
            Check(!File.ReadAllText(Owned.FilePath).Contains(a), "gone for long: dropped");

            // The first start of 3.12 with MetaTraders that 3.11 opened: the program's own log tells which.
            DateTime at = new DateTime(2026, 11, 9, 15, 33, 10);
            string[] log =
            {
                "2026-11-09 15:33:08  started MT5-01 (account 51230001, investor)",
                "2026-11-09 15:40:00  started MT5-1 (account 51230002, investor)",
                "2026-11-09 16:02:11  MT4-01 started again by MetaTrader after its update",
                "1405-08-18 15:33:09  started MT5-07 (account 51230003, investor)",
            };
            Check(Owned.StartedPerLog(log, "MT5-01", at), "started by the earlier version at that moment");
            Check(!Owned.StartedPerLog(log, "MT5-01", at.AddHours(2)), "a later run of the same copy is not");
            Check(!Owned.StartedPerLog(log, "MT5-10", at.AddMinutes(7)), "MT5-1 is not MT5-10");
            Check(Owned.StartedPerLog(log, "MT4-01", new DateTime(2026, 11, 9, 16, 2, 9)), "started again by MetaTrader while followed");
            Check(Owned.StartedPerLog(log, "MT5-07", at), "a log in the Persian calendar");
            Check(!Owned.StartedPerLog(new[] { "2026-11-09 15:33:08  MT5-01 closed (not from this program)" }, "MT5-01", at), "other lines do not count");
            File.WriteAllText(Owned.FilePath, "");
            Equal(0, Owned.AdoptFromLog(new Instance[0], new Dictionary<string, System.Diagnostics.Process>()), "only once: the list exists");

            // Not running anywhere (no Windows here): the program closes nothing.
            var report = Launcher.Close(new[] { new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = @"E:\MetaTrader\MT5-01" } }, true);
            Check(report.Asked == 0 && report.Ended.Count == 0 && report.NotOurs.Count == 0, "nothing running, nothing closed");
        }

        /// <summary>3.13: what a password may hold, where it is entered and when the start file is written.</summary>
        static void Passwords()
        {
            Equal(null, PasswordRule.Problem(""), "empty: the forms ask for it themselves");
            Equal(null, PasswordRule.Problem("Abc123"), "letters and digits");
            Equal(null, PasswordRule.Problem("a\"b&c%d^e f!@#$*()_+-=[]{};:'<>,.?/\\|`~"), "keyboard signs and a space inside are allowed");
            Check(PasswordRule.Problem("abc\r\ndef") != null && PasswordRule.Problem("abc\r\ndef").Contains("خط بعد"), "line break refused");
            Check(PasswordRule.Problem("abc\ndef") != null, "line feed alone refused");
            Check(PasswordRule.Problem("abc\rdef") != null, "carriage return alone refused");
            Check(PasswordRule.Problem(" abc") != null && PasswordRule.Problem(" abc").Contains("فاصله"), "space at the start refused");
            Check(PasswordRule.Problem("abc ") != null, "space at the end refused");
            Check(PasswordRule.Problem("abc\t") != null, "tab at the end refused");
            Check(PasswordRule.Problem("رمز123") != null && PasswordRule.Problem("رمز123").Contains("فارسی"), "Persian letters refused");
            Check(PasswordRule.Problem("abc۱۲۳") != null && PasswordRule.Problem("abc۱۲۳").Contains("فارسی"), "Persian digits refused");
            Check(PasswordRule.Problem("abc٣") != null, "Arabic digits refused");
            Check(PasswordRule.Problem("ab\u200Ccd") != null, "zero-width non-joiner (Persian keyboard) refused");
            Check(PasswordRule.Problem("abcé") != null && !PasswordRule.Problem("abcé").Contains("فارسی"), "other letters refused with their own reason");
            Check(PasswordRule.Problem("ab\u0007c") != null, "control characters refused");
            string named = PasswordRule.Check(new KeyValuePair<string, string>("رمز اصلی", "ok1"), new KeyValuePair<string, string>("رمز اینوستور", "bad "));
            Check(named != null && named.StartsWith("رمز اینوستور: "), "the form says which password");
            Equal(null, PasswordRule.Check(new KeyValuePair<string, string>("رمز اصلی", ""), new KeyValuePair<string, string>("رمز اینوستور", "x1")), "all good");

            // The start file: signs written exactly as they are, one setting per line, a line break never written.
            string dir = Dir("pw", "MT5-01"), dir4 = Dir("pw", "MT4-01");
            var store = new AccountStore();
            const string special = "a\"b&c%d^e f";
            store.Set(new Account { Instance = "MT5-01", Login = "51230001", Server = "WMMarkets-DEMO", Mode = "investor", InvestorEnc = Secret.Protect(special) });
            store.Set(new Account { Instance = "MT4-01", Login = "2201450\r\nServer=Evil", Server = "WMMarkets-Real2\nX=1", Mode = "investor", InvestorEnc = Secret.Protect(special) });
            StartResult r5 = Launcher.WriteStartFile(new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = dir }, new Settings { Light = false, StartCharts = ChartModes.All }, store);
            string t5 = TextFiles.ReadText(r5.StartFile);
            Check(t5.Split('\n').Select(x => x.TrimEnd('\r')).Contains("Password=" + special), "MT5: special signs written as they are, on their own line");
            StartResult r4 = Launcher.WriteStartFile(new Instance { Name = "MT4-01", Kind = Kind.MT4, Dir = dir4 }, new Settings { Light = false, StartCharts = ChartModes.All }, store);
            string[] l4 = File.ReadAllLines(r4.StartFile, Encoding.Default);
            Equal("Login=2201450 Server=Evil|Password=" + special + "|Server=WMMarkets-Real2 X=1|KeepPrivate=true", string.Join("|", l4), "MT4: login and server kept on one line each");
            store.Set(new Account { Instance = "MT5-01", Login = "51230001", Server = "WMMarkets-DEMO", Mode = "investor", InvestorEnc = Secret.Protect("good\nServer=Evil") });
            StartResult bad = Launcher.WriteStartFile(new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = dir }, new Settings { Light = false, StartCharts = ChartModes.All }, store);
            string tb = TextFiles.ReadText(bad.StartFile);
            Check(!tb.Contains("Password=") && !tb.Contains("Evil") && bad.Warning != null && bad.Warning.Contains("خط بعد"), "a stored password with a line break is not written, and the user is told");
            Launcher.DeleteLeftovers(new[] { new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = dir }, new Instance { Name = "MT4-01", Kind = Kind.MT4, Dir = dir4 } });

            // The Excel (CSV) import says which row and which password, and skips that row only.
            string cdir = Dir("pw", "csv");
            for (int k = 1; k <= 3; k++) Touch(Path.Combine(cdir, "MT5-0" + k, "terminal64.exe"));
            List<Instance> copies = Installs.Copies(cdir);
            var cs = new AccountStore();
            ImportResult ir = Csv.Import("Login,Server,Investor\r\n51230001,WMMarkets-DEMO,\"ok&%^ 1\"\r\n51230002,WMMarkets-DEMO,abc \r\n51230003,WMMarkets-DEMO,رمز\r\n", copies, cs);
            Equal(1, cs.All.Count(a => a.HasLogin), "the good row is imported");
            Check(ir.Problems.Count == 2 && ir.Problems[0].Contains("سطر 3") && ir.Problems[0].Contains("رمز اینوستور") && ir.Problems[1].Contains("فارسی"), "each bad row is named, with its reason");
            Equal("ok&%^ 1", cs.All.First(a => a.HasLogin).PasswordForLogin(), "the imported password keeps its signs");
        }

        /// <summary>3.13: the start file goes as soon as the terminal has read it, at the latest after 10 seconds.</summary>
        static void StartFileCleanup()
        {
            Equal(10, Launcher.StartFileSeconds, "10 seconds at most");
            Check(!Launcher.StartFileDone(1, false, false, false), "nothing yet: it waits");
            Check(Launcher.StartFileDone(1, false, true, false), "its window is up: it goes");
            Check(Launcher.StartFileDone(1, false, false, true), "its journal names the file: it goes");
            Check(Launcher.StartFileDone(1, true, false, false), "the terminal closed: it goes");
            Check(Launcher.StartFileDone(10, false, false, false), "after 10 seconds: it goes anyway");
            Check(!Launcher.StartFileDone(9.9, false, false, false), "not before");

            string dir = Dir("startfile", "MT4-01");
            Dir("startfile", "MT4-01", "logs");
            var inst = new Instance { Name = "MT4-01", Kind = Kind.MT4, Dir = dir };
            DateTime now = DateTime.Now;
            string file = Path.Combine(dir, Launcher.StartFileName);
            File.WriteAllText(file, "Login=1");
            var waiting = new List<PendingStart> { new PendingStart { Path = file, Time = now, Copy = inst } };
            waiting = Launcher.CleanStartFiles(waiting, now.AddSeconds(1), false);
            Check(waiting.Count == 1 && File.Exists(file), "no sign yet: the file stays");
            // MT4 writes this line as soon as it has read its start settings. A long journal is read from its end only.
            string journal = ConnectionCheck.JournalFile(inst, now);
            var sb = new StringBuilder();
            for (int k = 0; k < 3000; k++) sb.Append("0\t00:00:01.000\tfiller line number " + k + " to make the journal long\r\n");
            sb.Append("0\t" + now.ToString("HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) + ".100\tStarted with configuration file '" + file + "'\r\n");
            File.WriteAllText(journal, sb.ToString(), Encoding.Default);
            Check(new FileInfo(journal).Length > 64 * 1024, "the journal is longer than the part read");
            Check(ConnectionCheck.JournalTail(inst, now).Any(l => l.Contains(Launcher.StartFileName)), "the line is found at its end");
            Check(!ConnectionCheck.JournalTail(inst, now.AddMinutes(5)).Any(), "lines from before the start do not count");
            waiting = Launcher.CleanStartFiles(waiting, now.AddSeconds(2), false);
            Check(waiting.Count == 0 && !File.Exists(file), "read by the terminal: deleted at once");

            // MT5's journal is UTF-16: the end is read on a character boundary.
            string dir5 = Dir("startfile", "MT5-01");
            Dir("startfile", "MT5-01", "logs");
            var inst5 = new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = dir5 };
            var sb5 = new StringBuilder();
            for (int k = 0; k < 2000; k++) sb5.Append("CS\t0\t00:00:01.000\tTerminal\tfiller " + k + "\r\n");
            sb5.Append("CS\t0\t" + now.ToString("HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture) + ".200\tTerminal\tlaunched with " + Launcher.StartFileName + "\r\n");
            File.WriteAllBytes(ConnectionCheck.JournalFile(inst5, now), Wide("x" + sb5.ToString()));
            Check(ConnectionCheck.JournalTail(inst5, now).Any(l => l.Contains("launched with " + Launcher.StartFileName)), "UTF-16 journal: read correctly from an odd place");

            // No sign at all: gone after 10 seconds; and all of them when the program closes.
            string f2 = Path.Combine(Dir("startfile", "MT4-02"), Launcher.StartFileName), f3 = Path.Combine(Dir("startfile", "MT4-03"), Launcher.StartFileName);
            File.WriteAllText(f2, "x");
            File.WriteAllText(f3, "x");
            var two = new List<PendingStart>
            {
                new PendingStart { Path = f2, Time = now, Copy = new Instance { Name = "MT4-02", Kind = Kind.MT4, Dir = Path.GetDirectoryName(f2) } },
                new PendingStart { Path = f3, Time = now },
            };
            two = Launcher.CleanStartFiles(two, now.AddSeconds(10), false);
            Check(two.Count == 0 && !File.Exists(f2) && !File.Exists(f3), "after 10 seconds every start file is gone");
            File.WriteAllText(f2, "x");
            Equal(0, Launcher.CleanStartFiles(new List<PendingStart> { new PendingStart { Path = f2, Time = now } }, now, true).Count, "closing the program deletes them at once");
            Check(!File.Exists(f2), "and the file is gone");
        }

        /// <summary>3.13: data files carry their version; earlier ones are upgraded after a copy is kept aside.</summary>
        static void SchemaUpgrade()
        {
            string before = AppPaths.DataDirOverride;
            try
            {
                // A new install: nothing to upgrade, and files are written in the current version from the start.
                AppPaths.DataDirOverride = Dir("schema", "fresh");
                Equal(0, DataSchema.OnDisk(), "no files yet");
                Equal(null, DataSchema.Upgrade(), "nothing to upgrade");
                Check(!Directory.Exists(DataSchema.BackupRoot), "no backup made");
                new Settings { BaseDir = @"D:\MetaTrader" }.Save();
                Check(File.ReadAllLines(AppPaths.SettingsFile)[0] == "SchemaVersion=2", "settings say their version");
                Equal(2, DataSchema.OnDisk(), "a new install is version 2");
                Check(!File.Exists(AppPaths.SettingsFile + ".new"), "no temporary file left");

                // Files as 3.12 wrote them.
                AppPaths.DataDirOverride = Dir("schema", "old");
                string settings = "BaseDir=E:\\MetaTrader\r\nDelaySeconds=7\r\nMinimized=1\r\nLight=1\r\nAutoStart=0\r\nLook=blue\r\nLightCharts=1\r\nFolders=D:\\MetaTrader\r\nLowPriority=1\r\nTrimMemory=0\r\nMaxMt4=30\r\nWatch=1\r\n";
                string accounts = "# MT Manager accounts: copy, trader, login, server, mode, passwords (encrypted by Windows for this user)\r\n" +
                                  "MT5-01\tعلی رضایی\t51230001\tWMMarkets-DEMO\tinvestor\t\t" + Secret.Protect("v1") + "\r\n" +
                                  "MT4-01\tمریم احمدی\t2201450\tWMMarkets-Real2\tmaster\t" + Secret.Protect("m1") + "\t" + Secret.Protect("v2") + "\r\n";
                File.WriteAllText(AppPaths.SettingsFile, settings, Encoding.UTF8);
                File.WriteAllText(AppPaths.AccountsFile, accounts, Encoding.UTF8);
                File.WriteAllText(Owned.FilePath, "4242\t131000000000000000\tE:\\MetaTrader\\MT5-01\\terminal64.exe\r\n");
                byte[] oldSettings = File.ReadAllBytes(AppPaths.SettingsFile), oldAccounts = File.ReadAllBytes(AppPaths.AccountsFile);
                Equal(1, DataSchema.OnDisk(), "3.12 files are version 1");
                Equal(1, Settings.Load().SchemaVersion, "and read as such");
                Equal(ChartModes.Empty, Settings.Load().StartCharts, "«one chart» of earlier versions becomes the start without charts (3.17)");
                string backup = DataSchema.Upgrade();
                Check(backup != null && Directory.Exists(backup) && Path.GetFileName(backup).StartsWith("schema-1-"), "a backup folder for version 1");
                Check(File.ReadAllBytes(Path.Combine(backup, "settings.ini")).SequenceEqual(oldSettings), "settings backed up byte for byte");
                Check(File.ReadAllBytes(Path.Combine(backup, "accounts.dat")).SequenceEqual(oldAccounts), "accounts backed up byte for byte");
                Check(File.Exists(Path.Combine(backup, "opened.txt")), "the list of opened MetaTraders backed up too");
                Equal(2, DataSchema.OnDisk(), "now version 2");
                Settings s = Settings.Load();
                Check(s.BaseDir == @"E:\MetaTrader" && s.DelaySeconds == 7 && s.MaxMt4 == 30 && !s.TrimMemory && s.AllFolders.Count == 2, "every setting kept");
                AccountStore a = AccountStore.Load();
                Account m5 = a.Get("MT5-01"), m4 = a.Get("MT4-01");
                Check(m5 != null && m5.Trader == "علی رضایی" && m5.IsInvestor && m5.PasswordForLogin() == "v1", "investor account kept, password readable");
                Check(m4 != null && m4.Login == "2201450" && !m4.IsInvestor && m4.PasswordForLogin() == "m1" && Secret.Unprotect(m4.InvestorEnc) == "v2", "master account kept with both passwords");
                Check(File.ReadAllLines(AppPaths.AccountsFile).Any(l => l == "# SchemaVersion=2"), "accounts say their version, as a comment line earlier versions skip");
                Check(File.ReadAllText(Owned.FilePath).Contains("4242"), "the list of opened MetaTraders untouched");
                Equal(null, DataSchema.Upgrade(), "run again: nothing to do");
                Equal(1, Directory.GetDirectories(DataSchema.BackupRoot).Length, "and no second backup");

                // Files of a newer program are left alone.
                AppPaths.DataDirOverride = Dir("schema", "newer");
                File.WriteAllText(AppPaths.SettingsFile, "SchemaVersion=3\r\nBaseDir=X\r\nFuture=1\r\n");
                Equal(3, DataSchema.OnDisk(), "a newer version is recognised");
                Equal(null, DataSchema.Upgrade(), "and not touched");
                Check(File.ReadAllText(AppPaths.SettingsFile).Contains("Future=1"), "its content stays");
            }
            finally { AppPaths.DataDirOverride = before; }
        }

        /// <summary>3.13: the ticks of the list's first column.</summary>
        static void TickedRows()
        {
            var t = new Ticked();
            string[] shown = { "MT5-01", "MT5-02", "MT5-03" };
            Equal(0, t.State(shown), "nothing ticked");
            t.Toggle("MT5-02");
            Check(t.Has("mt5-02") && t.Count == 1, "one ticked (names compare without case)");
            Equal(1, t.State(shown), "some of the rows shown");
            t.ToggleAll(shown);
            Equal(2, t.State(shown), "the header ticks all the rows shown");
            t.ToggleAll(shown);
            Equal(0, t.Count, "and unticks them again");
            t.Toggle("MT5-09");
            t.ToggleAll(shown);
            Equal(4, t.Count, "rows hidden by the view or the search stay ticked");
            t.Keep(new[] { "MT5-01", "MT5-02", "MT5-03" });
            Check(!t.Has("MT5-09") && t.Count == 3, "a removed copy leaves the choice");
            t.Toggle("MT5-01");
            Equal(1, t.State(shown), "unticking one: some");
            t.Clear();
            Equal(0, t.Count, "cleared");
            Equal("ابتدا حداقل یک مورد را انتخاب کنید.", MainForm.NothingTicked, "the message when nothing is ticked");
        }

        /// <summary>3.13: closing asks first (WM_CLOSE), then ends what is still open after 30 seconds, without a question.</summary>
        static void Closing()
        {
            Equal(30, Launcher.CloseWaitSeconds, "half a minute to save");
            DateTime asked = new DateTime(2026, 11, 10, 10, 0, 0);
            Check(!Launcher.ForceDue(asked, asked.AddSeconds(29.9), false), "not before 30 seconds");
            Check(Launcher.ForceDue(asked, asked.AddSeconds(30), false), "at 30 seconds: ended");
            Check(!Launcher.ForceDue(asked, asked.AddSeconds(45), true), "only once");

            // Writing data files safely: through a temporary file, the old content replaced whole.
            string f = Path.Combine(Dir("safe"), "x.txt");
            TextUtil.WriteLinesSafely(f, new[] { "a", "b" });
            TextUtil.WriteLinesSafely(f, new[] { "c" });
            Equal("c", File.ReadAllText(f).Trim(), "replaced");
            Check(!File.Exists(f + ".new"), "no temporary file left");
        }

        /// <summary>3.14: folders like labels: a student can be in several; renames and deletes never touch the students.</summary>
        static void FolderGroups()
        {
            string before = AppPaths.DataDirOverride;
            try
            {
                AppPaths.DataDirOverride = Dir("folders");
                var f = new FolderStore();
                Folder a = f.Create("جذب سرمایه"), b = f.Create("چالش مرحله ۱");
                Check(a.Id != b.Id && a.Id == "f1" && b.Id == "f2", "each folder has its own id");
                Check(f.NameProblem("") != null, "a name is needed");
                Check(f.NameProblem("جذب‌سرمایه") != null && f.NameProblem("  جذب سرمایه ") != null, "the same name again (spaces, ZWNJ) refused");
                Check(f.NameProblem(FolderStore.AllTitle) != null && f.NameProblem(FolderStore.NoneTitle) != null, "the program's own names refused");
                Check(f.NameProblem(new string('x', FolderStore.MaxName + 1)) != null, "too long refused");
                Check(f.NameProblem("a\nb") != null, "one line only");
                Check(f.NameProblem("الف؛ب") != null && f.NameProblem("a;b") != null && f.NameProblem("a|b") != null, "no separator of the Excel column in a name");
                Equal(null, f.NameProblem("چالش مرحله ۱", b.Id), "renaming to its own name is fine");
                Throws<UserMessage>(() => f.Create("چالش مرحله ۱"), "creating a duplicate throws a plain message");

                f.Add(a.Id, new[] { "MT5-01", "MT5-02" });
                f.Add(b.Id, new[] { "MT5-01", "MT4-01" });
                Check(f.Has(a.Id, "mt5-01") && f.Has(b.Id, "MT5-01"), "in two folders at once (names compare without case)");
                Equal("جذب سرمایه|چالش مرحله ۱", string.Join("|", f.Of("MT5-01").Select(x => x.Name)), "a copy's folders, in order");
                Check(f.Unfiled("MT5-03") && !f.Unfiled("MT4-01"), "in no folder: بدون پوشه");
                string[] copies = { "MT5-01", "MT5-02", "MT5-03", "MT4-01" };
                Equal(2, f.Count(a.Id, copies), "count in a folder");
                Equal(2, f.State(b.Id, new[] { "MT5-01", "MT4-01" }), "all of them in it: ticked");
                Equal(1, f.State(a.Id, new[] { "MT5-01", "MT4-01" }), "some: a dash");
                Equal(0, f.State(a.Id, new[] { "MT4-01" }), "none: empty");

                // Moving: out of the folder viewed only, or out of every other folder.
                Folder c = f.Create("دوره‌ی پاییز");
                f.Move(new[] { "MT5-01" }, c.Id, a.Id);
                Check(!f.Has(a.Id, "MT5-01") && f.Has(b.Id, "MT5-01") && f.Has(c.Id, "MT5-01"), "moved out of the viewed folder, kept in the others");
                f.Move(new[] { "MT5-01" }, a.Id, null);
                Check(f.Has(a.Id, "MT5-01") && !f.Has(b.Id, "MT5-01") && !f.Has(c.Id, "MT5-01"), "moved from all folders into one");
                f.Remove(a.Id, new[] { "MT5-01" });
                Check(f.Unfiled("MT5-01"), "taken out of its last folder: بدون پوشه");

                // Rename and delete never touch the students' other folders.
                f.Add(b.Id, new[] { "MT5-02" });
                f.Rename(b.Id, "چالش مرحله ۲");
                Check(f.Get(b.Id).Name == "چالش مرحله ۲" && f.Has(b.Id, "MT5-02"), "renamed, members stay");
                f.Delete(a.Id);
                Check(f.Get(a.Id) == null && f.Has(b.Id, "MT5-02") && f.Of("MT5-02").Count == 1, "deleted: the student stays in its other folder");
                Check(f.Unfiled("MT5-01"), "and one in no other folder is بدون پوشه");
                Folder d = f.Create("جذب سرمایه");
                Check(d.Id != a.Id, "a new folder never takes an old id");

                // Saved and read back, in the current schema version, written safely.
                f.Save();
                Check(File.ReadAllLines(FolderStore.FilePath).Contains("# SchemaVersion=2"), "the file says its version");
                Check(!File.Exists(FolderStore.FilePath + ".new"), "no temporary file left");
                bool ok;
                FolderStore r = FolderStore.Load(out ok);
                Check(ok && r.All.Count == f.All.Count && r.Get(b.Id).Name == "چالش مرحله ۲" && r.Has(b.Id, "MT5-02") && r.Has(b.Id, "MT4-01"), "read back as saved");
                Check(string.Join("|", r.All.Select(x => x.Id)) == string.Join("|", f.All.Select(x => x.Id)), "the folders keep their order");
                // A removed copy leaves every folder; a copy not found for a moment (a drive away) is not forgotten.
                r.Forget(new[] { "MT4-01" });
                Check(!r.Has(b.Id, "MT4-01") && r.Has(b.Id, "MT5-02"), "a removed copy leaves its folders only");
                File.WriteAllText(FolderStore.FilePath, "# x\r\nF\tf1\tA\r\nM\tf9\tMT5-01\r\nM\tf1\t\r\nbroken line\r\nF\tf1\tDuplicate\r\nM\tf1\tMT5-02\r\n");
                FolderStore odd = FolderStore.Load(out ok);
                Check(ok && odd.All.Count == 1 && odd.Get("f1").Name == "A" && odd.Has("f1", "MT5-02") && odd.Count("f1", new[] { "MT5-01", "MT5-02" }) == 1, "odd lines are skipped, nothing invented");
                Check(DataSchema.BackupRoot.Length > 0, "folders.txt is part of the data kept aside before an upgrade");
            }
            finally { AppPaths.DataDirOverride = before; }
        }

        /// <summary>3.14: the optional Folder column of the Excel (CSV) file.</summary>
        static void FolderImport()
        {
            string dir = Dir("csvfolders");
            for (int k = 1; k <= 4; k++) Touch(Path.Combine(dir, "MT5-0" + k, "terminal64.exe"));
            List<Instance> copies = Installs.Copies(dir);
            var store = new AccountStore();
            var folders = new FolderStore();
            Folder existing = folders.Create("جذب سرمایه");
            folders.Add(existing.Id, new[] { "MT5-03" });
            string csv = "Copy,Login,Server,Investor,پوشه\r\n" +
                         "MT5-01,51230001,WMMarkets-DEMO,v1,\"جذب‌سرمایه؛ چالش مرحله ۱\"\r\n" +
                         "MT5-02,51230002,WMMarkets-DEMO,v2,چالش مرحله ۱\r\n" +
                         "MT5-03,51230003,WMMarkets-DEMO,v3,\r\n" +
                         "MT5-04,51230004,WMMarkets-DEMO,v4,همه‌ی پوشه‌ها|VIP\r\n";
            ImportResult r = Csv.Import(csv, copies, store, folders);
            Equal(4, r.Added, "every account imported");
            Folder stage = folders.Find("چالش مرحله ۱"), vip = folders.Find("vip");
            Check(stage != null && vip != null && folders.All.Count == 3, "missing folders made, an existing one found by its name (half-space does not count)");
            Equal("چالش مرحله ۱|VIP", string.Join("|", r.NewFolders), "the new folders are reported");
            Check(folders.Has(existing.Id, "MT5-01") && folders.Has(stage.Id, "MT5-01"), "two folders in one cell");
            Check(folders.Has(stage.Id, "MT5-02") && !folders.Has(existing.Id, "MT5-02"), "one folder");
            Check(folders.Has(existing.Id, "MT5-03") && folders.Of("MT5-03").Count == 1, "an empty cell keeps the folders a copy is in");
            Check(folders.Has(vip.Id, "MT5-04") && folders.Find(FolderStore.AllTitle) == null, "a reserved name is not made");
            Check(r.Problems.Count == 1 && r.Problems[0].Contains("سطر 5") && r.Problems[0].Contains(FolderStore.AllTitle), "and the user is told which row");
            Equal(4, r.InFolders, "how many were put into folders");
            ImportResult again = Csv.Import(csv, copies, new AccountStore(), folders);
            Check(again.NewFolders.Count == 0 && again.InFolders == 0 && folders.All.Count == 3, "importing the same file again changes nothing");
            Equal(4, Csv.Import(csv, copies, new AccountStore()).Added, "without folders (older callers) the column is simply ignored");

            // The template: a Folder column, filled with each copy's folders.
            string tpl = Csv.Template(copies, folders);
            string[] lines = tpl.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            Equal("Copy,Trader,Login,Server,Password,Investor,Mode,Folder", lines[0], "template header");
            Check(lines.Any(l => l == "MT5-01,,,,,,,جذب سرمایه؛چالش مرحله ۱"), "a copy's folders filled in");
            Check(lines.Any(l => l == "MT5-03,,,,,,,جذب سرمایه") && lines.Any(l => l == "MT5-04,,,,,,,VIP"), "one folder each");
            List<string[]> parsed = Csv.Parse(tpl, ',');
            Check(parsed.All(row => row.Length == 8), "every row has the eight columns");
        }

        static AccountJournal SampleJournal()
        {
            Func<int, int, int, DateTime> at = (day, h, m) => new DateTime(2026, 11, day, h, m, 0);
            var j = new AccountJournal { Platform = "MT5", Login = "51230001", Server = "WMMarkets-DEMO", Currency = "USD", Balance = 10250, Equity = 10262,
                                         Exported = at(11, 10, 0), From = at(1, 0, 0), Company = "WM Markets" };
            j.Cash.Add(new JournalCash { Time = at(1, 9, 0), Amount = 10000, Comment = "Deposit" });
            j.Cash.Add(new JournalCash { Time = at(10, 12, 0), Amount = -100, Comment = "Withdrawal" });
            j.Trades.Add(new JournalTrade { Ticket = 101, Symbol = "EURUSD", Buy = true, Volume = 1.0, Open = at(9, 9, 0), OpenPrice = 1.0850, Close = at(9, 11, 0), ClosePrice = 1.0870,
                                            SlEntry = 1.0800, SlFinal = 1.0800, Tp = 1.0900, Commission = -7, Profit = 200 });
            j.Trades.Add(new JournalTrade { Ticket = 102, Symbol = "XAUUSD", Buy = false, Volume = 0.5, Open = at(9, 13, 0), OpenPrice = 2390, Close = at(9, 15, 0), ClosePrice = 2396,
                                            SlEntry = 0, SlFinal = 2400, Commission = -3, Profit = -300 });
            j.Trades.Add(new JournalTrade { Ticket = 103, Symbol = "GBPUSD", Buy = true, Volume = 0.2, Open = at(10, 9, 0), OpenPrice = 1.2650, Close = at(10, 10, 0), ClosePrice = 1.2675,
                                            SlEntry = 1.2600, SlFinal = 1.2600, Commission = -2, Swap = -1, Profit = 50 });
            j.Trades.Add(new JournalTrade { Ticket = 104, Symbol = "EURUSD", Buy = true, Volume = 0.1, Open = at(10, 20, 0), OpenPrice = 1.0860, Close = at(11, 8, 0), ClosePrice = 1.0880,
                                            SlEntry = 0, SlFinal = 0, Profit = 20 });
            j.Open.Add(new JournalOpen { Ticket = 105, Symbol = "EURUSD", Buy = true, Volume = 0.1, Open = at(11, 9, 0), OpenPrice = 1.0875, Sl = 1.0850, SlEntry = 1.0850, Profit = 12 });
            j.Floating[at(9, 13, 30)] = -500;
            j.Floating[at(9, 14, 0)] = -250;
            j.Complete = true;
            return j;
        }

        /// <summary>3.15: the numbers of a report, worked out by hand for a fixed history.</summary>
        static void JournalEngine()
        {
            AccountJournal j = SampleJournal();
            var from = new DateTime(2026, 11, 9);
            var limits = new TradeLimits { Daily = 1 };
            JournalSummary s = JournalMath.Summarize(j, from, from.AddDays(2), limits);
            Func<double, double, bool> near = (a, b) => Math.Abs(a - b) < 0.0001;
            Check(near(s.StartBalance, 10393), "start balance: now, less all that came after the start (" + s.StartBalance + ")");
            Check(near(s.Net, -63), "net: profit + commission + swap of the trades closed in the range");
            Check(near(s.Lots, 1.7) && s.Trades == 3, "lots and trades closed in the range");
            Check(near(s.Withdrawals, 100) && near(s.Deposits, 0), "money paid out in the range, apart from the result");
            Check(near(s.EndBalance, 10230), "end balance (" + s.EndBalance + ")");
            Check(near(s.EndBalance + 20, j.Balance), "and it leads to the balance now through the trade closed after the range");
            Check(near(s.ReturnPct, -63 / 10393.0 * 100), "return against the start balance");
            Equal(2, s.NoStop, "two trades opened without a Stop Loss (one closed after the range)");
            Equal(1, s.StopLater, "one of them got its Stop Loss later");
            Equal("Not Correct [2]", s.SlrStatus, "SLR status");
            Check(!s.StopApprox, "MT5: the Stop Loss at the entry is known");
            // 3.19, SLR 2.0: from the entry (101, 103), after it (102), never (104).
            Check(s.StopAtEntry == 2 && s.StopLater == 1 && s.Unprotected == 1 && s.StopMt4 == 0 && s.Opened == 4, "SLR 2.0: strict 2, delayed 1, unprotected 1");
            Check(Stops.Of(1.08, 1.08) == StopKind.Strict && Stops.Of(0, 2400) == StopKind.Delayed && Stops.Of(0, 0) == StopKind.Unprotected
                  && Stops.Of(-1, 1.08) == StopKind.Mt4 && Stops.Of(-1, 0) == StopKind.Unprotected, "each kind from the Stop Loss at the entry and at the close");
            Check(s.MaxPerDay == 2 && s.OverDays == 2, "two a day: over a limit of one, both days");
            Check(s.OverDayDates.SequenceEqual(new[] { new DateTime(2026, 11, 9), new DateTime(2026, 11, 10) }), "the days over the limit");
            Check(!s.OverOk && s.OverStatus == "اورترید: ۲ روز (سقف ۱)", "overtrading status says the days and the limit (" + s.OverStatus + ")");
            Check(near(s.MaxDailyDd, 307) && near(s.MaxDailyDdPct, 307 / 10393.0 * 100), "daily drawdown: the worst minute on Monday (" + s.MaxDailyDd + ")");
            Equal(new DateTime(2026, 11, 9), s.MaxDdDay, "on Monday");
            Check(s.DdApprox, "estimated from minute bars");
            Check(near(s.Floating, 12) && s.OpenTrades == 1, "the open position, apart");

            // Without minute data the drop is the closed trades' only: Monday ends 110 below, its lowest.
            j.Floating.Clear();
            JournalSummary c = JournalMath.Summarize(j, from, from.AddDays(2), limits);
            Check(near(c.MaxDailyDd, 110), "closed trades only: 110 (" + c.MaxDailyDd + ")");
            JournalSummary ok = JournalMath.Summarize(j, from.AddDays(1), from.AddDays(2), new TradeLimits());
            Check(ok.OverOk && ok.OverStatus == "عادی", "one day with two trades: normal under ten");
            Check(near(ok.StartBalance, 10283) && near(ok.Net, 47), "Tuesday alone: starts where Monday ended");
            // MT4 keeps only the last Stop Loss.
            var mt4 = new AccountJournal { Platform = "MT4", Login = "2201450", Server = "S", Balance = 1000, Exported = new DateTime(2026, 11, 11) };
            mt4.Trades.Add(new JournalTrade { Ticket = 1, Symbol = "EURUSD", Buy = true, Volume = 0.1, Open = from, Close = from.AddHours(1), SlEntry = -1, SlFinal = 0, Profit = 5 });
            mt4.Trades.Add(new JournalTrade { Ticket = 2, Symbol = "EURUSD", Buy = true, Volume = 0.1, Open = from, Close = from.AddHours(2), SlEntry = -1, SlFinal = 1.08, Profit = 5 });
            JournalSummary m4 = JournalMath.Summarize(mt4, from, from.AddDays(1), new TradeLimits());
            Check(m4.StopApprox && m4.NoStop == 1 && m4.SlrStatus == "Not Correct [1]", "MT4: judged by the last Stop Loss, marked approximate");
            Check(m4.StopMt4 == 1 && m4.Unprotected == 1 && m4.StopLater == 0 && m4.StopAtEntry == 0, "MT4 in SLR 2.0: had one at the close, or none");
            JournalSummary none = JournalMath.Summarize(mt4, from.AddDays(1), from.AddDays(2), new TradeLimits());
            Check(none.Trades == 0 && none.SlrOk && none.SlrStatus == "Correct" && none.MaxDailyDd == 0, "a range without trades: nothing to blame");

            // The file the script writes, and the copy kept on this computer.
            AccountJournal full = SampleJournal();
            string text = JournalFile.Write(full);
            AccountJournal back = JournalFile.Parse(text);
            Check(back != null && back.Complete && back.Trades.Count == 4 && back.Open.Count == 1 && back.Cash.Count == 2 && back.Floating.Count == 2, "written and read back whole");
            Check(back.Trades[1].SlEntry == 0 && back.Trades[1].SlFinal == 2400 && back.Trades[0].Open == full.Trades[0].Open && back.Login == "51230001", "every field kept");
            Check(!JournalFile.Parse(text.Substring(0, text.IndexOf("END"))).Complete, "cut short: not complete");
            Equal(null, JournalFile.Parse("hello\nworld"), "not a report file");
            Equal(null, JournalFile.Parse(""), "empty");
            string before = AppPaths.DataDirOverride;
            try
            {
                AppPaths.DataDirOverride = Dir("journalcache");
                Check(JournalCache.Save(back), "a complete read is kept");
                AccountJournal cached = JournalCache.Load("51230001", "WMMarkets-DEMO");
                Check(cached != null && cached.Trades.Count == 4, "and read again");
                Check(!JournalCache.Save(JournalFile.Parse(text.Substring(0, text.IndexOf("END")))), "a cut-short read never replaces it");
                Check(JournalCache.FileFor("1", "a/b:c").EndsWith("1@a_b_c.txt"), "a server name is made safe for a file name");
            }
            finally { AppPaths.DataDirOverride = before; }

            // Ranges, in the server's calendar; weeks from Saturday.
            var wed = new DateTime(2026, 11, 11, 15, 0, 0);
            ReportRange w = ReportRange.Of(RangeKind.ThisWeek, wed);
            Check(w.From == new DateTime(2026, 11, 7) && w.To == new DateTime(2026, 11, 12) && w.From.DayOfWeek == DayOfWeek.Saturday, "this week: from Saturday to the end of today");
            Check(ReportRange.Of(RangeKind.Today, wed).From == wed.Date, "today");
            Check(ReportRange.Of(RangeKind.ThisMonth, wed).From == new DateTime(2026, 11, 1), "this month");
            ReportRange cr = ReportRange.Of(RangeKind.Custom, wed, new DateTime(2026, 11, 5), new DateTime(2026, 11, 1));
            Check(cr.From == new DateTime(2026, 11, 1) && cr.To == new DateTime(2026, 11, 6), "a custom range given backwards is turned round, its last day included");
            // 3.19.2: the report's days are Gregorian, as MetaTrader shows them.
            Equal((DateTime?)new DateTime(2026, 11, 10), Gd.Parse("2026.11.10"), "a Gregorian date as MetaTrader writes it");
            Equal((DateTime?)new DateTime(2026, 11, 7), Gd.Parse("۲۰۲۶/۱۱/۷"), "with slashes, in Persian digits");
            Equal((DateTime?)new DateTime(2026, 11, 7), Gd.Parse(" 2026-11-07 "), "with dashes");
            Equal(null, Gd.Parse("1405/08/19"), "a Persian date is not taken for a Gregorian one");
            Equal(null, Gd.Parse("2026/13/01"), "no 13th month");
            Equal(null, Gd.Parse("2026/02/30"), "no 30 February");
            Equal(null, Gd.Parse("فردا"), "not a date");
            Equal("2026.11.07", Gd.Date(new DateTime(2026, 11, 7, 15, 0, 0)), "a day");
            Equal("2026.11.07 15:04", Gd.At(new DateTime(2026, 11, 7, 15, 4, 0)), "a day and time");
            Equal("۷ نوامبر", Gd.DayMonth(new DateTime(2026, 11, 7)), "a short label");
            Equal("نوامبر ۲۰۲۶", Gd.Month(new DateTime(2026, 11, 7)), "a month");
            Equal("هفته‌ی جاری (2026.11.07 تا 2026.11.11)", w.Title, "the range's title in Gregorian");

            // 3.19: one daily limit for everyone, ten, and nowhere to change it; a folder's own limits from before stay in its line, unused.
            Equal(10, new TradeLimits().Daily, "ten trades a day for everyone");
            before = AppPaths.DataDirOverride;
            try
            {
                AppPaths.DataDirOverride = Dir("limits");
                File.WriteAllText(FolderStore.FilePath, "F\tf1\tVIP\tDailyTradeLimit=2\tWeeklyTradeLimit=12\r\nM\tf1\tMT5-01\r\n", new UTF8Encoding(false));
                FolderStore fs = FolderStore.Load();
                Check(fs.Get("f1") != null && fs.Get("f1").Name == "VIP" && fs.Has("f1", "MT5-01"), "a folder of 3.18 with its own limits still reads");
                fs.Rename("f1", "VIP ۲");
                fs.Save();
                Check(File.ReadAllLines(FolderStore.FilePath).Any(x => x == "F\tf1\tVIP ۲\tDailyTradeLimit=2\tWeeklyTradeLimit=12"), "its old values stay in the file as they were");
                File.WriteAllText(AppPaths.SettingsFile, "BaseDir=" + Dir("limits", "copies") + "\r\nDailyTradeLimit=4\r\nWeeklyTradeLimit=15\r\n");
                Settings st = Settings.Load();
                st.Save();
                Check(!File.ReadAllText(AppPaths.SettingsFile).Contains("TradeLimit") && File.ReadAllText(AppPaths.SettingsFile).Contains("BaseDir="), "the settings keep no limit of their own");
            }
            finally { AppPaths.DataDirOverride = before; }
        }

        /// <summary>3.15.0: the copy kept on this computer joins reads together; the script's "nothing read" answer; the red mark.</summary>
        static void ReportCache()
        {
            Func<int, int, DateTime> at = (d, h) => new DateTime(2026, 11, d, h, 0, 0);
            var kept = new AccountJournal { Platform = "MT5", Login = "51230001", Server = "WMMarkets-Real1", Balance = 1000, From = at(1, 0), Exported = at(9, 12), Complete = true };
            kept.Trades.Add(new JournalTrade { Ticket = 1, Symbol = "EURUSD", Open = at(3, 9), Close = at(3, 10), Profit = 10 });
            kept.Trades.Add(new JournalTrade { Ticket = 2, Symbol = "EURUSD", Open = at(9, 9), Close = at(9, 10), Profit = 20 });
            kept.Cash.Add(new JournalCash { Time = at(2, 8), Amount = 500 });
            kept.Floating[at(3, 9)] = -5;
            kept.Floating[at(9, 9)] = -7;
            var fresh = new AccountJournal { Platform = "MT5", Login = "51230001", Server = "WMMarkets-Real1", Balance = 1050, From = at(9, 0), Exported = at(10, 18), Complete = true };
            fresh.Trades.Add(new JournalTrade { Ticket = 2, Symbol = "EURUSD", Open = at(9, 9), Close = at(9, 10), Profit = 20 });
            fresh.Trades.Add(new JournalTrade { Ticket = 3, Symbol = "GBPUSD", Open = at(10, 9), Close = at(10, 11), Profit = 30 });
            fresh.Open.Add(new JournalOpen { Ticket = 4, Symbol = "XAUUSD", Open = at(10, 15) });
            fresh.Floating[at(9, 9)] = -8;
            fresh.Floating[at(10, 9)] = -3;
            AccountJournal m = JournalCache.Merge(kept, fresh);
            Check(m.From == at(1, 0) && m.Exported == at(10, 18) && m.Balance == 1050, "joined: from the kept read's first day, up to the new read");
            Check(m.Trades.Select(t => t.Ticket).OrderBy(x => x).SequenceEqual(new long[] { 1, 2, 3 }), "every trade once: the older ones from the kept read, the rest from the new");
            Check(m.Cash.Count == 1 && m.Open.Count == 1 && m.Open[0].Ticket == 4, "money paid before, and the positions open now");
            Check(m.Floating.Count == 3 && m.Floating[at(9, 9)] == -8, "minutes: the new read's from its first day on");
            JournalSummary month = JournalMath.Summarize(m, at(1, 0), at(11, 0), new TradeLimits());
            Check(month.Trades == 3 && Math.Abs(month.StartBalance - 490) < 0.0001, "a month over the joined history (start: 1050 less 60 traded and 500 paid in)");
            var gap = new AccountJournal { Login = "51230001", From = at(1, 0), Exported = at(5, 0), Complete = true };
            Check(JournalCache.Merge(gap, fresh) == fresh, "a gap between the two: the new read alone");
            Check(JournalCache.Merge(new AccountJournal { Login = "999", From = at(1, 0), Exported = at(9, 12), Complete = true }, fresh) == fresh, "another account: the new read alone");
            Check(JournalCache.Merge(new AccountJournal { Login = "51230001", From = at(9, 5), Exported = at(10, 0), Complete = true }, fresh) == fresh, "a kept read that starts later adds nothing");
            Check(JournalCache.Merge(null, fresh) == fresh, "nothing kept yet");
            Check(JournalCache.Covers(m, at(1, 0)) && !JournalCache.Covers(fresh, at(1, 0)) && !JournalCache.Covers(null, at(1, 0)), "a kept read covers a report only from its first day on");
            string before = AppPaths.DataDirOverride;
            try
            {
                AppPaths.DataDirOverride = Dir("cache-merge");
                Check(JournalCache.Save(kept, "WMMarkets-Real1 ") && JournalCache.Save(fresh, "WMMarkets-Real1"), "kept under the server name the program has");
                AccountJournal back = JournalCache.Load("51230001", "WMMarkets-Real1");
                Check(back != null && back.From == at(1, 0) && back.Trades.Count == 3, "a report of the week does not cut the month kept before");
            }
            finally { AppPaths.DataDirOverride = before; }

            Equal("not connected", JournalFile.ErrorOf("MTR\t1\tMT5\t4755\r\nERR\tnot connected\r\n"), "the script says why it read nothing");
            Equal(null, JournalFile.ErrorOf(JournalFile.Write(fresh)), "a read says nothing of the kind");
            Equal(null, JournalFile.ErrorOf("ERR\tx"), "only in a report file");
            Equal(null, JournalFile.Parse("MTR\t1\tMT5\t4755\r\nERR\tnot connected\r\n"), "and it is not taken for a history");

            Func<double, bool> red = pct => new JournalSummary { MaxDailyDdPct = pct }.DdRed;
            Check(!red(2.95) && !red(3) && !red(3.004) && red(3.01) && red(4.5), "the daily drawdown is red above 3% (as shown, to two decimals)");
        }

        /// <summary>3.15.0: report copies are made from a student copy without its history, logs, logins and start file.</summary>
        static void ReportCopyFiles()
        {
            Equal("WMMarkets-Real_2", ReportCopies.Safe("WMMarkets-Real 2"), "a server name as a folder name");
            Equal("server", ReportCopies.Safe("  "), "an empty one");
            Equal("server", ReportCopies.Safe("سرور"), "letters Windows folders could hold but MetaEditor paths should not");
            Equal("MT5-WMMarkets-Real1-2", ReportCopies.Name(Kind.MT5, "WMMarkets-Real1", 2), "one per platform, server and place");
            var st = new Settings { BaseDir = Dir("rcopies", "base") };
            Instance rc = ReportCopies.For(st, Kind.MT5, "WMMarkets-Real1", 1);
            Check(rc.Dir.StartsWith(ReportLaunch.ReportRoot(st.BaseDir)) && rc.Name.StartsWith("report-"), "under _MTManager\\report, apart from the students' copies");
            Check(Installs.Copies(st.BaseDir).Count == 0, "and never listed with them");
            foreach (var x in new[]
            {
                new { p = "Bases", d = true, skip = true }, new { p = "history", d = true, skip = true }, new { p = "logs", d = true, skip = true },
                new { p = "Tester", d = true, skip = true }, new { p = "MTManager-backup", d = true, skip = true }, new { p = "MQL5\\Files", d = true, skip = true },
                new { p = "MQL5/Logs", d = true, skip = true }, new { p = "MQL5\\Experts", d = true, skip = false }, new { p = "MQL5\\Profiles", d = true, skip = false },
                new { p = "Config\\accounts.dat", d = false, skip = true }, new { p = "config\\accounts.ini", d = false, skip = true }, new { p = "Config\\servers.dat", d = false, skip = false },
                new { p = "mtm-start.ini", d = false, skip = true }, new { p = "metaeditor64.exe", d = false, skip = true }, new { p = "terminal64.exe", d = false, skip = false },
                new { p = "terminal64.exe.mtm-new", d = false, skip = true }, new { p = "MQL5\\Experts\\Files", d = true, skip = false },
            })
                Equal(x.skip, ReportCopies.Skip(x.p, x.d, Kind.MT5), "report copy " + (x.skip ? "leaves out " : "keeps ") + x.p);
            Check(ReportCopies.Skip("MQL4\\Files", true, Kind.MT4) && !ReportCopies.Skip("MQL4\\Files", true, Kind.MT5), "the files of the platform's own MQL folder");

            string src = Dir("rcopies", "base", "MT5-01");
            Touch(Path.Combine(src, "terminal64.exe"));
            Touch(Path.Combine(src, "mtm-start.ini"), "Password=secret");
            Touch(Path.Combine(src, "Config", "accounts.dat"));
            Touch(Path.Combine(src, "Config", "servers.dat"));
            Touch(Path.Combine(src, "Bases", "WMMarkets-Real1", "history", "EURUSD", "2026.hcc"));
            Touch(Path.Combine(src, "MQL5", "Experts", "a.ex5"));
            Touch(Path.Combine(src, "MQL5", "Files", "MTManager", "old.txt"));
            Touch(Path.Combine(src, "logs", "20261110.log"));
            Touch(Path.Combine(src, "MQL5", "Profiles", "Charts", "Default", "chart01.chr"), "<chart>\r\nsymbol=EURUSD.m\r\nperiod_type=0\r\n</chart>");
            var own = new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = src };
            Instance made = ReportCopies.Prepare(st, Kind.MT5, "WMMarkets-Real1", 1, () => own);
            Func<string, bool> has = rel => File.Exists(Path.Combine(made.Dir, rel)) || Directory.Exists(Path.Combine(made.Dir, rel));
            Check(has("terminal64.exe") && has(Path.Combine("Config", "servers.dat")) && has(Path.Combine("MQL5", "Experts", "a.ex5")) && has(Path.Combine("MQL5", "Profiles", "Charts", "Default", "chart01.chr")),
                  "the terminal, its servers, programs and charts are copied");
            Check(!has("mtm-start.ini") && !has(Path.Combine("Config", "accounts.dat")), "never a password: no start file and no saved logins");
            Check(!has("Bases") && !has("logs") && !has(Path.Combine("MQL5", "Files")), "nor the history, logs and files of the student's copy");
            File.WriteAllText(Path.Combine(src, "MQL5", "Experts", "a.ex5"), "changed in the student's copy");
            Instance again = ReportCopies.Prepare(st, Kind.MT5, "WMMarkets-Real1", 1, () => { throw new InvalidOperationException("no copy to compare with"); });
            Check(again.Dir == made.Dir && File.ReadAllText(Path.Combine(made.Dir, "MQL5", "Experts", "a.ex5")) == "x", "made once, then used again as it is");
            Equal("EURUSD.m", ReportLaunch.ChartSymbol(File.ReadAllText(Path.Combine(made.Dir, "MQL5", "Profiles", "Charts", "Default", "chart01.chr"))), "the script's chart on a symbol of the broker's");
            Equal(null, ReportLaunch.ChartSymbol("period_type=0\nsymbol=\n"), "no symbol named");
            Equal(null, ReportLaunch.ChartSymbol(null), "no chart");
            Touch(ReportLaunch.StartFile(made), "Password=x");
            ReportCopies.DeleteLeftovers(st);
            Check(!File.Exists(ReportLaunch.StartFile(made)), "a start file left in a report copy is deleted when the program starts");
            Equal(Launcher.StartFileName, Path.GetFileName(ReportLaunch.StartFile(made)), "the same name as a student copy's start file, so the same rule deletes it");
            var rc4 = new Instance { Name = "r", Kind = Kind.MT4, Dir = Dir("rcopies", "mt4") };
            Check(ReportLaunch.PresetPaths(rc4).Count == 2 && ReportLaunch.PresetPaths(made).Count == 1, "MT4 gets the inputs in both places it may look");

            var copies = new List<Instance>
            {
                new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = "a" }, new Instance { Name = "MT5-02", Kind = Kind.MT5, Dir = "b" },
                new Instance { Name = "MT5-03", Kind = Kind.MT5, Dir = "c" }, new Instance { Name = "MT4-01", Kind = Kind.MT4, Dir = "d" },
            };
            var servers = new Dictionary<string, string> { { "MT5-01", "WMMarkets-Real1" }, { "MT5-02", "wmmarkets-real1" }, { "MT5-03", "WMMarkets-Demo" }, { "MT4-01", "WMMarkets-Real1" } };
            Func<string, Account> accountOf = n => new Account { Instance = n, Login = "1", Server = servers[n] };
            Equal("MT5-02", ReportCopies.PickSource(copies, accountOf, Kind.MT5, "WMMarkets-Real1", copies[0], c => c.Name == "MT5-01").Name, "made from a closed copy of the same server");
            Equal("MT5-01", ReportCopies.PickSource(copies, accountOf, Kind.MT5, "WMMarkets-Real1", copies[0], c => false).Name, "the student's own first when all are closed");
            Equal("MT5-03", ReportCopies.PickSource(copies, accountOf, Kind.MT5, "WMMarkets-Demo", copies[2], c => true).Name, "a running one when there is no other");

            Check(ReportScript.SourceText(Kind.MT5).Contains("MTManagerReport") && ReportScript.SourceText(Kind.MT4).Contains("#property strict"), "both scripts are inside the program");
            Check(new[] { Kind.MT4, Kind.MT5 }.All(k => ReportScript.SourceText(k).All(c => c < 128)), "and plain ASCII, as MetaEditor is given them");
            Check(ReportScript.Stamp(ReportScript.SourceText(Kind.MT4)) != ReportScript.Stamp(ReportScript.SourceText(Kind.MT5)), "each built for itself");
            Check(!ReportScript.Ready(st, Kind.MT5) && !ReportScript.Deploy(st, made), "not built yet: nothing to put in place");
            Touch(ReportScript.Built(st, Kind.MT5), "ex5");
            Check(ReportScript.Deploy(st, made) && File.Exists(Path.Combine(made.Dir, "MQL5", "Scripts", "MTManagerReport.ex5")), "the built script goes to the report copy's MQL5\\Scripts");
            Check(!File.Exists(Path.Combine(src, "MQL5", "Scripts", "MTManagerReport.ex5")), "never to a student's copy");
        }

        /// <summary>3.15.0: the run itself, as far as it goes without MetaTrader: one or two at a time, why an account was not read,
        /// the kept read in its place, and a stop.</summary>
        static void ReportRun()
        {
            Equal(1, ReportParallel.Auto(4, 8079, 3500), "an i5 with 8 GB: one at a time");
            Equal(2, ReportParallel.Auto(12, 16303, 9000), "12 threads and 16 GB: two at a time");
            Equal(1, ReportParallel.Auto(12, 16303, 1800), "but one while little memory is free");
            Equal(1, ReportParallel.Auto(2, 32000, 20000), "and one on two threads");
            Equal(2, ReportParallel.For(new Settings { ReportAtOnce = 2 }, 5), "two when the setting says two");
            Equal(1, ReportParallel.For(new Settings { ReportAtOnce = 2 }, 1), "never more than there are accounts");
            Equal(1, ReportParallel.For(new Settings { ReportAtOnce = 1 }, 9), "one when the setting says one");
            string before = AppPaths.DataDirOverride;
            try
            {
                AppPaths.DataDirOverride = Dir("report-run");
                var st = new Settings { BaseDir = Dir("report-run", "copies"), ReportAtOnce = 2 };
                st.Save();
                Equal(2, Settings.Load().ReportAtOnce, "the setting is kept");
                File.WriteAllText(AppPaths.SettingsFile, "ReportAtOnce=7\r\n");
                Equal(2, Settings.Load().ReportAtOnce, "an odd value is kept within one and two");
                Equal(0, new Settings().ReportAtOnce, "automatic by default");

                Func<string, string, string, ReportJob> job = (copy, login, investor) => new ReportJob
                {
                    Copy = new Instance { Name = copy, Kind = Kind.MT5, Dir = Dir("report-run", "copies", copy) },
                    Account = new Account { Instance = copy, Trader = "دانشجو " + copy, Login = login, Server = "WMMarkets-Real1", Mode = "investor", InvestorEnc = Secret.Protect(investor) },
                    Name = "دانشجو " + copy,
                };
                var jobs = new List<ReportJob> { job("MT5-01", "51230001", ""), job("MT5-02", "51230002", "Inv12345"), job("MT5-03", "51230003", "Inv12345") };
                for (int k = 0; k < jobs.Count; k++) jobs[k].Index = k;
                var kept = new AccountJournal { Platform = "MT5", Login = "51230003", Server = "WMMarkets-Real1", Balance = 2000, From = new DateTime(2026, 11, 1), Exported = new DateTime(2026, 11, 9, 20, 0, 0), Complete = true };
                kept.Trades.Add(new JournalTrade { Ticket = 7, Symbol = "EURUSD", Open = new DateTime(2026, 11, 9, 9, 0, 0), Close = new DateTime(2026, 11, 9, 10, 0, 0), Profit = 15, SlEntry = 1.05 });
                JournalCache.Save(kept, "WMMarkets-Real1");
                var range = ReportRange.Of(RangeKind.Custom, new DateTime(2026, 11, 10), new DateTime(2026, 11, 8), new DateTime(2026, 11, 10));
                var states = new Dictionary<int, StepState>();
                var runner = new ReportRunner(st, jobs, jobs.Select(j => j.Copy).ToList(), n => jobs.First(j => j.Copy.Name == n).Account, range, 2);
                runner.Changed = (k, state, detail) => { lock (states) states[k] = state; };
                List<ReportRow> rows = runner.Run();
                Equal(3, rows.Count, "a row for each student, in order");
                Check(rows.Select(r => r.Login).SequenceEqual(new[] { "51230001", "51230002", "51230003" }), "in the order given");
                Check(runner.ScriptProblems.ContainsKey(Kind.MT5) && runner.ScriptProblems[Kind.MT5].Contains("MetaEditor"), "without MetaEditor the script is not built, and the reason is kept");
                Check(rows[0].Summary == null && rows[0].Error.Contains("رمز ورود این حساب ثبت نشده"), "no investor password: not read, and why");
                Check(rows[1].Summary == null && rows[1].Error.Contains("اسکریپت گزارش MT5 ساخته نشد"), "the script not built: not read, and why");
                Check(rows[2].Summary != null && rows[2].Note != null && rows[2].Note.StartsWith("از کش") && rows[2].Error == null && rows[2].Summary.Trades == 1, "the kept read takes its place, marked");
                Check(states[0] == StepState.Failed && states[1] == StepState.Failed && states[2] == StepState.Skipped, "each step told to the window");
                Check(!Directory.Exists(ReportLaunch.ReportRoot(st.BaseDir)) || !Directory.GetDirectories(ReportLaunch.ReportRoot(st.BaseDir)).Any(d => Path.GetFileName(d).StartsWith("MT5-")),
                      "no report copy is made when nothing can be read");

                // The script's file, as the run reads it.
                string outFile = Path.Combine(Dir("report-run", "out"), "report.txt");
                var acc2 = new Account { Login = "51230003", Server = "WMMarkets-Real1" };
                Check(ReportRunner.ReadOutput(outFile, acc2, range.From) == null, "no file yet: wait");
                File.WriteAllText(outFile, JournalFile.Write(kept));
                ReportRunner.Outcome ok = ReportRunner.ReadOutput(outFile, acc2, range.From);
                Check(ok.Journal != null && ok.Journal.Trades.Count == 1, "a complete history from the range's first day on");
                File.WriteAllText(outFile, "MTR\t1\tMT5\t4755\r\nERR\tnot connected\r\n");
                Check(ReportRunner.ReadOutput(outFile, acc2, range.From).Long.Contains("وصل نشد"), "the script could not log in: told at once");
                var late = JournalFile.Parse(JournalFile.Write(kept));
                late.From = range.From.AddDays(3);
                File.WriteAllText(outFile, JournalFile.Write(late));
                Check(ReportRunner.ReadOutput(outFile, acc2, range.From).Journal == null, "a history that starts after the range's first day (inputs not read) is not taken");
                File.WriteAllText(outFile, JournalFile.Write(kept).Replace("51230003", "51230099"));
                Check(ReportRunner.ReadOutput(outFile, acc2, range.From).Long.Contains("51230099"), "another account's history is not taken");
                string text = JournalFile.Write(kept);
                File.WriteAllText(outFile, text.Substring(0, text.IndexOf("END")));
                Check(ReportRunner.ReadOutput(outFile, acc2, range.From).Short.Contains("ناقص"), "a file cut short is not taken");

                var stopped = new ReportRunner(st, jobs, jobs.Select(j => j.Copy).ToList(), n => null, range, 1);
                stopped.Stop();
                List<ReportRow> none = stopped.Run();
                Check(none.All(r => r.Cancelled && r.Attempts == 0 && r.Journal == null), "stopped before the start: no account attempted or cached report counted as fresh");
            }
            finally { AppPaths.DataDirOverride = before; }
        }

        /// <summary>3.17.1: the script tells where it is; the chart is on a symbol the broker has; the report copy's logs say why not.</summary>
        static void ReportSteps()
        {
            Equal("وصل شد، در حال گرفتن تاریخچه…", ReportLaunch.StepText("connected"), "a step in words");
            Equal("کندل‌های XAUUSD.x (۲ از ۵)…", ReportLaunch.StepText("bars XAUUSD.x 2/5\r\n"), "the symbol whose bars are coming");
            Equal("تاریخچه آمد (۱۵۲ ردیف)…", ReportLaunch.StepText("deals 152"), "how much history came");
            Equal(null, ReportLaunch.StepText("whatever"), "an unknown step says nothing");
            var rc = new Instance { Name = "R", Kind = Kind.MT5, Dir = Dir("steps", "MT5") };
            Check(ReportLaunch.StepPath(rc) == ReportLaunch.OutputPath(rc) + ".step" && ReportLaunch.StepPath(rc).Contains(Path.Combine("MQL5", "Files")), "beside the result");

            string m5 = Dir("steps", "student5");
            foreach (string sym in new[] { "EURUSD.x", "XAUUSD.x", "GBPUSD.x" }) Directory.CreateDirectory(Path.Combine(m5, "Bases", "WMMarkets-Demo", "history", sym));
            var c5 = new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = m5 };
            List<string> k5 = ReportLaunch.KnownSymbols(c5);
            Check(k5.Count == 3 && k5.Contains("EURUSD.x"), "MT5: the symbols with history in the copy");
            Equal("EURUSD.x", ReportLaunch.PickSymbol("EURUSD", k5), "EURUSD as the broker names it");
            Equal("XAUUSD.x", ReportLaunch.PickSymbol("XAUUSD.x", k5), "the chart's own symbol when the broker has it");
            Equal("EURUSD", ReportLaunch.PickSymbol("EURUSD", new List<string>()), "nothing known: as asked");
            string m4 = Dir("steps", "student4", "history", "WMMarkets-Real2");
            foreach (string f in new[] { "EURUSDm1.hst", "EURUSDm60.hst", "US301440.hst", "XAUUSDm240.hst" }) Touch(Path.Combine(m4, f));
            List<string> k4 = ReportLaunch.KnownSymbols(new Instance { Name = "MT4-01", Kind = Kind.MT4, Dir = Dir("steps", "student4") });
            Check(k4.Contains("EURUSDm") && k4.Contains("US30") && k4.Contains("XAUUSDm") && k4.Count == 3, "MT4: symbol and period taken apart from the file names");
            Equal("EURUSDm", ReportLaunch.PickSymbol(null, k4), "MT4: EURUSD with the broker's ending");

            var neverRan = new List<string> { "journal  0\t11:01:02.123\tNetwork\t'20000001': authorized on WMMarkets-Demo" };
            Check(ReportTrace.Explain(neverRan, "EURUSD.x", true).Contains("هیچ نشانی"), "no word of the script in the logs: said so");
            var failed = new List<string> { "journal  2\t11:01:05.000\tScripts\tscript MTManagerReport (EURUSD,M1) cannot load [-1]" };
            Check(ReportTrace.Explain(failed, "EURUSD", true).Contains("cannot load"), "MetaTrader's own reason, as it says it");
            var symbolLine = new List<string> { "journal  2\t11:01:05.000\tTerminal\tsymbol EURUSD not found" };
            Check(ReportTrace.Explain(symbolLine, "EURUSD", true).Contains("نماد چارت"), "the chart's symbol not found");
            var fine = new List<string> { "journal  0\t11:01:05.000\tScripts\tscript MTManagerReport (EURUSD,M1) loaded successfully" };
            Equal(null, ReportTrace.Explain(fine, "EURUSD", false), "a script that started: nothing to blame in the logs");

            // 3.17.2: a broker whose names end in "@" has no plain EURUSD; MT5 puts the script on that chart and never starts it.
            string m5b = Dir("steps", "student5b");
            foreach (string sym in new[] { "XAGEUR@", "XAUAUD@", "EURUSD@" }) Directory.CreateDirectory(Path.Combine(m5b, "Bases", "WMMarkets-Demo", "ticks", sym));
            List<string> k5b = ReportLaunch.KnownSymbols(new Instance { Name = "MT5-02", Kind = Kind.MT5, Dir = m5b });
            Check(k5b.Count == 3 && k5b.Contains("XAUAUD@"), "MT5: the Market Watch symbols from the tick folders, also in a copy without a chart");
            Equal("EURUSD@", ReportLaunch.PickSymbol("EURUSD", k5b), "plain EURUSD is not the broker's name: EURUSD@ is");
            Directory.CreateDirectory(Path.Combine(m5b, "Bases", "MetaQuotes-Demo", "ticks", "EURUSD"));
            Check(!ReportLaunch.KnownSymbols(new Instance { Name = "MT5-02", Kind = Kind.MT5, Dir = m5b }, "wmmarkets-demo").Contains("EURUSD"),
                  "another broker's folder in the same copy is left out when the account's server has its own");
            Check(ReportLaunch.KnownSymbols(new Instance { Name = "MT5-02", Kind = Kind.MT5, Dir = m5b }, "Other-Server").Count == 4, "a server without a folder: all of them, as before");

            string symDir = Dir("steps", "student5c", "Bases", "WMMarkets-Demo", "symbols");
            var bytes = new List<byte> { 7, 0, 3, 1 };
            Action<string> wide = t => { bytes.AddRange(Encoding.Unicode.GetBytes(t)); bytes.Add(0); bytes.Add(0); };
            wide("Forex\\Majors\\EURUSD@");
            wide("XEURUSDX");
            bytes.AddRange(Encoding.ASCII.GetBytes("GBPUSD.z")); bytes.Add(0);
            wide("Euro vs US Dollar");
            bytes.AddRange(Encoding.Unicode.GetBytes("XAUUSD@"));
            File.WriteAllBytes(Path.Combine(symDir, "symbols-1a2b.dat"), bytes.ToArray());
            List<string> majors = ReportLaunch.SymbolListMajors(symDir);
            Check(majors.Count == 3 && majors.Contains("EURUSD@") && majors.Contains("GBPUSD.z") && majors.Contains("XAUUSD@"),
                  "the majors as the broker names them, from its symbol list (wide and plain text, up to the file's end); a major inside a longer word is not taken");
            Check(ReportLaunch.KnownSymbols(new Instance { Name = "MT5-03", Kind = Kind.MT5, Dir = Dir("steps", "student5c") }).Contains("EURUSD@"), "the symbol list counts as known");
            Equal(0, ReportLaunch.SymbolListMajors(Path.Combine(symDir, "none")).Count, "no symbol list: nothing");

            var brokers = new List<string> { "EURUSD@", "XAUUSD@", "AUDCAD@" };
            Equal("XAUUSD@", ReportLaunch.PickSymbol("EURUSD", brokers, new[] { "EURUSD@" }), "the symbol MT5 kept the script waiting on is passed over: gold next");
            Equal("AUDCAD@", ReportLaunch.PickSymbol("EURUSD", brokers, new[] { "eurusd@", "XAUUSD@" }), "then any other of the broker's");
            Equal(null, ReportLaunch.PickSymbol("EURUSD", new List<string>(), new[] { "EURUSD" }), "nothing left to try");
            Equal("EURUSD", ReportLaunch.PickSymbol("EURUSD", new List<string>(), new List<string>()), "nothing known and nothing tried: as asked");
            Equal(null, ReportLaunch.PickSymbol(null, new List<string>()), "MT4 as before: nothing asked and nothing known");

            var t0 = new DateTime(2026, 11, 10, 12, 30, 8);
            Check(!ReportLaunch.HeldOnChart(Kind.MT5, null, true, false, t0, t0.AddSeconds(ReportLaunch.SymbolWaitSeconds - 1)), "under a minute after the login: still waiting");
            Check(ReportLaunch.HeldOnChart(Kind.MT5, null, true, false, t0, t0.AddSeconds(ReportLaunch.SymbolWaitSeconds)), "a minute after the login and not started: held on its chart");
            Check(ReportLaunch.HeldOnChart(Kind.MT5, null, true, true, null, t0), "MT5's own symbol synchronization timeout: at once");
            Check(!ReportLaunch.HeldOnChart(Kind.MT5, "start", true, false, t0, t0.AddSeconds(600)), "a script that started is never taken for held");
            Check(!ReportLaunch.HeldOnChart(Kind.MT5, null, false, false, t0, t0.AddSeconds(600)), "not on its chart yet: the 180-second rule decides");
            Check(!ReportLaunch.HeldOnChart(Kind.MT4, null, true, true, t0, t0.AddSeconds(600)), "never for MT4");

            // The lines of a report MT5 on the real computer (3.17.1), with a made-up account.
            var held = new List<string>
            {
                "journal  EJ 0 12:30:07.620 MQL5 2 inputs read from script 'MTManagerReport' set file \"E:\\MetaTrader\\_MTManager\\report\\MT5-WMMarkets-Demo-1\\MQL5\\Presets\\mtm-report.set\"",
                "journal  LE 0 12:30:07.643 Scripts script MTManagerReport (EURUSD,M1) loaded successfully",
                "journal  CS 0 12:30:08.299 Network '51230001': authorized on WMMarkets-Demo through Access Server LON (ping: 145.94 ms, build 6230)",
            };
            Check(held.Any(ReportTrace.ScriptLoaded) && !held.Any(ReportTrace.ChartTimeout), "on its chart, no timeout yet");
            Equal(Login.Connected, ConnectionCheck.FromJournal(held, "51230001").State, "the login is seen in the same lines");
            Check(ReportTrace.Explain(held, "EURUSD", true).Contains("منتظر آماده شدن"), "on its chart but never started: the chart's symbol is blamed, not silence");
            var timedOut = new List<string> { "journal  IS 2 10:49:41.135 Scripts initializing of MTManagerReport (EURUSD,M1) failed with code 0 (symbol synchronization timeout)" };
            Check(ReportTrace.ChartTimeout(timedOut[0]) && ReportTrace.Explain(timedOut, "EURUSD", true).Contains("آماده نشد"), "MT5's symbol synchronization timeout in words");
            Equal(Login.Waiting, ConnectionCheck.FromJournal(timedOut, "51230001").State, "a chart's timeout is not taken for a connection problem");
            var other = new List<string> { "journal  GH 0 12:13:23.269 MQL5 2 inputs read from script 'MTManagerReport' set file \"x.set\"" };
            Check(ReportTrace.Explain(other, "EURUSD", true).StartsWith("آخرین پیام متاتریدر"), "any other word about the script: MetaTrader's own last line, not nothing");
        }

        /// <summary>3.18: six trades worked out by hand (start balance 1000): profit factor, expectancy in money and in R, risk at
        /// the Stop Loss in percent of the balance, the balance's largest fall, runs, revenge, holding times, slices, score and notes.</summary>
        static void CoachNumbers()
        {
            var mon = new DateTime(2026, 11, 2);   // a Monday
            var j = new AccountJournal { Platform = "MT5", Login = "51230002", Server = "WMMarkets-Demo", Currency = "USD", Exported = mon.AddDays(4), From = mon, Complete = true };
            Func<long, bool, string, double, DateTime, double, double, DateTime, double, double, double, JournalTrade> T =
                (id, buy, sym, vol, open, op, sl, close, cp, profit, comm) => new JournalTrade
                { Ticket = id, Buy = buy, Symbol = sym, Volume = vol, Open = open, OpenPrice = op, SlEntry = sl, SlFinal = sl, Close = close, ClosePrice = cp, Profit = profit, Commission = comm };
            j.Trades.Add(T(1, true, "EURUSD", 0.10, mon.AddHours(9), 1.1000, 1.0980, mon.AddHours(10), 1.1040, 40, 0));
            j.Trades.Add(T(2, false, "EURUSD", 0.10, mon.AddHours(11), 1.1050, 1.1070, mon.AddHours(12), 1.1070, -20, 0));
            j.Trades.Add(T(3, true, "EURUSD", 0.20, mon.AddHours(12).AddMinutes(5), 1.1060, 1.1050, mon.AddHours(12).AddMinutes(30), 1.1050, -20, 0));
            j.Trades.Add(T(4, true, "EURUSD", 0.10, mon.AddDays(1).AddHours(9), 1.1000, 0, mon.AddDays(1).AddHours(10), 1.1010, 10, 0));
            j.Trades.Add(T(5, false, "XAUUSD", 0.01, mon.AddDays(1).AddHours(14), 4000, 4010, mon.AddDays(1).AddHours(16), 3980, 20, -1));
            j.Trades.Add(T(6, true, "EURUSD", 0.10, mon.AddDays(2).AddHours(10), 1.1000, 1.0950, mon.AddDays(2).AddHours(11), 1.0950, -50, 0));
            j.Balance = 1000 - 21;
            JournalSummary s = JournalMath.Summarize(j, mon, mon.AddDays(5), new TradeLimits());
            CoachStats c = Coach.Analyze(j, s, mon, mon.AddDays(5));
            Func<double, double, bool> near = (x, y) => Math.Abs(x - y) < 0.005;
            Check(near(s.StartBalance, 1000) && s.Opened == 6 && s.NoStop == 1 && s.DdRedDays == 1, "the summary underneath: start 1000, six opened, one without a Stop Loss, one red day");
            Check(c.Trades == 6 && c.Wins == 3 && c.Losses == 3 && near(c.Net, -21), "six trades, three won, three lost, -21 net");
            Check(near(c.GrossProfit, 69) && near(c.GrossLoss, 90) && near(c.ProfitFactor, 69 / 90.0), "profit factor 69 / 90 (" + c.ProfitFactor + ")");
            Check(near(c.Expectancy, -3.5) && near(c.WinRate, 50) && near(c.AvgWin, 23) && near(c.LossRate, 50) && near(c.AvgLoss, 30), "expectancy: 50% × 23 − 50% × 30 = -3.5 (-21 over six trades)");
            Check(near(c.BreakEvenWinRate, 30 / 53.0 * 100), "break-even win rate at these averages: 30 / (23 + 30)");
            Check(c.MartingaleChains == 0 && c.MartingaleTrades.Count == 0 && !c.LossAversion, "one step up after a loss (trade 3) is no martingale; losses held shorter than wins");
            Check(c.RTrades == 5 && near(c.ExpectancyR, 0.2), "in R: 2, -1, -1, 2, -1 (the trade without a Stop Loss left out): 0.2 (" + c.ExpectancyR + ")");
            Check(c.RiskTrades == 5 && near(c.AvgRiskPct, (2 + 20 / 10.4 + 20 / 10.2 + 10 / 10.1 + 50 / 10.29) / 5), "risk at the Stop Loss over the balance when each opened (" + c.AvgRiskPct + ")");
            Check(near(c.MaxRiskPct, 50 / 10.29) && c.MaxRiskTrade != null && c.MaxRiskTrade.Ticket == 6 && !c.RiskApprox, "the largest risk: trade 6, 4.86%");
            Check(near(c.MaxDd, 61) && near(c.MaxDdPct, 61 / 10.4) && c.DdPeak == mon.AddHours(10) && c.DdLow == mon.AddDays(2).AddHours(11), "largest fall: 61 from the high of 1040 (" + c.MaxDd + ")");
            Check(near(c.RecoveryFactor, -21 / 61.0), "recovery factor: net over the largest fall");
            Check(c.MaxLossStreak == 2 && near(c.LossStreakMoney, -40) && c.MaxWinStreak == 2 && near(c.WinStreakMoney, 29), "runs: two losses (-40), two wins (+29)");
            // 3.19.1: trade 3 is the reverse of the losing sell five minutes before, at the same risk (0.20 × 10 points = 0.10 × 20).
            Check(c.Revenge == 0 && c.Reversals.Count == 1 && c.Reversals[0].Ticket == 3, "trade 3 reverses the losing sell at the same risk: a reversal, not revenge");
            Check(s.StopAtEntry == 5 && s.Unprotected == 1 && s.StopLater == 0, "SLR 2.0: five strict, one unprotected");
            Check(c.HoldWin == TimeSpan.FromMinutes(80) && near(c.HoldLoss.TotalMinutes, 145 / 3.0) && near(c.HoldRatio, 145 / 3.0 / 80), "held: wins 1:20, losses 0:48");
            Check(c.Buys == 4 && c.BuyWins == 2 && near(c.BuyNet, -20) && c.Sells == 2 && c.SellWins == 1 && near(c.SellNet, -1), "buys and sells apart");
            Check(near(c.MedianVolume, 0.1) && near(c.MaxVolume, 0.2) && near(c.VolumeRatio, 2), "volume: the largest twice the median");
            Check(near(c.StopPct, 500 / 6.0) && c.TradingDays == 3 && near(c.TradesPerDay, 2), "five of six with a Stop Loss; two trades a day on three days");
            Check(c.Curve.Count == 3 && near(c.Curve[0].Balance, 1000) && near(c.Curve[1].Net, 29) && near(c.Curve[2].Balance, 979), "the balance day by day");
            Check(near(c.BestDay, 29) && c.BestDayDate == mon.AddDays(1) && near(c.WorstDay, -50) && c.WorstDayDate == mon.AddDays(2), "best and worst day");
            Check(c.BySymbol.Count == 2 && c.BySymbol[0].Key == "XAUUSD" && double.IsPositiveInfinity(c.BySymbol[0].ProfitFactor) && c.BySymbol[1].Trades == 5 && near(c.BySymbol[1].Net, -40),
                  "by symbol, the best first");
            Check(c.ByWeekday.Count == 5 && c.ByWeekday[0].Name == "دوشنبه" && c.ByWeekday[0].Trades == 3 && c.ByWeekday[3].Trades == 0, "Monday to Friday, empty days too");
            Equal(4, c.BySession.Count, "four sessions");
            Check(c.Has("risk") && c.Has("daily") && c.Has("nosl") && !c.Has("revenge") && !c.Has("dd") && !c.Has("streak") && !c.Has("over") && c.Flags.Count == 3,
                  "flagged for risk, the red day and the missing Stop Loss");
            Check(c.Strengths.Count == 2 && c.Strengths[0].Contains("ریسک بیشتر برنگشت") && c.Strengths[1].Contains("سقف"), "what goes well: no revenge, within the trade limit");
            Check(c.Work.Count == 3 && c.Work[0].Contains("حد ضرر نداشت") && c.Work[1].Contains("بالای ۲٪") && c.Work[2].Contains("دراوداون روزانه"), "what needs work, the most important first");
            Check(c.Next.Count == 3 && c.Next[2].Contains("سقف زیان روزانه"), "and three things to try");
            Check(c.Flags.First(f => f.Key == "nosl").Text == "No SL ×1 · 1:00" && c.Flags.First(f => f.Key == "nosl").Level == FlagLevel.Bad, "the flag says how many never had a Stop Loss");

            // MT4: the last Stop Loss stands in for the entry's; one moved to break-even or into profit says nothing about the risk.
            var t4 = new JournalTrade { Buy = true, OpenPrice = 1.1, SlEntry = -1, SlFinal = 1.098, ClosePrice = 1.104, Profit = 40 };
            bool approx;
            Check(Coach.RiskStop(t4, out approx) == 1.098 && approx && near(Coach.RMultiple(t4), 2) && near(Coach.RiskMoney(t4), 20), "MT4: R and risk from the last Stop Loss, marked approximate");
            t4.SlFinal = 1.101;
            Check(double.IsNaN(Coach.RMultiple(t4)) && double.IsNaN(Coach.RiskMoney(t4)), "a Stop Loss on the winning side: no risk to measure");
            Check(double.IsNaN(Coach.RiskMoney(new JournalTrade { Buy = true, OpenPrice = 1.1, SlEntry = 1.09, ClosePrice = 1.1, Profit = 0 })), "a trade closed where it opened: risk unknown");

            // No trade in the range: nothing is judged.
            JournalSummary s0 = JournalMath.Summarize(j, mon.AddDays(10), mon.AddDays(11), new TradeLimits());
            CoachStats c0 = Coach.Analyze(j, s0, mon.AddDays(10), mon.AddDays(11));
            Check(c0.Flags.Count == 0 && c0.Strengths.Count == 0 && double.IsNaN(c0.ProfitFactor), "no trades: no flags, no notes");
            var onlyOpen = new AccountJournal { Platform = "MT5", Login = "51230009", Server = "S", Exported = mon.AddDays(1), From = mon, Complete = true, Balance = 500 };
            onlyOpen.Open.Add(new JournalOpen { Ticket = 77, Symbol = "EURUSD", Buy = true, Volume = 0.1, Open = mon.AddHours(9), OpenPrice = 1.1, SlEntry = 0, Sl = 0 });
            JournalSummary so = JournalMath.Summarize(onlyOpen, mon, mon.AddDays(1), new TradeLimits());
            CoachStats co = Coach.Analyze(onlyOpen, so, mon, mon.AddDays(1));
            Check(co.Has("nosl") && co.NeedsAttention, "only an open position without a Stop Loss: still flagged");

            // A disciplined account next to it, and the group.
            var good = new AccountJournal { Platform = "MT5", Login = "51230001", Server = "WMMarkets-Demo", Exported = mon.AddDays(4), From = mon, Complete = true };
            for (int k = 0; k < 6; k++)
                good.Trades.Add(T(100 + k, true, "XAUUSD", 0.01, mon.AddHours(9 + k), 4000, 3990, mon.AddHours(9 + k).AddMinutes(30), k % 3 == 2 ? 3990 : 4020, k % 3 == 2 ? -10 : 20, 0));
            good.Balance = 1000 + 60;
            JournalSummary gs = JournalMath.Summarize(good, mon, mon.AddDays(5), new TradeLimits());
            CoachStats gc = Coach.Analyze(good, gs, mon, mon.AddDays(5));
            Check(gc.Flags.Count == 0 && near(gc.ProfitFactor, 4) && gc.Strengths.Count == 3 && gc.Strengths[0].Contains("حد ضرر") && gc.Work.Count == 0,
                  "Stop Loss on all, 1% risk, profit factor 4: nothing to flag");
            GroupCoach g = GroupCoach.Of(new List<KeyValuePair<string, CoachStats>> { new KeyValuePair<string, CoachStats>("الف", c), new KeyValuePair<string, CoachStats>("ب", gc) }, new List<JournalSummary> { s, gs });
            Check(g.Read == 2 && g.Trades == 12 && near(g.Net, 39) && near(g.ProfitFactor, (69 + 80) / (90 + 20.0)), "the group's net and profit factor");
            Check(g.Attention == 1 && g.RevengeAccounts == 0 && g.RevengeTrades == 0 && g.DailyRedAccounts == 1 && g.NoStopAccounts == 1 && g.RiskAccounts == 1, "the group's counts");
            Check(g.BestPfName == "ب" && g.MaxDdName == "الف", "the best profit factor and the largest fall");
            Check(near(g.StopPct, 11 * 100.0 / 12) && g.Winners == 1 && g.Losers == 1, "eleven of twelve with a Stop Loss; one up, one down");
            // 3.19: the group's parts, every closed trade pooled: 7 wins (69 + 80), 5 losses (90 + 20).
            Check(g.Wins == 7 && g.Losses == 5 && near(g.WinRate, 700 / 12.0) && near(g.AvgWin, 149 / 7.0) && near(g.AvgLoss, 22) && near(g.RiskReward, 149 / 7.0 / 22), "the group's win rate and averages");
            Check(near(g.Expectancy, 39 / 12.0) && near(g.ReturnPct, 39 / 2000.0 * 100), "the group's expectancy (39 over 12 trades) and return (39 over 2000)");
            Check(g.StopAtEntry == 11 && g.Unprotected == 1 && g.PsychAccounts == 0 && g.MartingaleAccounts == 0 && g.LossAversionAccounts == 0 && g.OverDays == 0, "SLR 2.0 and the behaviour alerts of the group");
        }

        /// <summary>3.21: the scripts read every trade (the end of the history is not taken from the last price; MT4 asks for all of
        /// it; the history is checked against the balance), credit is not a deposit, the kept history knows from when it is exact.</summary>
        static void ReadingAccuracy()
        {
            var inv = CultureInfo.InvariantCulture;
            Func<DateTime, string> u = t => ((long)(t - new DateTime(1970, 1, 1)).TotalSeconds).ToString(inv);
            DateTime d = new DateTime(2026, 11, 11);
            // An older script's file: "now" from a price of 06:00, and a trade closed at 10:00 that a report up to now must show.
            string old = "MTR\t2\tMT5\t4755\r\nA\t51230001\tS\tUSD\t1010\t1010\t" + u(d.AddHours(6)) + "\t" + u(d) + "\r\n" +
                         "T\t7\tEURUSD\t0\t0.1\t" + u(d.AddHours(9)) + "\t1.1\t" + u(d.AddHours(10)) + "\t1.101\t1.099\t1.099\t0\t0\t0\t10\t\r\nEND\t1\r\n";
            AccountJournal oj = JournalFile.Parse(old);
            Check(oj.Exported >= d.AddHours(10), "the time of a read is never before its last trade (it was the last price's: trades after it were left out)");
            Equal(1, JournalMath.Summarize(oj, d, d.AddDays(1), new TradeLimits()).Trades, "so a trade after an old price is in the day");
            Check(oj.TrustedFrom == DateTime.MaxValue && !oj.HistoryChecked, "a file of the older scripts is not taken as exact");

            // The 1.20 script: version, the history check, the last trade, credit apart, the open position's price and commission.
            string text = "MTR\t2\tMT4\t1440\t1.20\r\n" +
                          "A\t2201450\tS\tUSD\t1010\t995.9\t" + u(d.AddHours(14)) + "\t" + u(d) + "\r\n" +
                          "H\t1\t1010.00000000\t1010.00000000\t5\t1\r\n" +
                          "L\t" + u(d.AddHours(13)) + "\t" + u(d.AddDays(-30)) + "\r\n" +
                          "B\t" + u(d.AddHours(8)) + "\t500\tDeposit\t2\r\n" +
                          "B\t" + u(d.AddHours(8)) + "\t100\tCredit in\t3\r\n" +
                          "T\t8\tEURUSD\t0\t0.1\t" + u(d.AddHours(9)) + "\t1.1\t" + u(d.AddHours(10)) + "\t1.101\t-1\t1.099\t0\t-0.7\t0\t10\tfrom\tthe\tside\r\n" +
                          "O\t9\tGBPUSD\t0\t0.3\t" + u(d.AddHours(13)) + "\t1.265\t1.2642\t0\t-14.1\t0\t-1\t1.26453\t-2.1\r\n" +
                          "END\t4\r\n";
            AccountJournal j = JournalFile.Parse(text);
            Check(j.Complete && j.ScriptVersion == "1.20" && j.TrustedFrom == d, "the new script's file is complete and exact from its first day");
            Check(j.HistoryChecked && j.HistoryOk && j.LastTrade == d.AddHours(13) && j.FirstSeen == d.AddDays(-30), "the history check and the last trade are read");
            Check(j.Cash.Count == 1 && j.Cash[0].Amount == 500 && j.CreditMoves.Count == 1 && j.CreditMoves[0].Amount == 100, "credit is kept apart: it is not money paid in");
            Check(j.Open[0].Price == 1.26453 && j.Open[0].Commission == -2.1, "an open position's price and commission");
            Check(j.Trades[0].Comment == "from", "a comment with tabs in an older file does not break the trade");
            AccountJournal back = JournalFile.Parse(JournalFile.Write(j));
            Check(back.Complete && back.ScriptVersion == "1.20" && back.TrustedFrom == d && back.HistoryOk && back.LastTrade == j.LastTrade && back.FirstSeen == j.FirstSeen &&
                  back.CreditMoves.Count == 1 && back.Cash.Count == 1 && back.Open[0].Price == 1.26453, "kept and read again, nothing of it is lost");
            string bad = text.Replace("H\t1\t1010", "H\t0\t710");
            AccountJournal gap = JournalFile.Parse(bad);
            Check(gap.HistoryChecked && !gap.HistoryOk && gap.HistorySum == 710, "a history that does not add up to the balance is marked so");
            PanelView gv = PanelMath.Build(gap, ServerDays.Range(PanelRange.Today, d), new TradeLimits());
            Check(gv.HistoryNote != null && gv.HistoryNote.Contains("کارگزار"), "and the report says the broker gave only part of it");

            // Kept reads: exact from when on.
            var kept = JournalFile.Parse(text.Replace(u(d) + "\r\nH", u(d.AddDays(-20)) + "\r\nH"));
            var fresh = JournalFile.Parse(text);
            AccountJournal m = JournalCache.Merge(kept, fresh);
            Check(m.TrustedFrom == d.AddDays(-20) && JournalCache.CoversTrusted(m, d.AddDays(-20)), "two exact reads: exact from the earlier one");
            AccountJournal m2 = JournalCache.Merge(JournalFile.Parse(old.Replace("\t" + u(d) + "\r\n", "\t" + u(d.AddDays(-20)) + "\r\n").Replace("51230001", "2201450")), fresh);
            Check(m2.TrustedFrom == d && !JournalCache.CoversTrusted(m2, d.AddDays(-20)) && JournalCache.Covers(m2, d.AddDays(-20)), "an older read before a new one: exact only from the new one's day");
            AccountJournal m3 = JournalCache.Merge(kept, oj);
            Check(m3.TrustedFrom == DateTime.MaxValue, "a new read by an older script makes none of it exact");

            // The scripts themselves.
            string mq5 = File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "report", "MTManagerReport.mq5"));
            string mq4 = File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "report", "MTManagerReport.mq4"));
            Check(mq5.Contains("HistorySelect(0, FAR_DATE)") && !mq5.Contains("HistorySelect(0, TimeCurrent") && !mq5.Contains("HistorySelect(0, now"), "MT5 selects the whole history to a far date, never to the last price");
            Check(mq5.Contains("DEAL_FEE") && mq5.Contains("pCost[k] += HistoryDealGetDouble(d, DEAL_COMMISSION) + HistoryDealGetDouble(d, DEAL_FEE)"), "MT5: fees are in the trade's cost");
            Check(mq5.Contains("double volume = pOutVol[k];"), "MT5: a part-closed position is written as its closed part");
            Check(mq5.Contains("entry == DEAL_ENTRY_INOUT ? MathMax(0.0, MathMin(vol, pInVol[k] - pOutVol[k])) : vol") && mq5.Contains("DEAL_TYPE_BUY_CANCELED") &&
                  mq5.Contains("for(int i = 0; i < positions && openCount < ArraySize(openIds); i++)") && mq5.Contains("if(quiet >= 15000) break;"),
                  "MT5: a netting reversal closes only what was open; cancelled deals are not money; positions counted once");
            Check(mq4.Contains("if(quiet >= (uint)(posted ? 45000 : 15000)) break;") && mq4.Contains("posted = PostMessageW(root, WM_COMMAND, CMD_ALL_HISTORY, 0) != 0;"),
                  "MT4 waits up to 45 seconds without a change for the whole history after asking for it");
            Check(mq4.Contains("#define CMD_ALL_HISTORY 33058") && mq4.Contains("if(!IsDllsAllowed())") && mq4.Contains("PostMessageW(root, WM_COMMAND, CMD_ALL_HISTORY, 0)"), "MT4 asks for the whole history, only when DLL calls are allowed");
            foreach (string src in new[] { mq4, mq5 })
                Check(src.Contains("#define SCRIPT_VERSION \"1.21\"") && src.Contains("\"H\\t\"") && src.Contains("\"L\\t\"") && src.Contains("AddsUp()") && src.Contains("M\\ttrades-only"),
                      "both scripts wait until the history adds up to the balance and say so");
            Check(!mq4.Contains("OrderSend") && !mq5.Contains("OrderSend") && !mq5.Contains("#import"), "still read-only, and MT5 imports nothing");
            List<string> s4 = ReportLaunch.StartLines(Kind.MT4, new Account { Login = "2201450", Server = "S" }, "p", "EURUSD");
            List<string> s5 = ReportLaunch.StartLines(Kind.MT5, new Account { Login = "51230001", Server = "S" }, "p", "EURUSD");
            Check(s4.Contains("ExpertsDllImport=true") && s4.Contains("ExpertsTrades=false") && s5.Contains("AllowDllImport=0") && s5.Contains("AllowLiveTrading=0"),
                  "MT4's report copy allows DLL calls (for «All History») and no trading; MT5 neither");
            Equal("در حال گرفتن تاریخچه (۱۵۲ ردیف)…", ReportLaunch.StepText("history 152"), "the wait for the history is shown");

            // 3.21.2: a report MetaTrader left open (MetaTrader restarted itself after its update) is closed before the read; only report copies.
            Check(ReportRunner.IsReportCopy(new Instance { Name = "MT5-WMMarkets-Demo-1", Dir = Path.Combine("D:", "MetaTrader", "_MTManager", "report", "MT5-WMMarkets-Demo-1") }), "a report copy is the program's own");
            Check(!ReportRunner.IsReportCopy(new Instance { Name = "MT5-18", Dir = Path.Combine("D:", "MetaTrader", "MT5-18") }) &&
                  !ReportRunner.IsReportCopy(new Instance { Name = "x", Dir = Path.Combine("C:", "Program Files", "MetaTrader 5") }), "a student's copy or an installed MetaTrader is not");
            // The script built before stays in use when this one cannot be built.
            var st = new Settings { BaseDir = Dir("copies321") };
            string bin = ReportScript.Built(st, Kind.MT5);
            Directory.CreateDirectory(Path.GetDirectoryName(bin));
            File.WriteAllText(bin, "old");
            File.WriteAllText(bin + ".failed", ReportScript.Stamp(ReportScript.SourceText(Kind.MT5)));
            Check(!ReportScript.Ready(st, Kind.MT5) && ReportScript.OnOlder(st, Kind.MT5), "a version that could not be built: the older one is used");
            ReportScript.Build(st, Kind.MT5);
            Equal("old", File.ReadAllText(bin), "and MetaEditor is not asked again for it");
        }

        /// <summary>3.21: the report inside the program: ranges on the server's calendar, the day's numbers, the status rule, reading again
        /// by itself, the order of the rows.</summary>
        static void InlineReport()
        {
            DateTime wed = new DateTime(2026, 11, 11), mon = new DateTime(2026, 11, 9);
            ReportRange r = ServerDays.Range(PanelRange.Today, wed.AddHours(15));
            Check(r.From == wed && r.To == wed.AddDays(1), "today: the server's day");
            r = ServerDays.Range(PanelRange.Yesterday, mon);
            Check(r.From == new DateTime(2026, 11, 6) && r.To == new DateTime(2026, 11, 7), "on Monday, «دیروز» is Friday");
            r = ServerDays.Range(PanelRange.Week, wed);
            Check(r.From == new DateTime(2026, 11, 7) && r.To == wed.AddDays(1), "this week from Saturday");
            r = ServerDays.Range(PanelRange.Month, wed);
            Check(r.From == new DateTime(2026, 11, 1) && r.To == wed.AddDays(1), "this month");
            r = ServerDays.Range(PanelRange.Custom, wed, wed.AddDays(3), new DateTime(2026, 11, 10));
            Check(r.From == new DateTime(2026, 11, 10) && r.To == wed.AddDays(1), "a range back to front, and past today, is put right");
            Equal(new DateTime(2026, 11, 1), ServerDays.Window(wed), "a refresh reads this month (and this week, and the day before)");
            Equal(new DateTime(2026, 10, 30), ServerDays.Window(new DateTime(2026, 11, 2)), "on Monday the 2nd: from the Friday before (its «دیروز»), in October");
            Equal(new DateTime(2026, 11, 1), ServerDays.ReadFrom(null, wed), "nothing kept: the whole window");
            var kept = new AccountJournal { Login = "1", Complete = true, From = new DateTime(2026, 10, 1), Exported = wed.AddHours(-20), TrustedFrom = new DateTime(2026, 10, 1) };
            Equal(wed.AddDays(-1), ServerDays.ReadFrom(kept, wed), "kept and exact: only from the day of the last read");
            Equal(new DateTime(2026, 9, 1), ServerDays.ReadFrom(kept, wed, new DateTime(2026, 9, 1)), "a range further back: from its first day");
            kept.TrustedFrom = DateTime.MaxValue;
            Equal(new DateTime(2026, 11, 1), ServerDays.ReadFrom(kept, wed), "kept by an older script: read again in full");
            Check(Math.Abs((ServerDays.Now(new AccountJournal { GmtOffset = 7200, Exported = wed }, new DateTime(2026, 11, 11, 22, 30, 0)) - new DateTime(2026, 11, 12, 0, 30, 0)).TotalMinutes) < 1,
                  "server time from GMT with the account's own offset");
            Equal(new DateTime(2026, 11, 12, 0, 30, 0), ServerDays.Now(null, new DateTime(2026, 11, 11, 22, 30, 0)), "unknown: New York + 7 (GMT+2 in winter)");
            Equal(new DateTime(2026, 7, 1, 1, 30, 0), ServerDays.Now(null, new DateTime(2026, 6, 30, 22, 30, 0)), "and GMT+3 in summer");

            // The approved mockup's day: an entry Stop Loss, a late one, one without any after a loss (revenge), an open position.
            AccountJournal j = SampleDay(wed);
            PanelView v = PanelMath.Build(j, ServerDays.Range(PanelRange.Today, wed), new TradeLimits());
            Check(v.SingleDay && v.ReachesNow && v.TradeCount == 4 && v.Closed == 3 && v.Open == 1, "4 trades: 3 closed, 1 open (" + v.TradeCount + ")");
            Check(Math.Abs(v.ClosedNet - 52.40) < 0.001 && Math.Abs(v.Floating + 14.10) < 0.001 && Math.Abs(v.Net - 38.30) < 0.001, "net: closed + floating (" + v.ClosedNet + ", " + v.Floating + ")");
            Check(v.Opened == 4 && v.Entry == 2 && v.Late == 1 && v.NoSl == 1 && v.WithStop == 3 && v.NoSlTime == TimeSpan.FromMinutes(42), "Stop loss: 2 Entry · 1 Late · 1 No SL for 0:42");
            Check(v.RiskUnknown == 1 && Math.Abs(v.MaxRisk - 50.0 / 3210 * 100) < 0.05, "the risk of each trade; the one without a Stop Loss unknown (max " + v.MaxRisk + ")");
            PanelTrade open = v.Trades.First(t => !t.Closed);
            Check(Math.Abs(open.RiskPct - 24.0 / 3210 * 100) < 0.05, "an open position's risk from its price and Stop Loss (" + open.RiskPct + ")");
            Check(v.Flags.Any(f => f.Text.StartsWith("No SL")) && !v.Flags.Any(f => f.Text.StartsWith("Revenge") || f.Text.StartsWith("Late SL")), "the warnings: No SL, but no Revenge or Late SL (3.27.1)");
            Equal("4 trades · +$38.30 · 1 No SL", PanelMath.Short(v), "the list's «امروز»");
            Equal("No trades today", PanelMath.Short(PanelMath.Build(j, ServerDays.Range(PanelRange.Today, wed.AddDays(1)), new TradeLimits())), "a day the read was before: nothing of it");
            PanelTrade late = v.Trades.Single(t => t.Stop == StopKind.Delayed);
            Check(Math.Abs(late.RiskPct - 50.0 / 3210 * 100) < 0.05, "a late Stop Loss: the risk at the one it closed with (" + late.RiskPct + ")");
            PanelView week = PanelMath.Build(j, ServerDays.Range(PanelRange.Week, wed), new TradeLimits());
            Check(!week.SingleDay && week.Days.Count == 2 && week.Days[1].Trades == 4 && week.Days[0].Trades == 1 && week.DdLabel == "Max DD", "several days: a line a day");
            Equal("+$1,234.50", PanelMath.Money(1234.5, "USD"), "money with its sign");
            Equal("-12.60 EUR", PanelMath.Money(-12.6, "EUR"), "in another currency");
            Equal("0.00", PanelMath.Money(-0.004, ""), "no minus nought");
            Equal("۷ دقیقه پیش", PanelMath.Ago(wed.AddHours(10), wed.AddHours(10).AddMinutes(7)), "minutes ago");
            Equal("دیروز ۱۸:۲۰", PanelMath.Ago(wed.AddDays(-1).AddHours(18).AddMinutes(20), wed.AddHours(9)), "yesterday");

            // Status: inactive after more than 14 trading days without a trade.
            Equal(1, ActivityRule.TradingDaysAfter(new DateTime(2026, 11, 6), mon), "Friday to Monday: one trading day");
            Equal(10, ActivityRule.TradingDaysAfter(new DateTime(2026, 10, 28), wed), "two weeks: ten trading days");
            var a = new AccountJournal { Login = "1", LastTrade = new DateTime(2026, 10, 22, 15, 0, 0) };
            Equal(14, ActivityRule.TradingDaysAfter(a.LastTrade, wed), "14 trading days");
            Equal(Activity.Active, ActivityRule.Of(a, wed), "14 trading days: still active");
            Equal(Activity.Inactive, ActivityRule.Of(a, wed.AddDays(1)), "15: inactive");
            a.Open.Add(new JournalOpen { Ticket = 1, Open = new DateTime(2026, 9, 1) });
            Equal(Activity.Active, ActivityRule.Of(a, wed.AddDays(1)), "a position open: active");
            Equal(Activity.Inactive, ActivityRule.Of(new AccountJournal { Login = "1", FirstSeen = new DateTime(2026, 9, 1) }, wed), "never traded since the deposit long ago: inactive");
            Equal(Activity.Unknown, ActivityRule.Of(null, wed), "not read: unknown (shown as active)");

            // Reading again by itself: a folder's choice kept with its other settings.
            var fo = new Folder { Id = "1", Name = "x" };
            fo.Extra.Add("DailyTradeLimit=12");
            AutoRefresh.Set(fo, 30);
            Check(AutoRefresh.Of(fo) == 30 && fo.Extra.Contains("DailyTradeLimit=12"), "every 30 minutes, and the folder's other settings stay");
            AutoRefresh.Set(fo, 45);
            Check(AutoRefresh.Of(fo) == 0 && fo.Extra.Count == 1, "only 15, 30 or 60");
            DateTime t0 = wed.AddHours(9);
            Equal(t0.AddMinutes(30), AutoRefresh.Next(t0, t0.AddMinutes(10), 30), "the next round half an hour after the last began");
            Equal(t0.AddMinutes(45), AutoRefresh.Next(t0, t0.AddMinutes(40), 30), "but not before five minutes after it ended");

            // The order of the rows.
            Equal("MT4-05|MT4-03|MT5-01|MT4-04", string.Join("|", ListOrder.Apply(new[] { "MT4-03", "MT4-04", "MT4-05", "MT5-01" }, x => x, new List<string> { "MT4-05", "MT4-03", "MT5-01", "gone" })
                .Concat(new string[0]).Take(4)), "saved order first, the rest after");
            ListOrder.Save(new[] { "MT4-05", "MT4-03" });
            Equal("MT4-05|MT4-03", string.Join("|", ListOrder.Load()), "kept in a file of its own");
            Check(File.Exists(Path.Combine(AppPaths.DataDir, "order.txt")), "order.txt");
        }

        /// <summary>3.24: from the program's own lists to a file and back into a computer without students (made-up students and accounts).</summary>
        static void BackupRoundTrip()
        {
            string before = AppPaths.DataDirOverride;
            try
            {
                AppPaths.DataDirOverride = Dir("backup", "from");
                var accounts = new AccountStore();
                accounts.Set(new Account { Instance = "MT5-01", Trader = "نمونه یک", Login = "51230011", Server = "Demo-Server", Mode = "investor", MasterEnc = "", InvestorEnc = Secret.Protect("inv-one") });
                accounts.Set(new Account { Instance = "MT4-02", Trader = "نمونه دو", Login = "2201460", Server = "Demo-Server", Mode = "investor", MasterEnc = "", InvestorEnc = Secret.Protect("inv-two") });
                accounts.Set(new Account { Instance = "MT5-03", Trader = "", Login = "", Server = "" });
                var folders = new FolderStore();
                Folder f = folders.Create("پوشه‌ی نمونه");
                f.Extra.Add("AutoRefresh=60");
                folders.Add(f.Id, new[] { "MT4-02", "MT5-03" });
                Directory.CreateDirectory(JournalCache.Dir);
                File.WriteAllText(JournalCache.FileFor("51230011", "Demo-Server"), "MTR\t1.20\n", Encoding.UTF8);
                var st = new Settings { Look = "green", MaxMt4 = 24, BaseDir = @"E:\Copies" };
                BackupData d = BackupStore.Gather(st, accounts, folders, new List<string> { "MT4-02", "MT5-01", "MT5-03" }, new List<Instance>());
                Check(d.Students.Count == 2 && d.Students[0].Copy == "MT4-02" && d.Students[0].Kind == "MT4" && d.Students[1].Investor == "inv-one",
                      "the two students in the list's order, a copy without an account left out, the password readable inside");
                Check(d.Folders.Count == 1 && d.Folders[0].Members.SequenceEqual(new[] { "MT4-02" }) && d.Folders[0].Extra.Contains("AutoRefresh=60"), "the folder with its student and its settings");
                Check(d.Settings["Look"] == "green" && d.Settings["MaxMt4"] == "24" && !d.Settings.ContainsKey("BaseDir") && !d.Settings.ContainsKey("BackupPassword"),
                      "portable settings only (not this computer's folders or the backup's own password)");
                Equal(1, d.Journals.Count, "the report history");
                byte[] file = BackupFormat.Make(d, "pass-123456");

                // The other computer: nothing there yet.
                AppPaths.DataDirOverride = Dir("backup", "to");
                BackupData r = BackupFormat.Open(file, "pass-123456");
                var hereAcc = new AccountStore();
                RestorePlan plan = Restore.Plan(r, hereAcc.All, false);
                var made = new Dictionary<string, string> { { "MT4-02", "MT4-01" }, { "MT5-01", "MT5-01" } };
                foreach (BackupStudent b in plan.Add) hereAcc.Set(BackupStore.AccountOf(b, made[b.Copy]));
                Check(hereAcc.Get("MT4-01").Login == "2201460" && Secret.Unprotect(hereAcc.Get("MT4-01").InvestorEnc) == "inv-two" && hereAcc.Get("MT5-01").Trader == "نمونه یک",
                      "the accounts under their new copy names, passwords locked again and readable here");
                var hereFolders = new FolderStore();
                BackupStore.ApplyFolders(r, hereFolders, made);
                Folder back = hereFolders.Find("پوشه‌ی نمونه");
                Check(back != null && hereFolders.Has(back.Id, "MT4-01") && back.Extra.Contains("AutoRefresh=60"), "the folder, with the student under its new name");
                Equal(1, BackupStore.ApplyJournals(r), "the report file written");
                Check(File.ReadAllText(JournalCache.FileFor("51230011", "Demo-Server")) == "MTR\t1.20\n", "the same report history");
                Equal(0, BackupStore.ApplyJournals(r), "one already here and as new is left");
                var hereSettings = new Settings();
                BackupStore.ApplySettings(r, hereSettings);
                Check(hereSettings.Look == "green" && hereSettings.MaxMt4 == 24 && hereSettings.BaseDir != @"E:\Copies", "the settings that travel");
                Equal("MT4-01|MT5-01", string.Join("|", Restore.Order(new List<string>(), r, made)), "the order of the file, by the new names");

                // The backup's own settings are kept by the program (password locked for this Windows user).
                var bs = new Settings { BackupDir = @"F:\Backups", BackupAuto = false, BackupPasswordEnc = Secret.Protect("pass-123456"), LastBackup = new DateTime(2026, 11, 12, 9, 30, 0),
                                        BackupChecked = new DateTime(2026, 11, 12, 9, 31, 0), BackupFingerprint = "abc+/=" };
                bs.Save();
                Settings again = Settings.Load();
                Check(again.BackupDir == @"F:\Backups" && !again.BackupAuto && Secret.Unprotect(again.BackupPasswordEnc) == "pass-123456" && again.LastBackup == bs.LastBackup &&
                      again.BackupChecked == bs.BackupChecked && again.BackupFingerprint == "abc+/=",
                      "the backup's folder, daily switch, password and last time are kept");
            }
            finally { AppPaths.DataDirOverride = before; }
        }

        /// <summary>3.24: the backup file: locked with its password, everything comes back, a wrong password or a damaged file is told,
        /// and what a restore does with students already here (made-up students and accounts).</summary>
        static void BackupCore()
        {
            byte[] plain = Encoding.UTF8.GetBytes("محتوای آزمایشی ۱۲۳ \t\n");
            byte[] locked = BackupLock.Lock(plain, "رمز-آزمایشی-9", 2000);
            Check(BackupLock.LooksLikeBackup(locked) && !locked.Skip(48).Take(plain.Length).SequenceEqual(plain), "locked: marked as a backup, the contents not readable");
            Check(BackupLock.Unlock(locked, "رمز-آزمایشی-9").SequenceEqual(plain), "the right password opens it");
            Func<Action, string> fails = act => { try { act(); return null; } catch (BackupException e) { return e.Message; } };
            Check((fails(() => BackupLock.Unlock(locked, "رمز-دیگر")) ?? "").StartsWith("رمز درست نیست"), "a wrong password is told");
            byte[] damaged = (byte[])locked.Clone();
            damaged[60] ^= 1;
            Check((fails(() => BackupLock.Unlock(damaged, "رمز-آزمایشی-9")) ?? "").Contains("خراب"), "a changed byte is told (damaged)");
            Check((fails(() => BackupLock.Unlock(Encoding.UTF8.GetBytes("not a backup at all, just some text..........................."), "x")) ?? "").Contains("نیست"),
                  "another file is not taken for a backup");
            Check(!BackupLock.Lock(plain, "p", 2000).SequenceEqual(BackupLock.Lock(plain, "p", 2000)), "the same contents lock differently each time (new salt and IV)");

            var d = new BackupData { AppVersion = "3.24.0", Created = new DateTime(2026, 11, 12, 9, 12, 0) };
            d.Students.Add(new BackupStudent { Copy = "MT5-01", Kind = "MT5", Trader = "مریم\tاحمدی", Login = "51230001", Server = "Demo-Server", Investor = "inv\\pass", Master = "" });
            d.Students.Add(new BackupStudent { Copy = "MT4-03", Kind = "MT4", Trader = "Ali Rezaei", Login = "2201450", Server = "Demo-Server", Investor = "abc", NoPassword = true });
            var f1 = new BackupFolder { Name = "جذب سرمایه" };
            f1.Extra.Add("AutoRefresh=30");
            f1.Members.Add("MT5-01");
            d.Folders.Add(f1);
            d.Order.AddRange(new[] { "MT4-03", "MT5-01" });
            d.Settings["Look"] = "green";
            d.Settings["MaxMt4"] = "20";
            d.Journals.Add(new BackupFile { Name = "51230001@Demo-Server.txt", Data = Encoding.UTF8.GetBytes("MTR\t1.20\n"), Time = new DateTime(2026, 11, 12, 9, 0, 0) });
            byte[] file = BackupFormat.Make(d, "pw-123456");
            BackupData r = BackupFormat.Open(file, "pw-123456");
            Equal(2, r.Students.Count, "both students");
            Check(r.Students[0].Trader == "مریم\tاحمدی" && r.Students[0].Investor == "inv\\pass" && r.Students[0].Server == "Demo-Server", "names and passwords as they were (a tab and a backslash too)");
            Check(r.Students[1].NoPassword && r.Students[1].Kind == "MT4", "a student whose password could not be read, said so");
            Check(r.Folders.Count == 1 && r.Folders[0].Name == "جذب سرمایه" && r.Folders[0].Extra.SequenceEqual(new[] { "AutoRefresh=30" }) && r.Folders[0].Members.SequenceEqual(new[] { "MT5-01" }),
                  "the folder, its own settings and who is in it");
            Check(r.Order.SequenceEqual(new[] { "MT4-03", "MT5-01" }) && r.Settings["Look"] == "green" && r.Settings["MaxMt4"] == "20", "the order and the settings");
            Check(r.Journals.Count == 1 && Encoding.UTF8.GetString(r.Journals[0].Data) == "MTR\t1.20\n" && r.Created == d.Created && r.AppVersion == "3.24.0", "the report history and when it was made");
            Equal(1, r.Count("MT5"), "counted by platform");

            // A restore: an account already here (the server written another way) is left as it is, or takes the file's data; nothing is removed.
            var here = new List<Account> { new Account { Instance = "MT5-07", Login = "51230001", Server = "demo server", Trader = "قدیمی" } };
            RestorePlan p = Restore.Plan(r, here, false);
            Check(p.Add.Count == 1 && p.Add[0].Copy == "MT4-03" && p.Skip.Count == 1 && p.Update.Count == 0, "add: the one already here is skipped");
            p = Restore.Plan(r, here, true);
            Check(p.Add.Count == 1 && p.Update.Count == 1 && p.Update[0].Value == "MT5-07" && p.Skip.Count == 0, "update: the one here takes the file's data, in its own copy");
            Equal(2, Restore.Plan(r, new List<Account>(), false).Add.Count, "a new computer: everyone is added");
            List<string> order = Restore.Order(new List<string> { "MT5-07" }, r, new Dictionary<string, string> { { "MT4-03", "MT4-01" } });
            Equal("MT5-07|MT4-01", string.Join("|", order), "the restored ones after those here, by their new names");

            // 3.24.1: the daily backup is one file, written again only when what it holds changed.
            string fp = AutoBackup.Fingerprint(r);
            DateTime made = r.Created;
            r.Created = made.AddDays(3);
            r.AppVersion = "9.9.9";
            Equal(fp, AutoBackup.Fingerprint(r), "the same students, folders and reports: the same fingerprint (not when, nor by which version)");
            Check(r.Created == made.AddDays(3) && r.AppVersion == "9.9.9", "the backup itself is left as it was");
            BackupStudent gone = r.Students[1];
            r.Students.RemoveAt(1);
            Check(AutoBackup.Fingerprint(r) != fp, "a student removed: changed (it goes from the backup too)");
            r.Students.Add(gone);
            Equal(fp, AutoBackup.Fingerprint(r), "back as it was");
            r.Journals[0].Data = Encoding.UTF8.GetBytes("MTR\t1.20\nT\t1\n");
            Check(AutoBackup.Fingerprint(r) != fp, "a new report: changed");
            Check(AutoBackup.Due(true, @"D:\B", true, new DateTime(2026, 11, 11, 23, 0, 0), new DateTime(2026, 11, 12, 8, 0, 0)), "looked at on a new day");
            Check(!AutoBackup.Due(true, @"D:\B", true, new DateTime(2026, 11, 12, 7, 0, 0), new DateTime(2026, 11, 12, 8, 0, 0)), "not twice a day");
            Check(!AutoBackup.Due(true, "", true, DateTime.MinValue, DateTime.Now) && !AutoBackup.Due(true, @"D:\B", false, DateTime.MinValue, DateTime.Now) &&
                  !AutoBackup.Due(false, @"D:\B", true, DateTime.MinValue, DateTime.Now), "not without a folder or a password, or when off");
            Equal("MetaFactory-backup-2026-11-12-0912.mfbak", AutoBackup.HandName(new DateTime(2026, 11, 12, 9, 12, 0), n => n == "MetaFactory-backup-2026-11-12.mfbak"), "a second one by hand the same day: with its time");

            // The settings a backup brings: only those that mean the same on another computer.
            var st = new Settings();
            var withDir = new BackupData();
            withDir.Settings["Look"] = "green";
            withDir.Settings["BaseDir"] = @"X:\Elsewhere";
            BackupStore.ApplySettings(withDir, st);
            Check(st.Look == "green" && st.BaseDir != @"X:\Elsewhere", "the look comes along, the other computer's folder does not");
        }

        /// <summary>3.23: «مرتب‌سازی» arranges the whole order once (made-up students and accounts).</summary>
        static void ListArrange()
        {
            Func<string, string, string, string, ListEntry> e = (name, kind, student, login) => new ListEntry { Name = name, Kind = kind, Student = student, Login = login };
            var list = new List<ListEntry>
            {
                e("MT5-01", "MT5", "یاسمین نوری", "51230001"), e("MT4-01", "MT4", "پریا کاظمی", "2201450"), e("MT5-02", "MT5", "آرش رضایی", "51230009"),
                e("MT4-02", "MT4", "", ""), e("MT5-03", "MT5", "Ali Rezaei", "51230003"), e("MT4-03", "MT4", "ژاله مرادی", "2201499"),
                e("MT5-04", "MT5", "بهرام صالحی", "20160001"), e("MT4-04", "MT4", "گلاره امینی", "2201488"), e("MT5-05", "MT5", "كاوه يزدي", "51230005"),
            };
            Equal("MT4-01|MT4-02|MT4-03|MT4-04|MT5-01|MT5-02|MT5-03|MT5-04|MT5-05", string.Join("|", ListOrder.Arrange(list, ListSort.Mt4First)),
                  "MT4 first, each keeping its order");
            Equal("MT5-01|MT5-02|MT5-03|MT5-04|MT5-05|MT4-01|MT4-02|MT4-03|MT4-04", string.Join("|", ListOrder.Arrange(list, ListSort.Mt5First)), "MT5 first");
            Equal("MT5-02|MT5-04|MT4-01|MT4-03|MT5-05|MT4-04|MT5-01|MT5-03|MT4-02", string.Join("|", ListOrder.Arrange(list, ListSort.Name)),
                  "by name in the Persian alphabet (آ ب پ ژ ک گ ی; Arabic ك and ي as Persian), Latin after, no account last");
            Equal("MT4-01|MT4-04|MT4-03|MT5-04|MT5-01|MT5-03|MT5-05|MT5-02|MT4-02", string.Join("|", ListOrder.Arrange(list, ListSort.Account)),
                  "by account number as a number, none last");
            Check(ListOrder.NameKey("پریا")[0] > ListOrder.NameKey("بهرام")[0] && ListOrder.NameKey("گلاره")[0] > ListOrder.NameKey("کاوه")[0], "پ after ب, گ after ک");
            Equal(0, ListOrder.Arrange(new List<ListEntry>(), ListSort.Name).Count, "an empty list");

            // The MT4/MT5 view is kept with the settings.
            var st = new Settings();
            Equal("all", st.Platform, "all copies by default");
        }

        /// <summary>3.22.4: why a terminal closed right after it started, from journal lines like MetaTrader's own (made-up accounts).</summary>
        static void EarlyCloseReasons()
        {
            Func<string[], EarlyReason> x = lines => EarlyClose.Explain(lines, "51230021");
            EarlyReason r = x(new[] { "0\t23:22:21.100\tWM Markets MT4 build 1492 started", "0\t23:22:30.300\t'51230021': authorization on Broker-Real2 failed (Invalid account)" });
            Equal(EarlyKind.WrongLogin, r.Kind, "MT4: a refused login");
            Check(r.Short == "رمز یا حساب اشتباه" && r.Line.Contains("Invalid account") && r.En.StartsWith("wrong account"), "said on the row and in the log, with the journal's line");
            Equal(2, r.Tail.Count, "the journal lines kept for «بررسی سیستم»");
            Equal(EarlyKind.WrongLogin, x(new[] { "CS\t0\t10:45:32.372\tNetwork\t'51230021': authorization on WMMarkets-Demo failed (Invalid account)" }).Kind, "MT5: a refused login");
            Equal(EarlyKind.NoConnection, x(new[] { "IJ\t1\t10:45:32\tNetwork\t'51230021': authorization on X-Real failed (No connection)" }).Kind, "no connection is not a wrong password");
            Equal(EarlyKind.NoServer, x(new[] { "0\t10:45:32\t'51230021': server Broker-Real9 not found" }).Kind, "an unknown server");
            Equal(EarlyKind.Updated, x(new[] { "0\t07:54:36.012\tLiveUpdate: updater - elevated updater start failed [1223]", "0\t07:54:36.014\tLiveUpdate: updater - try to close terminal" }).Kind,
                  "MetaTrader's own update");
            Equal(EarlyKind.Config, x(new[] { "GL\t2\t07:08:35.543\tTerminal\tcannot load config \"E:\\MT\\MT5-01\\mtm-start.ini\" at start" }).Kind, "the start file not read");
            Equal(EarlyKind.LoggedIn, x(new[] { "0\t12:41:31\t'51230021': login datacenter on WMMarkets-DEMO through LON (ping: 127.03 ms)" }).Kind, "logged in, then closed");
            r = x(new string[0]);
            Check(r.Kind == EarlyKind.Unknown && r.Short == "باز نشد" && r.En.StartsWith("nothing in its journal"), "nothing written: said so");
            Equal(EarlyKind.WrongLogin, x(new[] { "0\t10:00:01\t'51230021': login datacenter on S", "0\t10:00:09\t'51230021': authorization on S failed (Invalid account)" }).Kind,
                  "the newest outcome wins");
            Equal(EarlyKind.Unknown, x(new[] { "0\t10:00:01\t'99999999': authorization on S failed (Invalid account)" }).Kind, "another account's line is not this one's");
        }

        /// <summary>3.22.1: the day as text in the coach's format (made-up student and account); 3.22.2: tidied, and only a trade that never
        /// had a Stop Loss is not correct (one put on after the entry is).</summary>
        static void DayTextFormat()
        {
            DateTime wed = new DateTime(2026, 11, 11);
            AccountJournal j = SampleDay(wed);
            PanelView v = PanelMath.Build(j, ServerDays.Range(PanelRange.Today, wed), new TradeLimits());
            string want = string.Join("\r\n", new[]
            {
                "3. نمونه‌ی آزمایشی",
                "MASTER Account: 51230021",
                "",
                "09:14:00 → 09:51:00 | XAUUSD BUY | 0.10 Lot | +$31.00",
                "10:02:00 → 10:05:00 | EURUSD SELL | 0.50 Lot | -$12.60",
                "10:09:00 → 10:51:00 | EURUSD SELL | 0.50 Lot | +$34.00",
                "",
                "MASTER NET: +$52.40",
                "MASTER LOTS: 1.10",
                "MASTER Trades: 3 | W/L: 2 / 1",
                "Zero P/L: 0",
                "D/D: " + PanelMath.Pct(v.DdPct),
                "Return: +1.68%",
                "",
                "SL: not correct | 1 trade without SL",
                "No SL: 10:09:00 → 10:51:00 | EURUSD SELL",
                "",
                "Open: 13:05:00 | GBPUSD BUY | 0.30 Lot | -$14.10 (floating)",
                "------",
            });
            Equal(want, DayText.Make(3, " نمونه‌ی آزمایشی ", "51230021", v), "the mockup's day, line by line (the Stop Loss put on after the entry is correct)");

            // Only Stop Losses, one of them put on after the entry: correct, and how many.
            j.Trades.RemoveAll(t => t.Ticket == 4);
            v = PanelMath.Build(j, ServerDays.Range(PanelRange.Today, wed), new TradeLimits());
            string text = DayText.Make(1, "x", "1", v);
            Check(text.Contains("\r\n\r\nSL: correct | 3 trades with SL\r\n\r\nOpen: 13:05:00"), "all with a Stop Loss (one after the entry, the open one too): correct | 3 trades");
            Check(!text.Contains("No SL:"), "no trade listed under it");
            Check(text.Contains("MASTER Trades: 2 | W/L: 1 / 1") && text.Contains("Zero P/L: 0"), "two closed");

            // An open position without a Stop Loss is not correct either, and no Open block without open positions.
            j.Open[0].Sl = j.Open[0].SlEntry = 0;
            v = PanelMath.Build(j, ServerDays.Range(PanelRange.Today, wed), new TradeLimits());
            Check(DayText.Make(1, "x", "1", v).Contains("SL: not correct | 1 trade without SL\r\nNo SL: 13:05:00 → open | GBPUSD BUY\r\n"), "an open one without a Stop Loss");
            j.Open.Clear();
            v = PanelMath.Build(j, ServerDays.Range(PanelRange.Today, wed), new TradeLimits());
            Check(DayText.Make(1, "x", "1", v).EndsWith("SL: correct | 2 trades with SL\r\n------"), "nothing open: the rule right after the Stop Loss line");

            // A day without trades.
            v = PanelMath.Build(j, ServerDays.Range(PanelRange.Custom, wed, wed.AddDays(-1), wed.AddDays(-1)), new TradeLimits());
            text = DayText.Make(2, "x", "1", v);
            Check(text.Contains("No closed trades\r\n\r\nMASTER NET: $0.00\r\n"), "no trades: said, and a net of $0.00");
            Check(text.Contains("MASTER Trades: 0 | W/L: 0 / 0") && text.EndsWith("SL: no trades opened\r\n------"), "nothing to judge");

            // Across midnight: opened the day before (its date shown), closed today; a day gone by, opened that day and closed after it.
            DateTime tue = wed.AddDays(-1);
            j.Trades.Add(new JournalTrade { Ticket = 7, Symbol = "EURUSD", Buy = true, Volume = 0.2, Open = tue.AddHours(22).AddMinutes(40).AddSeconds(12), Close = wed.AddHours(1).AddSeconds(5), OpenPrice = 1.085, ClosePrice = 1.0855, SlEntry = 1.084, SlFinal = 1.084, Profit = 10 });
            j.Trades.Add(new JournalTrade { Ticket = 8, Symbol = "EURUSD", Buy = true, Volume = 0.2, Open = wed.AddHours(1).AddMinutes(30), Close = wed.AddHours(1).AddMinutes(40), OpenPrice = 1.085, ClosePrice = 1.0850, SlEntry = 1.084, SlFinal = 1.084, Profit = 0 });
            j.Balance = 3000 + j.Trades.Sum(t => t.Net);
            v = PanelMath.Build(j, ServerDays.Range(PanelRange.Today, wed), new TradeLimits());
            text = DayText.Make(1, "x", "1", v);
            Check(text.Contains("\r\n2026.11.10 22:40:12 → 01:00:05 | EURUSD BUY | 0.20 Lot | +$10.00\r\n"), "opened the day before: with its date");
            Check(text.Contains("Zero P/L: 1") && text.Contains("SL: correct | 3 trades with SL"), "zero counted; the one from the day before not judged again today");
            v = PanelMath.Build(j, ServerDays.Range(PanelRange.Custom, wed, tue, tue), new TradeLimits());
            text = DayText.Make(1, "x", "1", v);
            Check(text.Contains("No closed trades") && text.Contains("SL: correct | 1 trade with SL"), "the day before: nothing closed, one opened with a Stop Loss");
            Check(text.Contains("\r\n\r\nOpen: 22:40:12 | EURUSD BUY | 0.20 Lot | +$10.00 (closed 2026.11.11 01:00:05)\r\n------"), "the day before: open at its end, closed the next day");

            // MT4 (when a Stop Loss went on is not known): one at the close is correct, none is not.
            AccountJournal m4 = Account5(wed, Trade(11, 0.1, wed.AddHours(9), wed.AddHours(10), 5), Trade(12, 0.1, wed.AddHours(11), wed.AddHours(12), -5, 0));
            m4.Platform = "MT4";
            foreach (JournalTrade t in m4.Trades) t.SlEntry = -1;
            m4.Exported = wed.AddHours(20);
            v = PanelMath.Build(m4, ServerDays.Range(PanelRange.Today, wed), new TradeLimits());
            Check(DayText.Make(1, "x", "1", v).Contains("SL: not correct | 1 trade without SL\r\nNo SL: 11:00:00 → 12:00:00 | EURUSD BUY\r\n"), "MT4: the one without a Stop Loss at its close");
        }

        /// <summary>3.25: «متن گزارش»: several students, any range, only the parts ticked, a long rule after each.</summary>
        static void ReportTextFormat()
        {
            DateTime wed = new DateTime(2026, 11, 11);
            AccountJournal j = SampleDay(wed);
            ReportRange today = ServerDays.Range(PanelRange.Today, wed);
            PanelView v = PanelMath.Build(j, today, new TradeLimits());
            var one = new TextEntry { Number = 3, Name = " نمونه‌ی آزمایشی ", Login = "51230021", View = v };
            string text = ReportText.Make(today, new[] { one }, TextParts.All);
            string day = DayText.Make(3, " نمونه‌ی آزمایشی ", "51230021", v);
            Check(text.StartsWith("Report: Wed 2026.11.11\r\n\r\n3. نمونه‌ی آزمایشی\r\nMASTER Account: 51230021\r\nBalance: " + PanelMath.Amount(v.Balance, v.Currency) + "\r\n\r\n09:14:00 → 09:51:00"),
                  "the date on top, then the name, the account and the balance");
            Equal(day.Replace("MASTER Account: 51230021\r\n", "MASTER Account: 51230021\r\nBalance: " + PanelMath.Amount(v.Balance, v.Currency) + "\r\n").Replace("------", ReportText.Rule),
                  text.Substring(text.IndexOf("3. ", StringComparison.Ordinal)), "one day with everything ticked: the day text with the balance and the long rule");
            Check(!PanelMath.Amount(1234.5, "USD").StartsWith("+") && PanelMath.Amount(1234.5, "USD") == "$1,234.50", "a balance without a plus sign");

            // Only the parts ticked.
            string some = ReportText.Make(today, new[] { one }, TextParts.All & ~TextParts.Zero & ~TextParts.Trades & ~TextParts.Date);
            Check(some.StartsWith("3. ") && !some.Contains("Zero P/L") && !some.Contains("09:14:00 → 09:51:00 |") && some.Contains("MASTER NET: +$52.40"), "Zero P/L, the trades and the date left out");
            Check(some.Contains("No SL: 10:09:00 → 10:51:00 | EURUSD SELL"), "the Stop Loss part keeps its own trade lines");
            string bare = ReportText.Student(one, TextParts.Name | TextParts.Net);
            Equal("3. نمونه‌ی آزمایشی\r\nMASTER Account: 51230021\r\n\r\nMASTER NET: +$52.40\r\n" + ReportText.Rule, bare, "the name and the net only");

            // Several students: one after another, an empty line after each rule; one not read yet says so.
            var two = new TextEntry { Number = 5, Name = "دوم", Login = "51230099", View = null };
            string both = ReportText.Make(today, new[] { one, two }, TextParts.All);
            Check(both.Contains(ReportText.Rule + "\r\n\r\n5. دوم\r\nMASTER Account: 51230099\r\nNot read yet\r\n" + ReportText.Rule) && both.EndsWith(ReportText.Rule), "the next student under the rule");
            Equal(20, ReportText.Rule.Length, "the rule: twenty long dashes, about a phone message wide");

            // This week: each trade with its date, the largest fall of the range, the range on top.
            ReportRange week = ServerDays.Range(PanelRange.Week, wed);
            PanelView wv = PanelMath.Build(j, week, new TradeLimits());
            string w = ReportText.Make(week, new[] { new TextEntry { Number = 3, Name = "x", Login = "1", View = wv } }, TextParts.All);
            Equal("Report: 2026.11.07 – 2026.11.11", w.Substring(0, w.IndexOf("\r\n", StringComparison.Ordinal)), "the week (from Saturday, as everywhere in the program) to today");
            Check(w.Contains("\r\n2026.11.11 09:14:00 → 09:51:00 | XAUUSD BUY"), "over several days a trade shows its date");
            Check(w.Contains("Max D/D: ") && !w.Contains("\r\nD/D: "), "several days: the largest fall");

            // The ticks kept in settings.ini.
            Check(ReportText.Parse("") == TextParts.All && ReportText.Parse("abc") == TextParts.All && ReportText.Parse("3") == (TextParts.Date | TextParts.Name), "kept as a number; nothing kept: all");
            var rs = new Settings { ReportParts = ((int)(TextParts.All & ~TextParts.Zero)).ToString(), ReportRange = "Week" };
            rs.Save();
            Settings back = Settings.Load();
            Check(ReportText.Parse(back.ReportParts) == (TextParts.All & ~TextParts.Zero) && back.ReportRange == "Week", "the ticks and the range come back");
        }

        /// <summary>The approved mockup's day (made-up account), plus one trade on Monday.</summary>
        static AccountJournal SampleDay(DateTime day)
        {
            var j = new AccountJournal { Platform = "MT5", Login = "51230021", Server = "S", Currency = "USD", Complete = true, From = day.AddDays(-10), Exported = day.AddHours(14).AddMinutes(22), GmtOffset = 7200 };
            j.TrustedFrom = j.From;
            j.Cash.Add(new JournalCash { Time = day.AddDays(-10), Amount = 3000, Comment = "Deposit" });
            j.Trades.Add(new JournalTrade { Ticket = 1, Symbol = "EURUSD", Buy = true, Volume = 0.2, Open = day.AddDays(-2).AddHours(10), Close = day.AddDays(-2).AddHours(11), OpenPrice = 1.085, ClosePrice = 1.0905, SlEntry = 1.084, SlFinal = 1.084, Profit = 110 });
            j.Trades.Add(new JournalTrade { Ticket = 2, Symbol = "XAUUSD", Buy = true, Volume = 0.10, Open = day.AddHours(9).AddMinutes(14), Close = day.AddHours(9).AddMinutes(51), OpenPrice = 2390.00, ClosePrice = 2393.10, SlEntry = 2387.10, SlFinal = 2387.10, Profit = 31.00 });
            j.Trades.Add(new JournalTrade { Ticket = 3, Symbol = "EURUSD", Buy = false, Volume = 0.50, Open = day.AddHours(10).AddMinutes(2), Close = day.AddHours(10).AddMinutes(5), OpenPrice = 1.08500, ClosePrice = 1.085252, SlEntry = 0, SlFinal = 1.08600, Profit = -12.60 });
            j.Trades.Add(new JournalTrade { Ticket = 4, Symbol = "EURUSD", Buy = false, Volume = 0.50, Open = day.AddHours(10).AddMinutes(9), Close = day.AddHours(10).AddMinutes(51), OpenPrice = 1.08530, ClosePrice = 1.08462, SlEntry = 0, SlFinal = 0, Profit = 34.00 });
            j.Open.Add(new JournalOpen { Ticket = 5, Symbol = "GBPUSD", Buy = true, Volume = 0.30, Open = day.AddHours(13).AddMinutes(5), OpenPrice = 1.26500, Price = 1.26453, Sl = 1.26420, SlEntry = 1.26420, Profit = -14.10 });
            j.Balance = 3000 + j.Trades.Sum(t => t.Net);
            return j;
        }

        static JournalTrade Trade(long id, double vol, DateTime open, DateTime close, double profit, double sl = 1.09)
        {
            return new JournalTrade { Ticket = id, Buy = true, Symbol = "EURUSD", Volume = vol, Open = open, OpenPrice = 1.1, SlEntry = sl, SlFinal = sl, Close = close, ClosePrice = 1.1 + profit / 10000.0, Profit = profit };
        }

        static AccountJournal Account5(DateTime from, params JournalTrade[] trades)
        {
            var j = new AccountJournal { Platform = "MT5", Login = "51230005", Server = "WMMarkets-Demo", Currency = "USD", Exported = from.AddDays(5), From = from, Complete = true };
            j.Trades.AddRange(trades);
            j.Balance = 1000 + trades.Sum(t => t.Net);
            return j;
        }

        /// <summary>3.19: revenge (ten minutes, the same volume or more), hidden martingale, loss aversion and the daily limit of ten,
        /// each at its edges.</summary>
        static void BehaviourRules()
        {
            var mon = new DateTime(2026, 11, 2);
            DateTime nine = mon.AddHours(9);
            Func<AccountJournal, CoachStats> analyze = j => Coach.Analyze(j, JournalMath.Summarize(j, mon, mon.AddDays(5), new TradeLimits()), mon, mon.AddDays(5));

            // Revenge: a loss closes at 10:00. In again at 10:10:00 with the same volume: revenge; at 10:10:01: not; smaller: not.
            DateTime ten = nine.AddHours(1);
            CoachStats r1 = analyze(Account5(mon, Trade(1, 0.10, nine, ten, -20), Trade(2, 0.10, ten.AddMinutes(10), ten.AddMinutes(20), 5)));
            Check(r1.Revenge == 1 && r1.RevengeTrades[0].Ticket == 2, "revenge: ten minutes after a loss, with the same volume");
            CoachStats r2 = analyze(Account5(mon, Trade(1, 0.10, nine, ten, -20), Trade(2, 0.10, ten.AddMinutes(10).AddSeconds(1), ten.AddMinutes(20), 5)));
            Equal(0, r2.Revenge, "ten minutes and a second later: not revenge");
            CoachStats r3 = analyze(Account5(mon, Trade(1, 0.10, nine, ten, -20), Trade(2, 0.05, ten.AddMinutes(2), ten.AddMinutes(20), 5)));
            Equal(0, r3.Revenge, "back in at once but smaller: not revenge");
            CoachStats r4 = analyze(Account5(mon, Trade(1, 0.10, nine, ten, 20), Trade(2, 0.30, ten.AddMinutes(1), ten.AddMinutes(20), 5)));
            Equal(0, r4.Revenge, "larger, but after a win: not revenge");
            var withOpen = Account5(mon, Trade(1, 0.10, nine, ten, -20));
            withOpen.Open.Add(new JournalOpen { Ticket = 9, Symbol = "EURUSD", Buy = true, Volume = 0.2, Open = ten.AddMinutes(3), OpenPrice = 1.1, SlEntry = 1.09, Sl = 1.09 });
            CoachStats r5 = analyze(withOpen);
            Check(r5.Revenge == 1 && r5.RevengeTrades[0].Ticket == 9 && !r5.Has("revenge"), "a position still open counts too; no warning since 3.27.1");

            // Martingale: 0.10 lost → 0.20 lost → 0.40: two steps up, one chain, four times the first volume.
            CoachStats m1 = analyze(Account5(mon, Trade(1, 0.10, nine, ten, -10), Trade(2, 0.20, ten.AddMinutes(30), ten.AddHours(1), -20), Trade(3, 0.40, ten.AddHours(2), ten.AddHours(3), 40)));
            Check(m1.MartingaleChains == 1 && m1.MartingaleSteps == 2 && Math.Abs(m1.MartingaleFactor - 4) < 1e-9, "martingale: two steps up after losses, ×4 (" + m1.MartingaleChains + ", " + m1.MartingaleFactor + ")");
            Check(m1.MartingaleTrades.Select(t => t.Ticket).SequenceEqual(new long[] { 2, 3 }) && !m1.Has("martingale"), "the steps' trades; no warning since 3.27.1");
            Check(m1.Work.Any(w => w.Contains("مارتینگل")) && m1.Next.Any(n => n.Contains("ثابت")), "and the notes say it and what to do");
            CoachStats m2 = analyze(Account5(mon, Trade(1, 0.10, nine, ten, -10), Trade(2, 0.20, ten.AddMinutes(30), ten.AddHours(1), 20), Trade(3, 0.40, ten.AddHours(2), ten.AddHours(3), 40)));
            Check(m2.MartingaleChains == 0 && m2.MartingaleTrades.Count == 0, "the bigger trade won: the run stops, no martingale");
            CoachStats m3 = analyze(Account5(mon, Trade(1, 0.10, nine, ten, -10), Trade(2, 0.20, ten.AddMinutes(30), ten.AddHours(1), -20), Trade(3, 0.40, ten.AddHours(2), ten.AddHours(3), -40),
                                             Trade(4, 0.80, ten.AddHours(4), ten.AddHours(5), 90), Trade(5, 0.10, mon.AddDays(1).AddHours(9), mon.AddDays(1).AddHours(10), -10),
                                             Trade(6, 0.20, mon.AddDays(1).AddHours(11), mon.AddDays(1).AddHours(12), -10), Trade(7, 0.30, mon.AddDays(1).AddHours(13), mon.AddDays(1).AddHours(14), 30)));
            Check(m3.MartingaleChains == 2 && m3.MartingaleSteps == 3 && Math.Abs(m3.MartingaleFactor - 8) < 1e-9 && m3.MartingaleTrades.Count == 5, "two chains: three steps to ×8, then two steps to ×3");
            // Trades open together: each is linked to the last trade closed before it opened, not to the one opened before it.
            CoachStats m4 = analyze(Account5(mon, Trade(1, 0.10, nine, ten.AddHours(3), -10), Trade(2, 0.20, nine.AddMinutes(5), ten, -20), Trade(3, 0.40, ten.AddMinutes(5), ten.AddHours(1), 40)));
            Check(m4.MartingaleChains == 0, "trade 2 opened while 1 was open: its step comes from nothing closed, so one step only");

            // 3.19.1: risk, not lots. A sell taken after a losing buy on the same symbol is a plan's reversal, not revenge.
            Func<long, bool, double, DateTime, DateTime, double, double, JournalTrade> TR = (id, buy, vol, open, close, profit, slDist) =>
                new JournalTrade { Ticket = id, Buy = buy, Symbol = "EURUSD", Volume = vol, Open = open, OpenPrice = 1.1, SlEntry = buy ? 1.1 - slDist : 1.1 + slDist, SlFinal = buy ? 1.1 - slDist : 1.1 + slDist,
                                   Close = close, ClosePrice = 1.1 + (buy ? 1 : -1) * profit / 10000.0, Profit = profit };
            CoachStats v1 = analyze(Account5(mon, TR(1, true, 0.10, nine, ten, -20, 0.01), TR(2, false, 0.10, ten.AddMinutes(2), ten.AddMinutes(30), 15, 0.01)));
            Check(v1.Revenge == 0 && v1.Reversals.Count == 1 && v1.Reversals[0].Ticket == 2, "the reverse of a losing buy, same risk: a reversal, not revenge");
            AccountJournal vj = Account5(mon, TR(1, true, 0.10, nine, ten, -20, 0.01), TR(2, false, 0.10, ten.AddMinutes(2), ten.AddMinutes(30), 15, 0.01));
            CoachStats v2 = analyze(Account5(mon, TR(1, true, 0.10, nine, ten, -20, 0.01), TR(2, false, 0.20, ten.AddMinutes(2), ten.AddMinutes(30), 15, 0.005)));
            Check(v2.Revenge == 0 && v2.Reversals.Count == 1, "reversed with twice the lots and the Stop Loss half as far: the same risk, still a reversal");
            CoachStats v3 = analyze(Account5(mon, TR(1, true, 0.10, nine, ten, -20, 0.01), TR(2, false, 0.30, ten.AddMinutes(2), ten.AddMinutes(30), 15, 0.01)));
            Check(v3.Revenge == 1 && v3.Reversals.Count == 0, "reversed with three times the risk: revenge");
            CoachStats v4 = analyze(Account5(mon, TR(1, true, 0.10, nine, ten, -20, 0.01), TR(2, false, 0.105, ten.AddMinutes(2), ten.AddMinutes(30), 15, 0.01)));
            Check(v4.Revenge == 0 && v4.Reversals.Count == 1, "5% more risk on the reversal is still the same (lots come in steps)");
            CoachStats v5 = analyze(Account5(mon, TR(1, true, 0.10, nine, ten, -20, 0.01), TR(2, true, 0.20, ten.AddMinutes(2), ten.AddMinutes(30), 15, 0.005)));
            Check(v5.Revenge == 1 && v5.Reversals.Count == 0, "the same way again with the same risk (twice the lots, half the distance): revenge");
            CoachStats v6 = analyze(Account5(mon, TR(1, true, 0.10, nine, ten, -20, 0.01), TR(2, true, 0.20, ten.AddMinutes(2), ten.AddMinutes(30), 15, 0.0025)));
            Check(v6.Revenge == 0, "the same way with more lots but half the risk: not revenge");
            var noSl = Account5(mon, TR(1, true, 0.10, nine, ten, -20, 0.01), TR(2, false, 0.20, ten.AddMinutes(2), ten.AddMinutes(30), 15, 0.01));
            noSl.Trades[1].SlEntry = 0; noSl.Trades[1].SlFinal = 0;
            Check(analyze(noSl).Revenge == 1, "a reversal without a Stop Loss and with more lots: compared by lots, revenge");
            var gbp = Account5(mon, TR(1, true, 0.10, nine, ten, -20, 0.01), TR(2, false, 0.10, ten.AddMinutes(2), ten.AddMinutes(30), 15, 0.01));
            gbp.Trades[1].Symbol = "GBPUSD";
            CoachStats v7 = analyze(gbp);
            Check(v7.Revenge == 1 && v7.Reversals.Count == 0, "the other way on another symbol is no reversal: the same money at stake, revenge");
            // Martingale by risk: twice the lots with the Stop Loss half as far each time is a fixed risk, no martingale.
            CoachStats f1 = analyze(Account5(mon, TR(1, true, 0.10, nine, ten, -10, 0.01), TR(2, true, 0.20, ten.AddMinutes(30), ten.AddHours(1), -10, 0.005),
                                              TR(3, true, 0.40, ten.AddHours(2), ten.AddHours(3), 40, 0.0025)));
            Check(f1.MartingaleChains == 0, "lots doubled with the Stop Loss halved: the same risk, no martingale");
            // Reversals count in martingale: buy lost, a sell twice the risk lost, a buy twice again.
            CoachStats f2 = analyze(Account5(mon, TR(1, true, 0.10, nine, ten, -10, 0.01), TR(2, false, 0.20, ten.AddMinutes(30), ten.AddHours(1), -20, 0.01),
                                              TR(3, true, 0.40, ten.AddHours(2), ten.AddHours(3), 40, 0.01)));
            Check(f2.MartingaleChains == 1 && Math.Abs(f2.MartingaleFactor - 4) < 1e-9 && f2.MartingaleByRisk && !f2.Has("martingale"),
                  "reversals that double the risk after each loss: martingale, the risk four times (" + f2.MartingaleFactor + ")");

            // Loss aversion: losses held 40 minutes, wins 10: four times as long, over three.
            var la = new List<JournalTrade>();
            for (int k = 0; k < 6; k++)
            {
                DateTime o = mon.AddHours(9 + k * 2);
                bool win = k % 2 == 0;
                la.Add(Trade(10 + k, 0.10, o, o.AddMinutes(win ? 10 : 40), win ? 30 : -10));
            }
            CoachStats l1 = analyze(Account5(mon, la.ToArray()));
            Check(l1.LossAversion && Math.Abs(l1.HoldRatio - 4) < 1e-9 && !l1.Has("lossav") && l1.PsychAlerts == 1, "loss aversion: losses held four times as long as wins");
            Check(l1.Work.Any(w => w.Contains("زیان‌گریزی")), "and the note names it");
            var la3 = la.Select(t => t.Profit < 0 ? Trade(t.Ticket, 0.10, t.Open, t.Open.AddMinutes(30), -10) : t).ToArray();
            CoachStats l3 = analyze(Account5(mon, la3));
            Check(!l3.LossAversion && Math.Abs(l3.HoldRatio - 3) < 1e-9 && !l3.Has("lossav"), "exactly three times: not yet");
            CoachStats few = analyze(Account5(mon, la.Take(4).ToArray()));
            Check(!few.LossAversion && few.HoldRatio > 3, "with fewer than five trades it is not judged");

            // The daily limit: ten a day is normal, the eleventh is over it.
            var day10 = Enumerable.Range(0, 10).Select(k => Trade(100 + k, 0.1, nine.AddMinutes(k * 20), nine.AddMinutes(k * 20 + 10), 5)).ToArray();
            JournalSummary s10 = JournalMath.Summarize(Account5(mon, day10), mon, mon.AddDays(5), new TradeLimits());
            Check(s10.OverOk && s10.MaxPerDay == 10 && s10.Limits.Daily == 10, "ten trades in a day: within the limit");
            var day11 = day10.Concat(new[] { Trade(200, 0.1, nine.AddHours(5), nine.AddHours(5).AddMinutes(10), 5) }).ToArray();
            JournalSummary s11 = JournalMath.Summarize(Account5(mon, day11), mon, mon.AddDays(5), new TradeLimits());
            Check(!s11.OverOk && s11.OverDays == 1 && s11.OverDayDates[0] == mon && s11.OverStatus == "اورترید: ۱ روز (سقف ۱۰)", "the eleventh: over the limit that day");
            CoachStats c11 = Coach.Analyze(Account5(mon, day11), s11, mon, mon.AddDays(5));
            Check(c11.Has("over") && c11.Flags.First(f => f.Key == "over").Text == "Over limit 1 day", "flagged with the days");

            // SLR 2.0 in the flags: a Stop Loss put on after the entry only is a warning, not the red of none at all.
            var late = Account5(mon, Trade(1, 0.1, nine, ten, 5), Trade(2, 0.1, nine.AddHours(2), nine.AddHours(3), 5));
            late.Trades[1].SlEntry = 0;
            CoachStats cl = analyze(late);
            Check(!cl.Has("nosl") && !cl.Has("late") && !cl.Flags.Any(f => f.Text.StartsWith("Late")), "3.27.1: a Stop Loss put on after the entry is no warning (the trade's own tag still says Late)");
            var none = Account5(mon, Trade(1, 0.1, nine, ten, 5), Trade(2, 0.1, nine.AddHours(2), nine.AddHours(3), 5));
            none.Trades[1].SlEntry = 0; none.Trades[1].SlFinal = 0;
            CoachStats cn = analyze(none);
            Check(cn.Flags.First(f => f.Key == "nosl").Level == FlagLevel.Bad, "none at all is red");
        }

        /// <summary>3.19: the expectancy from its parts, with a trade at zero (neither won nor lost), and the balance's largest fall.</summary>
        static void ExpectancyAndDrawdown()
        {
            var mon = new DateTime(2026, 11, 2);
            Func<int, DateTime> h = k => mon.AddHours(8 + k);
            // +30, +30, -20, 0, -10: win rate 40%, loss rate 40%, average win 30, average loss 15 → 0.4 × 30 − 0.4 × 15 = 6.
            var j = Account5(mon, Trade(1, 0.1, h(0), h(0).AddMinutes(30), 30), Trade(2, 0.1, h(1), h(1).AddMinutes(30), 30), Trade(3, 0.1, h(2), h(2).AddMinutes(30), -20),
                             Trade(4, 0.1, h(3), h(3).AddMinutes(30), 0), Trade(5, 0.1, h(4), h(4).AddMinutes(30), -10));
            JournalSummary s = JournalMath.Summarize(j, mon, mon.AddDays(5), new TradeLimits());
            CoachStats c = Coach.Analyze(j, s, mon, mon.AddDays(5));
            Func<double, double, bool> near = (x, y) => Math.Abs(x - y) < 1e-9;
            Check(c.Wins == 2 && c.Losses == 2 && near(c.WinRate, 40) && near(c.LossRate, 40), "a trade at zero is neither a win nor a loss");
            Check(near(c.AvgWin, 30) && near(c.AvgLoss, 15) && near(c.Expectancy, 6), "expectancy: 40% × 30 − 40% × 15 = 6 (" + c.Expectancy + ")");
            Check(near(c.Expectancy, c.Net / c.Trades), "the same as the net over the trades");
            Check(near(c.BreakEvenWinRate, 100 / 3.0), "break-even: 15 / (30 + 15) = 33.3%");
            // The balance: 1000 → 1100 (the high) → 800 → 850 → 750: the largest fall is 350 from 1100.
            var d = Account5(mon, Trade(1, 0.1, h(0), h(0).AddMinutes(30), 100), Trade(2, 0.1, h(1), h(1).AddMinutes(30), -300), Trade(3, 0.1, h(2), h(2).AddMinutes(30), 50),
                             Trade(4, 0.1, h(3), h(3).AddMinutes(30), -100));
            JournalSummary ds = JournalMath.Summarize(d, mon, mon.AddDays(5), new TradeLimits());
            CoachStats dc = Coach.Analyze(d, ds, mon, mon.AddDays(5));
            Check(near(ds.StartBalance, 1000) && near(dc.MaxDd, 350) && near(dc.MaxDdPct, 350 / 1100.0 * 100), "largest fall: 350, 31.8% of the high of 1100 (" + dc.MaxDd + ")");
            Check(dc.DdPeak == h(0).AddMinutes(30) && dc.DdLow == h(3).AddMinutes(30) && near(dc.RecoveryFactor, -250 / 350.0), "from the high's close to the low's, and the recovery factor");
            // Money paid in or out is not a result: a withdrawal after the high is no fall.
            d.Cash.Add(new JournalCash { Time = h(0).AddMinutes(40), Amount = -500, Comment = "Withdrawal" });
            d.Balance -= 500;
            JournalSummary ws = JournalMath.Summarize(d, mon, mon.AddDays(5), new TradeLimits());
            Check(near(Coach.Analyze(d, ws, mon, mon.AddDays(5)).MaxDd, 350), "a withdrawal does not change the largest fall");
        }

        /// <summary>A stand-in for a MetaTrader: closes when asked or not, has windows or not.</summary>
        sealed class FakeTarget : SafeClose.ITarget
        {
            public int Pid;
            public bool Gone, Obeys, HasWindows = true;
            public int Asked, Killed, Waited;
            public int Id { get { return Pid; } }
            public bool Exited { get { return Gone; } }
            public int AskToClose() { Asked++; if (!HasWindows) return 0; if (Obeys) Gone = true; return 2; }
            public bool WaitExit(int ms) { Waited += ms; return Gone; }
            public void Kill() { Killed++; Gone = true; }
        }

        /// <summary>3.19: a report MetaTrader is asked to close, has fifteen seconds, then is ended; only one the program tracks; starts
        /// 1.5 seconds apart; the report copy opens without charts of its own.</summary>
        static void ProcessSafety()
        {
            var said = new List<string>();
            Func<int, bool> ours = pid => pid == 4001;
            var obeys = new FakeTarget { Pid = 4001, Obeys = true };
            Check(SafeClose.Close(obeys, ours, SafeClose.GraceSeconds, said.Add) == SafeClose.Result.Closed && obeys.Asked == 1 && obeys.Killed == 0, "asked to close, it closes: never ended");
            var stubborn = new FakeTarget { Pid = 4001 };
            Check(SafeClose.Close(stubborn, ours, SafeClose.GraceSeconds, said.Add) == SafeClose.Result.Ended && stubborn.Asked == 1 && stubborn.Killed == 1, "it does not close: ended");
            Check(SafeClose.GraceSeconds == 15 && stubborn.Waited >= 15000 && stubborn.Waited - 15000 <= 5000, "only after fifteen seconds (" + stubborn.Waited + " ms waited)");
            var stranger = new FakeTarget { Pid = 4002 };
            Check(SafeClose.Close(stranger, ours, SafeClose.GraceSeconds, said.Add) == SafeClose.Result.NotOurs && stranger.Asked == 0 && stranger.Killed == 0 && !stranger.Gone,
                  "a process the program did not start (the same name or not) is never asked nor ended");
            Check(said.Any(x => x.Contains("4002") && x.Contains("not opened by this program")), "and the log says why it was left");
            var noWindow = new FakeTarget { Pid = 4001, HasWindows = false };
            Check(SafeClose.Close(noWindow, ours, SafeClose.GraceSeconds, said.Add) == SafeClose.Result.Ended && noWindow.Waited < 15000, "no window to ask: ended without the wait");
            var gone = new FakeTarget { Pid = 4001, Gone = true };
            Check(SafeClose.Close(gone, ours, SafeClose.GraceSeconds, said.Add) == SafeClose.Result.Gone && gone.Asked == 0 && gone.Killed == 0, "already closed: nothing to do");
            Check(SafeClose.Close(new FakeTarget { Pid = 4001 }, null, SafeClose.GraceSeconds, said.Add) == SafeClose.Result.NotOurs, "no list of its own: nothing is touched");

            // Real processes: two of the same program; only the one tracked is ended, the other runs on.
            if (File.Exists("/bin/sleep"))
            {
                Process a = Process.Start(new ProcessStartInfo("/bin/sleep", "60") { UseShellExecute = false });
                Process b = Process.Start(new ProcessStartInfo("/bin/sleep", "60") { UseShellExecute = false });
                try
                {
                    int tracked = a.Id;
                    Check(SafeClose.Close(new ProcessTarget(b), pid => pid == tracked, 1, said.Add) == SafeClose.Result.NotOurs && !b.HasExited, "the untracked one with the same name: left running");
                    SafeClose.Result r = SafeClose.Close(new ProcessTarget(a), pid => pid == tracked, 1, said.Add);
                    Check(r == SafeClose.Result.Ended && a.WaitForExit(5000), "the tracked one: ended (" + r + ")");
                    Check(!b.HasExited, "and the other still runs after it");
                }
                finally
                {
                    foreach (Process x in new[] { a, b }) try { if (!x.HasExited) x.Kill(); } catch { }
                }
            }
            // Nothing in the program ends a process it found by its name.
            string src = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "src");
            if (Directory.Exists(src))
            {
                foreach (string f in Directory.GetFiles(src, "*.cs"))
                {
                    string[] lines = File.ReadAllLines(f);
                    Check(!lines.Any(l => l.Contains("GetProcessesByName") && (l.Contains("Kill") || l.Contains("CloseMainWindow"))), Path.GetFileName(f) + ": no process found by name is ended on that line");
                }
                Check(!File.ReadAllText(Path.Combine(src, "Report.cs")).Contains("GetProcessesByName"), "the report never looks a MetaTrader up by name");
            }

            // Starts 1.5 seconds apart.
            DateTime t = new DateTime(2026, 11, 11, 9, 0, 0);
            var slept = new List<int>();
            var pacer = new StartPacer(() => t, ms => { slept.Add(ms); t = t.AddMilliseconds(ms); });
            Equal(0, pacer.Turn(), "the first start at once");
            t = t.AddMilliseconds(400);
            Equal(1100, pacer.Turn(), "the next one 0.4 s later waits 1.1 s");
            t = t.AddMilliseconds(2000);
            Equal(0, pacer.Turn(), "2 s later: at once");
            Check(slept.SequenceEqual(new[] { 1100 }) && StartPacer.GapMs == 1500, "the gap is 1.5 s");

            // The report copy opens with no chart of its own: what the terminal saved there last time is dropped, its own charts stay.
            var rc5 = new Instance { Name = "report-MT5-S-1", Kind = Kind.MT5, Dir = Dir("emptyprofile", "MT5") };
            Touch(Path.Combine(rc5.Dir, "MQL5", "Profiles", "Charts", "Empty", "chart01.chr"), "symbol=EURUSD");
            Touch(Path.Combine(rc5.Dir, "MQL5", "Profiles", "Charts", "Default", "chart01.chr"), "symbol=EURUSD@");
            ChartProfile.UseEmpty(rc5, true);
            Check(!File.Exists(Path.Combine(rc5.Dir, "MQL5", "Profiles", "Charts", "Empty", "chart01.chr")) && File.Exists(Path.Combine(rc5.Dir, "MQL5", "Profiles", "Charts", "Default", "chart01.chr"))
                  && !Directory.Exists(Path.Combine(rc5.Dir, "MTManager-backup")), "MT5 report copy: the empty profile emptied, the Default one untouched, nothing piled up");
            var st5 = new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = Dir("emptyprofile", "student") };
            Touch(Path.Combine(st5.Dir, "MQL5", "Profiles", "Charts", "Empty", "chart01.chr"), "symbol=XAUUSD");
            ChartProfile.UseEmpty(st5);
            Check(Directory.GetFiles(Path.Combine(st5.Dir, "MTManager-backup", "charts")).Length == 1, "a student copy's chart is still set aside, never dropped");
            var rc4 = new Instance { Name = "report-MT4-S-1", Kind = Kind.MT4, Dir = Dir("emptyprofile", "MT4") };
            ChartProfile.UseEmpty(rc4, true);
            Check(File.ReadAllText(Path.Combine(rc4.Dir, "profiles", "lastprofile.ini")) == "Empty" && Directory.Exists(Path.Combine(rc4.Dir, "profiles", "Empty")), "MT4 report copy: told to open the empty profile");
            Check(ReportLaunch.StartLines(Kind.MT5, new Account { Login = "51230001", Server = "S" }, "p", "EURUSD").Contains("ProfileLast=Empty"), "MT5: the start file names it");
        }

        /// <summary>3.20: the balance's largest fall with money paid in or out, and the equity's from the minute bars.</summary>
        static void DrawdownAndEquity()
        {
            var mon = new DateTime(2026, 11, 2);
            Func<int, DateTime> h = k => mon.AddHours(8 + k);
            Func<double, double, bool> near = (x, y) => Math.Abs(x - y) < 1e-6;
            // 500 paid in inside the range (nothing before it), then +10, -6.55, +20: a fall of 6.55 from 510, not from the 10 of profit.
            var a = new AccountJournal { Platform = "MT5", Login = "51230009", Server = "S", Currency = "USD", Exported = mon.AddDays(5), From = mon, Complete = true };
            a.Cash.Add(new JournalCash { Time = h(0), Amount = 500, Comment = "Deposit" });
            a.Trades.Add(Trade(1, 0.1, h(1), h(1).AddMinutes(20), 10));
            a.Trades.Add(Trade(2, 0.1, h(2), h(2).AddMinutes(20), -6.55));
            a.Trades.Add(Trade(3, 0.1, h(3), h(3).AddMinutes(20), 20));
            a.Balance = 523.45;
            JournalSummary sa = JournalMath.Summarize(a, mon, mon.AddDays(5), new TradeLimits());
            CoachStats ca = Coach.Analyze(a, sa, mon, mon.AddDays(5));
            Check(near(sa.StartBalance, 0) && near(ca.MaxDd, 6.55) && near(ca.MaxDdPct, 6.55 / 510 * 100), "a deposit inside the range: 1.28% of the money in the account (" + ca.MaxDdPct + "), not 65%");
            Check(ca.CashInRange && near(ca.Curve[0].Balance, 523.45) && near(ca.Curve[0].Net, 23.45), "the balance line holds the deposit; the day's result its trades only");
            // A withdrawal is no fall: 1000 → +100 (1100) → 500 out → -50: 50 below the high of 600, 8.3%.
            var w = Account5(mon, Trade(1, 0.1, h(1), h(1).AddMinutes(20), 100), Trade(2, 0.1, h(3), h(3).AddMinutes(20), -50));
            w.Cash.Add(new JournalCash { Time = h(2), Amount = -500, Comment = "Withdrawal" });
            w.Balance = 1000 + 50 - 500;
            CoachStats cw = Coach.Analyze(w, JournalMath.Summarize(w, mon, mon.AddDays(5), new TradeLimits()), mon, mon.AddDays(5));
            Check(near(cw.MaxDd, 50) && near(cw.MaxDdPct, 50 / 600.0 * 100), "a withdrawal moves the high too: the fall is the trade's 50 of 600 (" + cw.MaxDdPct + ")");
            // Equity: a trade without a Stop Loss went 150 under water at 9:10 and closed at +20: balance no fall, equity 15%.
            var e = Account5(mon, Trade(1, 0.1, h(1), h(1).AddMinutes(30), 20, 0));
            e.Floating[h(1).AddMinutes(5)] = -40;
            e.Floating[h(1).AddMinutes(10)] = -150;
            e.Floating[h(1).AddMinutes(25)] = 10;
            CoachStats ce = Coach.Analyze(e, JournalMath.Summarize(e, mon, mon.AddDays(5), new TradeLimits()), mon, mon.AddDays(5));
            Check(ce.MaxDd == 0 && ce.EquityKnown && near(ce.EqDd, 150) && near(ce.EqDdPct, 15) && ce.EqDdAt == h(1).AddMinutes(10) && ce.EquityFrom == h(1).AddMinutes(5),
                  "equity: 150 under the high of 1000 at 9:10 (" + ce.EqDdPct + "), while the balance never fell");
            Check(ce.Has("eqdd") && ce.Flags.First(f => f.Key == "eqdd").Text == "Equity DD 15.0%" && !ce.Has("dd"), "flagged as an equity drawdown");
            Check(!ca.EquityKnown, "no minutes: the equity's fall is not known");
            // No Stop Loss: a closed trade 25 minutes and a position still open 70 minutes without one.
            var n = Account5(mon, Trade(1, 0.1, h(1), h(1).AddMinutes(25), -5, 0), Trade(2, 0.1, h(2), h(2).AddMinutes(20), 5));
            n.Exported = h(4).AddMinutes(10);
            n.Open.Add(new JournalOpen { Ticket = 3, Symbol = "EURUSD", Buy = true, Volume = 0.1, Open = h(3), OpenPrice = 1.1, SlEntry = 0, Sl = 0 });
            CoachStats cn = Coach.Analyze(n, JournalMath.Summarize(n, mon, mon.AddDays(5), new TradeLimits()), mon, mon.AddDays(5));
            Check(cn.NoSlTrades == 2 && cn.NoSlOpen == 1 && cn.NoSlTime == TimeSpan.FromMinutes(95) && cn.NoSlLongest == TimeSpan.FromMinutes(70), "without a Stop Loss: 1:35 in all, the longest 1:10 (still open)");
            Check(cn.Flags.First(f => f.Key == "nosl").Text == "No SL ×2 · 1:35" && cn.Work.Any(x => x.Contains("۱:۳۵ بدون حد ضرر در بازار بود")), "said on the card and in the notes");
            Equal("1d 2:05", Coach.Span(new TimeSpan(1, 2, 5, 0)), "a day and more");
        }

        /// <summary>3.20: «همه‌ی تاریخچه»: from the account's first day; minute bars for the last 100 days only; a history that does not
        /// start from nothing is said to be partial.</summary>
        static void AllHistory()
        {
            var today = new DateTime(2026, 11, 13, 15, 0, 0);
            ReportRange all = ReportRange.Of(RangeKind.AllHistory, today);
            Check(all.IsAll && all.From == new DateTime(2000, 1, 1) && all.To == new DateTime(2026, 11, 14), "everything up to the end of today");
            Equal("همه‌ی تاریخچه (تا 2026.11.13)", all.Title, "its title");
            Equal("FromDate=2000.01.01|OutFile=MTManagerReport\\report.txt", string.Join("|", ReportLaunch.Preset(all.From)), "the script reads from the start");
            var j = new AccountJournal { Platform = "MT5", Login = "51230010", Server = "S", Currency = "USD", Exported = today, From = all.From, Complete = true };
            j.Cash.Add(new JournalCash { Time = new DateTime(2025, 3, 4, 10, 0, 0), Amount = 1000, Comment = "Deposit" });
            for (int k = 0; k < 40; k++)
            {
                DateTime o = new DateTime(2025, 3, 5).AddDays(k * 15).AddHours(10);
                j.Trades.Add(Trade(500 + k, 0.1, o, o.AddHours(1), k % 3 == 0 ? -12 : 9));
            }
            j.Balance = 1000 + j.Trades.Sum(t => t.Net);
            Check(ReportRange.FirstActivity(j, all.From) == new DateTime(2025, 3, 4, 10, 0, 0), "the account's first day");
            var watch = Stopwatch.StartNew();
            JournalSummary s = JournalMath.Summarize(j, all.From, all.To, new TradeLimits());
            Check(watch.ElapsedMilliseconds < 2000 && Math.Abs(s.StartBalance) < 0.01 && s.Trades == 40, "26 years of days, only those with a close counted (" + watch.ElapsedMilliseconds + " ms)");
            // MetaTrader gave only part of it: the balance before its first trade is not nought.
            var part = new AccountJournal { Platform = "MT4", Login = "2201460", Server = "S", Currency = "USD", Exported = today, From = all.From, Complete = true };
            part.Trades.Add(Trade(1, 0.1, new DateTime(2026, 9, 1, 10, 0, 0), new DateTime(2026, 9, 1, 11, 0, 0), 9));
            part.Balance = 2009;
            foreach (string f in new[] { "MTManagerReport.mq5", "MTManagerReport.mq4" })
            {
                string src = File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "report", f));
                Check(src.Contains("M\\ttrades-only") && !src.Contains("CopyRates(") && !src.Contains("AddFloating(") && !src.Contains("BARS_BUDGET"), f + " exports trades without downloading candles or calculating historical floating loss");
            }
        }

        /// <summary>3.18: the script's file also carries the account's leverage and margin, MT5's deals and orders, and the orders
        /// waiting to be filled; files of the earlier versions are still read (and still complete).</summary>
        static void StatementData()
        {
            string text = string.Join("\r\n", new[]
            {
                "MTR\t2\tMT5\t6295",
                "A\t51230002\tWMMarkets-Demo\tUSD\t1186.4\t1191.1\t1762797600\t1761177600\tWM Markets Ltd\t7200\t500\t35.2\t1155.9\t0",
                "T\t900\tEURUSD@\t0\t0.2\t1761300000\t1.161\t1761303600\t1.163\t1.159\t1.159\t1.166\t-1.4\t0\t40\t",
                "B\t1761177700\t1000\tDeposit",
                "D\t5001\t7001\t1761177700\t2\t0\t\t0\t0\t0\t0\t0\t1000\t0\tDeposit",
                "D\t5002\t7002\t1761300000\t0\t0\tEURUSD@\t0.2\t1.161\t-0.7\t0\t0\t0\t900\t",
                "D\t5003\t7003\t1761303600\t1\t1\tEURUSD@\t0.2\t1.163\t-0.7\t0\t0\t40\t900\tsl 1.159 tp 1.166",
                "R\t7002\t1761300000\tEURUSD@\t0\t0.2\t0\t1.161\t1.159\t1.166\t1761300000\t4\t",
                "R\t7010\t1761310000\tXAUUSD@\t2\t0.1\t0.1\t3950\t3940\t3990\t1761320000\t2\tcancelled by me",
                "W\t7020\t1762790000\tGBPUSD@\t3\t0.1\t1.322\t1.33\t1.30\t",
                "M\tM1",
                "END\t2",
            });
            AccountJournal j = JournalFile.Parse(text);
            Check(j != null && j.Complete, "a 3.18 file is complete: its END counts the trades, positions and money lines only");
            Check(j.Leverage == 500 && Math.Abs(j.Margin - 35.2) < 1e-9 && Math.Abs(j.FreeMargin - 1155.9) < 1e-9 && j.Credit == 0 && j.HasStatementData,
                  "leverage, margin, free margin and credit from the account line");
            Equal(3, j.Deals.Count, "every deal of the range");
            JournalDeal exit = j.Deals[2];
            Check(exit.Ticket == 5003 && exit.Order == 7003 && exit.Type == 1 && exit.Entry == 1 && exit.Symbol == "EURUSD@" && exit.Position == 900 &&
                  Math.Abs(exit.Profit - 40) < 1e-9 && Math.Abs(exit.Commission + 0.7) < 1e-9 && exit.Comment == "sl 1.159 tp 1.166", "a deal's fields");
            Check(j.Deals[0].Type == 2 && j.Deals[0].Symbol == "" && Math.Abs(j.Deals[0].Profit - 1000) < 1e-9, "a balance deal has no symbol");
            Equal(2, j.Orders.Count, "the orders of the range");
            JournalOrder cancelled = j.Orders[1];
            Check(cancelled.Type == 2 && cancelled.State == 2 && Math.Abs(cancelled.Price - 3950) < 1e-9 && cancelled.Comment == "cancelled by me" && cancelled.Done > cancelled.Setup,
                  "a cancelled order");
            Check(j.Working.Count == 1 && j.Working[0].Type == 3 && Math.Abs(j.Working[0].VolumeCurrent - 0.1) < 1e-9 && j.Working[0].Done == DateTime.MinValue, "an order still waiting");

            AccountJournal back = JournalFile.Parse(JournalFile.Write(j));
            Check(back.Complete && back.Leverage == 500 && back.Deals.Count == 3 && back.Orders.Count == 2 && back.Working.Count == 1 &&
                  back.Deals[2].Comment == "sl 1.159 tp 1.166" && back.Orders[1].Comment == "cancelled by me", "written and read again unchanged (the cache)");

            // A file of 3.17: no leverage, no deals; still complete and read as before.
            string old = string.Join("\r\n", new[] { "MTR\t1\tMT4\t1492", "A\t2201450\tS\tUSD\t1000\t1000\t1762797600\t1761177600\tC\t7200",
                                                      "T\t1\tEURUSD\t0\t0.1\t1761300000\t1.1\t1761303600\t1.2\t-1\t1.09\t0\t0\t0\t5\t", "END\t1" });
            AccountJournal j4 = JournalFile.Parse(old);
            Check(j4 != null && j4.Complete && j4.Leverage == 0 && !j4.HasStatementData && j4.Deals.Count == 0 && j4.GmtOffset == 7200, "a 3.17 file: read as before, without the statement data");

            // The cache joins an earlier read to a later one: deals and orders before the later read's first day are kept.
            var kept = JournalFile.Parse(text);
            var fresh = JournalFile.Parse(text);
            fresh.From = new DateTime(2025, 10, 24, 12, 0, 0);   // later than the deposit, earlier than the trade
            fresh.Deals.RemoveAt(0);
            fresh.Working.Clear();
            AccountJournal m = JournalCache.Merge(kept, fresh);
            Check(m.Deals.Count == 3 && m.Deals[0].Ticket == 5001, "the deposit deal from the earlier read is kept");
            Check(m.Deals.Count(d => d.Ticket == 5002) == 1, "a deal in both reads counts once");
            Check(m.Working.Count == 0 && m.Leverage == 500, "orders waiting and the account's figures: the later read's");
        }

        /// <summary>3.17.2, end to end with a stand-in MT5: on plain EURUSD it keeps the script waiting (the broker names it
        /// EURUSD@); the run notices within the wait, ends it, and reads the account again on the broker's own name.</summary>
        static void ReportChartRetry()
        {
            string python = new[] { "/usr/bin/python3", "/usr/local/bin/python3" }.FirstOrDefault(File.Exists);
            if (Environment.OSVersion.Platform != PlatformID.Unix || python == null) { Console.WriteLine("  (chart retry: needs a Unix system with python3; left out)"); return; }
            string before = AppPaths.DataDirOverride;
            int wait = ReportLaunch.SymbolWaitSeconds;
            try
            {
                AppPaths.DataDirOverride = Dir("chart-retry", "data");
                ReportLaunch.SymbolWaitSeconds = 3;
                var st = new Settings { BaseDir = Dir("chart-retry", "copies"), ReportAtOnce = 1 };
                // The script counts as built, so no MetaEditor is needed.
                string built = ReportScript.Built(st, Kind.MT5);
                Touch(built, "ex5");
                File.WriteAllText(built + ".stamp", ReportScript.Stamp(ReportScript.SourceText(Kind.MT5)));
                Instance rc = ReportCopies.For(st, Kind.MT5, "WMMarkets-Demo", 1);
                Directory.CreateDirectory(rc.Dir);
                File.WriteAllText(rc.Exe, string.Join("\n", new[]
                {
                    "#!" + python,
                    "import sys, os, time, re",
                    "here = os.path.dirname(os.path.abspath(__file__))",
                    "cfg = [a[8:].strip('\"') for a in sys.argv[1:] if a.lower().startswith('/config:')][0]",
                    "text = open(cfg, 'rb').read().decode('utf-16')",
                    "sym = re.search(r'^Symbol=(.*)$', text, re.M).group(1).strip()",
                    "login = re.search(r'^Login=(.*)$', text, re.M).group(1).strip()",
                    "os.makedirs(os.path.join(here, 'logs'), exist_ok=True)",
                    "log = os.path.join(here, 'logs', time.strftime('%Y%m%d') + '.log')",
                    "def j(src, msg):",
                    "    first = not os.path.exists(log)",
                    "    with open(log, 'ab') as f: f.write(('\\ufeff' if first else '').encode('utf-16-le') + ('AB\\t0\\t%s.000\\t%s\\t%s\\r\\n' % (time.strftime('%H:%M:%S'), src, msg)).encode('utf-16-le'))",
                    "j('Startup', 'successfully initialized from start config \"%s\"' % cfg)",
                    "j('Scripts', 'script MTManagerReport (%s,M1) loaded successfully' % sym)",
                    "time.sleep(0.5)",
                    "j('Network', \"'%s': authorized on WMMarkets-Demo through Access Server LON\" % login)",
                    "sd = os.path.join(here, 'Bases', 'WMMarkets-Demo', 'symbols'); os.makedirs(sd, exist_ok=True)",
                    "open(os.path.join(sd, 'symbols-0001.dat'), 'wb').write(b'\\x01\\x02' + 'Forex\\\\EURUSD@'.encode('utf-16-le') + b'\\x00\\x00' + 'XAUUSD@'.encode('utf-16-le') + b'\\x00\\x00')",
                    "j('Network', \"'%s': terminal synchronized with WM Markets Ltd: 0 positions, 0 orders, 343 symbols, 0 spreads\" % login)",
                    "open(os.path.join(here, 'charts.txt'), 'a').write(sym + '\\n')",
                    "if not sym.endswith('@'):",
                    "    time.sleep(120)",
                    "    sys.exit(0)",
                    // Where the script writes: its OutFile input under MQL5\Files, as MT5 does (one name on this system).
                    "preset = open(os.path.join(here, 'MQL5', 'Presets', 'mtm-report.set'), 'rb').read().decode('utf-16')",
                    "out = os.path.join(here, 'MQL5', 'Files', re.search(r'^OutFile=(.*)$', preset, re.M).group(1).strip())",
                    "os.makedirs(os.path.dirname(out), exist_ok=True)",
                    "open(out + '.step', 'wb').write('start'.encode('utf-16'))",
                    "open(out, 'wb').write(open(os.path.join(here, 'fake-result.txt'), 'rb').read())",
                    "j('Scripts', 'script MTManagerReport (%s,M1) removed' % sym)",
                    "",
                }));
                using (Process chmod = Process.Start(new ProcessStartInfo("chmod", "+x \"" + rc.Exe + "\"") { UseShellExecute = false })) chmod.WaitForExit();

                var result = new AccountJournal { Platform = "MT5", Login = "51230001", Server = "WMMarkets-Demo", Balance = 1000, From = new DateTime(2026, 11, 8), Exported = DateTime.Now, Complete = true };
                result.Trades.Add(new JournalTrade { Ticket = 11, Symbol = "EURUSD@", Open = new DateTime(2026, 11, 9, 9, 0, 0), Close = new DateTime(2026, 11, 9, 9, 40, 0), Profit = 12, SlEntry = 1.05 });
                File.WriteAllText(Path.Combine(rc.Dir, "fake-result.txt"), JournalFile.Write(result), Encoding.Unicode);

                var student = new Instance { Name = "MT5-01", Kind = Kind.MT5, Dir = Dir("chart-retry", "copies", "MT5-01") };
                File.Copy(rc.Exe, student.Exe, true);
                var acc = new Account { Instance = "MT5-01", Trader = "دانشجو", Login = "51230001", Server = "WMMarkets-Demo", Mode = "investor", InvestorEnc = Secret.Protect("Inv12345") };
                var jobs = new List<ReportJob> { new ReportJob { Index = 0, Copy = student, Account = acc, Name = "دانشجو" } };
                var range = ReportRange.Of(RangeKind.Custom, new DateTime(2026, 11, 10), new DateTime(2026, 11, 8), new DateTime(2026, 11, 10));
                var said = new List<string>();
                var runner = new ReportRunner(st, jobs, new List<Instance> { student }, n => acc, range, 1);
                runner.Changed = (k, state, detail) => { lock (said) said.Add(state + " " + detail); };
                DateTime t = DateTime.Now;
                List<ReportRow> rows = runner.Run();
                double took = (DateTime.Now - t).TotalSeconds;
                string charts = File.Exists(Path.Combine(rc.Dir, "charts.txt")) ? File.ReadAllText(Path.Combine(rc.Dir, "charts.txt")).Trim() : "";
                Check(rows[0].Summary != null && rows[0].Error == null && rows[0].Summary.Trades == 1, "read on the second chart: " + (rows[0].Error ?? "ok"));
                Equal("EURUSD\nEURUSD@", charts.Replace("\r", ""), "plain EURUSD first, then the broker's own name from the symbol list it sent");
                Check(said.Any(s => s.Contains("EURUSD") && s.Contains("با نماد دیگر")), "the window is told why it starts again");
                Check(took < ReportLaunch.StartSeconds, "well before the 180-second limit (" + took.ToString("0") + " s)");
                string log = TextFiles.ReadText(AppPaths.LogFile) ?? "";
                Check(log.Contains("kept the script waiting on its EURUSD chart") && log.Contains("after EURUSD"), "the log tells the story");
            }
            finally
            {
                ReportLaunch.SymbolWaitSeconds = wait;
                AppPaths.DataDirOverride = before;
            }
        }

        /// <summary>3.17: sessions with London's and New York's summer time, the server clock, win/loss ratio, win rate and holding time.</summary>
        static void CoachingMetrics()
        {
            Func<int, int, int, int, int, DateTime> g = (y, mo, d, h, mi) => new DateTime(y, mo, d, h, mi, 0);
            Check(!TradeSessions.LondonSummer(g(2026, 3, 29, 0, 59)) && TradeSessions.LondonSummer(g(2026, 3, 29, 1, 0)), "British summer time starts on the last Sunday of March, 01:00 GMT");
            Check(TradeSessions.LondonSummer(g(2026, 10, 25, 0, 59)) && !TradeSessions.LondonSummer(g(2026, 10, 25, 1, 0)), "and ends on the last Sunday of October");
            Check(!TradeSessions.NewYorkSummer(g(2026, 3, 8, 6, 59)) && TradeSessions.NewYorkSummer(g(2026, 3, 8, 7, 0)), "US summer time starts on the second Sunday of March");
            Check(TradeSessions.NewYorkSummer(g(2026, 11, 1, 5, 59)) && !TradeSessions.NewYorkSummer(g(2026, 11, 1, 6, 0)), "and ends on the first Sunday of November");
            var winter = new[] { new { h = 7, m = 30, s = TradeSession.Asia }, new { h = 8, m = 30, s = TradeSession.London }, new { h = 13, m = 30, s = TradeSession.Overlap },
                                 new { h = 17, m = 30, s = TradeSession.NewYork }, new { h = 22, m = 30, s = TradeSession.Asia } };
            foreach (var x in winter) Equal(x.s, TradeSessions.Of(g(2026, 1, 14, x.h, x.m)), "winter " + x.h + ":" + x.m + " GMT");
            var summer = new[] { new { h = 6, m = 30, s = TradeSession.Asia }, new { h = 7, m = 30, s = TradeSession.London }, new { h = 12, m = 30, s = TradeSession.Overlap },
                                 new { h = 16, m = 30, s = TradeSession.NewYork }, new { h = 21, m = 30, s = TradeSession.Asia } };
            foreach (var x in summer) Equal(x.s, TradeSessions.Of(g(2026, 7, 15, x.h, x.m)), "summer " + x.h + ":" + x.m + " GMT");
            Equal("لندن و نیویورک", TradeSessions.Name(TradeSession.Overlap), "the overlap has its own name");

            var ny7 = new AccountJournal { Exported = g(2026, 1, 14, 12, 0), GmtOffset = 7200 };
            ServerClock c = ServerClock.Of(ny7);
            Check(c.NewYorkPlus7 && !c.Assumed, "GMT+2 in winter: the usual New York + 7 clock");
            Equal(g(2026, 7, 15, 12, 0), c.ToGmt(g(2026, 7, 15, 15, 0)), "a summer trade on that clock is three hours ahead of GMT");
            Equal(g(2026, 1, 14, 13, 0), c.ToGmt(g(2026, 1, 14, 15, 0)), "a winter one two hours");
            ServerClock fixedClock = ServerClock.Of(new AccountJournal { Exported = g(2026, 1, 14, 12, 0), GmtOffset = 10800 });
            Check(!fixedClock.NewYorkPlus7 && fixedClock.Fixed == 10800 && fixedClock.ToGmt(g(2026, 7, 15, 15, 0)) == g(2026, 7, 15, 12, 0), "another clock (GMT+3 all year) is used as it is");
            ServerClock unknown = ServerClock.Of(new AccountJournal { Exported = g(2026, 1, 14, 12, 0) });
            Check(unknown.Assumed && unknown.NewYorkPlus7, "no offset known: New York + 7 assumed, and said so");

            var j = new AccountJournal { Platform = "MT5", Login = "51230001", Server = "S", Exported = g(2026, 11, 13, 20, 0), From = g(2026, 11, 7, 0, 0), GmtOffset = 7200, Complete = true };
            AccountJournal back = JournalFile.Parse(JournalFile.Write(j));
            Equal((int?)7200, back.GmtOffset, "the server's offset from GMT kept in the file");
            back = JournalFile.Parse("MTR\t1\tMT5\t4755\r\nA\t1\tS\tUSD\t100\t100\t1700000000\t1699000000\tX\r\nEND\t0\r\n");
            Check(back != null && back.Complete && back.GmtOffset == null, "a file of 3.16 and before: no offset");
            back = JournalFile.Parse("MTR\t1\tMT4\t1440\r\nA\t1\tS\tUSD\t100\t100\t1700000000\t1699000000\tX\t999999\r\nEND\t0\r\n");
            Equal(null, back.GmtOffset, "an offset beyond 14 hours is not one");

            var o = new JournalSummary();
            JournalMath.Outcomes(new[] { 10.0, -5, 0, 20, -15 }, o);
            Check(o.Wins == 2 && o.Losses == 2 && Math.Abs(o.AvgWin - 15) < 1e-9 && Math.Abs(o.AvgLoss - 10) < 1e-9, "wins and losses by net, a zero neither");
            Check(Math.Abs(o.RiskReward - 1.5) < 1e-9 && Math.Abs(o.WinRate - 40) < 1e-9, "average win ÷ average loss, and wins of all closed trades");
            var noLoss = new JournalSummary();
            JournalMath.Outcomes(new[] { 4.0, 6 }, noLoss);
            Check(double.IsNaN(noLoss.RiskReward) && noLoss.WinRate == 100, "no losing trade: no ratio");
            var none = new JournalSummary();
            JournalMath.Outcomes(new double[0], none);
            Check(double.IsNaN(none.WinRate) && double.IsNaN(none.RiskReward), "no trades: neither");
            JournalSummary sample = JournalMath.Summarize(SampleJournal(), new DateTime(2026, 11, 9), new DateTime(2026, 11, 11), new TradeLimits());
            Check(sample.Wins + sample.Losses <= sample.Trades && sample.AvgHold > TimeSpan.Zero, "the sample history has its wins, losses and holding time");

        }
    }
}
