# MetaFactory 3.35.0 preview

- Publish and persist validated native report snapshots immediately, before terminal cleanup. Private report cleanup no longer waits passively for MT5 to exit for ten seconds and has a one-second graceful close budget before owned-process force-close. User/student terminals are never closed by this path.
- MT5 can keep one owned native reporter per worker ready on its broker server. An official IPC fresh login ACK is required before every subsequent account request. A resident read-only MQL script, not a Python reconstruction, exports authoritative native deals, SL/TP and server-clock timestamps. Every result must match a new random request token, login, server, script 1.22 and trade-only mode.
- If a broker/terminal stops the resident script during account changes, or the IPC helper is unavailable/unconfirmed, retire that worker and fall back to the standard cold path. Failed warm reuse is disabled for that private worker/server path for the rest of the batch. Permanent credential rejection is not passed off as a connection timeout.
- Group queued work stably by platform and server while preserving result/student identity. Automatic two-worker reporting is now available on four-thread, approximately 8 GB machines with at least 2.5 GB free. Recheck RAM before every cold reporter start; stop/cancel still applies to all owned warm processes and helpers.
- Remove silent old-script fallback when compilation/deployment fails. Current binaries require a matching source stamp, and production results require the fresh protocol proof. Compilation failures are visible per-account. Previous binaries are preserved only for recovery.
- History stability now tracks total values as well as record count. Remove the extra MT4 minimum startup wait after All History when identity, balance reconciliation and stability checks have already passed. Preserve longer uncertain-history waits and explicitly note unreconciled history; data is not made complete by shortening timeouts.
- Add per-stage elapsed logs and password-free Route/ReadMs/TotalMs columns to automatic result Excel. Warm IPC supplies credentials over stdin, report request files contain only a token, login, server and from-date.
- Prior candle-free trade reports, No SL classification, stop/progress summaries and the existing interface remain. The native checkbox-menu dismissal issue reported by the user was deferred and is not changed in this speed release.

Native Windows MetaEditor compilation, broker behavior and throughput require Windows validation. Linux/Mono logical/UI tests do not establish an actual live-connection speedup.

## Validation

1282 logical assertions and 52 UI checks in each of English and Persian passed; the 11 Python IPC tests passed. The assembly/PE version, installer embedded executable and bundled runtime/probe payloads matched. One pre-existing chart-retry test remains skipped because python3 is unavailable in the Mono test image. Native Windows/broker throughput and MetaEditor MQL compilation were not tested here.
