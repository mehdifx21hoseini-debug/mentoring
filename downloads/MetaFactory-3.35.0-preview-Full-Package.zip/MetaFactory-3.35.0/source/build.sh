#!/bin/sh
# Builds against Microsoft's .NET Framework 4.5 reference assemblies (not Mono's own libraries),
# so the program can only call what really exists in .NET Framework on Windows.
set -e
cd "$(dirname "$0")"
REF=../refasm-dl/x45/build/.NETFramework/v4.5
R="-nostdlib -noconfig -r:$REF/mscorlib.dll -r:$REF/System.dll -r:$REF/System.Core.dll -r:$REF/System.Windows.Forms.dll -r:$REF/System.Drawing.dll -r:$REF/System.Security.dll -r:$REF/System.Xml.dll -r:$REF/System.IO.Compression.dll -r:$REF/System.Web.Extensions.dll"
C="mcs -codepage:utf8 -platform:anycpu -optimize+ $R"
APP="src/Core.cs src/Backup.cs src/Terminal.cs src/Journal.cs src/Coach.cs src/Today.cs src/Report.cs src/Theme.cs src/Install.cs src/Classic.cs src/Fluent.cs src/CopyGrid.cs src/DashboardFeatures.cs src/ReportResults.cs src/ReportPanel.cs src/Ui.cs src/BackupUi.cs src/FormParts.cs src/ReportTextUi.cs src/Student.cs src/Spreadsheet.cs src/StudentDirectory.cs src/ImportCoordinator.cs src/ConnectionProbes.cs src/VerificationQueueUi.cs src/StudentExport.cs src/ImportVisuals.cs src/BulkImport.cs src/BulkImportUi.cs src/Program.cs"
FONTS="-resource:fonts/Vazirmatn-Regular.ttf,Vazirmatn-Regular.ttf -resource:fonts/Vazirmatn-SemiBold.ttf,Vazirmatn-SemiBold.ttf"
# The report scripts go inside the program (MetaEditor builds them on the user's computer the first time).
SCRIPTS="-resource:report/MTManagerReport.mq5,MTManagerReport.mq5 -resource:report/MTManagerReport.mq4,MTManagerReport.mq4 -resource:bridge/runtime-win64.zip,mt5-runtime.zip -resource:bridge/MTManagerLoginProbe.mq4,MTManagerLoginProbe.mq4"
SETUP="src/Core.cs src/Terminal.cs src/Journal.cs src/Theme.cs src/Install.cs src/Classic.cs src/Fluent.cs setup/Setup.cs"
(cd res && llvm-rc -no-preprocess -fo app.res app.rc && llvm-rc -no-preprocess -fo setup.res setup.rc)
$C -target:winexe -win32res:res/app.res -resource:app.ico,app.ico -resource:res/logo.png,logo.png -resource:res/logo-small.png,logo-small.png $FONTS $SCRIPTS -out:MTManager.exe $APP
$C -target:winexe -define:SNAPSHOT -resource:app.ico,app.ico -resource:res/logo.png,logo.png -resource:res/logo-small.png,logo-small.png $FONTS $SCRIPTS -out:snapshot.exe $APP
# Two small files with MT4-like version numbers, for the update-before-start checks.
for b in 1470 1492; do (cd test/fx && llvm-rc -no-preprocess -fo t$b.res t$b.rc) && $C -target:exe -win32res:test/fx/t$b.res -out:test/fx/t$b.exe test/fx/t.cs; done
$C -target:exe -main:MTManager.Tests -resource:app.ico,app.ico -resource:res/logo.png,logo.png -resource:res/logo-small.png,logo-small.png $FONTS $SCRIPTS -out:tests.exe $APP test/Tests.cs test/BackgroundImportTests.cs test/PortableServerTests.cs test/DashboardMasterTests.cs test/ReportRunTests.cs
$C -target:winexe -win32res:res/setup.res -resource:app.ico,app.ico -resource:res/logo.png,logo.png -resource:res/logo-small.png,logo-small.png $FONTS -resource:MTManager.exe,MTManager.exe -resource:setup/Guide-fa.txt,Guide-fa.txt -resource:setup/Guide-en.txt,Guide-en.txt -resource:fonts/Vazirmatn-OFL.txt,Vazirmatn-OFL.txt -out:MTManager-Setup.exe $SETUP
$C -target:winexe -define:SNAPSHOT -resource:app.ico,app.ico -resource:res/logo.png,logo.png -resource:res/logo-small.png,logo-small.png $FONTS -resource:MTManager.exe,MTManager.exe -resource:setup/Guide-fa.txt,Guide-fa.txt -resource:setup/Guide-en.txt,Guide-en.txt -resource:fonts/Vazirmatn-OFL.txt,Vazirmatn-OFL.txt -out:setup-snapshot.exe $SETUP
echo built
