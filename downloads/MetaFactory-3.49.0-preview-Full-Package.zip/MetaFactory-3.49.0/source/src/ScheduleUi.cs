using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace MTManager
{
    /// <summary>Local schedule editor. Saving configures future deliveries; this dialog never sends a report.</summary>
    public sealed class ScheduleDialog : Form
    {
        readonly ScheduleOptions original;
        readonly Panel scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        TableLayoutPanel body;
        readonly Panel channelDetails = new Panel { Dock = DockStyle.Top, AutoSize = true };
        readonly Dictionary<string,TableLayoutPanel> channelPages = new Dictionary<string,TableLayoutPanel>();
        readonly Dictionary<string,DeliveryChannelCard> channelCards = new Dictionary<string,DeliveryChannelCard>();
        readonly Label channelTitle = new Label();
        string selectedChannel;
        readonly CheckBox dailyEnabled = new CheckBox(), telegramEnabled = new DeliveryToggle(), baleEnabled = new DeliveryToggle(), emailEnabled = new DeliveryToggle(), smtpSsl = new CheckBox();
        readonly TextBox time = Box(), telegramToken = Box(true), telegramChat = Box(), baleToken = Box(true), baleChat = Box();
        readonly TextBox smtpHost = Box(), smtpUser = Box(), smtpPassword = Box(true), emailFrom = Box(), emailTo = Box();
        readonly NumericUpDown smtpPort = new NumericUpDown { Minimum = 1, Maximum = 65535 };
        readonly ComboBox platform = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
        readonly Label error = new Label { AutoSize = true };
        readonly Button saveButton = new Button(), cancelButton = new Button();
        readonly List<Label> fullLabels = new List<Label>();
        readonly string telegramPlain, balePlain, smtpPlain;
        public ScheduleOptions Options { get; private set; }

        static TextBox Box(bool secret = false)
        { return new TextBox { UseSystemPasswordChar = secret, RightToLeft = RightToLeft.No, Dock = DockStyle.Fill }; }

        static ScheduleOptions Copy(ScheduleOptions value)
        {
            value = value ?? new ScheduleOptions();
            return new ScheduleOptions {
                Enabled = value.Enabled, Time = value.Time, Platform = value.Platform,
                TelegramEnabled = value.TelegramEnabled, TelegramTokenEnc = value.TelegramTokenEnc, TelegramChatId = value.TelegramChatId,
                BaleEnabled = value.BaleEnabled, BaleTokenEnc = value.BaleTokenEnc, BaleChatId = value.BaleChatId,
                EmailEnabled = value.EmailEnabled, SmtpHost = value.SmtpHost, SmtpPort = value.SmtpPort, SmtpSsl = value.SmtpSsl,
                SmtpUser = value.SmtpUser, SmtpPasswordEnc = value.SmtpPasswordEnc, EmailFrom = value.EmailFrom, EmailTo = value.EmailTo
            };
        }

        public ScheduleDialog(ScheduleOptions options, string lastStatus)
        {
            original = Copy(options); Options = Copy(original);
            Text = Lang.T("ارسال و زمان‌بندی گزارش‌ها", "Report delivery and scheduling");
            Font = Theme.Font; BackColor = Theme.Alt; ForeColor = Theme.Text;
            StartPosition = FormStartPosition.CenterParent; MinimizeBox = false;
            ClientSize = new Size(Theme.S(940), Theme.S(650)); MinimumSize = new Size(Theme.S(700), Theme.S(430));
            RightToLeft = Lang.En ? RightToLeft.No : RightToLeft.Yes;
            scroll.Padding=Theme.Pad(20,16,20,12);scroll.BackColor=Theme.Alt;
            var content=new TableLayoutPanel { Dock=DockStyle.Top,AutoSize=true,ColumnCount=1,Margin=Padding.Empty,Padding=Padding.Empty,RightToLeft=RightToLeft.No };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            scroll.Controls.Add(content);Controls.Add(scroll);
            var heading=new Label{Text=Lang.T("ارسال و زمان‌بندی", "Delivery and scheduling"),Font=Theme.Bold,ForeColor=Theme.Text,AutoSize=true,Margin=Theme.Pad(0,0,0,5)};
            AddContent(content,heading);
            var intro=new Label{Text=Lang.T("کانال‌ها را مستقل از هم فعال کنید؛ ذخیرهٔ تنظیمات گزارشی ارسال نمی‌کند.","Enable channels independently. Saving settings does not send a report."),AutoSize=true,Font=Theme.Small,ForeColor=Theme.Muted,Margin=Theme.Pad(0,0,0,14)};
            AddContent(content,intro);fullLabels.Add(intro);

            body=NewBody();body.Padding=Theme.Pad(18,10,18,10);AddContent(content,body);
            error.ForeColor = Theme.Bad; error.Font = Theme.Small; error.Visible = false; Full(error);
            if (!string.IsNullOrWhiteSpace(lastStatus)) Full(Lang.T("آخرین وضعیت: ", "Last status: ") + lastStatus, Theme.Small, Theme.Muted);
            if (options != null && !string.IsNullOrEmpty(options.LoadError)) Full(options.LoadError, Theme.Small, Theme.Warn);
            Check(dailyEnabled, Lang.T("گزارش و ارسال خودکار روزانه فعال باشد", "Enable daily reports and automatic delivery"), original.Enabled);
            time.Text = original.Time ?? "22:00"; time.MaxLength = 5;time.MaximumSize=new Size(Theme.S(150),0);
            Row(Lang.T("ساعت محلی (HH:mm)", "Local time (HH:mm)"), time);
            platform.Items.AddRange(new object[] { Lang.T("همهٔ حساب‌ها", "All accounts"), "MT4", "MT5" });
            platform.SelectedIndex = string.Equals(original.Platform, "MT4", StringComparison.OrdinalIgnoreCase) ? 1 : string.Equals(original.Platform, "MT5", StringComparison.OrdinalIgnoreCase) ? 2 : 0;
            platform.MaximumSize=new Size(Theme.S(250),0);Row(Lang.T("محدودهٔ حساب‌ها", "Account scope"), platform);

            var cards=new TableLayoutPanel{Dock=DockStyle.Top,Height=Theme.S(112),ColumnCount=3,RightToLeft=RightToLeft.No,Margin=Theme.Pad(0,16,0,16),Padding=Padding.Empty};
            for(int i=0;i<3;i++)cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100f/3));
            cards.RowStyles.Add(new RowStyle(SizeType.Percent,100));AddContent(content,cards);
            AddChannelCard(cards,Lang.En?0:2,"telegram",Lang.T("تلگرام","Telegram"),telegramEnabled,original.TelegramEnabled);
            AddChannelCard(cards,1,"bale",Lang.T("بله","Bale"),baleEnabled,original.BaleEnabled);
            AddChannelCard(cards,Lang.En?2:0,"email",Lang.T("ایمیل","Email"),emailEnabled,original.EmailEnabled);

            channelTitle.Text=Lang.T("تنظیمات تلگرام","Telegram settings");channelTitle.AutoSize=true;channelTitle.Font=Theme.Bold;channelTitle.ForeColor=Theme.Text;channelTitle.Margin=Theme.Pad(0,0,0,8);AddContent(content,channelTitle);
            AddContent(content,channelDetails);
            body=NewChannelPage("bale");
            balePlain = Secret.Unprotect(original.BaleTokenEnc); baleToken.Text = balePlain ?? ""; baleChat.Text = original.BaleChatId ?? "";
            Row(Lang.T("توکن ربات بله", "Bale bot token"), baleToken); Row(Lang.T("شناسهٔ گفتگو / Chat ID", "Chat ID"), baleChat);
            SecretNote(balePlain, original.BaleTokenEnc);EnableFields(baleEnabled, baleToken, baleChat);

            body=NewChannelPage("telegram");
            telegramPlain = Secret.Unprotect(original.TelegramTokenEnc); telegramToken.Text = telegramPlain ?? ""; telegramChat.Text = original.TelegramChatId ?? "";
            Row(Lang.T("توکن ربات تلگرام", "Telegram bot token"), telegramToken); Row(Lang.T("شناسهٔ گفتگو / Chat ID", "Chat ID"), telegramChat);
            SecretNote(telegramPlain, original.TelegramTokenEnc);EnableFields(telegramEnabled, telegramToken, telegramChat);

            body=NewChannelPage("email");
            smtpHost.Text = original.SmtpHost ?? ""; smtpPort.Value = Math.Max(1, Math.Min(65535, original.SmtpPort));smtpPort.MaximumSize=new Size(Theme.S(150),0);
            smtpUser.Text = original.SmtpUser ?? ""; smtpPlain = Secret.Unprotect(original.SmtpPasswordEnc); smtpPassword.Text = smtpPlain ?? "";
            emailFrom.Text = original.EmailFrom ?? ""; emailTo.Text = original.EmailTo ?? "";
            Row(Lang.T("سرور SMTP", "SMTP server"), smtpHost); Row(Lang.T("پورت", "Port"), smtpPort);
            Check(smtpSsl, "TLS / STARTTLS", original.SmtpSsl);
            Row(Lang.T("نام کاربری SMTP", "SMTP username"), smtpUser); Row(Lang.T("رمز SMTP / رمز برنامه", "SMTP / app password"), smtpPassword);
            Row(Lang.T("ایمیل فرستنده", "From email"), emailFrom); Row(Lang.T("ایمیل گیرنده", "To email"), emailTo);
            SecretNote(smtpPlain, original.SmtpPasswordEnc);EnableFields(emailEnabled, smtpHost, smtpPort, smtpSsl, smtpUser, smtpPassword, emailFrom, emailTo);

            var helpButton=new Button{Text=Lang.T("راهنمای زمان‌بندی و نگهداری رمزها ▾","Scheduling and saved credentials ▾"),FlatStyle=FlatStyle.Flat,AutoSize=true,Font=Theme.Small,ForeColor=Theme.Muted,Margin=Theme.Pad(0,12,0,0)};
            helpButton.FlatAppearance.BorderSize=0;AddContent(content,helpButton);
            body=NewBody();body.Visible=false;AddContent(content,body);var help=body;
            Full(Lang.T("این کامپیوتر باید روشن و بیدار باشد و MetaFactory در ساعت تعیین‌شده باز بماند. ساعت برنامه‌ریزی، ساعت محلی همین کامپیوتر است؛ روز معاملات با ساعت سرور بروکر محاسبه می‌شود.",
                "Keep this PC awake and MetaFactory running at the scheduled time. The schedule uses this PC's local clock; the trading day uses each broker's server clock."), Theme.Small, Theme.Muted);
            Full(Lang.T("گزارش همهٔ حساب‌های محدودهٔ انتخابی تهیه و به تمام کانال‌های تیک‌خورده ارسال می‌شود. با فعال‌کردن برنامهٔ روزانه، ارسال خودکار به مقصدهای زیر فعال می‌شود. ذخیرهٔ تنظیمات، گزارش را همین حالا ارسال نمی‌کند.",
                "All accounts in the selected platform scope are reported and sent to every checked channel. Enabling the daily schedule enables automatic delivery to the destinations below. Saving does not send a report now."), Theme.Small, Theme.Muted);
            Full(Lang.T("اگر ساعت گذشته باشد، پس از بازشدن برنامه یا پایان گزارش قبلی، گزارش همین روز یک‌بار اجرا می‌شود؛ روزهای گذشته جبران نمی‌شوند. فعال‌کردن برنامه پس از ساعت تعیین‌شده نیز آن را در بررسی بعدی زمان‌بندی اجرا می‌کند.",
                "If today's time has passed, the report runs once when the app opens or the previous report finishes; earlier days are skipped. Enabling an overdue schedule also starts it at the next schedule check."), Theme.Small, Theme.Muted);
            Full(Lang.T("توکن‌ها و رمزها رمزگذاری‌شده روی همین کامپیوتر ذخیره می‌شوند. مقدار ذخیره‌شده‌ای که ویرایش نکنید حفظ می‌شود.",
                "Tokens and passwords are stored encrypted on this PC. Stored values you do not edit are preserved."), Theme.Small, Theme.Muted);
            helpButton.Click+=(s,e)=>{help.Visible=!help.Visible;FitLabels();};
            var footer = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = Theme.S(68), Padding = Theme.Pad(16, 14),
                FlowDirection = FlowDirection.RightToLeft, RightToLeft=RightToLeft.No, WrapContents = false, BackColor = Theme.Surface };
            saveButton.Text = Lang.T("ذخیرهٔ تغییرات", "Save changes"); cancelButton.Text = Lang.T("انصراف", "Cancel");
            foreach (Button button in new[] { saveButton, cancelButton })
            {
                button.Size = new Size(Theme.S(144), Theme.S(38)); button.Font = Theme.Bold;
                button.FlatStyle = FlatStyle.Flat; button.FlatAppearance.BorderColor = Theme.BorderStrong;
                button.Margin = Theme.Pad(5, 0); button.BackColor = Theme.Surface; button.ForeColor = Theme.Text;
            }
            saveButton.BackColor = Theme.Accent; saveButton.ForeColor = Theme.OnAccent;
            saveButton.Click += SaveClicked; cancelButton.DialogResult = DialogResult.Cancel;
            footer.Controls.Add(saveButton); footer.Controls.Add(cancelButton); Controls.Add(footer);
            AcceptButton = saveButton; CancelButton = cancelButton;
            SelectChannel("telegram");
            Theme.StyleInputs(this);
            foreach(var page in channelPages.Values)Theme.StyleInputs(page);
            scroll.Resize += (s, e) => FitLabels(); FitLabels();
        }

        TableLayoutPanel NewBody()
        {
            var panel=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=2,RightToLeft=RightToLeft.No,GrowStyle=TableLayoutPanelGrowStyle.AddRows,BackColor=Theme.Surface,Padding=Theme.Pad(18,14),Margin=Padding.Empty};
            if(Lang.En){panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(190)));panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));}
            else{panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,Theme.S(190)));}
            return panel;
        }
        TableLayoutPanel NewChannelPage(string key)
        {var panel=NewBody();channelPages[key]=panel;return panel;}
        static void AddContent(TableLayoutPanel host,Control child)
        {int row=host.RowCount++;host.RowStyles.Add(new RowStyle(SizeType.AutoSize));child.Anchor=AnchorStyles.Left|AnchorStyles.Right;if(child is Label){child.RightToLeft=Lang.En?RightToLeft.No:RightToLeft.Yes;((Label)child).TextAlign=Lang.En?ContentAlignment.MiddleLeft:ContentAlignment.MiddleRight;}host.Controls.Add(child,0,row);}
        void AddChannelCard(TableLayoutPanel host,int column,string key,string title,CheckBox enabled,bool value)
        {
            enabled.Checked=value;enabled.Text="";enabled.AutoSize=false;enabled.Size=new Size(Theme.S(42),Theme.S(24));enabled.AccessibleName=Lang.T("ارسال به ","Send to ")+title;
            var card=new DeliveryChannelCard(key,title,enabled){Dock=DockStyle.Fill,Margin=Theme.Pad(column==2?0:5,0,column==0?0:5,0)};
            card.SelectRequested+=()=>SelectChannel(key);channelCards[key]=card;host.Controls.Add(card,column,0);
        }
        void SelectChannel(string key)
        {
            if(selectedChannel==key)return;channelDetails.SuspendLayout();channelDetails.Controls.Clear();channelDetails.Controls.Add(channelPages[key]);selectedChannel=key;
            channelTitle.Text=Lang.T("تنظیمات ","")+ (key=="telegram"?Lang.T("تلگرام","Telegram settings"):key=="bale"?Lang.T("بله","Bale settings"):Lang.T("ایمیل","Email settings"));
            foreach(var card in channelCards)card.Value.Selected=card.Key==key;
            channelDetails.ResumeLayout(true);FitLabels();
        }

        protected override void Dispose(bool disposing)
        {
            if(disposing)foreach(var page in channelPages.Values)if(!page.IsDisposed)page.Dispose();
            base.Dispose(disposing);
        }

        protected override void OnShown(EventArgs e)
        {
            Rectangle area = Screen.FromControl(this).WorkingArea;
            int width = Math.Max(1, area.Width - 20), height = Math.Max(1, area.Height - 20);
            MinimumSize = new Size(Math.Min(MinimumSize.Width, width), Math.Min(MinimumSize.Height, height));
            Size = new Size(Math.Min(Width, width), Math.Min(Height, height));
            Location = new Point(Math.Max(area.Left, Math.Min(Left, area.Right - Width)), Math.Max(area.Top, Math.Min(Top, area.Bottom - Height)));
            base.OnShown(e);
        }

        void Section(string text) { Full(text, Theme.Bold, Theme.Text); }
        void Full(string text, Font font, Color color)
        { Full(new Label { Text = text, Font = font, ForeColor = color, AutoSize = true }); }
        void Full(Label label)
        {
            label.Margin = Theme.Pad(0, 6, 0, 8); label.Anchor = AnchorStyles.Left | AnchorStyles.Right;label.RightToLeft=Lang.En?RightToLeft.No:RightToLeft.Yes;label.TextAlign=Lang.En?ContentAlignment.MiddleLeft:ContentAlignment.MiddleRight;
            int row = body.RowCount++; body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            body.Controls.Add(label, 0, row); body.SetColumnSpan(label, 2); fullLabels.Add(label);
        }
        void Check(CheckBox control, string text, bool value)
        {
            control.Text = text; control.Checked = value; control.AutoSize = true;control.RightToLeft=Lang.En?RightToLeft.No:RightToLeft.Yes;control.Anchor=Lang.En?AnchorStyles.Left:AnchorStyles.Right; control.Margin = Theme.Pad(0, 7, 0, 9);
            int row = body.RowCount++; body.RowStyles.Add(new RowStyle(SizeType.AutoSize)); body.Controls.Add(control, 0, row); body.SetColumnSpan(control, 2);
        }
        void Row(string title, Control control)
        {
            int row = body.RowCount++; body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var label = new Label { Text = title, AutoSize = true,RightToLeft=Lang.En?RightToLeft.No:RightToLeft.Yes,TextAlign=Lang.En?ContentAlignment.MiddleLeft:ContentAlignment.MiddleRight, Anchor = AnchorStyles.Left | AnchorStyles.Right, Margin = Theme.Pad(0, 8, 10, 8) };
            control.Dock = DockStyle.Fill; control.Margin = Theme.Pad(0, 4, 0, 4); control.RightToLeft = RightToLeft.No;
            if(control.MaximumSize.Width>0){control.Dock=DockStyle.None;control.Anchor=Lang.En?AnchorStyles.Left:AnchorStyles.Right;control.Width=control.MaximumSize.Width;}
            body.Controls.Add(label, Lang.En?0:1, row); body.Controls.Add(control, Lang.En?1:0, row);
        }
        void FitLabels()
        {
            int width = Math.Max(Theme.S(260), scroll.ClientSize.Width - Theme.S(84) - SystemInformation.VerticalScrollBarWidth);
            foreach (Label label in fullLabels) label.MaximumSize = new Size(width, 0);
        }
        void SecretNote(string plain, string encrypted)
        {
            if (plain == null && !string.IsNullOrEmpty(encrypted))
                Full(Lang.T("رمز ذخیره‌شده با این کاربر ویندوز باز نمی‌شود؛ برای فعال‌کردن این کانال، مقدار جدید وارد کنید.",
                    "The stored secret cannot be opened by this Windows user; enter a replacement to enable this channel."), Theme.Small, Theme.Warn);
        }
        static void EnableFields(CheckBox enabled, params Control[] fields)
        {
            Action sync = () => { foreach (Control field in fields) field.Enabled = enabled.Checked; };
            enabled.CheckedChanged += (s, e) => sync(); sync();
        }
        static string ProtectedValue(TextBox field, string plain, string encrypted)
        { return field.Text == (plain ?? "") ? encrypted ?? "" : Secret.Protect(field.Text); }

        void SaveClicked(object sender, EventArgs e)
        {
            try
            {
                var candidate = Copy(original);
                candidate.Enabled = dailyEnabled.Checked; candidate.Time = TextUtil.LatinDigits(time.Text.Trim());
                candidate.Platform = platform.SelectedIndex == 1 ? "MT4" : platform.SelectedIndex == 2 ? "MT5" : "All";
                candidate.BaleEnabled = baleEnabled.Checked; candidate.BaleChatId = baleChat.Text.Trim(); candidate.BaleTokenEnc = ProtectedValue(baleToken, balePlain, original.BaleTokenEnc);
                candidate.TelegramEnabled = telegramEnabled.Checked; candidate.TelegramChatId = telegramChat.Text.Trim(); candidate.TelegramTokenEnc = ProtectedValue(telegramToken, telegramPlain, original.TelegramTokenEnc);
                candidate.EmailEnabled = emailEnabled.Checked; candidate.SmtpHost = smtpHost.Text.Trim(); candidate.SmtpPort = (int)smtpPort.Value; candidate.SmtpSsl = smtpSsl.Checked;
                candidate.SmtpUser = smtpUser.Text.Trim(); candidate.SmtpPasswordEnc = ProtectedValue(smtpPassword, smtpPlain, original.SmtpPasswordEnc);
                candidate.EmailFrom = emailFrom.Text.Trim(); candidate.EmailTo = emailTo.Text.Trim();
                // Disabling must remain possible even if a previously saved destination is no longer usable.
                string invalid = candidate.Enabled ? ScheduledDelivery.Validate(candidate) : ScheduledDelivery.StructureProblem(candidate);
                if (invalid != null) { error.Text = invalid; error.Visible = true; scroll.ScrollControlIntoView(error); return; }
                Options = candidate; DialogResult = DialogResult.OK; Close();
            }
            catch
            {
                error.Text = Lang.T("تنظیمات ذخیره نشد؛ رمزگذاری اطلاعات روی این کاربر ویندوز را بررسی کنید.", "Settings could not be saved; check credential encryption for this Windows user.");
                error.Visible = true; scroll.ScrollControlIntoView(error);
            }
        }
    }
    // Paint-only channel identity. Channel selection never changes its independent enable checkbox.
    internal sealed class DeliveryChannelCard : Panel
    {
        readonly string channel,title;readonly CheckBox enabled;bool selected;
        public event Action SelectRequested;
        public bool Selected{get{return selected;}set{selected=value;Invalidate();}}
        public DeliveryChannelCard(string channel,string title,CheckBox enabled)
        {
            this.channel=channel;this.title=title;this.enabled=enabled;DoubleBuffered=true;Cursor=Cursors.Hand;BackColor=Theme.Surface;TabStop=true;AccessibleName=title;
            Controls.Add(enabled);enabled.CheckedChanged+=(s,e)=>Invalidate();Resize+=(s,e)=>PlaceToggle();PlaceToggle();
        }
        void PlaceToggle(){enabled.Location=new Point(Lang.En?Math.Max(Theme.S(10),Width-Theme.S(56)):Theme.S(12),Theme.S(16));}
        protected override void OnClick(EventArgs e){base.OnClick(e);if(SelectRequested!=null)SelectRequested();Focus();}
        protected override void OnKeyDown(KeyEventArgs e){base.OnKeyDown(e);if(e.KeyCode==Keys.Enter || e.KeyCode==Keys.Space){if(SelectRequested!=null)SelectRequested();e.Handled=true;}}
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using(var back=new SolidBrush(selected?Color.FromArgb(237,246,255):Theme.Surface))g.FillRectangle(back,ClientRectangle);
            using(var border=new Pen(selected?Theme.Accent:Theme.BorderStrong,selected?2:1))g.DrawRectangle(border,1,1,Math.Max(0,Width-3),Math.Max(0,Height-3));
            int icon=Theme.S(30),top=Theme.S(15),x=Lang.En?Theme.S(15):Width-Theme.S(46);Color brand=channel=="bale"?Color.FromArgb(0,166,139):Color.FromArgb(35,154,228);
            var rect=new Rectangle(x,top,icon,icon);DeliveryChannelArt.Paint(g,channel,rect,brand);
            int left=Lang.En?Theme.S(15):Theme.S(46),right=Lang.En?Theme.S(46):Theme.S(15);
            var flags=TextFormatFlags.EndEllipsis|TextFormatFlags.SingleLine|TextFormatFlags.VerticalCenter|(Lang.En?TextFormatFlags.Left:TextFormatFlags.Right|TextFormatFlags.RightToLeft);
            TextRenderer.DrawText(g,title,Theme.Bold,new Rectangle(left,Theme.S(50),Math.Max(5,Width-left-right),Theme.S(25)),Theme.Text,flags);
            TextRenderer.DrawText(g,enabled.Checked?Lang.T("فعال برای ارسال","Enabled for delivery"):Lang.T("غیرفعال","Disabled"),Theme.Small,new Rectangle(Theme.S(14),Theme.S(78),Math.Max(5,Width-Theme.S(28)),Theme.S(20)),enabled.Checked?Color.FromArgb(28,129,87):Theme.Muted,flags);
            if(Focused)ControlPaint.DrawFocusRectangle(g,new Rectangle(4,4,Width-8,Height-8));
        }
    }
    internal sealed class DeliveryToggle : CheckBox
    {
        public DeliveryToggle(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);AutoSize=false;Cursor=Cursors.Hand;}
        protected override void OnCheckedChanged(EventArgs e){base.OnCheckedChanged(e);Invalidate();}
        protected override void OnPaint(PaintEventArgs e)
        {
            var g=e.Graphics;g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;g.Clear(Parent==null?Theme.Surface:Parent.BackColor);
            int h=Theme.S(20),w=Theme.S(38),y=(Height-h)/2;
            using(var track=new SolidBrush(Checked?Theme.Accent:Color.FromArgb(178,188,200)))
            {g.FillEllipse(track,0,y,h,h);g.FillEllipse(track,w-h,y,h,h);g.FillRectangle(track,h/2,y,w-h,h);}
            int knob=h-Theme.S(4);using(var white=new SolidBrush(Color.White))g.FillEllipse(white,Checked?w-knob-Theme.S(2):Theme.S(2),y+Theme.S(2),knob,knob);
            if(Focused)ControlPaint.DrawFocusRectangle(g,ClientRectangle);
        }
    }
    internal static class DeliveryChannelArt
    {
        public static void Paint(Graphics g,string channel,Rectangle rect,Color brand)
        {
            var saved=g.Save();g.TranslateTransform(rect.X,rect.Y);g.ScaleTransform(rect.Width/32f,rect.Height/32f);
            using(var brush=new SolidBrush(brand))
            using(var white=new SolidBrush(Color.White))
            using(var pen=new Pen(brand,2))
            {
                if(channel=="email")
                {g.DrawRectangle(pen,2,6,28,20);g.DrawLines(pen,new[]{new Point(3,7),new Point(16,17),new Point(29,7)});}
                else if(channel=="telegram")
                {
                    g.FillEllipse(brush,0,0,32,32);
                    g.FillPolygon(white,new[]{new PointF(6,14),new PointF(26,6),new PointF(22,26),new PointF(15,20),new PointF(11,24),new PointF(12,17)});
                    using(var line=new Pen(brand,1.4f))g.DrawLine(line,12,18,23,9);
                }
                else
                {
                    // A lightweight Bale-inspired bubble/check mark, not a claimed official asset.
                    g.FillEllipse(brush,1,0,30,28);g.FillPolygon(brush,new[]{new Point(6,23),new Point(4,32),new Point(16,26)});
                    using(var check=new Pen(Color.White,3.2f)){check.StartCap=System.Drawing.Drawing2D.LineCap.Round;check.EndCap=System.Drawing.Drawing2D.LineCap.Round;g.DrawLines(check,new[]{new Point(9,13),new Point(14,18),new Point(23,9)});}
                }
            }
            g.Restore(saved);
        }
    }

}
