using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using MTManager;
class DeliveryPremiumSmoke {
 static int checks;
 static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);Console.WriteLine("PASS "+message);}
 static T Field<T>(object o,string name){return (T)o.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(o);}
 static void Select(ScheduleDialog dialog,string name){dialog.GetType().GetMethod("SelectChannel",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(dialog,new object[]{name});}
 static void Pump(){for(int i=0;i<12;i++){Application.DoEvents();Thread.Sleep(35);}}
 static void Shot(Form form,string path){Pump();using(var b=new Bitmap(form.Width,form.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(form.Location,Point.Empty,form.Size);b.Save(path);}}
 [STAThread]static int Main(string[] args){
  try{
   Application.EnableVisualStyles();typeof(Account).Assembly.GetType("MTManager.Theme").GetMethod("Init").Invoke(null,null);
   string output=args[0];Directory.CreateDirectory(output);
   foreach(bool english in new[]{false,true}){
    Lang.En=english;
    var options=new ScheduleOptions{Enabled=false,TelegramEnabled=true,BaleEnabled=true,EmailEnabled=true,Time="22:00",Platform="All",TelegramTokenEnc=Secret.Protect("123456:"+new string('a',35)),TelegramChatId="-100123456789",BaleTokenEnc=Secret.Protect("123456:"+new string('b',35)),BaleChatId="12345",SmtpHost="smtp.example.com",SmtpPort=587,SmtpSsl=true,SmtpUser="reports@example.com",SmtpPasswordEnc=Secret.Protect("synthetic-password"),EmailFrom="reports@example.com",EmailTo="mentor@example.com"};
    using(var dialog=new ScheduleDialog(options,"")){
     dialog.Show();Pump();
     foreach(string channel in new[]{"telegram","bale","email"}){
      Select(dialog,channel);Pump();Shot(dialog,Path.Combine(output,"delivery-"+(english?"en":"fa")+"-"+channel+".png"));
      Check(Field<CheckBox>(dialog,"telegramEnabled").Checked && Field<CheckBox>(dialog,"baleEnabled").Checked && Field<CheckBox>(dialog,"emailEnabled").Checked,"channel navigation preserves all enabled destinations "+(english?"en":"fa")+" "+channel);
     }
     foreach(string name in new[]{"telegramToken","telegramChat","baleToken","baleChat","smtpHost","smtpUser","smtpPassword","emailFrom","emailTo","time"})Check(Field<TextBox>(dialog,name).RightToLeft==RightToLeft.No,"LTR input "+name);
     Check(Field<TextBox>(dialog,"telegramToken").UseSystemPasswordChar && Field<TextBox>(dialog,"baleToken").UseSystemPasswordChar && Field<TextBox>(dialog,"smtpPassword").UseSystemPasswordChar,"secrets masked");
     var toggle=Field<CheckBox>(dialog,"telegramEnabled");bool previous=toggle.Checked;
     toggle.GetType().GetMethod("OnClick",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(toggle,new object[]{EventArgs.Empty});
     Check(toggle.Checked!=previous&&Field<CheckBox>(dialog,"baleEnabled").Checked&&Field<CheckBox>(dialog,"emailEnabled").Checked,"switch click changes only its own destination");
     toggle.GetType().GetMethod("OnClick",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(toggle,new object[]{EventArgs.Empty});
     var save=Field<Button>(dialog,"saveButton");var cancel=Field<Button>(dialog,"cancelButton");
     Check(save.Visible&&cancel.Visible&&save.Bottom<=save.Parent.ClientSize.Height,"fixed footer remains visible");
     Field<CheckBox>(dialog,"dailyEnabled").Checked=true;Field<TextBox>(dialog,"time").Text="99:99";save.PerformClick();Pump();
     Check(dialog.DialogResult!=DialogResult.OK&&Field<Label>(dialog,"error").Visible,"invalid save displays existing validation locally");
     Check(!options.Enabled&&options.Time=="22:00","editing leaves source model intact");
     Field<TextBox>(dialog,"time").Text="۲۲:۳۰";Field<ComboBox>(dialog,"platform").SelectedIndex=2;save.PerformClick();Pump();
     Check(dialog.DialogResult==DialogResult.OK&&dialog.Options.Time=="22:30"&&dialog.Options.Platform=="MT5","existing save normalization and scope preserved");
     Check(dialog.Options.TelegramEnabled&&dialog.Options.BaleEnabled&&dialog.Options.EmailEnabled,"all channels saved together");
     Check(dialog.Options.TelegramTokenEnc==options.TelegramTokenEnc&&dialog.Options.BaleTokenEnc==options.BaleTokenEnc&&dialog.Options.SmtpPasswordEnc==options.SmtpPasswordEnc,"unchanged secret ciphertext preserved");
    }
    using(var dialog=new ScheduleDialog(options,"")){
     dialog.ClientSize=new Size(720,450);dialog.Show();Pump();Select(dialog,"email");Shot(dialog,Path.Combine(output,"delivery-"+(english?"en":"fa")+"-small.png"));
     Check(Field<Panel>(dialog,"scroll").VerticalScroll.Visible,"small view scrolls email options");
     Field<TextBox>(dialog,"time").Text="10:00";Field<Button>(dialog,"cancelButton").PerformClick();Pump();
     Check(dialog.DialogResult==DialogResult.Cancel&&dialog.Options.Time=="22:00","Cancel discards edit");
    }
   }
   Console.WriteLine("DELIVERY PREMIUM PASS "+checks);return 0;
  }catch(Exception e){Console.Error.WriteLine(e);return 1;}
 }
}
