using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MTManager
{
    /// <summary>Submenus share their owner's edge; folder checkboxes can be changed without dismissing the menu.</summary>
    sealed class FluentMenuItem : ToolStripMenuItem
    {
        public bool KeepOpenOnClick;
        bool aligning, alignQueued;
        ToolStripDropDown trackedDrop;
        public FluentMenuItem(string text) : base(text) { }

        internal static Point Adjacent(Rectangle owner, Rectangle row, Size child, Rectangle work, bool rtl)
        {
            int left = owner.Left - child.Width + 1, right = owner.Right - 1;
            bool fitsLeft = left >= work.Left, fitsRight = right + child.Width <= work.Right;
            int x = rtl ? (fitsLeft || !fitsRight ? left : right) : (fitsRight || !fitsLeft ? right : left);
            x = Math.Max(work.Left, Math.Min(x, work.Right - child.Width));
            int y = Math.Max(work.Top, Math.Min(row.Top, work.Bottom - child.Height));
            return new Point(x, y);
        }
        protected override void OnDropDownOpened(EventArgs e)
        {
            base.OnDropDownOpened(e);
            if (trackedDrop != DropDown)
            {
                if (trackedDrop != null) { trackedDrop.LocationChanged -= DropMoved; trackedDrop.SizeChanged -= DropMoved; }
                trackedDrop = DropDown;
                trackedDrop.LocationChanged += DropMoved; trackedDrop.SizeChanged += DropMoved;
            }
            AlignDropDown(); QueueAlignment();
        }
        void DropMoved(object sender, EventArgs e) { if (!aligning) QueueAlignment(); }
        void QueueAlignment()
        {
            if (alignQueued || Owner == null || !Owner.IsHandleCreated || Owner.IsDisposed || !DropDown.Visible) return;
            alignQueued = true;
            // Windows can apply RTL menu placement after DropDownOpened returns. Recheck its final HWND position.
            Owner.BeginInvoke((Action)(() => { alignQueued = false; if (!IsDisposed) AlignDropDown(); }));
        }
        [StructLayout(LayoutKind.Sequential)]
        struct WindowRect { public int Left, Top, Right, Bottom; public Rectangle Bounds { get { return Rectangle.FromLTRB(Left, Top, Right, Bottom); } } }
        [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr window, out WindowRect rect);
        [DllImport("user32.dll", SetLastError = true)] static extern bool SetWindowPos(IntPtr window, IntPtr after, int x, int y, int width, int height, uint flags);
        void AlignDropDown()
        {
            if (aligning || Owner == null || Owner.IsDisposed || !Owner.Visible || !DropDown.Visible) return;
            aligning = true;
            try
            {
                Rectangle owner = Owner.Bounds, child = DropDown.Bounds, row = Owner.RectangleToScreen(Bounds);
                bool windows = Environment.OSVersion.Platform == PlatformID.Win32NT;
                WindowRect actual;
                if (windows && GetWindowRect(Owner.Handle, out actual)) owner = actual.Bounds;
                if (windows && GetWindowRect(DropDown.Handle, out actual)) child = actual.Bounds;
                Point at = Adjacent(owner, row, child.Size, Screen.FromRectangle(row).WorkingArea, RightToLeft == RightToLeft.Yes);
                if (child.Location == at) return;
                // SetWindowPos avoids ToolStrip's second RTL offset. Preserve size, activation and stacking order.
                if (!windows || !SetWindowPos(DropDown.Handle, IntPtr.Zero, at.X, at.Y, 0, 0, 0x0015)) DropDown.Location = at;
            }
            finally { aligning = false; }
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing && trackedDrop != null) { trackedDrop.LocationChanged -= DropMoved; trackedDrop.SizeChanged -= DropMoved; trackedDrop = null; }
            if(disposing && Image!=null){var image=Image;Image=null;image.Dispose();}
            base.Dispose(disposing);
        }
        protected override void OnClick(EventArgs e)
        {
            if (!KeepOpenOnClick) { base.OnClick(e); return; }
            var menus = new List<ToolStripDropDown>();
            for (ToolStripDropDown menu = Owner as ToolStripDropDown; menu != null; menu = menu.OwnerItem == null ? null : menu.OwnerItem.Owner as ToolStripDropDown)
                menus.Add(menu);
            ToolStripDropDownClosingEventHandler keep = (s, args) => { if (args.CloseReason == ToolStripDropDownCloseReason.ItemClicked) args.Cancel = true; };
            foreach (var menu in menus) menu.Closing += keep;
            try { base.OnClick(e); }
            finally
            {
                Action release = () => { foreach (var menu in menus) menu.Closing -= keep; };
                if (Owner != null && Owner.IsHandleCreated && !Owner.IsDisposed) Owner.BeginInvoke(release);
                else release();
            }
        }
    }

    // The parts of the main window in the Windows 11 style ("graphite"): a dark band with the title, the search
    // and the commands; under it, on a light page, warnings, the view tabs and the list in a white rounded card.

    sealed class FluentColors : ProfessionalColorTable
    {
        public override Color MenuBorder { get { return Theme.Mix(Theme.BorderStrong, Color.White, 0.2f); } }
        public override Color ToolStripDropDownBackground { get { return Theme.Surface; } }
        public override Color ImageMarginGradientBegin { get { return Theme.Surface; } }
        public override Color ImageMarginGradientMiddle { get { return Theme.Surface; } }
        public override Color ImageMarginGradientEnd { get { return Theme.Surface; } }
        public override Color SeparatorDark { get { return Theme.Border; } }
        public override Color SeparatorLight { get { return Theme.Surface; } }
        public override Color MenuItemSelected { get { return Theme.Mix(Theme.Hover, Color.Black, 0.03f); } }
        public override Color MenuItemBorder { get { return Color.Transparent; } }
    }

    /// <summary>Menus like Windows 11: white, a thin border, rounded gray highlight inside the edges.</summary>
    sealed class FluentRenderer : ToolStripProfessionalRenderer
    {
        public FluentRenderer() : base(new FluentColors()) { RoundedEdges = false; }

        protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
        {
            if (!e.Item.Selected || !e.Item.Enabled) return;
            var r = new Rectangle(Theme.S(4), 1, e.Item.Width - Theme.S(8), e.Item.Height - 2);
            Theme.Box(e.Graphics, r, Theme.Sf(4), Theme.Mix(Theme.Hover, Color.Black, 0.035f), Color.Transparent);
        }

        protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
        {
            var mi = e.Item as ToolStripMenuItem;
            // 3.26 (CHANGE-007): a note at the item's end («۲ از ۳») is muted; a heading (Tag "head") small and muted.
            bool note = mi != null && !string.IsNullOrEmpty(mi.ShortcutKeyDisplayString) && e.Text == mi.ShortcutKeyDisplayString;
            bool head = (e.Item.Tag as string) == "head";
            e.TextColor = note || head ? Theme.Muted : !e.Item.Enabled ? Theme.Faint : (e.Item.Tag as string) == "danger" ? Theme.Bad
                        : (e.Item.Tag as string) == "accent" ? Theme.AccentText : Theme.Text;
            if (head) e.TextFont = Theme.Small;
            base.OnRenderItemText(e);
        }

        protected override void OnRenderItemImage(ToolStripItemImageRenderEventArgs e)
        {
            if (e.Image == null) return;
            // Drawn as is, also on an item that is turned off (Windows would grey it).
            Rectangle r = e.ImageRectangle;
            e.Graphics.DrawImage(e.Image, new Rectangle(r.X + (r.Width - e.Image.Width) / 2, r.Y + (r.Height - e.Image.Height) / 2, e.Image.Width, e.Image.Height));
        }

        /// <summary>3.26 (CHANGE-007): the icon strip is plain white (Windows drew a shaded strip that broke the separator lines).</summary>
        protected override void OnRenderImageMargin(ToolStripRenderEventArgs e)
        {
            using (var b = new SolidBrush(Theme.Surface)) e.Graphics.FillRectangle(b, e.AffectedBounds);
        }

        protected override void OnRenderSeparator(ToolStripSeparatorRenderEventArgs e)
        {
            int y = e.Item.Height / 2;
            using (var pen = new Pen(Theme.Border)) e.Graphics.DrawLine(pen, Theme.S(6), y, e.Item.Width - Theme.S(6), y);
        }

        protected override void OnRenderArrow(ToolStripArrowRenderEventArgs e)
        {
            e.ArrowColor = Theme.Muted;
            base.OnRenderArrow(e);
        }
    }

    /// <summary>A command on the dark band: flat with a gray fill under the mouse; the main one is light blue.</summary>
    sealed class BandButton : Control
    {
        readonly Glyph icon;
        readonly Color iconColor;
        readonly bool primary;
        bool greenFilled;
        public bool GreenFilled { get { return greenFilled; } set { if(greenFilled!=value){greenFilled=value;Invalidate();} } }
        bool redFilled;
        public bool RedFilled { get { return redFilled; } set { if(redFilled!=value){redFilled=value;Invalidate();} } }
        bool lightSurface;
        public bool LightSurface { get { return lightSurface; } set { if(lightSurface!=value){lightSurface=value;Invalidate();} } }
        bool hover, down, hoverDrop, downInDrop;
        bool split, caret;
        string note;

        /// <summary>3.25: a small part at the end (left) with «▾» that opens a menu (DropClicked) instead of the button's own action.</summary>
        public bool Split { get { return split; } set { split = value; Fit(); Invalidate(); } }
        /// <summary>3.25: «▾» after the text: the whole button opens a menu.</summary>
        public bool Caret { get { return caret; } set { caret = value; Fit(); Invalidate(); } }
        /// <summary>3.25: a muted note after the text (e.g. «۷ دقیقه پیش»), behind a thin line; null or empty: none.</summary>
        public string Note
        {
            get { return note; }
            set
            {
                if (note == value) return;
                note = value;
                Fit();
                Invalidate();
                if (Parent != null) Parent.PerformLayout();
            }
        }
        public event EventHandler DropClicked;
        /// <summary>3.25.1 (approved): the «▾» part is a button of its own, with a small gap where a click does nothing.</summary>
        int DropWidth { get { return split ? Theme.S(primary ? 28 : 30) : 0; } }
        static Color C(int rgb) { return Color.FromArgb((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255); }
        int DropGap { get { return split ? Theme.S(4) : 0; } }
        bool downInGap;

        public BandButton(string text, Glyph icon, Color iconColor, bool primary = false)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            this.icon = icon;
            this.iconColor = iconColor;
            this.primary = primary;
            Text = text;
            Font = primary ? Theme.Bold : Theme.Font;
            Cursor = Cursors.Hand;
            TabStop = true;
            AccessibleRole = AccessibleRole.PushButton;
            AccessibleName = text;
            Fit();
        }

        void Fit()
        {
            Size t = Theme.Measure(Text, Font);
            int pad = Theme.S(primary ? 16 : 12);
            int extra = (string.IsNullOrEmpty(note) ? 0 : Theme.S(19) + Theme.Measure(note, Theme.Small).Width) + (caret ? Theme.S(16) : 0) + DropWidth + DropGap;
            Size = new Size(pad * 2 + Theme.S(16) + Theme.S(8) + t.Width + extra, Theme.S(32));
        }

        /// <summary>A new label (e.g. "اجرای انتخاب‌شده‌ها (۳)"): the button takes its width and the band lays out again.</summary>
        public void SetText(string text)
        {
            if (Text == text) return;
            Text = text;
            AccessibleName = text;
            Fit();
            Invalidate();
            if (Parent != null) Parent.PerformLayout();
        }

        protected override void OnMouseEnter(EventArgs e) { hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { hover = false; hoverDrop = false; down = false; Invalidate(); base.OnMouseLeave(e); }
        /// <summary>3.27: x measured from the button's end side (the left in Persian, the right in English).</summary>
        int EndX(int x) { return Lang.En ? Width - 1 - x : x; }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            bool d = split && EndX(e.X) < DropWidth;
            if (d != hoverDrop) { hoverDrop = d; Invalidate(); }
            base.OnMouseMove(e);
        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                down = true;
                downInDrop = split && EndX(e.X) < DropWidth;
                downInGap = split && EndX(e.X) >= DropWidth && EndX(e.X) < DropWidth + DropGap;
                Focus();
                Invalidate();
            }
            base.OnMouseDown(e);
        }

        /// <summary>A click on the «▾» part opens its menu; anywhere else (and Enter) is the button's own action.</summary>
        protected override void OnClick(EventArgs e)
        {
            if (split && downInGap && e is MouseEventArgs) { downInGap = false; return; }
            if (split && downInDrop && e is MouseEventArgs)
            {
                downInDrop = false;
                if (DropClicked != null) DropClicked(this, EventArgs.Empty);
                return;
            }
            base.OnClick(e);
        }
        protected override void OnMouseUp(MouseEventArgs e) { down = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
        protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }
        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override bool IsInputKey(Keys keyData) { return keyData == Keys.Enter || keyData == Keys.Space || base.IsInputKey(keyData); }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space) { e.Handled = true; OnClick(EventArgs.Empty); }
            base.OnKeyDown(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            bool red=RedFilled&&!primary;
            bool colored=(GreenFilled||RedFilled)&&!primary;
            Color fillAccent=Enabled?(red?C(0xC06464):C(0x4D9B77)):(red?C(0x6B5454):C(0x53605A));
            Color fillInk=Enabled?Color.White:(red?C(0xD0C2C2):C(0xC4CBC7));
            Color BandBack=LightSurface?Theme.Page:Band.CommandColor;
            Color BandText=LightSurface?Theme.Text:Color.White;
            Color BandSub=LightSurface?Theme.Muted:Color.FromArgb(191,196,205);
            Color BandHover=colored?(red?C(0xB45151):C(0x2D9468)):LightSurface?Theme.Hover:Color.FromArgb(58,62,70);
            Color BandDown=colored?(red?C(0x8F3838):C(0x206D4B)):LightSurface?Theme.Neutral:Color.FromArgb(68,73,82);
            Color BandLine=LightSurface?Theme.Border:Color.FromArgb(83,88,98);
            Color BandPrimary=Theme.Accent;
            Color BandPrimaryHover=Theme.AccentHover;
            Color BandPrimaryDown=Theme.AccentDown;
            Color BandPrimaryText=Theme.OnAccent;
            g.Clear(BandBack);
            Color fill, fore;
            if (primary)
            {
                fill = !Enabled ? BandDown : down ? BandPrimaryDown : hover ? BandPrimaryHover : BandPrimary;
                fore = Enabled ? BandPrimaryText : BandSub;
            }
            else
            {
                fill = colored ? (!Enabled?(red?C(0x5A4242):C(0x3C5147)):down?BandDown:hover&&!hoverDrop?BandHover:(red?C(0xA84646):C(0x26845B))) : down ? BandDown : hover ? BandHover : Color.Transparent;
                fore = colored?fillInk:Enabled ? BandText : Theme.Mix(BandSub, BandBack, 0.3f);
            }
            int dropW = DropWidth, offset = dropW + DropGap;
            // 3.27: drawn for right to left and mirrored in English.
            Rectangle cr = ClientRectangle;
            Func<Rectangle, Rectangle> F = r => Theme.Flip(r, cr);
            Func<float, float> MX = v => Lang.En ? Width - v : v;
            if (!split) Theme.Box(g, new Rectangle(0,0,Math.Max(0,Width-1),Math.Max(0,Height-1)), Theme.Sf(6), !colored && LightSurface && !primary && !hover && !down ? Theme.Surface : fill, colored?fillAccent:LightSurface && !primary ? Theme.BorderStrong : Color.Transparent);
            else
            {
                // 3.25.2 (approved «ب»): one thin frame around the button and its «▾», a thin line between them; the «▾» a plain chevron.
                Color frame = colored?fillAccent:LightSurface?Theme.BorderStrong:C(0x4A4A4A);
                if (primary) Theme.Box(g, ClientRectangle, Theme.Sf(4), hoverDrop ? BandPrimary : fill, Color.Transparent);
                else
                {
                    if (hover && !hoverDrop) Theme.Box(g, F(new Rectangle(offset, 1, Width - offset - 1, Height - 2)), Theme.Sf(5), fill, Color.Transparent);
                    Theme.Box(g, new Rectangle(0, 0, Width - 1, Height - 1), Theme.Sf(6), colored?fill:Color.Transparent, frame);
                }
                if(colored)
                    Theme.Box(g, F(new Rectangle(1,1,dropW-1,Height-2)),Theme.Sf(5),!Enabled?(red?C(0x503B3B):C(0x34473E)):down&&downInDrop?BandDown:hoverDrop?BandHover:(red?C(0x913C3C):C(0x206E4B)),Color.Transparent);
                if (!colored && hoverDrop && Enabled)
                    Theme.Box(g, F(new Rectangle(1, 1, dropW - 1, Height - 2)), Theme.Sf(5), primary ? BandPrimaryHover : BandHover, Color.Transparent);
                int lineX = (int)MX(dropW + DropGap / 2);
                using (var pen = new Pen(colored?Color.FromArgb(72,fillInk):primary ? Color.FromArgb(64, BandPrimaryText) : frame)) g.DrawLine(pen, lineX, primary ? Theme.S(7) : 1, lineX, Height - (primary ? Theme.S(7) : 2));
                float cx = MX(dropW / 2f), cy = Height / 2f, w = Theme.Sf(4);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (var pen = new Pen(primary ? BandPrimaryText : colored?fillInk:C(0x9CC9F5), Math.Max(1.4f, Theme.Sf(1.6f))))
                    g.DrawLines(pen, new[] { new PointF(cx - w, cy - w / 2), new PointF(cx, cy + w / 2), new PointF(cx + w, cy - w / 2) });
            }
            if (Focused && ShowFocusCues)
                using (var pen = new Pen(primary ? BandPrimaryText : BandText) { DashStyle = DashStyle.Dot })
                    g.DrawRectangle(pen, Theme.S(3), Theme.S(3), Width - 1 - Theme.S(6), Height - 1 - Theme.S(6));
            int pad = Theme.S(primary ? 16 : 12), iconSize = Theme.S(16);
            // Right to left: the icon first on the right, the text after it.
            var iconRect = new RectangleF(Width - pad - iconSize, (Height - iconSize) / 2f, iconSize, iconSize);
            Glyphs.Draw(g, icon, Theme.Flip(iconRect, cr), primary ? fore : colored?fillInk:Enabled ? (LightSurface?Theme.Muted:Color.White) : fore);
            int textRight = (int)iconRect.X - Theme.S(8), textW = Theme.Measure(Text, Font).Width;
            Theme.Line(g, Text, Font, F(new Rectangle(textRight - textW - 1, 0, textW + 2, Height)), fore);
            int x = textRight - textW;
            if (!string.IsNullOrEmpty(note))
            {
                // «به‌روزرسانی گزارش‌ها | ۷ دقیقه پیش»: a thin line, then the note in a lighter grey.
                int lx = (int)MX(x - Theme.S(9));
                using (var pen = new Pen(Theme.Mix(BandLine, BandSub, 0.35f))) g.DrawLine(pen, lx, Theme.S(10), lx, Height - Theme.S(10));
                int nw = Theme.Measure(note, Theme.Small).Width;
                Theme.Line(g, note, Theme.Small, F(new Rectangle(x - Theme.S(18) - nw, 0, nw + Theme.S(2), Height)), Enabled ? BandSub : fore);
                x -= Theme.S(19) + nw;
            }
            if (caret) Theme.Line(g, "▾", Theme.Small, F(new Rectangle(x - Theme.S(14), 0, Theme.S(12), Height)), BandSub, true);
        }
    }

    /// <summary>3.25 (approved mockup): at the start of the band when students are ticked, «۳ دانشجو انتخاب شده» in a light blue frame.</summary>
    sealed class BandPill : Control
    {
        bool neutralSelection;
        public bool NeutralSelection { get { return neutralSelection; } set { if(neutralSelection!=value){neutralSelection=value;Invalidate();} } }
        public BandPill()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Font = Theme.Bold;
            TabStop = false;
            Fit();
        }

        string link = "";
        bool hoverLink;
        Rectangle linkRect;
        /// <summary>3.26 (CHANGE-017, approved): a small link after the count («انتخاب همه‌ی ۹»); empty: none.</summary>
        public event EventHandler LinkClicked;

        public string Link
        {
            get { return link; }
            set
            {
                value = value ?? "";
                if (value == link) return;
                link = value;
                Fit();
                Invalidate();
                if (Parent != null) Parent.PerformLayout();
            }
        }

        int LinkWidth { get { return link.Length == 0 ? 0 : Theme.Measure(link, Theme.Small).Width + Theme.S(19); } }

        void Fit() { Size = new Size(Theme.S(14 + 16 + 8 + 14) + Theme.Measure(Text ?? "", Font).Width + LinkWidth, Theme.S(32)); }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            bool on = link.Length > 0 && linkRect.Contains(e.Location);
            Cursor = on ? Cursors.Hand : Cursors.Default;
            if (on != hoverLink) { hoverLink = on; Invalidate(); }
        }

        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); if (hoverLink) { hoverLink = false; Invalidate(); } }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            if (e.Button == MouseButtons.Left && link.Length > 0 && linkRect.Contains(e.Location) && LinkClicked != null) LinkClicked(this, EventArgs.Empty);
        }

        public void SetText(string text)
        {
            if (Text == text) return;
            Text = text;
            AccessibleName = text;
            Fit();
            Invalidate();
            if (Parent != null) Parent.PerformLayout();
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Band.CommandColor);
            var r = new Rectangle(0, Theme.S(1), Width - 1, Height - Theme.S(2) - 1);
            Color fill=NeutralSelection?Color.FromArgb(238,240,242):Theme.Mix(Theme.Page,Theme.Accent,0.16f);
            Color border=NeutralSelection?Color.FromArgb(207,211,215):Theme.Accent;
            Color ink=NeutralSelection?Color.FromArgb(39,43,48):Theme.AccentText;
            Color check=NeutralSelection?Color.FromArgb(59,65,72):Theme.Accent;
            Theme.Box(g, r, Theme.Square ? 0 : NeutralSelection?Theme.Sf(4):r.Height / 2f, fill, border);
            int box = Theme.S(16);
            Rectangle cr = ClientRectangle;
            var b = new Rectangle(Width - Theme.S(14) - box, (Height - box) / 2, box, box);
            Rectangle fb = Theme.Flip(b, cr);
            Theme.Box(g, fb, Theme.Sf(3), check, Color.Transparent);
            Glyphs.Draw(g, Glyph.Check, new RectangleF(fb.X + Theme.S(2), fb.Y + Theme.S(2), box - Theme.S(4), box - Theme.S(4)), NeutralSelection?Color.White:Theme.OnAccent);
            int textW = Theme.Measure(Text ?? "", Font).Width;
            int textX = b.X - Theme.S(8) - textW;
            Theme.Line(g, Text, Font, Theme.Flip(new Rectangle(Math.Max(Theme.S(12), textX - Theme.S(2)), 0, textW + Theme.S(4), Height), cr), ink);
            if (link.Length > 0)
            {
                int lw = Theme.Measure(link, Theme.Small).Width;
                int sep = textX - Theme.S(9);
                int sx = Lang.En ? Width - sep : sep;
                using (var pen = new Pen(NeutralSelection?Color.FromArgb(199,203,208):Theme.Mix(Theme.Accent, Theme.Page, 0.45f))) g.DrawLine(pen, sx, Theme.S(9), sx, Height - Theme.S(9));
                linkRect = Theme.Flip(new Rectangle(sep - Theme.S(8) - lw, Theme.S(4), lw + Theme.S(4), Height - Theme.S(8)), cr);
                Color lc = NeutralSelection?(hoverLink?Color.FromArgb(24,28,32):Color.FromArgb(66,71,77)):Theme.AccentText;
                using (var f = new Font(Theme.Small, FontStyle.Underline))
                    TextRenderer.DrawText(g, link, f, linkRect, lc, Theme.Rtl | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter);
            }
            else linkRect = Rectangle.Empty;
        }
    }

    /// <summary>The dark band at the top: the program's mark, title and counts, the search, and the commands under them.</summary>
    sealed class Band : Panel
    {
        internal static readonly Color HeaderColor=Color.FromArgb(0xF7,0xF8,0xFA);
        internal static readonly Color CommandColor=Color.FromArgb(0x2B,0x2E,0x34);
        readonly List<Control> commands = new List<Control>();
        readonly List<Control> headerCommands = new List<Control>();
        readonly List<Point> separators = new List<Point>();
        bool arranging;
        public readonly SearchBox Search;
        string title = "", sub = "";
        int percent = -1;

        public Band(SearchBox search)
        {
            // The search box first: setting the height lays the band out, and the layout places the search box.
            Search = search;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = HeaderColor;
            Controls.Add(search);
            Height = Theme.S(112);
        }

        internal Rectangle BrandLogoBounds{get{return Theme.Flip(new Rectangle(Width-Theme.S(50),Theme.S(12),Theme.S(30),Theme.S(30)),ClientRectangle);}}
        internal int BrandReservedWidth{get{return Math.Min(Math.Max(1,Width),Theme.Measure(title,Theme.Title).Width+Theme.S(84));}}
        internal Rectangle BrandTitleBounds{get{int width=Math.Max(1,Math.Min(Theme.Measure(title,Theme.Title).Width+Theme.S(10),Width-Theme.S(90)));return Theme.Flip(new Rectangle(Width-Theme.S(62)-width,Theme.S(10),width,Theme.S(36)),ClientRectangle);}}
        public string Title { get { return title; } set { if (title != value) { title = value; Invalidate(); } } }
        public string Sub { get { return sub; } set { if (sub != value) { sub = value; PerformLayout(); Invalidate(); } } }

        /// <summary>0-100 shows a thin progress line along the bottom; below 0 hides it.</summary>
        public int Progress { get { return percent; } set { if (percent != value) { percent = value; Invalidate(); } } }

        public T Add<T>(T b) where T : Control
        {
            commands.Add(b);
            var button=b as BandButton;if(button!=null)button.LightSurface=false;
            Controls.Add(b);
            return b;
        }

        public void Separator() { commands.Add(null); }

        /// <summary>Places an existing utility command in the compact graphite header.</summary>
        public void AddHeader(Control command)
        {
            commands.Remove(command);
            if(!headerCommands.Contains(command))headerCommands.Add(command);
            var button=command as BandButton;if(button!=null)button.LightSurface=true;
            if(command.Parent!=this)Controls.Add(command);
            PerformLayout();Invalidate();
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            if(Search==null || arranging)return;
            arranging=true;
            try
            {
                int utilityX=Theme.S(18);
                foreach(var command in headerCommands.Where(c=>c.Visible))
                {
                    command.Location=new Point(Theme.FlipX(utilityX,command.Width,Width),Theme.S(12));
                    utilityX+=command.Width+Theme.S(5);
                }
                int searchLeft=utilityX+Theme.S(20),searchRight=Width-BrandReservedWidth;
                int available=Math.Max(Theme.S(110),searchRight-searchLeft);
                int searchWidth=Math.Min(Theme.S(330),available);
                Search.Bounds=Theme.Flip(new Rectangle(searchLeft+Math.Max(0,(searchRight-searchLeft-searchWidth)/2),Theme.S(12),searchWidth,Theme.S(32)),0,Width);
                int y=Theme.S(62);
                
                separators.Clear();
                int x=Theme.S(18);bool placed=false,line=false;
                foreach(var command in commands)
                {
                    if(command==null){line=placed;continue;}
                    if(!command.Visible)continue;
                    int groupGap=line?Theme.S(8):0;
                    if(placed && x+groupGap+command.Width>Width-Theme.S(16))
                    {x=Theme.S(18);y+=Theme.S(42);placed=false;line=false;}
                    if(line){separators.Add(new Point(x+Theme.S(3),y));x+=Theme.S(8);line=false;}
                    command.Location=new Point(x,y);
                    x+=command.Width+Theme.S(10);placed=true;
                }
                int desired=y+Theme.S(40)+(string.IsNullOrEmpty(sub)?0:Theme.S(21));
                if(Height!=desired)Height=desired;
            }
            finally{arranging=false;}
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g=e.Graphics;g.Clear(Theme.Page);
            using(var fill=new SolidBrush(HeaderColor))g.FillRectangle(fill,0,0,Width,Theme.S(56));
            using(var fill=new SolidBrush(CommandColor))g.FillRectangle(fill,0,Theme.S(56),Width,Math.Max(0,Height-Theme.S(56)-(string.IsNullOrEmpty(sub)?0:Theme.S(21))));
            Rectangle cr=ClientRectangle;
            DrawMark(g,BrandLogoBounds);
            Theme.Line(g,title,Theme.Title,BrandTitleBounds,Theme.BandText);
            using(var pen=new Pen(Theme.Border))
            {
                g.DrawLine(pen,0,Height-1,Width,Height-1);
                foreach(var at in separators)g.DrawLine(pen,at.X,at.Y+Theme.S(6),at.X,at.Y+Theme.S(26));
            }
            if(!string.IsNullOrEmpty(sub))Theme.Line(g,sub,Theme.Small,Theme.Flip(new Rectangle(Theme.S(20),Height-Theme.S(23),Math.Max(1,Width-Theme.S(40)),Theme.S(20)),cr),Theme.Muted);
            if(percent>=0)
            {
                int height=Math.Max(2,Theme.S(2)),width=Width*Math.Min(100,percent)/100;
                using(var track=new SolidBrush(Theme.Border))g.FillRectangle(track,0,Height-height,Width,height);
                using(var fill=new SolidBrush(Theme.Accent))g.FillRectangle(fill,Lang.En?0:Width-width,Height-height,width,height);
            }
        }

        /// <summary>Three stacked terminal windows in light blue tones, the front one with a chart line.</summary>
        static void DrawMark(Graphics g, RectangleF r)
        {
            // 3.22: the MetaFactory logo, a little larger than the drawn mark was.
            RectangleF big = RectangleF.Inflate(r, r.Width * 0.12f, r.Height * 0.12f);
            if (Glyphs.DrawLogoImage(g, big)) return;
            SmoothingMode old = g.SmoothingMode;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float u = r.Width / 34f;
            Func<float, float, float, float, RectangleF> R = (x, y, w, h) => new RectangleF(r.X + x * u, r.Y + y * u, w * u, h * u);
            Color[] fills = { Color.FromArgb(140, 0x60, 0xCD, 0xFF), Color.FromArgb(204, 0x2B, 0x88, 0xD8), Color.FromArgb(0x0F, 0x6C, 0xBD) };
            RectangleF[] boxes = { R(2, 4, 20, 15), R(7, 9, 20, 15), R(12, 14, 20, 15) };
            for (int k = 0; k < 3; k++)
                using (GraphicsPath p = Theme.Round(boxes[k], 2.5f * u))
                using (var b = new SolidBrush(fills[k])) g.FillPath(b, p);
            using (var pen = new Pen(Color.FromArgb(0x0B, 0x12, 0x20), 2 * u) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
                g.DrawLines(pen, new[] { new PointF(r.X + 15 * u, r.Y + 25 * u), new PointF(r.X + 19.5f * u, r.Y + 21 * u), new PointF(r.X + 22.5f * u, r.Y + 23 * u), new PointF(r.X + 28.5f * u, r.Y + 17.5f * u) });
            g.SmoothingMode = old;
        }
    }

    /// <summary>A few views as text tabs (all, active, inactive) with counts; the chosen one underlined.</summary>
    /// <summary>3.23: at the left of the view tabs (approved mockup): «مرتب‌سازی ▾», which arranges the list once, and «همه | MT4 | MT5»,
    /// which shows all copies or those of one platform.</summary>
    sealed class ListTools : Control
    {
        static readonly string[] Keys = { "all", "MT4", "MT5" };
        static string[] Titles { get { return new[] { Lang.T("همه", "All"), "MT4", "MT5" }; } }
        static string SortText { get { return Lang.T("مرتب‌سازی", "Sort"); } }
        string platform = "all";
        Rectangle sortRect;
        readonly Rectangle[] segs = new Rectangle[3];
        // 3.27.2 (CHANGE-021): «معمولی | فشرده» (3.26, CHANGE-005) is gone; the list always has its normal look.
        Point mouse = new Point(-1, -1);

        public event Action<string> PlatformChanged;
        /// <summary>The menu is wanted (a point on the screen under the button's left edge).</summary>
        public event Action<Point> SortWanted;

        public ListTools()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Page;
            Height = Theme.S(40);
            Width = PreferredWidth;
        }

        public string Platform
        {
            get { return platform; }
            set { string v = Array.IndexOf(Keys, value) >= 0 ? value : "all"; if (v != platform) { platform = v; Invalidate(); } }
        }

        int SegWidth(int k) { return Theme.Measure(Titles[k], Theme.SmallBold).Width + Theme.S(26); }

        int SortWidth { get { return Theme.Measure(SortText, Theme.Small).Width + Theme.S(40); } }

        public int PreferredWidth { get { return Theme.S(4) + SortWidth + Theme.S(12) + Enumerable.Range(0, 3).Sum(SegWidth) + Theme.S(16); } }

        void Place()
        {
            int h = Theme.S(30), y = (Height - h) / 2, x = Theme.S(4);
            sortRect = new Rectangle(x, y, SortWidth, h);
            x = sortRect.Right + Theme.S(12);
            for (int k = 0; k < 3; k++) { segs[k] = new Rectangle(x, y, SegWidth(k), h); x += segs[k].Width; }
            if (!Lang.En) return;
            // 3.27, English: from the right end: «Sort», then «All | MT4 | MT5» (read left to right).
            x = Width - Theme.S(4);
            sortRect = new Rectangle(x - SortWidth, y, SortWidth, h);
            x = sortRect.Left - Theme.S(12) - Enumerable.Range(0, 3).Sum(SegWidth);
            for (int k = 0; k < 3; k++) { segs[k] = new Rectangle(x, y, SegWidth(k), h); x += segs[k].Width; }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(BackColor);
            Place();
            bool hover = sortRect.Contains(mouse);
            Theme.Box(g, sortRect, Theme.Sf(6), hover ? Theme.Hover : Theme.Surface, Theme.BorderStrong);
            int chev = Theme.S(10);
            var cr = new RectangleF(sortRect.X + Theme.S(10), sortRect.Y + (sortRect.Height - chev) / 2f, chev, chev);
            Glyphs.Draw(g, Glyph.Chevron, Theme.Flip(cr, sortRect), Theme.Muted);
            Theme.Line(g, SortText, Theme.Small, Theme.Flip(new Rectangle((int)cr.Right + Theme.S(6), sortRect.Y, sortRect.Right - Theme.S(10) - (int)cr.Right - Theme.S(6), sortRect.Height), sortRect), Theme.Text);
            var whole = Rectangle.FromLTRB(segs[0].Left, segs[0].Top, segs[2].Right, segs[0].Bottom);
            Theme.Box(g, whole, Theme.Sf(6), Theme.Surface, Theme.BorderStrong);
            for (int k = 0; k < 3; k++)
            {
                bool on = Keys[k] == platform;
                Rectangle r = segs[k];
                if (on) Theme.Box(g, r, Theme.Sf(6), Band.CommandColor, Band.CommandColor);
                else if (r.Contains(mouse)) using (var b = new SolidBrush(Theme.Hover)) g.FillRectangle(b, r.X + 1, r.Y + 1, r.Width - 2, r.Height - 2);
                if (k > 0 && !on && Keys[k - 1] != platform) using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, r.Left, r.Top + Theme.S(6), r.Left, r.Bottom - Theme.S(6));
                Theme.Line(g, Titles[k], on ? Theme.SmallBold : Theme.Small, r, on ? Theme.OnAccent : Theme.Text, true);
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            mouse = e.Location;
            Place();
            Cursor = sortRect.Contains(mouse) || segs.Any(r => r.Contains(mouse)) ? Cursors.Hand : Cursors.Default;
            Invalidate();
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e) { mouse = new Point(-1, -1); Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            if (e.Button != MouseButtons.Left) return;
            Place();
            if (sortRect.Contains(e.Location)) { if (SortWanted != null) SortWanted(PointToScreen(new Point(sortRect.Left, sortRect.Bottom + Theme.S(4)))); return; }
            for (int k = 0; k < 3; k++)
                if (segs[k].Contains(e.Location) && Keys[k] != platform)
                {
                    platform = Keys[k];
                    Invalidate();
                    if (PlatformChanged != null) PlatformChanged(platform);
                }
        }
    }

    sealed class Pivot : Control
    {
        sealed class Item
        {
            public string Key, Title;
            public int Count;
            public Rectangle Bounds;
        }

        readonly List<Item> items = new List<Item>();
        string selected;
        public event Action<string> Changed;

        public Pivot()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            Height = Theme.S(40);
            TabStop = true;
            AccessibleRole = AccessibleRole.PageTabList;
        }

        public void Add(string key, string title)
        {
            items.Add(new Item { Key = key, Title = title });
            if (selected == null) selected = key;
            Invalidate();
        }

        public string Selected
        {
            get { return selected; }
            set
            {
                if (selected == value || items.All(i => i.Key != value)) return;
                selected = value;
                Invalidate();
                if (Changed != null) Changed(value);
            }
        }

        public void Count(string key, int n)
        {
            Item i = items.FirstOrDefault(x => x.Key == key);
            if (i != null && i.Count != n) { i.Count = n; Invalidate(); }
        }

        Item At(Point p) { return items.FirstOrDefault(i => i.Bounds.Contains(p)); }

        protected override void OnMouseMove(MouseEventArgs e) { Cursor = At(e.Location) != null ? Cursors.Hand : Cursors.Default; base.OnMouseMove(e); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            Item i = At(e.Location);
            if (i != null) Selected = i.Key;
            base.OnMouseClick(e);
        }

        protected override bool IsInputKey(Keys keyData) { return keyData == Keys.Left || keyData == Keys.Right || base.IsInputKey(keyData); }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            int k = items.FindIndex(i => i.Key == selected);
            // Right to left: the next tab is on the left (3.27: on the right in English).
            Keys next = Lang.En ? Keys.Right : Keys.Left, back = Lang.En ? Keys.Left : Keys.Right;
            if (e.KeyCode == next && k < items.Count - 1) Selected = items[k + 1].Key;
            if (e.KeyCode == back && k > 0) Selected = items[k - 1].Key;
            base.OnKeyDown(e);
        }

        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent));
            int x=Width-Theme.S(8),top=Theme.S(4),h=Theme.S(30),pad=Theme.S(10);
            foreach(Item i in items)
            {
                bool on=i.Key==selected;Font f=on?Theme.Bold:Theme.Font;string count=Fa.N(i.Count);
                Size title=Theme.Measure(i.Title,f),number=Theme.Measure(count,Theme.Font);
                int content=title.Width+Theme.S(7)+number.Width,width=content+pad*2;
                var box=new Rectangle(x-width,top,width,h);i.Bounds=Theme.Flip(box,ClientRectangle);
                if(on)Theme.Box(g,i.Bounds,Theme.Sf(6),Band.CommandColor,Color.Transparent);
                Theme.Line(g,i.Title,f,Theme.Flip(new Rectangle(x-pad-title.Width,top,title.Width+1,h),ClientRectangle),on?Color.White:Theme.Muted);
                Theme.Line(g,count,Theme.Font,Theme.Flip(new Rectangle(x-pad-content,top,number.Width+1,h),ClientRectangle),on?Color.FromArgb(219,223,229):Theme.Faint);
                if(on&&Focused&&ShowFocusCues)ControlPaint.DrawFocusRectangle(g,Rectangle.Inflate(i.Bounds,-3,-3));
                x-=width+Theme.S(10);
            }
        }
    }

    /// <summary>The row of folders under the view tabs: "همه‌ی پوشه‌ها", each folder with how many are in it, "بدون پوشه",
    /// and "+ پوشه‌ی جدید". Folders that do not fit go behind a "⋯ N پوشه‌ی دیگر" pill (the chosen one always stays in sight).
    /// Right-click on a folder: its menu (rename, delete, tick its students).</summary>
    /// <summary>The line at the bottom of the main window (3.17): «تعداد کل دانشجویان: X | فعال: Y | انتخاب‌شده: Z».</summary>
    sealed class StatusLine : Control
    {
        string text = "";

        public StatusLine()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Height = Theme.S(28);
            TabStop = false;
        }

        public string Line { get { return text; } set { if (text != value) { text = value ?? ""; Invalidate(); } } }

        string left = "";
        Color dot = Color.Empty;
        /// <summary>3.25.1: the program's version, small, at the far left («نسخه‌ی ۳٫۲۵٫۱»).</summary>
        public string Version = "";

        /// <summary>3.25: at the other end (left): «● آخرین پشتیبان: امروز ۹:۳۰», the dot green, or orange when it is old or missing.</summary>
        public void SetLeft(string text, Color dotColor)
        {
            if (left == (text ?? "") && dot == dotColor) return;
            left = text ?? "";
            dot = dotColor;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.Surface);
            using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, 0, 0, Width, 0);
            // 3.27: in English all mirrored: the counts at the left, the backup and the version at the right.
            Rectangle cr = ClientRectangle;
            int leftW = 0, x0 = Theme.S(24);
            if (Version.Length > 0)
            {
                int vw = Theme.Measure(Version, Theme.Small).Width;
                Theme.Line(g, Version, Theme.Small, Theme.Flip(new Rectangle(x0, 1, vw + Theme.S(2), Height - 1), cr), Theme.Faint);
                x0 += vw + Theme.S(10);
                int lx = Lang.En ? Width - x0 : x0;
                using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, lx, Theme.S(8), lx, Height - Theme.S(8));
                x0 += Theme.S(10);
            }
            if (left.Length > 0)
            {
                int tw = Theme.Measure(left, Theme.Small).Width, d = Theme.S(8);
                // Read right to left: the dot first (at the right), then the words.
                Theme.Line(g, left, Theme.Small, Theme.Flip(new Rectangle(x0, 1, tw + Theme.S(2), Height - 1), cr), Theme.Muted);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (var b = new SolidBrush(dot)) g.FillEllipse(b, Theme.Flip(new RectangleF(x0 + tw + Theme.S(7), (Height - d) / 2f, d, d), cr));
                x0 += tw + d + Theme.S(7);
            }
            leftW = x0 - Theme.S(24) + Theme.S(24);
            Theme.Line(g, text, Theme.Small, Theme.Flip(new Rectangle(Theme.S(24) + leftW, 1, Width - Theme.S(48) - leftW, Height - 1), cr), Theme.Muted);
        }
    }

    sealed class FolderBar : Control
    {
        public const string AllKey = "all", NoneKey = "none", AddKey = "+", MoreKey = "…";

        /// <summary>Gently rounded, like the buttons and the input boxes (3.15.1; before, fully round ends).</summary>
        static float ChipRadius { get { return Theme.Square ? 0 : Theme.Sf(6); } }

        sealed class Item
        {
            public string Key, Title;
            public int Count;
            public Rectangle Bounds;
            public bool Visible;
        }

        readonly List<Item> folders = new List<Item>();
        readonly Item all = new Item { Key = AllKey, Title = FolderStore.AllTitle }, none = new Item { Key = NoneKey, Title = FolderStore.NoneTitle },
                      add = new Item { Key = AddKey, Title = Lang.T("پوشه‌ی جدید", "New folder") }, more = new Item { Key = MoreKey };
        string selected = AllKey;
        Item hover;
        public event Action<string> Changed;
        public event Action AddWanted;
        /// <summary>A folder's own menu was asked for (right-click), at a point on the screen.</summary>
        public event Action<string, Point> FolderMenuWanted;
        /// <summary>The folders that did not fit, to choose from in a menu at a point on the screen.</summary>
        public event Action<List<string>, Point> MoreWanted;
        /// <summary>3.21: the folder's "read again by itself" choice was clicked (its menu opens at a point on the screen).</summary>
        public event Action<Point> AutoWanted;

        /// <summary>3.21: at the far left, the viewed folder's own reading again by itself ("به‌روزرسانی خودکار: هر ۳۰ دقیقه ▾");
        /// null when a folder is not viewed (all, none).</summary>
        public string AutoText;
        public bool AutoOn;
        Rectangle autoBounds;
        bool autoHover;
        public Rectangle AutoBounds { get { return autoBounds; } }

        public FolderBar()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            Height = Theme.S(42);
            TabStop = true;
            AccessibleRole = AccessibleRole.PageTabList;
            AccessibleName = Lang.T("پوشه‌ها", "Folders");
        }

        /// <summary>The folders to show (key "f:id", title, count), and the counts of all and of those in no folder.</summary>
        public void SetFolders(IEnumerable<KeyValuePair<string, string>> list, Func<string, int> count, int total, int unfiled)
        {
            folders.Clear();
            foreach (KeyValuePair<string, string> f in list) folders.Add(new Item { Key = f.Key, Title = f.Value, Count = count(f.Key) });
            all.Count = total;
            none.Count = unfiled;
            if (selected != AllKey && selected != NoneKey && folders.All(f => f.Key != selected)) Select(AllKey);
            Invalidate();
        }

        public string Selected { get { return selected; } set { Select(value); } }

        void Select(string key)
        {
            if (selected == key) return;
            selected = key;
            Invalidate();
            if (Changed != null) Changed(key);
        }

        public string TitleOf(string key)
        {
            Item i = folders.FirstOrDefault(f => f.Key == key);
            return i != null ? i.Title : key == NoneKey ? none.Title : all.Title;
        }

        static string Caption(Item i) { return i.Key == AddKey ? "+  " + i.Title : i.Title; }

        static bool Counted(Item i) { return i.Key != AddKey && i.Key != MoreKey; }

        int WidthOf(Item i)
        {
            int w = Theme.Measure(Caption(i), i.Key == selected ? Theme.SmallBold : Theme.Small).Width + Theme.S(26);
            if (Counted(i)) w += Theme.Measure(Fa.N(i.Count), Theme.Small).Width + Theme.S(7);
            return w;
        }

        /// <summary>Which folders fit, from the right: "all" first, then the folders, then "none" and "+": the chosen folder always.</summary>
        int AutoWidth { get { return AutoText == null ? 0 : Theme.Measure(AutoText, Theme.Small).Width + Theme.S(34); } }

        void Arrange(out List<Item> row)
        {
            int gap = Theme.S(6), room = Width - Theme.S(4) - LabelWidth - (AutoText == null ? 0 : AutoWidth + Theme.S(16));
            int fixedW = WidthOf(all) + WidthOf(none) + WidthOf(add) + gap * 3;
            foreach (Item f in folders) f.Visible = false;
            int used = fixedW;
            Item chosen = folders.FirstOrDefault(f => f.Key == selected);
            if (chosen != null) { chosen.Visible = true; used += WidthOf(chosen) + gap; }
            more.Title = "";
            foreach (Item f in folders)
            {
                if (f.Visible) continue;
                int hidden = folders.Count(x => !x.Visible) - 1;
                more.Title = "⋯  " + Fa.N(Math.Max(1, hidden)) + Lang.T(" پوشه‌ی دیگر", " more folders");
                int moreW = hidden > 0 ? WidthOf(more) + gap : 0;
                if (used + WidthOf(f) + gap + moreW > room) break;
                f.Visible = true;
                used += WidthOf(f) + gap;
            }
            int left = folders.Count(f => !f.Visible);
            more.Title = "⋯  " + Fa.N(left) + Lang.T(" پوشه‌ی دیگر", " more folders");
            row = new List<Item> { all };
            row.AddRange(folders.Where(f => f.Visible));
            if (left > 0) row.Add(more);
            row.Add(none);
            row.Add(add);
        }

        int LabelWidth { get { return Theme.Measure(Lang.T("پوشه‌ها:", "Folders:"), Theme.Small).Width + Theme.S(10); } }

        Item At(Point p)
        {
            foreach (Item i in new[] { all, none, add, more }.Concat(folders))
                if (i.Bounds.Contains(p)) return i;
            return null;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            Item i = At(e.Location);
            bool onAuto = AutoText != null && autoBounds.Contains(e.Location);
            Cursor = i != null || onAuto ? Cursors.Hand : Cursors.Default;
            if (i != hover || onAuto != autoHover) { hover = i; autoHover = onAuto; Invalidate(); }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e) { hover = null; autoHover = false; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            if (AutoText != null && autoBounds.Contains(e.Location) && e.Button == MouseButtons.Left)
            {
                if (AutoWanted != null) AutoWanted(PointToScreen(new Point(Lang.En ? autoBounds.Right : autoBounds.Left, autoBounds.Bottom + Theme.S(2))));
                return;
            }
            Item i = At(e.Location);
            if (i == null) return;
            Point below = PointToScreen(new Point(Lang.En ? i.Bounds.Left : i.Bounds.Right, i.Bounds.Bottom + Theme.S(2)));
            if (e.Button == MouseButtons.Right)
            {
                if (i.Key.StartsWith("f:") && FolderMenuWanted != null) FolderMenuWanted(i.Key, below);
                return;
            }
            if (i == add) { if (AddWanted != null) AddWanted(); }
            else if (i == more) { if (MoreWanted != null) MoreWanted(folders.Where(f => !f.Visible).Select(f => f.Key).ToList(), below); }
            else Select(i.Key);
        }

        /// <summary>Build check and keyboard: the menu of a folder, as if right-clicked.</summary>
        public void ShowMenuOf(string key)
        {
            Item i = folders.FirstOrDefault(f => f.Key == key);
            if (i != null && FolderMenuWanted != null) FolderMenuWanted(key, PointToScreen(new Point(i.Bounds.Right, i.Bounds.Bottom + Theme.S(2))));
        }

        protected override bool IsInputKey(Keys keyData) { return keyData == Keys.Left || keyData == Keys.Right || keyData == Keys.Apps || base.IsInputKey(keyData); }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            List<Item> row;
            Arrange(out row);
            List<Item> keys = row.Where(i => i != add && i != more).ToList();
            int k = keys.FindIndex(i => i.Key == selected);
            Keys next = Lang.En ? Keys.Right : Keys.Left, back = Lang.En ? Keys.Left : Keys.Right;
            if (e.KeyCode == next && k < keys.Count - 1) Select(keys[k + 1].Key);
            if (e.KeyCode == back && k > 0) Select(keys[k - 1].Key);
            if ((e.KeyCode == Keys.Apps || (e.Shift && e.KeyCode == Keys.F10)) && selected.StartsWith("f:")) ShowMenuOf(selected);
            base.OnKeyDown(e);
        }

        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent));
            List<Item> row;
            Arrange(out row);
            foreach (Item i in new[] { all, none, add, more }.Concat(folders)) i.Bounds = Rectangle.Empty;
            int x = Width - Theme.S(2), h = Theme.S(28), top = Theme.S(6);
            Size l = Theme.Measure(Lang.T("پوشه‌ها:", "Folders:"), Theme.Small);
            Rectangle cr = ClientRectangle;
            Theme.Line(g, Lang.T("پوشه‌ها:", "Folders:"), Theme.Small, Theme.Flip(new Rectangle(x - l.Width, top, l.Width + 1, h), cr), Theme.Muted);
            x -= LabelWidth;
            foreach (Item i in row)
            {
                bool on = i.Key == selected;
                Font f = on ? Theme.SmallBold : Theme.Small;
                int w = WidthOf(i);
                i.Bounds = Theme.Flip(new Rectangle(x - w, top, w, h), cr);
                if (i == add)
                {
                    Theme.Box(g, i.Bounds, ChipRadius, i == hover ? Theme.AccentSoft : Theme.BackOf(Parent), Color.Transparent);
                    using (var pen = new Pen(Theme.Mix(Theme.Accent, Theme.Surface, 0.35f)) { DashStyle = DashStyle.Dash })
                    using (GraphicsPath p = Theme.Round(new RectangleF(i.Bounds.X + 0.5f, i.Bounds.Y + 0.5f, i.Bounds.Width - 1, i.Bounds.Height - 1), ChipRadius))
                    {
                        SmoothingMode old = g.SmoothingMode;
                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        g.DrawPath(pen, p);
                        g.SmoothingMode = old;
                    }
                    Theme.Line(g, Caption(i), f, i.Bounds, Theme.AccentText, true);
                }
                else
                {
                    Color fill = on ? Theme.Accent : i == hover ? Theme.Hover : Theme.Surface;
                    Color line = on ? Theme.Accent : Theme.Border;
                    Color fore = on ? Theme.OnAccent : i == none || i == more ? Theme.Muted : Theme.Text;
                    Theme.Box(g, i.Bounds, ChipRadius, fill, line);
                    if (!Counted(i)) Theme.Line(g, Caption(i), f, i.Bounds, fore, true);
                    else
                    {
                        // The name, then (to its left) how many, lighter: "دوره‌ی پاییز ۱۴۰۵   ۳" reads as a name and a count.
                        int tw = Theme.Measure(Caption(i), f).Width, cw = Theme.Measure(Fa.N(i.Count), Theme.Small).Width;
                        int right = i.Bounds.Right - Theme.S(13);
                        Theme.Line(g, Caption(i), f, Theme.Flip(new Rectangle(right - tw - 1, i.Bounds.Y, tw + 2, i.Bounds.Height), i.Bounds), fore);
                        Color countColor = on ? Theme.OnAccent : Theme.Faint;
                        Theme.Line(g, Fa.N(i.Count), Theme.Small, Theme.Flip(new Rectangle(right - tw - Theme.S(7) - cw - 1, i.Bounds.Y, cw + 2, i.Bounds.Height), i.Bounds), countColor);
                    }
                }
                if (on && Focused && ShowFocusCues)
                    using (var pen = new Pen(Theme.Accent) { DashStyle = DashStyle.Dot }) g.DrawRectangle(pen, i.Bounds.X + 2, i.Bounds.Y + 2, i.Bounds.Width - 5, i.Bounds.Height - 5);
                x -= w + Theme.S(6);
            }
            autoBounds = Rectangle.Empty;
            if (AutoText != null)
            {
                // 3.21: the folder's reading again by itself, at the far left: a quiet box, blue when on.
                autoBounds = Theme.Flip(new Rectangle(Theme.S(2), top, AutoWidth, h), cr);
                Color fill = AutoOn ? Theme.AccentSoft : autoHover ? Theme.Hover : Theme.Surface;
                Color line = AutoOn ? Theme.Mix(Theme.Accent, Theme.Surface, 0.55f) : Theme.Border;
                Theme.Box(g, autoBounds, ChipRadius, fill, line);
                int icon = Theme.S(12);
                var ir = new RectangleF(autoBounds.Right - Theme.S(11) - icon, autoBounds.Y + (autoBounds.Height - icon) / 2f, icon, icon);
                Glyphs.Draw(g, Glyph.Refresh, Theme.Flip(ir, autoBounds), AutoOn ? Theme.Accent : Theme.Muted);
                Theme.Line(g, AutoText, Theme.Small, Theme.Flip(new Rectangle(autoBounds.X + Theme.S(8), autoBounds.Y, (int)ir.X - Theme.S(5) - autoBounds.X - Theme.S(8), autoBounds.Height), autoBounds),
                           AutoOn ? Theme.AccentText : Theme.Muted);
            }
        }
    }

    /// <summary>A white card with rounded corners and a thin border; its child (the list) sits inside the corners.</summary>
    sealed class ListCard : Panel
    {
        public ListCard()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Surface;
            // Clear of the rounded corners: the list's square corners stay inside the arc.
            Padding = new Padding(1, Theme.S(4), 1, Theme.S(4));
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Theme.BackOf(Parent));
            Theme.Box(e.Graphics, ClientRectangle, Theme.Sf(8), Theme.Surface, Theme.Border);
        }
    }

    /// <summary>Warnings above the list (Windows 11 "info bars"): icon, text, the fix as a link, and ✕ to hide it for now.</summary>
    sealed class InfoBars : Control
    {
        sealed class Row
        {
            public Issue Issue;
            public Rectangle Bounds, Text, Link, Close;
        }

        readonly List<Row> rows = new List<Row>();
        readonly HashSet<string> hidden = new HashSet<string>();
        List<Issue> all = new List<Issue>();
        Action<Fix> onFix;

        public InfoBars()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Height = 0;
            Visible = false;
        }

        public void Show(IEnumerable<Issue> issues, Action<Fix> fix)
        {
            all = issues.ToList();
            onFix = fix;
            Arrange();
        }

        int Gap { get { return Theme.S(10); } }

        void Arrange()
        {
            rows.Clear();
            int w = Width;
            if (Parent != null && Dock == DockStyle.Top) w = Parent.ClientSize.Width - Parent.Padding.Horizontal;
            int y = 0, pad = Theme.S(12), icon = Theme.S(16), close = Theme.S(28);
            foreach (Issue i in all.Where(x => !hidden.Contains(x.Text)).Take(3))
            {
                var r = new Row { Issue = i };
                int linkW = i.Fix != Fix.None ? Theme.Measure(i.FixText, Theme.Bold).Width + Theme.S(4) : 0;
                int textRight = w - pad - icon - Theme.S(10);
                int textLeft = Theme.S(6) + close + Theme.S(8) + (linkW > 0 ? linkW + Theme.S(16) : 0);
                int textW = Math.Max(Theme.S(100), textRight - textLeft);
                Size t = TextRenderer.MeasureText(i.Text, Theme.Font, new Size(textW, 0), Theme.Rtl | TextFormatFlags.WordBreak);
                int h = Math.Max(Theme.S(40), t.Height + Theme.S(16));
                r.Bounds = new Rectangle(0, y, w, h);
                r.Text = Theme.Flip(new Rectangle(textRight - textW, y, textW, h), 0, w);
                var closeR = new Rectangle(Theme.S(6), y + (h - close) / 2, close, close);
                r.Close = Theme.Flip(closeR, 0, w);
                if (linkW > 0) r.Link = Theme.Flip(new Rectangle(closeR.Right + Theme.S(8), y + (h - Theme.S(28)) / 2, linkW, Theme.S(28)), 0, w);
                rows.Add(r);
                y += h + Gap;
            }
            int height = rows.Count > 0 ? y : 0;
            if (Height != height) Height = height;
            Visible = rows.Count > 0;
            Invalidate();
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (rows.Count == 0 || rows[0].Bounds.Width == Width) return;
            // The new height is set after the parent's layout pass: set inside it, it would be lost.
            if (IsHandleCreated) BeginInvoke((Action)Arrange); else Arrange();
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            bool hand = rows.Any(r => (r.Issue.Fix != Fix.None && r.Link.Contains(e.Location)) || r.Close.Contains(e.Location));
            Cursor = hand ? Cursors.Hand : Cursors.Default;
            base.OnMouseMove(e);
        }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            foreach (Row r in rows)
            {
                if (r.Close.Contains(e.Location)) { hidden.Add(r.Issue.Text); Arrange(); return; }
                if (r.Issue.Fix != Fix.None && r.Link.Contains(e.Location) && onFix != null) { onFix(r.Issue.Fix); return; }
            }
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent));
            int pad = Theme.S(12), icon = Theme.S(16);
            foreach (Row r in rows)
            {
                Theme.Box(g, r.Bounds, Theme.Sf(6), Theme.WarnSoft, Theme.WarnLine);
                var ir = Theme.Flip(new RectangleF(r.Bounds.Right - pad - icon, r.Bounds.Y + (r.Bounds.Height - icon) / 2f, icon, icon), r.Bounds);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (var b = new SolidBrush(Theme.Warn)) g.FillEllipse(b, ir);
                using (var b = new SolidBrush(Color.White))
                {
                    float cx = ir.X + icon / 2f, bar = Math.Max(1.5f, icon * 0.11f);
                    g.FillRectangle(b, cx - bar / 2, ir.Y + icon * 0.22f, bar, icon * 0.36f);
                    g.FillEllipse(b, cx - bar * 0.65f, ir.Y + icon * 0.66f, bar * 1.3f, bar * 1.3f);
                }
                TextRenderer.DrawText(g, r.Issue.Text, Theme.Font, r.Text, Theme.Text, Theme.Rtl | TextFormatFlags.WordBreak | TextFormatFlags.VerticalCenter | Theme.Start);
                if (r.Issue.Fix != Fix.None) Theme.Line(g, r.Issue.FixText, Theme.Bold, r.Link, Theme.Accent, true);
                float s = Theme.Sf(4.5f), cx2 = r.Close.X + r.Close.Width / 2f, cy = r.Close.Y + r.Close.Height / 2f;
                using (var pen = new Pen(Theme.Muted, Math.Max(1f, Theme.Sf(1.2f))))
                {
                    g.DrawLine(pen, cx2 - s, cy - s, cx2 + s, cy + s);
                    g.DrawLine(pen, cx2 + s, cy - s, cx2 - s, cy + s);
                }
            }
        }
    }
}
