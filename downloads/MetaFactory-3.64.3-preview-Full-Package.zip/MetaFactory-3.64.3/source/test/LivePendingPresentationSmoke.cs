using System;using System.IO;using System.Linq;using System.Collections;using System.Reflection;using System.Drawing;using System.Threading;using System.Windows.Forms;using MTManager;
class LivePendingPresentationSmoke
{
 static readonly BindingFlags F=BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic;static readonly Assembly A=typeof(Settings).Assembly;static readonly Type R=A.GetType("MTManager.CopyRow"),P=A.GetType("MTManager.AccountRowPresentation");static int checks;
 static object Get(object o,string n){return o.GetType().GetField(n,F).GetValue(o);}static void Set(object o,string n,object v){o.GetType().GetField(n,F).SetValue(o,v);}static object Call(object o,string n,params object[] args){return o.GetType().GetMethods(F).Single(m=>m.Name==n&&m.GetParameters().Length==args.Length).Invoke(o,args);}static void Check(bool v,string why){if(!v)throw new Exception(why);checks++;Console.WriteLine("PASS "+why);}static void Pump(){for(int k=0;k<4;k++){Application.DoEvents();Thread.Sleep(15);}}
 static LiveFeedSnapshot Feed(Kind kind,DateTime utc,double balance=1100,double profit=25,LiveFeedStatus status=LiveFeedStatus.HistoryPending,string server="Synthetic-Demo",string login="10001",int count=1)
 {
  var frame=Activator.CreateInstance(A.GetType("MTManager.LiveFeedFrame"),true);Set(frame,"Run","synthetic-run");Set(frame,"Sequence",1L);Set(frame,"Revision",1L);Set(frame,"Heartbeat",utc);Set(frame,"Values",new[]{balance,balance+profit,0.0,balance+profit,0.0});Set(frame,"Currency","USD");Set(frame,"State","history-unconfirmed");
  var positions=(IList)Get(frame,"Positions");for(int k=0;k<count;k++)positions.Add(Activator.CreateInstance(typeof(LivePosition),F,null,new object[]{(long)(k+1),"EURUSD",true,.1,utc.AddMinutes(-5),new[]{1.1,0.0,0.0,profit,-2.0,-1.0,1.1,-3.0}},null));
  return (LiveFeedSnapshot)Activator.CreateInstance(typeof(LiveFeedSnapshot),F,null,new object[]{status,"history-history-unconfirmed",kind.ToString(),login,server,frame,null},null);
 }
 static bool Apply(object row,Instance copy,Account account,LiveFeedSnapshot feed,DateTime utc){return (bool)P.GetMethod("ApplyPendingLive",F).Invoke(null,new object[]{row,copy,account,feed,utc});}
 static void Model()
 {
  var now=DateTime.UtcNow;
  foreach(var kind in new[]{Kind.MT4,Kind.MT5})foreach(bool en in new[]{true,false})
  {
   Lang.En=en;var copy=new Instance{Name=kind+"-01",Kind=kind};var account=new Account{Instance=copy.Name,Login="10001",Server="Synthetic-Demo"};var row=Activator.CreateInstance(R,true);Set(row,"AccountBalance","Balance $900.00");Set(row,"AccountDrawdown","Maximum DD 20.00%");Set(row,"AccountInfoTip","old verified history time");
   Check(Apply(row,copy,account,Feed(kind,now),now),"fresh pending heartbeat is accepted "+kind+" "+en);
   Check((bool)Get(row,"TodayLive")&&Get(row,"TodayClosedCount")==null&&Get(row,"TodayNet")==null,"live freshness never certifies closed counts or complete daily net "+kind+" "+en);
   var text=(string)Get(row,"TodayText");Check(text.Contains(kind==Kind.MT4?"20.00":"23.00")&&text.Contains("—")&&text.Contains("Open:"),"floating costs follow unchanged platform rules and unknown total remains dash "+kind+" "+en);
   Check(((string)Get(row,"AccountBalance")).Contains("1,100.00")&&(string)Get(row,"AccountDrawdown")=="Maximum DD 20.00%","fresh balance replaces old value without inventing drawdown "+kind+" "+en);
   Check(((string)Get(row,"TodayAgo")).EndsWith(Fa.N(0)+(en?"s":"ث"))&&((string)Get(row,"TodayTip")).Contains("history-unconfirmed"),"actual receipt age and history failure remain separate "+kind+" "+en);
   Check(((string)Get(row,"TodayTip")).Contains(en?"only floating":"فقط سود")&&((string)Get(row,"AccountInfoTip")).Contains(en?"last verified":"آخرین تاریخچه"),"pending money and historical drawdown are explicitly qualified "+kind+" "+en);
   Apply(row,copy,account,Feed(kind,now.AddSeconds(1),1200,45),now.AddSeconds(1));Check(((string)Get(row,"AccountBalance")).Contains("1,200.00")&&((string)Get(row,"TodayText")).Contains(kind==Kind.MT4?"40.00":"43.00"),"next pulse updates balance and P/L without any history "+kind+" "+en);
   Apply(row,copy,account,Feed(kind,now,count:0),now);Check((int?)Get(row,"TodayOpenCount")==0&&Get(row,"TodayClosedCount")==null&&!((string)Get(row,"TodayText")).Contains("Open:"),"no open positions does not falsely claim zero daily trades "+kind+" "+en);
   foreach(var bad in new[]{Feed(kind,now.AddSeconds(-11)),Feed(kind,now.AddSeconds(6)),Feed(kind,now,server:"Other-Demo"),Feed(kind,now,login:"10002"),Feed(kind,now,status:LiveFeedStatus.Disconnected),Feed(kind,now,status:LiveFeedStatus.Stale),Feed(kind,now,status:LiveFeedStatus.Stopped),Feed(kind==Kind.MT4?Kind.MT5:Kind.MT4,now)})
   {var empty=Activator.CreateInstance(R,true);Check(!Apply(empty,copy,account,bad,now)&&!(bool)Get(empty,"TodayLive"),"stale/future/mismatched/inactive pulse cannot appear live "+kind+" "+en);}
  }
 }
 static void Shot(Form f,string path){f.Location=new Point(10,10);Pump();using(var b=new Bitmap(f.Width,f.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(f.Location,Point.Empty,f.Size);b.Save(path);}}
 [STAThread]static int Main(string[] args)
 {
  string root=Path.Combine(Path.GetTempPath(),"live-pending-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);Directory.CreateDirectory(args[0]);AppPaths.DataDirOverride=root;
  try
  {
   Application.EnableVisualStyles();A.GetType("MTManager.Theme").GetMethod("Init",F).Invoke(null,null);Model();
   var diagnostic=A.GetType("MTManager.LiveAutoStart").GetMethod("HistoryRecoveryDiagnostic",F);string snap=Path.Combine(root,"snapshot.txt"),status=Path.Combine(root,"history-status.txt");File.WriteAllText(status,"MLHIST\t1\nreason=history-balance-mismatch");Check(((string)diagnostic.Invoke(null,new object[]{snap})).Contains("history-balance-mismatch"),"system check includes session-specific recovery reason");File.WriteAllText(status,new string('x',3000));Check((string)diagnostic.Invoke(null,new object[]{snap})=="","oversized diagnostic is bounded");File.Delete(status);Check((string)diagnostic.Invoke(null,new object[]{snap})=="","old reporters without diagnostic file remain compatible");
   foreach(bool en in new[]{true,false})
   {
    Lang.En=en;AppPaths.DataDirOverride=Path.Combine(root,en?"en":"fa");Directory.CreateDirectory(AppPaths.DataDir);var settings=new Settings{BaseDir=Path.Combine(AppPaths.DataDir,"copies"),AutoStart=false,LastBackup=DateTime.Now};var account=new Account{Instance="MT4-01",Trader="Sample student",Login="10001",Server="Synthetic-Demo",Platform="MT4",Mode="investor",InvestorEnc=Secret.Protect("SyntheticOnly9")};var accounts=new AccountStore();accounts.SetQueue(account);accounts.Save();var copy=new Instance{Name=account.Instance,Kind=Kind.MT4,Dir=Path.Combine(settings.BaseDir,account.Instance)};Directory.CreateDirectory(copy.Dir);File.WriteAllText(copy.Exe,"synthetic never executed");
    using(var main=(Form)Activator.CreateInstance(A.GetType("MTManager.MainForm"),F,null,new object[]{settings,accounts},null))
    {
     main.WindowState=FormWindowState.Normal;main.Bounds=new Rectangle(10,10,1300,900);main.Show();Pump();foreach(var field in main.GetType().GetFields(F))if(field.FieldType==typeof(System.Windows.Forms.Timer))((System.Windows.Forms.Timer)field.GetValue(main)).Stop();var grid=(DataGridView)Get(main,"grid");
     var target=LiveMonitorTarget.Create(copy,account);var view=Activator.CreateInstance(A.GetType("MTManager.LiveMonitorView"),true);Set(view,"Target",target);Set(view,"Feed",Feed(Kind.MT4,DateTime.UtcNow));((IDictionary)Get(main,"dashboardRows"))[copy.Name]=view;Call(main,"RefreshGrid",false);var row=grid.Rows[0].Tag;
     Check((bool)Get(row,"TodayLive")&&(bool)Get(row,"TodayNoSl")&&((string)Get(row,"AccountBalance")).Contains("1,100.00"),"actual main page updates partial live balance and No SL without a baseline "+en);
     Check(Get(row,"TodayClosedCount")==null&&Get(row,"TodayNet")==null&&((string)Get(row,"TodayTip")).Contains(en?"only floating":"فقط سود"),"main page never invents historical totals during synchronization "+en);
     Shot(main,Path.Combine(args[0],"live-history-pending-"+en+".png"));Set(view,"Feed",Feed(Kind.MT4,DateTime.UtcNow,1200,45));Call(main,"RefreshGrid",false);row=grid.Rows[0].Tag;Check(((string)Get(row,"AccountBalance")).Contains("1,200.00")&&((string)Get(row,"TodayText")).Contains("40.00"),"main page next heartbeat advances displayed values "+en);
     Set(view,"Feed",Feed(Kind.MT4,DateTime.UtcNow.AddSeconds(-30)));Call(main,"RefreshGrid",false);row=grid.Rows[0].Tag;Check(!(bool)Get(row,"TodayLive")&&!((string)Get(row,"AccountBalance")).Contains("1,200.00"),"expired heartbeat removes live state and live balance override "+en);
     Set(main,"appClosing",true);main.Close();Pump();
    }
   }
   Console.WriteLine("LIVE PENDING PRESENTATION PASS "+checks);return 0;
  }
  catch(Exception error){Console.Error.WriteLine(error);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
