using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace MTManager
{
    // IPC only changes the account of an already-owned report terminal; native MQL keeps authoritative SL/history/time data.
    public sealed class ReportLoginSession : IDisposable
    {
        internal const int IpcPhaseTimeoutMilliseconds = 12000;
        // The helper performs initialize and fresh login sequentially, each with its own
        // timeout. Killing it after 14s used to interrupt valid second-phase logins.
        internal const int ResponseTimeoutMilliseconds = IpcPhaseTimeoutMilliseconds * 2 + 2000;
        readonly Settings settings;
        Process helper;
        Task<string> errors;
        public ReportLoginSession(Settings settings) { this.settings = settings; }
        static bool Dead(Process p) { try { return p == null || p.HasExited; } catch { return true; } }
        public ImportConnection Login(Instance copy, Account account, Func<bool> cancel)
        {
            if (Environment.OSVersion.Platform != PlatformID.Win32NT || !Environment.Is64BitOperatingSystem) return null;
            try
            {
                if (cancel()) throw new OperationCanceledException();
                string runtime = DirectProbe.Runtime(settings, cancel);
                if (Dead(helper))
                {
                    Dispose();
                    helper = Process.Start(TerminalProcessPolicy.Prepare(new ProcessStartInfo(Path.Combine(runtime, "python.exe"), "-I \"" + Path.Combine(runtime, "mt5_check.py") + "\" --serve") { WorkingDirectory = runtime, UseShellExecute = false, CreateNoWindow = true, RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true }, settings));
                    errors = helper.StandardError.ReadToEndAsync();
                }
                Account proof = account.Snapshot(); proof.VerifyToken = Guid.NewGuid().ToString("N");
                Task<string> response = helper.StandardOutput.ReadLineAsync();
                response.ContinueWith(t => { var observed = t.Exception; }, TaskContinuationOptions.OnlyOnFaulted | TaskContinuationOptions.ExecuteSynchronously);
                helper.StandardInput.WriteLine(new JavaScriptSerializer().Serialize(new { terminal = copy.Exe, token = proof.VerifyToken, login = proof.Login, server = proof.Server, password = proof.PasswordForLogin(), timeout = IpcPhaseTimeoutMilliseconds })); helper.StandardInput.Flush();
                var clock = Stopwatch.StartNew();
                while (!response.Wait(100)) { if (cancel()) throw new OperationCanceledException(); if (clock.ElapsedMilliseconds > ResponseTimeoutMilliseconds || Dead(helper)) { Dispose(); return null; } }
                if (cancel()) throw new OperationCanceledException();
                return DirectProbe.PythonReply(response.Result, proof);
            }
            catch (OperationCanceledException) { Dispose(); throw; }
            catch (Exception e) { Log.Write("report IPC login: " + e.GetType().Name); Dispose(); return null; }
        }
        public void Dispose()
        {
            if (helper != null) { try { if (!helper.HasExited) { TerminalCloseAudit.Record(helper,Processes.PathOf(helper),"probe-cleanup");helper.Kill(); helper.WaitForExit(1000); } } catch { } helper.Dispose(); helper = null; }
            if (errors != null) errors.ContinueWith(t => { var observed = t.Exception; }, TaskContinuationOptions.OnlyOnFaulted | TaskContinuationOptions.ExecuteSynchronously);
            errors = null;
        }
    }

    public static class DirectProbe
    {
        public const string RuntimeTag = "python31210-mt56231-numpy1264-probe5-candidates";
        static readonly object buildGate = new object();
        static DateTime mt4RetryAfter = DateTime.MinValue;
        static bool SameLogin(string x, string y) { return (x ?? "").TrimStart('0') == (y ?? "").TrimStart('0'); }
        static bool SameServer(string x, string y) { return string.Equals((x ?? "").Trim(), (y ?? "").Trim(), StringComparison.OrdinalIgnoreCase); }
        public static ImportConnection Marker(string text, Account a)
        {
            string[] fields = (text ?? "").TrimEnd('\r', '\n').Split('\t');
            if (a.VerifyToken.Length != 32 || fields.Length != 6 || fields[0] != "MTMLOGIN" || fields[1] != "1" || fields[2] != a.VerifyToken || !SameLogin(fields[3], a.Login) || !SameServer(fields[4], a.Server) || fields[5] != "connected") return null;
            return new ImportConnection { Connected = true, State = Login.Connected, Reason = Lang.T("ورود حساب مستقیماً توسط متاتریدر تأیید شد.", "Account login was confirmed directly by MetaTrader.") };
        }
        public static ImportConnection PythonReply(string text, Account a)
        {
            try
            {
                var fields = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(text);
                Func<string, string> get = key => fields.ContainsKey(key) ? Convert.ToString(fields[key],System.Globalization.CultureInfo.InvariantCulture) : "";
                if (a.VerifyToken.Length != 32 || get("token") != a.VerifyToken || !SameLogin(get("login"), a.Login) || !SameServer(get("server"), a.Server)) return null;
                string state = get("state");
                if (state == "connected")
                {
                    var result=Marker("MTMLOGIN\t1\t" + a.VerifyToken + "\t" + a.Login + "\t" + a.Server + "\tconnected", a);
                    string symbol=get("symbol"); double close, bid, ask; long tick; int bars;
                    if(get("symbol_status")=="ready" && symbol.Length>0 && symbol.Length<=40 && !symbol.Any(char.IsControl) && !symbol.Contains("<") && !symbol.Contains(">") &&
                        int.TryParse(get("bar_count"),out bars) && bars>0 &&
                        double.TryParse(get("last_close"),System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out close) && close>0 && !double.IsInfinity(close) &&
                        double.TryParse(get("bid"),System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out bid) && bid>0 && !double.IsInfinity(bid) &&
                        double.TryParse(get("ask"),System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out ask) && ask>0 && !double.IsInfinity(ask) &&
                        long.TryParse(get("tick_time"),out tick) && tick>0)
                        result.ValidatedSymbol=symbol;
                    return result;
                }
                if (state == "rejected") return new ImportConnection { State = Login.WrongLogin, Reason = Lang.T("شماره حساب یا رمز توسط سرور رد شد.", "Account or password was rejected by the server.") };
                return new ImportConnection { Retryable = state != "unavailable", Reason = state == "unavailable"
                    ? Lang.T("رابط MT5 روی این ویندوز بارگذاری نشد؛ ویندوز ۶۴ بیتی و نصب بروکر را بررسی کنید.", "MT5 IPC could not load; check 64-bit Windows and broker installation.")
                    : Lang.T("پاسخ قطعی از سرور نرسید؛ اتصال تأیید نشده است.", "The server did not provide a conclusive response; login is unconfirmed.") };
            }
            catch { return null; }
        }
        public static string Runtime(Settings s, Func<bool> cancel)
        {
            lock (buildGate)
            {
                string root = Path.Combine(s.BaseDir, "_MTManager", "runtime", RuntimeTag);
                if (File.Exists(Path.Combine(root, "ready"))) return root;
                if (Directory.Exists(root)) throw new IOException("An incomplete private IPC runtime exists; it was preserved.");
                string temp = root + "." + Guid.NewGuid().ToString("N");
                try
                {
                    Directory.CreateDirectory(temp);
                    using (Stream input = Assembly.GetExecutingAssembly().GetManifestResourceStream("mt5-runtime.zip"))
                    using (var zip = new ZipArchive(input, ZipArchiveMode.Read))
                        foreach (ZipArchiveEntry entry in zip.Entries)
                        {
                            if (cancel()) throw new OperationCanceledException();
                            string target = Path.GetFullPath(Path.Combine(temp, entry.FullName.Replace('/', Path.DirectorySeparatorChar)));
                            if (!target.StartsWith(temp + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Invalid runtime resource.");
                            if (entry.Name.Length == 0) { Directory.CreateDirectory(target); continue; }
                            Directory.CreateDirectory(Path.GetDirectoryName(target));
                            using (var output = File.Create(target)) using (var source = entry.Open()) source.CopyTo(output);
                        }
                    File.WriteAllText(Path.Combine(temp, "ready"), RuntimeTag);
                    Directory.Move(temp, root);
                    return root;
                }
                finally { try { if (Directory.Exists(temp)) Directory.Delete(temp, true); } catch { } }
            }
        }
        public static string Mt4Binary(Settings s, Func<bool> cancel)
        {
            lock (buildGate)
            {
                string dir = Path.Combine(s.BaseDir, "_MTManager", "login-build"); Directory.CreateDirectory(dir);
                string source = Path.Combine(dir, "MTManagerLoginProbe.mq4"), binary = Path.ChangeExtension(source, ".ex4");
                string text;
                using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("MTManagerLoginProbe.mq4"))
                using (var reader = new StreamReader(stream)) text = reader.ReadToEnd();
                string stamp = ReportScript.Stamp(text);
                if (File.Exists(binary) && File.Exists(binary + ".stamp") && File.ReadAllText(binary + ".stamp") == stamp) return binary;
                if (DateTime.UtcNow < mt4RetryAfter) return null;
                mt4RetryAfter = DateTime.UtcNow.AddMinutes(5);
                string editor = StudentImportRuntime.FindWithDeadline(() => ReportScript.FindEditor(Kind.MT4, s), cancel, 10000);
                if (editor == null) return null;
                File.WriteAllText(source, text, Encoding.ASCII);
                if (File.Exists(binary)) File.Delete(binary);
                using (Process process = Process.Start(TerminalProcessPolicy.Prepare(new ProcessStartInfo(editor, "/compile:\"" + source + "\" /log:\"" + source + ".log\"") { UseShellExecute = false, CreateNoWindow = true, WorkingDirectory = Path.GetDirectoryName(editor) }, s)))
                {
                    var clock = Stopwatch.StartNew();
                    try { while (!process.WaitForExit(100)) { if (cancel()) throw new OperationCanceledException(); if (clock.ElapsedMilliseconds > 20000) return null; } }
                    finally { if (!process.HasExited) { try { TerminalCloseAudit.Record(process,Processes.PathOf(process),"probe-cleanup");process.Kill(); process.WaitForExit(1000); } catch { } } }
                }
                if (!File.Exists(binary)) return null;
                File.WriteAllText(binary + ".stamp", stamp); return binary;
            }
        }
    }

    // Each worker owns one private broker/platform terminal. Student terminals are never stopped or borrowed.
    public sealed class DirectAccountVerifier : IAccountVerifier, IIdleAccountVerifier
    {
        readonly Settings settings;
        readonly int slot;
        readonly string sourceDirectory;
        Process terminal, helper;
        Task<string> helperError;
        Task<bool> cleanup;
        DateTime lastUse = DateTime.UtcNow;
        string activeServer = "";
        Instance copy;
        readonly Dictionary<string, string> sources = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public DirectAccountVerifier(Settings settings, int slot,string sourceDirectory=null) { this.settings = settings; this.slot = slot; this.sourceDirectory=sourceDirectory; }
        static bool Exited(Process p) { try { p.Refresh(); return p.HasExited; } catch { return true; } }
        bool StopTerminal()
        {
            if (terminal == null) return true;
            Process owned = terminal;
            bool closed;
            try { int pid = owned.Id; SafeClose.Close(new ProcessTarget(owned, true), id => id == pid, 1, Log.Write); closed = Exited(owned); }
            catch { closed = Exited(owned); }
            if (closed) { owned.Dispose(); terminal = null; }
            return closed;
        }
        void StopHelper()
        {
            if (helper == null) return;
            try { if (!helper.HasExited) { TerminalCloseAudit.Record(helper,Processes.PathOf(helper),"probe-cleanup");helper.Kill(); helper.WaitForExit(1000); } } catch { }
            helper.Dispose(); helper = null;
            if (helperError != null) helperError.ContinueWith(t => { var observed = t.Exception; }, TaskContinuationOptions.OnlyOnFaulted | TaskContinuationOptions.ExecuteSynchronously);
            helperError = null;
        }
        void DrainCleanup()
        {
            if (cleanup == null) return;
            try { cleanup.GetAwaiter().GetResult(); } finally { cleanup = null; }
        }
        public void Idle(bool paused)
        {
            DrainCleanup();
            if (paused || (DateTime.UtcNow - lastUse).TotalSeconds > 5) { StopHelper(); StopTerminal(); }
        }
        Instance Prepare(Account a, Func<bool> cancel)
        {
            DrainCleanup();
            if (cancel()) throw new OperationCanceledException();
            Kind next = StudentDirectory.KindOf(a);
            if (VerificationReuse.CanReuse(copy == null ? Kind.MT4 : copy.Kind, activeServer, next, a.Server, terminal != null && !Exited(terminal))) return copy;
            StopHelper();
            if (!StopTerminal()) throw new IOException("The private verification terminal did not close.");
            Kind kind = StudentDirectory.KindOf(a);
            string key = kind + "|" + a.Server;
            string source;
            if (!sources.TryGetValue(key, out source)) { source = sourceDirectory ?? StudentDirectory.Source(settings, kind, a.Server, cancel); sources[key] = source; }
            if (source == null) throw new UserMessage(kind + " broker terminal is not installed.");
            string hash = ReportScript.Stamp(key).Substring(0, 16);
            copy = new Instance { Name = "verify-" + slot, Kind = kind, Dir = Path.Combine(settings.BaseDir, "_MTManager", "verify-" + slot, kind + "-" + hash) };
            if (Processes.IsRunningNow(copy.Exe)) throw new IOException("A previous private verifier is still running; close it before retrying.");
            StudentDirectory.Prepare(settings, source, copy, cancel);
            // Never authenticate through credentials cached by an earlier account or source installation.
            string config = Path.Combine(copy.Dir, "config");
            if (Directory.Exists(config)) foreach (string f in Directory.GetFiles(config, "accounts.*")) File.Delete(f);
            ChartProfile.UseEmpty(copy, true);
            activeServer = a.Server;
            return copy;
        }
        void Start(string path)
        {
            terminal = Process.Start(TerminalProcessPolicy.Prepare(new ProcessStartInfo(copy.Exe, Launcher.Arguments(copy.Kind, path)) { WorkingDirectory = copy.Dir, UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden }, settings));
            if (terminal == null) throw new IOException("Private terminal did not start.");
            Owned.Add(terminal, copy.Exe);
            try { terminal.PriorityClass = ProcessPriorityClass.BelowNormal; } catch { }
            Native.HideWindowsOf(terminal.Id);
        }
        public ImportConnection Verify(Account a, int milliseconds, Func<bool> cancel, Action<string> stage)
        { return VerifyCore(a,milliseconds,cancel,stage,null); }
        public ImportConnection VerifySymbols(Account a,int milliseconds,Func<bool> cancel,Action<string> stage,string preferred,string[] candidates=null)
        { return VerifyCore(a,milliseconds,cancel,stage,preferred??"",candidates); }
        ImportConnection VerifyCore(Account a,int milliseconds,Func<bool> cancel,Action<string> stage,string preferred,string[] candidates=null)
        {
            if (a.Mode != "investor" && a.Mode != "master") return new ImportConnection { Retryable = false, Reason = "Unknown login mode." };
            if (cancel()) throw new OperationCanceledException();
            string password = a.PasswordForLogin();
            if (string.IsNullOrEmpty(password)) return new ImportConnection { Retryable = false, Reason = Lang.T("رمز ذخیره‌شده خوانده نمی‌شود؛ دوباره وارد کنید.", "Saved password cannot be read; enter it again.") };
            if (PasswordRule.Problem(password) != null) return new ImportConnection { Retryable = false, Reason = Lang.T("رمز ذخیره‌شده قالب معتبری ندارد.", "Saved password has an invalid format.") };
            stage(Lang.T("آماده‌سازی نسخهٔ خصوصی بررسی…", "Preparing private verification terminal…"));
            Prepare(a, cancel);
            return copy.Kind == Kind.MT5 ? Mt5(a, password, milliseconds, cancel, stage,preferred,candidates) : Mt4(a, password, milliseconds, cancel, stage);
        }
        // The IPC SDK starts only this worker's reserved copy. Never adopt a student's process.
        void AdoptIpcTerminal()
        {
            if(terminal!=null && !Exited(terminal))return;
            if(terminal!=null){terminal.Dispose();terminal=null;}
            var running=Processes.Running();
            try
            {
                Process found;
                if(running.TryGetValue(copy.Exe.ToLowerInvariant(),out found))
                {
                    terminal=found;running.Remove(copy.Exe.ToLowerInvariant());
                    Owned.Add(terminal,copy.Exe);
                    try{terminal.PriorityClass=ProcessPriorityClass.BelowNormal;}catch{}
                    Native.HideWindowsOf(terminal.Id);
                }
            }
            finally{foreach(var process in running.Values)process.Dispose();}
        }
        void EnsureHelper(string runtime)
        {
            if (helper != null && !Exited(helper)) return;
            StopHelper();
            helper = Process.Start(TerminalProcessPolicy.Prepare(new ProcessStartInfo(Path.Combine(runtime, "python.exe"), "-I \"" + Path.Combine(runtime, "mt5_check.py") + "\" --serve") {
                WorkingDirectory = runtime, UseShellExecute = false, CreateNoWindow = true, RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true }, settings));
            if (helper == null) throw new IOException("Private IPC helper did not start.");
            helperError = helper.StandardError.ReadToEndAsync();
        }
        ImportConnection Mt5(Account a, string password, int timeout, Func<bool> cancel, Action<string> stage,string preferred,string[] candidates)
        {
            if (!Environment.Is64BitOperatingSystem) return new ImportConnection { Retryable = false, Reason = "MT5 IPC requires 64-bit Windows." };
            string runtime = DirectProbe.Runtime(settings, cancel), start = Path.Combine(copy.Dir, Launcher.StartFileName);
            bool retain = false, warm = terminal != null && !Exited(terminal), ipcStartup=preferred!=null;
            bool ipcRequested=false;
            try
            {
                if (cancel()) throw new OperationCanceledException();
                if (!ipcStartup && (terminal == null || Exited(terminal)))
                {
                    // Legacy login verification startup is unchanged. Symbol probes start through authenticated IPC.
                    File.WriteAllLines(start, new[] { "[Common]", "KeepPrivate=0", "[Experts]", "AllowLiveTrading=0", "AllowDllImport=0", "[Charts]", "ProfileLast=" + ChartProfile.EmptyName, "MaxBars=500" }, Encoding.Unicode);
                    Start(start);
                }
                EnsureHelper(runtime);
                Task<string> output = helper.StandardOutput.ReadLineAsync();
                output.ContinueWith(t => { var observed = t.Exception; }, TaskContinuationOptions.OnlyOnFaulted | TaskContinuationOptions.ExecuteSynchronously);
                var clock = Stopwatch.StartNew();
                ipcRequested=ipcStartup;
                helper.StandardInput.WriteLine(new JavaScriptSerializer().Serialize(new { terminal = copy.Exe, token = a.VerifyToken, login = a.Login, server = a.Server, password = password, timeout = timeout, action = preferred==null?"login":"symbols", preferred = preferred, candidates = candidates }));
                helper.StandardInput.Flush();
                while (!output.Wait(100))
                {
                    if (cancel()) throw new OperationCanceledException();
                    if(ipcStartup && terminal==null)AdoptIpcTerminal();
                    if(terminal!=null)Native.HideWindowsOf(terminal.Id);
                    if (clock.ElapsedMilliseconds > 10000) Launcher.DeleteStartFile(start);
                    if (clock.ElapsedMilliseconds > timeout || (terminal!=null && Exited(terminal)) || Exited(helper)) return TimedOut();
                    stage(Lang.T("منتظر تأیید مستقیم MT5: ", "Waiting for direct MT5 acknowledgement: ") + clock.ElapsedMilliseconds / 1000 + "s");
                }
                if (cancel()) throw new OperationCanceledException();
                if(ipcStartup)AdoptIpcTerminal();
                ImportConnection result = DirectProbe.PythonReply(output.Result, a);
                if(preferred!=null && result!=null && result.Connected && result.ValidatedSymbol==null)
                {
                    var raw=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(output.Result);
                    var counts=new[]{"catalogue_count","attempted","no_quote","no_bars","bad_bars","disabled","symbol_status","reason"};
                    result.Reason="symbol-check "+string.Join(" ",counts.Where(raw.ContainsKey).Select(k=>k+"="+Convert.ToString(raw[k],System.Globalization.CultureInfo.InvariantCulture)));
                }
                // Every account still needs a fresh explicit login ACK. Only the owned processes are reused.
                retain = result != null && (result.Connected || result.State == Login.WrongLogin) && terminal!=null && !Exited(terminal) && !Exited(helper);
                lastUse = DateTime.UtcNow;
                Log.Write("verification MT5 acknowledged in " + clock.ElapsedMilliseconds + " ms; warm=" + warm + "; retained=" + retain);
                return result ?? TimedOut();
            }
            finally
            {
                if (!retain)
                {
                    StopHelper();
                    // SDK startup may complete before its JSON response (including cancellation/failure).
                    if(ipcRequested)AdoptIpcTerminal();
                    StopTerminal();
                }
                Launcher.DeleteStartFile(start);
            }
        }
        static ImportConnection TimedOut() { return new ImportConnection { Reason = Lang.T("پاسخ قطعی در مهلت کوتاه نرسید؛ این حساب مانع بررسی بقیه نمی‌شود.", "No conclusive response within the check budget; other accounts will continue.") }; }
        ImportConnection Mt4(Account a, string password, int timeout, Func<bool> cancel, Action<string> stage)
        {
            string binary = DirectProbe.Mt4Binary(settings, cancel);
            string start = Path.Combine(copy.Dir, Launcher.StartFileName), markerName = "mtm-login-" + a.VerifyToken + ".txt";
            string marker = Path.Combine(copy.Dir, "MQL4", "Files", markerName);
            var lines = Launcher.StartLines(Kind.MT4, a, password, true);
            lines.RemoveAll(l => l.StartsWith("KeepPrivate=")); lines.Add("KeepPrivate=false"); lines.Add("ExpertsTrades=false"); lines.Add("ExpertsDllImport=false");
            if (binary != null)
            {
                string script = Path.Combine(copy.Dir, "MQL4", "Scripts", Path.GetFileName(binary)); Directory.CreateDirectory(Path.GetDirectoryName(script)); File.Copy(binary, script, true);
                string[] presets = { "ExpectedLogin=" + a.Login, "ExpectedServer=" + a.Server, "Token=" + a.VerifyToken, "OutFile=" + markerName };
                foreach (string dir in new[] { Path.Combine(copy.Dir, "MQL4", "Presets"), Path.Combine(copy.Dir, "presets") }) { Directory.CreateDirectory(dir); File.WriteAllLines(Path.Combine(dir, "mtm-login.set"), presets, Encoding.Default); }
                var source = new Instance { Kind = Kind.MT4, Dir = sources[Kind.MT4 + "|" + a.Server] };
                string symbol = ReportLaunch.PickSymbol(null, ReportLaunch.KnownSymbols(source, a.Server).Concat(ReportLaunch.KnownSymbols(copy, a.Server)).Distinct().ToList());
                lines.Add("Symbol=" + (symbol ?? "EURUSD")); lines.Add("Period=M1"); lines.Add("Script=MTManagerLoginProbe"); lines.Add("ScriptParameters=mtm-login.set");
            }
            File.WriteAllLines(start, lines, Encoding.Default);
            DateTime since = DateTime.Now; var watch = new LoginWatch(); watch.BeginSession(copy, a.Login, since);
            bool confirmed = false;
            try
            {
                if (cancel()) throw new OperationCanceledException();
                Start(start); var clock = Stopwatch.StartNew();
                while (clock.ElapsedMilliseconds < timeout)
                {
                    if (cancel()) throw new OperationCanceledException();
                    Native.HideWindowsOf(terminal.Id);
                    if (clock.ElapsedMilliseconds > 10000) Launcher.DeleteStartFile(start);
                    if (File.Exists(marker)) { ImportConnection proof = DirectProbe.Marker(TextFiles.ReadText(marker), a); if (proof != null) { confirmed = true; return proof; } }
                    watch.Update(copy, a.Login, since, DateTime.Now);
                    LoginResult journal = watch.AttemptResult;
                    if (journal.State == Login.Connected || journal.State == Login.WrongLogin || journal.State == Login.NoServer) { confirmed = journal.State == Login.Connected; return StudentImportRuntime.Describe(journal); }
                    if (Exited(terminal)) return StudentImportRuntime.Describe(watch.CompleteClosed(copy, a.Login, since, DateTime.Now));
                    stage((binary == null ? Lang.T("بررسی ژورنال MT4؛ ابزار مستقیم آماده نشد: ", "MT4 journal fallback; probe unavailable: ") : Lang.T("منتظر تأیید مستقیم MT4: ", "Waiting for direct MT4 acknowledgement: ")) + clock.ElapsedMilliseconds / 1000 + "s");
                    Thread.Sleep(100);
                }
                if (StopTerminal()) return StudentImportRuntime.Describe(watch.CompleteClosed(copy, a.Login, since, DateTime.Now));
                return TimedOut();
            }
            finally
            {
                if (confirmed) cleanup = Task.Factory.StartNew(() => StopTerminal(), CancellationToken.None, TaskCreationOptions.None, TaskScheduler.Default);
                else StopTerminal();
                Launcher.DeleteStartFile(start); try { if (File.Exists(marker)) File.Delete(marker); } catch { }
            }
        }
        public void Dispose() { DrainCleanup(); StopHelper(); StopTerminal(); }
    }
}
