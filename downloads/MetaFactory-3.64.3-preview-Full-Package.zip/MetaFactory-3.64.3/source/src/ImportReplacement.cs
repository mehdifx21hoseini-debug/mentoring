using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace MTManager
{
    public enum ImportDuplicateAction { Cancel, Skip, Replace }
    public sealed class ImportDuplicateDecision
    {
        public ImportDuplicateAction Action;
        public bool ApplyAll;
        public string Instance="";
    }
    public static class ImportReplacement
    {
        public static Account[] Matches(AccountStore accounts,StudentImportRow row)
        {
            string key=StudentImport.Key(row.Kind,row.Login,row.Server);
            if(key.Length==0)return new Account[0];
            return accounts.All.Where(a=>a.HasLogin&&StudentImport.Key(StudentDirectory.KindOf(a),a.Login,a.Server)==key)
                .OrderBy(a=>a.Instance,StringComparer.OrdinalIgnoreCase).ToArray();
        }
        static string Fingerprint(StudentImportRow row)
        {
            using(var sha=SHA256.Create())return Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(string.Join("\t",new[]{row.Name,row.OriginalName,row.Platform,row.Kind.ToString(),row.Login,row.Server,row.ImportServers,row.Mode,row.Investor,row.Master}))));
        }
        public static void Reset(StudentImportRow row)
        {row.ReplacementAccount=null;row.ReplacementInput="";row.ReplacementFailure="";row.Replaced=false;}
        public static bool Resolve(IEnumerable<StudentImportRow> rows,AccountStore accounts,Func<StudentImportRow,Account[],ImportDuplicateDecision> ask)
        {
            ImportDuplicateAction? all=null;var handled=new HashSet<string>(StringComparer.Ordinal);
            foreach(var row in rows.Where(r=>!r.Saved&&r.State==ImportState.Duplicate).ToArray())
            {
                if(!handled.Add(StudentImport.Key(row.Kind,row.Login,row.Server))){row.Reason=Lang.T("تکراری در فایل؛ رد شد.","Duplicate in file; skipped.");continue;}
                var matches=Matches(accounts,row);
                if(matches.Length==0){row.Reason=Lang.T("تکراری در فایل؛ رد شد.","Duplicate in file; skipped.");continue;}
                var choice=all.HasValue&&(all.Value==ImportDuplicateAction.Skip||matches.Length==1)?new ImportDuplicateDecision{Action=all.Value,Instance=matches[0].Instance}:ask(row,matches);
                if(choice==null||choice.Action==ImportDuplicateAction.Cancel)return false;
                if(choice.ApplyAll)all=choice.Action;
                if(choice.Action!=ImportDuplicateAction.Replace){row.Reason=Lang.T("حساب تکراری؛ رد شد.","Existing account; skipped.");continue;}
                var target=matches.SingleOrDefault(a=>a.Instance==choice.Instance);
                if(target==null){row.State=ImportState.Invalid;row.Reason="نسخهٔ قبلی انتخاب نشده؛ اطلاعات قبلی حفظ شد.";continue;}
                if(StudentDirectory.KindOf(target)!=row.Kind)
                {row.State=ImportState.Invalid;row.Reason="پلتفرم متفاوت است؛ اطلاعات قبلی حفظ شد. MT4/MT5 را بررسی کنید.";row.ReplacementFailure="پلتفرم متفاوت؛ قبلی حفظ شد.";continue;}
                row.ReplacementAccount=target.Snapshot();row.ReplacementInput=Fingerprint(row);
                row.State=ImportState.Ready;row.Reason=Lang.T("آمادهٔ بررسی و جایگزینی.","Ready to verify and replace.");
            }
            return true;
        }
        public static void ValidateApproval(StudentImportRow row)
        {
            if(row.ReplacementAccount==null||row.ReplacementInput!=Fingerprint(row)||
                StudentImport.Key(row.Kind,row.Login,row.Server)!=StudentImport.Key(StudentDirectory.KindOf(row.ReplacementAccount),row.ReplacementAccount.Login,row.ReplacementAccount.Server))
                throw new UserMessage("اطلاعات ورودی تغییر کرده؛ جایگزینی را دوباره انتخاب کنید. قبلی حفظ شد.");
        }
        // Called only after a positive verifier result, never before authentication. No file/profile/chart deletion.
        public static void CommitVerified(AccountStore accounts,StudentImportRow row,string verifiedServer,Func<bool> cancel)
        {
            ValidateApproval(row);
            bool readable;AccountStore.Load(out readable);if(!readable)throw new UserMessage("فایل حساب‌ها خوانده نشد؛ قبلی حفظ شد.");
            lock(accounts.Sync)
            {
                if(cancel())throw new OperationCanceledException();
                var before=row.ReplacementAccount;var current=accounts.Get(before.Instance);
                if(current==null||current.CredentialKey!=before.CredentialKey||current.Trader!=before.Trader||current.OriginalTrader!=before.OriginalTrader||
                    current.Platform!=before.Platform||current.DeferredDir!=before.DeferredDir||StudentDirectory.KindOf(current)!=row.Kind)
                {row.ReplacementFailure="اطلاعات قبلی تغییر کرده؛ دوباره بررسی کنید.";throw new UserMessage(row.ReplacementFailure);}
                var updated=current.Snapshot();
                updated.Trader=row.Name;updated.OriginalTrader=string.IsNullOrEmpty(row.OriginalName)?current.OriginalTrader:row.OriginalName;updated.Login=row.Login;updated.Server=verifiedServer;updated.Mode=row.Mode;
                updated.InvestorEnc=Secret.Protect(row.Investor);updated.MasterEnc=Secret.Protect(row.Master);updated.ImportServers="";
                // Retain the instance identity, platform, deferred path and existing folder-recovery marker.
                updated.VerifyState="connected";updated.VerifyUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture);
                updated.VerifyToken="";updated.VerifyPass=0;updated.VerifyReason=Lang.T("اطلاعات جدید پس از تأیید ورود جایگزین شد.","New details replaced after successful login verification.");
                accounts.SetQueue(updated);
                try{accounts.Save();}catch{accounts.SetQueue(current);throw;}
                row.Copy=updated.Instance;row.Server=verifiedServer;row.ImportServers="";row.Replaced=true;row.State=ImportState.Connected;
                row.Reason=Lang.T("جایگزین شد؛ پوشه‌ها، یادداشت‌ها و گزارش‌های قبلی حفظ شدند. اطلاعات جدید در اجرای بعدی نسخه استفاده می‌شود.","Replaced; existing folders, notes and reports preserved. New details apply on the copy's next launch.");
            }
        }
    }

    sealed class ImportDuplicateDialog:FormDialog
    {
        readonly Account[] matches;
        readonly CheckBox applyAll=new CheckBox{AutoSize=true};
        readonly ComboBox target=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList};
        public ImportDuplicateDecision Decision=new ImportDuplicateDecision();
        public ImportDuplicateDialog(StudentImportRow row,Account[] matches):base(Lang.T("شماره حساب از قبل وجود دارد","Account number already exists"),null,false,true)
        {
            this.matches=matches;MinWidth(380);
            Wide(Theme.Label(row.Name+" · "+row.Login,380,Theme.Bold,Theme.Text));
            Wide(Theme.Label(Lang.T("جدید: ","New: ")+row.Platform+" · "+row.Server,380,Theme.Small,Theme.Muted));
            target.Width=Theme.S(380);target.Font=Theme.Small;
            foreach(var account in matches)target.Items.Add(account.Instance+" · "+account.Trader+" · "+account.Server);
            if(matches.Length>1)Wide(Theme.Label(Lang.T("کدام نسخه جایگزین شود؟","Which existing copy should be replaced?"),380,Theme.Small,Theme.Text));
            Wide(target);target.SelectedIndex=matches.Length==1?0:-1;
            Wide(Theme.Label(Lang.T("جایگزینی فقط پس از اتصال موفق انجام می‌شود.","Replacement happens only after successful login."),380,Theme.Small,Theme.Muted));
            applyAll.Text=Lang.T("برای همهٔ تکراری‌ها","Apply to all duplicates");applyAll.Visible=true;Wide(applyAll);
            var replace=AddButton(Lang.T("جایگزین کن","Replace"),(s,e)=>Choose(ImportDuplicateAction.Replace),true);
            replace.Enabled=target.SelectedIndex>=0;target.SelectedIndexChanged+=(s,e)=>replace.Enabled=target.SelectedIndex>=0;
            var skip=AddButton(Lang.T("رد کن","Skip"),(s,e)=>Choose(ImportDuplicateAction.Skip));
            AcceptButton=replace;CancelButton=skip;Finish();
        }
        void Choose(ImportDuplicateAction action)
        {
            Decision=new ImportDuplicateDecision{Action=action,ApplyAll=applyAll.Checked,Instance=target.SelectedIndex>=0?matches[target.SelectedIndex].Instance:""};
            Close(DialogResult.OK);
        }
    }

    public static class ImportPreviewDetails
    {
        public static string Short(StudentImportRow row)
        {
            string raw=ImportPersian.Details(row.Redact(row.Reason));
            if(!string.IsNullOrEmpty(row.ReplacementFailure))return row.ReplacementFailure;
            switch(row.State)
            {
                case ImportState.Connected:return row.Replaced?"اطلاعات جایگزین شد.":"اتصال تأیید شد.";
                case ImportState.Duplicate:
                    if(raw.Contains("رد شد")||(row.Reason??"").IndexOf("skipped",StringComparison.OrdinalIgnoreCase)>=0)
                        return raw.Contains("فایل")||(row.Reason??"").IndexOf("in file",StringComparison.OrdinalIgnoreCase)>=0?"تکراری در فایل؛ رد شد.":"تکراری؛ رد شد.";
                    return "شماره حساب تکراری است.";
                case ImportState.Invalid:
                    var fields=new List<string>();
                    if(string.IsNullOrWhiteSpace(row.Name))fields.Add("نام وارد نشده");
                    if(row.Platform!="MT4"&&row.Platform!="MT5")fields.Add("MT4/MT5 مشخص نیست");
                    string login=TextUtil.LatinDigits(row.Login??"");
                    if(row.LoginNeedsCorrection||login.Length==0||login.Length>20||login.Any(c=>c<'0'||c>'9')||login.All(c=>c=='0'))fields.Add("شماره حساب نیاز به اصلاح دارد");
                    if(string.IsNullOrWhiteSpace(row.Server))fields.Add("سرور وارد نشده");
                    if(string.IsNullOrEmpty(row.SelectedPassword))fields.Add("رمز وارد نشده");
                    return fields.Count>0?string.Join("؛ ",fields):Clip(raw);
                case ImportState.Checking:return row.ReplacementAccount!=null?"بررسی اطلاعات جدید…":"در حال بررسی اتصال…";
                case ImportState.Creating:return "آماده‌سازی بررسی…";
                case ImportState.Ready:return row.ReplacementAccount!=null?"آمادهٔ بررسی و جایگزینی.":raw.Length==0?"آمادهٔ بررسی.":Clip(raw);
                case ImportState.Cancelled:return row.ReplacementAccount!=null?"متوقف شد؛ قبلی حفظ شد.":"بررسی متوقف شد.";
                case ImportState.Unconfirmed:return row.ReplacementAccount!=null?"اتصال جدید تأیید نشد؛ قبلی حفظ شد.":"پاسخ قطعی دریافت نشد؛ دوباره بررسی کنید.";
                case ImportState.Failed:
                    bool rejected=row.Outcome==Login.WrongLogin||raw.Contains("رد شد");
                    if(row.ReplacementAccount!=null)return rejected?"ورود جدید رد شد؛ قبلی حفظ شد.":"جایگزینی کامل نشد؛ قبلی حفظ شد.";
                    return rejected?"ورود رد شد؛ حساب یا رمز بررسی شود.":Clip(raw.Length==0?"بررسی کامل نشد؛ دوباره تلاش کنید.":raw);
                default:return Clip(raw);
            }
        }
        static string Clip(string value){return value.Length<=88?value:value.Substring(0,87)+"…";}
    }
}
