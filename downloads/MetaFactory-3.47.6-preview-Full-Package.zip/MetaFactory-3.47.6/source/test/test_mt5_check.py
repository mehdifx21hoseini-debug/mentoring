import importlib.util
from pathlib import Path
from types import SimpleNamespace
import unittest
import io
import json

spec = importlib.util.spec_from_file_location('probe', Path(__file__).parents[1] / 'bridge/mt5_check.py')
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


class Api:
    def __init__(self):
        self.ok_init = True
        self.ok_login = True
        self.error = (-10005, 'do not expose passwords')
        self.account = SimpleNamespace(login=12345, server='WMMarkets-Demo')
        self.terminal = SimpleNamespace(connected=True)
        self.closed = False
        self.calls = []

    def initialize(self, path, **kwargs):
        self.calls.append(('initialize', path, kwargs))
        return self.ok_init

    def login(self, number, **kwargs):
        self.calls.append(('login', number, kwargs))
        return self.ok_login

    def last_error(self):
        return self.error

    def account_info(self):
        return self.account

    def terminal_info(self):
        return self.terminal

    def shutdown(self):
        self.closed = True


class ProbeTests(unittest.TestCase):
    def setUp(self):
        self.api = Api()
        self.request = dict(token='a' * 32, login='12345', server='WMMarkets-Demo', password='Sensitive!sentinel', terminal='C:/private/terminal64.exe', timeout=15000)

    def run_probe(self):
        reply = probe.check(self.request, self.api)
        self.assertTrue(self.api.closed)
        self.assertNotIn(self.request['password'], str(reply))
        return reply

    def test_success_requires_fresh_ack(self):
        self.assertEqual('connected', self.run_probe()['state'])
        self.assertEqual('login', self.api.calls[1][0])
        self.assertEqual(self.request['token'], self.run_probe()['token'])

    def test_cached_account_does_not_override_rejection(self):
        self.api.ok_login = False
        self.api.error = (-6, self.request['password'])
        self.assertEqual('rejected', self.run_probe()['state'])

    def test_ipc_failure_not_bad_password(self):
        self.api.ok_login = False
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_wrong_account(self):
        self.api.account.login = 99
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_wrong_server(self):
        self.api.account.server = 'Other'
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_disconnected(self):
        self.api.terminal.connected = False
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_unavailable_account(self):
        self.api.account = None
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_failed_initialize(self):
        self.api.ok_init = False
        self.assertEqual('unconfirmed', self.run_probe()['state'])
        self.assertEqual(1, len(self.api.calls))

    def test_exception_does_not_leak_password(self):
        def failing(*a, **kw):
            raise RuntimeError(self.request['password'])
        self.api.login = failing
        self.assertEqual('unconfirmed', self.run_probe()['state'])

    def test_persistent_service_requires_ack_for_each_account(self):
        class SwitchingApi(Api):
            def login(self, number, **kwargs):
                self.calls.append(('login', number, kwargs))
                if kwargs['password'] == 'bad':
                    self.error = (-6, 'rejected')
                    return False
                self.account = SimpleNamespace(login=number, server=kwargs['server'])
                return True
        api = SwitchingApi()
        requests = [dict(self.request, login=str(n), token=str(n) * 32, password=p)
                    for n, p in [(1, 'good'), (2, 'bad'), (3, 'good')]]
        output = io.StringIO()
        probe.serve(io.StringIO(''.join(json.dumps(r) + '\n' for r in requests)), output, api, persistent=True)
        responses = [json.loads(line) for line in output.getvalue().splitlines()]
        self.assertEqual(['connected', 'rejected', 'connected'], [r['state'] for r in responses])
        self.assertEqual([r['token'] for r in requests], [r['token'] for r in responses])
        self.assertEqual(3, len([c for c in api.calls if c[0] == 'login']))
        self.assertNotIn('Sensitive!sentinel', output.getvalue())

    def test_single_request_mode_remains_compatible(self):
        raw = json.dumps(self.request) + '\n'
        output = io.StringIO()
        probe.serve(io.StringIO(raw + raw), output, self.api)
        self.assertEqual(1, len(output.getvalue().splitlines()))


if __name__ == '__main__':
    unittest.main()
