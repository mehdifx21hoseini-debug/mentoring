using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
namespace MTManager {
static class LiveDashboardUiSmoke {
 static int checks;
 const BindingFlags Flags=BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public;
 static object Field(object o,string n){return o.GetType().GetField(n,Flags).GetValue(o);}
 static object Call(object o,string n,params object[] a){return o.GetType().GetMethod(n,Flags).Invoke(o,a);}
 static void Put(object o,string n,object v){o.GetType().GetField(n,Flags).SetValue(o,v);}
 static void Check(bool b,string m){if(!b)throw new Exception(m);checks++;Console.WriteLine("PASS "+m);}
 static void Pump(){for(int k=0;k<6;k++){Application.DoEvents();Thread.Sleep(30);}}
 static AccountJournal History(DateTime utc){
  DateTime server=DateTime.SpecifyKind(utc.AddHours(2),DateTimeKind.Unspecified);
  var j=new AccountJournal{Platform="MT5",Login="12345",Server="Synthetic-Demo",Currency="USD",Complete=true,Exported=server,From=server.Date.AddDays(-7),GmtOffset=7200,
   FloatingBars=AccountJournal.TradesOnly,Balance=900,Equity=948,HistoryChecked=true,HistoryOk=true,HistorySum=900,HistoryBalance=900,TrustedFrom=server.Date.AddDays(-7),
   FullHistoryPresent=true,FullHistoryValid=true,FullHistoryReconciled=true,FullHistoryScanOk=true,FullHistoryRequested=true,FullHistoryCount=2,FullHistorySum=900,FullHistoryBalance=900,LastTrade=server.AddMinutes(-3)};
  DateTime epoch=new DateTime(1970,1,1);j.FullHistory.Add(new JournalBalanceEvent{Ticket=1,Type=2,Net=1000,TimeMilliseconds=(long)(server.AddDays(-8)-epoch).TotalMilliseconds});
  j.FullHistory.Add(new JournalBalanceEvent{Ticket=2,Type=0,Net=-100,TimeMilliseconds=(long)(server.AddMinutes(-3)-epoch).TotalMilliseconds});
  j.Trades.Add(new JournalTrade{Ticket=2,Symbol="SYNTH",Open=server.AddHours(-2),Close=server.AddMinutes(-3),Profit=-90,Swap=-4,Commission=-6,Volume=1});
  j.Deals.Add(new JournalDeal{Ticket=2,Position=2,Type=0,Entry=1,Time=server.AddMinutes(-3),Profit=-90,Swap=-4,Commission=-6});return j;
 }
 static LiveFeedSnapshot Feed(AccountJournal j,DateTime utc,long seq,double profit){
  var f=new LiveFeedFrame{Token=new string('a',32),Run="synthetic-run",Sequence=seq,Revision=1,Heartbeat=utc,Platform="MT5",Login=j.Login,Server=j.Server,Currency="USD",Connected=true,State="ready",Values=new[]{900.0,948.0,20,928,0}};
  f.Positions.Add(new LivePosition(8,"SYNTH",true,1,DateTime.SpecifyKind(utc.Date.AddHours(1),DateTimeKind.Unspecified),new[]{100.0,0,120,profit,-2,90,110,-3}));
  return new LiveFeedSnapshot(LiveFeedStatus.Live,"ready","MT5",j.Login,j.Server,f,j);
 }
 [STAThread]static int Main(){string previous=AppPaths.DataDirOverride;string root=Path.Combine(Path.GetTempPath(),"live-dashboard-smoke-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=root;
 try{Application.EnableVisualStyles();Theme.Init();Lang.En=true;DateTime utc=DateTime.UtcNow;utc=utc.AddTicks(-(utc.Ticks%TimeSpan.TicksPerSecond));
  var settings=new Settings{Language="en",BaseDir=Path.Combine(root,"copies")};Directory.CreateDirectory(settings.BaseDir);
  var copy=new Instance{Name="MT5-01",Kind=Kind.MT5,Dir=Path.Combine(settings.BaseDir,"MT5-01")};Directory.CreateDirectory(copy.Dir);
  var account=new Account{Instance=copy.Name,Login="12345",Server="Synthetic-Demo",Trader="Synthetic live student",Platform="MT5"};var accounts=new AccountStore();accounts.Set(account);
  var target=LiveMonitorTarget.Create(copy,account);target.Token=new string('a',32);var projector=new LiveDashboardProjectionCache();var summaries=new LiveReportSummaryCache();
  var history=History(utc);var feed=Feed(history,utc,1,50);var data=projector.Update(target,feed,summaries.Update(feed,utc));
  using(var main=new MainForm(settings,accounts)){
   Lang.En=true;
   Put(main,"copies",new List<Instance>{copy});
   var rows=(Dictionary<string,LiveMonitorView>)Field(main,"dashboardRows");var last=(Dictionary<string,LiveDashboardData>)Field(main,"dashboardLast");
   rows[copy.Name]=new LiveMonitorView{CopyName=copy.Name,Target=target,Feed=feed,Dashboard=data,State="Live",History="History ready",LiveUntilUtc=utc.AddSeconds(10)};last[copy.Name]=data;
   object student=Call(main,"StudentOf",copy);Check((bool)Field(student,"LiveCurrent")&&((PanelView)Field(student,"Today")).Net==-52,"main page consumes verified live data without opening monitor dialog");
   Check(Field(main,"liveMonitorDialog")==null,"main page integration needs no separate monitoring window");
   var row=new CopyRow{Name=copy.Name,Trader=account.Trader,Login=account.Login,Server=account.Server,Kind="MT5",HasAccount=true,Running=true};
   Call(main,"Today",copy,row,DateTime.Now);Console.WriteLine("TODAY="+row.TodayText+" | "+row.TodayAgo);Check(row.TodayText.Contains("O/+48")&&row.TodayAgo.Contains("Live"),"Today cell shows current floating value and Live label");
   var source=(ReportTextSource)Call(main,"ReportSource",new List<Instance>{copy});var entries=source.Entries(PanelRange.Today,DateTime.Today,DateTime.Today);
   Check(entries.Count==1&&entries[0].View.Net==-52,"report text uses the same verified live financial model");string fingerprint=source.Fingerprint();
   Put(main,"pageName",copy.Name);Call(main,"UpdatePanel");Check(((ReportPanel)Field(main,"panel")).View.Net==-52,"student report panel receives live data");
   var next=Feed(history,utc.AddSeconds(1),2,80);var changed=projector.Update(target,next,summaries.Update(next,utc.AddSeconds(1)));rows[copy.Name].Feed=next;rows[copy.Name].Dashboard=changed;last[copy.Name]=changed;
   Call(main,"Today",copy,row,DateTime.Now);Check(row.TodayText.Contains("O/+78")&&projector.Builds==1,"price update changes Today without repeating full history math");
   Check(source.Entries(PanelRange.Today,DateTime.Today,DateTime.Today)[0].View.Net==-22&&source.Fingerprint()!=fingerprint,"report text fingerprint and totals advance on a live pulse");
   Call(main,"UpdatePanel");Check(((ReportPanel)Field(main,"panel")).View.Net==-22,"open report panel updates on the next pulse");
   var grid=(CopyGrid)Field(main,"grid");main.Controls.Remove(grid);
   using(var host=new Form{Text="MetaFactory — synthetic live dashboard test",ClientSize=new Size(1320,360),StartPosition=FormStartPosition.CenterScreen}){
    grid.Parent=host;grid.Dock=DockStyle.Fill;row.Status="Open";row.State=RowState.Active;
    grid.Rows.Clear();grid.SetRow(grid.Rows.Add(),row);host.Show();Pump();
    using(var bmp=new Bitmap(host.Width,host.Height)){using(var g=Graphics.FromImage(bmp))g.CopyFromScreen(host.Location,Point.Empty,host.Size);bmp.Save("/workspace/MetaFactory-delivery/MetaFactory-3.47.1-dashboard-synthetic.png");}
    host.Controls.Remove(grid);host.Close();
   }
   var pendingFrame=new LiveFeedFrame{Token=target.Token,Run="synthetic-run",Sequence=3,Revision=1,Heartbeat=utc.AddSeconds(2),Platform="MT5",Login=account.Login,Server=account.Server,Currency="USD",Connected=true,State="history-pending",Values=new[]{900.0,978.0,20,958,0}};
   pendingFrame.Positions.Add(new LivePosition(8,"SYNTH",true,1,feed.Positions[0].Open,new[]{100.0,0,120,80,-2,90,110,-3}));
   var pendingFeed=new LiveFeedSnapshot(LiveFeedStatus.HistoryPending,"history pending","MT5",account.Login,account.Server,pendingFrame,null);
   rows[copy.Name].Dashboard=null;rows[copy.Name].Feed=pendingFeed;rows[copy.Name].State="History pending";
   var partialRow=new CopyRow();Call(main,"Today",copy,partialRow,DateTime.Now);
   Check(partialRow.TodayText.Contains("O/+78")&&partialRow.TodayText.Contains("DD?")&&!partialRow.TodayNet.HasValue,"partial live data shows open P/L while keeping closed totals and DD unknown");
   var expired=rows[copy.Name].VisibleAt(utc.AddSeconds(12));rows[copy.Name]=expired;
   student=Call(main,"StudentOf",copy);Check(!(bool)Field(student,"LiveCurrent")&&((AccountJournal)Field(student,"Journal")).Exported==changed.Journal.Exported,"expired live source retains last verified report without marking it live");
   row=new CopyRow();Call(main,"Today",copy,row,DateTime.Now);Check(!row.TodayAgo.StartsWith("Live"),"stale report does not keep the Live badge");
   Call(main,"UpdatePanel");Check(!string.IsNullOrEmpty(((ReportPanel)Field(main,"panel")).Error),"open report panel gains an explicit stale-source notice");
   account.Login="99999";accounts.Set(account);student=Call(main,"StudentOf",copy);
   Check(Field(student,"LiveData")==null&&Field(student,"Journal")==null,"edited account cannot inherit another account's last live report");
   Call(main,"ShutdownLiveMonitoring");Check(!((LiveMonitorController)Field(main,"dashboardController")).Enabled,"application shutdown stops dashboard receiver");
  }
  Console.WriteLine("DASHBOARD UI PASS "+checks);return 0;
 }catch(Exception e){Console.Error.WriteLine(e);return 1;}
 finally{AppPaths.DataDirOverride=previous;try{Directory.Delete(root,true);}catch{}}
 }
}}
