"""Read-only, single-request MetaTrader IPC check. Credentials only arrive on stdin."""
import json
import sys


def check(request, api):
    reply = {key: request[key] for key in ('token', 'login', 'server')}
    reply.update(state='unconfirmed', reason='No conclusive connection response.')
    try:
        timeout = max(1000, min(60000, int(request['timeout'])))
        if not api.initialize(request['terminal'], portable=True, timeout=timeout):
            reply['reason'] = 'Could not initialize the private MetaTrader terminal.'
            return reply
        # A fresh explicit acknowledgement is mandatory; cached account_info alone is insufficient.
        if not api.login(int(request['login']), password=request['password'], server=request['server'], timeout=timeout):
            error = api.last_error()
            reply['state'] = 'rejected' if error and error[0] == -6 else 'unconfirmed'
            reply['reason'] = 'Account/password rejected.' if reply['state'] == 'rejected' else 'Broker connection was not confirmed.'
            return reply
        account = api.account_info()
        terminal = api.terminal_info()
        if (account and terminal and terminal.connected
                and int(account.login) == int(request['login'])
                and str(account.server).strip().casefold() == request['server'].strip().casefold()):
            reply.update(state='connected', reason='Fresh login acknowledged by MetaTrader IPC.')
        else:
            reply['reason'] = 'The connected account or server did not match the request.'
        return reply
    except Exception:
        reply['reason'] = 'MetaTrader IPC check could not be completed.'
        return reply
    finally:
        try:
            api.shutdown()
        except Exception:
            pass


def serve(input_stream, output_stream, api=None, persistent=False):
    if api is None:
        try:
            import MetaTrader5 as api
        except Exception:
            api = None
    for raw in input_stream:
        request = json.loads(raw)
        if api is None:
            response = {key: request[key] for key in ('token', 'login', 'server')}
            response.update(state='unavailable', reason='The bundled Windows 64-bit MetaTrader IPC runtime could not load.')
        else:
            response = check(request, api)
        print(json.dumps(response), file=output_stream, flush=True)
        if not persistent:
            break


def main():
    serve(sys.stdin, sys.stdout, persistent='--serve' in sys.argv[1:])


if __name__ == '__main__':
    main()
