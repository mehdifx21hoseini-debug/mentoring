using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using MTManager;

static class UiQueueSmoke
{
    static int count;
    static void Assert(bool result, string text) { if (!result) throw new Exception(text); count++; }
    static FieldInfo Field(object x, string name) { return x.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic); }
    static void Call(object x, string name, params object[] args) { x.GetType().GetMethod(name, BindingFlags.Instance | BindingFlags.NonPublic).Invoke(x, args); }
    static void Pump(int ms) { var clock = Stopwatch.StartNew(); do { Application.DoEvents(); Thread.Sleep(10); } while (clock.ElapsedMilliseconds < ms); }
    static readonly ManualResetEvent allow = new ManualResetEvent(false);
    sealed class Fake : IAccountVerifier
    {
        public ImportConnection Verify(Account a, int timeout, Func<bool> cancel, Action<string> stage) { while (!allow.WaitOne(10) && !cancel()) { } return new ImportConnection { Connected = true, State = Login.Connected }; }
        public void Dispose() { }
    }
    [STAThread] static int Main(string[] args)
    {
        string root = Path.Combine(Path.GetTempPath(), "mtm-ui-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root); AppPaths.DataDirOverride = root; Lang.En = args.Contains("en");
        Application.EnableVisualStyles(); typeof(Account).Assembly.GetType("MTManager.Theme").GetMethod("Init").Invoke(null, null);
        var settings = new Settings { BaseDir = Path.Combine(root, "copies") }; Directory.CreateDirectory(settings.BaseDir);
        var accounts = new AccountStore(); var folders = new FolderStore();
        var assembly = typeof(Account).Assembly;
        try
        {
            using (var queue = new ImportCoordinator(settings, accounts, folders, slot => new Fake(), 1))
            {
                Type dialogType = assembly.GetType("MTManager.StudentImportDialog");
                using (var dialog = (Form)Activator.CreateInstance(dialogType, new object[] { settings, accounts, folders, "", queue }))
                {
                    var rows = Enumerable.Range(1, 100).Select(n => new StudentImportRow { Name = "UI student " + n, Login = (20000000 + n).ToString(), Server = "WMMarkets-Demo", Platform = "MT5", Kind = Kind.MT5, Investor = "FakePass!123", State = ImportState.Ready }).ToList();
                    Field(dialog, "rows").SetValue(dialog, rows);
                    var grid = (DataGridView)Field(dialog, "grid").GetValue(dialog);
                    foreach (var row in rows) grid.Rows.Add(row.Line, row.Name, row.Platform, row.Login, row.Server, row.Folder, row.Copy, "Ready", "");
                    dialog.Show(); Pump(150); var clock = Stopwatch.StartNew(); Call(dialog, "Begin", null, EventArgs.Empty);
                    while (accounts.All.Count() != 100 && clock.ElapsedMilliseconds < 10000) Pump(50);
                    Pump(300);
                    Assert(dialog.Visible, "Excel dialog stays open during checks");
                    Assert(accounts.All.Count() == 100, "100 students registered through production UI");
                    Assert(rows.Any(r => r.State == ImportState.Registered || r.State == ImportState.Checking), "pending accounts are not mislabeled as connected");
                    Assert(Directory.GetDirectories(settings.BaseDir).Length == 0, "registration creates no personal terminal copies");
                    Console.WriteLine("100-row UI registration: " + clock.ElapsedMilliseconds + " ms (no live broker check)");
                    Call(dialog, "RequestStop"); Pump(300);
                    Assert(queue.Paused, "Excel stop button pauses background checks");
                    Assert(rows.All(r => r.State == ImportState.Cancelled), "paused rows shown in same Excel table");
                    Call(dialog, "Retry", null, EventArgs.Empty); allow.Set();
                    var done = Stopwatch.StartNew();
                    while (!rows.All(r => r.State == ImportState.Connected) && done.ElapsedMilliseconds < 10000) Pump(50);
                    Assert(rows.All(r => r.State == ImportState.Connected), "same Excel table shows every connection result");
                    Assert(dialog.Visible, "results stay visible after completion");
                    Assert(((DataGridView)Field(dialog, "grid").GetValue(dialog)).Rows.Count == 100, "Excel table retains all rows");
                    Assert(accounts.All.Count() == 100, "retry does not duplicate registered students");
                    string autoResult = (string)Field(dialog, "automaticResultPath").GetValue(dialog);
                    Assert(Spreadsheet.Read(autoResult).Skip(1).All(r => r.Cells[8] == StudentImport.Status(ImportState.Connected)), "automatic result export contains final connection outcomes");
                    dialog.Close(); Pump(100);
                }
                Assert(accounts.All.All(a => a.VerifyState == "connected"), "background verifier processes durable jobs");
                Type queueType = assembly.GetType("MTManager.VerificationQueueDialog");
                using (var view = (Form)Activator.CreateInstance(queueType, new object[] { accounts, queue }))
                {
                    view.Show(); Pump(200);
                    var grid = (DataGridView)Field(view, "grid").GetValue(view);
                    Assert(grid.Rows.Count == 100, "queue displays all students");
                    Assert(!grid.Columns.Cast<DataGridViewColumn>().Any(c => c.HeaderText.Contains("Password")), "queue hides passwords");
                    queue.Pause(); Pump(1100); Assert(queue.Paused, "queue pauses without blocking window");
                    queue.Resume(false); Pump(100); Assert(!queue.Paused, "queue resumes");
                    view.Close(); Assert(!queue.Paused, "closing queue view does not pause service");
                }
            }
            // Recovered students remain visible in the main directory without terminal directories.
            var seeded = accounts.All.OrderBy(a => a.Instance).Take(3).ToArray();
            seeded[0].Mode = "master"; seeded[0].MasterEnc = Secret.Protect("MasterUiOnly!1"); seeded[0].Server = "Broker-Real2";
            seeded[1].Server = "Broker-Demo3"; seeded[2].Server = "WingoGroupLtd-server";
            foreach (var a in seeded) accounts.SetQueue(a);
            Type mainType = assembly.GetType("MTManager.MainForm");
            using (var main = (Form)Activator.CreateInstance(mainType, new object[] { settings, accounts }))
            {
                main.Show(); Pump(500);
                var list = (List<Instance>)Field(main, "copies").GetValue(main);
                Assert(list.Count == 100, "main screen includes unprovisioned students");
                var mainGrid = (DataGridView)Field(main, "grid").GetValue(main);
                Func<DataGridViewRow, string, object> rowValue = (r, name) => r.Tag.GetType().GetField(name).GetValue(r.Tag);
                Assert(mainGrid.Rows.Cast<DataGridViewRow>().Count(r => (bool)rowValue(r, "MasterLogin")) == 1, "only master accounts receive the M indicator");
                var choice = Field(main, "chosen").GetValue(main);
                choice.GetType().GetMethod("Toggle").Invoke(choice, new object[] { seeded[0].Instance }); Call(main, "RefreshGrid", false);
                var baseline = ((List<Instance>)Field(main, "shown").GetValue(main)).Select(i => i.Name).ToArray();
                var cycle = mainGrid.GetType().GetMethod("CycleHeaderSort");
                string focusBefore = mainGrid.CurrentRow == null ? "" : (string)rowValue(mainGrid.CurrentRow, "Name");
                cycle.Invoke(mainGrid, new object[] { "Server" }); Pump(50);
                Assert(focusBefore == (string)rowValue(mainGrid.CurrentRow, "Name"), "header sorting preserves focused student for keyboard actions");
                var categories = mainGrid.Rows.Cast<DataGridViewRow>().Select(r => ServerCategories.Of((string)rowValue(r, "Server"))).ToArray();
                Assert(categories[0] == ServerCategory.Demo && categories.Last() == ServerCategory.Unknown, "header server sort groups Demo then Real and unknown at end");
                Assert((bool)rowValue(mainGrid.Rows.Cast<DataGridViewRow>().First(r => (string)rowValue(r, "Name") == seeded[0].Instance), "Checked"), "sorting preserves student checkboxes");
                cycle.Invoke(mainGrid, new object[] { "Server" }); Pump(50);
                Assert(ServerCategories.Of((string)rowValue(mainGrid.Rows[0], "Server")) == ServerCategory.Real, "second header click reverses recognized server categories");
                cycle.Invoke(mainGrid, new object[] { "Server" }); Pump(50);
                Assert(((List<Instance>)Field(main, "shown").GetValue(main)).Select(i => i.Name).SequenceEqual(baseline), "third header click restores original row order");
                foreach (string column in new[] { "Trader", "Copy", "Login", "Folders", "Today", "Status" })
                {
                    cycle.Invoke(mainGrid, new object[] { column }); cycle.Invoke(mainGrid, new object[] { column }); cycle.Invoke(mainGrid, new object[] { column });
                    Assert(mainGrid.Rows.Count == 100, column + " header sorts in both directions without losing rows");
                }
                var model = (ReportWorkProgress)Field(main, "reportWork").GetValue(main); model.Begin(); model.Add(seeded[0].Instance);
                Call(main, "ReadStep", seeded[0].Instance, StepState.Starting, "Starting test"); Pump(100);
                var strip = (Control)Field(main, "reportProgress").GetValue(main); var footer = (Control)Field(main, "statusLine").GetValue(main);
                Assert(strip.Visible && strip.Bottom <= footer.Top + 1, "continuous progress strip sits above original status footer");
                Assert(model.Fraction > 0 && model.Fraction < 1, "single-student progress starts before the report finishes");
                Call(main, "ReadStep", seeded[0].Instance, StepState.Reading, "Reading test");
                Call(main, "ReadStep", seeded[0].Instance, StepState.Done, "Done"); Pump(300);
                Assert(model.Complete && model.Fraction == 1, "single report fills the bar when done");
                model.Begin(); model.Add(seeded[0].Instance); model.Add(seeded[1].Instance);
                Call(main, "ReadStep", seeded[0].Instance, StepState.Done, "Done"); Pump(700);
                Assert(Math.Abs(model.Fraction - 0.5) < 0.001, "one completed out of two reports shows half-full progress");
                cycle.Invoke(mainGrid, new object[] { "Server" }); Pump(200);
                using (var shot = new System.Drawing.Bitmap(main.Width, main.Height))
                {
                    using (var graphics = System.Drawing.Graphics.FromImage(shot)) graphics.CopyFromScreen(main.Location, System.Drawing.Point.Empty, main.Size);
                    shot.Save("/workspace/MetaFactory-delivery/MetaFactory-3.32.0-preview-ui-" + (Lang.En ? "en" : "fa") + ".png");
                }
                main.Close(); Pump(100);
            }
            Console.WriteLine(count + " UI checks passed"); return 0;
        }
        catch (Exception e) { Console.WriteLine(e); return 1; }
        finally { try { Directory.Delete(root, true); } catch { } }
    }
}
