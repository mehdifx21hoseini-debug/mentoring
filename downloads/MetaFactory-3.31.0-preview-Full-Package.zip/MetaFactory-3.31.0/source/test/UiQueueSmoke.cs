using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using MTManager;

static class UiQueueSmoke
{
    static int count;
    static void Assert(bool result, string text) { if (!result) throw new Exception(text); count++; }
    static FieldInfo Field(object x, string name) { return x.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic); }
    static void Call(object x, string name, params object[] args) { x.GetType().GetMethod(name, BindingFlags.Instance | BindingFlags.NonPublic).Invoke(x, args); }
    static void Pump(int ms) { var clock = Stopwatch.StartNew(); do { Application.DoEvents(); Thread.Sleep(10); } while (clock.ElapsedMilliseconds < ms); }
    sealed class Fake : IAccountVerifier
    {
        public ImportConnection Verify(Account a, int timeout, Func<bool> cancel, Action<string> stage) { return new ImportConnection { Connected = true, State = Login.Connected }; }
        public void Dispose() { }
    }
    [STAThread] static int Main(string[] args)
    {
        string root = Path.Combine(Path.GetTempPath(), "mtm-ui-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root); AppPaths.DataDirOverride = root; Lang.En = args.Contains("en");
        Application.EnableVisualStyles(); typeof(Account).Assembly.GetType("MTManager.Theme").GetMethod("Init").Invoke(null, null);
        var settings = new Settings { BaseDir = Path.Combine(root, "copies") }; Directory.CreateDirectory(settings.BaseDir);
        var accounts = new AccountStore(); var folders = new FolderStore();
        var assembly = typeof(Account).Assembly;
        try
        {
            using (var queue = new ImportCoordinator(settings, accounts, folders, slot => new Fake(), 1))
            {
                Type dialogType = assembly.GetType("MTManager.StudentImportDialog");
                using (var dialog = (Form)Activator.CreateInstance(dialogType, new object[] { settings, accounts, folders, "", queue }))
                {
                    var rows = Enumerable.Range(1, 100).Select(n => new StudentImportRow { Name = "UI student " + n, Login = (20000000 + n).ToString(), Server = "WMMarkets-Demo", Platform = "MT5", Kind = Kind.MT5, Investor = "FakePass!123", State = ImportState.Ready }).ToList();
                    Field(dialog, "rows").SetValue(dialog, rows);
                    var grid = (DataGridView)Field(dialog, "grid").GetValue(dialog);
                    foreach (var row in rows) grid.Rows.Add(row.Line, row.Name, row.Platform, row.Login, row.Server, row.Folder, row.Copy, "Ready", "");
                    dialog.Show(); Pump(150); var clock = Stopwatch.StartNew(); Call(dialog, "Begin", null, EventArgs.Empty);
                    while (dialog.Visible && clock.ElapsedMilliseconds < 10000) Pump(50);
                    Assert(!dialog.Visible, "registration dialog closes after durable commit");
                    Assert(accounts.All.Count() == 100, "100 students registered through production UI");
                    Assert(rows.All(r => r.State == ImportState.Registered), "registration is not mislabeled as connected");
                    Assert(Directory.GetDirectories(settings.BaseDir).Length == 0, "production import creates no terminal copies");
                    Console.WriteLine("100-row UI registration: " + clock.ElapsedMilliseconds + " ms (no live broker check)");
                }
                queue.Start(); var done = Stopwatch.StartNew(); while (!accounts.All.All(a => a.VerifyState == "connected") && done.ElapsedMilliseconds < 5000) Pump(50);
                Assert(accounts.All.All(a => a.VerifyState == "connected"), "background verifier processes durable jobs");
                Type queueType = assembly.GetType("MTManager.VerificationQueueDialog");
                using (var view = (Form)Activator.CreateInstance(queueType, new object[] { accounts, queue }))
                {
                    view.Show(); Pump(200);
                    var grid = (DataGridView)Field(view, "grid").GetValue(view);
                    Assert(grid.Rows.Count == 100, "queue displays all students");
                    Assert(!grid.Columns.Cast<DataGridViewColumn>().Any(c => c.HeaderText.Contains("Password")), "queue hides passwords");
                    queue.Pause(); Pump(1100); Assert(queue.Paused, "queue pauses without blocking window");
                    queue.Resume(false); Pump(100); Assert(!queue.Paused, "queue resumes");
                    view.Close(); Assert(!queue.Paused, "closing queue view does not pause service");
                }
            }
            // Recovered students remain visible in the main directory without terminal directories.
            Type mainType = assembly.GetType("MTManager.MainForm");
            using (var main = (Form)Activator.CreateInstance(mainType, new object[] { settings, accounts }))
            {
                main.Show(); Pump(500);
                var list = (List<Instance>)Field(main, "copies").GetValue(main);
                Assert(list.Count == 100, "main screen includes unprovisioned students");
                main.Close(); Pump(100);
            }
            Console.WriteLine(count + " UI checks passed"); return 0;
        }
        catch (Exception e) { Console.WriteLine(e); return 1; }
        finally { try { Directory.Delete(root, true); } catch { } }
    }
}
