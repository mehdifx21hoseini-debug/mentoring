using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MTManager
{
    static partial class Tests
    {
        sealed class FakeVerifier : IAccountVerifier
        {
            readonly Func<Account, int, Func<bool>, ImportConnection> action;
            public FakeVerifier(Func<Account, int, Func<bool>, ImportConnection> action) { this.action = action; }
            public ImportConnection Verify(Account a, int timeout, Func<bool> cancel, Action<string> stage) { return action(a, timeout, cancel); }
            public void Dispose() { }
        }
        static void Eventually(Func<bool> predicate, string message)
        {
            var clock = System.Diagnostics.Stopwatch.StartNew();
            while (!predicate() && clock.ElapsedMilliseconds < 5000) Thread.Sleep(10);
            Check(predicate(), message);
        }
        static StudentImportRow ImportRow(int n) { return new StudentImportRow { Line = n + 1, Name = "Student " + n, Login = (20000000 + n).ToString(), Server = "WMMarkets-Demo", Platform = n % 2 == 0 ? "MT5" : "MT4", Kind = n % 2 == 0 ? Kind.MT5 : Kind.MT4, Investor = "Sentinel!_Password", State = ImportState.Ready }; }
        static void BackgroundImportChecks()
        {
            string previous = AppPaths.DataDirOverride;
            AppPaths.DataDirOverride = Dir("background", "data");
            try
            {
                var settings = new Settings { BaseDir = Dir("background", "copies") };
                var accounts = new AccountStore(); var folders = new FolderStore();
                var order = new List<string>(); int calls = 0;
                Func<int, IAccountVerifier> factory = slot => new FakeVerifier((a, timeout, cancel) => {
                    lock (order) order.Add(a.Instance + ":" + timeout);
                    Interlocked.Increment(ref calls);
                    if (a.Login == "20000001" && timeout == 15000) return new ImportConnection();
                    return new ImportConnection { Connected = true, State = Login.Connected };
                });
                var rows = Enumerable.Range(1, 100).Select(ImportRow).ToList();
                using (var queue = new ImportCoordinator(settings, accounts, folders, factory, 1))
                {
                    queue.Register(rows, "Academy", () => false, row => { });
                    Equal(100, accounts.All.Count(), "batch registers every student before any connection");
                    Equal(0, calls, "registration never starts terminals");
                    Check(rows.All(r => r.State == ImportState.Registered), "all valid batch rows durably registered");
                    Check(rows.All(r => !Directory.Exists(Path.Combine(settings.BaseDir, r.Copy))), "registration creates no personal terminal directories");
                    Equal(100, AccountStore.Load().All.Count(), "entire batch durable before background checks");
                    Equal(100, StudentDirectory.All(settings, accounts).Count, "virtual students visible before personal copies exist");
                    Equal(100, accounts.All.Count(a => folders.Has(folders.Find("Academy").Id, a.Instance)), "all batch memberships committed");
                    Check(!File.ReadAllText(AppPaths.AccountsFile).Contains("Sentinel!_Password"), "passwords encrypted on disk");
                    var repeated = Enumerable.Range(1, 100).Select(ImportRow).ToArray();
                    queue.Register(repeated, "", () => false, row => { });
                    Check(repeated.All(r => r.State == ImportState.Duplicate), "retry of the same batch skips duplicates");
                    queue.Start();
                    Eventually(() => accounts.All.All(a => a.VerifyState == "connected"), "all valid students checked asynchronously");
                    Equal(101, calls, "one deferred check is retried once");
                    lock (order) Equal("60000", order.Last().Split(':').Last(), "slow account deferred behind every first-pass account");
                    string export = Path.Combine(AppPaths.DataDir, "queue.xlsx"); queue.Export(export);
                    Check(Spreadsheet.Read(export).All(r => r.Cells.Values.All(v => !v.Contains("Sentinel!_Password"))), "queue export excludes passwords");
                }
                Account saved = accounts.Get(rows[0].Copy); saved.VerifyState = "checking"; saved.VerifyPass = 1; saved.VerifyToken = new string('a', 32); accounts.SetQueue(saved); accounts.Save();
                using (var restored = new ImportCoordinator(settings, accounts, folders, factory, 1))
                { Equal("queued", accounts.Get(saved.Instance).VerifyState, "interrupted attempt recovered after restart"); Equal("", accounts.Get(saved.Instance).VerifyToken, "old attempt token discarded"); }
                // Legacy account editors cannot erase metadata or apply an old authentication result to new credentials.
                Account old = accounts.Get(saved.Instance);
                accounts.Set(new Account { Instance = old.Instance, Trader = "Edited", Login = old.Login, Server = old.Server, Mode = old.Mode, InvestorEnc = old.InvestorEnc });
                Equal(old.DeferredDir, accounts.Get(old.Instance).DeferredDir, "legacy edit preserves deferred path");
                var changed = accounts.Get(old.Instance); changed.InvestorEnc = Secret.Protect("Different!Password"); accounts.Set(changed);
                Equal("queued", accounts.Get(old.Instance).VerifyState, "credential edits require a new check");
                Equal("", accounts.Get(old.Instance).VerifyToken, "credential edit cancels stale completion");
                accounts.Save(); var loaded = AccountStore.Load();
                Equal(settings.BaseDir, Path.GetDirectoryName(loaded.Get(old.Instance).DeferredDir), "queue metadata roundtrip");
                var proof = old.Snapshot(); proof.VerifyToken = new string('b', 32);
                string marker = "MTMLOGIN\t1\t" + proof.VerifyToken + "\t" + proof.Login + "\t" + proof.Server + "\tconnected\r\n";
                Check(DirectProbe.Marker(marker, proof).Connected, "fresh exact-account marker accepted");
                Check(DirectProbe.Marker(marker.Replace(new string('b', 32), new string('c', 32)), proof) == null, "stale nonce marker rejected");
                Check(DirectProbe.Marker(marker.Replace(proof.Login, "999999"), proof) == null, "different account marker rejected");
                Check(DirectProbe.Marker(marker.Replace(proof.Server, "Other-Server"), proof) == null, "different server marker rejected");
                Check(DirectProbe.Marker(marker.Substring(0, marker.Length - 5), proof) == null, "partial proof rejected");
                ConcurrentQueueAndPause(settings);
                RegisterRollback(settings);
                LazyCopyAtomic(settings);
            }
            finally { AppPaths.DataDirOverride = previous; }
        }
        static void ConcurrentQueueAndPause(Settings settings)
        {
            AppPaths.DataDirOverride = Dir("background", "concurrent-data");
            var accounts = new AccountStore(); var folders = new FolderStore();
            int active = 0, peak = 0, total = 0;
            using (var gate = new ManualResetEvent(false))
            using (var queue = new ImportCoordinator(settings, accounts, folders, slot => new FakeVerifier((a, timeout, cancel) => {
                int n = Interlocked.Increment(ref active); Interlocked.Increment(ref total);
                lock (accounts.Sync) peak = Math.Max(peak, n);
                try { while (!gate.WaitOne(10) && !cancel()) { } return new ImportConnection { Connected = true, State = Login.Connected }; }
                finally { Interlocked.Decrement(ref active); }
            }), 2))
            {
                queue.Register(Enumerable.Range(1, 4).Select(ImportRow), "", () => false, r => { }); queue.Start();
                Eventually(() => active == 2, "two independent workers run on configured capacity");
                queue.Pause(); gate.Set(); Eventually(() => active == 0, "pause cancels active workers");
                Check(accounts.All.All(a => a.VerifyState == "paused"), "late successful result cannot overwrite pause");
                queue.Resume(false); Eventually(() => accounts.All.All(a => a.VerifyState == "connected"), "paused queue resumes without lost rows");
                Equal(2, peak, "maximum parallelism bounded to two");
            }
        }
        static void RegisterRollback(Settings settings)
        {
            AppPaths.DataDirOverride = Dir("background", "rollback-data");
            var accounts = new AccountStore(); var folders = new FolderStore();
            Directory.CreateDirectory(AppPaths.AccountsFile);
            using (var queue = new ImportCoordinator(settings, accounts, folders, slot => new FakeVerifier((a, t, c) => new ImportConnection()), 1))
            {
                var row = ImportRow(600);
                try { queue.Register(new[] { row }, "", () => false, r => { }); Check(false, "failed batch persistence throws"); }
                catch (IOException) { Check(true, "failed batch persistence throws"); }
                Equal(0, accounts.All.Count(), "failed batch save rolls back in-memory registrations");
                Check(!row.Saved, "failed batch never reports saved account");
            }
        }
        static void LazyCopyAtomic(Settings settings)
        {
            string source = Dir("background", "source");
            File.WriteAllText(Path.Combine(source, "terminal.exe"), "fake terminal");
            Directory.CreateDirectory(Path.Combine(source, "config")); File.WriteAllText(Path.Combine(source, "config", "accounts.ini"), "private source data");
            var copy = new Instance { Name = "MT4-700", Kind = Kind.MT4, Dir = Path.Combine(settings.BaseDir, "MT4-700") };
            Throws<OperationCanceledException>(() => StudentDirectory.Prepare(settings, source, copy, () => true), "cancelled provisioning stops");
            Check(!Directory.Exists(copy.Dir), "cancelled provisioning never exposes partial student directory");
            StudentDirectory.Prepare(settings, source, copy, () => false);
            Check(File.Exists(copy.Exe), "personal copy created on demand");
            Check(!File.Exists(Path.Combine(copy.Dir, "config", "accounts.ini")), "source login cache never copied");
        }
    }
}
