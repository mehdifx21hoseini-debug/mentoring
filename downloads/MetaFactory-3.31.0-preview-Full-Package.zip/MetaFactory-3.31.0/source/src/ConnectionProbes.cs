using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace MTManager
{
    public static class DirectProbe
    {
        public const string RuntimeTag = "python31210-mt56231-numpy1264";
        static readonly object buildGate = new object();
        static DateTime mt4RetryAfter = DateTime.MinValue;
        static bool SameLogin(string x, string y) { return (x ?? "").TrimStart('0') == (y ?? "").TrimStart('0'); }
        static bool SameServer(string x, string y) { return string.Equals((x ?? "").Trim(), (y ?? "").Trim(), StringComparison.OrdinalIgnoreCase); }
        public static ImportConnection Marker(string text, Account a)
        {
            string[] fields = (text ?? "").TrimEnd('\r', '\n').Split('\t');
            if (a.VerifyToken.Length != 32 || fields.Length != 6 || fields[0] != "MTMLOGIN" || fields[1] != "1" || fields[2] != a.VerifyToken || !SameLogin(fields[3], a.Login) || !SameServer(fields[4], a.Server) || fields[5] != "connected") return null;
            return new ImportConnection { Connected = true, State = Login.Connected, Reason = Lang.T("ورود حساب مستقیماً توسط متاتریدر تأیید شد.", "Account login was confirmed directly by MetaTrader.") };
        }
        public static ImportConnection PythonReply(string text, Account a)
        {
            try
            {
                var fields = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(text);
                Func<string, string> get = key => fields.ContainsKey(key) ? Convert.ToString(fields[key]) : "";
                if (a.VerifyToken.Length != 32 || get("token") != a.VerifyToken || !SameLogin(get("login"), a.Login) || !SameServer(get("server"), a.Server)) return null;
                string state = get("state");
                if (state == "connected") return Marker("MTMLOGIN\t1\t" + a.VerifyToken + "\t" + a.Login + "\t" + a.Server + "\tconnected", a);
                if (state == "rejected") return new ImportConnection { State = Login.WrongLogin, Reason = Lang.T("شماره حساب یا رمز توسط سرور رد شد.", "Account or password was rejected by the server.") };
                return new ImportConnection { Retryable = state != "unavailable", Reason = state == "unavailable"
                    ? Lang.T("رابط MT5 روی این ویندوز بارگذاری نشد؛ ویندوز ۶۴ بیتی و نصب بروکر را بررسی کنید.", "MT5 IPC could not load; check 64-bit Windows and broker installation.")
                    : Lang.T("پاسخ قطعی از سرور نرسید؛ اتصال تأیید نشده است.", "The server did not provide a conclusive response; login is unconfirmed.") };
            }
            catch { return null; }
        }
        public static string Runtime(Settings s, Func<bool> cancel)
        {
            lock (buildGate)
            {
                string root = Path.Combine(s.BaseDir, "_MTManager", "runtime", RuntimeTag);
                if (File.Exists(Path.Combine(root, "ready"))) return root;
                if (Directory.Exists(root)) throw new IOException("An incomplete private IPC runtime exists; it was preserved.");
                string temp = root + "." + Guid.NewGuid().ToString("N");
                try
                {
                    Directory.CreateDirectory(temp);
                    using (Stream input = Assembly.GetExecutingAssembly().GetManifestResourceStream("mt5-runtime.zip"))
                    using (var zip = new ZipArchive(input, ZipArchiveMode.Read))
                        foreach (ZipArchiveEntry entry in zip.Entries)
                        {
                            if (cancel()) throw new OperationCanceledException();
                            string target = Path.GetFullPath(Path.Combine(temp, entry.FullName.Replace('/', Path.DirectorySeparatorChar)));
                            if (!target.StartsWith(temp + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Invalid runtime resource.");
                            if (entry.Name.Length == 0) { Directory.CreateDirectory(target); continue; }
                            Directory.CreateDirectory(Path.GetDirectoryName(target));
                            using (var output = File.Create(target)) using (var source = entry.Open()) source.CopyTo(output);
                        }
                    File.WriteAllText(Path.Combine(temp, "ready"), RuntimeTag);
                    Directory.Move(temp, root);
                    return root;
                }
                finally { try { if (Directory.Exists(temp)) Directory.Delete(temp, true); } catch { } }
            }
        }
        public static string Mt4Binary(Settings s, Func<bool> cancel)
        {
            lock (buildGate)
            {
                string dir = Path.Combine(s.BaseDir, "_MTManager", "login-build"); Directory.CreateDirectory(dir);
                string source = Path.Combine(dir, "MTManagerLoginProbe.mq4"), binary = Path.ChangeExtension(source, ".ex4");
                string text;
                using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("MTManagerLoginProbe.mq4"))
                using (var reader = new StreamReader(stream)) text = reader.ReadToEnd();
                string stamp = ReportScript.Stamp(text);
                if (File.Exists(binary) && File.Exists(binary + ".stamp") && File.ReadAllText(binary + ".stamp") == stamp) return binary;
                if (DateTime.UtcNow < mt4RetryAfter) return null;
                mt4RetryAfter = DateTime.UtcNow.AddMinutes(5);
                string editor = StudentImportRuntime.FindWithDeadline(() => ReportScript.FindEditor(Kind.MT4, s), cancel, 10000);
                if (editor == null) return null;
                File.WriteAllText(source, text, Encoding.ASCII);
                if (File.Exists(binary)) File.Delete(binary);
                using (Process process = Process.Start(new ProcessStartInfo(editor, "/compile:\"" + source + "\" /log:\"" + source + ".log\"") { UseShellExecute = false, CreateNoWindow = true, WorkingDirectory = Path.GetDirectoryName(editor) }))
                {
                    var clock = Stopwatch.StartNew();
                    try { while (!process.WaitForExit(100)) { if (cancel()) throw new OperationCanceledException(); if (clock.ElapsedMilliseconds > 20000) return null; } }
                    finally { if (!process.HasExited) { try { process.Kill(); process.WaitForExit(1000); } catch { } } }
                }
                if (!File.Exists(binary)) return null;
                File.WriteAllText(binary + ".stamp", stamp); return binary;
            }
        }
    }

    // Each worker owns one private broker/platform terminal. Student terminals are never stopped or borrowed.
    public sealed class DirectAccountVerifier : IAccountVerifier
    {
        readonly Settings settings;
        readonly int slot;
        Process terminal;
        Instance copy;
        readonly Dictionary<string, string> sources = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public DirectAccountVerifier(Settings settings, int slot) { this.settings = settings; this.slot = slot; }
        static bool Exited(Process p) { try { p.Refresh(); return p.HasExited; } catch { return true; } }
        bool StopTerminal()
        {
            if (terminal == null) return true;
            Process owned = terminal;
            bool closed;
            try { int pid = owned.Id; SafeClose.Close(new ProcessTarget(owned, true), id => id == pid, 1, Log.Write); closed = Exited(owned); }
            catch { closed = Exited(owned); }
            if (closed) { owned.Dispose(); terminal = null; }
            return closed;
        }
        Instance Prepare(Account a, Func<bool> cancel)
        {
            if (!StopTerminal()) throw new IOException("The private verification terminal did not close.");
            Kind kind = StudentDirectory.KindOf(a);
            string key = kind + "|" + a.Server;
            string source;
            if (!sources.TryGetValue(key, out source)) { source = StudentDirectory.Source(settings, kind, a.Server, cancel); sources[key] = source; }
            if (source == null) throw new UserMessage(kind + " broker terminal is not installed.");
            string hash = ReportScript.Stamp(key).Substring(0, 16);
            copy = new Instance { Name = "verify-" + slot, Kind = kind, Dir = Path.Combine(settings.BaseDir, "_MTManager", "verify-" + slot, kind + "-" + hash) };
            if (Processes.IsRunning(Processes.Running(), copy.Exe)) throw new IOException("A previous private verifier is still running; close it before retrying.");
            StudentDirectory.Prepare(settings, source, copy, cancel);
            // Never authenticate through credentials cached by an earlier account or source installation.
            string config = Path.Combine(copy.Dir, "config");
            if (Directory.Exists(config)) foreach (string f in Directory.GetFiles(config, "accounts.*")) File.Delete(f);
            ChartProfile.UseEmpty(copy, true);
            return copy;
        }
        void Start(string path)
        {
            terminal = Process.Start(new ProcessStartInfo(copy.Exe, Launcher.Arguments(copy.Kind, path)) { WorkingDirectory = copy.Dir, UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden });
            if (terminal == null) throw new IOException("Private terminal did not start.");
            Owned.Add(terminal, copy.Exe);
            try { terminal.PriorityClass = ProcessPriorityClass.BelowNormal; } catch { }
            Native.HideWindowsOf(terminal.Id);
        }
        public ImportConnection Verify(Account a, int milliseconds, Func<bool> cancel, Action<string> stage)
        {
            if (!a.IsInvestor) return new ImportConnection { Retryable = false, Reason = "Only investor accounts can be verified automatically." };
            if (cancel()) throw new OperationCanceledException();
            stage(Lang.T("آماده‌سازی نسخهٔ خصوصی بررسی…", "Preparing private verification terminal…"));
            Prepare(a, cancel);
            string password = a.PasswordForLogin();
            if (string.IsNullOrEmpty(password)) return new ImportConnection { Retryable = false, Reason = Lang.T("رمز ذخیره‌شده خوانده نمی‌شود؛ دوباره وارد کنید.", "Saved password cannot be read; enter it again.") };
            if (PasswordRule.Problem(password) != null) return new ImportConnection { Retryable = false, Reason = Lang.T("رمز ذخیره‌شده قالب معتبری ندارد.", "Saved password has an invalid format.") };
            return copy.Kind == Kind.MT5 ? Mt5(a, password, milliseconds, cancel, stage) : Mt4(a, password, milliseconds, cancel, stage);
        }
        ImportConnection Mt5(Account a, string password, int timeout, Func<bool> cancel, Action<string> stage)
        {
            if (!Environment.Is64BitOperatingSystem) return new ImportConnection { Retryable = false, Reason = "MT5 IPC requires 64-bit Windows." };
            string runtime = DirectProbe.Runtime(settings, cancel), start = Path.Combine(copy.Dir, Launcher.StartFileName);
            // Python performs the explicit login. No credentials are written to the launch configuration.
            File.WriteAllLines(start, new[] { "[Common]", "KeepPrivate=0", "[Experts]", "AllowLiveTrading=0", "AllowDllImport=0", "[Charts]", "ProfileLast=" + ChartProfile.EmptyName, "MaxBars=500" }, Encoding.Unicode);
            Process helper = null;
            try
            {
                if (cancel()) throw new OperationCanceledException();
                Start(start);
                helper = Process.Start(new ProcessStartInfo(Path.Combine(runtime, "python.exe"), "-I \"" + Path.Combine(runtime, "mt5_check.py") + "\"") {
                    WorkingDirectory = runtime, UseShellExecute = false, CreateNoWindow = true, RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true });
                Task<string> output = helper.StandardOutput.ReadToEndAsync(), error = helper.StandardError.ReadToEndAsync();
                helper.StandardInput.WriteLine(new JavaScriptSerializer().Serialize(new { terminal = copy.Exe, token = a.VerifyToken, login = a.Login, server = a.Server, password = password, timeout = timeout }));
                helper.StandardInput.Close();
                var clock = Stopwatch.StartNew();
                while (!helper.WaitForExit(100))
                {
                    if (cancel()) throw new OperationCanceledException();
                    Native.HideWindowsOf(terminal.Id);
                    if (clock.ElapsedMilliseconds > 10000) Launcher.DeleteStartFile(start);
                    if (clock.ElapsedMilliseconds > timeout || Exited(terminal)) return TimedOut();
                    stage(Lang.T("منتظر تأیید مستقیم MT5: ", "Waiting for direct MT5 acknowledgement: ") + clock.ElapsedMilliseconds / 1000 + "s");
                }
                if (!Task.WaitAll(new Task[] { output, error }, 1500)) return TimedOut();
                string json = output.Result.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).LastOrDefault();
                return DirectProbe.PythonReply(json, a) ?? TimedOut();
            }
            finally
            {
                // Stop IPC first: it must not auto-start a replacement terminal during teardown.
                if (helper != null) { try { if (!helper.HasExited) { helper.Kill(); helper.WaitForExit(1000); } } catch { } helper.Dispose(); }
                StopTerminal(); Launcher.DeleteStartFile(start);
            }
        }
        static ImportConnection TimedOut() { return new ImportConnection { Reason = Lang.T("پاسخ قطعی در مهلت کوتاه نرسید؛ این حساب مانع بررسی بقیه نمی‌شود.", "No conclusive response within the check budget; other accounts will continue.") }; }
        ImportConnection Mt4(Account a, string password, int timeout, Func<bool> cancel, Action<string> stage)
        {
            string binary = DirectProbe.Mt4Binary(settings, cancel);
            string start = Path.Combine(copy.Dir, Launcher.StartFileName), markerName = "mtm-login-" + a.VerifyToken + ".txt";
            string marker = Path.Combine(copy.Dir, "MQL4", "Files", markerName);
            var lines = Launcher.StartLines(Kind.MT4, a, password, true);
            lines.RemoveAll(l => l.StartsWith("KeepPrivate=")); lines.Add("KeepPrivate=false"); lines.Add("ExpertsTrades=false"); lines.Add("ExpertsDllImport=false");
            if (binary != null)
            {
                string script = Path.Combine(copy.Dir, "MQL4", "Scripts", Path.GetFileName(binary)); Directory.CreateDirectory(Path.GetDirectoryName(script)); File.Copy(binary, script, true);
                string[] presets = { "ExpectedLogin=" + a.Login, "ExpectedServer=" + a.Server, "Token=" + a.VerifyToken, "OutFile=" + markerName };
                foreach (string dir in new[] { Path.Combine(copy.Dir, "MQL4", "Presets"), Path.Combine(copy.Dir, "presets") }) { Directory.CreateDirectory(dir); File.WriteAllLines(Path.Combine(dir, "mtm-login.set"), presets, Encoding.Default); }
                var source = new Instance { Kind = Kind.MT4, Dir = sources[Kind.MT4 + "|" + a.Server] };
                string symbol = ReportLaunch.PickSymbol(null, ReportLaunch.KnownSymbols(source, a.Server).Concat(ReportLaunch.KnownSymbols(copy, a.Server)).Distinct().ToList());
                lines.Add("Symbol=" + (symbol ?? "EURUSD")); lines.Add("Period=M1"); lines.Add("Script=MTManagerLoginProbe"); lines.Add("ScriptParameters=mtm-login.set");
            }
            File.WriteAllLines(start, lines, Encoding.Default);
            DateTime since = DateTime.Now; var watch = new LoginWatch(); watch.BeginSession(copy, a.Login, since);
            try
            {
                if (cancel()) throw new OperationCanceledException();
                Start(start); var clock = Stopwatch.StartNew();
                while (clock.ElapsedMilliseconds < timeout)
                {
                    if (cancel()) throw new OperationCanceledException();
                    Native.HideWindowsOf(terminal.Id);
                    if (clock.ElapsedMilliseconds > 10000) Launcher.DeleteStartFile(start);
                    if (File.Exists(marker)) { ImportConnection proof = DirectProbe.Marker(TextFiles.ReadText(marker), a); if (proof != null) return proof; }
                    watch.Update(copy, a.Login, since, DateTime.Now);
                    LoginResult journal = watch.AttemptResult;
                    if (journal.State == Login.Connected || journal.State == Login.WrongLogin || journal.State == Login.NoServer) return StudentImportRuntime.Describe(journal);
                    if (Exited(terminal)) return StudentImportRuntime.Describe(watch.CompleteClosed(copy, a.Login, since, DateTime.Now));
                    stage((binary == null ? Lang.T("بررسی ژورنال MT4؛ ابزار مستقیم آماده نشد: ", "MT4 journal fallback; probe unavailable: ") : Lang.T("منتظر تأیید مستقیم MT4: ", "Waiting for direct MT4 acknowledgement: ")) + clock.ElapsedMilliseconds / 1000 + "s");
                    Thread.Sleep(100);
                }
                if (StopTerminal()) return StudentImportRuntime.Describe(watch.CompleteClosed(copy, a.Login, since, DateTime.Now));
                return TimedOut();
            }
            finally { StopTerminal(); Launcher.DeleteStartFile(start); try { if (File.Exists(marker)) File.Delete(marker); } catch { } }
        }
        public void Dispose() { StopTerminal(); }
    }
}
