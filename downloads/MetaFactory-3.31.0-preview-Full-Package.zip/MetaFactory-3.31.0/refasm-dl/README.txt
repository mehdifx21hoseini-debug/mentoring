Download Microsoft.NETFramework.ReferenceAssemblies.net45 1.0.3 from NuGet and extract it into x45/. Run source/build.sh using Mono mcs and llvm-rc. The Windows broker and MetaEditor are not bundled.
