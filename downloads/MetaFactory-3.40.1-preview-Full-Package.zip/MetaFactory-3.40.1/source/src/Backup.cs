using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace MTManager
{
    // ================================================================== 3.24: backup and restore (approved mockup)
    //
    // One file (.mfbak) holds everything needed to have the same list on another computer: the students with their accounts and
    // passwords, the folders and who is in them, the list's order, the report history kept on this computer and the program's
    // settings. The MetaTrader copies themselves (gigabytes) are not in it: a restore makes them again from the MetaTrader installed
    // there. Windows' own encryption of the passwords (DPAPI) opens on this user of this computer only, so the file is locked with a
    // password of its own: PBKDF2 (HMAC-SHA1, 200 000 rounds) makes two keys from it, AES-256-CBC hides the contents and HMAC-SHA256
    // over everything tells a wrong password or a damaged file. The file stays wherever it is saved; nothing is sent anywhere.

    /// <summary>A file that is not a backup, a wrong password or a damaged file: the message says which, for the user.</summary>
    public sealed class BackupException : Exception
    {
        public BackupException(string message) : base(message) { }
    }

    public static class BackupLock
    {
        static readonly byte[] Magic = Encoding.ASCII.GetBytes("MFBAK");
        const byte Version = 1;
        public const int Rounds = 200000;
        const int HeaderLength = 5 + 1 + 16 + 4 + 16;

        static byte[] Random(int n)
        {
            var b = new byte[n];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(b);
            return b;
        }

        static void Keys(string password, byte[] salt, int rounds, out byte[] enc, out byte[] mac)
        {
            using (var kdf = new Rfc2898DeriveBytes(password ?? "", salt, rounds))
            {
                byte[] k = kdf.GetBytes(64);
                enc = k.Take(32).ToArray();
                mac = k.Skip(32).ToArray();
            }
        }

        public static byte[] Lock(byte[] plain, string password, int rounds = Rounds)
        {
            byte[] salt = Random(16), iv = Random(16), enc, macKey;
            Keys(password, salt, rounds, out enc, out macKey);
            byte[] cipher;
            using (Aes aes = Aes.Create())
            {
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                aes.Key = enc;
                aes.IV = iv;
                using (ICryptoTransform t = aes.CreateEncryptor()) cipher = t.TransformFinalBlock(plain, 0, plain.Length);
            }
            var o = new MemoryStream();
            o.Write(Magic, 0, Magic.Length);
            o.WriteByte(Version);
            o.Write(salt, 0, 16);
            o.Write(BitConverter.GetBytes(rounds), 0, 4);
            o.Write(iv, 0, 16);
            o.Write(cipher, 0, cipher.Length);
            byte[] body = o.ToArray();
            byte[] tag;
            using (var h = new HMACSHA256(macKey)) tag = h.ComputeHash(body);
            o.Write(tag, 0, tag.Length);
            return o.ToArray();
        }

        public static bool LooksLikeBackup(byte[] data)
        {
            return data != null && data.Length > HeaderLength + 32 && data.Take(5).SequenceEqual(Magic);
        }

        public static byte[] Unlock(byte[] data, string password)
        {
            if (!LooksLikeBackup(data)) throw new BackupException(Lang.T("این فایل، فایل پشتیبان MetaFactory نیست.", "This file is not a MetaFactory backup file."));
            if (data[5] != Version) throw new BackupException(Lang.T("این فایل با نسخه‌ی تازه‌تری از برنامه ساخته شده؛ اول برنامه را به‌روز کنید.", "This file was made by a newer version of the program; update the program first."));
            byte[] salt = data.Skip(6).Take(16).ToArray();
            int rounds = BitConverter.ToInt32(data, 22);
            if (rounds < 1000 || rounds > 10000000) throw new BackupException(Lang.T("فایل پشتیبان خراب است.", "The backup file is damaged."));
            byte[] iv = data.Skip(26).Take(16).ToArray();
            int cipherLength = data.Length - HeaderLength - 32;
            if (cipherLength <= 0 || cipherLength % 16 != 0) throw new BackupException(Lang.T("فایل پشتیبان خراب است.", "The backup file is damaged."));
            byte[] enc, macKey;
            Keys(password, salt, rounds, out enc, out macKey);
            byte[] tag;
            using (var h = new HMACSHA256(macKey)) tag = h.ComputeHash(data, 0, data.Length - 32);
            int diff = 0;
            for (int k = 0; k < 32; k++) diff |= tag[k] ^ data[data.Length - 32 + k];
            if (diff != 0) throw new BackupException(Lang.T("رمز درست نیست (یا فایل خراب شده است).", "The password is wrong (or the file is damaged)."));
            using (Aes aes = Aes.Create())
            {
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                aes.Key = enc;
                aes.IV = iv;
                using (ICryptoTransform t = aes.CreateDecryptor()) return t.TransformFinalBlock(data, HeaderLength, cipherLength);
            }
        }
    }

    public sealed class BackupStudent
    {
        /// <summary>The copy's name where the backup was made (folders and order refer to it).</summary>
        public string Copy = "";
        public string Kind = "", Trader = "", Login = "", Server = "", Mode = "investor", Investor = "", Master = "";
        /// <summary>Its passwords could not be read where the backup was made (saved by another Windows user): restored without them.</summary>
        public bool NoPassword;
        public string VerifyState = "", VerifyReason = "", VerifyUtc = "";
    }

    public sealed class BackupFolder
    {
        public string Name = "";
        public readonly List<string> Extra = new List<string>();
        /// <summary>Copy names where the backup was made.</summary>
        public readonly List<string> Members = new List<string>();
    }

    public sealed class BackupFile
    {
        public string Name = "";
        public byte[] Data = new byte[0];
        public DateTime Time;
    }

    /// <summary>Everything in a backup.</summary>
    public sealed class BackupData
    {
        public const int Format = 1;
        public string AppVersion = "";
        public DateTime Created;
        public readonly List<BackupStudent> Students = new List<BackupStudent>();
        public readonly List<BackupFolder> Folders = new List<BackupFolder>();
        public readonly List<string> Order = new List<string>();
        /// <summary>The program's settings that mean the same on another computer (not its folders).</summary>
        public readonly Dictionary<string, string> Settings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        /// <summary>The report history (the files of %APPDATA%\MT Manager\journal).</summary>
        public readonly List<BackupFile> Journals = new List<BackupFile>();

        public int Count(string kind) { return Students.Count(s => string.Equals(s.Kind, kind, StringComparison.OrdinalIgnoreCase)); }

        /// <summary>The newest report kept, or null without any.</summary>
        public DateTime? ReportsUntil { get { return Journals.Count == 0 ? (DateTime?)null : Journals.Max(j => j.Time); } }
    }

    public static class BackupFormat
    {
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        /// <summary>Settings that are the same choice on any computer (BaseDir and the backup's own folder and password are not).</summary>
        public static readonly string[] PortableSettings =
            { "DelaySeconds", "Minimized", "NormalTerminalRights", "Light", "AutoStart", "Look", "StartCharts", "LowPriority", "TrimMemory", "MaxMt4", "ReportAtOnce", "Platform" };

        static string Esc(string s)
        {
            var b = new StringBuilder();
            foreach (char c in s ?? "")
            {
                if (c == '\\') b.Append("\\\\");
                else if (c == '\t') b.Append("\\t");
                else if (c == '\n') b.Append("\\n");
                else if (c == '\r') b.Append("\\r");
                else b.Append(c);
            }
            return b.ToString();
        }

        static string Unesc(string s)
        {
            var b = new StringBuilder();
            for (int k = 0; k < s.Length; k++)
            {
                char c = s[k];
                if (c != '\\' || k == s.Length - 1) { b.Append(c); continue; }
                char n = s[++k];
                b.Append(n == 't' ? '\t' : n == 'n' ? '\n' : n == 'r' ? '\r' : n);
            }
            return b.ToString();
        }

        static string Line(params string[] fields) { return string.Join("\t", fields.Select(Esc)); }

        static string[] Fields(string line) { return line.Split('\t').Select(Unesc).ToArray(); }

        // The contents: named entries (text files and the report history), one after another, then compressed (Deflate):
        // "MFDATA1", then for each entry its name, time and bytes, each with its length before it.
        static readonly byte[] DataMark = Encoding.ASCII.GetBytes("MFDATA1");

        sealed class Entry
        {
            public string Name;
            public DateTime Time;
            public byte[] Data;
        }

        static Entry TextEntry(string name, IEnumerable<string> lines)
        {
            var b = new StringBuilder();
            foreach (string l in lines) b.Append(l).Append('\n');
            return new Entry { Name = name, Data = new UTF8Encoding(false).GetBytes(b.ToString()) };
        }

        static List<string> Lines(Dictionary<string, Entry> all, string name)
        {
            Entry e;
            if (!all.TryGetValue(name, out e)) return new List<string>();
            return Encoding.UTF8.GetString(e.Data).Split('\n').Select(l => l.TrimEnd('\r')).Where(l => l.Length > 0).ToList();
        }

        static byte[] Pack(IEnumerable<Entry> entries)
        {
            var raw = new MemoryStream();
            var w = new BinaryWriter(raw, Encoding.UTF8);
            w.Write(DataMark);
            foreach (Entry e in entries)
            {
                w.Write(e.Name);
                w.Write(e.Time.Ticks);
                w.Write(e.Data.Length);
                w.Write(e.Data);
            }
            w.Flush();
            var packed = new MemoryStream();
            using (var z = new DeflateStream(packed, CompressionMode.Compress, true)) raw.WriteTo(z);
            return packed.ToArray();
        }

        static List<Entry> Unpack(byte[] packed)
        {
            var raw = new MemoryStream();
            using (var z = new DeflateStream(new MemoryStream(packed), CompressionMode.Decompress)) z.CopyTo(raw);
            raw.Position = 0;
            var r = new BinaryReader(raw, Encoding.UTF8);
            if (!r.ReadBytes(DataMark.Length).SequenceEqual(DataMark)) throw new BackupException(Lang.T("فایل پشتیبان خراب است.", "The backup file is damaged."));
            var list = new List<Entry>();
            while (raw.Position < raw.Length)
            {
                string name = r.ReadString();
                long ticks = r.ReadInt64();
                int n = r.ReadInt32();
                if (n < 0 || n > raw.Length - raw.Position) throw new BackupException(Lang.T("فایل پشتیبان خراب است.", "The backup file is damaged."));
                list.Add(new Entry { Name = name, Time = ticks > 0 && ticks <= DateTime.MaxValue.Ticks ? new DateTime(ticks) : DateTime.MinValue, Data = r.ReadBytes(n) });
            }
            return list;
        }

        /// <summary>The contents (before it is locked).</summary>
        public static byte[] Write(BackupData d)
        {
            var entries = new List<Entry>
            {
                TextEntry("manifest.txt", new[]
                {
                    "Format=" + BackupData.Format.ToString(Inv), "App=" + d.AppVersion, "Created=" + d.Created.ToString("yyyy-MM-dd HH:mm:ss", Inv),
                    "Students=" + d.Students.Count.ToString(Inv), "Folders=" + d.Folders.Count.ToString(Inv),
                }),
                TextEntry("students.tsv", d.Students.Select(s => Line(s.Copy, s.Kind, s.Trader, s.Login, s.Server, s.Mode, s.Investor, s.Master, s.NoPassword ? "1" : "0", s.VerifyState, s.VerifyReason, s.VerifyUtc))),
            };
            var folderLines = new List<string>();
            foreach (BackupFolder f in d.Folders)
            {
                folderLines.Add(Line(new[] { "F", f.Name }.Concat(f.Extra).ToArray()));
                foreach (string m in f.Members) folderLines.Add(Line("M", m));
            }
            entries.Add(TextEntry("folders.tsv", folderLines));
            entries.Add(TextEntry("order.txt", d.Order.Select(Esc)));
            entries.Add(TextEntry("settings.txt", d.Settings.Select(kv => Line(kv.Key, kv.Value))));
            entries.AddRange(d.Journals.Select(j => new Entry { Name = "journal/" + j.Name, Time = j.Time, Data = j.Data }));
            return Pack(entries);
        }

        public static BackupData Read(byte[] packed)
        {
            var d = new BackupData();
            try
            {
                List<Entry> entries = Unpack(packed);
                var all = new Dictionary<string, Entry>(StringComparer.Ordinal);
                foreach (Entry e in entries) all[e.Name] = e;
                foreach (string l in Lines(all, "manifest.txt"))
                {
                    int eq = l.IndexOf('=');
                    if (eq <= 0) continue;
                    string k = l.Substring(0, eq), v = l.Substring(eq + 1);
                    if (k == "Format") { int f; if (int.TryParse(v, out f) && f > BackupData.Format) throw new BackupException(Lang.T("این فایل با نسخه‌ی تازه‌تری از برنامه ساخته شده؛ اول برنامه را به‌روز کنید.", "This file was made by a newer version of the program; update the program first.")); }
                    else if (k == "App") d.AppVersion = v;
                    else if (k == "Created") { DateTime t; if (DateTime.TryParseExact(v, "yyyy-MM-dd HH:mm:ss", Inv, DateTimeStyles.None, out t)) d.Created = t; }
                }
                foreach (string l in Lines(all, "students.tsv"))
                {
                    string[] f = Fields(l);
                    if (f.Length < 8) continue;
                    d.Students.Add(new BackupStudent
                    {
                        Copy = f[0], Kind = f[1], Trader = f[2], Login = f[3], Server = f[4], Mode = f[5], Investor = f[6], Master = f[7],
                        NoPassword = f.Length > 8 && f[8] == "1", VerifyState = f.Length > 9 ? f[9] : "", VerifyReason = f.Length > 10 ? f[10] : "", VerifyUtc = f.Length > 11 ? f[11] : "",
                    });
                }
                BackupFolder cur = null;
                foreach (string l in Lines(all, "folders.tsv"))
                {
                    string[] f = Fields(l);
                    if (f.Length >= 2 && f[0] == "F") { cur = new BackupFolder { Name = f[1] }; cur.Extra.AddRange(f.Skip(2)); d.Folders.Add(cur); }
                    else if (f.Length >= 2 && f[0] == "M" && cur != null) cur.Members.Add(f[1]);
                }
                d.Order.AddRange(Lines(all, "order.txt").Select(Unesc));
                foreach (string l in Lines(all, "settings.txt"))
                {
                    string[] f = Fields(l);
                    if (f.Length >= 2) d.Settings[f[0]] = f[1];
                }
                foreach (Entry e in entries.Where(x => x.Name.StartsWith("journal/", StringComparison.Ordinal)))
                {
                    // Only a plain file name goes back into the journal folder.
                    string name = e.Name.Substring("journal/".Length);
                    if (name.Length == 0 || name.IndexOfAny(new[] { '/', '\\', ':' }) >= 0 || name.Contains("..")) continue;
                    d.Journals.Add(new BackupFile { Name = name, Data = e.Data, Time = e.Time });
                }
            }
            catch (BackupException) { throw; }
            catch (Exception e) { throw new BackupException(Lang.T("فایل پشتیبان خراب است (", "The backup file is damaged (") + e.Message + ")."); }
            if (d.Students.Count == 0 && d.Folders.Count == 0) throw new BackupException(Lang.T("در این فایل پشتیبان دانشجویی نیست.", "There are no students in this backup file."));
            return d;
        }

        /// <summary>The file: the contents locked with the password.</summary>
        public static byte[] Make(BackupData d, string password) { return BackupLock.Lock(Write(d), password); }

        public static BackupData Open(byte[] file, string password) { return Read(BackupLock.Unlock(file, password)); }
    }

    /// <summary>What a restore does with each student of the backup.</summary>
    public sealed class RestorePlan
    {
        /// <summary>Not on this computer: a copy is made for it.</summary>
        public readonly List<BackupStudent> Add = new List<BackupStudent>();
        /// <summary>Already here (same account on the same server), with the copy it has: its data is taken from the file.</summary>
        public readonly List<KeyValuePair<BackupStudent, string>> Update = new List<KeyValuePair<BackupStudent, string>>();
        /// <summary>Already here, left as it is.</summary>
        public readonly List<BackupStudent> Skip = new List<BackupStudent>();
    }

    public static class Restore
    {
        public static string Key(string login, string server) { return (login ?? "").Trim() + "|" + ServerCatalog.Norm(server); }

        /// <summary>update: a student already here takes the file's data; otherwise it is left as it is. Nothing here is removed either way.</summary>
        public static RestorePlan Plan(BackupData d, IEnumerable<Account> here, bool update)
        {
            var have = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (Account a in here.Where(a => a.HasLogin))
            {
                string k = Key(a.Login, a.Server);
                if (!have.ContainsKey(k)) have[k] = a.Instance;
            }
            var plan = new RestorePlan();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (BackupStudent s in d.Students)
            {
                string k = Key(s.Login, s.Server);
                if (!seen.Add(k)) continue;  // the same account twice in the file: once
                string copy;
                if (have.TryGetValue(k, out copy))
                {
                    if (update) plan.Update.Add(new KeyValuePair<BackupStudent, string>(s, copy));
                    else plan.Skip.Add(s);
                }
                else plan.Add.Add(s);
            }
            return plan;
        }

        /// <summary>The new order: what is here first (in its order) and the restored copies after, in the file's order.</summary>
        public static List<string> Order(IList<string> here, BackupData d, IDictionary<string, string> made)
        {
            var list = here.ToList();
            var at = new HashSet<string>(list, StringComparer.OrdinalIgnoreCase);
            IEnumerable<string> fileOrder = d.Order.Concat(d.Students.Select(s => s.Copy));
            foreach (string old in fileOrder)
            {
                string now;
                if (made.TryGetValue(old, out now) && at.Add(now)) list.Add(now);
            }
            return list;
        }
    }

    /// <summary>Between the program's own lists and a backup.</summary>
    public static class BackupStore
    {
        /// <summary>Everything to keep, from the lists as they are now: the students in the list's order (a copy without an account
        /// holds no student and is left out), the folders with their students, the portable settings and the report history.</summary>
        public static BackupData Gather(Settings s, AccountStore accounts, FolderStore folders, IList<string> order, IEnumerable<Instance> copies, bool journals = true)
        {
            var d = new BackupData { AppVersion = AppInfo.Version, Created = DateTime.Now };
            var kinds = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (Instance i in copies) kinds[i.Name] = i.Kind.ToString();
            List<Account> students = ListOrder.Apply(accounts.All.Where(a => a.HasLogin).OrderBy(a => a.Instance, StringComparer.OrdinalIgnoreCase), a => a.Instance, order ?? new List<string>());
            foreach (Account a in students)
            {
                string investor = Secret.Unprotect(a.InvestorEnc), master = Secret.Unprotect(a.MasterEnc), kind;
                if (!kinds.TryGetValue(a.Instance, out kind)) kind = a.Instance.StartsWith("MT4", StringComparison.OrdinalIgnoreCase) ? "MT4" : "MT5";
                d.Students.Add(new BackupStudent
                {
                    Copy = a.Instance, Kind = kind, Trader = a.Trader ?? "", Login = a.Login ?? "", Server = a.Server ?? "", Mode = a.Mode ?? "investor",
                    Investor = investor ?? "", Master = master ?? "", NoPassword = investor == null || master == null, VerifyState = a.VerifyState, VerifyReason = a.VerifyReason, VerifyUtc = a.VerifyUtc,
                });
            }
            foreach (Folder f in folders.All)
            {
                var b = new BackupFolder { Name = f.Name };
                b.Extra.AddRange(f.Extra);
                b.Members.AddRange(students.Where(a => folders.Has(f.Id, a.Instance)).Select(a => a.Instance));
                d.Folders.Add(b);
            }
            d.Order.AddRange(students.Select(a => a.Instance));
            foreach (string line in s.Lines())
            {
                int eq = line.IndexOf('=');
                if (eq > 0 && BackupFormat.PortableSettings.Contains(line.Substring(0, eq))) d.Settings[line.Substring(0, eq)] = line.Substring(eq + 1);
            }
            if (journals) AddJournals(d);
            return d;
        }

        /// <summary>The report history files (read apart, so the daily backup reads them away from the window).</summary>
        public static void AddJournals(BackupData d)
        {
            if (!Directory.Exists(JournalCache.Dir)) return;
            foreach (string f in Directory.GetFiles(JournalCache.Dir, "*.txt"))
                try { d.Journals.Add(new BackupFile { Name = Path.GetFileName(f), Data = File.ReadAllBytes(f), Time = File.GetLastWriteTime(f) }); }
                catch (Exception e) { Log.Write("backup: " + Path.GetFileName(f) + " left out (" + e.Message + ")"); }
        }

        /// <summary>The settings of the file (those meaning the same everywhere), into the program's.</summary>
        public static void ApplySettings(BackupData d, Settings s)
        {
            bool said = false;
            foreach (KeyValuePair<string, string> kv in d.Settings)
                if (BackupFormat.PortableSettings.Contains(kv.Key)) s.Set(kv.Key, kv.Value, ref said);
        }

        /// <summary>The report history: a file kept here that is newer than the one in the backup stays. Returns how many were written.</summary>
        public static int ApplyJournals(BackupData d)
        {
            int n = 0;
            if (d.Journals.Count == 0) return 0;
            Directory.CreateDirectory(JournalCache.Dir);
            foreach (BackupFile j in d.Journals)
            {
                string path = Path.Combine(JournalCache.Dir, j.Name);
                try
                {
                    // File times are kept less exactly than they are read (two seconds on a FAT32 flash drive).
                    if (File.Exists(path) && File.GetLastWriteTime(path) >= j.Time.AddSeconds(-2)) continue;
                    File.WriteAllBytes(path, j.Data);
                    if (j.Time > DateTime.MinValue) File.SetLastWriteTime(path, j.Time);
                    n++;
                }
                catch (Exception e) { Log.Write("restore: " + j.Name + " not written (" + e.Message + ")"); }
            }
            return n;
        }

        /// <summary>The folders of the file, by name (one here of the same name is used), with the restored students in them.</summary>
        public static void ApplyFolders(BackupData d, FolderStore folders, IDictionary<string, string> copyNow)
        {
            foreach (BackupFolder b in d.Folders)
            {
                if (string.IsNullOrWhiteSpace(b.Name)) continue;
                Folder f = folders.Find(b.Name);
                if (f == null)
                {
                    f = folders.Create(b.Name);
                    f.Extra.AddRange(b.Extra);
                }
                List<string> members = b.Members.Where(copyNow.ContainsKey).Select(m => copyNow[m]).ToList();
                if (members.Count > 0) folders.Add(f.Id, members);
            }
        }

        /// <summary>A student of the file as this program's account of a copy (passwords locked again for this Windows user).</summary>
        public static Account AccountOf(BackupStudent b, string copy)
        {
            return new Account
            {
                Instance = copy, Trader = b.Trader, Login = b.Login, Server = b.Server, Mode = string.IsNullOrEmpty(b.Mode) ? "investor" : b.Mode,
                MasterEnc = Secret.Protect(b.Master ?? ""), InvestorEnc = Secret.Protect(b.Investor ?? ""), Platform = b.Kind,
                VerifyState = b.VerifyState == "checking" || b.VerifyState == "retry" ? "queued" : b.VerifyState, VerifyReason = b.VerifyReason, VerifyUtc = b.VerifyUtc,
            };
        }
    }

    /// <summary>3.24.1 (approved): the daily backup is one file that always holds the list as it is now (MetaFactory-auto.mfbak);
    /// every day the program looks whether anything changed since it was written (a student added, removed or edited, the folders,
    /// a new report) and writes it again only then, keeping the one before as MetaFactory-auto-previous.mfbak. A student removed from
    /// the program goes from it too. A backup made by hand (MetaFactory-backup-….mfbak) and the daily files of 3.24.0 are never touched.</summary>
    public static class AutoBackup
    {
        public const string Extension = ".mfbak", HandPrefix = "MetaFactory-backup-";
        public const string MainName = "MetaFactory-auto" + Extension, PreviousName = "MetaFactory-auto-previous" + Extension;
        public static string HandName(DateTime t, Func<string, bool> taken)
        {
            string day = HandPrefix + t.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
            if (!taken(day + Extension)) return day + Extension;
            return HandPrefix + t.ToString("yyyy-MM-dd-HHmm", CultureInfo.InvariantCulture) + Extension;
        }

        /// <summary>Due: on, a folder and a password set, and not looked at yet today.</summary>
        public static bool Due(bool on, string dir, bool hasPassword, DateTime checkedOn, DateTime now)
        {
            return on && !string.IsNullOrWhiteSpace(dir) && hasPassword && checkedOn.Date < now.Date;
        }

        /// <summary>What the backup holds, as a short text: the same as long as nothing in it changed (not when it was made, nor by
        /// which version of the program).</summary>
        public static string Fingerprint(BackupData d)
        {
            DateTime created = d.Created;
            string version = d.AppVersion;
            try
            {
                d.Created = DateTime.MinValue;
                d.AppVersion = "";
                using (var sha = SHA256.Create()) return Convert.ToBase64String(sha.ComputeHash(BackupFormat.Write(d)));
            }
            finally { d.Created = created; d.AppVersion = version; }
        }
    }
}
