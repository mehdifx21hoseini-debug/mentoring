using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using MTManager;

// Production UI queue exercised with an injected launcher; this is NOT a live MetaTrader capacity test.
static class ManualLaunchSmoke
{
    static int checks;
    static void Check(bool ok, string what) { if (!ok) throw new Exception(what); checks++; }
    static FieldInfo F(object o, string n) { return o.GetType().GetField(n, BindingFlags.Instance | BindingFlags.NonPublic); }
    static object Get(object o, string n) { return F(o,n).GetValue(o); }
    static void Set(object o, string n, object v) { F(o,n).SetValue(o,v); }
    static void Call(object o, string n, params object[] v) { o.GetType().GetMethod(n,BindingFlags.Instance|BindingFlags.NonPublic).Invoke(o,v); }
    static void Pump() { Application.DoEvents(); Thread.Sleep(10); }
    [STAThread] static int Main(string[] args)
    {
        var root=Path.Combine(Path.GetTempPath(),"manual-launch-"+Guid.NewGuid().ToString("N")); Directory.CreateDirectory(root);
        AppPaths.DataDirOverride=root; Lang.En=!args.Contains("fa");
        Application.EnableVisualStyles(); typeof(Account).Assembly.GetType("MTManager.Theme").GetMethod("Init",BindingFlags.Static|BindingFlags.Public).Invoke(null,null);
        var settings=new Settings { BaseDir=Path.Combine(root,"copies"), MaxMt4=1, DelaySeconds=0, AutoStart=false };
        Directory.CreateDirectory(settings.BaseDir); var accounts=new AccountStore();
        Process helper=null;
        try
        {
            var type=typeof(Account).Assembly.GetType("MTManager.MainForm");
            using(var main=(Form)Activator.CreateInstance(type,new object[]{settings,accounts}))
            {
                main.Show(); Pump();
                foreach(var f in type.GetFields(BindingFlags.Instance|BindingFlags.NonPublic))
                    if(f.FieldType==typeof(System.Windows.Forms.Timer)) ((System.Windows.Forms.Timer)f.GetValue(main)).Stop();
                var list=(List<Instance>)Get(main,"copies");list.Clear();
                for(int i=0;i<100;i++)
                {
                    var copy=new Instance { Name="launch-"+i, Kind=i<70?Kind.MT4:Kind.MT5, Dir=Path.Combine(settings.BaseDir,"launch-"+i) };
                    Directory.CreateDirectory(copy.Dir); File.WriteAllText(copy.Exe,"fake");list.Add(copy);
                }
                Set(main,"launchTotalRam",(Func<ulong>)(()=>8192)); Set(main,"launchFreeRam",(Func<ulong>)(()=>1));
                var attempted=new List<string>();
                Set(main,"startTerminal",(Func<Instance,StartResult>)(copy=>{
                    attempted.Add(copy.Name);
                    if(copy.Name=="launch-10" || copy.Name=="launch-42") throw new IOException("simulated OS launch failure");
                    return new StartResult();
                }));
                Call(main,"Enqueue",list.Concat(list).ToList());
                var queue=(Queue<Instance>)Get(main,"startQueue");
                Check(queue.Count==99,"duplicate selections are not enqueued twice");
                while(queue.Count>0) Call(main,"StartNext");
                Check(attempted.Count==100 && attempted.Distinct().Count()==100,"all 70 MT4 and 30 MT5 attempted despite legacy cap 1 and low memory");
                Check((int)Get(main,"launchFailed")==2,"per-copy launch errors counted without aborting batch");
                Check(((Dictionary<string,string>)Get(main,"launchErrors")).Count==2,"individual OS errors retained for diagnostics");
                Check(((string)Get(main,"launchMemoryWarning")).Length>0,"low memory is a visible non-modal advisory");
                Check(!((System.Windows.Forms.Timer)Get(main,"startTimer")).Enabled,"finished queue stops its timer");
                Set(main,"launchTotalRam",(Func<ulong>)(()=>0)); Call(main,"WarnLaunchMemory",list[0]);
                Check(((string)Get(main,"launchMemoryWarning")).Length>0,"unknown memory also warns without rejecting starts");
                Set(main,"launchTotalRam",(Func<ulong>)(()=>65536));Set(main,"launchFreeRam",(Func<ulong>)(()=>60000));Call(main,"WarnLaunchMemory",list[0]);
                Check(((string)Get(main,"launchMemoryWarning")).Length==0,"memory warning clears after recovery");
                helper=Process.Start(new ProcessStartInfo("/bin/sleep","120") { UseShellExecute=false });
                Set(main,"startTerminal",(Func<Instance,StartResult>)(copy=>{attempted.Add(copy.Name);return new StartResult();}));
                queue.Enqueue(list[70]);Set(main,"pacing",helper);Set(main,"lastLaunched",list[0]);Set(main,"lastStartAt",DateTime.Now.AddSeconds(-6));
                settings.DelaySeconds=5; int before=attempted.Count;Call(main,"PaceTick");
                Check(attempted.Count==before+1 && queue.Count==0,"no-window terminal cannot extend the configured five-second start interval");
                Check(!helper.HasExited,"slow terminal is left running, never killed to make room");
                helper.Kill();helper.WaitForExit();queue.Enqueue(list[71]);Set(main,"pacing",helper);Set(main,"lastStartAt",DateTime.Now.AddSeconds(-3));
                before=attempted.Count;Call(main,"PaceTick");
                Check(attempted.Count==before+1,"early exit does not cancel later launches");
                var missing=new Instance{Name="missing-template",Kind=Kind.MT4,Dir=Path.Combine(root,"missing")};
                queue.Enqueue(missing);queue.Enqueue(list[72]);before=attempted.Count;Call(main,"StartNext");
                var clock=Stopwatch.StartNew();while(((bool)Get(main,"preparingCopy") || queue.Count>0)&&clock.ElapsedMilliseconds<5000) Pump();
                Check(queue.Count==0 && attempted.Count==before+1,"copy preparation failure continues to next copy without a dialog");
                Check(((Dictionary<string,string>)Get(main,"launchErrors")).ContainsKey(missing.Name),"preparation failure retained for review");
                Call(main,"Enqueue",new List<Instance>{list[10]});
                Check(!((Dictionary<string,string>)Get(main,"launchErrors")).ContainsKey(list[10].Name),"successful retry clears previous launch error");
                queue.Enqueue(list[90]); Set(main,"appClosing",true); before=attempted.Count; Call(main,"StartNext");
                Check(attempted.Count==before && queue.Count==1,"application close still prevents further starts");
                queue.Clear(); Set(main,"appClosing",false);
                var settingsType=typeof(Account).Assembly.GetType("MTManager.SettingsDialog");
                using(var dialog=(Form)Activator.CreateInstance(settingsType,new object[]{settings}))
                {
                    dialog.Show();Pump();
                    var normalRights=(CheckBox)Get(dialog,"normalRights");
                    Check(normalRights.Checked,"current-privilege setting is enabled and visible in settings");
                    using(var image=new System.Drawing.Bitmap(dialog.Width,dialog.Height))
                    {
                        dialog.DrawToBitmap(image,new System.Drawing.Rectangle(0,0,image.Width,image.Height));
                        image.Save("/workspace/MetaFactory-delivery/MetaFactory-3.40.1-settings-"+(Lang.En?"en":"fa")+".png");
                    }
                    Check(dialog.ClientSize.Height<=900,"settings remain usable at laptop height");dialog.Close();
                }
                main.Close();
            }
            Console.WriteLine("Manual launch queue: "+checks+" checks passed (simulated launcher, 70 MT4 + 30 MT5; no live broker validation).");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
        finally{if(helper!=null){try{if(!helper.HasExited)helper.Kill();}catch{}helper.Dispose();}try{Directory.Delete(root,true);}catch{}}
    }
}
