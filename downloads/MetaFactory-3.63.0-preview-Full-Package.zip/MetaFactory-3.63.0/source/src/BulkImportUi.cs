using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MTManager
{
    sealed class ImportProgress : Control
    {
        int value, maximum = 1;
        public int Value { get { return value; } set { this.value = Math.Max(0, Math.Min(maximum, value)); Invalidate(); } }
        public int Maximum { get { return maximum; } set { maximum = Math.Max(1, value); Invalidate(); } }
        public ImportProgress() { SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true); }
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Theme.Surface);
            if (Width < 3 || Height < 3) return;
            Theme.Box(e.Graphics, new Rectangle(0, 0, Width - 1, Height - 1), Height / 2f, Theme.Border, Theme.Border);
            int filled = Width * value / maximum;
            if (filled > 2) Theme.Box(e.Graphics, new Rectangle(Lang.En ? 0 : Width - filled, 0, filled - 1, Height - 1), Height / 2f, Theme.Accent, Theme.Accent);
        }
    }

    /// <summary>Preview first, then one terminal at a time; results remain visible and exportable.</summary>
    sealed class StudentImportDialog : Form
    {
        readonly Settings settings;
        readonly ImportCoordinator coordinator;
        bool following, finalExported;
        bool CheckingNow {get{return following&&runRows.Any(r=>r.State==ImportState.Registered||r.State==ImportState.Checking);}}
        string automaticResultPath = "";
        readonly AccountStore accounts;
        readonly DataGridView grid = new DataGridView();
        string summaryText = "";
        readonly Label fileName = new Label();
        readonly ImportProgress progress = new ImportProgress();
        readonly Button open, template, start, retry, export, close;
        readonly Button pasteText, editRow, copyIssues, inputExcel; bool editingGrid;
        readonly BackgroundWorker worker = new BackgroundWorker();
        List<StudentImportRow> rows = new List<StudentImportRow>();
        volatile bool stop;
        bool running;
        public IEnumerable<StudentImportRow> Results { get { return rows; } }

        readonly Label stageLine = new Label();
        readonly Label activeStudent = new Label(), livePhase = new Label(), elapsed = new Label(), fraction = new Label();
        readonly Label privacy = new Label();
        readonly Button dismiss;
        readonly Label totals = new Label();
        readonly ImportFileCard fileCard;
        readonly ToolTip hints = new ToolTip();
        readonly System.Windows.Forms.Timer heartbeat = new System.Windows.Forms.Timer { Interval = 250 };
        readonly System.Diagnostics.Stopwatch runClock = new System.Diagnostics.Stopwatch();
        List<StudentImportRow> runRows = new List<StudentImportRow>();
        bool hasRun;
        internal Func<IStudentImportRuntime> RuntimeFactory;

        public StudentImportDialog(Settings settings,AccountStore accounts,FolderStore folders,string defaultFolder,ImportCoordinator imports=null):this(settings,accounts,folders,defaultFolder,imports,false){}
        public StudentImportDialog(Settings settings, AccountStore accounts, FolderStore folders, string defaultFolder, ImportCoordinator imports, bool textFirst)
        {
            this.settings = settings; this.accounts = accounts; coordinator = imports;
            RuntimeFactory = () => new StudentImportRuntime(settings, accounts, folders, defaultFolder);
            Text = Lang.T("افزودن گروهی دانشجوها", "Add students");
            StartPosition = FormStartPosition.CenterParent;
            AutoScaleMode = AutoScaleMode.None;
            Rectangle screen = Screen.FromPoint(Cursor.Position).WorkingArea;
            ClientSize = new Size(Math.Min(Theme.S(1240), screen.Width - 50), Math.Min(Theme.S(800), screen.Height - 60));
            MinimumSize = new Size(Math.Min(Theme.S(900), screen.Width - 50), Math.Min(Theme.S(560), screen.Height - 90));
            BackColor = Theme.Surface; ForeColor = Theme.Text; Font = Theme.Font;
            RightToLeft = Theme.Dir; RightToLeftLayout = false;
            ShowIcon = false; ShowInTaskbar = false;
            Theme.Window(this);
            BackColor = Theme.Surface;
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 9, Padding = Theme.Pad(20, 12, 20, 6) };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            for (int i = 0; i < 9; i++) layout.RowStyles.Add(new RowStyle(i == 4 ? SizeType.Percent : i == 0 ? SizeType.Absolute : SizeType.AutoSize, i == 4 ? 100 : i == 0 ? Theme.S(76) : 0));
            Controls.Add(layout);
            var header=Theme.GraphiteHeader(Lang.T("افزودن دانشجو از متن یا اکسل","Add students from text or Excel"),Lang.T("بررسی ورود و ثبت فقط حساب‌های متصل","Verify login and add only connected accounts"));header.Dock=DockStyle.Fill;layout.Controls.Add(header,0,0);

            start = Button(Lang.T("شروع افزودن", "Start import"), Begin, ButtonKind.Primary, Glyph.Play);
            open = Button(Lang.T("تغییر فایل", "Choose file"), OpenFile, ButtonKind.Secondary, Glyph.Folder);
            template = Button(Lang.T("الگوی Excel", "Excel template"), SaveTemplate, ButtonKind.Subtle, Glyph.Doc);
            fileName.AutoEllipsis = true; fileName.ForeColor = Theme.Text;
            fileName.Text = Lang.T("یک فایل Excel انتخاب کنید", "Choose an Excel workbook");
            fileCard = new ImportFileCard(fileName, open, template) { Dock = DockStyle.Fill, Margin = Theme.Pad(0, 0, 0, 6) };
            layout.Controls.Add(fileCard, 0, 2);
            var sourceActions=new ButtonRow{Dock=DockStyle.Fill};
            pasteText=Button(Lang.T("چسباندن متن…","Paste text…"),PasteText,ButtonKind.Primary,Glyph.CopyText);
            editRow=Button(Lang.T("ویرایش ردیف…","Edit row…"),EditRow,ButtonKind.Secondary,Glyph.NoteEdit);
            copyIssues=Button(Lang.T("کپی موارد نیازمند اصلاح","Copy issues"),CopyIssues,ButtonKind.Subtle,Glyph.CopyText);
            inputExcel=Button(Lang.T("اطلاعات به Excel…","Data to Excel…"),InputExcel,ButtonKind.Subtle,Glyph.Sheet);
            sourceActions.Add(pasteText);sourceActions.Add(editRow);sourceActions.Add(copyIssues);sourceActions.Add(inputExcel);layout.Controls.Add(sourceActions,0,1);
            totals.Dock = DockStyle.Fill; totals.Height = Theme.S(38); totals.Font = Theme.Bold; totals.ForeColor = Theme.LabelColor;
            totals.TextAlign = Lang.En ? ContentAlignment.MiddleLeft : ContentAlignment.MiddleRight;
            totals.Margin = Theme.Pad(0, 0, 0, 8); layout.Controls.Add(totals, 0, 3);
            grid.Dock = DockStyle.Fill; grid.BackgroundColor = Theme.Surface; grid.BorderStyle = BorderStyle.None;
            grid.ReadOnly = false; grid.AllowUserToAddRows = false; grid.AllowUserToDeleteRows = false; grid.AllowUserToOrderColumns = false;
            grid.AllowUserToResizeRows = false; grid.AutoGenerateColumns = false; grid.RowHeadersVisible = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; grid.MultiSelect = false;
            grid.RightToLeft = Theme.Dir; grid.Font = Theme.Font;
            grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None; grid.RowTemplate.Height = Theme.S(44);
            grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal; grid.GridColor = Theme.Border;
            grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing; grid.ColumnHeadersHeight = Theme.S(40);
            grid.DefaultCellStyle.BackColor = Theme.Surface; grid.DefaultCellStyle.ForeColor = Theme.Text;
            grid.DefaultCellStyle.SelectionBackColor = Theme.Surface; grid.DefaultCellStyle.SelectionForeColor = Theme.Text;
            grid.DefaultCellStyle.Padding = Theme.Pad(5, 3); grid.DefaultCellStyle.Alignment = Lang.En ? DataGridViewContentAlignment.MiddleLeft : DataGridViewContentAlignment.MiddleRight;
            grid.DefaultCellStyle.WrapMode = DataGridViewTriState.False; grid.EnableHeadersVisualStyles = false;
            grid.ColumnHeadersDefaultCellStyle.BackColor = Theme.Footer; grid.ColumnHeadersDefaultCellStyle.ForeColor = Theme.Muted;
            grid.ColumnHeadersDefaultCellStyle.Font = Theme.SmallBold;
            string[] titles = { Lang.T("سطر", "Row"), Lang.T("نام دانشجو", "Name"), Lang.T("پلتفرم", "Platform"), Lang.T("حساب", "Account"), Lang.T("سرور", "Server"), Lang.T("پوشه", "Group"), Lang.T("نسخه", "Copy"), Lang.T("وضعیت", "Status"), Lang.T("توضیحات", "Details") };
            int[] widths = { 48, 145, 48, 100, 150, 110, 85, 145, 250 };
            for (int i = 0; i < titles.Length; i++) grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = titles[i], Width = Theme.S(widths[i]), SortMode = DataGridViewColumnSortMode.NotSortable });
            grid.Columns[0].Visible = false; grid.Columns[5].Visible = false; grid.Columns[6].Visible = false;
            grid.Columns[3].DisplayIndex = 2; grid.Columns[2].DisplayIndex = 3;
            int[] shown = { 1, 2, 3, 4, 7, 8 }, weights = { 17, 7, 12, 21, 16, 27 }, minimum = { 110, 55, 90, 135, 115, 180 };
            for (int i = 0; i < shown.Length; i++) { var col = grid.Columns[shown[i]]; col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill; col.FillWeight = weights[i]; col.MinimumWidth = Theme.S(minimum[i]); }
            for(int c=0;c<grid.Columns.Count;c++)grid.Columns[c].ReadOnly=c<1||c>4;
            grid.CellBeginEdit+=(s,e)=>{if(running||CheckingNow||rows[e.RowIndex].Saved)e.Cancel=true;};
            grid.CellEndEdit+=(s,e)=>{if(editingGrid||e.RowIndex<0||e.RowIndex>=rows.Count)return;var row=rows[e.RowIndex];string value=Convert.ToString(grid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value);switch(e.ColumnIndex){case 1:row.Name=value;break;case 2:row.Platform=value;row.ImportServers="";break;case 3:row.Login=value;row.LoginNeedsCorrection=false;break;case 4:row.Server=value;row.ImportServers="";break;}row.InputProblem="";RevalidatePreview();};
            grid.CellDoubleClick+=(s,e)=>{if(e.RowIndex>=0&&e.ColumnIndex>=7)EditRow(s,EventArgs.Empty);};
            grid.CellClick+=(s,e)=>{if(e.RowIndex<0||e.ColumnIndex!=7)return;var r=rows[e.RowIndex];if(r.State==ImportState.Invalid||r.State==ImportState.Failed||r.State==ImportState.Unconfirmed)SafeClipboard.Copy(TextStudentImport.CorrectionText(new[]{r}));};
            grid.DataError+=(s,e)=>{e.ThrowException=false;};
            grid.CellPainting += PaintBadge;
            grid.Columns[8].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            var card = new ListCard { Dock = DockStyle.Fill, Margin = Padding.Empty };
            card.Controls.Add(grid); layout.Controls.Add(card, 0, 4);
            var live = new Panel { Dock = DockStyle.Fill, Height = Theme.S(58), Padding = Theme.Pad(0, 8, 0, 6), Margin = Theme.Pad(0, 6, 0, 4) };
            var liveGrid = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, RightToLeft = Theme.Dir, Margin = Padding.Empty };
            liveGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80)); liveGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            liveGrid.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); liveGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, Theme.S(7)));
            activeStudent.Font = Theme.Font; activeStudent.ForeColor = Theme.Text; activeStudent.AutoEllipsis = true;
            fraction.Font = Theme.Small; fraction.ForeColor = Theme.Muted;
            activeStudent.Dock = fraction.Dock = DockStyle.Fill; activeStudent.Margin = fraction.Margin = Padding.Empty;
            activeStudent.TextAlign = Lang.En ? ContentAlignment.MiddleLeft : ContentAlignment.MiddleRight;
            fraction.TextAlign = Lang.En ? ContentAlignment.MiddleRight : ContentAlignment.MiddleLeft;
            progress.Dock = DockStyle.Fill; progress.Margin = Padding.Empty;
            liveGrid.Controls.Add(activeStudent, 0, 0); liveGrid.Controls.Add(fraction, 1, 0);
            liveGrid.Controls.Add(progress, 0, 1); liveGrid.SetColumnSpan(progress, 2);
            live.Controls.Add(liveGrid); layout.Controls.Add(live, 0, 5);
            var bottom = new ButtonRow { Dock = DockStyle.Fill, BackColor = Theme.Surface, Padding = Theme.Pad(0, 6) };
            close = Button(Lang.T("توقف بررسی", "Stop checks"), (s1, e1) => { if (running || following) RequestStop(); }, ButtonKind.Secondary);
            dismiss = Button(Lang.T("بستن", "Close"), (s1, e1) => Close(), ButtonKind.Subtle);
            export = Button(Lang.T("ذخیره نتیجه", "Save results"), Export, ButtonKind.Primary, Glyph.Doc);
            ((ModernButton)close).Outline = true; ((ModernButton)export).Outline = true;
            retry = Button(Lang.T("تلاش دوباره", "Retry"), Retry, ButtonKind.Secondary, Glyph.Refresh);
            bottom.Add(close); bottom.Add(dismiss); bottom.AddApart(start); bottom.AddApart(export); bottom.AddApart(retry); layout.Controls.Add(bottom, 0, 7);
            privacy.Dock = DockStyle.Fill; privacy.Height = Theme.S(18); privacy.Margin = Padding.Empty; privacy.Font = Theme.Small; privacy.ForeColor = Theme.Muted;
            privacy.TextAlign = Lang.En ? ContentAlignment.MiddleLeft : ContentAlignment.MiddleRight;
            privacy.Text = Lang.T("رمزها در خروجی نتیجه ذخیره نمی‌شوند.", "Passwords are never included in result exports."); hints.SetToolTip(export, privacy.Text);
            worker.WorkerReportsProgress = true;
            worker.DoWork += (s, e) => {
                if (imports != null) { imports.VerifyAndRegister(runRows, defaultFolder, () => stop, r => worker.ReportProgress(0, r)); return; }
                IStudentImportRuntime runtime = RuntimeFactory();
                try { StudentImport.Run(runRows, runtime, () => stop, r => worker.ReportProgress(0, r)); }
                finally { var disposable = runtime as IDisposable; if (disposable != null) disposable.Dispose(); }
            };
            worker.ProgressChanged += (s, e) => { Render((StudentImportRow)e.UserState); Counts(); };
            worker.RunWorkerCompleted += (s, e) => {
                running = false; heartbeat.Stop(); runClock.Stop(); close.Enabled = true;
                Log.Write("bulk import finished: rows=" + runRows.Count + ", stopped=" + stop);
                close.Text = Lang.T("توقف بررسی", "Stop checks");
                if (e.Error != null)
                    foreach (var r in runRows.Where(r => r.State == ImportState.Ready || r.State == ImportState.Creating || r.State == ImportState.Checking))
                    { r.State = ImportState.Failed; r.Reason = Lang.T("عملیات با خطا متوقف شد؛ دوباره امتحان کنید.", "The operation stopped with an error; retry."); }
                foreach (StudentImportRow r in rows) Render(r);
                Counts();
                try
                {
                    string dir = Path.Combine(AppPaths.DataDir, "imports"); Directory.CreateDirectory(dir);
                    string path = Path.Combine(dir, "import-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 6) + ".xlsx");
                    automaticResultPath = path;
                    StudentImport.Export(path, rows);
                    hints.SetToolTip(export, Lang.T("آخرین نتیجه: ", "Latest results: ") + path);
                    hints.SetToolTip(privacy, path);
                }
                catch (Exception ex) { Ui.Error(this, ex); }
                if (e.Error != null) Ui.Error(this, e.Error);
                if (imports != null && e.Error == null && runRows.Any(r => r.State == ImportState.Registered))
                {
                    following = true; finalExported = false; runClock.Start(); if (stop) imports.Pause(); imports.Start(); heartbeat.Start(); SyncChecks();
                }
            };
            heartbeat.Tick += (s, e) => { if (following) { SyncChecks(); return; } foreach (var r in runRows.Where(r => r.State == ImportState.Creating || r.State == ImportState.Checking)) Render(r); Counts(); };
            FormClosing += (s, e) => { if (running) { RequestStop(); e.Cancel = true; } };
            FormClosed += (s, e) => { foreach (StudentImportRow r in rows) { r.Investor = ""; r.Master = ""; } heartbeat.Dispose(); hints.Dispose(); worker.Dispose(); stageLine.Dispose(); livePhase.Dispose(); elapsed.Dispose(); privacy.Dispose(); };
            if (imports != null)
            {
                start.Text = Lang.T("بررسی و افزودن آماده‌ها", "Verify and add ready accounts");
                hints.SetToolTip(start, Lang.T("فقط پس از تأیید ورود ثبت می‌شود؛ موارد ناموفق همین‌جا برای اصلاح می‌مانند.", "Only verified accounts are added; unsuccessful rows stay here for correction."));
            }
            Counts();
            if(textFirst)Shown+=(s,e)=>BeginInvoke(new Action(()=>PasteText(this,EventArgs.Empty)));
        }

        Button Button(string text, EventHandler click, ButtonKind kind = ButtonKind.Secondary, Glyph icon = Glyph.None)
        {
            return new ModernButton(text, click, kind, icon) { Margin = Theme.Pad(4, 4) };
        }

        void RequestStop()
        {
            if (following && coordinator != null)
            {
                try { coordinator.Pause(); stop = true; SyncChecks(); }
                catch (Exception e) { Ui.Error(this, e); }
                return;
            }
            stop = true; close.Enabled = false; close.Text = Lang.T("در حال توقف…", "Stopping…"); Counts();
        }

        internal void LoadPreview(List<StudentImportRow> next,string title)
        {foreach(var r in rows){r.Investor="";r.Master="";}rows=next;following=false;hasRun=false;runRows.Clear();grid.Rows.Clear();foreach(var r in rows)grid.Rows.Add(r.Line,r.Name,r.Platform,r.Login,r.Server,r.Folder,r.Copy,StudentImport.Status(r.State),r.Reason);foreach(var r in rows)Render(r);fileName.Text=title;Counts();}
        IEnumerable<string> Existing(){return accounts.All.Select(a=>StudentImport.Key(StudentDirectory.KindOf(a),a.Login,a.Server)).ToArray();}
        void RevalidatePreview(){if(running||CheckingNow||rows.Count==0)return;TextStudentImport.Revalidate(rows.Where(r=>!r.Saved),Existing());foreach(var r in rows)Render(r);Counts();}
        void PasteText(object sender,EventArgs e)
        {
            if(running||following&&runRows.Any(r=>r.State==ImportState.Registered||r.State==ImportState.Checking))return;
            using(var d=new TextImportEntryDialog(settings,accounts))
            {if(d.ShowDialog(this)!=DialogResult.OK)return;LoadPreview(d.Rows,Lang.T("اطلاعات خوانده‌شده از متن","Information read from text"));}
        }
        void EditRow(object sender,EventArgs e)
        {if(running||CheckingNow||grid.CurrentCell==null)return;var r=rows[grid.CurrentCell.RowIndex];if(r.Saved)return;using(var d=new ImportRowEditDialog(r)){if(d.ShowDialog(this)==DialogResult.OK)RevalidatePreview();}}
        void CopyIssues(object sender,EventArgs e)
        {string text=TextStudentImport.CorrectionText(rows);if(text.Length>0)SafeClipboard.Copy(text);}
        void InputExcel(object sender,EventArgs e)
        {
            grid.EndEdit();using(var d=new SaveFileDialog{Filter="Excel Workbook (*.xlsx)|*.xlsx",FileName="MetaFactory-students.xlsx"})
            {if(d.ShowDialog(this)!=DialogResult.OK)return;try{StudentImport.WriteInput(d.FileName,rows);}catch(Exception ex){Ui.Error(this,ex);}}
        }

        void SaveTemplate(object sender, EventArgs e)
        {
            using (var d = new SaveFileDialog { Filter = "Excel Workbook (*.xlsx)|*.xlsx", FileName = "MetaFactory-students.xlsx", DefaultExt = "xlsx" })
            { if (d.ShowDialog(this) != DialogResult.OK) return; try { StudentImport.Template(d.FileName); Ui.Message(this, Lang.T("فایل الگو ذخیره شد. راهنما در شیت Guide است.", "Template saved. Instructions are on the Guide sheet.")); } catch (Exception ex) { Ui.Error(this, ex); } }
        }

        void OpenFile(object sender, EventArgs e)
        {
            using (var d = new OpenFileDialog { Filter = "Excel Workbook (*.xlsx)|*.xlsx", CheckFileExists = true })
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    var kinds = Installs.Copies(settings).ToDictionary(i => i.Name, i => i.Kind, StringComparer.OrdinalIgnoreCase);
                    var existing = accounts.All.Select(a => StudentImport.Key(kinds.ContainsKey(a.Instance) ? kinds[a.Instance] : a.Instance.StartsWith("MT4", StringComparison.OrdinalIgnoreCase) ? Kind.MT4 : Kind.MT5, a.Login, a.Server)).ToList();
                    List<StudentImportRow> next = StudentImport.Read(d.FileName, existing, true);
                    LoadPreview(next,Path.GetFileName(d.FileName)); hints.SetToolTip(fileName, d.FileName);
                    Counts();
                }
                catch (Exception ex) { Ui.Error(this, ex); }
            }
        }

        void Begin(object sender, EventArgs e)
        {
            if (running || (following && runRows.Any(r => r.State == ImportState.Registered || r.State == ImportState.Checking)) || !rows.Any(r => r.State == ImportState.Ready)) return;
            grid.EndEdit();RevalidatePreview();
            runRows = rows.Where(r => r.State == ImportState.Ready).ToList();
            stop = false; running = true; hasRun = true; runClock.Restart();
            Log.Write("bulk import started: rows=" + runRows.Count);
            close.Text = Lang.T("توقف بررسی", "Stop checks");
            Counts(); heartbeat.Start();
            try { worker.RunWorkerAsync(); }
            catch { running = false; heartbeat.Stop(); runClock.Stop(); close.Text = Lang.T("توقف بررسی", "Stop checks"); Counts(); throw; }
        }

        void Retry(object sender, EventArgs e)
        {
            if (following && coordinator != null)
            {
                var retryRows = rows.Where(r => r.Saved && (r.State == ImportState.Failed || r.State == ImportState.Cancelled || r.State == ImportState.Unconfirmed)).ToList();
                if (retryRows.Count == 0) return;
                try
                {
                    coordinator.RecheckMany(retryRows.Select(r => r.Copy));
                    stop = false; finalExported = false; runClock.Restart(); heartbeat.Start(); SyncChecks();
                }
                catch (Exception ex) { Ui.Error(this, ex); }
                return;
            }
            foreach (StudentImportRow r in rows.Where(r => (r.State == ImportState.Failed || r.State == ImportState.Cancelled || r.State == ImportState.Unconfirmed))) { r.State = ImportState.Ready; r.Reason = ""; Render(r); }
            Begin(sender, e);
        }

        void SyncChecks()
        {
            foreach (StudentImportRow r in runRows.Where(r => r.Saved))
            {
                Account account = accounts.Get(r.Copy);
                if (account == null) { r.State = ImportState.Failed; r.Reason = Lang.T("این حساب از فهرست حذف شد.", "This account was removed."); Render(r); continue; }
                ImportState state;
                switch (account.VerifyState)
                {
                    case "connected": state = ImportState.Connected; break;
                    case "rejected": state = ImportState.Failed; r.Outcome = Login.WrongLogin; break;
                    case "unconfirmed": state = ImportState.Unconfirmed; break;
                    case "checking": state = ImportState.Checking; break;
                    case "paused": state = ImportState.Cancelled; break;
                    default: state = ImportState.Registered; break;
                }
                r.Server=account.Server;r.ImportServers=account.ImportServers;
                string reason = account.VerifyReason;
                if (state == ImportState.Registered) reason = account.VerifyState == "retry"
                    ? Lang.T("در صف بررسی تکمیلی؛ حساب‌های دیگر ادامه دارند.", "Deferred to an extended check; other accounts continue.")
                    : Lang.T("ثبت شد؛ در صف بررسی اتصال.", "Registered; queued for connection check.");
                if (state != r.State || reason != r.Reason || Convert.ToString(grid.Rows[rows.IndexOf(r)].Cells[4].Value)!=r.Server) { r.State = state; r.Reason = reason; Render(r); }
            }
            bool pending = runRows.Any(r => r.State == ImportState.Registered || r.State == ImportState.Checking);
            if (!pending)
            {
                heartbeat.Stop(); runClock.Stop();
                if (!finalExported && automaticResultPath.Length > 0)
                {
                    finalExported = true;
                    try { StudentImport.Export(automaticResultPath, rows); }
                    catch (Exception e) { Log.Write("bulk final result export: " + e.GetType().Name); }
                }
            }
            Counts();
        }

        void Render(StudentImportRow r)
        {
            int i = rows.IndexOf(r); if (i < 0 || i >= grid.Rows.Count) return;
            DataGridViewRow display = grid.Rows[i];
            editingGrid=true;
            display.Cells[1].Value=r.Name;display.Cells[2].Value=r.Platform;display.Cells[3].Value=r.Login;display.Cells[4].Value=r.Server;
            string details=ImportPersian.Details(r.Redact(r.Reason));
            display.Cells[5].Value = r.Folder; display.Cells[6].Value = r.Copy; display.Cells[7].Value = StudentImport.Status(r.State); display.Cells[8].Value = details;
            int detailWidth=Math.Max(80,display.Cells[8].Size.Width-Theme.S(16));
            int detailHeight=TextRenderer.MeasureText(details,Theme.Font,new Size(detailWidth,0),TextFormatFlags.WordBreak|TextFormatFlags.TextBoxControl|TextFormatFlags.RightToLeft|TextFormatFlags.NoPadding).Height+Theme.S(16);
            display.Height=Math.Max(Theme.S(48),Math.Min(Theme.S(160),detailHeight));
            display.DefaultCellStyle.BackColor = r.State == ImportState.Creating || r.State == ImportState.Checking ? Theme.AccentSoft : Theme.Surface;
            display.DefaultCellStyle.SelectionBackColor = display.DefaultCellStyle.BackColor;
            display.Cells[7].Style.ForeColor = r.State == ImportState.Connected ? Theme.Ok : r.State == ImportState.Invalid || r.State == ImportState.Failed ? Theme.Bad : r.State == ImportState.Unconfirmed ? Theme.Warn : r.State == ImportState.Duplicate ? Theme.Muted : Theme.Accent;
            display.Cells[8].ToolTipText = details;
            display.Cells[7].ToolTipText=(r.State==ImportState.Invalid||r.State==ImportState.Failed||r.State==ImportState.Unconfirmed)?Lang.T("کلیک: کپی اطلاعات و درخواست اصلاح، بدون رمز","Click: copy account details and correction request, without passwords"):details;
            display.Cells[5].ToolTipText = r.Folder; display.Cells[1].ToolTipText = Lang.T("نام اصلی: ", "Original name: ")+r.OriginalName+" · "+Lang.T("سطر: ", "Row: ") + r.Line;
            editingGrid=false;
            grid.InvalidateRow(i);
        }

        void PaintBadge(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if(e.RowIndex>=0&&e.RowIndex<rows.Count&&e.ColumnIndex==8)
            {
                e.PaintBackground(e.ClipBounds,true);var area=Rectangle.Inflate(e.CellBounds,-Theme.S(8),-Theme.S(6));
                TextRenderer.DrawText(e.Graphics,Convert.ToString(e.FormattedValue),Theme.Font,area,Theme.Text,TextFormatFlags.RightToLeft|TextFormatFlags.Right|TextFormatFlags.WordBreak|TextFormatFlags.TextBoxControl|TextFormatFlags.NoPrefix|TextFormatFlags.NoPadding);
                e.Paint(e.ClipBounds,DataGridViewPaintParts.Border);e.Handled=true;return;
            }
            if (e.RowIndex < 0 || e.RowIndex >= rows.Count || (e.ColumnIndex != 2 && e.ColumnIndex != 7)) return;
            StudentImportRow r = rows[e.RowIndex];
            e.PaintBackground(e.ClipBounds, true);
            Color ink = Theme.Accent, fill = Theme.AccentSoft; Glyph glyph = Glyph.None;
            string text = Convert.ToString(e.FormattedValue);
            if (e.ColumnIndex == 2)
            {
                if (r.Platform == "MT5") { ink = Theme.Violet; fill = Theme.VioletSoft; }
            }
            else switch (r.State)
            {
                case ImportState.Registered: ink = Theme.Muted; fill = Theme.Footer; glyph = Glyph.Info; text = Lang.T("در صف بررسی", "Queued for check"); break;
                case ImportState.Connected: ink = Theme.Ok; fill = Theme.OkSoft; glyph = Glyph.Check; text = Lang.T("متصل شد", "Connected"); break;
                case ImportState.Checking: glyph = Glyph.Refresh; text = Lang.T("در حال بررسی", "Checking"); break;
                case ImportState.Creating: glyph = Glyph.Refresh; text = Lang.T("در حال افزودن", "Adding"); break;
                case ImportState.Unconfirmed: ink = Theme.Warn; fill = Theme.WarnSoft; glyph = Glyph.Warning; text = Lang.T("تأیید نشد", "Unconfirmed"); break;
                case ImportState.Invalid: case ImportState.Failed: ink = Theme.Bad; fill = Theme.BadSoft; glyph = Glyph.Warning; text = Lang.T("ناموفق", "Failed"); break;
                case ImportState.Duplicate: ink = Theme.Muted; fill = Theme.Footer; glyph = Glyph.Copies; text = Lang.T("تکراری", "Duplicate"); break;
                case ImportState.Cancelled: ink = Theme.Muted; fill = Theme.Footer; glyph = Glyph.Stop; text = Lang.T("متوقف", "Stopped"); break;
                default: ink = Theme.Muted; fill = Theme.Footer; glyph = Glyph.Info; text = running ? Lang.T("در صف", "Queued") : Lang.T("آماده", "Ready"); break;
            }
            Rectangle bounds = Rectangle.Inflate(e.CellBounds, -Theme.S(8), 0);
            if (e.ColumnIndex == 7)
            {
                int dot = Theme.S(7), gap = Theme.S(8);
                int dx = Lang.En ? bounds.Left : bounds.Right - dot;
                using (var brush = new SolidBrush(ink)) e.Graphics.FillEllipse(brush, dx, bounds.Top + (bounds.Height - dot) / 2, dot, dot);
                if (Lang.En) bounds.X += dot + gap;
                bounds.Width -= dot + gap;
            }
            if(e.ColumnIndex==7&&(r.State==ImportState.Invalid||r.State==ImportState.Failed||r.State==ImportState.Unconfirmed))
            {int size=Theme.S(13);var icon=new Rectangle(Lang.En?bounds.Right-size:bounds.Left,bounds.Top+(bounds.Height-size)/2,size,size);Glyphs.Draw(e.Graphics,Glyph.CopyText,icon,ink);if(!Lang.En)bounds.X+=size+Theme.S(5);bounds.Width-=size+Theme.S(5);}
            ImportArt.Text(e.Graphics, text, Theme.Font, e.ColumnIndex == 2 ? Theme.Text : ink, bounds);
            e.Paint(e.ClipBounds, DataGridViewPaintParts.Border);
            e.Handled = true;
        }

        void Counts()
        {
            bool checkingNow = following && runRows.Any(r => r.State == ImportState.Registered || r.State == ImportState.Checking);
            int ready = rows.Count(r => r.State == ImportState.Ready), connected = rows.Count(r => r.State == ImportState.Connected);
            summaryText = Lang.T("آماده: ", "Ready: ") + Fa.N(ready) + Lang.T("   ·   ذخیره‌شده: ", "   ·   Saved: ") + Fa.N(rows.Count(r => r.Saved)) + Lang.T("   ·   تکراری: ", "   ·   Duplicates: ") + Fa.N(rows.Count(r => r.State == ImportState.Duplicate)) + Lang.T("   ·   متوقف‌شده: ", "   ·   Stopped: ") + Fa.N(rows.Count(r => r.State == ImportState.Cancelled));
            int review = rows.Count(r => r.State == ImportState.Invalid || r.State == ImportState.Failed || r.State == ImportState.Unconfirmed || r.State == ImportState.Cancelled);
            totals.Text = Fa.N(rows.Count) + Lang.T(" دانشجو   ·   ", " students   ·   ") + Fa.N(connected) + Lang.T(" متصل   ·   ", " connected   ·   ") + Fa.N(review) + Lang.T(" نیاز به بررسی   ·   ", " need review   ·   ") + Fa.N(ready + rows.Count(r => r.State == ImportState.Registered)) + Lang.T(" در انتظار", " queued");
            hints.SetToolTip(totals, summaryText); fileCard.Count = rows.Count;
            int processed = runRows.Count(r => (!following && r.State == ImportState.Registered) || r.State == ImportState.Connected || r.State == ImportState.Failed || r.State == ImportState.Cancelled || r.State == ImportState.Unconfirmed);
            progress.Maximum = Math.Max(1, runRows.Count);
            progress.Value = hasRun ? processed : 0;
            StudentImportRow active = runRows.FirstOrDefault(r => r.State == ImportState.Creating || r.State == ImportState.Checking);
            activeStudent.Text = active != null ? Lang.T("در حال بررسی: ", "Checking: ") + active.Name : (running || checkingNow) ? Lang.T("ردیف بعدی", "Next student") : hasRun ? Lang.T("پایان این نوبت", "Run complete") : Lang.T("آماده‌ی شروع", "Ready to begin");
            livePhase.Text = running || checkingNow ? stop ? Lang.T("در حال توقف", "Stopping") : (active != null && active.State == ImportState.Creating ? Lang.T("آماده‌سازی حساب", "Preparing account") : Lang.T("در حال بررسی اتصال", "Checking connections")) : hasRun ? Lang.T("نتیجه‌ی بررسی", "Check results") : Lang.T("پیش‌نمایش اطلاعات", "Preview data");
            elapsed.Text = Lang.T("زمان سپری‌شده: ", "Elapsed: ") + Fa.N((int)runClock.Elapsed.TotalSeconds) + Lang.T(" ثانیه", " seconds");
            fraction.Text = hasRun ? Fa.N(processed) + Lang.T(" از ", " of ") + Fa.N(runRows.Count) : Lang.T("هنوز شروع نشده", "Not started");
            if (running || checkingNow)
                stageLine.Text = stop ? Lang.T("در حال توقف امن عملیات…", "Stopping the operation safely…") : active == null ? Lang.T("شروع ردیف بعدی…", "Starting next student…") : active.Reason.Length > 0 ? active.Reason : StudentImport.Status(active.State);
            else if (hasRun) stageLine.Text = stop ? Lang.T("عملیات متوقف شد؛ حساب‌های ذخیره‌شده باقی مانده‌اند و موارد دیگر قابل تلاش دوباره‌اند.", "Stopped; saved accounts remain and unsuccessful rows can be retried.") : Lang.T("عملیات این نوبت پایان یافت؛ نتیجه‌ی هر نفر در جدول مشخص است.", "This run has finished; see each student's result in the table.");
            else stageLine.Text = rows.Count == 0 ? Lang.T("متن پیام‌ها را بچسبانید یا فایل Excel باز کنید.", "Paste messages or open an Excel workbook.") : ready > 0
                ? Lang.T("پیش‌نمایش آماده است؛ عملیات هنوز شروع نشده. دکمه‌ی آبی «شروع افزودن» را بزنید.", "Preview ready; nothing has started. Press the blue Start button.")
                : Lang.T("ردیف آماده‌ای برای افزودن وجود ندارد؛ دلیل هر ردیف را در جدول ببینید.", "No rows are ready to add; see the reasons in the table.");
            hints.SetToolTip(activeStudent, stageLine.Text + " · " + elapsed.Text);
            pasteText.Enabled=open.Enabled = template.Enabled = !running && !checkingNow;
            editRow.Enabled=!running&&!checkingNow&&rows.Any(r=>!r.Saved);copyIssues.Enabled=!running&&rows.Any(r=>r.State==ImportState.Invalid||r.State==ImportState.Failed||r.State==ImportState.Unconfirmed);inputExcel.Enabled=!running&&rows.Count>0; start.Enabled = !running && ready > 0;
            start.Visible = !running && (!hasRun || ready > 0);
            close.Visible = running || checkingNow; close.Enabled = (running || checkingNow) && !stop; dismiss.Enabled = !running;
            retry.Enabled = !running && !checkingNow && rows.Any(r => (r.State == ImportState.Failed || r.State == ImportState.Cancelled || r.State == ImportState.Unconfirmed));
            retry.Visible = retry.Enabled;
            export.Enabled = !running && rows.Count > 0;
        }

        void Export(object sender, EventArgs e)
        {
            using (var d = new SaveFileDialog { Filter = "Excel Workbook (*.xlsx)|*.xlsx", FileName = "MetaFactory-import-results.xlsx", DefaultExt = "xlsx" })
            { if (d.ShowDialog(this) != DialogResult.OK) return; try { StudentImport.Export(d.FileName, rows); } catch (Exception ex) { Ui.Error(this, ex); } }
        }
    }
}
