using System;using System.IO;using System.Linq;using System.Text;using System.Drawing;using System.Collections.Generic;using System.Diagnostics;using System.Windows.Forms;
namespace MTManager
{
    public sealed class ReviewCopyPlan
    {
        public Instance Parent,Copy; public Account Account; public int Number;
    }
    public static class ReviewCopies
    {
        public const int MaxCopies=200;
        const string Marker="metafactory-review.txt";
        public static ReviewCopyPlan Plan(Instance parent,Account account,int number)
        {
            if(parent==null||string.IsNullOrWhiteSpace(parent.Name)||parent.Name=="."||parent.Name==".."||parent.Name.IndexOfAny(new[]{'/','\\','\r','\n'})>=0)throw new ArgumentException("Invalid source copy.");
            if(number<2||number>MaxCopies)throw new ArgumentOutOfRangeException("number");
            string dir=Path.Combine(Path.GetDirectoryName(Path.GetFullPath(parent.Dir)),"_MTManager","review",parent.Name,number.ToString("00"));
            return new ReviewCopyPlan{Parent=parent,Number=number,Account=account==null?null:account.Snapshot(),Copy=new Instance{Name=parent.Name+"~review-"+number.ToString("00"),Kind=parent.Kind,Dir=dir}};
        }
        static string Identity(Instance parent){return Convert.ToBase64String(Encoding.UTF8.GetBytes(Path.GetFullPath(parent.Dir)))+"\t"+parent.Kind;}
        public static bool Owned(ReviewCopyPlan plan){try{return Directory.Exists(plan.Copy.Dir)&&(File.GetAttributes(plan.Copy.Dir)&FileAttributes.ReparsePoint)==0&&File.ReadAllText(Path.Combine(plan.Copy.Dir,Marker))==Identity(plan.Parent);}catch{return false;}}
        public static IEnumerable<Instance> Existing(Instance parent)
        {
            var first=Plan(parent,null,2);string root=Path.GetDirectoryName(first.Copy.Dir);if(!Directory.Exists(root))return new Instance[0];var result=new List<Instance>();
            string[] dirs;try{dirs=Directory.GetDirectories(root);}catch(IOException){return result;}catch(UnauthorizedAccessException){return result;}
            foreach(string dir in dirs){int n;if(!int.TryParse(Path.GetFileName(dir),out n)||n<2||n>MaxCopies)continue;var plan=Plan(parent,null,n);if(Owned(plan)&&File.Exists(plan.Copy.Exe))result.Add(plan.Copy);}return result;
        }
        public static void Prepare(Settings settings,ReviewCopyPlan plan,Func<bool> cancelled)
        {
            if(cancelled())throw new OperationCanceledException();
            if(Directory.Exists(plan.Copy.Dir))
            {if(!Owned(plan))throw new IOException(Lang.T("پوشهٔ نسخهٔ بررسی شناخته نشد؛ فایل‌ها دست‌نخورده ماندند.","Review directory is not managed; existing files were preserved."));if(!File.Exists(plan.Copy.Exe))throw new IOException("Review terminal is incomplete.");return;}
            var provision=PlainSettings(settings);provision.BaseDir=Path.GetDirectoryName(Path.GetFullPath(plan.Parent.Dir));
            StudentDirectory.EnsureCopy(provision,plan.Parent,plan.Account,cancelled);
            StudentDirectory.Prepare(provision,plan.Parent.Dir,plan.Copy,cancelled);
            File.WriteAllText(Path.Combine(plan.Copy.Dir,Marker),Identity(plan.Parent),Encoding.UTF8);
        }
        public static Settings PlainSettings(Settings source)
        {
            var copy=new Settings();foreach(var f in typeof(Settings).GetFields(System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.Public))f.SetValue(copy,f.GetValue(source));copy.Folders=new List<string>(source.Folders);
            copy.ManualLiveReports=false;copy.Minimized=false;copy.Light=false;copy.StartCharts=ChartModes.All;copy.LightCharts=false;copy.AutoStart=false;return copy;
        }
        public static AccountStore Accounts(ReviewCopyPlan plan)
        {var store=new AccountStore();if(plan.Account!=null){var account=plan.Account.Snapshot();account.Instance=plan.Copy.Name;account.DeferredDir="";store.Set(account);}return store;}
    }
    enum CloseCopyKind { Review, Primary, Both }
    // One compact anchored editor, not a separately resized window. No saved count.
    sealed class LaunchMenuPanel : Panel
    {
        internal readonly Stepper Count = new Stepper(1,ReviewCopies.MaxCopies,112);
        internal readonly CheckBox Live = new SettingsToggle();
        internal readonly ModernButton Run;
        readonly Label estimate;
        internal LaunchMenuPanel(int students,bool live,Action<int,bool> accept)
        {
            Size=new Size(Theme.S(296),Theme.S(204));BackColor=Theme.Surface;Font=Theme.Font;RightToLeft=Theme.Dir;
            var title=Theme.Label(Lang.T("تعداد نسخه برای هر نفر","Copies per student"),268,Theme.Bold,Theme.Text);
            title.SetBounds(Theme.S(14),Theme.S(10),Theme.S(268),Theme.S(24));Controls.Add(title);
            Count.Location=new Point(Theme.S(14),Theme.S(42));Controls.Add(Count);
            var scope=Theme.Label(Fa.N(students)+Lang.T(" نفر انتخاب‌شده"," selected"),138,Theme.Small,Theme.Muted);
            scope.SetBounds(Theme.S(140),Theme.S(46),Theme.S(142),Theme.S(28));Controls.Add(scope);
            Live.Text=Lang.T("نسخهٔ اصلی با گزارش زنده","Primary with live report");Live.Checked=live;Live.ForeColor=Theme.Text;Live.Font=Theme.Font;
            Live.SetBounds(Theme.S(14),Theme.S(82),Theme.S(268),Theme.S(26));Controls.Add(Live);
            estimate=Theme.Label("",268,Theme.Small,Theme.Muted);estimate.SetBounds(Theme.S(14),Theme.S(113),Theme.S(268),Theme.S(34));Controls.Add(estimate);
            Action update=()=>estimate.Text=Lang.T("برای هر نفر: ۱ اصلی + ","Per student: 1 primary + ")+Fa.N(Count.Value-1)+Lang.T(" بررسی"," review");
            Count.Changed+=(s,e)=>update();update();
            Run=new ModernButton(Lang.T("اجرای انتخاب‌شده‌ها","Run selected"),ButtonKind.Primary,Glyph.Play);
            Run.SetBounds(Theme.S(14),Theme.S(158),Theme.S(268),Theme.S(34));Run.Click+=(s,e)=>accept(Count.Value,Live.Checked);Controls.Add(Run);
        }
    }
    sealed partial class MainForm
    {
        readonly Dictionary<string,ReviewCopyPlan> reviewPlans=new Dictionary<string,ReviewCopyPlan>(StringComparer.OrdinalIgnoreCase);
        string reviewDiscoveryKey="";int reviewOpenCount;
        void DisposeCopyMenus(){if(compactLaunchMenu!=null)compactLaunchMenu.Dispose();if(closeCopiesMenu!=null)closeCopiesMenu.Dispose();}
        Func<ReviewCopyPlan,Settings,StartResult> startReviewTerminal;
        List<Instance> KnownReviewCopies()
        {
            string key=string.Join("|",copies.Select(i=>i.Dir));if(key!=reviewDiscoveryKey){reviewDiscoveryKey=key;foreach(var parent in copies)foreach(var extra in ReviewCopies.Existing(parent))if(!reviewPlans.ContainsKey(extra.Name))reviewPlans[extra.Name]=new ReviewCopyPlan{Parent=parent,Copy=extra};}
            return reviewPlans.Values.Where(p=>copies.Any(c=>c.Dir==p.Parent.Dir)).Select(p=>p.Copy).ToList();
        }
        bool ReviewSelected(Instance copy){ReviewCopyPlan plan;return chosen.Has(copy.Name)||(reviewPlans.TryGetValue(copy.Name,out plan)&&chosen.Has(plan.Parent.Name));}
        List<Instance> WithReviewCopies(IEnumerable<Instance> parents){var list=parents.ToList();var names=new HashSet<string>(list.Select(i=>i.Name),StringComparer.OrdinalIgnoreCase);return list.Concat(KnownReviewCopies().Where(i=>{ReviewCopyPlan plan;return reviewPlans.TryGetValue(i.Name,out plan)&&names.Contains(plan.Parent.Name);})).GroupBy(i=>i.Dir,StringComparer.OrdinalIgnoreCase).Select(g=>g.First()).ToList();}
        void RequestManualLaunch(List<Instance> targets,bool live=true)
        {
            var snapshot=targets.ToList();if(snapshot.Count==0)return;
            if(preparingCopy||startQueue.Count>0||busy||report!=null||scheduledBatch!=null){SetStatus(Lang.T("عملیات فعلی هنوز تمام نشده؛ پس از پایان دوباره اجرا کنید.","Wait for the current operation before starting a new batch."));return;}
            ShowCompactLaunch(snapshot,live,runButton.Visible?(Control)runButton:grid);
        }
        void AcceptManualLaunch(List<Instance> targets,int count,bool live)
        {
            if(preparingCopy||startQueue.Count>0||busy||report!=null||scheduledBatch!=null){SetStatus(Lang.T("عملیات فعلی هنوز تمام نشده است.","Wait for the current operation to finish."));return;}
            if(count<1||count>ReviewCopies.MaxCopies)throw new ArgumentOutOfRangeException("count");
            var originals=targets.ToList();
            if(count>1&&originals.Any(parent=>{var a=accounts.Get(parent.Name);return a==null||!a.HasLogin;}))throw new UserMessage(Lang.T("برای نسخهٔ بررسی، ابتدا حساب دانشجو را ثبت کنید.","Save each student's account before opening review instances."));
            var requested=new List<Instance>(originals);
            foreach(var parent in originals)for(int n=2;n<=count;n++){var plan=ReviewCopies.Plan(parent,accounts.Get(parent.Name),n);reviewPlans[plan.Copy.Name]=plan;requested.Add(plan.Copy);}
            settings.ManualLiveReports=live;settings.Save();runButton.SetText(live?Lang.T("اجرا · زنده","Run · live"):Lang.T("اجرا · عادی","Run · ordinary"));
            Enqueue(requested);
        }
        ContextMenuStrip compactLaunchMenu,closeCopiesMenu;
        void ShowCompactLaunch(List<Instance> targets,bool live,Control anchor)
        {
            if(compactLaunchMenu!=null)compactLaunchMenu.Dispose();
            var snapshot=targets.ToList();var menu=compactLaunchMenu=Theme.Menu();menu.ShowImageMargin=false;menu.Padding=Padding.Empty;
            var panel=new LaunchMenuPanel(snapshot.Count,live,(count,mode)=>{menu.Close();Guard(()=>AcceptManualLaunch(snapshot,count,mode));});
            var host=new ToolStripControlHost(panel){Margin=Padding.Empty,Padding=Padding.Empty,AutoSize=false,Size=panel.Size};menu.Items.Add(host);
            menu.Disposed+=(s,e)=>panel.Dispose();ShowCopyMenu(menu,anchor);
        }
        List<Instance> CopiesToClose(IEnumerable<Instance> parents,CloseCopyKind kind)
        {
            var originals=parents.ToList();var all=WithReviewCopies(originals);
            var paths=new HashSet<string>(originals.Select(i=>i.Dir),StringComparer.OrdinalIgnoreCase);
            return all.Where(i=>kind==CloseCopyKind.Both||(kind==CloseCopyKind.Primary?paths.Contains(i.Dir):!paths.Contains(i.Dir))).ToList();
        }
        void ShowCloseCopies(List<Instance> parents,Control anchor)
        {
            if(parents.Count==0)return;
            if(closeCopiesMenu!=null)closeCopiesMenu.Dispose();
            var snapshot=parents.ToList();var menu=closeCopiesMenu=Theme.Menu();menu.ShowImageMargin=true;
            var header=new ToolStripLabel(Fa.N(snapshot.Count)+Lang.T(" نفر؛ بستن نسخه‌ها"," people; close instances")){ForeColor=Theme.Muted};menu.Items.Add(header);
            IconItem(menu.Items,Lang.T("فقط نسخه‌های بررسی","Review instances only"),Glyph.Chart,()=>CloseCopies(snapshot,CloseCopyKind.Review)).ToolTipText=Lang.T("نسخه‌های اصلیِ گزارش زنده باز می‌مانند.","Primary live-report instances stay open.");
            IconItem(menu.Items,Lang.T("فقط نسخه‌های اصلی","Primary instances only"),Glyph.Pulse,()=>CloseCopies(snapshot,CloseCopyKind.Primary)).ToolTipText=Lang.T("گزارش زندهٔ این افراد متوقف می‌شود؛ نسخه‌های بررسی باز می‌مانند.","Stops their live reporting; review instances stay open.");
            menu.Items.Add(new ToolStripSeparator());
            IconItem(menu.Items,Lang.T("هر دو نوع نسخه","Both instance types"),Glyph.Copies,()=>CloseCopies(snapshot,CloseCopyKind.Both));
            ShowCopyMenu(menu,anchor);
        }
        void ShowCopyMenu(ContextMenuStrip menu,Control anchor)
        {
            if(anchor==grid){var point=grid.PointToClient(Cursor.Position);if(!grid.ClientRectangle.Contains(point))point=new Point(Theme.S(20),Theme.S(24));menu.Show(grid,point);}
            else ShowUnder(menu,anchor);
        }
        void CloseCopies(List<Instance> parents,CloseCopyKind kind)
        {
            // A queued/in-flight preparation must settle before closing by type, so a
            // terminal cannot appear again immediately after the user's close command.
            if(preparingCopy||startQueue.Count>0){SetStatus(Lang.T("ابتدا صبر کنید صف اجرا تمام شود یا آن را متوقف کنید.","Wait for the launch queue to finish, or stop it first."));return;}
            var exact=CopiesToClose(parents,kind);bannerKey=null;StopExact(exact,false);
        }
        bool TryStartReviewCopy()
        {
            ReviewCopyPlan plan;if(startQueue.Count==0||!reviewPlans.TryGetValue(startQueue.Peek().Name,out plan))return false;
            var copy=startQueue.Dequeue();if(plan.Account==null)plan.Account=accounts.Get(plan.Parent.Name);
            preparingCopy=true;lastStartAt=DateTime.Now;pacing=null;launchWork.Add(copy.Name);launchWork.Detail=copy.Name+Lang.T("؛ آماده‌سازی نسخه بررسی","; preparing review instance");RefreshLaunchProgress();LaunchComparison.Preparing(copy);
            var plain=ReviewCopies.PlainSettings(settings);var request=plan;
            System.Threading.Tasks.Task.Factory.StartNew(()=>{
                Func<bool> cancel=()=>appClosing||launchWork.Stopped||accounts.Get(request.Parent.Name)==null;
                ReviewCopies.Prepare(plain,request,cancel);if(cancel())throw new OperationCanceledException();
                return startReviewTerminal!=null?startReviewTerminal(request,plain):Launcher.StartReview(request.Copy,plain,ReviewCopies.Accounts(request));
            }).ContinueWith(task=>{
                var error=task.Exception==null?null:task.Exception.GetBaseException();var result=error==null?task.Result:null;
                if(appClosing||IsDisposed||!IsHandleCreated){CleanDetachedStart(copy,result);return;}
                try{BeginInvoke((Action)(()=>{preparingCopy=false;launchWork.SettleStop();if(error is OperationCanceledException&&launchWork.Stopped)launchWork.Skip(copy.Name);else if(error!=null)RecordLaunchFailure(copy,error);else CompleteManualStart(copy,result);RefreshLaunchProgress();if(startQueue.Count==0)startTimer.Stop();else startTimer.Start();}));}catch(InvalidOperationException){CleanDetachedStart(copy,result);}
            });return true;
        }
    }
}
