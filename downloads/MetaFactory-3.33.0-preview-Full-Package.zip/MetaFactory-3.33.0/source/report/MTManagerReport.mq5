//+------------------------------------------------------------------+
//| MTManagerReport.mq5 - MT Manager                                  |
//| Reads the account's history once and writes it to a file, then   |
//| ends. Read-only: it never places, changes or closes an order, and |
//| imports no DLL. Run by MT Manager in its own report copy of       |
//| MetaTrader, with the investor (view-only) password.               |
//|                                                                  |
//| 1.20 (MT Manager 3.21): the whole history is selected up to a     |
//| fixed far date (not up to the last price, which can be old); the  |
//| script waits until the history adds up to the account's balance   |
//| (H line); each position is built in one pass over its deals,      |
//| fees included, a part-closed position as its closed part; the     |
//| last trade of the whole history is written (L line).              |
//+------------------------------------------------------------------+
#property copyright "MT Manager"
#property version   "1.20"
#property description "Read-only history export for MT Manager"

input string FromDate = "";                    // first server day, yyyy.mm.dd
input string OutFile  = "MTManagerReport\\report.txt"; // under MQL5\Files

#define SCRIPT_VERSION "1.20"
// Every deal of the account is before this date.
#define FAR_DATE D'2100.01.01 00:00'

string N(double v) { return DoubleToString(v, 8); }
string T(datetime t) { return IntegerToString((long)t); }

void Line(int h, string s) { FileWriteString(h, s + "\r\n"); }

// A text as one field: no tab or line break in it.
string Clean(string s)
{
   string r = s;
   StringReplace(r, "\t", " ");
   StringReplace(r, "\r", " ");
   StringReplace(r, "\n", " ");
   return r;
}

// The server's clock less GMT, to the half hour, for the trading sessions. Anything that is not a whole half hour is left out.
string Offset()
{
   long d = (long)(TimeTradeServer() - TimeGMT());
   long r = (long)MathRound(d / 1800.0) * 1800;
   if(MathAbs(d - r) > 300 || MathAbs(r) > 14 * 3600) return "";
   return IntegerToString(r);
}

string Header() { return "MTR\t2\tMT5\t" + IntegerToString(TerminalInfoInteger(TERMINAL_BUILD)) + "\t" + SCRIPT_VERSION; }

// Writes the file under a temporary name and renames it at the end: the program never reads half a file.
bool Finish(int h, string tmp)
{
   FileClose(h);
   FileDelete(OutFile);
   if(FileMove(tmp, 0, OutFile, FILE_REWRITE)) return true;
   Print("MTManagerReport: cannot finish ", OutFile);
   return false;
}

// Tells the program at once why nothing was read, instead of letting it wait.
void Fail(string why)
{
   Print("MTManagerReport: ", why);
   string tmp = OutFile + ".part";
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) return;
   Line(h, Header());
   Line(h, "ERR\t" + why);
   Finish(h, tmp);
}

// Where the script is, for the program: one line in a file beside the result ("start", "connected", "history 152", "bars EURUSD 2/5", "writing").
void Step(string what)
{
   int h = FileOpen(OutFile + ".step", FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) return;
   FileWriteString(h, what);
   FileClose(h);
}

// ------------------------------------------------------------------ the history adds up to the balance

double   sumAll = 0;      // every deal's profit, commission, fee and swap, credit left out
double   sumBonus = 0;    // the bonus deals among them (some servers keep bonus out of the balance)
int      dealCount = 0;

void AddUp()
{
   sumAll = 0; sumBonus = 0;
   HistorySelect(0, FAR_DATE);
   dealCount = HistoryDealsTotal();
   for(int i = 0; i < dealCount; i++)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(type == DEAL_TYPE_CREDIT) continue;
      double v = HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_COMMISSION) + HistoryDealGetDouble(d, DEAL_FEE) + HistoryDealGetDouble(d, DEAL_SWAP);
      sumAll += v;
      if(type == DEAL_TYPE_BONUS) sumBonus += v;
   }
}

bool AddsUp()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double tol = MathMax(0.02, MathAbs(balance) * 0.000001);
   return MathAbs(sumAll - balance) <= tol || MathAbs(sumAll - sumBonus - balance) <= tol;
}

// Waits until the terminal is connected and the whole history is there: it adds up to the balance and has stopped growing.
// A history that never adds up (the broker keeps only part of it) is taken once it has not grown for 15 seconds.
bool WaitForHistory()
{
   for(int k = 0; k < 120 && (!TerminalInfoInteger(TERMINAL_CONNECTED) || AccountInfoInteger(ACCOUNT_LOGIN) == 0); k++) Sleep(500);
   if(!TerminalInfoInteger(TERMINAL_CONNECTED)) return false;
   Step("connected");
   uint begun = GetTickCount(), still = GetTickCount();
   int last = -1;
   while(GetTickCount() - begun < 90000)
   {
      AddUp();
      if(dealCount != last) { last = dealCount; still = GetTickCount(); Step("history " + IntegerToString(dealCount)); }
      uint quiet = GetTickCount() - still, waited = GetTickCount() - begun;
      bool empty = dealCount == 0 && AccountInfoDouble(ACCOUNT_BALANCE) == 0;
      if(AddsUp() && quiet >= 2000 && waited >= (uint)(empty ? 8000 : 3000)) break;
      if(quiet >= 15000) break;
      Sleep(500);
   }
   return true;
}

// ------------------------------------------------------------------ positions, one pass over the deals

long     pid[];           // position ids, sorted
string   pSym[];
bool     pBuy[], pIn[];
double   pInVol[], pInValue[], pOutVol[], pOutValue[], pCost[], pSwap[], pProfit[], pSlEntry[], pSlFinal[], pTp[];
datetime pOpen[], pClose[];
string   pComment[];

int Find(long id)
{
   int lo = 0, hi = ArraySize(pid) - 1;
   while(lo <= hi)
   {
      int mid = (lo + hi) / 2;
      if(pid[mid] == id) return mid;
      if(pid[mid] < id) lo = mid + 1; else hi = mid - 1;
   }
   return -1;
}

void Positions()
{
   // The ids of every position that has a buy or sell deal, once each.
   long all[];
   int n = 0;
   ArrayResize(all, dealCount);
   for(int i = 0; i < dealCount; i++)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(type != DEAL_TYPE_BUY && type != DEAL_TYPE_SELL) continue;
      all[n++] = HistoryDealGetInteger(d, DEAL_POSITION_ID);
   }
   ArrayResize(all, n);
   if(n > 1) ArraySort(all);
   int u = 0;
   ArrayResize(pid, n);
   for(int i = 0; i < n; i++) if(u == 0 || all[i] != pid[u - 1]) pid[u++] = all[i];
   ArrayResize(pid, u);
   ArrayResize(pSym, u); ArrayResize(pBuy, u); ArrayResize(pIn, u); ArrayResize(pInVol, u); ArrayResize(pInValue, u); ArrayResize(pOutVol, u);
   ArrayResize(pOutValue, u); ArrayResize(pCost, u); ArrayResize(pSwap, u); ArrayResize(pProfit, u); ArrayResize(pSlEntry, u); ArrayResize(pSlFinal, u);
   ArrayResize(pTp, u); ArrayResize(pOpen, u); ArrayResize(pClose, u); ArrayResize(pComment, u);
   for(int k = 0; k < u; k++)
   {
      pSym[k] = ""; pBuy[k] = true; pIn[k] = false; pInVol[k] = 0; pInValue[k] = 0; pOutVol[k] = 0; pOutValue[k] = 0; pCost[k] = 0; pSwap[k] = 0;
      pProfit[k] = 0; pSlEntry[k] = 0; pSlFinal[k] = 0; pTp[k] = 0; pOpen[k] = 0; pClose[k] = 0; pComment[k] = "";
   }
   for(int i = 0; i < dealCount; i++)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(type != DEAL_TYPE_BUY && type != DEAL_TYPE_SELL) continue;
      int k = Find(HistoryDealGetInteger(d, DEAL_POSITION_ID));
      if(k < 0) continue;
      long entry = HistoryDealGetInteger(d, DEAL_ENTRY);
      datetime t = (datetime)HistoryDealGetInteger(d, DEAL_TIME);
      double vol = HistoryDealGetDouble(d, DEAL_VOLUME), price = HistoryDealGetDouble(d, DEAL_PRICE);
      pCost[k] += HistoryDealGetDouble(d, DEAL_COMMISSION) + HistoryDealGetDouble(d, DEAL_FEE);
      pSwap[k] += HistoryDealGetDouble(d, DEAL_SWAP);
      pProfit[k] += HistoryDealGetDouble(d, DEAL_PROFIT);
      if(entry == DEAL_ENTRY_IN)
      {
         if(!pIn[k])
         {
            pIn[k] = true;
            pSym[k] = HistoryDealGetString(d, DEAL_SYMBOL);
            pBuy[k] = type == DEAL_TYPE_BUY;
            pOpen[k] = t;
            pComment[k] = Clean(HistoryDealGetString(d, DEAL_COMMENT));
            ulong order = (ulong)HistoryDealGetInteger(d, DEAL_ORDER);
            if(order > 0) pSlEntry[k] = HistoryOrderGetDouble(order, ORDER_SL);
         }
         pInVol[k] += vol;
         pInValue[k] += vol * price;
      }
      else
      {
         // DEAL_ENTRY_OUT, OUT_BY, and INOUT (a netting account turned round): the volume that left the position.
         if(pSym[k] == "") { pSym[k] = HistoryDealGetString(d, DEAL_SYMBOL); pBuy[k] = type == DEAL_TYPE_SELL; }
         // A netting account turned round (INOUT): only the part that closed the position left it.
         double closing = entry == DEAL_ENTRY_INOUT ? MathMax(0.0, MathMin(vol, pInVol[k] - pOutVol[k])) : vol;
         pOutVol[k] += closing;
         pOutValue[k] += closing * price;
         if(t > pClose[k]) pClose[k] = t;
         pSlFinal[k] = HistoryDealGetDouble(d, DEAL_SL);
         pTp[k] = HistoryDealGetDouble(d, DEAL_TP);
      }
   }
}

// ------------------------------------------------------------------ worst floating result per minute

double minuteWorst[];
bool   minuteUsed[];
datetime base;
// The minutes with positions open are kept for the last MINUTE_DAYS days at most (about what 100000 minute bars hold).
#define MINUTE_DAYS 100
datetime mbase;
string bars = "M1";
uint   started;
bool   partial = false;
// Bars are fetched for this long at most (milliseconds): the history itself is always written.
#define BARS_BUDGET 150000

// The trades whose worst floating result is worked out at the end, symbol by symbol.
string qSym[]; bool qBuy[]; double qVol[], qPrice[]; datetime qOpen[], qClose[];

void Queue(string symbol, bool buy, double volume, double openPrice, datetime open, datetime close)
{
   if(symbol == "" || volume <= 0) return;
   int n = ArraySize(qSym);
   ArrayResize(qSym, n + 1); ArrayResize(qBuy, n + 1); ArrayResize(qVol, n + 1); ArrayResize(qPrice, n + 1); ArrayResize(qOpen, n + 1); ArrayResize(qClose, n + 1);
   qSym[n] = symbol; qBuy[n] = buy; qVol[n] = volume; qPrice[n] = openPrice; qOpen[n] = open; qClose[n] = close;
}

// Each queued trade's worst floating result, minute by minute. The bars of a symbol are fetched once for all its trades
// (M1, or coarser when M1 is missing); the terminal downloads them from the server the first time.
void Floating(datetime now)
{
   ENUM_TIMEFRAMES tf[] = { PERIOD_M1, PERIOD_M5, PERIOD_M15, PERIOD_H1 };
   int total = ArraySize(qSym), symbols = 0, k = 0;
   string seen = "|";
   for(int i = 0; i < total; i++) if(StringFind(seen, "|" + qSym[i] + "|") < 0) { seen += qSym[i] + "|"; symbols++; }
   string done = "|";
   for(int i = 0; i < total; i++)
   {
      string sym = qSym[i];
      if(StringFind(done, "|" + sym + "|") >= 0) continue;
      done += sym + "|";
      k++;
      if(GetTickCount() - started > BARS_BUDGET) { partial = true; break; }
      Step("bars " + sym + " " + IntegerToString(k) + "/" + IntegerToString(symbols));
      datetime a = now;
      for(int j = i; j < total; j++) if(qSym[j] == sym) a = (datetime)MathMin(a, MathMax(qOpen[j], mbase));
      SymbolSelect(sym, true);
      MqlRates r[];
      int got = 0, used = 0;
      for(int t = 0; t < ArraySize(tf) && got <= 0; t++)
      {
         used = t;
         datetime from = a - a % PeriodSeconds(tf[t]);
         for(int tries = 0; tries < 8 && got <= 0 && GetTickCount() - started <= BARS_BUDGET; tries++)
         {
            got = CopyRates(sym, tf[t], from, now, r);
            if(got <= 0) Sleep(1000);
         }
      }
      if(got <= 0) { partial = true; continue; }
      if(used > 0) bars = EnumToString(tf[used]);
      int step = PeriodSeconds(tf[used]);
      for(int j = i; j < total; j++)
      {
         if(qSym[j] != sym) continue;
         datetime ta = (datetime)MathMax(qOpen[j], mbase), tb = (datetime)MathMin(qClose[j], now);
         if(tb <= ta) continue;
         // The first bar that ends after the trade opened.
         int lo = 0, hi = got;
         while(lo < hi) { int mid = (lo + hi) / 2; if(r[mid].time + step <= ta) lo = mid + 1; else hi = mid; }
         for(int b = lo; b < got && r[b].time <= tb; b++)
         {
            double worst = qBuy[j] ? r[b].low : r[b].high, p = 0;
            if(!OrderCalcProfit(qBuy[j] ? ORDER_TYPE_BUY : ORDER_TYPE_SELL, sym, qVol[j], qPrice[j], worst, p)) continue;
            for(datetime m = (datetime)MathMax(r[b].time, ta); m < (datetime)MathMin(r[b].time + step, tb + 60); m += 60)
            {
               int idx = (int)((m - mbase) / 60);
               if(idx < 0 || idx >= ArraySize(minuteWorst)) continue;
               minuteWorst[idx] += p;
               minuteUsed[idx] = true;
            }
         }
      }
   }
}

// ------------------------------------------------------------------ the file

void OnStart()
{
   started = GetTickCount();
   Step("start");
   if(!WaitForHistory()) { Fail("not connected"); return; }
   started = GetTickCount();   // the minute bars' time budget starts now, not before the wait for the history
   // The whole history is selected once more, now that it is all there; everything below reads this selection.
   AddUp();
   bool addsUp = AddsUp();
   Positions();

   // Now: the server's clock, and never before the last deal (the last price can be old after a quiet spell).
   datetime now = (datetime)MathMax(TimeTradeServer(), TimeCurrent());
   datetime lastTrade = 0, firstSeen = 0;
   for(int i = 0; i < dealCount; i++)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      datetime t = (datetime)HistoryDealGetInteger(d, DEAL_TIME);
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(t > now) now = t;
      if(firstSeen == 0 || t < firstSeen) firstSeen = t;
      if((type == DEAL_TYPE_BUY || type == DEAL_TYPE_SELL) && t > lastTrade) lastTrade = t;
   }
   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong p = PositionGetTicket(i);
      if(p == 0) continue;
      datetime t = (datetime)PositionGetInteger(POSITION_TIME);
      if(t > now) now = t;
      if(t > lastTrade) lastTrade = t;
   }
   base = StringToTime(FromDate);
   if(base <= 0) base = now - 7 * 86400;
   mbase = (datetime)MathMax(base, now - MINUTE_DAYS * 86400);
   int minutes = (int)((now - mbase) / 60) + 2;
   if(minutes < 2) minutes = 2;
   ArrayResize(minuteWorst, minutes); ArrayInitialize(minuteWorst, 0);
   ArrayResize(minuteUsed, minutes);  ArrayInitialize(minuteUsed, false);

   string tmp = OutFile + ".part";
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) { Print("MTManagerReport: cannot write ", tmp); return; }
   Step("writing");
   Line(h, Header());
   Line(h, "A\t" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "\t" + Clean(AccountInfoString(ACCOUNT_SERVER)) + "\t" + AccountInfoString(ACCOUNT_CURRENCY) + "\t" +
           N(AccountInfoDouble(ACCOUNT_BALANCE)) + "\t" + N(AccountInfoDouble(ACCOUNT_EQUITY)) + "\t" + T(now) + "\t" + T(base) + "\t" + Clean(AccountInfoString(ACCOUNT_COMPANY)) + "\t" +
           Offset() + "\t" + IntegerToString(AccountInfoInteger(ACCOUNT_LEVERAGE)) + "\t" + N(AccountInfoDouble(ACCOUNT_MARGIN)) + "\t" + N(AccountInfoDouble(ACCOUNT_MARGIN_FREE)) + "\t" +
           N(AccountInfoDouble(ACCOUNT_CREDIT)));
   // H: whether the history adds up to the balance, the sum, the balance and the number of deals.
   Line(h, "H\t" + (addsUp ? "1" : "0") + "\t" + N(sumAll) + "\t" + N(AccountInfoDouble(ACCOUNT_BALANCE)) + "\t" + IntegerToString(dealCount));
   // L: the last trade of the whole history (a deal or a position opened) and the first record of the account.
   Line(h, "L\t" + T(lastTrade) + "\t" + T(firstSeen));
   int records = 0;

   // Money in and out since the first day: time, amount, comment, deal type (2 balance, 3 credit, 4 charge, 5 correction, 6 bonus...).
   for(int i = 0; i < dealCount; i++)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(type == DEAL_TYPE_BUY || type == DEAL_TYPE_SELL) continue;
      if(type == DEAL_TYPE_BUY_CANCELED || type == DEAL_TYPE_SELL_CANCELED) continue;
      datetime t = (datetime)HistoryDealGetInteger(d, DEAL_TIME);
      if(t < base) continue;
      double amount = HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_COMMISSION) + HistoryDealGetDouble(d, DEAL_FEE) + HistoryDealGetDouble(d, DEAL_SWAP);
      Line(h, "B\t" + T(t) + "\t" + N(amount) + "\t" + Clean(HistoryDealGetString(d, DEAL_COMMENT)) + "\t" + IntegerToString(type));
      records++;
   }

   // Positions still open, by id: a position partly closed is written as its closed part (T) and its open rest (O).
   long openIds[];
   int positions = PositionsTotal();
   ArrayResize(openIds, positions);
   int openCount = 0;
   for(int i = 0; i < positions && openCount < ArraySize(openIds); i++)
   {
      ulong p = PositionGetTicket(i);
      if(p == 0) continue;
      openIds[openCount++] = PositionGetInteger(POSITION_IDENTIFIER);
   }
   ArrayResize(openIds, openCount);

   // Each position with volume closed since the first day: its entry, its exits, and the Stop Loss of the order that opened it.
   for(int k = 0; k < ArraySize(pid); k++)
   {
      if(pOutVol[k] <= 0 || pClose[k] < base) continue;
      bool stillOpen = false;
      for(int i = 0; i < openCount && !stillOpen; i++) stillOpen = openIds[i] == pid[k];
      double volume = pOutVol[k];
      double openPrice = pInVol[k] > 0 ? pInValue[k] / pInVol[k] : 0;
      datetime open = pIn[k] ? pOpen[k] : pClose[k];
      Line(h, "T\t" + IntegerToString(pid[k]) + "\t" + pSym[k] + "\t" + (pBuy[k] ? "0" : "1") + "\t" + N(volume) + "\t" + T(open) + "\t" + N(openPrice) + "\t" +
              T(pClose[k]) + "\t" + N(pOutValue[k] / pOutVol[k]) + "\t" + N(pIn[k] ? pSlEntry[k] : -1) + "\t" + N(pSlFinal[k]) + "\t" + N(pTp[k]) + "\t" +
              N(pCost[k]) + "\t" + N(pSwap[k]) + "\t" + N(pProfit[k]) + "\t" + pComment[k] + (stillOpen ? " [part]" : ""));
      records++;
      Queue(pSym[k], pBuy[k], volume, openPrice, open, pClose[k]);
   }
   // Positions still open.
   for(int i = 0; i < PositionsTotal(); i++)
   {
      ulong p = PositionGetTicket(i);
      if(p == 0) continue;
      string symbol = PositionGetString(POSITION_SYMBOL);
      bool buy = PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY;
      double volume = PositionGetDouble(POSITION_VOLUME), openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      datetime open = (datetime)PositionGetInteger(POSITION_TIME);
      long id = PositionGetInteger(POSITION_IDENTIFIER);
      double sl = PositionGetDouble(POSITION_SL), tp = PositionGetDouble(POSITION_TP), profit = PositionGetDouble(POSITION_PROFIT), swap = PositionGetDouble(POSITION_SWAP);
      int k = Find(id);
      double slEntry = k >= 0 && pIn[k] ? pSlEntry[k] : -1;
      Line(h, "O\t" + IntegerToString(id) + "\t" + symbol + "\t" + (buy ? "0" : "1") + "\t" + N(volume) + "\t" + T(open) + "\t" + N(openPrice) + "\t" + N(sl) + "\t" + N(tp) + "\t" +
              N(profit) + "\t" + N(swap) + "\t" + N(slEntry) + "\t" + N(PositionGetDouble(POSITION_PRICE_CURRENT)) + "\t" +
              N(k >= 0 && pOutVol[k] <= 0 ? pCost[k] : 0));   // the entry's commission (a part-closed one's went with its closed part)
      records++;
      Queue(symbol, buy, volume, openPrice, open, now);
   }
   Floating(now);
   Step("writing");
   Line(h, "M\t" + bars + (partial ? " partial" : ""));
   for(int i = 0; i < ArraySize(minuteWorst); i++)
      if(minuteUsed[i]) Line(h, "F\t" + T(mbase + i * 60) + "\t" + N(minuteWorst[i]));
   Line(h, "END\t" + IntegerToString(records));
   Finish(h, tmp);
}
