//+------------------------------------------------------------------+
//| MTManagerReport.mq4 - MT Manager                                  |
//| Reads the account's history once and writes it to a file, then   |
//| ends. Read-only: it never places, changes or closes an order. Run |
//| by MT Manager in its own report copy of MetaTrader, with the      |
//| investor (view-only) password.                                    |
//| MT4 keeps only the last Stop Loss of a closed order: the entry's  |
//| is written as -1 (unknown).                                       |
//|                                                                  |
//| 1.20 (MT Manager 3.21): MT4 gives a program only the part of the  |
//| history its "Account History" tab shows (often the last month).   |
//| The script asks the terminal for "All History" - the same command |
//| as the tab's own menu, through user32.dll, only when DLL calls are|
//| allowed - and waits until the history adds up to the balance      |
//| (H line). The last trade of the whole history is written (L).     |
//+------------------------------------------------------------------+
#property copyright "MT Manager"
#property version   "1.20"
#property strict

#import "user32.dll"
int PostMessageW(int hWnd, int Msg, int wParam, int lParam);
int GetAncestor(int hWnd, int gaFlags);
#import

input string FromDate = "";                    // first server day, yyyy.mm.dd
input string OutFile  = "MTManagerReport\\report.txt"; // under MQL4\Files

#define SCRIPT_VERSION "1.20"
#define WM_COMMAND 0x0111
#define GA_ROOT 2
// The "All History" item of the Account History tab's menu.
#define CMD_ALL_HISTORY 33058

string N(double v) { return DoubleToString(v, 8); }
string T(datetime t) { return IntegerToString((long)t); }
void Line(int h, string s) { FileWriteString(h, s + "\r\n"); }

// A text as one field: no tab or line break in it.
string Clean(string s)
{
   string r = s;
   StringReplace(r, "\t", " ");
   StringReplace(r, "\r", " ");
   StringReplace(r, "\n", " ");
   return r;
}

// The server's clock less GMT, to the half hour, for the trading sessions. MT4's server clock stands still
// without prices (a weekend): then it is not a whole half hour away from GMT and is left out.
string Offset()
{
   long d = (long)(TimeCurrent() - TimeGMT());
   long r = (long)MathRound(d / 1800.0) * 1800;
   if(MathAbs(d - r) > 300 || MathAbs(r) > 14 * 3600) return "";
   return IntegerToString(r);
}

string Header() { return "MTR\t2\tMT4\t" + IntegerToString(TerminalInfoInteger(TERMINAL_BUILD)) + "\t" + SCRIPT_VERSION; }

// Writes the file under a temporary name and renames it at the end: the program never reads half a file.
bool Finish(int h, string tmp)
{
   FileClose(h);
   FileDelete(OutFile);
   if(FileMove(tmp, 0, OutFile, FILE_REWRITE)) return true;
   Print("MTManagerReport: cannot finish ", OutFile);
   return false;
}

// Tells the program at once why nothing was read, instead of letting it wait.
void Fail(string why)
{
   Print("MTManagerReport: ", why);
   string tmp = OutFile + ".part";
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) return;
   Line(h, Header());
   Line(h, "ERR\t" + why);
   Finish(h, tmp);
}

// Where the script is, for the program: one line in a file beside the result ("start", "connected", "history 152", "bars EURUSD 2", "writing").
void Step(string what)
{
   int h = FileOpen(OutFile + ".step", FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) return;
   FileWriteString(h, what);
   FileClose(h);
}

// ------------------------------------------------------------------ the history adds up to the balance

double sumAll = 0;
int    histCount = 0;

void AddUp()
{
   sumAll = 0;
   histCount = OrdersHistoryTotal();
   for(int i = 0; i < histCount; i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      int type = OrderType();
      if(type == OP_BUY || type == OP_SELL) sumAll += OrderProfit() + OrderCommission() + OrderSwap();
      else if(type == 6) sumAll += OrderProfit();   // balance: deposits, withdrawals, charges (7, credit, is not in the balance)
   }
}

bool AddsUp()
{
   double balance = AccountBalance();
   return MathAbs(sumAll - balance) <= MathMax(0.02, MathAbs(balance) * 0.000001);
}

bool posted = false;

// Asks the terminal for its whole account history, as its "All History" menu item does.
void AskAllHistory()
{
   if(!IsDllsAllowed()) { Print("MTManagerReport: DLL calls are not allowed; the history is what the Account History tab shows"); return; }
   int chart = (int)ChartGetInteger(0, CHART_WINDOW_HANDLE);
   if(chart == 0) chart = WindowHandle(Symbol(), Period());
   if(chart == 0) return;
   int root = GetAncestor(chart, GA_ROOT);
   if(root == 0) return;
   posted = PostMessageW(root, WM_COMMAND, CMD_ALL_HISTORY, 0) != 0;
}

// Waits until the terminal is connected and the whole history is there: it adds up to the balance and has stopped growing.
// A history that never adds up (the broker keeps only part of it) is taken once it has not grown for 15 seconds.
bool WaitForHistory()
{
   for(int k = 0; k < 120 && (!IsConnected() || AccountNumber() == 0); k++) Sleep(500);
   if(!IsConnected()) return false;
   Step("connected");
   AskAllHistory();
   uint begun = GetTickCount(), still = GetTickCount();
   int last = -1;
   while(GetTickCount() - begun < 90000)
   {
      AddUp();
      if(histCount != last) { last = histCount; still = GetTickCount(); Step("history " + IntegerToString(histCount)); }
      uint quiet = GetTickCount() - still, waited = GetTickCount() - begun;
      bool empty = histCount == 0 && AccountBalance() == 0;
      if(AddsUp() && quiet >= 2000 && waited >= (uint)(empty ? 8000 : (posted ? 5000 : 3000))) break;
      // After "All History" MT4 can take half a minute or more to load it: 45 seconds without a change then.
      if(quiet >= (uint)(posted ? 45000 : 15000)) break;
      Sleep(500);
   }
   return true;
}

// ------------------------------------------------------------------ worst floating result per minute

// MT4 fetches missing bars from the server when they are first asked for (error 4066): ask again for a few seconds.
bool BarsReady(string symbol, int tf)
{
   for(int tries = 0; tries < 10; tries++)
   {
      ResetLastError();
      int n = iBars(symbol, tf);
      if(n > 0 && GetLastError() != 4066) return true;
      Sleep(500);
   }
   return iBars(symbol, tf) > 0;
}

double minuteWorst[];
bool   minuteUsed[];
datetime base;
// The minutes with positions open are kept for the last MINUTE_DAYS days at most (about what 100000 minute bars hold).
#define MINUTE_DAYS 100
datetime mbase;
string bars = "M1";
string noData = "|";   // symbol:timeframe pairs the terminal had no bars for: not asked again
string seenSymbols = "|";
int    symbolCount = 0;
uint   started;
bool   partial = false;
// Bars are fetched for this long at most (milliseconds): the history itself is always written.
#define BARS_BUDGET 150000

// One trade's worst floating result, minute by minute, from the bars of its symbol (M1, or coarser when M1 is missing).
void AddFloating(string symbol, bool buy, double lots, double openPrice, datetime open, datetime close, datetime now)
{
   datetime a = (datetime)MathMax(open, mbase), b = (datetime)MathMin(close, now);
   if(b <= a) return;
   if(GetTickCount() - started > BARS_BUDGET) { partial = true; return; }
   if(StringFind(seenSymbols, "|" + symbol + "|") < 0)
   {
      seenSymbols += symbol + "|";
      symbolCount++;
      Step("bars " + symbol + " " + IntegerToString(symbolCount));
   }
   SymbolSelect(symbol, true);
   int tf[] = { PERIOD_M1, PERIOD_M5, PERIOD_M15, PERIOD_H1 };
   double tickValue = MarketInfo(symbol, MODE_TICKVALUE), tickSize = MarketInfo(symbol, MODE_TICKSIZE);
   if(tickSize <= 0 || tickValue <= 0) return;
   for(int k = 0; k < ArraySize(tf); k++)
   {
      string key = symbol + ":" + IntegerToString(tf[k]) + "|";
      if(StringFind(noData, "|" + key) >= 0) continue;
      if(!BarsReady(symbol, tf[k])) { noData += key; continue; }
      int first = iBarShift(symbol, tf[k], a, false), last = iBarShift(symbol, tf[k], b, false);
      if(first < 0 || iTime(symbol, tf[k], first) > a + tf[k] * 60) continue;
      if(k > 0) bars = "M" + IntegerToString(tf[k]);
      for(int i = first; i >= last && i >= 0; i--)
      {
         datetime bt = iTime(symbol, tf[k], i);
         double worst = buy ? iLow(symbol, tf[k], i) : iHigh(symbol, tf[k], i);
         double p = (buy ? worst - openPrice : openPrice - worst) / tickSize * tickValue * lots;
         for(datetime m = (datetime)MathMax(bt, a); m < (datetime)MathMin(bt + tf[k] * 60, b + 60); m += 60)
         {
            int idx = (int)((m - mbase) / 60);
            if(idx < 0 || idx >= ArraySize(minuteWorst)) continue;
            minuteWorst[idx] += p;
            minuteUsed[idx] = true;
         }
      }
      return;
   }
}

// ------------------------------------------------------------------ the file

void OnStart()
{
   started = GetTickCount();
   Step("start");
   if(!WaitForHistory()) { Fail("not connected"); return; }
   started = GetTickCount();   // the minute bars' time budget starts now, not before the wait for the history
   AddUp();
   bool addsUp = AddsUp();

   // Now: the server's clock, never before the last record (the last price can be old after a quiet spell).
   datetime now = TimeCurrent();
   datetime lastTrade = 0, firstSeen = 0;
   for(int i = 0; i < histCount; i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      int type = OrderType();
      datetime o = OrderOpenTime(), c = OrderCloseTime();
      if(c > now) now = c;
      if(o > now) now = o;
      if(type == OP_BUY || type == OP_SELL || type == 6)
         if(firstSeen == 0 || o < firstSeen) firstSeen = o;
      if((type == OP_BUY || type == OP_SELL) && c > lastTrade) lastTrade = c;
   }
   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      int type = OrderType();
      datetime o = OrderOpenTime();
      if(o > now) now = o;
      if((type == OP_BUY || type == OP_SELL) && o > lastTrade) lastTrade = o;
   }
   base = StrToTime(FromDate);
   if(base <= 0) base = now - 7 * 86400;
   mbase = (datetime)MathMax(base, now - MINUTE_DAYS * 86400);
   int minutes = (int)((now - mbase) / 60) + 2;
   if(minutes < 2) minutes = 2;
   ArrayResize(minuteWorst, minutes); ArrayInitialize(minuteWorst, 0);
   ArrayResize(minuteUsed, minutes);  ArrayInitialize(minuteUsed, false);

   string tmp = OutFile + ".part";
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) { Print("MTManagerReport: cannot write ", tmp); return; }
   Step("writing");
   Line(h, Header());
   Line(h, "A\t" + IntegerToString(AccountNumber()) + "\t" + Clean(AccountServer()) + "\t" + AccountCurrency() + "\t" + N(AccountBalance()) + "\t" + N(AccountEquity()) + "\t" +
           T(now) + "\t" + T(base) + "\t" + Clean(AccountCompany()) + "\t" + Offset() + "\t" + IntegerToString(AccountLeverage()) + "\t" + N(AccountMargin()) + "\t" +
           N(AccountFreeMargin()) + "\t" + N(AccountCredit()));
   // H: whether the history adds up to the balance, the sum, the balance, the number of history records, and whether "All History" was asked for.
   Line(h, "H\t" + (addsUp ? "1" : "0") + "\t" + N(sumAll) + "\t" + N(AccountBalance()) + "\t" + IntegerToString(histCount) + "\t" + (posted ? "1" : "0"));
   // L: the last trade of the whole history (closed, or an open position's entry) and the first record of the account.
   Line(h, "L\t" + T(lastTrade) + "\t" + T(firstSeen));
   int records = 0;
   for(int i = 0; i < histCount; i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      int type = OrderType();
      // Money in and out: time, amount, comment, kind (2 balance, 3 credit: as MT5 numbers them).
      if(type == 6 || type == 7)
      {
         if(OrderOpenTime() < base) continue;
         Line(h, "B\t" + T(OrderOpenTime()) + "\t" + N(OrderProfit()) + "\t" + Clean(OrderComment()) + "\t" + (type == 6 ? "2" : "3"));
         records++;
         continue;
      }
      if(type != OP_BUY && type != OP_SELL) continue;
      if(OrderCloseTime() < base) continue;
      Line(h, "T\t" + IntegerToString(OrderTicket()) + "\t" + OrderSymbol() + "\t" + (type == OP_BUY ? "0" : "1") + "\t" + N(OrderLots()) + "\t" + T(OrderOpenTime()) + "\t" +
              N(OrderOpenPrice()) + "\t" + T(OrderCloseTime()) + "\t" + N(OrderClosePrice()) + "\t-1\t" + N(OrderStopLoss()) + "\t" + N(OrderTakeProfit()) + "\t" +
              N(OrderCommission()) + "\t" + N(OrderSwap()) + "\t" + N(OrderProfit()) + "\t" + Clean(OrderComment()));
      records++;
      AddFloating(OrderSymbol(), type == OP_BUY, OrderLots(), OrderOpenPrice(), OrderOpenTime(), OrderCloseTime(), now);
   }
   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      int type = OrderType();
      if(type != OP_BUY && type != OP_SELL) continue;
      Line(h, "O\t" + IntegerToString(OrderTicket()) + "\t" + OrderSymbol() + "\t" + (type == OP_BUY ? "0" : "1") + "\t" + N(OrderLots()) + "\t" + T(OrderOpenTime()) + "\t" +
              N(OrderOpenPrice()) + "\t" + N(OrderStopLoss()) + "\t" + N(OrderTakeProfit()) + "\t" + N(OrderProfit()) + "\t" + N(OrderSwap()) + "\t-1\t" +
              N(OrderClosePrice()) + "\t" + N(OrderCommission()));
      records++;
      AddFloating(OrderSymbol(), type == OP_BUY, OrderLots(), OrderOpenPrice(), OrderOpenTime(), now, now);
   }
   Step("writing");
   Line(h, "M\t" + bars + (partial ? " partial" : ""));
   for(int i = 0; i < ArraySize(minuteWorst); i++)
      if(minuteUsed[i]) Line(h, "F\t" + T(mbase + i * 60) + "\t" + N(minuteWorst[i]));
   Line(h, "END\t" + IntegerToString(records));
   Finish(h, tmp);
}
