using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;

namespace MTManager
{
    public sealed class ReportResultEntry
    {
        public string Copy = "", Name = "", Login = "", Server = "", Platform = "", State = "pending", Reason = "", CompletedUtc = "";
        public int Attempts;
        public ReportResultEntry Snapshot() { return (ReportResultEntry)MemberwiseClone(); }
    }
    public sealed class ReportRunSummary
    {
        readonly Dictionary<string, ReportResultEntry> entries = new Dictionary<string, ReportResultEntry>(StringComparer.OrdinalIgnoreCase);
        public bool Stopping, Finished;
        public string SavedPath = "";
        public int Total { get { return entries.Count; } }
        public int Fresh { get { return entries.Values.Count(r => r.State == "read"); } }
        public int Unread { get { return Total - Fresh; } }
        public int Cached { get { return entries.Values.Count(r => r.State == "cached"); } }
        public int Failed { get { return entries.Values.Count(r => r.State == "failed"); } }
        public int Stopped { get { return entries.Values.Count(r => r.State == "stopped"); } }
        public int Pending { get { return entries.Values.Count(r => r.State == "pending" || r.State == "reading" || r.State == "retry"); } }
        public ReportResultEntry[] Rows { get { return entries.Values.Select(r => r.Snapshot()).ToArray(); } }
        public void Begin() { entries.Clear(); Stopping = Finished = false; SavedPath = ""; }
        public void Add(string copy, Account a, Kind kind)
        {
            if (entries.ContainsKey(copy)) return;
            entries[copy] = new ReportResultEntry { Copy = copy, Name = a.Trader, Login = a.Login, Server = a.Server, Platform = kind.ToString() };
        }
        public void Stage(string copy, StepState state, string reason)
        {
            ReportResultEntry row;
            if (!entries.TryGetValue(copy, out row) || row.State == "read" || row.State == "cached" || row.State == "failed" || row.State == "stopped") return;
            row.State = state == StepState.Retrying ? "retry" : "reading"; row.Reason = reason ?? "";
        }
        public bool Record(string copy, ReportRow result)
        {
            ReportResultEntry row; if (!entries.TryGetValue(copy, out row)) return false;
            string nextState = result.Cached ? "cached" : result.Journal != null && result.Error == null ? "read" : result.Cancelled ? "stopped" : "failed";
            string nextReason = result.Error ?? result.Note ?? "";
            if (row.State == nextState && row.Reason == nextReason && row.Attempts == result.Attempts && row.CompletedUtc.Length > 0) return false;
            row.State = nextState; row.Reason = nextReason; row.Attempts = result.Attempts;
            row.CompletedUtc = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture); return true;
        }
        public void StopPending()
        {
            Stopping = true;
            foreach (ReportResultEntry row in entries.Values.Where(r => r.State == "pending" || r.State == "retry"))
            { row.State = "stopped"; row.Reason = Lang.T("پیش از این حساب متوقف شد.", "Stopped before this account."); }
        }
        public void End()
        {
            foreach (ReportResultEntry row in entries.Values.Where(r => r.State == "pending" || r.State == "reading" || r.State == "retry"))
            { row.State = Stopping ? "stopped" : "failed"; row.Reason = Lang.T("گزارش تازه‌ای دریافت نشد.", "No fresh report was received."); }
            Finished = true;
        }
        public string Counts()
        {
            return Lang.T("کل: ", "Total: ") + Fa.N(Total) + Lang.T(" · تازه خوانده‌شده: ", " · Fresh: ") + Fa.N(Fresh) +
                Lang.T(" · تازه خوانده نشد: ", " · No fresh report: ") + Fa.N(Unread) + Lang.T(" · ناموفق: ", " · Failed: ") + Fa.N(Failed) + Lang.T(" · باقی‌مانده: ", " · Remaining: ") + Fa.N(Pending) +
                (Cached > 0 ? Lang.T(" · فقط گزارش قبلی: ", " · Previous only: ") + Fa.N(Cached) : "") +
                (Stopped > 0 ? Lang.T(" · متوقف: ", " · Stopped: ") + Fa.N(Stopped) : "");
        }
        public static string Status(string state)
        {
            switch (state)
            {
                case "read": return Lang.T("گزارش تازه خوانده شد", "Fresh report read");
                case "cached": return Lang.T("فقط گزارش قبلی؛ تازه خوانده نشد", "Previous report only; fresh read failed");
                case "failed": return Lang.T("خوانده نشد", "Not read");
                case "stopped": return Lang.T("متوقف / انجام نشد", "Stopped / not attempted");
                case "retry": return Lang.T("در صف تلاش دوباره", "Queued for retry");
                case "reading": return Lang.T("در حال خواندن", "Reading");
                default: return Lang.T("در انتظار", "Waiting");
            }
        }
        public void Export(string path)
        {
            var sheet = new List<string[]> { new[] { "Name", "Login", "Platform", "Server", "Copy", "Status", "Reason", "Attempts", "CompletedUtc" } };
            sheet.AddRange(Rows.Select(r => new[] { r.Name, r.Login, r.Platform, r.Server, r.Copy, Status(r.State), r.Reason, r.Attempts.ToString(CultureInfo.InvariantCulture), r.CompletedUtc }));
            Spreadsheet.Write(path, sheet, new[] { Counts(), "Fresh and cached results are separate. Previous cached data is never counted as a fresh successful read. Passwords are not included." });
        }
    }
    sealed class ReportResultsDialog : Form
    {
        readonly ReportRunSummary summary;
        readonly DataGridView grid = new DataGridView();
        readonly Label counts = new Label();
        ModernButton retryButton;
        readonly Timer timer = new Timer { Interval = 750 };
        public ReportResultsDialog(ReportRunSummary summary, Action<string[]> retry)
        {
            this.summary = summary; Text = Lang.T("نتیجهٔ گزارش‌گیری", "Report results"); Font = Theme.Font; BackColor = Theme.Page; ForeColor = Theme.Text;
            StartPosition = FormStartPosition.CenterParent; Size = new Size(Theme.S(1040), Theme.S(590)); RightToLeft = Theme.Dir;
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Padding = Theme.Pad(16, 12) };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, Theme.S(55))); layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, Theme.S(55)));
            counts.Dock = DockStyle.Fill; counts.TextAlign = Lang.En ? ContentAlignment.MiddleLeft : ContentAlignment.MiddleRight; layout.Controls.Add(counts, 0, 0);
            grid.Dock = DockStyle.Fill; grid.ReadOnly = true; grid.AllowUserToAddRows = grid.AllowUserToDeleteRows = false; grid.RowHeadersVisible = false;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; grid.BackgroundColor = Theme.Surface; grid.DefaultCellStyle.ForeColor = Theme.Text; grid.DefaultCellStyle.BackColor = Theme.Surface; grid.RightToLeft = Theme.Dir;
            foreach (string title in new[] { Lang.T("دانشجو", "Student"), Lang.T("حساب", "Account"), Lang.T("سرور", "Server"), Lang.T("نتیجه", "Result"), Lang.T("دلیل", "Reason"), Lang.T("تلاش", "Attempts") }) grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = title, SortMode = DataGridViewColumnSortMode.NotSortable });
            grid.Columns[4].FillWeight = 220; layout.Controls.Add(grid, 0, 1);
            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = Lang.En ? FlowDirection.LeftToRight : FlowDirection.RightToLeft };
            buttons.Controls.Add(new ModernButton(Lang.T("ذخیرهٔ Excel", "Save Excel"), (s, e) => {
                using (var d = new SaveFileDialog { Filter = "Excel (*.xlsx)|*.xlsx", FileName = "MetaFactory-report-results.xlsx" })
                    if (d.ShowDialog(this) == DialogResult.OK) try { summary.Export(d.FileName); } catch (Exception ex) { Ui.Error(this, ex); }
            }, ButtonKind.Primary));
            if (retry != null) { retryButton = new ModernButton(Lang.T("تلاش دوبارهٔ خوانده‌نشده‌ها", "Retry unread"), (s, e) => {
                var unread = summary.Rows.Where(r => r.State == "failed" || r.State == "cached" || r.State == "stopped").Select(r => r.Copy).ToArray();
                if (unread.Length > 0) { Close(); retry(unread); }
            }, ButtonKind.Secondary); buttons.Controls.Add(retryButton); }
            buttons.Controls.Add(new ModernButton(Lang.T("بستن", "Close"), (s, e) => Close(), ButtonKind.Subtle));
            layout.Controls.Add(buttons, 0, 2); Controls.Add(layout); timer.Tick += (s, e) => RefreshRows(); Shown += (s, e) => { RefreshRows(); timer.Start(); }; FormClosed += (s, e) => timer.Dispose();
        }
        void RefreshRows()
        {
            if (retryButton != null) retryButton.Enabled = summary.Finished && summary.Rows.Any(r => r.State == "failed" || r.State == "cached" || r.State == "stopped");
            int at = Math.Max(0, grid.FirstDisplayedScrollingRowIndex); counts.Text = summary.Counts(); grid.Rows.Clear();
            foreach (var row in summary.Rows) { int n = grid.Rows.Add(row.Name, row.Login, row.Server, ReportRunSummary.Status(row.State), row.Reason, row.Attempts); grid.Rows[n].Cells[4].ToolTipText = row.Reason; }
            if (at < grid.Rows.Count) grid.FirstDisplayedScrollingRowIndex = at;
        }
    }
}
