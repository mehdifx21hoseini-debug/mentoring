using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Windows.Forms;

namespace MTManager
{
    /// <summary>The look shared by the program and its setup: sizes that follow the screen scaling, fonts and colors.</summary>
    static class Theme
    {
        [DllImport("user32.dll")]
        static extern bool SetProcessDPIAware();

        /// <summary>Screen scaling: 1 at 100%, 1.5 at 150%. Fonts follow it by themselves; pixel sizes go through S().</summary>
        public static float Scale = 1f;
        public static string Family = "Tahoma";
        static float fontScale = 1f;

        public static Font Font, Bold, Small, SmallBold, Heading, Title, Number, Link;

        // The colors of the chosen look (see Palettes); set by Apply before any window is made.
        public static Color Accent, AccentHover, AccentDown, AccentSoft, AccentLine, AccentText, OnAccent;
        public static Color Page, Surface, Footer, Border, BorderStrong, Hover, Input, HeroTop, Alt;
        public static Color Text, LabelColor, Muted, Faint;
        public static Color Ok, OkSoft, Bad, BadSoft, Warn, WarnSoft, WarnLine, WarnMark;
        public static Color Violet, VioletSoft, Neutral;
        public static bool Dark;
        public static Palette Current;

        /// <summary>Windows 11 corners: slightly rounded (4 px controls, 8 px cards).</summary>
        /// <summary>Sharp corners everywhere (kept as a switch; the program uses rounded ones).</summary>
        public static readonly bool Square = false;

        // The dark band at the top of the main window (title, search and commands).
        public static readonly Color BandBack = C(0x1F1F1F), BandText = Color.White, BandSub = C(0xA3A3A3), BandHover = C(0x2E2E2E), BandDown = C(0x383838),
            BandLine = C(0x3A3A3A), BandField = C(0x2C2C2C), BandFieldLine = C(0x3B3B3B), BandFieldText = C(0x9B9B9B),
            BandPrimary = C(0x60CDFF), BandPrimaryHover = C(0x7AD5FF), BandPrimaryDown = C(0x4CB8EA), BandPrimaryText = C(0x00131F);

        static Color C(int rgb) { return Color.FromArgb((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255); }

        /// <summary>The looks to choose from in Settings: classic Windows (light) and a dark trading-terminal look.</summary>
        public static readonly Palette[] Palettes =
        {
            new Palette
            {
                Id = "classic", NameFa = "گرافیت", NameEn = "Graphite",
                Accent = C(0x005FB8), AccentHover = C(0x1A6FC2), AccentDown = C(0x004C93), AccentSoft = C(0xE8F1FB), AccentLine = C(0xC4DCF3), AccentText = C(0x005FB8), OnAccent = Color.White,
                Page = C(0xF3F3F3), Surface = Color.White, Footer = C(0xF3F3F3), Border = C(0xE3E3E3), BorderStrong = C(0xCFCFCF), Hover = C(0xF5F5F5),
                Input = Color.White, HeroTop = Color.White, Alt = C(0xFAFAFA),
                Text = C(0x1A1A1A), LabelColor = C(0x333333), Muted = C(0x616161), Faint = C(0x8F8F8F),
                Ok = C(0x0F7B0F), OkSoft = C(0xDFF6DD), Bad = C(0xC42B1C), BadSoft = C(0xFDE7E9),
                Warn = C(0x9D5D00), WarnSoft = C(0xFFF4CE), WarnLine = C(0xF0DC9C), WarnMark = C(0x9D5D00),
                Violet = C(0x7A3EE0), VioletSoft = C(0xEFE7FD), Neutral = C(0xEDEDED),
            },
            new Palette
            {
                Id = "terminal", NameFa = "تیره (ترمینال)", NameEn = "Dark (terminal)", IsDark = true,
                Accent = C(0xE8A33D), AccentHover = C(0xF0B456), AccentDown = C(0xC9862A), AccentSoft = C(0x2A3442), AccentLine = C(0x4B6B93), AccentText = C(0xF0B456), OnAccent = C(0x17130B),
                Page = C(0x1B1E23), Surface = C(0x15181C), Footer = C(0x24282E), Border = C(0x30353D), BorderStrong = C(0x3D434C), Hover = C(0x20252C),
                Input = C(0x101317), HeroTop = C(0x15181C), Alt = C(0x191C21),
                Text = C(0xE8EAED), LabelColor = C(0xC9CDD3), Muted = C(0xA2A9B4), Faint = C(0x6E7681),
                Ok = C(0x3FB950), OkSoft = C(0x12321F), Bad = C(0xF85149), BadSoft = C(0x3A1519),
                Warn = C(0xE8A33D), WarnSoft = C(0x2B2414), WarnLine = C(0x6B5420), WarnMark = C(0xE8A33D),
                Violet = C(0xB392F0), VioletSoft = C(0x2A2145), Neutral = C(0x24282E),
            },
        };

        public static void Apply(string id)
        {
            // One look since 3.4 (graphite): the looks of earlier versions all open in it.
            Palette p = Palettes[0];
            Current = p;
            Dark = p.IsDark;
            Accent = p.Accent; AccentHover = p.AccentHover; AccentDown = p.AccentDown; AccentSoft = p.AccentSoft; AccentLine = p.AccentLine; AccentText = p.AccentText; OnAccent = p.OnAccent;
            Page = p.Page; Surface = p.Surface; Footer = p.Footer; Border = p.Border; BorderStrong = p.BorderStrong; Hover = p.Hover; Input = p.Input; HeroTop = p.HeroTop; Alt = p.Alt;
            Text = p.Text; LabelColor = p.LabelColor; Muted = p.Muted; Faint = p.Faint;
            Ok = p.Ok; OkSoft = p.OkSoft; Bad = p.Bad; BadSoft = p.BadSoft; Warn = p.Warn; WarnSoft = p.WarnSoft; WarnLine = p.WarnLine; WarnMark = p.WarnMark;
            Violet = p.Violet; VioletSoft = p.VioletSoft; Neutral = p.Neutral;
        }

        static Theme() { Apply("classic"); }

        [DllImport("dwmapi.dll")]
        static extern int DwmSetWindowAttribute(IntPtr window, int attribute, ref int value, int size);

        /// <summary>A title bar that matches the window: dark above the main window's dark band (Windows 10 and 11),
        /// and exactly the band's color on Windows 11.</summary>
        public static void Window(Form f, bool darkCaption = false)
        {
            f.HandleCreated += (s, e) =>
            {
                try
                {
                    int on = Dark || darkCaption ? 1 : 0;
                    // 20 since Windows 10 2004; 19 on Windows 10 1809-1909 and Server 2019.
                    if (DwmSetWindowAttribute(f.Handle, 20, ref on, 4) != 0) DwmSetWindowAttribute(f.Handle, 19, ref on, 4);
                    int caption = ColorTranslator.ToWin32(darkCaption ? BandBack : Surface), text = ColorTranslator.ToWin32(darkCaption ? BandText : Text);
                    DwmSetWindowAttribute(f.Handle, 35, ref caption, 4);
                    DwmSetWindowAttribute(f.Handle, 36, ref text, 4);
                }
                catch { }  // older Windows, or not Windows at all
            };
        }

        [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)]
        static extern int SetWindowTheme(IntPtr window, string appName, string idList);

        /// <summary>In the dark look, dark scroll bars (and combo boxes) where Windows 10/11 has them; nothing changes elsewhere.</summary>
        public static void DarkParts(Control c, string theme = "DarkMode_Explorer")
        {
            if (!Dark) return;
            Action apply = () => { try { SetWindowTheme(c.Handle, theme, null); } catch { } };
            if (c.IsHandleCreated) apply(); else c.HandleCreated += (s, e) => apply();
        }

        /// <summary>Gives the standard input controls inside a window the look's colors.</summary>
        public static void StyleInputs(Control root)
        {
            foreach (Control c in root.Controls.Cast<Control>().ToList())
            {
                if (c is TextBoxBase || c is ComboBox || c is UpDownBase)
                {
                    c.BackColor = Input;
                    c.ForeColor = Text;
                    if (c is ComboBox) DarkParts(c, "DarkMode_CFD");
                    else if (c is TextBoxBase && ((TextBoxBase)c).Multiline) DarkParts(c);
                    // Plain boxes get the program's own frame; those drawn by the program already (no border) keep theirs.
                    if (InputFrame.Wants(c)) { InputFrame.Wrap(c); continue; }
                }
                else if (c is LinkLabel)
                {
                    var l = (LinkLabel)c;
                    l.LinkColor = l.VisitedLinkColor = AccentText;
                    l.ActiveLinkColor = AccentHover;
                }
                else if (c is CheckBox) c.ForeColor = Text;
                StyleInputs(c);
            }
        }

        /// <summary>Once, before the first window.</summary>
        public static void Init()
        {
            // Sharp text on scaled screens (125%, 150%) instead of Windows stretching a blurry 100% picture.
            try { SetProcessDPIAware(); } catch { }
            float dpi = 96;
            try { using (Graphics g = Graphics.FromHwnd(IntPtr.Zero)) dpi = g.DpiX; } catch { }
            Scale = Math.Max(1f, dpi / 96f);
#if SNAPSHOT
            // Build check on Linux: pretend a scaled screen.
            float forced;
            string s = Environment.GetEnvironmentVariable("MTM_SCALE");
            if (!string.IsNullOrEmpty(s) && float.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out forced))
            {
                fontScale = forced / Scale;
                Scale = forced;
            }
#endif
            LoadFonts();
            Fonts();
        }

        /// <summary>3.27: the program's fonts for the language (again after the language is changed).</summary>
        public static void Fonts()
        {
            regular = vazir;
            semibold = vazirBold;
            Family = familyFa;
            // English in Windows' own Segoe UI (it has the Persian letters of students' names too); Vazirmatn when it is missing.
            if (Lang.En && !forcedFont && Installed("Segoe UI")) { regular = semibold = null; Family = "Segoe UI"; }
            Font = F(9.75f);
            Bold = F(9.75f, FontStyle.Bold);
            Small = F(9f);
            SmallBold = F(9f, FontStyle.Bold);
            Heading = F(12f, FontStyle.Bold);
            Title = F(15f, FontStyle.Bold);
            Number = F(15.5f, FontStyle.Bold);
            Link = F(9.75f, FontStyle.Underline);
        }

        [DllImport("gdi32.dll")]
        static extern IntPtr AddFontMemResourceEx(IntPtr font, uint size, IntPtr reserved, ref uint count);

        static readonly PrivateFontCollection embedded = new PrivateFontCollection();
        static FontFamily regular, semibold, vazir, vazirBold;
        static string familyFa = "Tahoma";
        static bool forcedFont;

        /// <summary>Vazirmatn comes inside the program (SIL Open Font License): nothing is installed in Windows.
        /// GDI+ gets it for Font objects, GDI for the controls and TextRenderer.</summary>
        static void LoadFonts()
        {
#if SNAPSHOT
            // Build check on Linux: Mono cannot measure fonts loaded from memory, so the same font is installed instead.
            string forcedFamily = Environment.GetEnvironmentVariable("MTM_FONT");
            if (!string.IsNullOrEmpty(forcedFamily) && Installed(forcedFamily)) { Family = familyFa = forcedFamily; forcedFont = true; return; }
#endif
            try
            {
                Load("Vazirmatn-Regular.ttf");
                Load("Vazirmatn-SemiBold.ttf");
                regular = embedded.Families.FirstOrDefault(f => f.Name == "Vazirmatn");
                semibold = embedded.Families.FirstOrDefault(f => f.Name == "Vazirmatn SemiBold");
                // One trial with each face before any window uses them: if this Windows cannot use the font,
                // the program falls back to a system font instead of failing to open.
                if (regular != null && !Works(regular)) regular = null;
                if (semibold != null && (regular == null || !Works(semibold))) semibold = null;
            }
            catch (Exception e) { regular = semibold = null; try { Log.Write("font: " + e.Message); } catch { } }
            Family = regular != null ? regular.Name : Installed("Segoe UI") ? "Segoe UI" : "Tahoma";
            vazir = regular;
            vazirBold = semibold;
            familyFa = Family;
        }

        static bool Works(FontFamily family)
        {
            try
            {
                using (var f = new Font(family, 9.75f))
                {
                    int h = f.Height;
                    Size size = TextRenderer.MeasureText("آزمایش 123", f);
                    using (var bmp = new Bitmap(64, 32))
                    using (Graphics g = Graphics.FromImage(bmp))
                    {
                        TextRenderer.DrawText(g, "آزمایش", f, new Point(0, 0), Color.Black);
                        g.DrawString("123", f, Brushes.Black, 0, 0);
                    }
                    return h > 0 && size.Width > 0;
                }
            }
            catch (Exception e)
            {
                try { Log.Write("font " + family.Name + " not usable: " + e.Message); } catch { }
                return false;
            }
        }

        static void Load(string resource)
        {
            using (Stream st = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource))
            {
                if (st == null) return;
                var data = new byte[st.Length];
                int read = 0;
                while (read < data.Length) { int n = st.Read(data, read, data.Length - read); if (n <= 0) break; read += n; }
                // Kept for the life of the program: both GDI and GDI+ read the font from this memory.
                IntPtr mem = Marshal.AllocCoTaskMem(data.Length);
                Marshal.Copy(data, 0, mem, data.Length);
                uint count = 0;
                try { AddFontMemResourceEx(mem, (uint)data.Length, IntPtr.Zero, ref count); } catch { }
                embedded.AddMemoryFont(mem, data.Length);
            }
        }

        static bool Installed(string family)
        {
            try
            {
                using (var fonts = new InstalledFontCollection())
                    return fonts.Families.Any(x => string.Equals(x.Name, family, StringComparison.OrdinalIgnoreCase));
            }
            catch { return false; }
        }

        public static Color Mix(Color a, Color b, float t)
        {
            return Color.FromArgb((int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
        }

        public static Font F(float points, FontStyle style = FontStyle.Regular)
        {
            float size = points * fontScale;
            if (regular != null)
            {
                // The semibold face stands in for bold (it is the real weight, not a thickened regular).
                if ((style & FontStyle.Bold) != 0 && semibold != null) return new Font(semibold, size, style & ~FontStyle.Bold);
                return new Font(regular, size, style);
            }
            return new Font(Family, size, style);
        }

        public static int S(int px) { return (int)Math.Round(px * Scale); }
        public static float Sf(float px) { return px * Scale; }
        public static Size Sz(int w, int h) { return new Size(S(w), S(h)); }
        public static Padding Pad(int all) { return new Padding(S(all)); }
        public static Padding Pad(int horizontal, int vertical) { return new Padding(S(horizontal), S(vertical), S(horizontal), S(vertical)); }
        public static Padding Pad(int left, int top, int right, int bottom) { return new Padding(S(left), S(top), S(right), S(bottom)); }

        /// <summary>The color behind a control, for controls that paint their own rounded shape.</summary>
        public static Color BackOf(Control c)
        {
            for (Control p = c; p != null; p = p.Parent)
                if (p.BackColor.A == 255) return p.BackColor;
            return Surface;
        }

        public static GraphicsPath Round(RectangleF r, float radius)
        {
            var p = new GraphicsPath();
            float d = Math.Min(radius * 2, Math.Min(r.Width, r.Height));
            if (d < 1)
            {
                p.AddRectangle(r);
                return p;
            }
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        /// <summary>A rounded box filling the rectangle, its 1px border inside it.</summary>
        public static void Box(Graphics g, Rectangle r, float radius, Color fill, Color border)
        {
            if (Square)
            {
                if (fill.A > 0) using (var b = new SolidBrush(fill)) g.FillRectangle(b, r);
                if (border.A > 0) using (var pen = new Pen(border)) g.DrawRectangle(pen, r.X, r.Y, r.Width - 1, r.Height - 1);
                return;
            }
            SmoothingMode old = g.SmoothingMode;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var rr = new RectangleF(r.X + 0.5f, r.Y + 0.5f, r.Width - 1, r.Height - 1);
            using (GraphicsPath p = Round(rr, radius))
            {
                if (fill.A > 0) using (var b = new SolidBrush(fill)) g.FillPath(b, p);
                if (border.A > 0) using (var pen = new Pen(border)) g.DrawPath(pen, p);
            }
            g.SmoothingMode = old;
        }

        // ---------------------------------------------------------------- input boxes (3.15.1: «قاب نرم»)

        /// <summary>Room around an input box for its focus ring.</summary>
        public static int FieldRing { get { return S(3); } }

        /// <summary>The height of an input box itself (without the ring).</summary>
        public static int FieldHeight { get { return S(32); } }

        public static Color FieldHover { get { return Mix(BorderStrong, Muted, 0.55f); } }

        /// <summary>An input box filling r less the ring around it: rounded, white, a gray frame (darker under the mouse);
        /// while typing an accent frame with a soft ring of the same color; red when its value is not accepted; gray when off.</summary>
        public static void Field(Graphics g, Rectangle r, FieldLook look)
        {
            int ring = FieldRing;
            var box = new RectangleF(r.X + ring + 0.5f, r.Y + ring + 0.5f, r.Width - 2 * ring - 1, r.Height - 2 * ring - 1);
            float radius = Square ? 0 : Sf(8);
            SmoothingMode old = g.SmoothingMode;
            g.SmoothingMode = Square ? SmoothingMode.None : SmoothingMode.AntiAlias;
            bool strong = look == FieldLook.Focus || look == FieldLook.Bad;
            Color edge = look == FieldLook.Bad ? Bad : look == FieldLook.Focus ? Accent : look == FieldLook.Hover ? FieldHover : look == FieldLook.Off ? Border : BorderStrong;
            if (strong)
            {
                var halo = new RectangleF(box.X - ring + 0.5f, box.Y - ring + 0.5f, box.Width + 2 * ring - 1, box.Height + 2 * ring - 1);
                using (GraphicsPath p = Round(halo, radius + ring))
                using (var b = new SolidBrush(Color.FromArgb(look == FieldLook.Bad ? (Dark ? 50 : 34) : (Dark ? 56 : 41), edge))) g.FillPath(b, p);
            }
            using (GraphicsPath p = Round(box, radius))
            {
                using (var b = new SolidBrush(look == FieldLook.Off ? Hover : Input)) g.FillPath(b, p);
                using (var pen = new Pen(edge, strong ? Sf(1.5f) : 1f)) g.DrawPath(pen, p);
            }
            g.SmoothingMode = old;
        }

        /// <summary>The text direction of the language (3.27: none in English) with no prefix or padding.</summary>
        public static TextFormatFlags Rtl { get { return (Lang.En ? TextFormatFlags.Default : TextFormatFlags.RightToLeft) | TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding; } }
        /// <summary>3.27: where a line of text starts: the right in Persian, the left in English; End is the other side.</summary>
        public static TextFormatFlags Start { get { return Lang.En ? TextFormatFlags.Left : TextFormatFlags.Right; } }
        public static TextFormatFlags End { get { return Lang.En ? TextFormatFlags.Right : TextFormatFlags.Left; } }
        /// <summary>3.27: RightToLeft for the controls of the language.</summary>
        public static RightToLeft Dir { get { return Lang.En ? RightToLeft.No : RightToLeft.Yes; } }

        /// <summary>3.27: a rectangle placed for right to left (the Persian design), on the other side in English: mirrored within
        /// [left, right). In Persian it is the same rectangle.</summary>
        public static Rectangle Flip(Rectangle r, int left, int right)
        {
            return Lang.En ? new Rectangle(left + right - r.Right, r.Y, r.Width, r.Height) : r;
        }
        public static Rectangle Flip(Rectangle r, Rectangle within) { return Flip(r, within.Left, within.Right); }
        public static RectangleF Flip(RectangleF r, Rectangle within) { return Lang.En ? new RectangleF(within.Left + within.Right - r.Right, r.Y, r.Width, r.Height) : r; }
        /// <summary>3.27: an x placed for right to left, on the other side in English (for something w wide within [0, width)).</summary>
        public static int FlipX(int x, int w, int width) { return Lang.En ? width - x - w : x; }

        /// <summary>One line of text: aligned to the start (right in Persian, left in English) unless centered.</summary>
        public static void Line(Graphics g, string text, Font font, Rectangle r, Color color, bool center = false)
        {
            TextFormatFlags f = Rtl | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis |
                                (center ? TextFormatFlags.HorizontalCenter : Start);
            TextRenderer.DrawText(g, text, font, r, color, f);
        }

        /// <summary>One line of figures (an amount with its sign, a percent): left to right, so "-72.00" never shows as "72.00-",
        /// but aligned to the right like the Persian text around it.</summary>
        public static void Amount(Graphics g, string text, Font font, Rectangle r, Color color)
        {
            TextRenderer.DrawText(g, text, font, r, color, TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding | TextFormatFlags.SingleLine |
                                                           TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.Right);
        }

        public static Size Measure(string text, Font font)
        {
            return TextRenderer.MeasureText(text ?? "", font, Size.Empty, Rtl | TextFormatFlags.SingleLine);
        }

        /// <summary>The size a label needs to show its text wrapped within a width, measured the way the label draws it.</summary>
        public static Size WrapSize(Control l, int maxWidth)
        {
            TextFormatFlags f = TextFormatFlags.WordBreak | TextFormatFlags.TextBoxControl | TextFormatFlags.NoPrefix |
                                (l.RightToLeft == RightToLeft.Yes ? TextFormatFlags.RightToLeft : 0);
            int inner = Math.Max(1, maxWidth - l.Padding.Horizontal);
            Size t = TextRenderer.MeasureText(l.Text ?? "", l.Font, new Size(inner, 0), f);
            return new Size(Math.Min(maxWidth, t.Width + l.Padding.Horizontal + 2), t.Height + l.Padding.Vertical + 1);
        }

        public static Label Label(string text, int maxWidth = 0, Font font = null, Color? color = null)
        {
            // UseMnemonic off: an "&" in a path or a name is shown, not turned into a keyboard shortcut.
            var l = new Label { Text = text, AutoSize = true, Margin = Pad(0, 4, 0, 4), ForeColor = color ?? Theme.LabelColor, Font = font ?? Font, RightToLeft = Theme.Dir, UseMnemonic = false };
            if (maxWidth > 0) l.MaximumSize = new Size(S(maxWidth), 0);
            return l;
        }

        /// <summary>A square tick box: empty (0), a dash for "some" (1), or filled with a tick (2).</summary>
        public static void TickBox(Graphics g, Rectangle box, int state, bool hover)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            if (state == 0)
            {
                Box(g, box, Sf(3), hover ? AccentSoft : Surface, hover ? Accent : BorderStrong);
                return;
            }
            Box(g, box, Sf(3), Accent, Accent);
            if (state == 1)
            {
                int w = box.Width / 2, h = Math.Max(2, S(2));
                using (var b = new SolidBrush(Color.White)) g.FillRectangle(b, box.X + (box.Width - w) / 2, box.Y + (box.Height - h) / 2, w, h);
            }
            else Glyphs.Draw(g, Glyph.Check, new RectangleF(box.X + 1, box.Y + 1, box.Width - 2, box.Height - 2), Color.White);
        }

        public static ContextMenuStrip Menu()
        {
            var m = new ContextMenuStrip
            {
                RightToLeft = Theme.Dir, Font = Font, ShowImageMargin = false, ShowCheckMargin = false,
                Renderer = new FluentRenderer(),
                Padding = Pad(4, 4), BackColor = Surface,
            };
            return m;
        }

        public static ToolStripMenuItem Item(ContextMenuStrip menu, string text, EventHandler click)
        {
            var item = new ToolStripMenuItem(text) { Padding = Pad(10, 6), ForeColor = Text };
            item.Click += click;
            menu.Items.Add(item);
            return item;
        }

        /// <summary>3.26 (CHANGE-006B): a menu item's small line icon, drawn at the screen's scale.</summary>
        public static Bitmap MenuIcon(Glyph glyph, Color color)
        {
            int size = S(16);
            var bmp = new Bitmap(size, size);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.Transparent);
                Glyphs.Draw(g, glyph, new RectangleF(S(1), S(1), size - S(2), size - S(2)), color);
            }
            return bmp;
        }

        public static void Separator(ContextMenuStrip menu)
        {
            menu.Items.Add(new ToolStripSeparator { Margin = Pad(0, 3) });
        }

        /// <summary>Turns on double buffering where WinForms keeps it private (the grid), so it repaints without flicker.</summary>
        public static void DoubleBuffer(Control c)
        {
            try
            {
                typeof(Control).GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
                    .SetValue(c, true, null);
            }
            catch { }
        }
    }

    public sealed class Palette
    {
        public string Id, NameFa, NameEn;
        /// <summary>3.27.2: in the language shown now (the palettes are made once, before a language change).</summary>
        public string Name { get { return Lang.T(NameFa, NameEn); } }
        public bool IsDark;
        public Color Accent, AccentHover, AccentDown, AccentSoft, AccentLine, AccentText, OnAccent;
        public Color Page, Surface, Footer, Border, BorderStrong, Hover, Input, HeroTop, Alt;
        public Color Text, LabelColor, Muted, Faint;
        public Color Ok, OkSoft, Bad, BadSoft, Warn, WarnSoft, WarnLine, WarnMark;
        public Color Violet, VioletSoft, Neutral;
    }

    public enum Glyph { None, Plus, Play, Stop, User, Chevron, Help, Gear, Folder, Check, Logo, Info, Warning, Error, Question, Success, ChevronRight, ChevronLeft, Chart, Pulse, Doc, More, Copies, Window, UserAdd, Refresh, Grip, CopyText, Key, Plug, Trash, FolderMove, Lock, Eye, EyeOff }

    /// <summary>Small line icons drawn in code, so they stay sharp at any screen scaling.</summary>
    static class Glyphs
    {
        public static void Draw(Graphics g, Glyph glyph, RectangleF r, Color c)
        {
            SmoothingMode old = g.SmoothingMode;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float w = Math.Max(1.4f, r.Width * 0.11f);
            using (var pen = new Pen(c, w) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
            using (var brush = new SolidBrush(c))
            {
                Func<float, float, PointF> P = (x, y) => new PointF(r.X + x * r.Width, r.Y + y * r.Height);
                Func<float, float, float, float, RectangleF> R = (x, y, ww, hh) => new RectangleF(r.X + x * r.Width, r.Y + y * r.Height, ww * r.Width, hh * r.Height);
                switch (glyph)
                {
                    case Glyph.Plus:
                        g.DrawLine(pen, P(0.5f, 0.17f), P(0.5f, 0.83f));
                        g.DrawLine(pen, P(0.17f, 0.5f), P(0.83f, 0.5f));
                        break;
                    case Glyph.Play:
                        {
                            var pts = new[] { P(0.3f, 0.2f), P(0.8f, 0.5f), P(0.3f, 0.8f) };
                            g.FillPolygon(brush, pts);
                            using (var thin = new Pen(c, w * 0.8f) { LineJoin = LineJoin.Round }) g.DrawPolygon(thin, pts);
                        }
                        break;
                    case Glyph.Refresh:
                        // A circle not closed at the top right, with its arrowhead: "read again".
                        g.DrawArc(pen, R(0.16f, 0.16f, 0.68f, 0.68f), -60, 300);
                        g.FillPolygon(brush, new[] { P(0.62f, 0.06f), P(0.9f, 0.24f), P(0.6f, 0.38f) });
                        break;
                    case Glyph.CopyText:
                        // A sheet with two lines of text, another behind it: "copy the text".
                        using (GraphicsPath p = Theme.Round(R(0.34f, 0.3f, 0.52f, 0.62f), r.Width * 0.08f)) g.DrawPath(pen, p);
                        g.DrawLines(pen, new[] { P(0.14f, 0.7f), P(0.14f, 0.16f), P(0.62f, 0.16f) });
                        g.DrawLine(pen, P(0.47f, 0.5f), P(0.73f, 0.5f));
                        g.DrawLine(pen, P(0.47f, 0.7f), P(0.73f, 0.7f));
                        break;
                    case Glyph.Grip:
                        // Six dots: a row that can be dragged.
                        for (int gx = 0; gx < 2; gx++)
                            for (int gy = 0; gy < 3; gy++)
                                g.FillEllipse(brush, R(0.3f + gx * 0.28f, 0.16f + gy * 0.28f, 0.14f, 0.14f));
                        break;
                    case Glyph.Stop:
                        using (GraphicsPath p = Theme.Round(R(0.24f, 0.24f, 0.52f, 0.52f), r.Width * 0.08f)) g.FillPath(brush, p);
                        break;
                    case Glyph.User:
                        g.DrawEllipse(pen, R(0.33f, 0.14f, 0.34f, 0.34f));
                        g.DrawArc(pen, R(0.17f, 0.58f, 0.66f, 0.56f), 180, 180);
                        break;
                    case Glyph.Chevron:
                        g.DrawLines(pen, new[] { P(0.27f, 0.4f), P(0.5f, 0.63f), P(0.73f, 0.4f) });
                        break;
                    case Glyph.Help:
                        g.DrawEllipse(pen, R(0.1f, 0.1f, 0.8f, 0.8f));
                        g.DrawArc(pen, R(0.37f, 0.26f, 0.26f, 0.24f), 190, 250);
                        g.DrawLine(pen, P(0.5f, 0.5f), P(0.5f, 0.56f));
                        g.FillEllipse(brush, R(0.445f, 0.66f, 0.11f, 0.11f));
                        break;
                    case Glyph.Gear:
                        for (int k = 0; k < 8; k++)
                        {
                            double a = k * Math.PI / 4;
                            float cx = 0.5f, cy = 0.5f;
                            using (var tooth = new Pen(c, r.Width * 0.14f))
                                g.DrawLine(tooth, P(cx + 0.27f * (float)Math.Cos(a), cy + 0.27f * (float)Math.Sin(a)), P(cx + 0.42f * (float)Math.Cos(a), cy + 0.42f * (float)Math.Sin(a)));
                        }
                        g.DrawEllipse(pen, R(0.24f, 0.24f, 0.52f, 0.52f));
                        g.DrawEllipse(pen, R(0.41f, 0.41f, 0.18f, 0.18f));
                        break;
                    case Glyph.Folder:
                        g.DrawPolygon(pen, new[] { P(0.12f, 0.24f), P(0.4f, 0.24f), P(0.48f, 0.34f), P(0.88f, 0.34f), P(0.88f, 0.78f), P(0.12f, 0.78f) });
                        break;
                    case Glyph.ChevronRight:
                        g.DrawLines(pen, new[] { P(0.38f, 0.2f), P(0.68f, 0.5f), P(0.38f, 0.8f) });
                        break;
                    case Glyph.ChevronLeft:
                        g.DrawLines(pen, new[] { P(0.62f, 0.2f), P(0.32f, 0.5f), P(0.62f, 0.8f) });
                        break;
                    case Glyph.Chart:
                        g.DrawLines(pen, new[] { P(0.1f, 0.8f), P(0.35f, 0.5f), P(0.55f, 0.65f), P(0.9f, 0.22f) });
                        g.DrawLine(pen, P(0.06f, 0.94f), P(0.94f, 0.94f));
                        break;
                    case Glyph.Pulse:
                        g.DrawLines(pen, new[] { P(0.05f, 0.55f), P(0.28f, 0.55f), P(0.4f, 0.25f), P(0.58f, 0.82f), P(0.7f, 0.45f), P(0.78f, 0.55f), P(0.95f, 0.55f) });
                        break;
                    case Glyph.Doc:
                        g.DrawPolygon(pen, new[] { P(0.22f, 0.1f), P(0.62f, 0.1f), P(0.8f, 0.28f), P(0.8f, 0.9f), P(0.22f, 0.9f) });
                        g.DrawLines(pen, new[] { P(0.36f, 0.56f), P(0.48f, 0.68f), P(0.66f, 0.44f) });
                        break;
                    case Glyph.Check:
                        g.DrawLines(pen, new[] { P(0.2f, 0.52f), P(0.41f, 0.72f), P(0.8f, 0.3f) });
                        break;
                    case Glyph.More:
                        foreach (float x in new[] { 0.18f, 0.5f, 0.82f }) g.FillEllipse(brush, R(x - 0.085f, 0.415f, 0.17f, 0.17f));
                        break;
                    case Glyph.Copies:
                        using (GraphicsPath p = Theme.Round(R(0.1f, 0.3f, 0.56f, 0.56f), r.Width * 0.09f)) g.DrawPath(pen, p);
                        g.DrawLines(pen, new[] { P(0.34f, 0.14f), P(0.8f, 0.14f), P(0.88f, 0.22f), P(0.88f, 0.66f) });
                        break;
                    // 3.26 (CHANGE-006B): icons of the row menu.
                    case Glyph.Key:
                        g.DrawEllipse(pen, R(0.08f, 0.32f, 0.36f, 0.36f));
                        g.DrawLine(pen, P(0.44f, 0.5f), P(0.92f, 0.5f));
                        g.DrawLine(pen, P(0.8f, 0.5f), P(0.8f, 0.68f));
                        g.DrawLine(pen, P(0.66f, 0.5f), P(0.66f, 0.64f));
                        break;
                    case Glyph.Plug:
                        g.DrawLine(pen, P(0.36f, 0.08f), P(0.36f, 0.3f));
                        g.DrawLine(pen, P(0.64f, 0.08f), P(0.64f, 0.3f));
                        using (GraphicsPath p = Theme.Round(R(0.2f, 0.3f, 0.6f, 0.34f), r.Width * 0.08f)) g.DrawPath(pen, p);
                        g.DrawLine(pen, P(0.5f, 0.64f), P(0.5f, 0.92f));
                        break;
                    case Glyph.Trash:
                        g.DrawLine(pen, P(0.14f, 0.24f), P(0.86f, 0.24f));
                        g.DrawLines(pen, new[] { P(0.38f, 0.24f), P(0.38f, 0.1f), P(0.62f, 0.1f), P(0.62f, 0.24f) });
                        g.DrawLines(pen, new[] { P(0.22f, 0.24f), P(0.28f, 0.9f), P(0.72f, 0.9f), P(0.78f, 0.24f) });
                        break;
                    case Glyph.Lock:
                        using (GraphicsPath p = Theme.Round(R(0.18f, 0.44f, 0.64f, 0.48f), r.Width * 0.08f)) g.DrawPath(pen, p);
                        g.DrawArc(pen, R(0.3f, 0.1f, 0.4f, 0.6f), 180, 180);
                        break;
                    case Glyph.Eye:
                    case Glyph.EyeOff:
                        g.DrawBezier(pen, P(0.05f, 0.5f), P(0.3f, 0.12f), P(0.7f, 0.12f), P(0.95f, 0.5f));
                        g.DrawBezier(pen, P(0.05f, 0.5f), P(0.3f, 0.88f), P(0.7f, 0.88f), P(0.95f, 0.5f));
                        g.DrawEllipse(pen, R(0.38f, 0.38f, 0.24f, 0.24f));
                        if (glyph == Glyph.EyeOff) g.DrawLine(pen, P(0.14f, 0.12f), P(0.86f, 0.88f));
                        break;
                    case Glyph.FolderMove:
                        g.DrawPolygon(pen, new[] { P(0.12f, 0.24f), P(0.4f, 0.24f), P(0.48f, 0.34f), P(0.88f, 0.34f), P(0.88f, 0.78f), P(0.12f, 0.78f) });
                        g.DrawLine(pen, P(0.34f, 0.56f), P(0.64f, 0.56f));
                        g.DrawLines(pen, new[] { P(0.54f, 0.46f), P(0.64f, 0.56f), P(0.54f, 0.66f) });
                        break;
                    case Glyph.Window:
                        using (GraphicsPath p = Theme.Round(R(0.1f, 0.18f, 0.8f, 0.64f), r.Width * 0.09f)) g.DrawPath(pen, p);
                        g.DrawLine(pen, P(0.1f, 0.38f), P(0.9f, 0.38f));
                        break;
                    case Glyph.UserAdd:
                        g.DrawEllipse(pen, R(0.2f, 0.1f, 0.34f, 0.34f));
                        g.DrawArc(pen, R(0.06f, 0.56f, 0.62f, 0.56f), 180, 90);
                        g.DrawLine(pen, P(0.78f, 0.56f), P(0.78f, 0.94f));
                        g.DrawLine(pen, P(0.59f, 0.75f), P(0.97f, 0.75f));
                        break;
                    case Glyph.Logo:
                        DrawLogo(g, r);
                        break;
                    case Glyph.Info:
                    case Glyph.Warning:
                    case Glyph.Error:
                    case Glyph.Question:
                    case Glyph.Success:
                        DrawStatus(g, glyph, r);
                        break;
                }
            }
            g.SmoothingMode = old;
        }

        /// <summary>3.22: the program's logo (MetaFactory) as a picture inside the program: the whole logo, or below 48 pixels its gear
        /// and candles alone, where the words could not be read. False when the picture is not there.</summary>
        static Image logoFull, logoSmall;
        static bool logoTried;

        public static bool DrawLogoImage(Graphics g, RectangleF r)
        {
            if (!logoTried)
            {
                logoTried = true;
                Func<string, Image> load = name =>
                {
                    try
                    {
                        using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
                            return s == null ? null : new Bitmap(Image.FromStream(s));
                    }
                    catch { return null; }
                };
                logoFull = load("logo.png");
                logoSmall = load("logo-small.png");
            }
            Image img = r.Width < 48 && logoSmall != null ? logoSmall : logoFull ?? logoSmall;
            if (img == null) return false;
            System.Drawing.Drawing2D.InterpolationMode im = g.InterpolationMode;
            System.Drawing.Drawing2D.PixelOffsetMode pm = g.PixelOffsetMode;
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            g.DrawImage(img, r);
            g.InterpolationMode = im;
            g.PixelOffsetMode = pm;
            return true;
        }

        /// <summary>The program's mark: the logo picture; when it is missing, the earlier drawn mark (three stacked terminal windows).</summary>
        static void DrawLogo(Graphics g, RectangleF r)
        {
            if (DrawLogoImage(g, r)) return;
            Func<float, float, float, float, RectangleF> R = (x, y, w, h) => new RectangleF(r.X + x * r.Width, r.Y + y * r.Height, w * r.Width, h * r.Height);
            float rad = r.Width * 0.07f;
            Color[] colors = { Theme.Mix(Theme.Accent, Color.White, 0.55f), Theme.Mix(Theme.Accent, Color.White, 0.3f), Theme.Accent };
            for (int k = 0; k < 3; k++)
            {
                RectangleF box = R(0.06f + k * 0.13f, 0.1f + k * 0.13f, 0.56f, 0.46f);
                using (GraphicsPath p = Theme.Round(box, rad))
                {
                    using (var b = new SolidBrush(colors[k])) g.FillPath(b, p);
                    if (k > 0) using (var edge = new Pen(Theme.Surface, Math.Max(1f, r.Width * 0.025f))) g.DrawPath(edge, p);
                }
            }
            RectangleF front = R(0.32f, 0.36f, 0.56f, 0.46f);
            Func<float, float, PointF> F = (x, y) => new PointF(front.X + x * front.Width, front.Y + y * front.Height);
            using (var line = new Pen(Color.White, Math.Max(1.2f, r.Width * 0.045f)) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
                g.DrawLines(line, new[] { F(0.12f, 0.82f), F(0.36f, 0.6f), F(0.55f, 0.72f), F(0.88f, 0.34f) });
        }

        static void DrawStatus(Graphics g, Glyph glyph, RectangleF r)
        {
            Color soft, strong;
            switch (glyph)
            {
                case Glyph.Warning: soft = Theme.WarnMark; strong = Theme.Dark ? Theme.OnAccent : Theme.Warn; break;
                case Glyph.Error: soft = Theme.BadSoft; strong = Theme.Bad; break;
                case Glyph.Success: soft = Theme.OkSoft; strong = Theme.Ok; break;
                default: soft = Theme.AccentSoft; strong = Theme.AccentText; break;
            }
            using (var b = new SolidBrush(soft)) g.FillEllipse(b, r);
            RectangleF inner = new RectangleF(r.X + r.Width * 0.25f, r.Y + r.Height * 0.25f, r.Width * 0.5f, r.Height * 0.5f);
            Func<float, float, PointF> P = (x, y) => new PointF(inner.X + x * inner.Width, inner.Y + y * inner.Height);
            float w = Math.Max(1.6f, r.Width * 0.075f);
            using (var pen = new Pen(strong, w) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
            using (var brush = new SolidBrush(strong))
            {
                float dot = w * 1.25f;
                switch (glyph)
                {
                    case Glyph.Info:
                        g.FillEllipse(brush, P(0.5f, 0.1f).X - dot / 2, P(0.5f, 0.1f).Y - dot / 2, dot, dot);
                        g.DrawLine(pen, P(0.5f, 0.38f), P(0.5f, 0.9f));
                        break;
                    case Glyph.Warning:
                        g.DrawLine(pen, P(0.5f, 0.08f), P(0.5f, 0.62f));
                        g.FillEllipse(brush, P(0.5f, 0.9f).X - dot / 2, P(0.5f, 0.9f).Y - dot / 2, dot, dot);
                        break;
                    case Glyph.Error:
                        g.DrawLine(pen, P(0.18f, 0.18f), P(0.82f, 0.82f));
                        g.DrawLine(pen, P(0.82f, 0.18f), P(0.18f, 0.82f));
                        break;
                    case Glyph.Question:
                        g.DrawArc(pen, new RectangleF(P(0.24f, 0.0f).X, P(0.24f, 0.0f).Y, inner.Width * 0.52f, inner.Height * 0.48f), 190, 250);
                        g.DrawLine(pen, P(0.5f, 0.48f), P(0.5f, 0.6f));
                        g.FillEllipse(brush, P(0.5f, 0.9f).X - dot / 2, P(0.5f, 0.9f).Y - dot / 2, dot, dot);
                        break;
                    case Glyph.Success:
                        g.DrawLines(pen, new[] { P(0.08f, 0.52f), P(0.38f, 0.8f), P(0.92f, 0.2f) });
                        break;
                }
            }
        }
    }

    public enum ButtonKind { Primary, Secondary, Subtle, Danger }

    /// <summary>A flat rounded button that keeps everything a button does (Enter, Esc, keyboard focus).</summary>
    class ModernButton : Button
    {
        ButtonKind kind;
        readonly Glyph icon, trailing;
        readonly bool compact;
        bool hover, down;
        bool outline;
        public bool Outline { get { return outline; } set { outline = value; Invalidate(); } }

        public ModernButton(string text, ButtonKind kind = ButtonKind.Secondary, Glyph icon = Glyph.None, Glyph trailing = Glyph.None, bool compact = false)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            this.kind = kind;
            this.icon = icon;
            this.trailing = trailing;
            this.compact = compact;
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            UseVisualStyleBackColor = false;
            Cursor = Cursors.Hand;
            Margin = Theme.Pad(4, 0);
            Font = kind == ButtonKind.Primary || kind == ButtonKind.Danger ? Theme.Bold : Theme.Font;
            Text = text;
            Fit();
        }

        public ModernButton(string text, EventHandler click, ButtonKind kind = ButtonKind.Secondary, Glyph icon = Glyph.None)
            : this(text, kind, icon)
        {
            if (click != null) Click += click;
        }

        /// <summary>Changing it restyles the button (used for on/off toggles).</summary>
        public ButtonKind Kind
        {
            get { return kind; }
            set
            {
                if (kind == value) return;
                kind = value;
                Font = kind == ButtonKind.Primary || kind == ButtonKind.Danger ? Theme.Bold : Theme.Font;
                Fit();
                Invalidate();
            }
        }

        void Fit()
        {
            int iconSize = Theme.S(compact ? 14 : 16), gap = Theme.S(8);
            Size t = Text.Length > 0 ? Theme.Measure(Text, Font) : Size.Empty;
            int w = t.Width + Theme.S(compact ? 24 : 32);
            if (icon != Glyph.None) w += iconSize + (t.Width > 0 ? gap : 0);
            if (trailing != Glyph.None) w += iconSize + gap;
            if (Text.Length == 0) w = Theme.S(compact ? 30 : 36);
            int h = Math.Max(Theme.S(compact ? 30 : 36), t.Height + Theme.S(compact ? 10 : 14));
            Size = new Size(Math.Max(w, MinimumSize.Width), h);
        }

        protected override void OnTextChanged(EventArgs e) { base.OnTextChanged(e); Fit(); Invalidate(); }
        protected override void OnFontChanged(EventArgs e) { base.OnFontChanged(e); Fit(); }
        protected override void OnMouseEnter(EventArgs e) { hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { hover = false; down = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { if (e.Button == MouseButtons.Left) { down = true; Invalidate(); } base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { down = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent));
            Color fill, border, fore;
            switch (kind)
            {
                case ButtonKind.Primary:
                    fill = outline ? (down || hover ? Theme.AccentSoft : Theme.Surface) : down ? Theme.AccentDown : hover ? Theme.AccentHover : Theme.Accent;
                    border = outline ? Theme.AccentLine : fill;
                    fore = outline ? Theme.AccentText : Theme.OnAccent;
                    break;
                case ButtonKind.Danger:
                    fill = outline ? (down || hover ? Theme.BadSoft : Theme.Surface) : down ? Theme.Mix(Theme.Bad, Color.Black, 0.25f) : hover ? Theme.Mix(Theme.Bad, Color.Black, 0.12f) : Theme.Bad;
                    border = outline ? Theme.Bad : fill;
                    fore = outline ? Theme.Bad : Color.White;
                    break;
                case ButtonKind.Subtle:
                    // A command button: flat until the mouse is over it, then a light gray fill (Windows 11).
                    fill = down ? Theme.Mix(Theme.Hover, Color.Black, 0.04f) : hover ? Theme.Hover : Color.Transparent;
                    border = Color.Transparent;
                    fore = Theme.Text;
                    break;
                default:
                    fill = down ? Theme.Mix(Theme.Hover, Color.Black, 0.04f) : hover ? Theme.Alt : Theme.Surface;
                    border = Theme.BorderStrong;
                    fore = Theme.Text;
                    break;
            }
            if (!Enabled)
            {
                fill = kind == ButtonKind.Subtle ? Color.Transparent : Theme.Neutral;
                border = kind == ButtonKind.Subtle ? Color.Transparent : Theme.Border;
                fore = Theme.Faint;
            }
            float radius = Theme.Square ? 0 : Theme.Sf(4);
            Theme.Box(g, ClientRectangle, radius, fill, border);
            if (Focused && ShowFocusCues)
            {
                g.SmoothingMode = Theme.Square ? SmoothingMode.None : SmoothingMode.AntiAlias;
                float inset = Theme.Sf(2);
                var focus = new RectangleF(inset, inset, Width - 1 - 2 * inset, Height - 1 - 2 * inset);
                using (var pen = new Pen(kind == ButtonKind.Primary || kind == ButtonKind.Danger ? Theme.OnAccent : Theme.Accent, Theme.Sf(1.5f)) { DashStyle = DashStyle.Dot })
                using (GraphicsPath p = Theme.Round(focus, radius - inset)) g.DrawPath(pen, p);
            }

            bool rtl = RightToLeft == RightToLeft.Yes;
            int iconSize = Theme.S(compact ? 14 : 16), gap = Theme.S(8);
            Size t = Text.Length > 0 ? Theme.Measure(Text, Font) : Size.Empty;
            int lead = icon != Glyph.None ? iconSize + (t.Width > 0 ? gap : 0) : 0;
            int trail = trailing != Glyph.None ? iconSize + gap : 0;
            int total = lead + t.Width + trail;
            int x = (Width - total) / 2;
            int iy = (Height - iconSize) / 2;
            // Right to left: the icon comes first on the right, the trailing one last on the left.
            int textX = rtl ? x + trail : x + lead;
            if (icon != Glyph.None)
                Glyphs.Draw(g, icon, new RectangleF(rtl ? x + total - iconSize : x, iy, iconSize, iconSize), fore);
            if (trailing != Glyph.None)
                Glyphs.Draw(g, trailing, new RectangleF(rtl ? x : x + total - iconSize, iy, iconSize, iconSize), fore);
            if (t.Width > 0)
                TextRenderer.DrawText(g, Text, Font, new Rectangle(textX, 0, t.Width + 2, Height), fore,
                    Theme.Rtl | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter | TextFormatFlags.NoClipping);
        }
    }

    /// <summary>A white rounded card; children sit inside its padding.</summary>
    class Card : Panel
    {
        public Color Fill = Theme.Surface;
        public Color Border = Theme.Border;
        public float Radius = Theme.Sf(8);

        public Card()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Surface;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Theme.BackOf(Parent));
            Theme.Box(e.Graphics, ClientRectangle, Radius, Fill, Border);
        }
    }

    /// <summary>One option of a few, shown as a selectable card (instead of a small round radio button).</summary>
    sealed class Choice : RadioButton
    {
        readonly string note;
        readonly Palette preview;
        bool hover;

        /// <summary>A look to choose: shows a small picture of its colors.</summary>
        public Palette Look { get { return preview; } }

        public Choice(Palette look, int minWidth = 0) : this(look.Name, null, minWidth, look) { }

        public Choice(string text, string note = null, int minWidth = 0, Palette preview = null)
        {
            this.preview = preview;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            this.note = note;
            Text = text;
            AutoSize = false;
            Cursor = Cursors.Hand;
            Margin = Theme.Pad(0, 3, 8, 3);
            Font = Theme.Font;
            Size t = Theme.Measure(text, Theme.Bold);
            Size n = note != null ? Theme.Measure(note, Theme.Small) : Size.Empty;
            int w = Math.Max(t.Width, n.Width) + Theme.S(16 + 18 + 12 + 16) + (preview != null ? Theme.S(44) : 0);
            Size = new Size(Math.Max(w, Theme.S(minWidth)), Theme.S(note != null ? 58 : 42));
        }

        protected override void OnCheckedChanged(EventArgs e) { Invalidate(); base.OnCheckedChanged(e); }
        protected override void OnMouseEnter(EventArgs e) { hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { hover = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent));
            Color fill = Checked ? Theme.AccentSoft : hover ? Theme.Hover : Theme.Surface;
            Color border = Checked ? Theme.Accent : hover ? Theme.Faint : Theme.BorderStrong;
            Theme.Box(g, ClientRectangle, Theme.Sf(6), fill, border);
            if (Checked)
                using (var pen = new Pen(Theme.Accent, Theme.Sf(1)))
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    using (GraphicsPath p = Theme.Round(new RectangleF(1.5f, 1.5f, Width - 4, Height - 4), Theme.Square ? 0 : Theme.Sf(5))) g.DrawPath(pen, p);
                }
            if (Focused && ShowFocusCues)
                using (var pen = new Pen(Theme.Accent) { DashStyle = DashStyle.Dot })
                    g.DrawRectangle(pen, Theme.S(4), Theme.S(4), Width - 1 - Theme.S(8), Height - 1 - Theme.S(8));

            bool rtl = RightToLeft == RightToLeft.Yes;
            int dot = Theme.S(18), pad = Theme.S(14);
            var circle = new RectangleF(rtl ? Width - pad - dot : pad, (Height - dot) / 2f, dot, dot);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (var b = new SolidBrush(Theme.Surface)) g.FillEllipse(b, circle);
            using (var pen = new Pen(Checked ? Theme.Accent : Theme.Faint, Theme.Sf(1.5f))) g.DrawEllipse(pen, circle);
            if (Checked)
            {
                float d = dot * 0.5f;
                using (var b = new SolidBrush(Theme.Accent)) g.FillEllipse(b, circle.X + (dot - d) / 2, circle.Y + (dot - d) / 2, d, d);
            }
            int textLeft = rtl ? pad : pad + dot + Theme.S(10);
            int textWidth = Width - pad * 2 - dot - Theme.S(10);
            if (preview != null)
            {
                // A tiny window in the look's colors, at the end of the card.
                int pw = Theme.S(34), ph = Theme.S(24);
                var box = new Rectangle(rtl ? pad : Width - pad - pw, (Height - ph) / 2, pw, ph);
                Theme.Box(g, box, Theme.Sf(4), preview.Page, preview.BorderStrong);
                var bar = new Rectangle(box.X + 1, box.Y + 1, box.Width - 2, Theme.S(7));
                using (var b = new SolidBrush(preview.Surface)) g.FillRectangle(b, bar);
                Theme.Box(g, new Rectangle(box.X + Theme.S(5), box.Bottom - Theme.S(10), Theme.S(14), Theme.S(6)), Theme.Sf(3), preview.Accent, Color.Transparent);
                using (var b = new SolidBrush(preview.Muted)) g.FillRectangle(b, box.X + Theme.S(21), box.Bottom - Theme.S(8), Theme.S(8), Math.Max(1, Theme.S(2)));
                textWidth -= pw + Theme.S(10);
                if (rtl) textLeft += pw + Theme.S(10);
            }
            Color fore = Enabled ? Theme.Text : Theme.Faint;
            if (note == null)
                Theme.Line(g, Text, Checked ? Theme.Bold : Theme.Font, new Rectangle(textLeft, 0, textWidth, Height), fore);
            else
            {
                int half = Height / 2;
                Theme.Line(g, Text, Theme.Bold, new Rectangle(textLeft, Theme.S(6), textWidth, half - Theme.S(4)), fore);
                Theme.Line(g, note, Theme.Small, new Rectangle(textLeft, half, textWidth, half - Theme.S(8)), Theme.Muted);
            }
        }
    }

    /// <summary>A thin rounded progress bar.</summary>
    sealed class ProgressLine : Control
    {
        int percent;

        public ProgressLine()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Height = Theme.S(6);
            TabStop = false;
        }

        public int Value
        {
            get { return percent; }
            set { percent = Math.Max(0, Math.Min(100, value)); Invalidate(); }
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.BackOf(Parent));
            float r = Height / 2f;
            Theme.Box(g, ClientRectangle, r, Theme.Border, Color.Transparent);
            int w = (int)(Width * percent / 100f);
            if (w <= 0) return;
            w = Math.Max(w, Height);
            bool rtl = RightToLeft == RightToLeft.Yes;
            Theme.Box(g, new Rectangle(rtl ? Width - w : 0, 0, w, Height), r, Theme.Accent, Color.Transparent);
        }
    }

    /// <summary>Buttons at the end of a dialog: right to left, the first (main) one nearest the reading start.</summary>
    sealed class ButtonRow : Panel
    {
        readonly List<Button> list = new List<Button>();

        public ButtonRow()
        {
            AutoSize = true;
            Padding = Theme.Pad(20, 14);
            BackColor = Theme.Footer;
            Margin = Padding.Empty;
        }

        public T Add<T>(T b) where T : Button
        {
            b.Margin = Padding.Empty;
            list.Add(b);
            Controls.Add(b);
            PerformLayout();
            return b;
        }

        readonly List<Button> apart = new List<Button>();

        /// <summary>3.26 (CHANGE-010): a button kept away from the others, at the start (right), e.g. «حذف حساب».</summary>
        public T AddApart<T>(T b) where T : Button
        {
            b.Margin = Padding.Empty;
            apart.Add(b);
            Controls.Add(b);
            PerformLayout();
            return b;
        }

        int Gap { get { return Theme.S(8); } }

        public override Size GetPreferredSize(Size proposed)
        {
            int w = Padding.Horizontal, h = 0;
            foreach (Button b in list.Concat(apart).Where(x => x.Visible))
            {
                w += b.Width + Gap;
                h = Math.Max(h, b.Height);
            }
            if (apart.Any(x => x.Visible)) w += Theme.S(40);
            return new Size(w, h + Padding.Vertical);
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            // The group sits at the reading end (left for Persian), the main button nearest the start.
            Art.AtEnd(this, list.Cast<Control>().ToList(), Padding.Left, Gap);
            int x = Width - Padding.Right;
            foreach (Button b in apart.Where(v => v.Visible))
            {
                x -= b.Width;
                // 3.27: at the start side: the right in Persian, the left in English.
                b.Location = new Point(Theme.FlipX(x, b.Width, Width), Padding.Top);
                x -= Gap;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using (var pen = new Pen(Theme.Border)) e.Graphics.DrawLine(pen, 0, 0, Width, 0);
        }
    }

    /// <summary>A dialog sized around its content: a heading, label/field rows and a footer with buttons.</summary>
    public enum FieldLook { Normal, Hover, Focus, Off, Bad }

    /// <summary>The program's input box (3.15.1, «قاب نرم») around a standard TextBox, NumericUpDown or ComboBox: the box itself
    /// loses its Windows border and sits inside a rounded frame the program draws (see Theme.Field). Put in place by
    /// Theme.StyleInputs where the box was, so every window gets it without changing its layout code.</summary>
    sealed class InputFrame : Control
    {
        public readonly Control Inner;
        bool hover, invalid;

        /// <summary>Red frame: the value is not accepted.</summary>
        public bool Invalid { get { return invalid; } set { if (invalid == value) return; invalid = value; Invalidate(); } }

        public static bool Wants(Control c)
        {
            if (c.Parent == null || c.Parent is InputFrame) return false;
            var t = c as TextBox;
            if (t != null) return !t.Multiline && t.BorderStyle != BorderStyle.None;
            return c is UpDownBase || (c is ComboBox && ((ComboBox)c).DropDownStyle == ComboBoxStyle.DropDownList);
        }

        public static InputFrame Wrap(Control c)
        {
            Control parent = c.Parent;
            int ring = Theme.FieldRing;
            var table = parent as TableLayoutPanel;
            TableLayoutPanelCellPosition cell = table != null ? table.GetPositionFromControl(c) : new TableLayoutPanelCellPosition();
            int span = table != null ? table.GetColumnSpan(c) : 1;
            int index = parent.Controls.GetChildIndex(c);
            Padding m = c.Margin;
            parent.SuspendLayout();
            parent.Controls.Remove(c);
            var f = new InputFrame(c, new Size(c.Width + 2 * ring, Theme.FieldHeight + 2 * ring))
            {
                Margin = new Padding(Math.Max(0, m.Left - ring), Math.Max(0, m.Top - ring), Math.Max(0, m.Right - ring), Math.Max(0, m.Bottom - ring)),
                Anchor = c.Anchor, Dock = c.Dock, TabIndex = c.TabIndex, RightToLeft = c.RightToLeft,
            };
            c.Margin = Padding.Empty;
            c.Dock = DockStyle.None;
            c.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            if (table != null)
            {
                table.Controls.Add(f, cell.Column, cell.Row);
                if (span > 1) table.SetColumnSpan(f, span);
            }
            else
            {
                parent.Controls.Add(f);
                parent.Controls.SetChildIndex(f, index);
            }
            parent.ResumeLayout();
            CenterRow(parent);
            return f;
        }

        /// <summary>In a row of a field and words ("[ ۵ ] معامله در روز، [ ۲۰ ] در هفته"), the words stand at the boxes' middle.</summary>
        static void CenterRow(Control parent)
        {
            var flow = parent as FlowLayoutPanel;
            if (flow == null || flow.FlowDirection == FlowDirection.TopDown || flow.FlowDirection == FlowDirection.BottomUp) return;
            int tall = 0;
            foreach (Control x in flow.Controls) if (x is InputFrame) tall = Math.Max(tall, x.Height + x.Margin.Vertical);
            foreach (Control x in flow.Controls)
            {
                if (x is InputFrame) continue;
                int h = x.AutoSize ? x.GetPreferredSize(Size.Empty).Height : x.Height;
                if (h >= tall) continue;
                int top = (tall - h) / 2;
                x.Margin = new Padding(x.Margin.Left, top, x.Margin.Right, tall - h - top);
            }
        }

        readonly Size wanted;

        InputFrame(Control inner, Size size)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Inner = inner;
            wanted = size;
            AutoSize = false;
            Size = size;
            TabStop = false;
            var t = inner as TextBox;
            if (t != null) { t.BorderStyle = BorderStyle.None; Cursor = Cursors.IBeam; }
            var u = inner as UpDownBase;
            if (u != null) u.BorderStyle = BorderStyle.None;
            var cb = inner as ComboBox;
            if (cb != null) cb.FlatStyle = FlatStyle.Flat;
            Controls.Add(inner);
            inner.Enter += (s, e) => Invalidate();
            inner.Leave += (s, e) => Invalidate();
            inner.EnabledChanged += (s, e) => { Colors(); Invalidate(); };
            Follow(inner);
            Colors();
        }

        /// <summary>Under the mouse: the frame, the box and the box's own parts (a number box's arrows).</summary>
        void Follow(Control c)
        {
            c.MouseEnter += (s, e) => Hover();
            c.MouseLeave += (s, e) => Hover();
            foreach (Control x in c.Controls) Follow(x);
        }

        void Hover()
        {
            bool now = IsHandleCreated && ClientRectangle.Contains(PointToClient(Cursor.Position));
            if (now == hover) return;
            hover = now;
            Invalidate();
        }

        protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e); Hover(); }
        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); Hover(); }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (Inner.Enabled) Inner.Focus();
        }

        void Colors()
        {
            Inner.BackColor = Inner.Enabled ? Theme.Input : Theme.Hover;
            Inner.ForeColor = Inner.Enabled ? Theme.Text : Theme.Faint;
        }

        FieldLook Look
        {
            get
            {
                if (!Inner.Enabled) return FieldLook.Off;
                if (invalid) return FieldLook.Bad;
                if (Inner.ContainsFocus) return FieldLook.Focus;
                return hover ? FieldLook.Hover : FieldLook.Normal;
            }
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            if (Inner == null || Inner.Parent != this) return;
            int ring = Theme.FieldRing, pad = Inner is TextBox ? Theme.S(10) : Theme.S(4);
            var box = new Rectangle(ring, ring, Width - 2 * ring, Height - 2 * ring);
            int h = Inner.Height;
            Inner.Bounds = new Rectangle(box.X + pad, box.Y + (box.Height - h) / 2, Math.Max(10, box.Width - 2 * pad), h);
            var cb = Inner as ComboBox;
            // A combo box always draws a thin border of its own: it is cut off, the frame stands in its place.
            if (cb != null) cb.Region = new Region(new Rectangle(1, 1, cb.Width - 2, cb.Height - 2));
        }

        /// <summary>The size the box was given: never worked out from the box inside (which the frame itself places).</summary>
        public override Size GetPreferredSize(Size proposedSize) { return wanted; }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Theme.BackOf(Parent == null ? this : Parent));
            Theme.Field(e.Graphics, ClientRectangle, Look);
        }
    }

    class FormDialog : Form
    {
        protected readonly TableLayoutPanel Body;
        protected readonly ButtonRow Buttons = new ButtonRow();
        readonly TableLayoutPanel root;
        readonly List<Control> wide = new List<Control>();
        int minWidth;

        public FormDialog(string title, string subtitle = null, bool heading = true)
        {
            Text = title;
            Font = Theme.Font;
            ForeColor = Theme.Text;
            BackColor = Theme.Surface;
            RightToLeft = Theme.Dir;
            RightToLeftLayout = false;  // the window frame stays as in every Windows program: buttons at the top right
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowIcon = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            Padding = Padding.Empty;
            Theme.Window(this);

            root = new TableLayoutPanel { AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 1, Margin = Padding.Empty, Padding = Padding.Empty, Location = Point.Empty };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            Body = new TableLayoutPanel { AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 2, Margin = Theme.Pad(24, heading ? 6 : 22, 24, 18), Padding = Padding.Empty };
            Body.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            Body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            int row = 0;
            if (heading)
            {
                var top = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false, Margin = Theme.Pad(24, 22, 24, 10) };
                top.Controls.Add(new Label { Text = title, Font = Theme.Heading, ForeColor = Theme.Text, AutoSize = true, Margin = Padding.Empty, UseMnemonic = false });
                if (subtitle != null) top.Controls.Add(Theme.Label(subtitle, 470, Theme.Font, Theme.Muted));
                root.Controls.Add(top, 0, row++);
            }
            root.Controls.Add(Body, 0, row++);
            Buttons.Dock = DockStyle.Fill;
            root.Controls.Add(Buttons, 0, row);
            Controls.Add(root);
        }

        protected void Row(string label, Control field)
        {
            int r = Body.RowCount;
            Body.RowCount = r + 1;
            Body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            if (label.Length > 0)
            {
                Label l = Theme.Label(label);
                l.Margin = Theme.Pad(0, 6, 0, 6);
                l.Anchor = AnchorStyles.Left;
                Body.Controls.Add(l, 0, r);
            }
            field.Margin = Theme.Pad(14, 5, 0, 5);
            Body.Controls.Add(field, 1, r);
        }

        protected void Wide(Control c)
        {
            wide.Add(c);
            int r = Body.RowCount;
            Body.RowCount = r + 1;
            Body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Body.Controls.Add(c, 0, r);
            Body.SetColumnSpan(c, 2);
        }

        protected Button AddButton(string text, EventHandler click, bool primary = false)
        {
            var b = new ModernButton(text, click, primary ? ButtonKind.Primary : ButtonKind.Secondary);
            if (b.Width < Theme.S(96)) b.Width = Theme.S(96);
            return Buttons.Add(b);
        }

        protected void MinWidth(int px) { minWidth = Theme.S(px); }

        /// <summary>Call once, after the rows and buttons are added.</summary>
        protected void Finish()
        {
            // Rows that span both columns do not widen auto-sized columns by themselves: size the table for them.
            int width = minWidth;
            foreach (Control c in wide)
            {
                int w = c is TextBoxBase ? c.Width : Math.Max(c.Width, c.GetPreferredSize(Size.Empty).Width);
                width = Math.Max(width, w + c.Margin.Horizontal);
            }
            Body.MinimumSize = new Size(width, 0);
            Theme.StyleInputs(this);
        }

        protected void Close(DialogResult result)
        {
            DialogResult = result;
        }
    }

    /// <summary>The program's own message window, in the same style as the rest.</summary>
    sealed class MessageDialog : FormDialog
    {
        public MessageDialog(string text, MessageBoxIcon icon, MessageBoxButtons buttons) : base(Ui.Title, null, false)
        {
            Glyph g;
            switch (icon)
            {
                case MessageBoxIcon.Warning: g = Glyph.Warning; break;
                case MessageBoxIcon.Error: g = Glyph.Error; break;
                case MessageBoxIcon.Question: g = Glyph.Question; break;
                case MessageBoxIcon.None: g = Glyph.None; break;
                default: g = Glyph.Info; break;
            }
            var mark = new GlyphBox(g, 40) { Margin = Theme.Pad(0, 2, 0, 0), Anchor = AnchorStyles.Top | AnchorStyles.Left };
            Label body = Theme.Label(text, 420, Theme.Font, Theme.Text);
            body.Margin = Theme.Pad(16, 10, 0, 6);
            int r = Body.RowCount;
            Body.RowCount = r + 1;
            Body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Body.Controls.Add(mark, 0, r);
            Body.Controls.Add(body, 1, r);
            if (buttons == MessageBoxButtons.YesNo)
            {
                Button yes = AddButton(Lang.T("بله", "Yes"), null, true);
                yes.DialogResult = DialogResult.Yes;
                Button no = AddButton(Lang.T("خیر", "No"), null);
                no.DialogResult = DialogResult.No;
                AcceptButton = yes;
                CancelButton = no;
            }
            else
            {
                Button ok = AddButton(Lang.T("باشه", "OK"), null, true);
                ok.DialogResult = DialogResult.OK;
                AcceptButton = ok;
                CancelButton = ok;
            }
            MinWidth(300);
            Finish();
        }
    }

    /// <summary>One status icon or the logo, drawn at a size.</summary>
    sealed class GlyphBox : Control
    {
        public Glyph Glyph;
        public Color Color = Theme.Accent;

        public GlyphBox(Glyph glyph, int size)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Glyph = glyph;
            Size = new Size(Theme.S(size), Theme.S(size));
            TabStop = false;
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Theme.BackOf(Parent));
            if (Glyph != Glyph.None) Glyphs.Draw(e.Graphics, Glyph, new RectangleF(0, 0, Width - 1, Height - 1), Color);
        }
    }

    static class Ui
    {
        public const string Title = "MetaFactory";

        public static DialogResult Message(IWin32Window owner, string text, MessageBoxIcon icon = MessageBoxIcon.Information, MessageBoxButtons buttons = MessageBoxButtons.OK)
        {
            try
            {
                using (var d = new MessageDialog(text, icon, buttons))
                {
                    if (owner == null)
                    {
                        d.StartPosition = FormStartPosition.CenterScreen;
                        d.ShowInTaskbar = true;
                    }
                    return d.ShowDialog(owner);
                }
            }
            catch (Exception e)
            {
                // Never lose a message because of the window drawing it.
                try { Log.Write("message window: " + e.Message); } catch { }
                return MessageBox.Show(owner, text, Title, buttons, icon, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading | MessageBoxOptions.RightAlign);
            }
        }

        public static bool Confirm(IWin32Window owner, string text)
        {
            return Message(owner, text, MessageBoxIcon.Question, MessageBoxButtons.YesNo) == DialogResult.Yes;
        }

        /// <summary>Plain message for expected problems; the error text and where the details are for anything else.</summary>
        public static void Error(IWin32Window owner, Exception e)
        {
            if (e is UserMessage)
            {
                Message(owner, e.Message, MessageBoxIcon.Warning);
                return;
            }
            Log.Write("error: " + e);
            Message(owner, Lang.T("خطایی پیش آمد:\n", "Something went wrong:\n") + e.Message + Lang.T("\n\nجزئیات در فایل گزارش ثبت شد. اگر تکرار شد، از «ابزارها > بررسی سیستم» متن را کپی کنید و بفرستید.", "\n\nThe details are in the log file. If it happens again, copy the text from “Tools > System check” and send it."), MessageBoxIcon.Error);
        }

        public static bool IsAdmin()
        {
            try { return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator); }
            catch { return false; }
        }

        public static void OpenUrl(string url)
        {
            try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); } catch (Exception e) { Log.Write("open " + url + ": " + e.Message); }
        }
    }
    static class Art
    {
        /// <summary>The program icon at every size Windows asks for (title bar, taskbar, Alt+Tab).</summary>
        public static Icon AppIcon()
        {
            try
            {
                using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("app.ico"))
                    if (s != null) return new Icon(s);
            }
            catch { }
            try { return Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { return null; }
        }

        public static LinkLabel Link(string text)
        {
            return new LinkLabel
            {
                Text = text, AutoSize = true, LinkColor = Theme.AccentText, ActiveLinkColor = Theme.AccentHover, VisitedLinkColor = Theme.AccentText,
                LinkBehavior = LinkBehavior.HoverUnderline, RightToLeft = Theme.Dir, UseMnemonic = false,
            };
        }

        /// <summary>Puts controls side by side at the reading end of a container (left for Persian), the first nearest the start.</summary>
        public static void AtEnd(Control parent, IList<Control> items, int edge, int gap, int top = -1)
        {
            bool rtl = parent.RightToLeft == RightToLeft.Yes;
            int x = rtl ? edge : parent.ClientSize.Width - edge;
            for (int k = items.Count - 1; k >= 0; k--)
            {
                Control c = items[k];
                if (!c.Visible) continue;
                int y = top >= 0 ? top : (parent.ClientSize.Height - c.Height) / 2;
                if (rtl)
                {
                    c.Location = new Point(x, y);
                    x += c.Width + gap;
                }
                else
                {
                    x -= c.Width;
                    c.Location = new Point(x, y);
                    x -= gap;
                }
            }
        }
    }

#if SNAPSHOT
    /// <summary>Build check on Linux only: captures a window from the virtual screen.</summary>
    static class Shots
    {
        public static void Draw(Form f, string path, bool hide = true)
        {
            if (!f.Visible) f.Show();
            for (int k = 0; k < 20; k++) { Application.DoEvents(); System.Threading.Thread.Sleep(50); }
            Rectangle b = f.Bounds;
            var p = Process.Start(new ProcessStartInfo("import", "-window root -crop " + b.Width + "x" + b.Height + "+" + Math.Max(0, b.X) + "+" + Math.Max(0, b.Y) + " \"" + path + "\"") { UseShellExecute = false });
            p.WaitForExit();
            Console.WriteLine(Path.GetFileName(path) + " " + b);
            if (hide) f.Hide();
        }
    }
#endif
}
