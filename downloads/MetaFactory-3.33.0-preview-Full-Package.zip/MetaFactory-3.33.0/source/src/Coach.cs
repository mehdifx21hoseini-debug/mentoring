using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace MTManager
{
    // ================================================================== a coach's numbers for one account (3.18)

    /// <summary>One slice of an account's trades (a symbol, a weekday, a session): how many, how many won, and what they made.</summary>
    public sealed class SliceStat
    {
        public string Key = "", Name = "";
        public int Trades, Wins;
        public double Net, GrossProfit, GrossLoss;
        public double WinRate { get { return Trades > 0 ? Wins * 100.0 / Trades : double.NaN; } }
        /// <summary>Gross profit ÷ gross loss; +∞ with profit and no loss; NaN with neither.</summary>
        public double ProfitFactor { get { return Coach.Factor(GrossProfit, GrossLoss); } }
    }

    /// <summary>A day of the balance curve: the trades closed that day and the balance after them (money paid in or out left out).</summary>
    public sealed class CurvePoint
    {
        public DateTime Day;
        public double Net, Balance;
        public int Trades;
    }

    public enum FlagLevel { Warn, Bad }

    /// <summary>Why an account needs the coach's attention: a key for the page's filters, words, and how serious.</summary>
    public sealed class CoachFlag
    {
        public string Key = "", Text = "";
        public FlagLevel Level;
    }

    /// <summary>What a coach looks at in one account over a report's range: results, risk, discipline and style; a score out of
    /// 100 with its grade; the reasons it needs attention; and a few notes in words. All from the history the script read.</summary>
    public sealed class CoachStats
    {
        // results
        public int Trades, Wins, Losses;
        public double Net, GrossProfit, GrossLoss, ProfitFactor = double.NaN, Expectancy = double.NaN, ExpectancyR = double.NaN;
        public int RTrades;
        /// <summary>3.19, the parts of the expectancy: Expectancy = WinRate × AvgWin − LossRate × AvgLoss (rates in percent of the
        /// trades closed, averages as positive money); the win rate at which this AvgWin and AvgLoss would break even.</summary>
        public double WinRate = double.NaN, LossRate = double.NaN, AvgWin, AvgLoss, BreakEvenWinRate = double.NaN;
        public double LargestWin, LargestLoss, BestDay, WorstDay;
        public DateTime BestDayDate, WorstDayDate;
        // risk
        /// <summary>The money at stake at each trade's Stop Loss, in percent of the balance when it opened (trades with a Stop Loss
        /// on the losing side and a price that moved); NaN when no trade had one.</summary>
        public double AvgRiskPct = double.NaN, MaxRiskPct = double.NaN;
        public int RiskTrades;
        public JournalTrade MaxRiskTrade;
        /// <summary>Each closed trade's risk in percent, by ticket (for the tickets' table).</summary>
        public readonly Dictionary<long, double> RiskByTicket = new Dictionary<long, double>();
        /// <summary>MT4 keeps only the last Stop Loss: risk and R are worked out from it, so approximately.</summary>
        public bool RiskApprox;
        /// <summary>The largest fall of the balance from a high (3.20: the real balance, money paid in or out moving the balance and
        /// its high together, so it is neither a gain nor a fall), in money and in percent of the high.</summary>
        public double MaxDd, MaxDdPct;
        public DateTime DdPeak, DdLow;
        /// <summary>3.20, the largest fall of the equity: the balance plus the worst floating result of the positions open in each
        /// minute (from the minute bars the script read, so an estimate), below the balance's high. Known only where there were
        /// minute bars (EquityFrom on); never below the balance's own fall.</summary>
        public bool EquityKnown;
        public double EqDd, EqDdPct;
        public DateTime EqDdAt, EquityFrom;
        /// <summary>3.20: the trades that had no Stop Loss at all (closed without one, or still open without one): how many, how long
        /// they were in the market without one together and the longest; MT4 tells only the last Stop Loss (approximate). Trades with
        /// a Stop Loss put on after the entry: how many, and at most how long (their whole time: when it was put on is not kept).</summary>
        public int NoSlTrades, NoSlOpen, LateSlTrades;
        public TimeSpan NoSlTime, NoSlLongest, LateSlUpTo;
        public bool NoSlApprox;
        public double RecoveryFactor = double.NaN;
        public double MaxVolume, MedianVolume, AvgVolume, VolumeRatio = double.NaN;
        // discipline
        public int Opened, WithStop;
        public double StopPct = double.NaN;
        /// <summary>Trades opened within RevengeMinutes of a losing trade's close with the same risk as it or more (see Coach.Size);
        /// a reversal (the same symbol, the other way) only with clearly more.</summary>
        public int Revenge;
        public readonly List<JournalTrade> RevengeTrades = new List<JournalTrade>();
        /// <summary>3.19.1: reversals within RevengeMinutes of a loss without more risk: part of a plan, not revenge; shown apart.</summary>
        public readonly List<JournalTrade> Reversals = new List<JournalTrade>();
        /// <summary>3.20: why a trade carries a tag (revenge, reversal, martingale), in English, by ticket; shown with the trade.</summary>
        public readonly Dictionary<long, string> Why = new Dictionary<long, string>();
        /// <summary>3.19, hidden martingale: runs where the volume went up after a loss, and up again after that one lost too (two
        /// steps or more). The runs, the most steps in one, the largest volume reached ÷ the run's first, and the trades of the steps.</summary>
        public int MartingaleChains, MartingaleSteps;
        public double MartingaleFactor = double.NaN;
        /// <summary>3.19.1: whether the largest chain's steps were all measured by risk (otherwise, somewhere, by lots: no Stop Loss).</summary>
        public bool MartingaleByRisk;
        public readonly List<JournalTrade> MartingaleTrades = new List<JournalTrade>();
        public int MaxLossStreak, MaxWinStreak;
        public double LossStreakMoney, WinStreakMoney;
        // style
        public TimeSpan HoldWin, HoldLoss;
        public double HoldRatio = double.NaN;
        /// <summary>3.19: losses held more than Coach.LossAversionRatio times as long as wins (with enough trades): profits taken
        /// early, losses left open in hope.</summary>
        public bool LossAversion;
        public int Buys, Sells, BuyWins, SellWins;
        public double BuyNet, SellNet;
        public int TradingDays;
        public double TradesPerDay = double.NaN;
        // slices and the curve
        public readonly List<SliceStat> BySymbol = new List<SliceStat>(), ByWeekday = new List<SliceStat>(), BySession = new List<SliceStat>();
        public readonly List<CurvePoint> Curve = new List<CurvePoint>();
        public double CurveStart;
        public bool CashInRange;
        // what needs attention
        public readonly List<CoachFlag> Flags = new List<CoachFlag>();
        public readonly List<string> Strengths = new List<string>(), Work = new List<string>(), Next = new List<string>();

        public bool NeedsAttention { get { return Flags.Count > 0; } }
        /// <summary>3.19: how many of the three behaviour alerts this account has (revenge, martingale, loss aversion).</summary>
        public int PsychAlerts { get { return (Revenge > 0 ? 1 : 0) + (MartingaleChains > 0 ? 1 : 0) + (LossAversion ? 1 : 0); } }
        public bool Has(string key) { return Flags.Any(f => f.Key == key); }
    }

    public static class Coach
    {
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
        /// <summary>3.19: back in within this many minutes of a losing close, with the same volume or more, is revenge.</summary>
        public const int RevengeMinutes = 10;
        /// <summary>3.19: losses held more than this many times as long as wins, on average, is loss aversion.</summary>
        public const double LossAversionRatio = 3;
        /// <summary>3.19.1: two risks within this share of each other are "the same" (lots come in steps, Stop Losses in points).</summary>
        public const double RiskTolerance = 0.1;

        /// <summary>3.19.1: how much more a trade put at stake than an earlier one, as a ratio, so a larger lot with a closer Stop Loss
        /// and the same risk (a fixed 1% a trade) is not taken for more. With a Stop Loss on both: on the same symbol, lots × the
        /// distance to it (the money at stake, in proportion); across symbols, the money at stake worked out from each result (when both
        /// can be). Otherwise the lots. NaN when neither can be compared.</summary>
        public static double Size(JournalTrade later, JournalTrade earlier, out bool byRisk)
        {
            byRisk = false;
            bool a1, a2;
            double s1 = RiskStop(later, out a1), s2 = RiskStop(earlier, out a2);
            if (s1 > 0 && s2 > 0)
            {
                if (string.Equals(later.Symbol, earlier.Symbol, StringComparison.OrdinalIgnoreCase))
                {
                    double r1 = later.Volume * Math.Abs(later.OpenPrice - s1), r2 = earlier.Volume * Math.Abs(earlier.OpenPrice - s2);
                    if (r1 > 0 && r2 > 0) { byRisk = true; return r1 / r2; }
                }
                double m1 = RiskMoney(later), m2 = RiskMoney(earlier);
                if (m1 > 0 && m2 > 0) { byRisk = true; return m1 / m2; }
            }
            return later.Volume > 0 && earlier.Volume > 0 ? later.Volume / earlier.Volume : double.NaN;
        }

        /// <summary>At least as much at stake (by risk, within RiskTolerance; by lots, exactly).</summary>
        public static bool AsMuch(double ratio, bool byRisk) { return !double.IsNaN(ratio) && ratio >= (byRisk ? 1 - RiskTolerance : 1 - 1e-9); }

        /// <summary>Clearly more at stake (by risk, beyond RiskTolerance; by lots, any larger lot).</summary>
        public static bool More(double ratio, bool byRisk) { return !double.IsNaN(ratio) && ratio > (byRisk ? 1 + RiskTolerance : 1 + 1e-9); }

        /// <summary>The same symbol the other way: the reverse of a trade, as some plans take after a loss.</summary>
        public static bool Reverses(JournalTrade later, JournalTrade earlier)
        {
            return later.Buy != earlier.Buy && string.Equals(later.Symbol, earlier.Symbol, StringComparison.OrdinalIgnoreCase);
        }
        /// <summary>Above these an account is flagged: risk per trade on average, the balance's largest fall, losses in a row.</summary>
        public const double RiskFlagPct = 2, DdFlagPct = 10;
        public const int StreakFlag = 5, FewTradesBelow = 5;

        public static double Factor(double gross, double loss)
        {
            if (loss > 0) return gross / loss;
            return gross > 0 ? double.PositiveInfinity : double.NaN;
        }

        static double R2(double v) { return Math.Round(v, 2, MidpointRounding.AwayFromZero); }

        /// <summary>A trade's Stop Loss on its losing side, as the risk is measured from: the one at the entry (MT5), otherwise the
        /// last one (MT4); 0 when there is none to measure from.</summary>
        public static double RiskStop(JournalTrade t, out bool approx)
        {
            approx = t.SlEntry < 0;
            double sl = t.SlEntry >= 0 ? t.SlEntry : t.SlFinal;
            if (sl <= 0 || t.OpenPrice <= 0) return 0;
            bool lossSide = t.Buy ? sl < t.OpenPrice : sl > t.OpenPrice;
            return lossSide ? sl : 0;
        }

        /// <summary>The result in R: the price's move in the trade's favour ÷ the distance to its Stop Loss. NaN without one.</summary>
        public static double RMultiple(JournalTrade t)
        {
            bool approx;
            double sl = RiskStop(t, out approx);
            if (sl <= 0) return double.NaN;
            double dist = Math.Abs(t.OpenPrice - sl);
            if (dist <= 0) return double.NaN;
            return (t.Buy ? t.ClosePrice - t.OpenPrice : t.OpenPrice - t.ClosePrice) / dist;
        }

        /// <summary>The money at stake at the Stop Loss, from the trade's own result: profit × (distance to the Stop Loss ÷ the price's
        /// move). NaN without a Stop Loss or when the price did not move.</summary>
        public static double RiskMoney(JournalTrade t)
        {
            bool approx;
            double sl = RiskStop(t, out approx);
            if (sl <= 0) return double.NaN;
            double move = Math.Abs(t.ClosePrice - t.OpenPrice);
            if (move <= t.OpenPrice * 1e-9 || Math.Abs(t.Profit) < 0.005) return double.NaN;
            return Math.Abs(t.Profit) * Math.Abs(t.OpenPrice - sl) / move;
        }

        static bool InRange(DateTime t, DateTime from, DateTime to) { return t >= from && t < to; }

        static int Outcome(double net)
        {
            double v = R2(net);
            return v > 0 ? 1 : v < 0 ? -1 : 0;
        }

        /// <summary>The numbers of one account over [from, to), next to its JournalSummary for the same range.</summary>
        public static CoachStats Analyze(AccountJournal j, JournalSummary s, DateTime from, DateTime to)
        {
            var c = new CoachStats();
            if (j == null || s == null) return c;
            DateTime end = to > j.Exported && j.Exported > DateTime.MinValue ? j.Exported.AddSeconds(1) : to;
            List<JournalTrade> closed = j.Trades.Where(t => InRange(t.Close, from, end)).OrderBy(t => t.Close).ThenBy(t => t.Ticket).ToList();
            c.Trades = closed.Count;
            foreach (JournalTrade t in closed)
            {
                double n = t.Net;
                c.Net += n;
                int o = Outcome(n);
                if (o > 0) { c.Wins++; c.GrossProfit += R2(n); }
                else if (o < 0) { c.Losses++; c.GrossLoss -= R2(n); }
            }
            c.ProfitFactor = Factor(c.GrossProfit, c.GrossLoss);
            if (c.Trades > 0)
            {
                c.WinRate = c.Wins * 100.0 / c.Trades;
                c.LossRate = c.Losses * 100.0 / c.Trades;
                c.AvgWin = c.Wins > 0 ? c.GrossProfit / c.Wins : 0;
                c.AvgLoss = c.Losses > 0 ? c.GrossLoss / c.Losses : 0;
                c.Expectancy = c.WinRate / 100 * c.AvgWin - c.LossRate / 100 * c.AvgLoss;
                if (c.Wins > 0 && c.Losses > 0) c.BreakEvenWinRate = c.AvgLoss / (c.AvgWin + c.AvgLoss) * 100;
                c.LargestWin = Math.Max(0, closed.Max(t => t.Net));
                c.LargestLoss = Math.Min(0, closed.Min(t => t.Net));
            }
            List<double> rs = closed.Select(RMultiple).Where(r => !double.IsNaN(r)).ToList();
            c.RTrades = rs.Count;
            if (rs.Count > 0) c.ExpectancyR = rs.Average();

            Risk(j, s, closed, from, c);
            Curve(j, s, closed, from, end, c);
            Equity(j, s, closed, from, end, c);
            WithoutStops(j, from, end, c);
            Volumes(closed, c);
            Discipline(j, s, closed, from, end, c);
            Martingale(j, from, end, c);
            Style(j, closed, from, end, c);
            Slices(j, closed, c);
            Judge(s, c);
            Notes(s, c);
            return c;
        }

        static void Risk(AccountJournal j, JournalSummary s, List<JournalTrade> closed, DateTime from, CoachStats c)
        {
            var pcts = new List<double>();
            foreach (JournalTrade t in closed)
            {
                double money = RiskMoney(t);
                if (double.IsNaN(money)) continue;
                bool approx;
                RiskStop(t, out approx);
                if (approx) c.RiskApprox = true;
                double balance = s.StartBalance;
                if (t.Open > from)
                    balance += j.Trades.Where(x => x.Close >= from && x.Close < t.Open).Sum(x => x.Net) + j.Cash.Where(x => x.Time >= from && x.Time < t.Open).Sum(x => x.Amount);
                if (balance <= 0) continue;
                double pct = money / balance * 100;
                pcts.Add(pct);
                c.RiskByTicket[t.Ticket] = pct;
                if (double.IsNaN(c.MaxRiskPct) || pct > c.MaxRiskPct) { c.MaxRiskPct = pct; c.MaxRiskTrade = t; }
            }
            c.RiskTrades = pcts.Count;
            if (pcts.Count > 0) c.AvgRiskPct = pcts.Average();
        }

        /// <summary>A change of the balance: a trade's close (its net) or money paid in or out.</summary>
        sealed class Move
        {
            public DateTime At;
            public double Amount;
            public bool Cash;
        }

        static List<Move> Moves(AccountJournal j, List<JournalTrade> closed, DateTime from, DateTime end)
        {
            return j.Cash.Where(x => InRange(x.Time, from, end)).Select(x => new Move { At = x.Time, Amount = x.Amount, Cash = true })
                .Concat(closed.Select(t => new Move { At = t.Close, Amount = t.Net }))
                .OrderBy(m => m.At).ThenBy(m => m.Cash ? 0 : 1).ToList();
        }

        /// <summary>The balance and its high, as money comes and goes: a trade moves the balance (and the high when above it); money
        /// paid in or out moves both, so a deposit is no gain and a withdrawal no fall.</summary>
        sealed class Peak
        {
            public double Balance, High;
            public DateTime HighAt;
            public void Apply(Move m)
            {
                Balance += m.Amount;
                if (m.Cash) { High += m.Amount; if (High < Balance) High = Balance; return; }
                if (Balance > High) { High = Balance; HighAt = m.At; }
            }
        }

        /// <summary>The balance through the range, day by day, and its largest fall from a high (3.20: with the money paid in or out,
        /// which before left a deposit inside the range out and measured the fall against the profits alone).</summary>
        static void Curve(AccountJournal j, JournalSummary s, List<JournalTrade> closed, DateTime from, DateTime end, CoachStats c)
        {
            c.CurveStart = s.StartBalance;
            List<Move> moves = Moves(j, closed, from, end);
            c.CashInRange = moves.Any(m => m.Cash);
            var p = new Peak { Balance = s.StartBalance, High = s.StartBalance, HighAt = from };
            foreach (Move m in moves)
            {
                p.Apply(m);
                if (m.Cash) continue;
                double dd = p.High - p.Balance;
                if (dd > c.MaxDd + 1e-9)
                {
                    c.MaxDd = dd;
                    c.MaxDdPct = p.High > 0 ? dd / p.High * 100 : 0;
                    c.DdPeak = p.HighAt; c.DdLow = m.At;
                }
            }
            if (c.MaxDd > 0) c.RecoveryFactor = c.Net / c.MaxDd;
            // The balance at the end of each day with a close or a payment; the day's result is its trades only.
            double run = s.StartBalance;
            foreach (IGrouping<DateTime, Move> day in moves.GroupBy(m => m.At.Date).OrderBy(g => g.Key))
            {
                run += day.Sum(m => m.Amount);
                List<Move> trades = day.Where(m => !m.Cash).ToList();
                c.Curve.Add(new CurvePoint { Day = day.Key, Net = trades.Sum(m => m.Amount), Balance = run, Trades = trades.Count });
            }
            if (c.Curve.Count > 0)
            {
                CurvePoint best = c.Curve.OrderByDescending(x => x.Net).First(), worst = c.Curve.OrderBy(x => x.Net).First();
                if (best.Net > 0) { c.BestDay = best.Net; c.BestDayDate = best.Day; }
                if (worst.Net < 0) { c.WorstDay = worst.Net; c.WorstDayDate = worst.Day; }
            }
        }

        /// <summary>3.20: the largest fall of the equity. For each minute with positions open: the balance (the closes and payments
        /// before that minute) plus their worst floating result in it, below the balance's high so far. The closes count too, so it
        /// is never smaller than the balance's own fall.</summary>
        static void Equity(AccountJournal j, JournalSummary s, List<JournalTrade> closed, DateTime from, DateTime end, CoachStats c)
        {
            List<KeyValuePair<DateTime, double>> minutes = j.Floating.Where(f => f.Key >= from && f.Key < end).ToList();
            if (minutes.Count == 0) return;
            c.EquityKnown = true;
            c.EquityFrom = minutes[0].Key;
            List<Move> moves = Moves(j, closed, from, end);
            var p = new Peak { Balance = s.StartBalance, High = s.StartBalance, HighAt = from };
            Action<double, DateTime> low = (equity, at) =>
            {
                double dd = p.High - equity;
                if (dd > c.EqDd + 1e-9) { c.EqDd = dd; c.EqDdPct = p.High > 0 ? dd / p.High * 100 : 0; c.EqDdAt = at; }
            };
            int k = 0;
            foreach (KeyValuePair<DateTime, double> f in minutes)
            {
                while (k < moves.Count && moves[k].At < f.Key) { p.Apply(moves[k]); if (!moves[k].Cash) low(p.Balance, moves[k].At); k++; }
                low(p.Balance + f.Value, f.Key);
            }
            for (; k < moves.Count; k++) { p.Apply(moves[k]); if (!moves[k].Cash) low(p.Balance, moves[k].At); }
            if (c.MaxDd > c.EqDd) { c.EqDd = c.MaxDd; c.EqDdPct = c.MaxDdPct; c.EqDdAt = c.DdLow; }
        }

        /// <summary>3.20: how long trades were in the market without a Stop Loss.</summary>
        static void WithoutStops(AccountJournal j, DateTime from, DateTime end, CoachStats c)
        {
            DateTime now = j.Exported > DateTime.MinValue ? j.Exported : end;
            foreach (JournalTrade t in Entries(j, from, end))
            {
                bool open = t.Close == DateTime.MaxValue;
                TimeSpan held = (open ? now : t.Close) - t.Open;
                if (held < TimeSpan.Zero) held = TimeSpan.Zero;
                StopKind kind = Stops.Of(t.SlEntry, t.SlFinal);
                if (kind == StopKind.Unprotected)
                {
                    c.NoSlTrades++;
                    if (open) c.NoSlOpen++;
                    c.NoSlTime += held;
                    if (held > c.NoSlLongest) c.NoSlLongest = held;
                    if (t.SlEntry < 0) c.NoSlApprox = true;
                }
                else if (kind == StopKind.Delayed)
                {
                    c.LateSlTrades++;
                    if (held > c.LateSlUpTo) c.LateSlUpTo = held;
                }
            }
        }

        /// <summary>A length of time in English short form: "2:25", "1d 3:20".</summary>
        public static string Span(TimeSpan t)
        {
            if (t < TimeSpan.Zero) t = TimeSpan.Zero;
            string hm = ((int)t.TotalHours % 24).ToString(Inv) + ":" + t.Minutes.ToString("00", Inv);
            return t.TotalDays >= 1 ? ((int)t.TotalDays).ToString(Inv) + "d " + hm : ((int)t.TotalHours).ToString(Inv) + ":" + t.Minutes.ToString("00", Inv);
        }

        static void Volumes(List<JournalTrade> closed, CoachStats c)
        {
            if (closed.Count == 0) return;
            List<double> v = closed.Select(t => t.Volume).OrderBy(x => x).ToList();
            c.MaxVolume = v[v.Count - 1];
            c.AvgVolume = v.Average();
            c.MedianVolume = v.Count % 2 == 1 ? v[v.Count / 2] : (v[v.Count / 2 - 1] + v[v.Count / 2]) / 2;
            if (c.MedianVolume > 0) c.VolumeRatio = c.MaxVolume / c.MedianVolume;
        }

        static void Discipline(AccountJournal j, JournalSummary s, List<JournalTrade> closed, DateTime from, DateTime end, CoachStats c)
        {
            c.Opened = s.Opened;
            c.WithStop = Math.Max(0, s.Opened - s.NoStop);
            if (s.Opened > 0) c.StopPct = c.WithStop * 100.0 / s.Opened;

            // In a row, in the order they closed; a trade at exactly zero ends a run.
            int run = 0; double money = 0;
            foreach (JournalTrade t in closed)
            {
                int o = Outcome(t.Net);
                if (o == 0) { run = 0; money = 0; continue; }
                if (run != 0 && Math.Sign(run) != o) { run = 0; money = 0; }
                run += o; money += t.Net;
                if (run > c.MaxWinStreak) { c.MaxWinStreak = run; c.WinStreakMoney = money; }
                if (-run > c.MaxLossStreak) { c.MaxLossStreak = -run; c.LossStreakMoney = money; }
            }

            // Revenge: soon after a loss, back in with as much at stake or more. The reverse of the loss is a plan's, unless it
            // puts clearly more at stake.
            List<JournalTrade> losses = j.Trades.Where(t => Outcome(t.Net) < 0).OrderBy(t => t.Close).ToList();
            foreach (JournalTrade e in Entries(j, from, end))
            {
                // The last loss closed before this entry (never the entry itself).
                JournalTrade last = losses.LastOrDefault(l => l.Close <= e.Open && !ReferenceEquals(l, e));
                if (last == null) continue;
                if ((e.Open - last.Close).TotalMinutes > RevengeMinutes) continue;
                bool byRisk;
                double ratio = Size(e, last, out byRisk);
                string after = Math.Max(0, (int)Math.Round((e.Open - last.Close).TotalMinutes)).ToString(Inv) + " min after a loss at " + last.Close.ToString("HH:mm", Inv);
                string size = double.IsNaN(ratio) ? "" : ", " + ratio.ToString("0.0", Inv) + "× the " + (byRisk ? "risk" : "lots");
                if (Reverses(e, last))
                {
                    if (More(ratio, byRisk)) { c.Revenge++; c.RevengeTrades.Add(e); AddWhy(c, e.Ticket, "Revenge (a reversal with more at stake): " + after + size); }
                    else { c.Reversals.Add(e); AddWhy(c, e.Ticket, "Reversal of the " + last.Close.ToString("HH:mm", Inv) + " loss" + size); }
                }
                else if (AsMuch(ratio, byRisk)) { c.Revenge++; c.RevengeTrades.Add(e); AddWhy(c, e.Ticket, "Revenge: " + after + size); }
            }
        }

        static void AddWhy(CoachStats c, long ticket, string text)
        {
            string had;
            c.Why[ticket] = c.Why.TryGetValue(ticket, out had) ? had + " · " + text : text;
        }

        /// <summary>Every trade opened in [from, end): closed ones and the positions still open (as trades without a close), by open time.</summary>
        static List<JournalTrade> Entries(AccountJournal j, DateTime from, DateTime end)
        {
            return j.Trades.Where(t => InRange(t.Open, from, end))
                .Concat(j.Open.Where(o => InRange(o.Open, from, end)).Select(o => new JournalTrade
                {
                    Ticket = o.Ticket, Symbol = o.Symbol, Buy = o.Buy, Volume = o.Volume, Open = o.Open, OpenPrice = o.OpenPrice, SlEntry = o.SlEntry, SlFinal = o.Sl, Close = DateTime.MaxValue,
                }))
                .OrderBy(t => t.Open).ThenBy(t => t.Ticket).ToList();
        }

        /// <summary>Hidden martingale (3.19). Each trade is linked to the last trade closed before it opened; the link is a step up
        /// when that trade lost and this one puts clearly more at stake (by risk, see Size; a reversal too). Steps follow each other
        /// while the trade stepped up to lost too, so 0.10 (loss) → 0.20 (loss) → 0.40 at the same Stop Loss distance is two steps;
        /// two steps or more, ending in the range, make a chain. 0.10 → 0.20 → 0.40 with the Stop Loss half as far each time is the
        /// same risk: no step.</summary>
        static void Martingale(AccountJournal j, DateTime from, DateTime end, CoachStats c)
        {
            List<JournalTrade> byClose = j.Trades.OrderBy(t => t.Close).ThenBy(t => t.Ticket).ToList();
            List<JournalTrade> all = j.Trades.Where(t => t.Open < end)
                .Concat(Entries(j, from, end).Where(t => t.Close == DateTime.MaxValue))
                .OrderBy(t => t.Open).ThenBy(t => t.Ticket).ToList();
            var steps = new Dictionary<JournalTrade, int>();
            var back = new Dictionary<JournalTrade, JournalTrade>();
            // How much more at stake than the run's first trade, and whether every step was measured by risk.
            var grown = new Dictionary<JournalTrade, double>();
            var risky = new Dictionary<JournalTrade, bool>();
            int p = 0;
            foreach (JournalTrade t in all)
            {
                while (p < byClose.Count && byClose[p].Close <= t.Open) p++;
                int q = p - 1;
                while (q >= 0 && ReferenceEquals(byClose[q], t)) q--;
                JournalTrade before = q >= 0 ? byClose[q] : null;
                int n = 0;
                bool byRisk = false;
                double ratio = before != null && Outcome(before.Net) < 0 ? Size(t, before, out byRisk) : double.NaN;
                if (More(ratio, byRisk))
                {
                    int was;
                    bool onStep = steps.TryGetValue(before, out was) && was > 0;
                    n = (onStep ? was : 0) + 1;
                    back[t] = before;
                    grown[t] = (onStep ? grown[before] : 1) * ratio;
                    risky[t] = byRisk && (!onStep || risky[before]);
                }
                steps[t] = n;
            }
            var roots = new Dictionary<JournalTrade, double>();
            var rootRisk = new Dictionary<JournalTrade, bool>();
            var seen = new HashSet<JournalTrade>();
            foreach (JournalTrade t in all)
            {
                if (steps[t] < 2 || !InRange(t.Open, from, end)) continue;
                JournalTrade x = t;
                while (steps.ContainsKey(x) && steps[x] > 0)
                {
                    if (seen.Add(x) && InRange(x.Open, from, end))
                    {
                        c.MartingaleTrades.Add(x);
                        bool r;
                        double step = Size(x, back[x], out r);
                        AddWhy(c, x.Ticket, "Martingale step " + steps[x].ToString(Inv) + ": " + step.ToString("0.0", Inv) + "× the " + (r ? "risk" : "lots") + " after a loss");
                    }
                    x = back[x];
                }
                double factor = grown[t], had;
                if (!roots.TryGetValue(x, out had) || factor > had) { roots[x] = factor; rootRisk[x] = risky[t]; }
                c.MartingaleSteps = Math.Max(c.MartingaleSteps, steps[t]);
            }
            c.MartingaleChains = roots.Count;
            if (roots.Count > 0)
            {
                JournalTrade top = roots.OrderByDescending(r => r.Value).First().Key;
                c.MartingaleFactor = roots[top];
                c.MartingaleByRisk = rootRisk[top];
            }
            c.MartingaleTrades.Sort((a, b) => a.Open != b.Open ? a.Open.CompareTo(b.Open) : a.Ticket.CompareTo(b.Ticket));
        }

        static void Style(AccountJournal j, List<JournalTrade> closed, DateTime from, DateTime end, CoachStats c)
        {
            List<JournalTrade> wins = closed.Where(t => Outcome(t.Net) > 0).ToList(), losses = closed.Where(t => Outcome(t.Net) < 0).ToList();
            if (wins.Count > 0) c.HoldWin = TimeSpan.FromSeconds(wins.Average(t => Math.Max(0, (t.Close - t.Open).TotalSeconds)));
            if (losses.Count > 0) c.HoldLoss = TimeSpan.FromSeconds(losses.Average(t => Math.Max(0, (t.Close - t.Open).TotalSeconds)));
            if (wins.Count > 0 && losses.Count > 0 && c.HoldWin.TotalSeconds > 0) c.HoldRatio = c.HoldLoss.TotalSeconds / c.HoldWin.TotalSeconds;
            c.LossAversion = closed.Count >= FewTradesBelow && c.HoldRatio > LossAversionRatio;
            foreach (JournalTrade t in closed)
            {
                bool won = Outcome(t.Net) > 0;
                if (t.Buy) { c.Buys++; if (won) c.BuyWins++; c.BuyNet += t.Net; }
                else { c.Sells++; if (won) c.SellWins++; c.SellNet += t.Net; }
            }
            var days = new HashSet<DateTime>(j.Trades.Where(t => InRange(t.Open, from, end)).Select(t => t.Open.Date)
                .Concat(j.Open.Where(o => InRange(o.Open, from, end)).Select(o => o.Open.Date)));
            c.TradingDays = days.Count;
            if (days.Count > 0) c.TradesPerDay = c.Opened > 0 ? c.Opened / (double)days.Count : 0;
        }

        public static string[] WeekdayNames { get { return new[] { Lang.T("یکشنبه", "Sunday"), Lang.T("دوشنبه", "Monday"), Lang.T("سه‌شنبه", "Tuesday"), Lang.T("چهارشنبه", "Wednesday"), Lang.T("پنجشنبه", "Thursday"), Lang.T("جمعه", "Friday"), Lang.T("شنبه", "Saturday") }; } }

        static void Add(Dictionary<string, SliceStat> map, string key, string name, JournalTrade t)
        {
            SliceStat g;
            if (!map.TryGetValue(key, out g)) map[key] = g = new SliceStat { Key = key, Name = name };
            g.Trades++;
            g.Net += t.Net;
            int o = Outcome(t.Net);
            if (o > 0) { g.Wins++; g.GrossProfit += R2(t.Net); }
            else if (o < 0) g.GrossLoss -= R2(t.Net);
        }

        static void Slices(AccountJournal j, List<JournalTrade> closed, CoachStats c)
        {
            var sym = new Dictionary<string, SliceStat>(StringComparer.OrdinalIgnoreCase);
            var day = new Dictionary<string, SliceStat>();
            var ses = new Dictionary<string, SliceStat>();
            ServerClock clock = ServerClock.Of(j);
            foreach (JournalTrade t in closed)
            {
                Add(sym, t.Symbol, t.Symbol, t);
                int d = (int)t.Open.DayOfWeek;
                Add(day, d.ToString(Inv), WeekdayNames[d], t);
                TradeSession session = TradeSessions.Of(clock.ToGmt(t.Open));
                Add(ses, TradeSessions.Key(session), TradeSessions.Name(session), t);
            }
            c.BySymbol.AddRange(sym.Values.OrderByDescending(g => g.Net).ThenBy(g => g.Key, StringComparer.OrdinalIgnoreCase));
            // Monday to Friday always, the weekend only when traded; in the order of the week from Monday.
            foreach (int d in new[] { 1, 2, 3, 4, 5, 6, 0 })
            {
                SliceStat g;
                if (day.TryGetValue(d.ToString(Inv), out g)) c.ByWeekday.Add(g);
                else if (d >= 1 && d <= 5) c.ByWeekday.Add(new SliceStat { Key = d.ToString(Inv), Name = WeekdayNames[d] });
            }
            foreach (TradeSession t in new[] { TradeSession.Overlap, TradeSession.London, TradeSession.NewYork, TradeSession.Asia })
            {
                SliceStat g;
                c.BySession.Add(ses.TryGetValue(TradeSessions.Key(t), out g) ? g : new SliceStat { Key = TradeSessions.Key(t), Name = TradeSessions.Name(t) });
            }
        }

        // ---------------------------------------------------------------- the score

        /// <summary>3.27.1 (CHANGE-020): what needs attention. Revenge, Late SL, Martingale and Loss aversion are no longer warnings, and
        /// there is no A–D grade; the Stop Loss kind of each trade is still shown with the trade.</summary>
        public static void Judge(JournalSummary s, CoachStats c)
        {
            // What needs attention, closed trades or not (a position opened without a Stop Loss counts too). 3.20: the words in
            // English, as traders say them.
            if (!double.IsNaN(c.AvgRiskPct) && c.AvgRiskPct > RiskFlagPct) Flag(c, "risk", FlagLevel.Bad, "Risk " + Pct(c.AvgRiskPct) + " per trade");
            if (c.MaxDdPct > DdFlagPct) Flag(c, "dd", FlagLevel.Bad, "Max DD " + Pct(c.MaxDdPct));
            if (c.EquityKnown && c.EqDdPct > DdFlagPct && c.EqDdPct > c.MaxDdPct + 0.05) Flag(c, "eqdd", FlagLevel.Bad, "Equity DD " + Pct(c.EqDdPct));
            if (s.DdRed) Flag(c, "daily", FlagLevel.Bad, "Daily DD " + Pct(s.MaxDailyDdPct));
            // SLR 2.0: never a Stop Loss is red; one put on after the entry only a warning.
            if (s.Unprotected > 0) Flag(c, "nosl", FlagLevel.Bad, "No SL ×" + s.Unprotected.ToString(Inv) + (c.NoSlTrades > 0 ? " · " + Span(c.NoSlTime) : ""));
            if (c.MaxLossStreak >= StreakFlag) Flag(c, "streak", FlagLevel.Warn, c.MaxLossStreak.ToString(Inv) + " losses in a row");
            if (!s.OverOk) Flag(c, "over", FlagLevel.Warn, "Over limit " + s.OverDays.ToString(Inv) + (s.OverDays == 1 ? " day" : " days"));
        }

        static void Flag(CoachStats c, string key, FlagLevel level, string text) { c.Flags.Add(new CoachFlag { Key = key, Level = level, Text = text }); }

        /// <summary>What grew in the martingale: the risk (measured at the Stop Loss) or, without one, the lots.</summary>
        public static string MartingaleWord(CoachStats c) { return c.MartingaleByRisk ? Lang.T("ریسک", "Risk") : Lang.T("حجم", "Volume"); }

        /// <summary>A percent with one decimal ("2.4%"), in Latin digits as the page shows money and rates.</summary>
        public static string Pct(double v) { return v.ToString("0.0", Inv) + "%"; }

        public static string Money(double v) { return (v < 0 ? "-" : v > 0 ? "+" : "") + Math.Abs(v).ToString("#,0.00", Inv); }

        public static string Num(double v, string format = "0.00") { return double.IsPositiveInfinity(v) ? "∞" : double.IsNaN(v) ? "—" : v.ToString(format, Inv); }

        public static string Hold(TimeSpan t)
        {
            if (t.TotalMinutes < 1) return "0:00";
            int h = (int)t.TotalHours;
            return h >= 24 ? Fa.N(h / 24) + Lang.T(" روز ", " day ") + (h % 24).ToString(Inv) + ":" + t.Minutes.ToString("00", Inv) : h.ToString(Inv) + ":" + t.Minutes.ToString("00", Inv);
        }

        // ---------------------------------------------------------------- the notes

        /// <summary>A few sentences for the coach, from the numbers only: what goes well, what needs work, and what to try next week.</summary>
        public static void Notes(JournalSummary s, CoachStats c)
        {
            if (c.Trades == 0) return;
            bool enough = c.Trades >= FewTradesBelow;
            SliceStat best = c.BySymbol.Where(g => g.Trades >= 5 && g.ProfitFactor >= 1.5).OrderByDescending(g => g.Net).FirstOrDefault();
            SliceStat worst = c.BySymbol.Where(g => g.Trades >= 4 && g.ProfitFactor < 0.8).OrderBy(g => g.Net).FirstOrDefault();

            // what goes well
            if (c.Opened >= 3 && s.NoStop == 0) c.Strengths.Add(Lang.T("همه‌ی ", "All ") + Fa.N(c.Opened) + Lang.T(" معامله حد ضرر داشتند.", " trades had a stop loss."));
            if (best != null) c.Strengths.Add(best.Name + Lang.T(" بهترین نماد است: ", " is the best symbol: ") + Fa.N(best.Trades) + Lang.T(" معامله، پروفیت فاکتور ", " trades, profit factor ") + Num(best.ProfitFactor) + ".");
            if (!double.IsNaN(c.AvgRiskPct) && c.AvgRiskPct <= 1) c.Strengths.Add(Lang.T("ریسک میانگین هر معامله ", "Average risk per trade is ") + Pct(c.AvgRiskPct) + Lang.T(" است؛ زیر سقف ۱٪.", "; under the 1% cap."));
            if (enough && c.ProfitFactor >= 1.5) c.Strengths.Add(Lang.T("پروفیت فاکتور ", "Profit factor") + Num(c.ProfitFactor) + Lang.T(": سودها خوب از زیان‌ها جلو افتاده‌اند.", ": profits clearly outweigh losses."));
            if (enough && s.RiskReward >= 1.5) c.Strengths.Add(Lang.T("میانگین سود ", "The average win is ") + Num(s.RiskReward, "0.0") + Lang.T(" برابر میانگین زیان است.", " times the average loss."));
            if (enough && c.Revenge == 0 && c.MartingaleChains == 0 && c.Losses > 0) c.Strengths.Add(Lang.T("بعد از ضرر، با عجله یا ریسک بیشتر برنگشت.", "After a loss, did not come back in a hurry or with more risk."));
            if (enough && c.MaxDdPct < 5 && (!c.EquityKnown || c.EqDdPct < 5)) c.Strengths.Add(Lang.T("بیشترین افت سرمایه (Max DD) ", "Largest drawdown (Max DD) ") + Pct(c.MaxDdPct) + Lang.T(" بود؛ کنترل‌شده.", " was; under control."));
            if (enough && s.OverOk) c.Strengths.Add(Lang.T("از سقف تعداد معامله بیرون نزد.", "Stayed within the trade count limit."));

            // what needs work, and the matching advice
            if (s.Unprotected > 0)
            {
                c.Work.Add(Fa.N(s.Unprotected) + Lang.T(" معامله هیچ‌وقت حد ضرر نداشت", " trades never had a stop loss") + (c.NoSlTrades > 0 ? Lang.T("؛ روی هم ", "; together ") + TextUtil.PersianDigits(Span(c.NoSlTime)) + Lang.T(" بدون حد ضرر در بازار بود (طولانی‌ترین ", " in the market without a stop loss (longest ") + TextUtil.PersianDigits(Span(c.NoSlLongest)) + ")" : "") + ".");
                c.Next.Add(Lang.T("پیش از هر ورود، حد ضرر بگذارد.", "Set a stop loss before every entry."));
            }
            else if (s.StopLater > 0) { c.Work.Add(Fa.N(s.StopLater) + Lang.T(" معامله بدون حد ضرر باز شد و حد ضرر بعداً اضافه شد.", " trades were opened without a stop loss and the stop loss was added later.")); c.Next.Add(Lang.T("حد ضرر را هم‌زمان با خود سفارش بگذارد.", "Place the stop loss together with the order itself.")); }
            if (c.MartingaleChains > 0)
            {
                c.Work.Add(Lang.T("بعد از باخت ", "After a loss ") + MartingaleWord(c) + Lang.T(" را پشت‌سرهم بزرگ کرد (مارتینگل): ", " was increased again and again (martingale): ") + Fa.N(c.MartingaleChains) + Lang.T(" بار، ", " times, ") + MartingaleWord(c) + Lang.T(" تا ", " up to ") + TextUtil.PersianDigits(c.MartingaleFactor.ToString("0.0", Inv)).Replace('.', '٫') + Lang.T(" برابر.", " times."));
                c.Next.Add(Lang.T("بعد از هر باخت ریسک را ثابت نگه دارد؛ هیچ‌وقت برای جبران بزرگ‌ترش نکند.", "Keep the risk the same after every loss; never make it bigger to win it back."));
            }
            if (!double.IsNaN(c.AvgRiskPct) && c.AvgRiskPct > RiskFlagPct)
            {
                c.Work.Add(Lang.T("ریسک میانگین هر معامله ", "Average risk per trade is ") + Pct(c.AvgRiskPct) + Lang.T(" است؛ بالای ۲٪.", "; above 2%."));
                c.Next.Add(Lang.T("ریسک هر معامله را به ۱٪ برساند.", "Bring the risk per trade down to 1%."));
            }
            else if (!double.IsNaN(c.MaxRiskPct) && c.MaxRiskPct > RiskFlagPct)
                c.Next.Add(Lang.T("سقف ریسک ۱٪ را نگه دارد؛ یک معامله ", "Keep the 1% risk cap; one trade had ") + Pct(c.MaxRiskPct) + Lang.T(" ریسک داشت.", " risk."));
            if (c.Revenge > 0)
            {
                c.Work.Add(Fa.N(c.Revenge) + Lang.T(" بار تا ", " times within ") + Fa.N(RevengeMinutes) + Lang.T(" دقیقه بعد از ضرر، با همان ریسک یا بیشتر دوباره وارد شد.", " minutes after a loss, entered again with the same risk or more."));
                c.Next.Add(Lang.T("بعد از هر ضرر، ", "After every loss, do not trade for ") + Fa.N(RevengeMinutes) + Lang.T(" دقیقه معامله نکند.", " minutes."));
            }
            if (s.DdRed)
            {
                c.Work.Add(Lang.T("دراوداون روزانه به ", "Daily drawdown reached ") + Pct(s.MaxDailyDdPct) + Lang.T(" رسید (", " (") + Gd.Date(s.MaxDdDay) + Lang.T(")؛ بالای ۳٪.", "); above 3%."));
                c.Next.Add(Lang.T("سقف زیان روزانه ۳٪ را نگه دارد و بعد از آن، آن روز را تمام کند.", "Keep the 3% daily loss cap and stop for the day after it."));
            }
            if (enough && c.HoldRatio >= 1.5)
            {
                c.Work.Add(Lang.T("باخت‌ها ", "Losing trades stay open ") + TextUtil.PersianDigits(c.HoldRatio.ToString("0.0", Inv)).Replace('.', '٫') + Lang.T(" برابر بردها باز می‌مانند (", " times longer than winning ones (") + Hold(c.HoldLoss) + Lang.T(" در برابر ", " vs ") + Hold(c.HoldWin) + ")"
                           + (c.LossAversion ? Lang.T("؛ زیان‌گریزی: سود زود بسته می‌شود و باخت به امید برگشت باز می‌ماند.", "; loss aversion: profits are closed early and losses are left open hoping they come back.") : "."));
                c.Next.Add(c.LossAversion ? Lang.T("باخت را به حد ضرر بسپارد و برد را تا حد سود نگه دارد.", "Leave losses to the stop loss and keep wins until the take profit.") : Lang.T("حد ضرر را عقب نکشد و باخت را زودتر ببندد.", "Do not move the stop loss back; close losses sooner."));
            }
            if (c.MaxLossStreak >= 4)
            {
                c.Work.Add(Fa.N(c.MaxLossStreak) + Lang.T(" باخت پیاپی داشت (روی هم ", " losses in a row (together ") + Money(c.LossStreakMoney) + ").");
                c.Next.Add(Lang.T("بعد از ۳ باخت پیاپی، آن روز را تمام کند.", "After 3 losses in a row, stop for the day."));
            }
            if (c.Buys >= 5 && c.Sells >= 5)
            {
                double b = c.BuyWins * 100.0 / c.Buys, se = c.SellWins * 100.0 / c.Sells;
                if (se + 15 <= b) c.Work.Add(Lang.T("فروش‌ها ضعیف‌اند: درصد برد ", "Sells are weak: win rate ") + Pct(se) + Lang.T(" در برابر ", " vs ") + Pct(b) + Lang.T(" خرید.", " buys."));
                else if (b + 15 <= se) c.Work.Add(Lang.T("خریدها ضعیف‌اند: درصد برد ", "Buys are weak: win rate ") + Pct(b) + Lang.T(" در برابر ", " vs ") + Pct(se) + Lang.T(" فروش.", " sells."));
            }
            if (worst != null)
            {
                c.Work.Add(worst.Name + Lang.T(" زیان‌ده است: پروفیت فاکتور ", " is losing: profit factor ") + Num(worst.ProfitFactor) + Lang.T(" در ", " in ") + Fa.N(worst.Trades) + Lang.T(" معامله.", " trades."));
                c.Next.Add(worst.Name + Lang.T(" را کمتر معامله کند.", " should be traded less."));
            }
            if (!s.OverOk) { c.Work.Add(Lang.T("بیشتر از سقف معامله کرد (", "Traded more than the limit (") + s.OverStatus.Replace(Lang.T("اورترید: ", "Overtrading: "), "") + ")."); c.Next.Add(Lang.T("به سقف ", "Stick to the limit of ") + Fa.N(s.Limits.Daily) + Lang.T(" معامله در روز پایبند بماند.", " trades a day.")); }
            if (enough && c.ProfitFactor < 1) c.Work.Add(Lang.T("پروفیت فاکتور ", "Profit factor") + Num(c.ProfitFactor) + Lang.T(": زیان‌ها از سودها بیشترند.", ": losses are larger than profits."));

            Trim(c.Strengths); Trim(c.Work); Trim(c.Next);
        }

        static void Trim(List<string> list) { if (list.Count > 3) list.RemoveRange(3, list.Count - 3); }
    }

    /// <summary>The whole group's numbers, for the top of the page.</summary>
    public sealed class GroupCoach
    {
        public int Read, Attention, Winners, Losers, Trades;
        public double Net, GrossProfit, GrossLoss, ProfitFactor = double.NaN, ExpectancyR = double.NaN, Expectancy = double.NaN;
        public double MaxDdPct; public string MaxDdName = ""; public DateTime MaxDdPeak;
        public int Opened, WithStop; public double StopPct = double.NaN;
        public double AvgRiskPct = double.NaN;
        public int RevengeAccounts, RevengeTrades, HoldLongerAccounts, HoldCompared, DailyRedAccounts, OverAccounts, RiskAccounts, NoStopAccounts;
        /// <summary>3.19: the parts of the group's expectancy (every closed trade pooled), SLR 2.0 counts, overtrading days and the
        /// behaviour alerts.</summary>
        public int Wins, Losses, StopAtEntry, StopLater, Unprotected, StopMt4, OverDays, MartingaleAccounts, LossAversionAccounts, PsychAccounts;
        public double WinRate = double.NaN, AvgWin, AvgLoss, RiskReward = double.NaN, StartBalance, ReturnPct = double.NaN;
        public string BestPfName = ""; public double BestPf = double.NaN;

        public static GroupCoach Of(IList<KeyValuePair<string, CoachStats>> rows, IList<JournalSummary> summaries)
        {
            var g = new GroupCoach();
            double rSum = 0; int rCount = 0; double riskSum = 0; int riskCount = 0;
            for (int k = 0; k < rows.Count; k++)
            {
                CoachStats c = rows[k].Value; JournalSummary s = summaries[k];
                if (c == null || s == null) continue;
                string name = rows[k].Key;
                g.Read++;
                g.Trades += c.Trades; g.Net += c.Net; g.GrossProfit += c.GrossProfit; g.GrossLoss += c.GrossLoss;
                if (c.Trades > 0) { if (c.Net > 0.004) g.Winners++; else if (c.Net < -0.004) g.Losers++; }
                if (c.MaxDdPct > g.MaxDdPct) { g.MaxDdPct = c.MaxDdPct; g.MaxDdName = name; g.MaxDdPeak = c.DdPeak; }
                g.Opened += c.Opened; g.WithStop += c.WithStop;
                g.Wins += c.Wins; g.Losses += c.Losses; g.StartBalance += s.StartBalance;
                g.StopAtEntry += s.StopAtEntry; g.StopLater += s.StopLater; g.Unprotected += s.Unprotected; g.StopMt4 += s.StopMt4; g.OverDays += s.OverDays;
                if (c.MartingaleChains > 0) g.MartingaleAccounts++;
                if (c.LossAversion) g.LossAversionAccounts++;
                if (c.PsychAlerts > 0) g.PsychAccounts++;
                if (c.RTrades > 0) { rSum += c.ExpectancyR * c.RTrades; rCount += c.RTrades; }
                if (c.RiskTrades > 0) { riskSum += c.AvgRiskPct * c.RiskTrades; riskCount += c.RiskTrades; }
                if (c.Revenge > 0) { g.RevengeAccounts++; g.RevengeTrades += c.Revenge; }
                if (!double.IsNaN(c.HoldRatio)) { g.HoldCompared++; if (c.HoldRatio > 1) g.HoldLongerAccounts++; }
                if (s.DdRed) g.DailyRedAccounts++;
                if (!s.OverOk) g.OverAccounts++;
                if (c.Has("risk")) g.RiskAccounts++;
                if (s.NoStop > 0) g.NoStopAccounts++;
                if (c.NeedsAttention) g.Attention++;
                if (c.Trades >= Coach.FewTradesBelow && !double.IsNaN(c.ProfitFactor) && !double.IsInfinity(c.ProfitFactor) && (double.IsNaN(g.BestPf) || c.ProfitFactor > g.BestPf))
                { g.BestPf = c.ProfitFactor; g.BestPfName = name; }
            }
            g.ProfitFactor = Coach.Factor(g.GrossProfit, g.GrossLoss);
            if (g.Trades > 0)
            {
                g.WinRate = g.Wins * 100.0 / g.Trades;
                g.AvgWin = g.Wins > 0 ? g.GrossProfit / g.Wins : 0;
                g.AvgLoss = g.Losses > 0 ? g.GrossLoss / g.Losses : 0;
                double lossRate = g.Losses * 100.0 / g.Trades;
                g.Expectancy = g.WinRate / 100 * g.AvgWin - lossRate / 100 * g.AvgLoss;
                if (g.Losses > 0) g.RiskReward = g.AvgWin / g.AvgLoss;
            }
            if (g.StartBalance > 0) g.ReturnPct = g.Net / g.StartBalance * 100;
            if (rCount > 0) g.ExpectancyR = rSum / rCount;
            if (riskCount > 0) g.AvgRiskPct = riskSum / riskCount;
            if (g.Opened > 0) g.StopPct = g.WithStop * 100.0 / g.Opened;
            return g;
        }
    }
}
