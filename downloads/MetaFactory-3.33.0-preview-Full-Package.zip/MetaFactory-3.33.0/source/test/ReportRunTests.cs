using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MTManager
{
    static partial class Tests
    {
        static void ReportRunChecks()
        {
            var summary = new ReportRunSummary();
            for (int n = 0; n < 110; n++) summary.Add("s" + n, new Account { Trader = "Student " + n, Login = (1000 + n).ToString(), Server = "Broker-Demo" }, Kind.MT5);
            for (int n = 0; n < 70; n++) summary.Record("s" + n, new ReportRow { Journal = new AccountJournal() });
            for (int n = 70; n < 90; n++) summary.Record("s" + n, new ReportRow { Error = "connection failed" });
            summary.StopPending(); summary.End();
            Equal(110, summary.Total, "summary covers entire selected batch"); Equal(70, summary.Fresh, "summary reports seventy fresh successes");
            Equal(40, summary.Unread, "summary reports forty without a fresh report"); Equal(20, summary.Failed, "actual failures distinguished from unattempted accounts");
            Equal(20, summary.Stopped, "stopped unattempted accounts counted separately"); Equal(0, summary.Pending, "finished stopped summary has no hanging pending rows");
            Check(summary.Rows.Where(r => r.State == "failed").All(r => r.Reason == "connection failed"), "each failed account keeps its own reason");
            summary.Record("s0", new ReportRow { Journal = new AccountJournal() }); Equal(70, summary.Fresh, "repeated final callbacks do not double-count successes");
            summary.Begin(); summary.Add("cached", new Account { Login = "123" }, Kind.MT4);
            summary.Record("cached", new ReportRow { Journal = new AccountJournal(), Cached = true, Note = "earlier report; fresh connection failed" });
            Equal(0, summary.Fresh, "cached history is never counted as a fresh successful report"); Equal(1, summary.Cached, "cached history has its own result count");
            Equal(1, summary.Unread, "cached fallback still means the fresh report was not read");
            string file = Path.Combine(root, "report-results.xlsx"); summary.Export(file);
            Check(Spreadsheet.Read(file).Count == 2, "per-student report result exports to Excel");
            Check(Spreadsheet.Read(file)[1].Cells[6].Contains("fresh connection failed"), "Excel result includes the original per-row failure reason");
            Check(Installation.AppName == "MetaFactory" && Installation.LegacyAppNames.Contains("MT Manager") && Installation.LegacyAppNames.Contains("MTManager"), "installer migrates both English legacy desktop shortcut names");
            Check(LaunchMemoryPolicy.CanStart(8192, 4096, Kind.MT4, 200), "bulk launch proceeds with adequate free physical memory");
            Check(!LaunchMemoryPolicy.CanStart(8192, 800, Kind.MT4, 200), "bulk launch halts before exhausting physical memory");
            Check(!LaunchMemoryPolicy.CanStart(0, 0, Kind.MT5, 0), "unavailable memory measurement cannot trigger a blind bulk launch");
            Check(LaunchMemoryPolicy.Required(Kind.MT5, 1000) >= 1250, "launch guard adjusts to observed terminal peak with headroom");
            Check(LaunchMemoryPolicy.Reserve(131072) == 4096 && LaunchMemoryPolicy.Reserve(4096) >= 768, "launch policy reserves capacity for Windows on both small and large machines");
            Check(!LaunchMemoryPolicy.StartupTimedOut(10, false) && LaunchMemoryPolicy.StartupTimedOut(16, false) && !LaunchMemoryPolicy.StartupTimedOut(16, true), "bulk launch waits for a window but stops stalled startup");
            RetryAndCancelChecks();
        }
        static void RetryAndCancelChecks()
        {
            var settings = new Settings { BaseDir = Dir("report-run-fakes") };
            var jobs = new List<ReportJob>();
            foreach (string name in new[] { "first", "second", "permanent", "always-transient" })
                jobs.Add(new ReportJob { Index = jobs.Count, Name = name, Copy = new Instance { Name = name, Kind = Kind.MT5, Dir = settings.BaseDir }, Account = new Account { Login = (100 + jobs.Count).ToString(), Server = "Broker-Demo" } });
            var sequence = new List<string>();
            var runner = new ReportRunner(settings, jobs, new List<Instance>(), name => null, new ReportRange { From = DateTime.Today.AddDays(-1), To = DateTime.Today }, 1,
                (job, slot) => {
                    sequence.Add(job.Copy.Name + ":" + job.Attempt);
                    if (job.Name == "first" && job.Attempt == 1 || job.Name == "always-transient") return new ReportRow { Copy = job.Copy.Name, Error = "temporary connection issue", Retryable = true };
                    if (job.Name == "permanent") return new ReportRow { Copy = job.Copy.Name, Error = "wrong password" };
                    return new ReportRow { Copy = job.Copy.Name, Journal = new AccountJournal() };
                });
            var results = runner.Run();
            Equal("first:1,second:1,permanent:1,always-transient:1,first:2,always-transient:2", string.Join(",", sequence), "one deferred retry runs only after all first-pass accounts");
            Check(results[0].Journal != null && results[0].Attempts == 2, "transient first failure can become a successful fresh report");
            Equal(1, results[2].Attempts, "permanent credential failures are not retried automatically");
            Equal(2, results[3].Attempts, "repeated transient failure stops after two passes");
            var started = new ManualResetEvent(false); ReportRunner cancellable = null;
            cancellable = new ReportRunner(settings, jobs, new List<Instance>(), name => null, new ReportRange { From = DateTime.Today.AddDays(-1), To = DateTime.Today }, 1,
                (job, slot) => { started.Set(); while (!cancellable.Stopping) Thread.Sleep(10); return new ReportRow { Copy = job.Copy.Name, Cancelled = true, Error = "stopped" }; });
            Task<List<ReportRow>> task = Task.Factory.StartNew(() => cancellable.Run());
            Check(started.WaitOne(2000), "cancellation test reaches the active report"); cancellable.EndNow();
            Check(task.Wait(2000), "stop ends the report batch without waiting for all accounts");
            Check(task.Result.All(r => r.Cancelled), "stopped accounts are not mislabeled as successful or authentication failures");
            Check(task.Result.Skip(1).All(r => r.Attempts == 0), "accounts skipped by stop have zero attempts"); started.Dispose();
            string source = Dir("report-cancel-copy-source"); Touch(Path.Combine(source, "terminal.exe"));
            var candidate = new Instance { Kind = Kind.MT4, Name = "candidate", Dir = source };
            Throws<OperationCanceledException>(() => ReportCopies.Prepare(settings, Kind.MT4, "Cancel-Demo", 9, () => candidate, () => true), "report copy preparation honors stop before deployment");
            Check(!File.Exists(ReportCopies.For(settings, Kind.MT4, "Cancel-Demo", 9).Exe), "cancelled provisioning never exposes a partial report executable");
        }
    }
}
