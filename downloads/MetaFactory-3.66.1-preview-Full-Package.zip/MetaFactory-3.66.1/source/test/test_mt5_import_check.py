import importlib.util
from pathlib import Path
from types import SimpleNamespace
import io
import json
import unittest

spec = importlib.util.spec_from_file_location('import_probe', Path(__file__).parents[1] / 'bridge/mt5_import_check.py')
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


class Api:
    def __init__(self):
        self.calls = []
        self.ok_init = self.ok_login = True
        self.error = (-10005, 'SyntheticPassword9! must never be logged')
        self.account = SimpleNamespace(login=12345, server='WMMarkets-Demo', trade_allowed=False)
        self.terminal = SimpleNamespace(connected=True)
        self.closed = False
        self.time = 0.0

    def initialize(self, path, **kwargs):
        self.calls.append(('initialize', path, kwargs))
        self.time += 40
        return self.ok_init

    def login(self, number, **kwargs):
        self.calls.append(('login', number, kwargs))
        self.time += 20
        return self.ok_login

    def last_error(self):
        return self.error

    def account_info(self):
        self.calls.append(('account_info',))
        return self.account

    def terminal_info(self):
        self.calls.append(('terminal_info',))
        return self.terminal

    def shutdown(self):
        self.closed = True


class ImportProbeTests(unittest.TestCase):
    def setUp(self):
        self.api = Api()
        self.request = dict(token='a'*32, login='12345', server='WMMarkets-Demo', password='SyntheticPassword9!',
                            terminal='C:/private/terminal64.exe', initialize_timeout=60000,
                            login_timeout=30000, overall_timeout=150000)
        self.progress = []

    def check(self):
        result = probe.check(self.request, self.api, self.progress.append, lambda: self.api.time)
        self.assertTrue(self.api.closed)
        self.assertNotIn(self.request['password'], str(result) + str(self.progress))
        self.assertTrue(all(p['token'] == self.request['token'] for p in self.progress))
        return result

    def test_authenticated_start_then_fresh_ack_with_independent_budgets(self):
        reply = self.check()
        self.assertEqual('connected', reply['state'])
        self.assertTrue(reply['acknowledged'] and reply['identity_matched'])
        init, login = self.api.calls[:2]
        self.assertEqual(self.request['terminal'], init[1])
        self.assertEqual(12345, init[2]['login'])
        self.assertEqual(self.request['password'], init[2]['password'])
        self.assertEqual(self.request['server'], init[2]['server'])
        self.assertTrue(init[2]['portable'])
        self.assertEqual(60000, init[2]['timeout'])
        self.assertEqual(30000, login[2]['timeout'])
        self.assertEqual(['initialize', 'login', 'verify', 'shutdown'], [p['phase'] for p in self.progress])
        self.assertEqual(60, self.api.time)  # would exceed the old parent30s cutoff

    def test_initialization_timeout_is_not_password_rejection(self):
        self.api.ok_init = False
        result = self.check()
        self.assertEqual('unconfirmed', result['state'])
        self.assertEqual('initialize', result['phase'])
        self.assertEqual(-10005, result['error_code'])
        self.assertEqual(1, len(self.api.calls))

    def test_initialization_explicit_auth_rejection(self):
        self.api.ok_init = False
        self.api.error = (-6, self.request['password'])
        self.assertEqual('rejected', self.check()['state'])
        self.assertEqual(1, len(self.api.calls))

    def test_cached_account_never_overrides_fresh_login_rejection(self):
        self.api.ok_login = False
        self.api.error = (-6, self.request['password'])
        result = self.check()
        self.assertEqual('rejected', result['state'])
        self.assertEqual('login', result['phase'])
        self.assertFalse(result['acknowledged'])
        self.assertEqual(2, len(self.api.calls))

    def test_login_ipc_timeout_is_not_rejection(self):
        self.api.ok_login = False
        result = self.check()
        self.assertEqual('unconfirmed', result['state'])
        self.assertEqual('login', result['phase'])
        self.assertEqual(-10005, result['error_code'])

    def test_wrong_account_not_accepted(self):
        self.api.account.login = 54321
        result = self.check()
        self.assertEqual('unconfirmed', result['state'])
        self.assertTrue(result['acknowledged'])
        self.assertFalse(result['identity_matched'])
        self.assertEqual('verify', result['phase'])

    def test_wrong_server_not_accepted(self):
        self.api.account.server = 'Other-Demo'
        self.assertEqual('unconfirmed', self.check()['state'])

    def test_disconnected_not_accepted(self):
        self.api.terminal.connected = False
        self.assertEqual('unconfirmed', self.check()['state'])

    def test_missing_account_not_accepted(self):
        self.api.account = None
        result = self.check()
        self.assertEqual('unconfirmed', result['state'])
        self.assertEqual('verify', result['phase'])
        self.assertEqual(-10005, result['error_code'])

    def test_exception_cannot_reuse_old_auth_rejection(self):
        def fail(*a, **kw):
            raise RuntimeError(self.request['password'])
        self.api.initialize = fail
        self.api.error = (-6, self.request['password'])
        self.assertEqual('unconfirmed', self.check()['state'])

    def test_successful_init_with_expired_overall_budget_cannot_prove_login(self):
        old = self.api.initialize
        def init(*a, **kw):
            old(*a, **kw)
            self.api.time = 999
            return True
        self.api.initialize = init
        result = self.check()
        self.assertEqual('unconfirmed', result['state'])
        self.assertFalse(result['acknowledged'])
        self.assertEqual(1, len(self.api.calls))

    def test_invalid_configuration_never_uses_stale_bad_password_code(self):
        self.request['initialize_timeout'] = 'invalid'
        self.api.error = (-6, self.request['password'])
        self.assertEqual('unconfirmed', self.check()['state'])

    def test_persistent_stream_is_framed_and_password_free(self):
        raw = json.dumps(self.request) + '\n'
        output = io.StringIO()
        # use a fresh virtual clock for each native call sequence in this stream test
        self.api.initialize = lambda *a, **kw: True
        self.api.login = lambda *a, **kw: True
        probe.serve(io.StringIO(raw + raw), output, self.api, persistent=True)
        packets = [json.loads(line) for line in output.getvalue().splitlines()]
        finals = [p for p in packets if p['type'] == 'import-result']
        self.assertEqual(2, len(finals))
        self.assertTrue(all(p['state'] == 'connected' for p in finals))
        self.assertEqual(10, len(packets))
        self.assertNotIn(self.request['password'], output.getvalue())

    def test_malformed_stdin_does_not_echo_credentials(self):
        output = io.StringIO()
        probe.serve(io.StringIO('broken ' + self.request['password'] + '\n'), output, self.api)
        self.assertNotIn(self.request['password'], output.getvalue())
        self.assertEqual('invalid-request', json.loads(output.getvalue())['type'])

    def test_error_descriptions_are_never_returned(self):
        self.api.ok_login = False
        self.api.error = (-10003, 'private SDK text ' + self.request['password'])
        result = self.check()
        self.assertEqual(-10003, result['error_code'])
        self.assertNotIn('private SDK text', str(result))


if __name__ == '__main__':
    unittest.main()
