"""Private import-only MT5 check. Credentials arrive on stdin; diagnostics omit secrets."""
import json
import sys
import time

PROTOCOL = 1
PHASES = ('initialize', 'login', 'verify', 'shutdown')


def error_code(api):
    try:
        code = api.last_error()[0]
        if isinstance(code, int) and not isinstance(code, bool) and -1000000 <= code <= 1000000:
            return code
    except Exception:
        pass
    return None


def check(request, api, progress=None, monotonic=time.monotonic):
    reply = {k: request[k] for k in ('token', 'login', 'server')}
    reply.update(type='import-result', protocol=PROTOCOL, state='unconfirmed',
                 phase='initialize', acknowledged=False, identity_matched=False)
    started = monotonic()
    phase = 'initialize'

    def notify(value):
        if progress is not None:
            progress(dict(type='import-progress', protocol=PROTOCOL, token=request['token'], phase=value))

    def fail(value, code=None, authentication=False):
        reply.update(phase=value, error_code=code)
        # Only the SDK's explicit authentication rejection can mean rejected.
        if authentication and code == -6 and value in ('initialize', 'login'):
            reply['state'] = 'rejected'
        return reply

    try:
        initialize_ms = max(1000, min(60000, int(request['initialize_timeout'])))
        login_ms = max(1000, min(60000, int(request['login_timeout'])))
        overall_ms = max(initialize_ms + login_ms, min(180000, int(request['overall_timeout'])))

        def remaining():
            return max(0, overall_ms - int((monotonic() - started) * 1000))

        notify(phase)
        # Authenticate from SDK startup; no anonymous terminal/account wizard first.
        if not api.initialize(request['terminal'], portable=True, timeout=min(initialize_ms, remaining()),
                              login=int(request['login']), password=request['password'], server=request['server']):
            return fail(phase, error_code(api), True)
        if remaining() < 1000:
            return fail(phase)
        phase = 'login'
        notify(phase)
        # Even successful initialize/cached account_info never replaces this fresh ACK.
        if not api.login(int(request['login']), password=request['password'], server=request['server'],
                         timeout=min(login_ms, remaining())):
            return fail(phase, error_code(api), True)
        reply['acknowledged'] = True
        phase = 'verify'
        notify(phase)
        if remaining() <= 0:
            return fail(phase)
        account = api.account_info()
        if account is None:
            return fail(phase, error_code(api))
        terminal = api.terminal_info()
        if terminal is None:
            return fail(phase, error_code(api))
        if (account and terminal and terminal.connected
                and int(account.login) == int(request['login'])
                and str(account.server).strip().casefold() == request['server'].strip().casefold()):
            reply.update(state='connected', phase=phase, identity_matched=True)
        else:
            fail(phase)
        return reply
    except Exception:
        return fail(phase, error_code(api))
    finally:
        try:
            notify('shutdown')
            api.shutdown()
        except Exception:
            pass


def serve(input_stream, output_stream, api=None, persistent=False):
    if api is None:
        try:
            import MetaTrader5 as api
        except Exception:
            api = None
    for raw in input_stream:
        try:
            request = json.loads(raw)
        except Exception:
            # Never echo malformed input, exceptions or credential values.
            print(json.dumps(dict(type='invalid-request', protocol=PROTOCOL)), file=output_stream, flush=True)
            break
        def emit(packet):
            print(json.dumps(packet), file=output_stream, flush=True)
        if api is None:
            result = {k: request[k] for k in ('token', 'login', 'server')}
            result.update(type='import-result', protocol=PROTOCOL, state='unavailable', phase='startup',
                          acknowledged=False, identity_matched=False)
        else:
            result = check(request, api, emit)
        emit(result)
        if not persistent:
            break


if __name__ == '__main__':
    serve(sys.stdin, sys.stdout, persistent='--serve' in sys.argv[1:])
