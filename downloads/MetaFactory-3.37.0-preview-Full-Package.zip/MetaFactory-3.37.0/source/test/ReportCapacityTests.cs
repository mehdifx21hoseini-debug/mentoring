using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MTManager
{
    static partial class Tests
    {
        static ReportResourceSnapshot CapacitySample(long now = 0)
        { return new ReportResourceSnapshot { Processors = 4, TotalMb = 8075, FreeMb = 2200, CpuPercent = 40, MonotonicMs = now }; }

        static List<ReportJob> CapacityJobs(int count, Kind kind)
        {
            return Enumerable.Range(0, count).Select(n => new ReportJob
            {
                Index = n, Name = "capacity-" + n,
                Copy = new Instance { Name = "capacity-" + n, Kind = kind, Dir = root },
                Account = new Account { Login = (1000 + n).ToString(), Server = "Test-Demo" }
            }).ToList();
        }

        static void ReportCapacityChecks()
        {
            var automatic = new Settings();
            Equal(2, ReportParallel.For(automatic, new[] { Kind.MT4, Kind.MT4 }, 4, 8075, 2200), "8GB MT4-only batch can provision a parked second pilot worker");
            Equal(1, ReportParallel.For(automatic, new[] { Kind.MT5, Kind.MT5 }, 4, 8075, 2200), "MT5 keeps its existing low-memory concurrency ceiling");
            Equal(1, ReportParallel.For(automatic, new[] { Kind.MT4, Kind.MT5 }, 4, 8075, 2200), "mixed batches do not silently enable the MT4-only pilot");
            Equal(1, ReportParallel.For(new Settings { ReportAtOnce = 1 }, new[] { Kind.MT4, Kind.MT4 }, 4, 8075, 2200), "explicit one-worker setting always disables the pilot");
            Equal(1, ReportParallel.For(automatic, new[] { Kind.MT4 }, 4, 8075, 2200), "one account never needs a parked second worker");
            Equal(4, ReportParallel.For(automatic, Enumerable.Repeat(Kind.MT4, 6), 8, 16000, 6000), "strong-machine four-worker ceiling remains available");
            Equal(1, ReportParallel.For(automatic, new[] { Kind.MT4, Kind.MT4 }, 4, 8075, 1000), "insufficient RAM cannot provision a pilot worker");

            var policy = new Mt4AdaptiveAdmission();
            ReportResourceSnapshot sample = CapacitySample();
            Check(!policy.AllowSecond(sample), "pilot starts serially before measured outcomes");
            policy.Record(false, 200); policy.Record(true, 0); policy.Record(true, 200);
            sample.MonotonicMs = 3000;
            Check(!policy.AllowSecond(sample), "failure, unknown peak and only one measured success cannot promote");
            policy.Record(true, 220);
            Check(!policy.AllowSecond(sample), "second measured success begins low-pressure stability window");
            sample.MonotonicMs = 5000;
            Check(policy.AllowSecond(sample), "second worker admitted after two measured successes and stable low CPU");
            sample.CpuPercent = 82;
            Check(policy.AllowSecond(sample), "CPU hysteresis avoids oscillation in the intermediate band");
            sample.CpuPercent = 95;
            Check(!policy.AllowSecond(sample), "high CPU parks subsequent second-worker jobs without killing readers");
            sample.CpuPercent = 82; sample.MonotonicMs = 8000;
            Check(!policy.AllowSecond(sample), "recovery requires CPU below promotion threshold");
            sample.CpuPercent = 40; sample.MonotonicMs = 9000; policy.AllowSecond(sample); sample.MonotonicMs = 11000;
            Check(policy.AllowSecond(sample), "second worker can resume after pressure clears stably");
            sample.PendingGrowthMb = 1800;
            Check(!policy.AllowSecond(sample), "outstanding reservations prevent false promotion from optimistic free-RAM readings");
            sample.PendingGrowthMb = 0; sample.CpuPercent = -1;
            Check(!policy.AllowSecond(sample), "unknown CPU measurement never promotes the pilot");
            sample.CpuPercent = 40; sample.FreeMb = 1000;
            Check(!policy.AllowSecond(sample), "RAM pressure parks second-worker claims");
            var large = new Mt4AdaptiveAdmission(); large.Record(true, 2000); large.Record(true, 1800);
            Check(!large.AllowSecond(CapacitySample(5000)), "large measured terminal peaks keep an 8GB machine serial");
            Equal(50.0, ReportResourceSampler.CpuBusy(150, 250, 200, 100, 200, 150), "CPU load removes idle time from kernel-inclusive system counters");
            Equal(-1.0, ReportResourceSampler.CpuBusy(100, 200, 150, 100, 200, 150), "unchanged processor counters remain unknown");
            Equal(-1.0, ReportResourceSampler.CpuBusy(1, 2, 3, 100, 200, 150), "reset processor counters cannot manufacture low CPU load");

            int probes = 0, announcements = 0, sleeps = 0;
            ReportCapacityWait.Until(() => ++probes >= 4, () => false, () => announcements++, ms => sleeps++);
            Check(probes == 4 && announcements == 1 && sleeps == 3, "resource waiting retries capacity internally without account retries or repeated status spam");
            bool cancelled = false; probes = 0;
            Throws<OperationCanceledException>(() => ReportCapacityWait.Until(() => { probes++; return false; }, () => cancelled, null, ms => cancelled = true), "resource wait responds to cancellation");
            Equal(1, probes, "cancelled resource wait does not attempt another admission");

            var jobs = CapacityJobs(6, Kind.MT4);
            var range = new ReportRange { From = DateTime.Today.AddDays(-1), To = DateTime.Today };
            Func<ReportJob, int, ReportRow> fresh = (job, slot) => new ReportRow { Copy = job.Copy.Name, Journal = new AccountJournal(), PeakMb = 200 };
            var downgraded = new ReportRunner(automatic, jobs, new List<Instance>(), n => null, range, 4, fresh, () => CapacitySample());
            Check(downgraded.Parallel == 2 && downgraded.InitialParallel == 1, "fresh resource downgrade caps a previously selected four-worker pilot at two");
            var explicitOne = new ReportRunner(new Settings { ReportAtOnce = 1 }, jobs, new List<Instance>(), n => null, range, 4, fresh, () => CapacitySample());
            Equal(1, explicitOne.Parallel, "constructor honors explicit serial mode even with an excessive supplied ceiling");
            var strong = new ReportRunner(automatic, jobs, new List<Instance>(), n => null, range, 4, fresh,
                () => new ReportResourceSnapshot { Processors = 8, TotalMb = 16000, FreeMb = 6000, CpuPercent = 30 });
            Check(strong.Parallel == 4 && strong.InitialParallel == 4, "strong-machine constructor preserves normal four-worker reporting");

            int calls = 0, active = 0, maximum = 0; long resourceTime = 0;
            var overlap = new ManualResetEvent(false); var primaryOverlap = new ManualResetEvent(false);
            var adaptive = new ReportRunner(automatic, jobs, new List<Instance>(), n => null, range, 2, (job, slot) =>
            {
                int call = Interlocked.Increment(ref calls);
                int concurrent = Interlocked.Increment(ref active);
                int previous; do { previous = Volatile.Read(ref maximum); if (concurrent <= previous) break; } while (Interlocked.CompareExchange(ref maximum, concurrent, previous) != previous);
                bool met = true;
                if (call >= 3)
                {
                    if (slot == 2) { overlap.Set(); met = primaryOverlap.WaitOne(4000); }
                    else { primaryOverlap.Set(); met = overlap.WaitOne(4000); }
                }
                Interlocked.Decrement(ref active);
                return new ReportRow { Copy = job.Copy.Name, Journal = met ? new AccountJournal() : null, Error = met ? null : "pilot overlap missing", PeakMb = 200 };
            }, () => CapacitySample(Interlocked.Add(ref resourceTime, 1000)));
            var results = adaptive.Run(); overlap.Dispose(); primaryOverlap.Dispose();
            Check(results.All(r => r.Journal != null && r.Attempts == 1) && calls == jobs.Count, "pilot processes each account once without synthetic resource failures or retries");
            Equal(2, maximum, "parked pilot worker becomes active after measured serial successes");

            var entered = new ManualResetEvent(false); ReportRunner stopping = null;
            stopping = new ReportRunner(automatic, CapacityJobs(4, Kind.MT4), new List<Instance>(), n => null, range, 2, (job, slot) =>
            {
                entered.Set(); while (!stopping.Stopping) Thread.Sleep(10);
                return new ReportRow { Copy = job.Copy.Name, Cancelled = true, Error = "stopped" };
            }, () => CapacitySample());
            Task<List<ReportRow>> task = Task.Factory.StartNew(() => stopping.Run());
            Check(entered.WaitOne(2000), "adaptive cancellation reaches its initial active reader"); stopping.EndNow();
            Check(task.Wait(2000), "stop releases both the active reader and parked preclaim worker promptly");
            Check(task.Result.Count(r => r.Attempts == 0) == 3 && task.Result.All(r => r.Cancelled), "parked capacity worker never consumes an account attempt before stop");
            entered.Dispose();
        }
    }
}
