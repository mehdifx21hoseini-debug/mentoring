// Manual MT4 overflow only. Sandboxie is an installed, optional Windows dependency.
// Never returns a launcher PID, kills a process, edits DefaultBox, or requests elevation.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Microsoft.Win32;

namespace MTManager
{
    public static class SandboxLaunch
    {
        public const int NativeBudget = 28;
        public const int BoxBudget = 24;
        static readonly object ApiLock = new object();
        static NativeApi api;
        static bool Windows { get { return Environment.OSVersion.Platform == PlatformID.Win32NT; } }
        public static bool Available { get { return Windows && Installation() != null; } }
        public static bool IsEnabled(Settings s) { return s != null && s.SandboxieOverflow && Available; }
        public static int ReportLimit(Settings s) { return IsEnabled(s) ? Math.Min(32, s.MaxMt4) : s.MaxMt4; }
        public static int AdmissionMt4Count(Settings s)
        {
            // Explicit opt-out must not require an operational Sandboxie driver.
            return IsEnabled(s) ? NativeMt4Count() : Processes.Mt4InSession();
        }
        public static string Describe()
        {
            return Available ? "Sandboxie installed; manual MT4: native budget 28, managed groups of 24; MT5 unchanged. Runtime API availability checked on launch."
                : "Sandboxie not installed/available; manual launch remains native.";
        }
        static UserMessage Error(string detail)
        {
            return new UserMessage(Lang.T("اجرای MT4 با Sandboxie انجام نشد: ", "Sandboxie MT4 launch failed: ") + detail);
        }
        static string Installation()
        {
            if (!Windows) return null;
            var roots = new List<string>();
            // Sandboxie installer itself derives its location from the installed driver service.
            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\SbieDrv"))
                {
                    string image = key == null ? null : key.GetValue("ImagePath") as string;
                    if (!string.IsNullOrWhiteSpace(image))
                    {
                        image = Environment.ExpandEnvironmentVariables(image).Trim().Trim('"');
                        if (image.StartsWith(@"\??\", StringComparison.Ordinal)) image = image.Substring(4);
                        if (Path.IsPathRooted(image)) roots.Add(Path.GetDirectoryName(image));
                    }
                }
            }
            catch { }
            foreach (RegistryView view in new[] { RegistryView.Registry64, RegistryView.Registry32 })
                try
                {
                    using (var lm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, view))
                    using (var key = lm.OpenSubKey(@"SOFTWARE\Sandboxie"))
                        if (key != null) { var p = key.GetValue("HomePath") as string; if (!string.IsNullOrWhiteSpace(p)) roots.Add(p); }
                }
                catch { }
            foreach (string pf in new[] { Environment.GetEnvironmentVariable("ProgramW6432"), Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) })
                if (!string.IsNullOrEmpty(pf)) { roots.Add(Path.Combine(pf, "Sandboxie-Plus")); roots.Add(Path.Combine(pf, "Sandboxie")); }
            return roots.FirstOrDefault(p => Path.IsPathRooted(p) && File.Exists(Path.Combine(p, "Start.exe")) && File.Exists(Path.Combine(p, "SbieIni.exe")) && File.Exists(Path.Combine(p, "SbieDll.dll")));
        }
        static NativeApi Api()
        {
            lock (ApiLock)
            {
                if (api != null) return api;
                string home = Installation();
                if (home == null) throw Error("Sandboxie is not installed.");
                try { return api = new NativeApi(home); }
                catch (UserMessage) { throw; }
                catch (Exception ex) { throw Error("API unavailable (" + ex.GetType().Name + ")."); }
            }
        }
        public static bool IsSandboxedPid(int pid)
        {
            return Available && Api().Pids(null).Contains(pid);
        }
        public static int NativeMt4Count()
        {
            if (!Available) return Processes.Mt4InSession();
            var boxed = new HashSet<int>(Api().Pids(null));
            int session; using (var self = Process.GetCurrentProcess()) session = self.SessionId;
            int count = 0;
            foreach (Process p in Process.GetProcessesByName("terminal"))
            {
                using (p)
                {
                    try { if (p.SessionId == session && !boxed.Contains(p.Id)) count++; }
                    catch (InvalidOperationException) { }
                    catch { count++; } // Unknown is conservatively occupied, never a free slot.
                }
            }
            return count;
        }
        internal static string Canonical(string path)
        {
            return Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar).ToUpperInvariant();
        }
        internal static string ManagedDirectoryRule(string dir)
        {
            if (string.IsNullOrWhiteSpace(dir) || dir.IndexOfAny(new[] { ',', '%', '*', '?', '\r', '\n', '\t', '"' }) >= 0)
                throw Error("The MT4 copy directory contains unsupported Sandboxie rule characters (comma, percent, wildcard or control characters). Move this copy to a simple directory name first.");
            try
            {
                if (!Path.IsPathRooted(dir)) throw Error("A managed MT4 copy needs an absolute directory path.");
                string full = Path.GetFullPath(dir);
                if (string.Equals(Canonical(full), Canonical(Path.GetPathRoot(full)), StringComparison.OrdinalIgnoreCase))
                    throw Error("A whole drive or share cannot be opened to a managed box; select an individual MT4 copy directory.");
                return full.TrimEnd('\\', '/') + "\\";
            }
            catch (UserMessage) { throw; }
            catch { throw Error("The MT4 copy directory is not a valid managed-box path."); }
        }
        internal static string Hash(string value)
        {
            using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(value))).Replace("-", "").Substring(0, 12);
        }
        // SbieIni uses CmdEatString/CmdCopyString: quotes group a literal string; backslashes
        // are not escape characters. This is intentionally different from Start.exe arguments.
        internal static string IniQuote(string arg)
        {
            if (arg == null || arg.IndexOfAny(new[] { '"', '\r', '\n', '\0' }) >= 0)
                throw Error("Invalid Sandboxie configuration argument.");
            return "\"" + arg + "\"";
        }
        internal static string Quote(string arg)
        {
            // CommandLineToArgvW-compatible escaping, including a directory's trailing backslash.
            var b = new StringBuilder("\""); int slashes = 0;
            foreach (char c in arg)
            {
                if (c == '\\') { slashes++; continue; }
                if (c == '"') { b.Append('\\', slashes * 2 + 1); b.Append(c); }
                else { b.Append('\\', slashes); b.Append(c); }
                slashes = 0;
            }
            return b.Append('\\', slashes * 2).Append('"').ToString();
        }
        internal sealed class Assignments
        {
            internal string Owner;
            internal readonly Dictionary<string, string> Boxes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            internal string Scope;
            internal Assignments(string scope) { Scope = Hash(Canonical(scope)); Owner = Guid.NewGuid().ToString("N"); }
            internal string Assign(string dir)
            {
                dir = Canonical(dir); string found;
                if (Boxes.TryGetValue(dir, out found)) return found;
                int group = 1;
                while (Boxes.Values.Count(x => x == BoxName(group)) >= BoxBudget) group++;
                found = BoxName(group); Boxes.Add(dir, found); return found;
            }
            string BoxName(int group) { return "MetaFactory_" + Scope + "_" + group.ToString(CultureInfo.InvariantCulture); }
            internal bool ValidBox(string name)
            {
                string prefix = "MetaFactory_" + Scope + "_"; int group;
                return name.StartsWith(prefix, StringComparison.Ordinal) && int.TryParse(name.Substring(prefix.Length), out group) && group > 0 && name.Length < 38;
            }
            internal static Assignments Read(string path, string scope)
            {
                var map = new Assignments(scope);
                if (!File.Exists(path)) return map;
                string[] lines = File.ReadAllLines(path, Encoding.UTF8);
                Guid owner;
                if (lines.Length == 0 || !Guid.TryParseExact(lines[0], "N", out owner)) throw Error("The managed-box assignment file is invalid; no boxes were changed.");
                map.Owner = owner.ToString("N");
                foreach (string line in lines.Skip(1))
                {
                    string[] pair = line.Split('\t');
                    if (pair.Length != 2 || !map.ValidBox(pair[0])) throw Error("The managed-box assignment file is invalid.");
                    string dir;
                    try { dir = Canonical(Encoding.UTF8.GetString(Convert.FromBase64String(pair[1]))); }
                    catch { throw Error("The managed-box assignment file contains an invalid path."); }
                    if (map.Boxes.ContainsKey(dir)) throw Error("Duplicate managed-box assignment.");
                    map.Boxes.Add(dir, pair[0]);
                }
                if (map.Boxes.Values.GroupBy(x => x).Any(g => g.Count() > BoxBudget)) throw Error("The managed-box assignment file exceeds its group capacity.");
                return map;
            }
            internal void Save(string path)
            {
                string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
                try
                {
                    File.WriteAllLines(temp, new[] { Owner }.Concat(Boxes.OrderBy(x => x.Key).Select(x => x.Value + "\t" + Convert.ToBase64String(Encoding.UTF8.GetBytes(x.Key)))), Encoding.UTF8);
                    if (File.Exists(path)) File.Replace(temp, path, null); else File.Move(temp, path);
                }
                finally { if (File.Exists(temp)) File.Delete(temp); }
            }
        }
        static void EnsureNotRunning(Instance inst)
        {
            int session; using (var self = Process.GetCurrentProcess()) session = self.SessionId;
            foreach (var p in Process.GetProcessesByName("terminal"))
                using (p)
                {
                    try
                    {
                        if (p.HasExited || p.SessionId != session) continue;
                        string path = Processes.PathOf(p);
                        if (path == null) throw Error("An existing MT4 process cannot be identified. Close it before opening another copy.");
                        if (Canonical(path) == Canonical(inst.Exe)) throw Error("This MT4 copy is already running. Close it before changing its launch context.");
                    }
                    catch (InvalidOperationException) { }
                }
        }
        internal static bool ExpectedTerminal(string expectedBox, string expectedExe, ulong since, ISet<int> before, int pid, string actualBox, ulong created, string actualPath)
        {
            if (pid <= 0 || before.Contains(pid) || created < since || created == 0 || !string.Equals(expectedBox, actualBox, StringComparison.OrdinalIgnoreCase) || string.IsNullOrEmpty(actualPath)) return false;
            try { return Canonical(expectedExe) == Canonical(actualPath); }
            catch { return false; }
        }
        sealed class ManualGate : IDisposable
        {
            Mutex mutex;
            internal ManualGate(Mutex value) { mutex = value; }
            public void Dispose()
            {
                Mutex value = Interlocked.Exchange(ref mutex, null);
                if (value != null) { try { value.ReleaseMutex(); } finally { value.Dispose(); } }
            }
        }
        // Acquire and dispose on the same worker thread. This must enclose credential/config preparation,
        // not merely Process.Start, so another app instance cannot replace an active launch's ini file.
        public static IDisposable AcquireManualGate(Settings settings)
        {
            if (!IsEnabled(settings)) return new ManualGate(null);
            var gate = new Mutex(false, @"Local\MetaFactorySandbox_" + Hash(Canonical(AppPaths.DataDir)));
            bool held = false;
            try
            {
                try { held = gate.WaitOne(120000); } catch (AbandonedMutexException) { held = true; }
                if (!held) throw Error("Another MT4 launch is still pending. Try again after it finishes.");
                return new ManualGate(gate);
            }
            catch { if (held) gate.ReleaseMutex(); gate.Dispose(); throw; }
        }
        public static Process Start(Instance inst, Settings s, ProcessStartInfo nativePsi)
        {
            if (inst.Kind != Kind.MT4 || !IsEnabled(s)) return Process.Start(nativePsi);
            // One user-data scoped lock serializes assignment and launch discovery across app instances.
            string data = AppPaths.DataDir;
            Directory.CreateDirectory(data);
            using (var gate = new Mutex(false, @"Local\MetaFactorySandbox_" + Hash(Canonical(data))))
            {
                bool held = false;
                try
                {
                    try { held = gate.WaitOne(120000); } catch (AbandonedMutexException) { held = true; }
                    if (!held) throw Error("Another MT4 launch is still pending. Try again after it finishes.");
                    EnsureNotRunning(inst);
                    var native = Api(); // An installed but unusable dependency must never silently fall back.
                    string mapFile = Path.Combine(data, "sandbox-assignments.tsv");
                    var map = Assignments.Read(mapFile, data);
                    string box;
                    if (!map.Boxes.TryGetValue(Canonical(inst.Dir), out box) && NativeMt4Count() < NativeBudget)
                        return Process.Start(nativePsi);
                    string rule = ManagedDirectoryRule(inst.Dir);
                    box = map.Assign(inst.Dir);
                    // Persist before touching config: recovery after interruption retains the ownership marker.
                    map.Save(mapFile);
                    native.Configure(box, map.Owner, rule);
                    var before = new HashSet<int>(native.Pids(box));
                    ulong since = (ulong)DateTime.UtcNow.AddSeconds(-2).ToFileTimeUtc();
                    var psi = new ProcessStartInfo(Path.Combine(native.Home, "Start.exe"), "/silent /box:" + box + " /wait " + Quote(nativePsi.FileName) + " " + nativePsi.Arguments)
                    { UseShellExecute = false, WorkingDirectory = nativePsi.WorkingDirectory, CreateNoWindow = true };
                    foreach (string key in nativePsi.EnvironmentVariables.Keys) psi.EnvironmentVariables[key] = nativePsi.EnvironmentVariables[key];
                    Log.Write("sandbox launch: box=" + box + " native-mt4=" + NativeMt4Count().ToString(CultureInfo.InvariantCulture));
                    using (var launcher = Process.Start(psi))
                    {
                        var watch = Stopwatch.StartNew();
                        while (watch.ElapsedMilliseconds < 120000)
                        {
                            foreach (int pid in native.Pids(box))
                            {
                                if (before.Contains(pid)) continue;
                                var identity = native.Identity(pid);
                                if (!string.Equals(identity.Box, box, StringComparison.OrdinalIgnoreCase) || identity.Created < since) continue;
                                Process p = null;
                                try
                                {
                                    p = Process.GetProcessById(pid);
                                    string path = Processes.PathOf(p);
                                    if (ExpectedTerminal(box, inst.Exe, since, before, pid, identity.Box, identity.Created, path) && !p.HasExited)
                                    {
                                        Log.Write("sandbox terminal: box=" + box + " pid=" + pid.ToString(CultureInfo.InvariantCulture));
                                        Process result = p; p = null; return result;
                                    }
                                }
                                catch (ArgumentException) { }
                                catch (InvalidOperationException) { }
                                finally { if (p != null) p.Dispose(); }
                            }
                            if (launcher != null && launcher.HasExited && launcher.ExitCode != 0)
                                throw Error("Start.exe exited with code " + launcher.ExitCode.ToString(CultureInfo.InvariantCulture) + ". No terminal was verified.");
                            Thread.Sleep(200);
                        }
                    }
                    throw Error("Timed out identifying the actual MT4 process. No process was closed; inspect Sandboxie before retrying.");
                }
                finally { if (held) gate.ReleaseMutex(); }
            }
        }
        sealed class ProcessIdentity { internal string Box; internal ulong Created; }
        sealed class NativeApi
        {
            internal readonly string Home;
            readonly IntPtr library;
            readonly EnumProcesses enumerate;
            readonly QueryProcess query;
            readonly QueryConf conf;
            [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Unicode)] delegate int GetHomePath(IntPtr nt, uint ntChars, StringBuilder dos, uint dosChars);
            [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int EnumProcesses(IntPtr box, byte allSessions, uint session, [Out] uint[] pids, IntPtr count);
            [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Unicode)] delegate int QueryProcess(IntPtr pid, uint imageChars, StringBuilder box, StringBuilder image, StringBuilder sid, out uint session, out ulong created);
            [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Unicode)] delegate int QueryConf(string section, string setting, uint index, StringBuilder output, uint bytes);
            internal NativeApi(string home)
            {
                Home = home;
                string dll = Path.Combine(home, "SbieDll.dll");
                if (IntPtr.Size == 4 && Environment.Is64BitOperatingSystem) dll = Path.Combine(home, "32", "SbieDll.dll");
                library = LoadLibraryEx(dll, IntPtr.Zero, 0x00000100 | 0x00001000);
                if (library == IntPtr.Zero) throw Error("Cannot load the installed Sandboxie API (Windows error " + Marshal.GetLastWin32Error() + ").");
                try
                {
                    enumerate = (EnumProcesses)Export("SbieApi_EnumProcessEx", typeof(EnumProcesses));
                    query = (QueryProcess)Export("SbieApi_QueryProcessEx2", typeof(QueryProcess));
                    conf = (QueryConf)Export("SbieApi_QueryConf", typeof(QueryConf));
                    var homeQuery = (GetHomePath)Export("SbieApi_GetHomePath", typeof(GetHomePath));
                    var installed = new StringBuilder(2048);
                    int status = homeQuery(IntPtr.Zero, 0, installed, 2048);
                    if (status < 0 || installed.Length == 0 || Canonical(installed.ToString()) != Canonical(home))
                        throw Error("The installed Sandboxie driver and tools do not match. Repair the Sandboxie installation first.");
                    Pids(null); // Driver availability check, not merely a DLL-present check.
                    using (var self = Process.GetCurrentProcess())
                        if (!string.IsNullOrEmpty(Identity(self.Id).Box))
                            throw Error("Run MetaFactory outside Sandboxie so it can manage separate MT4 boxes safely.");
                }
                catch { FreeLibrary(library); throw; }
            }
            Delegate Export(string name, Type type)
            {
                IntPtr proc = GetProcAddress(library, name);
                if (proc == IntPtr.Zero) throw Error("The installed Sandboxie version lacks " + name + ".");
                return Marshal.GetDelegateForFunctionPointer(proc, type);
            }
            internal int[] Pids(string box)
            {
                IntPtr name = IntPtr.Zero;
                try
                {
                    if (box != null)
                    {
                        if (box.Length >= 38) throw Error("Invalid managed-box name.");
                        name = Marshal.AllocHGlobal(80); Marshal.Copy(new byte[80], 0, name, 80);
                        byte[] bytes = Encoding.Unicode.GetBytes(box); Marshal.Copy(bytes, 0, name, bytes.Length);
                    }
                    var pids = new uint[512]; int status = enumerate(name, 0, uint.MaxValue, pids, IntPtr.Zero);
                    if (status < 0 || pids[0] >= 511) throw Error("Sandboxie process enumeration failed (0x" + unchecked((uint)status).ToString("X8") + ").");
                    return pids.Skip(1).Take((int)pids[0]).Select(x => checked((int)x)).ToArray();
                }
                finally { if (name != IntPtr.Zero) Marshal.FreeHGlobal(name); }
            }
            internal ProcessIdentity Identity(int pid)
            {
                var box = new StringBuilder(40); var image = new StringBuilder(1024); var sid = new StringBuilder(96); uint session; ulong created;
                int status = query(new IntPtr(pid), 1024, box, image, sid, out session, out created);
                if (status < 0) return new ProcessIdentity { Box = "", Created = 0 }; // May have exited between enumeration and query.
                return new ProcessIdentity { Box = box.ToString(), Created = created };
            }
            string Value(string section, string setting, uint index)
            {
                var value = new StringBuilder(8192);
                int status = conf(section, setting, index | (section == null && setting == null ? 0x30000000u : ConfRawFlags), value, 16384);
                if (status == unchecked((int)0xC000008B)) return null; // STATUS_RESOURCE_NAME_NOT_FOUND (end of values).
                if (status < 0) throw Error("Sandboxie configuration query failed (0x" + unchecked((uint)status).ToString("X8") + ").");
                return value.ToString();
            }
            // CONF_GET_NO_GLOBAL | CONF_GET_NO_TEMPLS | CONF_GET_NO_EXPAND; pinned Sandboxie API definitions.
            const uint ConfRawFlags = 0x40000000 | 0x20000000 | 0x10000000;
            bool Has(string box, string setting, string value)
            {
                for (uint n = 0; n < 4096; n++)
                {
                    string found = Value(box, setting, n);
                    if (found == null) return false;
                    if (string.Equals(found, value, StringComparison.OrdinalIgnoreCase)) return true;
                }
                throw Error("Sandboxie configuration exceeds the supported value count.");
            }
            bool BoxExists(string box)
            {
                for (uint n = 0; n < 4096; n++)
                {
                    string found = Value(null, null, n);
                    if (found == null) return false;
                    if (string.Equals(found, box, StringComparison.OrdinalIgnoreCase)) return true;
                }
                throw Error("Sandboxie configuration exceeds the supported section count.");
            }
            void Write(string verb, string box, string setting, string value)
            {
                var psi = new ProcessStartInfo(Path.Combine(Home, "SbieIni.exe"), verb + " " + IniQuote(box) + " " + IniQuote(setting) + " " + IniQuote(value))
                { UseShellExecute = false, CreateNoWindow = true, WorkingDirectory = Home };
                using (var p = Process.Start(psi))
                {
                    if (p == null || !p.WaitForExit(15000)) throw Error("Sandboxie configuration did not finish. No terminal was launched.");
                    if (p.ExitCode != 0) throw Error("Sandboxie configuration failed (exit " + p.ExitCode.ToString(CultureInfo.InvariantCulture) + ").");
                }
                if (!Has(box, setting, value)) throw Error("Sandboxie did not retain the requested managed-box configuration.");
            }
            internal void Configure(string box, string owner, string dir)
            {
                if (!Path.IsPathRooted(dir) || string.Equals(Canonical(dir), Canonical(Path.GetPathRoot(dir)), StringComparison.OrdinalIgnoreCase))
                    throw Error("A whole drive cannot be opened to a managed box; select an individual MT4 copy directory.");
                bool exists = BoxExists(box);
                if (exists && !string.Equals(Value(box, "MetaFactoryOwnerId", 0), owner, StringComparison.Ordinal))
                    throw Error("A box with this name belongs to another configuration. It was not modified.");
                if (!exists) Write("set", box, "MetaFactoryOwnerId", owner);
                if (!string.Equals(Value(box, "Enabled", 0), "y", StringComparison.OrdinalIgnoreCase)) Write("set", box, "Enabled", "y");
                if (!string.Equals(Value(box, "AutoDelete", 0), "n", StringComparison.OrdinalIgnoreCase)) Write("set", box, "AutoDelete", "n");
                if (!Has(box, "OpenFilePath", dir)) Write("append", box, "OpenFilePath", dir);
            }
        }
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] static extern IntPtr LoadLibraryEx(string file, IntPtr reserved, uint flags);
        [DllImport("kernel32.dll")] static extern bool FreeLibrary(IntPtr module);
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true)] static extern IntPtr GetProcAddress(IntPtr module, string name);
    }
}
