using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace MTManager
{
    public enum ImportState { Invalid, Duplicate, Ready, Creating, Checking, Connected, Failed, Cancelled, Unconfirmed, Registered }

    public sealed class StudentImportRow
    {
        public int Line;
        public string Name = "", Platform = "", Login = "", Server = "", Investor = "", Folder = "", Copy = "", Reason = "";
        public string Mode = "investor", Master = "";
        public string SelectedPassword { get { return Mode == "master" ? Master : Investor; } }
        public string Redact(string text) { foreach (string secret in new[] { Investor, Master }) if (!string.IsNullOrEmpty(secret)) text = (text ?? "").Replace(secret, "***"); return text ?? ""; }
        public Kind Kind;
        public ImportState State;
        public Login Outcome = MTManager.Login.Waiting;
        public bool Saved { get { return Copy.Length > 0; } }
    }

    public sealed class ImportConnection
    {
        public bool Connected;
        public bool Retryable = true;
        public Login State = Login.Waiting;
        public string Reason = "";
    }

    public interface IStudentImportRuntime
    {
        // Save returns only after the account is durably saved. Connection failure must not remove it.
        string Save(StudentImportRow row);
        ImportConnection Connect(StudentImportRow row, Func<bool> cancel);
    }

    public interface IStudentImportProgress
    {
        void Configure(Func<bool> cancel, Action<string> stage);
    }

    public static class StudentImport
    {
        public static readonly string[] Headers = { "Name", "Platform", "Login", "Server", "Investor", "Folder", "Mode", "Master" };
        static readonly Dictionary<string, string> Aliases = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) {
            { "Name", "Name" }, { "Trader", "Name" }, { "نام", "Name" }, { "نام دانشجو", "Name" },
            { "Platform", "Platform" }, { "MT", "Platform" }, { "متاتریدر", "Platform" },
            { "Login", "Login" }, { "Account", "Login" }, { "شماره حساب", "Login" },
            { "Server", "Server" }, { "سرور", "Server" },
            { "Mode", "Mode" }, { "LoginMode", "Mode" }, { "Login Mode", "Mode" }, { "PasswordType", "Mode" }, { "نوع ورود", "Mode" },
            { "Master", "Master" }, { "MasterPassword", "Master" }, { "Master Password", "Master" }, { "Master_Password", "Master" }, { "رمز مستر", "Master" },
            { "Password", "Password" }, { "رمز", "Password" },
            { "Investor", "Investor" }, { "InvestorPassword", "Investor" }, { "Investor Password", "Investor" }, { "Investor_Password", "Investor" }, { "رمز اینوستور", "Investor" },
            { "Folder", "Folder" }, { "پوشه", "Folder" }, { "گروه", "Folder" }
        };

        public static string Key(Kind kind, string login, string server)
        {
            string number = TextUtil.LatinDigits((login ?? "").Trim()).TrimStart('0');
            return kind + "|" + number + "|" + ServerCatalog.Norm(server);
        }

        public static List<StudentImportRow> Read(string path, IEnumerable<string> existing)
        {
            return Plan(Spreadsheet.ReadForImport(path), existing);
        }

        public static List<StudentImportRow> Plan(IList<SheetRow> input, IEnumerable<string> existing)
        {
            if (input.Count == 0) throw new UserMessage(Lang.T("فایل خالی است.", "The file is empty."));
            var columns = new Dictionary<string, int>();
            foreach (var cell in input[0].Cells)
            {
                string key;
                if (!Aliases.TryGetValue(cell.Value.Trim().TrimStart('\uFEFF'), out key)) continue;
                if (columns.ContainsKey(key)) throw new UserMessage(Lang.T("ستون تکراری: ", "Duplicate column: ") + key);
                columns.Add(key, cell.Key);
            }
            string[] missing = Headers.Take(4).Where(h => !columns.ContainsKey(h)).ToArray();
            if (missing.Length > 0) throw new UserMessage(Lang.T("ستون‌های لازم پیدا نشد: ", "Missing required columns: ") + string.Join(", ", missing));
            if (!new[] { "Investor", "Master", "Password" }.Any(columns.ContainsKey)) throw new UserMessage(Lang.T("ستون رمز Investor، Master یا Password لازم است.", "An Investor, Master or Password column is required."));
            var seen = new HashSet<string>(existing ?? new string[0], StringComparer.OrdinalIgnoreCase);
            var rows = new List<StudentImportRow>();
            foreach (SheetRow source in input.Skip(1))
            {
                Func<string, string> get = key => { int col; string value; return columns.TryGetValue(key, out col) && source.Cells.TryGetValue(col, out value) ? value : ""; };
                var r = new StudentImportRow { Line = source.Number, Name = TextUtil.OneLine(get("Name")), Platform = TextUtil.LatinDigits(get("Platform").Trim()).ToUpperInvariant(), Login = TextUtil.LatinDigits(get("Login").Trim()), Server = get("Server").Trim(), Investor = get("Investor"), Master = get("Master"), Folder = TextUtil.OneLine(get("Folder")), State = ImportState.Ready };
                var errors = new List<string>();
                string mode = get("Mode").Trim().ToLowerInvariant();
                if (mode == "اینوستور" || mode == "readonly" || mode == "read-only") mode = "investor";
                if (mode == "مستر") mode = "master";
                if (mode.Length == 0) mode = r.Master.Length > 0 && r.Investor.Length == 0 ? "master" : "investor";
                r.Mode = mode;
                if (mode != "master" && mode != "investor") errors.Add(Lang.T("نوع ورود باید investor یا master باشد", "Mode must be investor or master"));
                if (mode == "master" && r.Master.Length == 0) r.Master = get("Password");
                if (mode == "investor" && r.Investor.Length == 0) r.Investor = get("Password");
                if (source.Problem.Length > 0) errors.Add(source.Problem);
                if (r.Name.Length == 0) errors.Add(Lang.T("نام دانشجو خالی است", "Student name is empty"));
                if (r.Platform == "4") r.Platform = "MT4";
                if (r.Platform == "5") r.Platform = "MT5";
                if (r.Platform != "MT4" && r.Platform != "MT5") errors.Add(Lang.T("متاتریدر باید MT4 یا MT5 باشد", "Platform must be MT4 or MT5"));
                r.Kind = r.Platform == "MT4" ? Kind.MT4 : Kind.MT5;
                if (!Regex.IsMatch(r.Login, "^[0-9]{1,20}$") || r.Login.All(c => c == '0')) errors.Add(Lang.T("شماره حساب را به صورت متن و فقط رقم وارد کنید، نه نماد علمی Excel", "Account must be text containing digits, not Excel scientific notation"));
                if (source.Numeric.Contains(columns["Login"]) && r.Login.Length > 15) errors.Add(Lang.T("Excel شماره حساب عددیِ بیش از ۱۵ رقم را گرد می‌کند؛ شماره اصلی را با قالب Text وارد کنید", "Excel rounds numeric accounts longer than 15 digits; enter the original account as Text"));
                if (r.Server.Length == 0) errors.Add(Lang.T("سرور خالی است", "Server is empty"));
                else if (r.Server != TextUtil.OneLine(r.Server)) errors.Add(Lang.T("سرور نباید چندخطی باشد", "Server must be one line"));
                string passwordName = r.Mode == "master" ? Lang.T("رمز مستر", "Master password") : Lang.T("رمز اینوستور", "Investor password");
                if (r.SelectedPassword.Length == 0) errors.Add(passwordName + Lang.T(" خالی است", " is empty"));
                foreach (var named in new[] { new KeyValuePair<string, string>("Investor", r.Investor), new KeyValuePair<string, string>("Master", r.Master) })
                {
                    string bad = PasswordRule.Problem(named.Value);
                    if (bad != null) errors.Add(named.Key + ": " + bad);
                }
                if (errors.Count > 0) { r.State = ImportState.Invalid; r.Reason = string.Join("؛ ", errors); }
                else if (!seen.Add(Key(r.Kind, r.Login, r.Server))) { r.State = ImportState.Duplicate; r.Reason = Lang.T("این حساب در برنامه یا در ردیف قبلی فایل وجود دارد؛ اطلاعات قبلی تغییر نمی‌کند.", "Account already exists in the app or an earlier row; existing data is unchanged."); }
                rows.Add(r);
            }
            if (rows.Count == 0) throw new UserMessage(Lang.T("فایل هیچ دانشجویی ندارد؛ از ردیف دوم اطلاعات را بنویسید.", "No students in this file; enter data from row 2."));
            return rows;
        }

        public static string Status(ImportState s)
        {
            switch (s)
            {
                case ImportState.Invalid: return Lang.T("اطلاعات ناقص/نامعتبر", "Invalid data");
                case ImportState.Duplicate: return Lang.T("تکراری؛ رد شد", "Duplicate; skipped");
                case ImportState.Registered: return Lang.T("ثبت شد؛ در صف بررسی", "Registered; verification queued");
                case ImportState.Ready: return Lang.T("آماده", "Ready");
                case ImportState.Creating: return Lang.T("در حال افزودن", "Adding");
                case ImportState.Checking: return Lang.T("در حال بررسی اتصال", "Checking connection");
                case ImportState.Connected: return Lang.T("متصل شد", "Connected");
                case ImportState.Failed: return Lang.T("ناموفق", "Failed");
                case ImportState.Unconfirmed: return Lang.T("اتصال تأیید نشد", "Connection unconfirmed");
                default: return Lang.T("متوقف شد", "Stopped");
            }
        }

        public static void Run(IEnumerable<StudentImportRow> rows, IStudentImportRuntime runtime, Func<bool> cancel, Action<StudentImportRow> progress)
        {
            foreach (StudentImportRow r in rows)
            {
                if (r.State != ImportState.Ready) continue;
                if (cancel()) { r.State = ImportState.Cancelled; r.Reason = Lang.T("پیش از شروع این ردیف متوقف شد.", "Stopped before starting this row."); progress(r); continue; }
                try
                {
                    var reporting = runtime as IStudentImportProgress;
                    long notified = -1000;
                    var clock = Stopwatch.StartNew();
                    if (reporting != null) reporting.Configure(cancel, text => {
                        text = r.Redact(text);
                        r.Reason = text;
                        if (clock.ElapsedMilliseconds - notified >= 150) { notified = clock.ElapsedMilliseconds; progress(r); }
                    });
                    r.State = ImportState.Creating; progress(r);
                    Log.Write("bulk row " + r.Line + ": preparing");
                    if (!r.Saved) r.Copy = runtime.Save(r);
                    if (cancel()) { r.State = ImportState.Cancelled; r.Reason = Lang.T("ذخیره شد؛ بررسی اتصال متوقف شد.", "Saved; connection check was stopped."); progress(r); continue; }
                    r.State = ImportState.Checking; progress(r);
                    Log.Write("bulk row " + r.Line + ": saved; checking connection");
                    ImportConnection result = runtime.Connect(r, cancel);
                    r.Outcome = result.State;
                    r.State = Outcome(result, cancel());
                    r.Reason = result.Reason;
                }
                catch (OperationCanceledException) { r.State = ImportState.Cancelled; r.Reason = Lang.T("به درخواست شما متوقف شد؛ ردیف‌های بعدی شروع نمی‌شوند.", "Stopped at your request; later rows will not start."); }
                catch (Exception e) { r.State = ImportState.Failed; r.Reason = e.Message; }
                // Never export a password through exception text, even from a future runtime implementation.
                r.Reason = r.Redact(r.Reason);
                Log.Write("bulk row " + r.Line + ": " + r.State + ", saved=" + r.Saved);
                progress(r);
            }
        }

        public static ImportState Outcome(ImportConnection result, bool cancelled)
        {
            if (cancelled) return ImportState.Cancelled;
            if (result.Connected) return ImportState.Connected;
            return result.State == Login.Waiting ? ImportState.Unconfirmed : ImportState.Failed;
        }

        public static void Template(string path)
        {
            Spreadsheet.Write(path, new List<string[]> { Headers, new[] { "", "MT5", "", "", "", "", "investor", "" } }, new[] {
                "MetaFactory — ورود گروهی دانشجوها / Bulk student import",
                "در شیت Students، ردیف دوم را با اولین دانشجوی واقعی جایگزین کنید. هر سطر یک حساب است. / One account per row, starting at row 2.",
                "Name: نام دانشجو / Student name (required)", "Platform: فقط MT4 یا MT5 / MT4 or MT5 (required)",
                "Login: شماره حساب؛ قالب ستون Text بماند تا ارقام و صفر اول عوض نشود. / Account number; keep the column formatted as Text.",
                "Server: نام دقیق سرور حساب، نه فقط نام بروکر / Exact account server name, not just broker name (required)",
                "Investor: رمز اینوستور، یا Master: رمز مستر. Mode را investor یا master انتخاب کنید؛ رمز نوع انتخاب‌شده لازم است. / Set Mode to investor or master and provide the matching password.",
                "Folder: نام یک پوشه‌ی گروه‌بندی داخل برنامه؛ اختیاری، مسیر روی دیسک نیست. / Optional group name, not a disk path.",
                "ستون‌ها را حذف نکنید؛ ترتیبشان می‌تواند عوض شود. فرمول استفاده نکنید؛ Paste Values کنید. / Keep headers; column order may change. Paste values, not formulas.",
                "فقط شیت اول خوانده می‌شود؛ حداکثر ۱۰۰۰ دانشجو. فایل قدیمی .xls را با نام .xlsx ذخیره کنید. / First sheet only; up to 1,000 students. Save old .xls files as .xlsx.",
                "حساب تکراری تغییر نمی‌کند. حساب ذخیره‌شده با اتصال ناموفق در برنامه می‌ماند تا بتوانید اصلاحش کنید. / Duplicates are skipped. Saved accounts remain even if connection fails.",
                "فایل ورودی حاوی رمزهای قابل خواندن است؛ آن را فقط در محل امن نگه دارید. گزارش نتیجه هیچ رمزی ندارد. / Input contains readable passwords; store it privately. Results never include passwords."
            });
        }

        public static void Export(string path, IEnumerable<StudentImportRow> input)
        {
            var rows = new List<string[]> { new[] { "Row", "Name", "Platform", "Login", "Server", "Folder", "Copy", "Saved", "Status", "Reason", "Mode" } };
            rows.AddRange(input.Select(r => new[] { r.Line.ToString(CultureInfo.InvariantCulture), r.Name, r.Platform, r.Login, r.Server, r.Folder, r.Copy, r.Saved ? "Yes" : "No", Status(r.State), r.Redact(r.Reason), r.Mode }));
            Spreadsheet.Write(path, rows);
        }
    }

    public sealed class StudentImportRuntime : IStudentImportRuntime, IStudentImportProgress, IDisposable
    {
        readonly Settings settings;
        readonly AccountStore accounts;
        readonly FolderStore folders;
        readonly string defaultFolder;
        Instance previousCopy;
        bool needsRelease;
        readonly ImportCleanup cleanup = new ImportCleanup();
        void DrainCleanup()
        {
            if (cleanup.Pending) stage(Lang.T("منتظر بسته‌شدن نسخه‌ی قبلی…", "Waiting for the previous terminal to close…"));
            bool closed = cleanup.Drain();
            if (previousCopy != null && (needsRelease || !closed))
            {
                Instance previous = previousCopy;
                WaitForRelease(() => Processes.IsRunning(Processes.Running(), previous.Exe), cancel,
                    () => stage(Lang.T("منتظر بسته‌شدن نسخه‌ی قبلی؛ پس از بسته‌شدن خودکار ادامه می‌یابد…", "Waiting for the previous terminal to close; import will resume automatically…")));
            }
            previousCopy = null; needsRelease = false;
        }
        // With no next launch to protect, only join the teardown we started. Do not make closing the
        // import dialog depend on an unrelated/restarted process at the same path being closed by hand.
        public void Dispose() { cleanup.Dispose(); }

        public static void WaitForRelease(Func<bool> running, Func<bool> cancel, Action waiting)
        {
            while (true)
            {
                if (cancel()) throw new OperationCanceledException();
                if (!running()) return;
                waiting();
                Thread.Sleep(250);
            }
        }

        Func<bool> cancel = () => false;
        Action<string> stage = text => { };
        readonly Dictionary<string, string> sources = new Dictionary<string, string>();
        readonly Dictionary<string, string> sourceErrors = new Dictionary<string, string>();
        public void Configure(Func<bool> cancel, Action<string> stage) { this.cancel = cancel; this.stage = stage; }

        // Only read-only discovery runs on this bounded background task; no late account/file writes.
        public static string FindWithDeadline(Func<string> find, Func<bool> cancel, int milliseconds)
        {
            Task<string> task = Task.Factory.StartNew(find);
            task.ContinueWith(t => { var observed = t.Exception; }, TaskContinuationOptions.OnlyOnFaulted | TaskContinuationOptions.ExecuteSynchronously);
            var clock = Stopwatch.StartNew();
            while (!task.IsCompleted)
            {
                if (cancel()) throw new OperationCanceledException();
                if (clock.ElapsedMilliseconds >= milliseconds) throw new TimeoutException(Lang.T("جستجوی نصب متاتریدر بیش از حد طول کشید؛ مسیر نصب و دسترسی دیسک را بررسی کنید.", "Finding the MetaTrader installation timed out; check installation paths and disk access."));
                Thread.Sleep(20);
            }
            if (cancel()) throw new OperationCanceledException();
            return task.GetAwaiter().GetResult();
        }
        public StudentImportRuntime(Settings settings, AccountStore accounts, FolderStore folders, string defaultFolder)
        { this.settings = settings; this.accounts = accounts; this.folders = folders; this.defaultFolder = defaultFolder; }

        public string Save(StudentImportRow row)
        {
            var clock = Stopwatch.StartNew();
            Func<bool> interrupted = () => {
                if (cancel()) throw new OperationCanceledException();
                if (clock.Elapsed.TotalSeconds >= 180) throw new TimeoutException(Lang.T("آماده‌سازی نسخه در ۱۸۰ ثانیه تمام نشد؛ فضای دیسک، حجم پوشه‌ی مبدأ و دسترسی فایل‌ها را بررسی کنید.", "Copy preparation exceeded 180 seconds; check disk space, source size and file access."));
                return false;
            };
            string group = row.Folder.Length == 0 ? defaultFolder : row.Folder;
            Folder into = string.IsNullOrEmpty(group) ? null : folders.Find(group);
            if (into == null && !string.IsNullOrEmpty(group))
            {
                string problem = folders.NameProblem(group);
                if (problem != null) throw new UserMessage(problem);
            }
            stage(Lang.T("جستجوی نصب متاتریدر…", "Finding MetaTrader installation…"));
            string source, sourceKey = row.Kind + "|" + row.Server;
            string previousError;
            if (sourceErrors.TryGetValue(sourceKey, out previousError)) throw new UserMessage(previousError);
            if (!sources.TryGetValue(sourceKey, out source))
            {
                try { source = FindWithDeadline(() => { bool sure; return ServerCatalog.InstallFor(row.Kind, row.Server, settings, out sure); }, cancel, 30000); }
                catch (TimeoutException e) { sourceErrors[sourceKey] = e.Message; throw; }
                sources[sourceKey] = source;
            }
            if (source == null) throw new UserMessage(row.Kind + Lang.T(" نصب نیست؛ متاتریدر بروکر را نصب کنید.", " is not installed; install the broker's MetaTrader."));
            string enc = Secret.Protect(row.Investor);
            string masterEnc = Secret.Protect(row.Master);
            string name = row.Kind + "-" + CopyMaker.NextIndex(settings.AllFolders, row.Kind.ToString()).ToString("00");
            string dest = Path.Combine(settings.BaseDir, name);
            bool existed = Directory.Exists(dest), saved = false;
            try
            {
                stage(Lang.T("بررسی فضای دیسک و آماده‌سازی نسخه…", "Checking disk space and preparing copy…"));
                name = CopyMaker.Create(new CreateRequest { Kind = row.Kind, Source = source, Count = 1, Prefix = row.Kind.ToString(), Folder = settings.BaseDir, CopyData = false }, settings, null, interrupted,
                    file => stage(Lang.T("کپی فایل: ", "Copying file: ") + file))[0];
                stage(Lang.T("ذخیره‌ی حساب دانشجو…", "Saving student account…"));
                accounts.Set(new Account { Instance = name, Trader = row.Name, Login = row.Login, Server = row.Server, Mode = row.Mode, InvestorEnc = enc, MasterEnc = masterEnc });
                accounts.Save(); saved = true;
                // Set immediately: a subsequent grouping failure must not conceal a saved account.
                row.Copy = name;
                row.Folder = group ?? "";
                if (into == null && !string.IsNullOrEmpty(group)) into = folders.Create(group);
                if (into != null) { folders.Add(into.Id, new[] { name }); folders.Save(); }
                return name;
            }
            catch
            {
                if (!saved)
                {
                    accounts.Remove(name);
                    if (!existed && Directory.Exists(dest)) { try { Directory.Delete(dest, true); } catch { } }
                }
                throw;
            }
        }

        public static ImportConnection Describe(LoginResult r)
        {
            switch (r.State)
            {
                case Login.Connected: return new ImportConnection { Connected = true, State = r.State, Reason = Lang.T("ورود در ژورنال متاتریدر تأیید شد.", "Login confirmed in MetaTrader's journal.") };
                case Login.WrongLogin:
                    return new ImportConnection { State = r.State, Reason = (r.Detail ?? "").IndexOf("invalid password", StringComparison.OrdinalIgnoreCase) >= 0
                        ? Lang.T("رمز حساب توسط سرور رد شد.", "Password was rejected by the server.")
                        : Lang.T("شماره حساب یا رمز رد شد، یا حساب غیرفعال است؛ متاتریدر علت را دقیق‌تر مشخص نکرد.", "Account/password rejected or account disabled; MetaTrader did not distinguish the cause.") };
                case Login.NoServer: return new ImportConnection { State = r.State, Reason = Lang.T("متاتریدر سرور حساب را پیدا نکرد؛ نام دقیق سرور و نصب بروکر را بررسی کنید.", "MetaTrader could not find the account server; check its exact name and broker installation.") };
                case Login.NoConnection: return new ImportConnection { State = r.State, Reason = Lang.T("اتصال به سرور برقرار نشد؛ اینترنت یا دسترسی بروکر را بررسی کنید. اشتباه بودن رمز تأیید نشده.", "Could not connect to the server; check Internet/broker access. A wrong password was not confirmed.") };
                default: return new ImportConnection { Reason = Lang.T("در مهلت بررسی پاسخ قطعی نرسید؛ اتصال تأیید نشده است.", "No conclusive response before timeout; connection is unconfirmed.") };
            }
        }

        /// <summary>MT4 can buffer its journal. Decide only AFTER this operation's own terminal has closed and flushed.</summary>
        public static ImportConnection ReadAfterClose(LoginWatch watch, Instance copy, string login, DateTime since, Action close, Func<bool> exited)
        {
            close();
            if (!exited()) return Describe(new LoginResult { State = Login.Waiting });
            return Describe(watch.CompleteClosed(copy, login, since, DateTime.Now));
        }

        // A terminal can keep successful login messages in memory until it closes. Flush once early;
        // if there is still no proof, restart and use the remainder of the original 90-second budget.
        public static bool ShouldFlushEarly(Kind kind, double seconds, double windowSeconds, Login state)
        { return (kind == Kind.MT4 || kind == Kind.MT5) && seconds >= (kind == Kind.MT5 ? 8 : 12) && windowSeconds >= 3 && (state == Login.Waiting || state == Login.NoConnection); }

        public ImportConnection Connect(StudentImportRow row, Func<bool> cancel)
        {
            DrainCleanup();
            var copy = new Instance { Name = row.Copy, Kind = row.Kind, Dir = Path.Combine(settings.BaseDir, row.Copy) };
            if (Processes.IsRunning(Processes.Running(), copy.Exe))
                return new ImportConnection { Reason = Lang.T("متاتریدر این دانشجو از قبل باز است؛ آن را ببندید و دوباره بررسی کنید. فرایند قبلی دست‌نخورده ماند.", "This student's terminal is already open; close it and retry. The existing process was left untouched.") };
            if (row.Kind == Kind.MT4 && !Mt4Limit.Room(Processes.Mt4InSession(), settings.MaxMt4))
                return new ImportConnection { Reason = Lang.T("سقف نسخه‌های باز MT4 پر است؛ چند MT4 را ببندید و دوباره بررسی کنید.", "The open MT4 limit is full; close some MT4 terminals and check again.") };
            var budget = Stopwatch.StartNew();
            bool again;
            ImportConnection result = Attempt(copy, row, cancel, budget, true, out again);
            if (again && !cancel() && budget.Elapsed.TotalSeconds < 90)
            {
                stage(Lang.T("تأیید اولیه کافی نبود؛ ادامه‌ی بررسی کامل…", "Initial confirmation was inconclusive; continuing the full check…"));
                DrainCleanup();
                return Attempt(copy, row, cancel, budget, false, out again);
            }
            return result;
        }

        ImportConnection Attempt(Instance copy, StudentImportRow row, Func<bool> cancel, Stopwatch budget, bool quick, out bool again)
        {
            again = false;
            StartResult started = null;
            bool confirmed = false;
            DateTime since = DateTime.Now;
            var sessionClock = Stopwatch.StartNew();
            var watch = new LoginWatch();
            watch.BeginSession(copy, row.Login, since);
            try
            {
                if (cancel()) throw new OperationCanceledException();
                stage(Lang.T("باز کردن متاتریدر برای بررسی اتصال…", "Opening MetaTrader to check connection…"));
                started = Launcher.Start(copy, settings, accounts);
                if (!string.IsNullOrEmpty(started.Warning)) throw new UserMessage(started.Warning);
                if (started.Process == null) throw new UserMessage(Lang.T("فرایند متاتریدر شروع نشد.", "MetaTrader process did not start."));
                var pending = new PendingStart { Path = started.StartFile, Copy = copy, Process = started.Process, Time = since };
                DateTime? exitedAt = null;
                double? windowAt = null;
                while (budget.Elapsed.TotalSeconds < 90)
                {
                    stage(Lang.T("منتظر تأیید ورود از متاتریدر: ", "Waiting for MetaTrader login confirmation: ") + (int)budget.Elapsed.TotalSeconds + Lang.T(" از ۹۰ ثانیه", " of 90 seconds"));
                    if (cancel()) return new ImportConnection { Reason = Lang.T("ذخیره شد؛ بررسی اتصال به درخواست شما متوقف شد.", "Saved; connection check stopped at your request.") };
                    if (pending.Path != null && pending.Ready(DateTime.Now) != null) { Launcher.DeleteStartFile(pending.Path); pending.Path = null; }
                    watch.Update(copy, row.Login, since, DateTime.Now);
                    LoginResult result = watch.AttemptResult;
                    if (result.State == Login.Connected || result.State == Login.WrongLogin || result.State == Login.NoServer)
                    { confirmed = result.State == Login.Connected; Log.Write("bulk check " + copy.Name + ": " + result.State + " after " + budget.ElapsedMilliseconds + " ms"); return Describe(result); }
                    started.Process.Refresh();
                    if (started.Process.HasExited)
                    {
                        if (!exitedAt.HasValue) exitedAt = DateTime.Now;
                        if ((DateTime.Now - exitedAt.Value).TotalSeconds >= 3)
                        {
                            LoginResult flushed = watch.CompleteClosed(copy, row.Login, since, DateTime.Now);
                            if (flushed.State != Login.Waiting) { confirmed = flushed.State == Login.Connected; return Describe(flushed); }
                            return new ImportConnection { Reason = SelfUpdate.Since(copy, since)
                                ? Lang.T("متاتریدر برای به‌روزرسانی بسته شد؛ پس از پایان به‌روزرسانی دوباره اتصال را بررسی کنید.", "MetaTrader closed for an update; check again after the update completes.")
                                : Lang.T("متاتریدر پیش از تأیید اتصال بسته شد؛ از «بررسی اتصال» دوباره امتحان کنید.", "MetaTrader closed before login was confirmed; retry using Check connection.") };
                        }
                    }
                    else
                    {
                        if (started.Process.MainWindowHandle != IntPtr.Zero) { if (!windowAt.HasValue) windowAt = sessionClock.Elapsed.TotalSeconds; }
                        else windowAt = null;
                        if (quick && ShouldFlushEarly(row.Kind, sessionClock.Elapsed.TotalSeconds, windowAt.HasValue ? sessionClock.Elapsed.TotalSeconds - windowAt.Value : 0, result.State))
                        {
                            stage(Lang.T("بررسی زودهنگام تأیید ورود ", "Checking buffered login confirmation early: ") + row.Kind + "…");
                            Log.Write("bulk check " + copy.Name + ": early journal flush after " + budget.ElapsedMilliseconds + " ms");
                            ImportConnection early = Flush(watch, copy, row.Login, since, started.Process);
                            Log.Write("bulk check " + copy.Name + ": flushed outcome " + early.State + " after " + budget.ElapsedMilliseconds + " ms");
                            if (early.Connected || early.State == Login.WrongLogin || early.State == Login.NoServer) { confirmed = early.Connected; return early; }
                            started.Process.Refresh();
                            again = started.Process.HasExited;
                            return early;
                        }
                    }
                    Thread.Sleep(150);
                }
                stage(Lang.T("بازخوانی نهایی ژورنال پس از بستن نسخه‌ی بررسی…", "Re-reading the journal after closing the checked terminal…"));
                ImportConnection final = Flush(watch, copy, row.Login, since, started.Process);
                if (!final.Connected && final.State == Login.Waiting)
                    final.Reason += " " + (watch.JournalSeen
                        ? Lang.T("فایل ژورنال خوانده شد اما پیام ورود این حساب شناسایی نشد.", "The journal was read, but this account's login confirmation was not recognized.")
                        : Lang.T("فایل ژورنال این نسخه در دسترس نبود.", "This copy's journal file was unavailable."));
                confirmed = final.Connected;
                return final;
            }
            finally
            {
                Launcher.DeleteStartFile(Path.Combine(copy.Dir, Launcher.StartFileName));
                if (started != null && started.Process != null)
                {
                    Process process = started.Process;
                    // Publishing confirmed login must not wait for chart/settings shutdown. At most one cleanup
                    // overlaps preparation of the next row; it is joined before another terminal is launched.
                    previousCopy = copy;
                    if (confirmed) cleanup.Start(() => CloseOwned(process, copy));
                    else needsRelease = !CloseOwned(process, copy);
                }
            }
        }

        static ImportConnection Flush(LoginWatch watch, Instance copy, string login, DateTime since, Process process)
        {
            return ReadAfterClose(watch, copy, login, since, () => {
                int pid = process.Id;
                SafeClose.Close(new ProcessTarget(process), id => id == pid, 2, Log.Write);
            }, () => { process.Refresh(); return process.HasExited; });
        }

        static bool CloseOwned(Process process, Instance copy)
        {
            try
            {
                int pid = process.Id;
                SafeClose.Close(new ProcessTarget(process), id => id == pid, 2, Log.Write);
                return !Processes.IsRunning(Processes.Running(), copy.Exe);
            }
            catch (Exception e) { Log.Write("bulk cleanup " + copy.Name + ": " + e.GetType().Name); return false; }
            finally { process.Dispose(); }
        }
    }

    /// <summary>One bounded teardown job; joining it before the next launch prevents terminal accumulation.</summary>
    public sealed class ImportCleanup : IDisposable
    {
        Task<bool> pending;
        public bool Pending { get { return pending != null && !pending.IsCompleted; } }
        public void Start(Func<bool> close)
        {
            if (pending != null) throw new InvalidOperationException("Previous terminal cleanup was not joined.");
            pending = Task.Factory.StartNew(close, CancellationToken.None, TaskCreationOptions.None, TaskScheduler.Default);
        }
        public bool Drain()
        {
            if (pending == null) return true;
            Task<bool> task = pending; pending = null;
            try { return task.GetAwaiter().GetResult(); }
            catch (Exception e) { Log.Write("bulk cleanup: " + e.GetType().Name); return false; }
        }
        public void Dispose() { Drain(); }
    }
}
