using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MTManager
{
    /// <summary>3.21: the report under a student's row (approved mockup): the range at the top right, when it was read and «به‌روزرسانی» at
    /// the left; five numbers (Trades, Net, Risk / trade, Stop loss, Daily DD); the warnings, only when there are any; and the trades
    /// (one day) or the days (several, each opening on its trades). Painted, like the list it sits in.</summary>
    sealed class ReportPanel : Control
    {
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
        static string[] RangeNames { get { return new[] { Lang.T("امروز", "Today"), Lang.T("دیروز", "Yesterday"), Lang.T("این هفته", "This week"), Lang.T("این ماه", "This month"), Lang.T("بازه…", "Range…") }; } }

        /// <summary>The numbers of the range shown; null when this student has not been read yet.</summary>
        public PanelView View;
        public PanelRange Range = PanelRange.Today;
        /// <summary>The range in words, at the top ("چهارشنبه 2026.11.11 · از 00:00 سرور تا الان").</summary>
        public string RangeText = "";
        public bool Busy;
        public string BusyText;
        /// <summary>Why the last read did not work; null when it did.</summary>
        public string Error;
        /// <summary>When this student was last read, on this computer's clock.</summary>
        public DateTime? ReadLocal;
        /// <summary>The history kept does not reach back to the range's first day: it must be read.</summary>
        public bool NotCovered;
        public bool HasAccount = true;

        public event Action<PanelRange> RangeWanted;
        public event Action<DateTime, DateTime> CustomWanted;
        public event Action RefreshWanted;
        /// <summary>3.22.1: «کپی متن روز» (one day shown).</summary>
        public event Action CopyWanted;
        /// <summary>The wheel was turned with nothing left to scroll here: the list scrolls (+1 down, -1 up).</summary>
        public event Action<int> ScrollList;

        readonly TextBox fromBox = DateBox(), toBox = DateBox();
        readonly HashSet<DateTime> openDays = new HashSet<DateTime>();
        readonly List<KeyValuePair<Rectangle, Action>> hits = new List<KeyValuePair<Rectangle, Action>>();
        Point mouse = new Point(-1, -1);
        int scroll, contentHeight, tableArea;

        static int P(int px) { return Theme.S(px); }

        static TextBox DateBox()
        {
            return new TextBox { BorderStyle = BorderStyle.FixedSingle, Font = Theme.Font, RightToLeft = RightToLeft.No, TextAlign = HorizontalAlignment.Center, Visible = false, MaxLength = 10 };
        }

        public ReportPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            BackColor = Theme.Alt;
            Font = Theme.Font;
            Controls.Add(fromBox);
            Controls.Add(toBox);
            KeyEventHandler enter = (s, e) => { if (e.KeyCode == Keys.Enter) { ShowCustom(); e.Handled = true; e.SuppressKeyPress = true; } };
            fromBox.KeyDown += enter;
            toBox.KeyDown += enter;
        }

        public void SetCustom(DateTime from, DateTime to)
        {
            fromBox.Text = from.ToString("yyyy.MM.dd", Inv);
            toBox.Text = to.ToString("yyyy.MM.dd", Inv);
        }

        void ShowCustom()
        {
            DateTime? a = Gd.Parse(fromBox.Text), b = Gd.Parse(toBox.Text);
            if (a == null || b == null)
            {
                Ui.Message(FindForm(), Lang.T("تاریخ‌ها را میلادی و به شکل 2026.11.01 بنویسید.", "Write the dates in the Gregorian calendar, like 2026.11.01."), MessageBoxIcon.Warning);
                return;
            }
            if (CustomWanted != null) CustomWanted(a.Value, b.Value);
        }

        /// <summary>A day of the range was opened or closed (several days).</summary>
        void Toggle(DateTime day)
        {
            if (!openDays.Remove(day)) openDays.Add(day);
            Changed();
        }

        /// <summary>New data: the height it wants may change (the list asks again through Wanted).</summary>
        public void Changed()
        {
            Invalidate();
            if (HeightChanged != null) HeightChanged();
        }

        public event Action HeightChanged;

        public void ResetDays() { openDays.Clear(); scroll = 0; }

        /// <summary>A day of several opened on its trades, as a click on it does.</summary>
        public void OpenDay(DateTime day) { openDays.Add(day); Changed(); }

        // ------------------------------------------------------------- sizes

        const int Top = 12, Bar = 32, Gap = 12, Tile = 76, Flags = 24, Head = 28, RowH = 28, Bottom = 14;

        /// <summary>The height everything needs at this width (the list gives the panel at most what fits).</summary>
        public int Wanted()
        {
            int h = P(Top + Bar + Gap);
            if (View == null) return h + P(48 + Bottom);
            h += P(Tile + 10);
            if (View.Flags.Count > 0) h += P(Flags + 8);
            if (View.HistoryNote != null || Error != null) h += P(22) * ((View.HistoryNote != null ? 1 : 0) + (Error != null ? 1 : 0));
            if (NotCovered) h += P(40);
            h += P(Head) + P(RowH) * Math.Max(1, TableRows().Count) + P(Bottom) + P(4);
            return h;
        }

        sealed class TableRow
        {
            public PanelDay Day;
            public PanelTrade Trade;
            public bool Nested;
        }

        List<TableRow> TableRows()
        {
            var rows = new List<TableRow>();
            if (View == null) return rows;
            if (View.SingleDay) rows.AddRange(View.Trades.Select(t => new TableRow { Trade = t }));
            else
                foreach (PanelDay d in View.Days)
                {
                    rows.Add(new TableRow { Day = d });
                    if (openDays.Contains(d.Day)) rows.AddRange(View.Trades.Where(t => t.Day == d.Day).Select(t => new TableRow { Trade = t, Nested = true }));
                }
            return rows;
        }

        // ------------------------------------------------------------- painting

        static void L(Graphics g, string t, Font f, Rectangle r, Color c, bool right = false)
        {
            TextRenderer.DrawText(g, t ?? "", f, r, c, TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter |
                                                      TextFormatFlags.EndEllipsis | (right ? TextFormatFlags.Right : TextFormatFlags.Left));
        }

        static int W(string t, Font f) { return TextRenderer.MeasureText(t ?? "", f, Size.Empty, TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding | TextFormatFlags.SingleLine).Width; }

        static Color Tone(double v) { double r = Math.Round(v, 2); return r > 0 ? Theme.Ok : r < 0 ? Theme.Bad : Theme.Text; }

        void Hit(Rectangle r, Action a) { hits.Add(new KeyValuePair<Rectangle, Action>(r, a)); }

        /// <summary>3.27: the bar above the numbers is drawn for right to left and mirrored in English.</summary>
        Rectangle M(Rectangle r) { return Theme.Flip(r, 0, Width); }
        RectangleF M(RectangleF r) { return Theme.Flip(r, new Rectangle(0, 0, Width, Height)); }

        bool Hover(Rectangle r) { return r.Contains(mouse); }

        /// <summary>3.21.1: the report is a page of its own (no accent edge, the page's background).</summary>
        public bool PageMode;
        string paintError;
        /// <summary>Why the page could not be painted last time; null when it was.</summary>
        public string PaintError { get { return paintError; } }

        protected override void OnPaint(PaintEventArgs e)
        {
            try { PaintAll(e.Graphics); paintError = null; }
            catch (Exception ex)
            {
                // Never the red cross of a control that failed to paint: what failed goes to the log, and a line says so.
                if (paintError != ex.Message) { paintError = ex.Message; Log.Write("report page paint: " + ex); }
                e.Graphics.Clear(BackColor);
                Theme.Line(e.Graphics, Lang.T("این بخش گزارش نمایش داده نشد (جزئیات در لاگ). بازه‌ی دیگری را انتخاب کنید یا «به‌روزرسانی» را بزنید.", "This part of the report could not be shown (details in the log). Choose another range or press “Refresh”."), Theme.Font,
                           new Rectangle(P(22), P(12), Math.Max(0, Width - P(44)), P(40)), Theme.Bad);
            }
        }

        void PaintAll(Graphics g)
        {
            hits.Clear();
            g.Clear(BackColor);
            if (!PageMode)
            {
                // The accent along the start (right) edge, like the marked row above it; a line at the bottom.
                using (var b = new SolidBrush(Theme.Accent)) g.FillRectangle(b, Lang.En ? 0 : Width - P(3), 0, P(3), Height);
                using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, 0, Height - 1, Width, Height - 1);
            }
            int pad = PageMode ? P(2) : P(22), right = Width - pad - (PageMode ? 0 : P(3)), left = pad;
            int y = P(Top);
            PaintBar(g, left, right, y);
            y += P(Bar + Gap);
            if (!HasAccount)
            {
                Theme.Line(g, Lang.T("این نسخه حساب ندارد؛ از منوی «⋯» حساب و رمز اینوستور را وارد کنید.", "This copy has no account; enter the account and investor password from the “⋯” menu."), Theme.Font, new Rectangle(left, y, right - left, P(40)), Theme.Muted);
                return;
            }
            if (View == null)
            {
                string t = Busy ? Lang.T("در حال خواندن… (حدود یک دقیقه)", "Reading… (about a minute)") : Error != null ? Lang.T("خوانده نشد: ", "Not read: ") + Error
                         : Lang.T("هنوز خوانده نشده. «به‌روزرسانی» را بزنید تا خوانده شود (حدود یک دقیقه).", "Not read yet. Press “Refresh” to read it (about a minute).");
                Theme.Line(g, t, Theme.Font, new Rectangle(left, y, right - left, P(40)), Error != null && !Busy ? Theme.Bad : Theme.Muted);
                return;
            }
            PaintTiles(g, left, right, y);
            y += P(Tile + 10);
            if (View.Flags.Count > 0)
            {
                int x = left;
                foreach (CoachFlag f in View.Flags)
                {
                    int w = W(f.Text, Theme.SmallBold) + P(18);
                    if (x + w > right) break;
                    var r = new Rectangle(x, y, w, P(Flags));
                    bool bad = f.Level == FlagLevel.Bad;
                    Theme.Box(g, r, Theme.Sf(4), bad ? Theme.BadSoft : Theme.WarnSoft, Color.Transparent);
                    L(g, f.Text, Theme.SmallBold, new Rectangle(r.X + P(9), r.Y, r.Width - P(9), r.Height), bad ? Theme.Bad : Theme.Warn);
                    x += w + P(8);
                }
                y += P(Flags + 8);
            }
            if (Error != null)
            {
                Theme.Line(g, Lang.T("آخرین خواندن نشد: ", "The last reading failed: ") + Error + Lang.T(" — عددها از خواندن قبلی است.", " — the numbers are from the reading before."), Theme.Small, new Rectangle(left, y, right - left, P(22)), Theme.Bad);
                y += P(22);
            }
            if (View.HistoryNote != null)
            {
                Theme.Line(g, View.HistoryNote, Theme.Small, new Rectangle(left, y, right - left, P(22)), Theme.Warn);
                y += P(22);
            }
            if (NotCovered)
            {
                var box = new Rectangle(left, y + P(4), right - left, P(32));
                Theme.Box(g, box, Theme.Sf(6), Theme.WarnSoft, Theme.WarnLine);
                Theme.Line(g, Lang.T("تاریخچه‌ی این بازه هنوز روی این کامپیوتر نیست. «به‌روزرسانی» آن را می‌خواند؛ عددهای زیر فقط تا جایی است که خوانده شده.", "The history of this range is not on this computer yet. “Refresh” reads it; the numbers below only go as far as was read."),
                           Theme.Small, new Rectangle(box.X + P(12), box.Y, box.Width - P(24), box.Height), Theme.Warn);
                y += P(40);
            }
            PaintTable(g, left, right, y);
        }

        void PaintBar(Graphics g, int left, int right, int y)
        {
            int h = P(Bar);
            // The ranges, from the right.
            int x = right;
            int[] widths = RangeNames.Select(n => Theme.Measure(n, Theme.Small).Width + P(24)).ToArray();
            int total = widths.Sum();
            var whole = new Rectangle(right - total, y, total, h);
            Theme.Box(g, M(whole), Theme.Sf(6), Theme.Surface, Theme.BorderStrong);
            for (int k = 0; k < RangeNames.Length; k++)
            {
                var r = M(new Rectangle(x - widths[k], y, widths[k], h));
                bool on = (int)Range == k;
                if (on) Theme.Box(g, r, Theme.Sf(6), Theme.Accent, Theme.Accent);
                else if (Hover(r)) using (var b = new SolidBrush(Theme.Hover)) g.FillRectangle(b, r.X + 1, r.Y + 1, r.Width - 2, r.Height - 2);
                Theme.Line(g, RangeNames[k], on ? Theme.SmallBold : Theme.Small, r, on ? Theme.OnAccent : Theme.Text, true);
                int sx = Lang.En ? r.Left : r.Right;
                if (k > 0 && !on && (int)Range != k - 1) using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, sx, r.Y + P(6), sx, r.Bottom - P(6));
                PanelRange kind = (PanelRange)k;
                Hit(r, () => { if (RangeWanted != null) RangeWanted(kind); });
                x -= widths[k];
            }
            x = whole.X - P(12);

            // At the left: «به‌روزرسانی» and when it was read.
            string button = Busy ? Lang.T("در حال خواندن…", "Reading…") : Lang.T("به‌روزرسانی", "Refresh");
            int bw = Theme.Measure(button, Theme.SmallBold).Width + P(40);
            var br = new Rectangle(left, y, bw, h);
            bool can = HasAccount && !Busy;
            Theme.Box(g, M(br), Theme.Sf(4), !can ? Theme.Mix(Theme.Accent, Theme.Surface, 0.55f) : Hover(M(br)) ? Theme.AccentHover : Theme.Accent, Color.Transparent);
            int icon = P(12);
            var ir = new RectangleF(br.Right - P(12) - icon, br.Y + (h - icon) / 2f, icon, icon);
            Glyphs.Draw(g, Glyph.Refresh, M(ir), Theme.OnAccent);
            Theme.Line(g, button, Theme.SmallBold, M(new Rectangle(br.X + P(10), br.Y, (int)ir.X - P(6) - br.X - P(10), h)), Theme.OnAccent, true);
            if (can) Hit(M(br), () => { if (RefreshWanted != null) RefreshWanted(); });
            int textLeft = br.Right + P(12);
            // 3.22.1: beside it, «کپی متن روز» (approved mockup), when one day is shown and has been read.
            // 3.27.2 (CHANGE-022): for several days too, as «کپی متن گزارش»: the same text as «متن گزارش», for this student.
            if (View != null && HasAccount)
            {
                string copy = View.SingleDay ? Lang.T("کپی متن روز", "Copy day text") : Lang.T("کپی متن گزارش", "Copy report text");
                int cw = Theme.Measure(copy, Theme.SmallBold).Width + P(40);
                var cr = new Rectangle(br.Right + P(8), y, cw, h);
                Theme.Box(g, M(cr), Theme.Sf(4), Hover(M(cr)) ? Theme.Mix(Theme.AccentSoft, Theme.Accent, 0.08f) : Theme.Surface, Theme.AccentLine);
                var ci = new RectangleF(cr.Right - P(12) - icon, cr.Y + (h - icon) / 2f, icon, icon);
                Glyphs.Draw(g, Glyph.CopyText, M(ci), Theme.AccentText);
                Theme.Line(g, copy, Theme.SmallBold, M(new Rectangle(cr.X + P(10), cr.Y, (int)ci.X - P(6) - cr.X - P(10), h)), Theme.AccentText, true);
                Hit(M(cr), () => { if (CopyWanted != null) CopyWanted(); });
                textLeft = cr.Right + P(12);
            }
            if (ReadLocal.HasValue || Busy)
            {
                string ago = Busy ? (BusyText ?? Lang.T("در حال خواندن…", "Reading…")) : Lang.T("به‌روز شده ", "Updated ") + PanelMath.Ago(ReadLocal.Value, DateTime.Now) + " (" + ReadLocal.Value.ToString("HH:mm", Inv) + ")";
                int aw = Math.Min(Theme.Measure(ago, Theme.Small).Width + P(4), Math.Max(0, x - textLeft - P(200)));
                var ar = new Rectangle(textLeft, y, aw, h);
                if (!Busy)
                {
                    int dot = P(7);
                    using (var b = new SolidBrush(Error != null ? Theme.Bad : CopyGrid.OkDot))
                        g.FillEllipse(b, M(new Rectangle(ar.Right + P(4), y + (h - dot) / 2, dot, dot)));
                }
                Theme.Line(g, ago, Theme.Small, M(ar), Busy ? Theme.Accent : Theme.Muted);
                textLeft = ar.Right + P(20);
            }

            // Between them: the range in words, or the two dates of «بازه».
            if (Range == PanelRange.Custom)
            {
                int bxw = P(96), lab = Theme.Measure(Lang.T("تا", "to"), Theme.Small).Width + P(6), show = Theme.Measure(Lang.T("نمایش", "Show"), Theme.SmallBold).Width + P(24);
                int fx = x - Theme.Measure(Lang.T("از", "from"), Theme.Small).Width - P(6);
                Theme.Line(g, Lang.T("از", "from"), Theme.Small, M(new Rectangle(fx, y, x - fx, h)), Theme.Muted);
                var fromD = new Rectangle(fx - P(4) - bxw, y + (h - fromBox.Height) / 2, bxw, fromBox.Height);
                fromBox.Bounds = M(fromD);
                int tx = fromD.Left - P(8) - lab;
                Theme.Line(g, Lang.T("تا", "to"), Theme.Small, M(new Rectangle(tx, y, lab, h)), Theme.Muted);
                var toD = new Rectangle(tx - P(4) - bxw, y + (h - toBox.Height) / 2, bxw, toBox.Height);
                toBox.Bounds = M(toD);
                var sr = M(new Rectangle(toD.Left - P(10) - show, y + P(2), show, h - P(4)));
                Theme.Box(g, sr, Theme.Sf(4), Hover(sr) ? Theme.Mix(Theme.AccentSoft, Theme.Accent, 0.08f) : Theme.AccentSoft, Theme.AccentLine);
                Theme.Line(g, Lang.T("نمایش", "Show"), Theme.SmallBold, sr, Theme.AccentText, true);
                Hit(sr, ShowCustom);
                fromBox.Visible = toBox.Visible = true;
            }
            else
            {
                fromBox.Visible = toBox.Visible = false;
                if (x - textLeft > P(40)) Theme.Line(g, RangeText, Theme.Small, M(new Rectangle(textLeft, y, x - textLeft, h)), Theme.Muted);
            }
        }

        void PaintTiles(Graphics g, int left, int right, int y)
        {
            PanelView v = View;
            int gap = P(10), h = P(Tile);
            string riskSub = v.RiskUnknown > 0 ? (double.IsNaN(v.MaxRisk) ? "" : "max " + PanelMath.Pct(v.MaxRisk) + " · ") + v.RiskUnknown.ToString(Inv) + " unknown (No SL)"
                           : double.IsNaN(v.MaxRisk) ? "no trades with SL" : "max " + PanelMath.Pct(v.MaxRisk);
            string stopSub = v.Opened == 0 ? "no trades opened" : v.Mt4 > 0 && v.Entry + v.Late == 0
                ? v.Mt4.ToString(Inv) + " with SL" + (v.NoSl > 0 ? " · " + v.NoSl.ToString(Inv) + " No SL (" + Coach.Span(v.NoSlTime) + ")" : "")
                : string.Join(" · ", new[]
                  {
                      v.Entry > 0 ? v.Entry.ToString(Inv) + " Entry" : null, v.Late > 0 ? v.Late.ToString(Inv) + " Late" : null, v.Mt4 > 0 ? v.Mt4.ToString(Inv) + " SL (MT4)" : null,
                      v.NoSl > 0 ? v.NoSl.ToString(Inv) + " No SL (" + Coach.Span(v.NoSlTime) + ")" : null,
                  }.Where(t => t != null));
            // 3.25 (approved): the account's balance first, with what it was when the range began under it.
            string start = v.StartBalance > 0 ? Math.Round(v.StartBalance, 2).ToString("#,##0.00", Inv) : null;
            string balanceSub = start == null ? "at the last read" : (v.ReachesNow ? "" : "now · ") + (v.SingleDay ? "start of day " : "start ") + start;
            var tiles = new[]
            {
                new { K = "Balance", V = PanelMath.Amount(v.Balance, v.Currency), S = balanceSub, C = Theme.Text, Bad = false },
                new { K = "Trades", V = v.TradeCount.ToString(Inv), S = v.Closed.ToString(Inv) + " closed · " + v.Open.ToString(Inv) + " open", C = Theme.Text, Bad = false },
                new { K = v.SingleDay ? "Net (day)" : "Net (range)", V = PanelMath.Money(v.Net, v.Currency), S = v.ReachesNow && v.Open > 0
                      ? "closed " + PanelMath.Money(v.ClosedNet, v.Currency) + " · floating " + PanelMath.Money(v.Floating, v.Currency) : "closed trades", C = Tone(v.Net), Bad = false },
                new { K = "Risk / trade", V = PanelMath.Pct(v.AvgRisk), S = riskSub, C = Theme.Text, Bad = false },
                new { K = "Stop loss", V = v.Opened == 0 ? "—" : v.WithStop.ToString(Inv) + " / " + v.Opened.ToString(Inv), S = stopSub, C = v.NoSl > 0 ? Theme.Bad : Theme.Text, Bad = v.NoSl > 0 },
                new { K = v.DdLabel, V = PanelMath.Pct(v.DdPct), S = v.SingleDay ? "from day start" : "in the range", C = Theme.Text, Bad = false },
            };
            tiles = tiles.Where(t => !v.FloatingDisabled || t.K != v.DdLabel).ToArray();
            // Each card as wide as its words need, the room left shared out evenly; too little room: all narrower alike.
            int n = tiles.Length, room = right - left - gap * (n - 1);
            int[] need = tiles.Select(t => Math.Max(W(t.K, Theme.Small), Math.Max(W(t.V, Theme.Number), W(t.S, Theme.Small))) + P(30)).ToArray();
            int sum = need.Sum();
            int[] widths = need.Select(x => sum <= room ? x + (room - sum) / n : x * room / Math.Max(1, sum)).ToArray();
            int cx = left;
            for (int k = 0; k < tiles.Length; k++)
            {
                var r = new Rectangle(cx, y, widths[k], h);
                cx += widths[k] + gap;
                Theme.Box(g, r, Theme.Sf(8), tiles[k].Bad ? Theme.Mix(Theme.BadSoft, Theme.Surface, 0.5f) : Theme.Surface, tiles[k].Bad ? Theme.Mix(Theme.Bad, Theme.Surface, 0.7f) : Theme.Border);
                int ix = r.X + P(14), iw = r.Width - P(24);
                L(g, tiles[k].K, Theme.Small, new Rectangle(ix, r.Y + P(7), iw, P(18)), Theme.Muted);
                L(g, tiles[k].V, Theme.Number, new Rectangle(ix, r.Y + P(24), iw, P(28)), tiles[k].C);
                L(g, tiles[k].S, Theme.Small, new Rectangle(ix, r.Y + P(52), iw, P(18)), tiles[k].Bad ? Theme.Bad : Theme.Muted);
            }
        }

        void PaintTable(Graphics g, int left, int right, int y)
        {
            List<TableRow> rows = TableRows();
            var frame = new Rectangle(left, y, right - left, Height - y - P(Bottom));
            if (frame.Height < P(Head)) return;
            Theme.Box(g, frame, Theme.Sf(6), Theme.Surface, Theme.Border);
            bool days = !View.SingleDay;
            // Columns, left to right (English, as the mockup): the share of the width and whether the text sits at the right.
            string[] names = days ? new[] { "Day", "Trades", "Net", "Max risk", "Stop loss", "Daily DD" } : new[] { "Time", "Symbol", "Side", "Lots", "Risk", "Stop loss", "Result" };
            float[] share = days ? new[] { 0.2f, 0.1f, 0.15f, 0.12f, 0.3f, 0.13f } : new[] { 0.16f, 0.13f, 0.08f, 0.09f, 0.09f, 0.27f, 0.18f };
            bool[] alignRight = days ? new[] { false, true, true, true, false, true } : new[] { false, false, false, true, true, false, true };
            int inner = frame.Width - P(20);
            Func<float[], List<Rectangle>> layout = sh =>
            {
                var list = new List<Rectangle>();
                int cx = frame.X + P(10);
                foreach (float f in sh)
                {
                    int w = (int)(inner * f);
                    list.Add(new Rectangle(cx, 0, w - P(10), 0));
                    cx += w;
                }
                return list;
            };
            List<Rectangle> cols = layout(share);
            // The trades opened under a day have the trades' own seven columns, not the day's six.
            List<Rectangle> tradeCols = days ? layout(new[] { 0.16f, 0.13f, 0.08f, 0.09f, 0.09f, 0.27f, 0.18f }) : cols;
            using (var b = new SolidBrush(Theme.Mix(Theme.Alt, Theme.Surface, 0.5f))) g.FillRectangle(b, frame.X + 1, y + 1, frame.Width - 2, P(Head) - 1);
            for (int k = 0; k < names.Length; k++)
                L(g, names[k], Theme.SmallBold, new Rectangle(cols[k].X, y, cols[k].Width, P(Head)), Theme.Muted, alignRight[k]);
            using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, frame.X, y + P(Head), frame.Right, y + P(Head));
            int top = y + P(Head) + 1, area = frame.Bottom - top - 1;
            tableArea = area;
            contentHeight = rows.Count * P(RowH);
            scroll = Math.Max(0, Math.Min(scroll, Math.Max(0, contentHeight - area)));
            if (rows.Count == 0)
            {
                Theme.Line(g, View.SingleDay ? Lang.T("در این روز معامله‌ای نیست.", "No trades on this day.") : Lang.T("در این بازه معامله‌ای نیست.", "No trades in this range."), Theme.Small, new Rectangle(frame.X, top, frame.Width, P(RowH)), Theme.Muted, true);
                return;
            }
            Region old = g.Clip;
            g.SetClip(new Rectangle(frame.X + 1, top, frame.Width - 2, area));
            int ry = top - scroll;
            foreach (TableRow row in rows)
            {
                var rr = new Rectangle(frame.X + 1, ry, frame.Width - 2, P(RowH));
                if (rr.Bottom >= top && rr.Top <= frame.Bottom)
                {
                    if (row.Day != null) PaintDay(g, row.Day, rr, cols);
                    else PaintTrade(g, row.Trade, rr, tradeCols, row.Nested, days);
                }
                ry += P(RowH);
            }
            g.Clip = old;
            // A thin scroll bar when the trades do not fit.
            if (contentHeight > area)
            {
                int bh = Math.Max(P(24), area * area / contentHeight), by = top + (area - bh) * scroll / Math.Max(1, contentHeight - area);
                Theme.Box(g, new Rectangle(frame.Right - P(7), by, P(4), bh), Theme.Sf(2), Theme.BorderStrong, Color.Transparent);
            }
        }

        static string StopText(PanelTrade t, out Color fore, out Color back)
        {
            switch (t.Stop)
            {
                case StopKind.Strict: fore = Theme.Ok; back = Theme.OkSoft; return "Entry";
                case StopKind.Delayed: fore = Theme.Warn; back = Theme.WarnSoft; return "Late · ≤ " + Coach.Span(t.Hold);
                case StopKind.Mt4: fore = Theme.Ok; back = Theme.OkSoft; return "SL (MT4)";
                default: fore = Theme.Bad; back = Theme.BadSoft; return "No SL · " + Coach.Span(t.Hold);
            }
        }

        static int Tag(Graphics g, string text, int x, Rectangle row, Color fore, Color back)
        {
            int w = W(text, Theme.SmallBold) + P(12), h = P(19);
            var r = new Rectangle(x, row.Y + (row.Height - h) / 2, w, h);
            Theme.Box(g, r, Theme.Sf(4), back, Color.Transparent);
            L(g, text, Theme.SmallBold, new Rectangle(r.X + P(6), r.Y, r.Width - P(6), r.Height), fore);
            return w + P(6);
        }

        void PaintTrade(Graphics g, PanelTrade t, Rectangle rr, List<Rectangle> cols, bool nested, bool days)
        {
            using (var pen = new Pen(Theme.Mix(Theme.Border, Theme.Surface, 0.5f))) g.DrawLine(pen, rr.X, rr.Bottom - 1, rr.Right, rr.Bottom - 1);
            if (nested) using (var b = new SolidBrush(Theme.Mix(Theme.Alt, Theme.Surface, 0.6f))) g.FillRectangle(b, rr.X, rr.Y, rr.Width, rr.Height - 1);
            Func<int, Rectangle> c = k => new Rectangle(cols[k].X + (nested && k == 0 ? P(16) : 0), rr.Y, cols[k].Width - (nested && k == 0 ? P(16) : 0), rr.Height);
            string close = !t.Closed ? "open" : t.Close.Date == t.Open.Date ? t.Close.ToString("HH:mm", Inv) : t.Close.ToString("MM-dd HH:mm", Inv);
            string time = (days && !nested ? t.Open.ToString("MM-dd ", Inv) : "") + t.Open.ToString("HH:mm", Inv) + " – " + close;
            L(g, time, Theme.Small, c(0), t.Closed ? Theme.Text : Theme.Muted);
            L(g, t.Symbol, Theme.Small, c(1), Theme.Text);
            L(g, t.Buy ? "Buy" : "Sell", Theme.Small, c(2), t.Buy ? Theme.Accent : Theme.Bad);
            L(g, t.Lots.ToString("0.00", Inv), Theme.Small, c(3), Theme.Text, true);
            L(g, double.IsNaN(t.RiskPct) ? "—" : PanelMath.Pct(t.RiskPct), Theme.Small, c(4), double.IsNaN(t.RiskPct) ? Theme.Faint : Theme.Text, true);
            Color fore, back;
            string stop = StopText(t, out fore, out back);
            int x = c(5).X;
            x += Tag(g, stop, x, rr, fore, back);
            if (t.Over > 0) x += Tag(g, "Over limit", x, rr, Theme.Warn, Theme.WarnSoft);
            string net = PanelMath.Money(t.Net, View.Currency) + (t.Closed ? "" : " floating");
            L(g, net, Theme.Small, c(6), Tone(t.Net), true);
        }

        void PaintDay(Graphics g, PanelDay d, Rectangle rr, List<Rectangle> cols)
        {
            bool open = openDays.Contains(d.Day);
            if (Hover(rr)) using (var b = new SolidBrush(Theme.Hover)) g.FillRectangle(b, rr.X, rr.Y, rr.Width, rr.Height - 1);
            using (var pen = new Pen(Theme.Mix(Theme.Border, Theme.Surface, 0.4f))) g.DrawLine(pen, rr.X, rr.Bottom - 1, rr.Right, rr.Bottom - 1);
            Func<int, Rectangle> c = k => new Rectangle(cols[k].X, rr.Y, cols[k].Width, rr.Height);
            int chev = P(10);
            Glyphs.Draw(g, open ? Glyph.Chevron : Glyph.ChevronRight, new RectangleF(cols[0].X, rr.Y + (rr.Height - chev) / 2f, chev, chev), Theme.Muted);
            L(g, d.Day.ToString("ddd yyyy.MM.dd", Inv), Theme.SmallBold, new Rectangle(cols[0].X + chev + P(6), rr.Y, cols[0].Width - chev - P(6), rr.Height), Theme.Text);
            L(g, d.Trades.ToString(Inv), Theme.Small, c(1), Theme.Text, true);
            L(g, PanelMath.Money(d.Net, View.Currency), Theme.Small, c(2), Tone(d.Net), true);
            L(g, PanelMath.Pct(d.MaxRisk), Theme.Small, c(3), double.IsNaN(d.MaxRisk) ? Theme.Faint : Theme.Text, true);
            int x = c(4).X;
            if (d.Entry > 0) x += Tag(g, d.Entry.ToString(Inv) + " Entry", x, rr, Theme.Ok, Theme.OkSoft);
            if (d.Mt4 > 0) x += Tag(g, d.Mt4.ToString(Inv) + " SL", x, rr, Theme.Ok, Theme.OkSoft);
            if (d.Late > 0) x += Tag(g, d.Late.ToString(Inv) + " Late", x, rr, Theme.Warn, Theme.WarnSoft);
            if (d.NoSl > 0) x += Tag(g, d.NoSl.ToString(Inv) + " No SL", x, rr, Theme.Bad, Theme.BadSoft);
            L(g, PanelMath.Pct(d.DailyDdPct), Theme.Small, c(5), Theme.Text, true);
            DateTime day = d.Day;
            Hit(rr, () => Toggle(day));
        }

        // ------------------------------------------------------------- mouse

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            mouse = e.Location;
            bool on = hits.Any(h => h.Key.Contains(e.Location));
            Cursor = on ? Cursors.Hand : Cursors.Default;
            Invalidate();
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            mouse = new Point(-1, -1);
            Invalidate();
        }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            if (!fromBox.Focused && !toBox.Focused) Focus();
            if (e.Button != MouseButtons.Left) return;
            foreach (KeyValuePair<Rectangle, Action> h in hits.ToList())
                if (h.Key.Contains(e.Location)) { h.Value(); return; }
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            int step = P(RowH) * 3 * Math.Sign(-e.Delta);
            int area = Math.Max(P(RowH), tableArea);
            int max = Math.Max(0, contentHeight - Math.Max(1, area));
            int was = scroll;
            scroll = Math.Max(0, Math.Min(max, scroll + step));
            if (scroll != was) Invalidate();
            else if (ScrollList != null) ScrollList(Math.Sign(-e.Delta));
        }
    }

    /// <summary>3.21.1: the top of a student's page: «بازگشت به فهرست» at the right, the name and the account under it, and the student
    /// before and after in the list at the left.</summary>
    sealed class StudentHeader : Control
    {
        public string Title = "", Meta = "", Status = "";
        public RowState State;
        public bool CanPrev, CanNext;
        public event Action BackWanted, PrevWanted, NextWanted;
        Rectangle back, prev, next;
        Point mouse = new Point(-1, -1);

        public StudentHeader()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Height = Theme.S(70);
            BackColor = Theme.Page;
        }

        static void Button(Graphics g, Rectangle r, string text, Glyph icon, bool iconRight, bool hover, bool enabled)
        {
            // 3.27: mirrored in English: the icon on the other side, pointing the other way.
            if (Lang.En)
            {
                iconRight = !iconRight;
                icon = icon == Glyph.ChevronRight ? Glyph.ChevronLeft : icon == Glyph.ChevronLeft ? Glyph.ChevronRight : icon;
            }
            Theme.Box(g, r, Theme.Sf(4), !enabled ? Theme.Page : hover ? Theme.Hover : Theme.Surface, enabled ? Theme.BorderStrong : Theme.Border);
            int i = Theme.S(11);
            Color c = enabled ? Theme.Text : Theme.Faint;
            var ir = new RectangleF(iconRight ? r.Right - Theme.S(12) - i : r.X + Theme.S(12), r.Y + (r.Height - i) / 2f, i, i);
            Glyphs.Draw(g, icon, ir, c);
            var tr = iconRight ? new Rectangle(r.X + Theme.S(8), r.Y, (int)ir.X - Theme.S(6) - r.X - Theme.S(8), r.Height)
                               : new Rectangle((int)ir.Right + Theme.S(6), r.Y, r.Right - Theme.S(10) - (int)ir.Right - Theme.S(6), r.Height);
            Theme.Line(g, text, Theme.Font, tr, c, true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(BackColor);
            int h = Theme.S(34), y = Theme.S(6);
            string b = Lang.T("بازگشت به فهرست", "Back to list");
            int bw = Theme.Measure(b, Theme.Font).Width + Theme.S(44);
            back = Theme.Flip(new Rectangle(Width - Theme.S(2) - bw, y, bw, h), 0, Width);
            Button(g, back, b, Glyph.ChevronRight, true, back.Contains(mouse), true);
            int nw = Math.Max(Theme.Measure(Lang.T("نفر بعدی", "Next"), Theme.Font).Width, Theme.Measure(Lang.T("نفر قبلی", "Previous"), Theme.Font).Width) + Theme.S(40);
            var nextD = new Rectangle(Theme.S(2), y, nw, h);
            var prevD = new Rectangle(nextD.Right + Theme.S(8), y, nw, h);
            next = Theme.Flip(nextD, 0, Width);
            prev = Theme.Flip(prevD, 0, Width);
            Button(g, prev, Lang.T("نفر قبلی", "Previous"), Glyph.ChevronRight, true, prev.Contains(mouse) && CanPrev, CanPrev);
            Button(g, next, Lang.T("نفر بعدی", "Next"), Glyph.ChevronLeft, false, next.Contains(mouse) && CanNext, CanNext);
            int backX = Width - Theme.S(2) - bw;
            int tx = prevD.Right + Theme.S(20), tw = backX - Theme.S(20) - tx;
            if (tw > 0)
            {
                Theme.Line(g, Title, Theme.Title, Theme.Flip(new Rectangle(tx, y - Theme.S(4), tw, Theme.S(32)), 0, Width), Theme.Text);
                Theme.Line(g, Meta + (Status.Length > 0 ? "  ·  " + Status : ""), Theme.Small, Theme.Flip(new Rectangle(tx, y + Theme.S(30), tw, Theme.S(22)), 0, Width), Theme.Muted);
            }
            using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, 0, Height - 1, Width, Height - 1);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            mouse = e.Location;
            Cursor = back.Contains(mouse) || (prev.Contains(mouse) && CanPrev) || (next.Contains(mouse) && CanNext) ? Cursors.Hand : Cursors.Default;
            Invalidate();
        }

        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); mouse = new Point(-1, -1); Invalidate(); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            if (e.Button != MouseButtons.Left) return;
            if (back.Contains(e.Location)) { if (BackWanted != null) BackWanted(); }
            else if (prev.Contains(e.Location) && CanPrev) { if (PrevWanted != null) PrevWanted(); }
            else if (next.Contains(e.Location) && CanNext) { if (NextWanted != null) NextWanted(); }
        }
    }
}
