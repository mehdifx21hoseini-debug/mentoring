using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MTManager
{
    /// <summary>Bounded evidence for one reporting run. Never copies settings, credentials or report/trade payloads.</summary>
    public sealed class ReportDiagnostics
    {
        const int MaxLineChars = 1600, MaxNativeBytes = 32768, MaxTailBytes = 65536, KeepRuns = 5;
        internal const long MaxRunBytes = 16 * 1024 * 1024;
        static readonly object gate = new object();
        static readonly Regex RunName = new Regex(@"^run-[0-9]{8}T[0-9]{9}-[a-f0-9]{32}$");
        static readonly Regex NativeName = new Regex(@"^native-[0-9]{5}-[0-9]{5}-[0-9]{2}\.txt$");
        static readonly Regex CredentialAssignment = new Regex(@"(?i)\b(password|passwd|investorpassword|masterpassword|authorization|access[_-]?token|refresh[_-]?token)\s*[:=]\s*[^\r\n]+", RegexOptions.CultureInvariant);
        static ReportDiagnostics latestActive;
        readonly List<string> secrets = new List<string>();
        readonly Stopwatch clock = Stopwatch.StartNew();
        readonly string directory;
        int captureId;
        long usedBytes;
        bool truncated, finished;
        public string DirectoryPath { get { return directory; } }
        static string Root { get { return Path.Combine(AppPaths.DataDir, "report-diagnostics"); } }

        public ReportDiagnostics(IEnumerable<ReportJob> jobs, int parallel)
        {
            try
            {
                var list = (jobs ?? Enumerable.Empty<ReportJob>()).ToList();
                foreach (var job in list)
                {
                    if (job.Account == null) continue;
                    foreach (string value in new[] { Secret.Unprotect(job.Account.MasterEnc), Secret.Unprotect(job.Account.InvestorEnc) })
                        if (!string.IsNullOrEmpty(value) && !secrets.Contains(value)) secrets.Add(value);
                }
                secrets.Sort((a, b) => b.Length.CompareTo(a.Length));
                directory = Path.Combine(Root, "run-" + DateTime.UtcNow.ToString("yyyyMMdd'T'HHmmssfff", CultureInfo.InvariantCulture) + "-" + Guid.NewGuid().ToString("N"));
                lock (gate)
                {
                    Directory.CreateDirectory(directory);
                    latestActive = this;
                    Write("manifest.txt", "MetaFactory report diagnostics\nVersion: " + AppInfo.Version + "\nStarted UTC: " + DateTime.UtcNow.ToString("o") +
                        "\nRequested students: " + list.Count + "\nWorkers: " + parallel + "\nCPU threads: " + Environment.ProcessorCount + "\nTotal RAM MB: " + Checks.TotalRamMb() +
                        "\nOS: " + Environment.OSVersion + "\n\nA past success/cache timestamp is historical evidence, not proof of a fresh report.\n" +
                        "Journal/Experts snapshots are bounded tails for the current attempt. Missing lines are not proof that an event never happened.\n" +
                        "The archive omits account configuration files, passwords and trade/report payloads. Account IDs, server names, student names and local paths may be present.\n" +
                        "Limits: last 5 runs, 16 MiB per run, 32 KiB per native snapshot. Some lines are omitted if these limits are reached.\n");
                    Write("events.tsv", "utc\trun_ms\tstudent_index\tpass\tstudent\tcopy\taccount\tserver\tplatform\tevent\tdetail\n");
                    Write("results.tsv", "utc\tstudent_index\tpass\tstudent\tcopy\taccount\tserver\tplatform\tresult\tcode\troute\tread_ms\ttotal_ms\tcache_exported\tdetail\n");
                    Prune();
                }
            }
            catch (Exception e) { Log.Write("report diagnostics initialization: " + e.GetType().Name); }
        }

        internal string Redact(string text)
        {
            string clean = text ?? "";
            foreach (string secret in secrets) clean = clean.Replace(secret, "[REDACTED]");
            return CredentialAssignment.Replace(clean, "$1=[REDACTED]");
        }
        string Cell(object value)
        {
            string text = Redact(Convert.ToString(value, CultureInfo.InvariantCulture) ?? "").Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ');
            return text.Length > MaxLineChars ? text.Substring(0, MaxLineChars) + " [truncated]" : text;
        }
        string Cells(params object[] values) { return string.Join("\t", values.Select(Cell)) + "\n"; }
        static string Utc { get { return DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture); } }
        bool Write(string file, string text, bool append = false)
        {
            if (directory == null) return false;
            string safe = Redact(text); long size = Encoding.UTF8.GetByteCount(safe);
            if (usedBytes + size > MaxRunBytes)
            {
                if (!truncated)
                {
                    truncated = true;
                    File.AppendAllText(Path.Combine(directory, "manifest.txt"), "\nCapture limit reached; later evidence may be omitted.\n", Encoding.UTF8);
                }
                return false;
            }
            string path = Path.Combine(directory, file);
            if (append) File.AppendAllText(path, safe, Encoding.UTF8); else File.WriteAllText(path, safe, Encoding.UTF8);
            usedBytes += size; return true;
        }
        static int TerminalCount()
        {
            int n = 0;
            foreach (string name in new[] { "terminal", "terminal64" })
                try { foreach (var p in Process.GetProcessesByName(name)) { n++; p.Dispose(); } } catch { }
            return n;
        }
        public void BeginAttempt(ReportJob job, DateTime? previousSuccess = null)
        {
            try
            {
                Stage(job, "attempt.begin", "free_ram_mb=" + Checks.FreeRamMb() + "; terminals=" + TerminalCount() +
                    (previousSuccess.HasValue ? "; previous_success=" + previousSuccess.Value.ToString("o") + " (historical, not fresh)" : ""));
            }
            catch (Exception e) { Log.Write("report diagnostics attempt: " + e.GetType().Name); }
        }
        public void Stage(ReportJob job, string code, string detail)
        {
            try
            {
                lock (gate)
                {
                    if (finished || job == null) return;
                    Write("events.tsv", Cells(Utc, clock.ElapsedMilliseconds, job.Index, job.Attempt, job.Name, job.Copy.Name, job.Account.Login, job.Account.Server, job.Copy.Kind, code, detail), true);
                }
            }
            catch (Exception e) { Log.Write("report diagnostics event: " + e.GetType().Name); }
        }
        public void Result(ReportJob job, ReportRow row, string code = null)
        {
            try
            {
                lock (gate)
                {
                    if (finished || job == null || row == null) return;
                    string state = row.Cancelled ? "stopped" : row.Cached ? "previous-only" : row.Journal != null ? "fresh" : "failed";
                    string cached = row.Cached && row.Journal != null ? row.Journal.Exported.ToString("o") : "";
                    Write("results.tsv", Cells(Utc, job.Index, job.Attempt, job.Name, job.Copy.Name, job.Account.Login, job.Account.Server, job.Copy.Kind,
                        state, code, row.Route, row.ReadMs, row.TotalMs, cached, row.Error ?? row.Note), true);
                }
            }
            catch (Exception e) { Log.Write("report diagnostics result: " + e.GetType().Name); }
        }

        static bool PrivateCopy(Instance copy)
        {
            if (copy == null || string.IsNullOrWhiteSpace(copy.Dir)) return false;
            string path = Path.GetFullPath(copy.Dir).Replace('\\', '/');
            return path.IndexOf("/_MTManager/report/", StringComparison.OrdinalIgnoreCase) >= 0;
        }
        static bool Link(string path) { return (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0; }
        // A fixed-size read avoids copying an ever-growing terminal log or blocking on exclusive writers.
        internal static List<string> Tail(string path, DateTime day, DateTime started)
        {
            var lines = new List<string>();
            try
            {
                if (!File.Exists(path) || Link(path)) return lines;
                using (var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                {
                    byte[] first = new byte[2]; int got = file.Read(first, 0, 2);
                    bool wide = got == 2 && (first[0] == 0xff && first[1] == 0xfe || first[0] != 0 && first[1] == 0);
                    long start = Math.Max(wide && first[0] == 0xff ? 2 : 0, file.Length - MaxTailBytes);
                    if (wide && start % 2 != 0) start++;
                    file.Position = Math.Min(file.Length, start);
                    byte[] bytes = new byte[MaxTailBytes]; int read = 0;
                    while (read < bytes.Length) { int n = file.Read(bytes, read, bytes.Length - read); if (n <= 0) break; read += n; }
                    string text = (wide ? Encoding.Unicode : TextFiles.Bytes).GetString(bytes, 0, wide ? read - read % 2 : read);
                    IEnumerable<string> whole = text.Split('\n'); if (start > 2) whole = whole.Skip(1);
                    lines = ConnectionCheck.After(whole, day == started.Date ? started.TimeOfDay.Subtract(TimeSpan.FromSeconds(2)) : TimeSpan.Zero).ToList();
                    if (lines.Count > 96) lines = lines.Skip(lines.Count - 96).ToList();
                }
            }
            catch { }
            return lines;
        }
        public void Capture(ReportJob job, Instance copy, DateTime started, string route)
        {
            try
            {
                if (!PrivateCopy(copy)) { Stage(job, "native.skipped", "Not a private report copy"); return; }
                // Never follow a linked root/log folder outside the private report terminal.
                string[] folders = { copy.Dir, Path.Combine(copy.Dir, "logs"), Path.Combine(copy.Dir, Kinds.Mql(copy.Kind)), Path.Combine(copy.Dir, Kinds.Mql(copy.Kind), "Logs") };
                if (folders.Any(f => Directory.Exists(f) && Link(f))) { Stage(job, "native.skipped", "Linked log directory"); return; }
                var lines = new List<string>();
                DateTime today = DateTime.Now.Date;
                DateTime first = started.Date < today.AddDays(-1) ? today.AddDays(-1) : started.Date;
                for (DateTime day = first; day <= today; day = day.AddDays(1))
                {
                    lines.AddRange(Tail(ConnectionCheck.JournalFile(copy, day), day, started).Select(s => "Journal: " + s));
                    lines.AddRange(Tail(ReportTrace.ProgramsLog(copy, day), day, started).Select(s => "Experts: " + s));
                }
                lock (gate)
                {
                    if (finished) return;
                    string header = "Account: " + Cell(job.Account.Login) + "\nServer: " + Cell(job.Account.Server) + "\nCopy: " + Cell(job.Copy.Name) +
                        "\nPrivate terminal: " + Cell(copy.Dir) + "\nPass: " + job.Attempt + "\nRoute: " + Cell(route) + "\nAttempt start (local): " + started.ToString("o") +
                        "\nCaptured UTC: " + Utc + "\nTerminal version: " + Cell(TerminalUpdate.FileVersion(copy.Exe)) + "\nFree RAM MB: " + Checks.FreeRamMb() + "\n\n";
                    var selected = new List<string>(); int budget = Math.Max(0, (MaxNativeBytes - Encoding.UTF8.GetByteCount(header)) / 2);
                    // Keep evidence from both streams even if one is exceptionally noisy.
                    foreach (string stream in new[] { "Journal: ", "Experts: " })
                    {
                        var part = new List<string>(); int bytes = 0;
                        foreach (string line in Enumerable.Reverse(lines.Where(l => l.StartsWith(stream, StringComparison.Ordinal))))
                        {
                            string safe = Cell(line); int n = Encoding.UTF8.GetByteCount(safe) + 1;
                            if (bytes + n > budget) break;
                            part.Add(safe); bytes += n;
                        }
                        part.Reverse(); selected.AddRange(part);
                    }
                    if (selected.Count == 0) selected.Add("No timestamped native lines found in the bounded tail for this attempt.");
                    string name = "native-" + (++captureId).ToString("D5") + "-" + Math.Max(0, job.Index).ToString("D5") + "-" + Math.Max(0, job.Attempt).ToString("D2") + ".txt";
                    Write(name, header + string.Join("\n", selected) + "\n");
                }
            }
            catch (Exception e) { Stage(job, "native.capture-error", e.GetType().Name); }
        }
        public void Finish()
        {
            try
            {
                lock (gate)
                {
                    if (finished) return;
                    Write("manifest.txt", "\nFinished UTC: " + Utc + "\nElapsed ms: " + clock.ElapsedMilliseconds + "\n", true);
                    finished = true; secrets.Clear(); if (latestActive == this) latestActive = null;
                }
            }
            catch (Exception e) { Log.Write("report diagnostics finish: " + e.GetType().Name); }
        }
        static bool AllowedFile(string name) { return name == "manifest.txt" || name == "events.tsv" || name == "results.tsv" || NativeName.IsMatch(name); }
        static IEnumerable<string> Runs()
        {
            if (!Directory.Exists(Root)) return Enumerable.Empty<string>();
            return Directory.GetDirectories(Root).Where(d => RunName.IsMatch(Path.GetFileName(d)) && !Link(d) && File.Exists(Path.Combine(d, "manifest.txt"))).OrderByDescending(d => Path.GetFileName(d), StringComparer.Ordinal).ToArray();
        }
        static string LatestDirectory()
        {
            if (latestActive != null && latestActive.directory != null && latestActive.directory.StartsWith(Root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) && File.Exists(Path.Combine(latestActive.directory, "manifest.txt"))) return latestActive.directory;
            return Runs().FirstOrDefault();
        }
        public static bool HasLatest { get { try { lock (gate) return LatestDirectory() != null; } catch { return false; } } }
        static void Prune()
        {
            string active = latestActive == null ? null : latestActive.directory;
            foreach (string run in Runs().Where(r => r != active).Skip(KeepRuns - (active == null ? 0 : 1)))
            {
                try
                {
                    foreach (string file in Directory.GetFiles(run).Where(f => AllowedFile(Path.GetFileName(f)) && !Link(f))) File.Delete(file);
                    if (!Directory.EnumerateFileSystemEntries(run).Any()) Directory.Delete(run);
                }
                catch { }
            }
        }
        public static void ExportLatest(string destination)
        {
            lock (gate)
            {
                string run = LatestDirectory();
                if (run == null) throw new UserMessage(Lang.T("هنوز گزارش عیب‌یابی ثبت نشده است؛ یک نوبت گزارش‌گیری اجرا کنید.", "No report diagnostics have been recorded yet; run a report first."));
                string full = Path.GetFullPath(destination);
                if (full.StartsWith(Path.GetFullPath(Root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                    throw new UserMessage(Lang.T("فایل خروجی را بیرون از پوشهٔ داخلی عیب‌یابی ذخیره کنید.", "Save the exported ZIP outside the internal diagnostics folder."));
                string temporary = full + "." + Guid.NewGuid().ToString("N") + ".tmp";
                try
                {
                    using (var output = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    using (var zip = new ZipArchive(output, ZipArchiveMode.Create))
                    {
                        long total = 0;
                        foreach (string file in Directory.GetFiles(run).Where(f => AllowedFile(Path.GetFileName(f)) && !Link(f)).OrderBy(f => f))
                        {
                            long size = new FileInfo(file).Length;
                            if (size > MaxRunBytes || total + size > MaxRunBytes + 4096) continue;
                            var entry = zip.CreateEntry(Path.GetFileName(file), CompressionLevel.Optimal);
                            using (var input = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read))
                            using (var target = entry.Open()) input.CopyTo(target);
                            total += size;
                        }
                    }
                    if (File.Exists(full)) File.Replace(temporary, full, null); else File.Move(temporary, full);
                }
                finally { if (File.Exists(temporary)) File.Delete(temporary); }
            }
        }
    }
}
