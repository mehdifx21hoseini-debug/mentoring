using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;

namespace MTManager
{
    static partial class Tests
    {
        static void ReportDiagnosticChecks()
        {
            string previous = AppPaths.DataDirOverride;
            try
            {
                AppPaths.DataDirOverride = Dir("report-diagnostic-store");
                const string master = "MasterSecret!901", investor = "InvestorSecret@902";
                var job = new ReportJob
                {
                    Index = 3, Attempt = 1, Name = "Synthetic student",
                    Copy = new Instance { Name = "MT5-12", Kind = Kind.MT5, Dir = Dir("diagnostic-student") },
                    Account = new Account { Login = "123456", Server = "Broker-Demo", MasterEnc = Secret.Protect(master), InvestorEnc = Secret.Protect(investor) }
                };
                var run = new ReportDiagnostics(new[] { job }, 4);
                Check(Directory.Exists(run.DirectoryPath), "diagnostic run is persisted separately from credentials");
                Equal("[REDACTED] / [REDACTED]", run.Redact(master + " / " + investor), "diagnostics scrub both saved password modes, not just current login mode");
                Check(!run.Redact("Password=an-unregistered-secret\naccess_token: another-secret").Contains("an-unregistered-secret") && !run.Redact("access_token: another-secret").Contains("another-secret"), "diagnostics scrub explicit credential assignments even when not registered");
                run.BeginAttempt(job, DateTime.Now.AddMinutes(-30));
                run.Stage(job, "native.ready", "A report may fail although a previous report succeeded. " + master);
                run.Stage(job, "large-event", new string('z', 100000));
                Check(new FileInfo(Path.Combine(run.DirectoryPath, "events.tsv")).Length < 6000, "a large diagnostic detail is bounded before it is written");
                var privateCopy = new Instance { Kind = Kind.MT5, Name = "private", Dir = Dir("diagnostic-base", "_MTManager", "report", "MT5-Broker-Demo-1") };
                DateTime begun = DateTime.Today.AddHours(1);
                Directory.CreateDirectory(Path.Combine(privateCopy.Dir, "logs"));
                Directory.CreateDirectory(Path.Combine(privateCopy.Dir, "MQL5", "Logs"));
                string journal = ConnectionCheck.JournalFile(privateCopy, DateTime.Today), experts = ReportTrace.ProgramsLog(privateCopy, DateTime.Today);
                File.WriteAllText(journal, "00:01:00 old attempt\n01:01:00 authorized with " + investor + "\n01:01:01 password=unregistered-secret\n", Encoding.Unicode);
                File.WriteAllText(experts, "01:01:03 MTManagerReport initialization failed\n", Encoding.Unicode);
                run.Capture(job, privateCopy, begun, "warm");
                job.Attempt = 2;
                run.BeginAttempt(job);
                run.Capture(job, privateCopy, begun, "cold-retry");
                string[] snapshots = Directory.GetFiles(run.DirectoryPath, "native-*.txt");
                Equal(2, snapshots.Length, "each native capture retains a separate attempt snapshot even for a reused private terminal");
                string evidence = string.Join("\n", snapshots.Select(File.ReadAllText));
                Check(evidence.Contains("authorized") && evidence.Contains("initialization failed") && !evidence.Contains("old attempt"), "native diagnostics retain Journal and Experts for the actual attempt only");
                Check(!evidence.Contains(master) && !evidence.Contains(investor) && !evidence.Contains("unregistered-secret"), "native credentials are redacted before persistence");
                run.Capture(job, job.Copy, begun, "student-terminal");
                Equal(2, Directory.GetFiles(run.DirectoryPath, "native-*.txt").Length, "diagnostics refuse student terminals outside the private report folder");
                run.Result(job, new ReportRow { Cached = true, Journal = new AccountJournal { Exported = DateTime.Now.AddMinutes(-30) }, Note = "no fresh result", ReadMs = 0, TotalMs = 45000 }, "REPORTER_START_TIMEOUT");
                Check(File.ReadAllText(Path.Combine(run.DirectoryPath, "results.tsv")).Contains("previous-only") && File.ReadAllText(Path.Combine(run.DirectoryPath, "results.tsv")).Contains("REPORTER_START_TIMEOUT"), "cached previous success remains distinct from this attempt's fresh failure and reason code");
                File.WriteAllText(Path.Combine(run.DirectoryPath, "accounts.ini"), "Password=DO-NOT-EXPORT");
                File.WriteAllText(Path.Combine(run.DirectoryPath, "unrelated.txt"), "DO-NOT-EXPORT");
                string archive = Path.Combine(AppPaths.DataDir, "support.zip");
                ReportDiagnostics.ExportLatest(archive);
                using (var file = File.OpenRead(archive))
                using (var zip = new ZipArchive(file, ZipArchiveMode.Read))
                {
                    Check(zip.GetEntry("manifest.txt") != null && zip.GetEntry("events.tsv") != null && zip.GetEntry("results.tsv") != null, "active-run ZIP includes consistent generated manifest/events/results");
                    Check(zip.GetEntry("accounts.ini") == null && zip.GetEntry("unrelated.txt") == null, "diagnostic ZIP exports only generated whitelist files, never stray account configuration");
                    foreach (var entry in zip.Entries)
                        using (var reader = new StreamReader(entry.Open()))
                        {
                            string contents = reader.ReadToEnd();
                            Check(!contents.Contains(master) && !contents.Contains(investor) && !contents.Contains("DO-NOT-EXPORT"), "export is password-safe: " + entry.FullName);
                        }
                }
                run.Finish(); run.Stage(job, "late", "must not be written");
                Check(!File.ReadAllText(Path.Combine(run.DirectoryPath, "events.tsv")).Contains("must not be written"), "finished diagnostic runs reject late stage events");
                string large = string.Join("\n", Enumerable.Range(0, 1000).Select(n => "01:02:03 line " + n + " " + new string('x', 500)));
                File.WriteAllText(journal, large, Encoding.Unicode);
                var tail = ReportDiagnostics.Tail(journal, DateTime.Today, begun);
                Check(tail.Count <= 96 && tail.Last().Contains("line 999") && !tail.Any(l => l.Contains("line 0 ")), "native log reads are bounded to a tail and retain newest evidence");
                for (int i = 0; i < 6; i++) new ReportDiagnostics(new[] { job }, 1).Finish();
                int manifests = Directory.GetDirectories(Path.Combine(AppPaths.DataDir, "report-diagnostics")).Count(d => File.Exists(Path.Combine(d, "manifest.txt")));
                Equal(5, manifests, "diagnostics retain at most five generated runs");
                Check(File.Exists(Path.Combine(run.DirectoryPath, "unrelated.txt")), "retention never deletes unrelated user-added files");
            }
            finally { AppPaths.DataDirOverride = previous; }
        }
    }
}
