using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace MTManager
{
    static partial class Tests
    {
        static void DashboardMasterChecks()
        {
            var progress = new ReportWorkProgress(); progress.Begin(); progress.Add("one");
            Equal(1, progress.Total, "one selected student has one share of report work");
            progress.Update("one", StepState.Starting); Check(progress.Fraction > 0 && progress.Fraction < 1, "one-student bar advances at actual start phase");
            progress.Update("one", StepState.Reading); Check(progress.Fraction > 0.1 && progress.Fraction < 1, "one-student bar advances at reading phase");
            progress.Update("one", StepState.Done); Check(progress.Complete && progress.Fraction == 1 && progress.Done == 1, "single student fills report bar exactly on completion");
            progress.Update("one", StepState.Failed); Equal(0, progress.Failed, "duplicate late terminal events cannot change completed work");
            progress.Begin(); foreach (string n in Enumerable.Range(1, 10).Select(n => "s" + n)) progress.Add(n);
            for (int n = 1; n <= 3; n++) progress.Update("s" + n, StepState.Done);
            Check(Math.Abs(progress.Fraction - 0.3) < 0.00001 && progress.Done == 3, "three of ten students yields three equal completed shares");
            progress.Update("s4", StepState.Failed); Equal(1, progress.Failed, "failed work is counted and exposed separately");
            for (int n = 5; n <= 10; n++) progress.Update("s" + n, StepState.Done);
            Check(progress.Complete && progress.Done == 10 && progress.Fraction == 1, "all attempted rows finish bar including explicit failures");
            progress.Begin(); progress.Add("one"); progress.Add("ONE"); Equal(1, progress.Total, "report progress deduplicates selected account names");
            progress.Update("one", StepState.Reading); double stopped = progress.Fraction; progress.Cancel(); progress.Update("one", StepState.Done);
            Check(progress.Cancelled && !progress.Complete && progress.Fraction == stopped, "cancelled work never fabricates a completed report");
            progress.Begin(); progress.Add("old"); progress.Update("old", StepState.Reading); progress.Add("new");
            Check(progress.Total == 2 && Math.Abs(progress.Fraction - 0.275) < 0.00001, "new queued work extends denominator without resetting completed phases");
            foreach (string server in new[] { "WMMarkets-DEMO", "Broker-MT5Trial15", "Broker-Practice", "Demo", "Broker-Demo1" }) Equal(ServerCategory.Demo, ServerCategories.Of(server), "recognize explicit demo server " + server);
            foreach (string server in new[] { "WMMarkets-REAL6", "WMMarkets-Real1", "Broker-Live02", "Real" }) Equal(ServerCategory.Real, ServerCategories.Of(server), "recognize explicit real server " + server);
            foreach (string server in new[] { "WM", "WingoGroupLtd-server", "RealMarkets-Server", "Demolition-Server", "Demo-Live", "" }) Equal(ServerCategory.Unknown, ServerCategories.Of(server), "never guess account type from ambiguous server " + server);
            Check(DashboardSort.Number("9999999999999999999", "10000000000000000000") < 0, "account sort handles 20 digits without overflow");
            Equal(0, DashboardSort.Number("0002", "2"), "account sorting ignores leading zeroes without rewriting login");
            Check(DashboardSort.Natural("MT4-2", "MT4-10") < 0, "copy names use natural numeric order");
            var rows = new[] {
                new CopyRow { Name = "MT5-10", Kind = "MT5", Trader = "Z", Login = "20", Server = "Unknown", Activity = Activity.Inactive, HasAccount = true, State = RowState.Inactive },
                new CopyRow { Name = "MT4-10", Kind = "MT4", Trader = "B", Login = "3", Server = "Broker-Real2", TodayNet = -10, Activity = Activity.Active, HasAccount = true, State = RowState.Active },
                new CopyRow { Name = "MT4-2", Kind = "MT4", Trader = "A", Login = "2", Server = "Broker-Demo1", TodayNet = 20, Activity = Activity.Active, HasAccount = true, State = RowState.Active },
            };
            Equal("MT4-2,MT4-10,MT5-10", string.Join(",", DashboardSort.Apply(rows, "Copy", 1).Select(r => r.Name)), "sort platforms then numeric copy index");
            Equal("2,3,20", string.Join(",", DashboardSort.Apply(rows, "Login", 1).Select(r => r.Login)), "account sorting is numeric rather than lexical");
            Equal("A,B,Z", string.Join(",", DashboardSort.Apply(rows, "Trader", 1).Select(r => r.Trader)), "student names ascending");
            Equal("Z,B,A", string.Join(",", DashboardSort.Apply(rows, "Trader", -1).Select(r => r.Trader)), "student names descending");
            Equal("Broker-Demo1,Broker-Real2,Unknown", string.Join(",", DashboardSort.Apply(rows, "Server", 1).Select(r => r.Server)), "server sort groups demo, real, then unknown");
            Equal("Broker-Real2,Broker-Demo1,Unknown", string.Join(",", DashboardSort.Apply(rows, "Server", -1).Select(r => r.Server)), "reverse server sort keeps unknown separate at end");
            Check(DashboardSort.Apply(rows, "Today", 1).First().TodayNet == -10 && DashboardSort.Apply(rows, "Today", -1).First().TodayNet == 20, "today sort compares signed numeric profit and loss");
            Check(!DashboardSort.Apply(rows, "Today", 1).Last().TodayNet.HasValue && !DashboardSort.Apply(rows, "Today", -1).Last().TodayNet.HasValue, "missing daily data stays at end in both directions");
            Check(DashboardSort.Apply(rows, "Status", 1).Take(2).All(r => r.Activity == Activity.Active), "status sort groups active accounts together");
            Check(DashboardSort.Apply(rows, "Copy", 0).SequenceEqual(rows), "third-click direction restores original order");
            Check(DashboardSort.Apply(rows, "Action", 1).SequenceEqual(rows), "action column never changes row order");
            var same = new[] { new CopyRow { Name = "second", Trader = "Equal" }, new CopyRow { Name = "first", Trader = "Equal" } };
            Check(DashboardSort.Apply(same, "Trader", 1).SequenceEqual(same), "equal values preserve manual order");
            var key = new CopyRow { Name = "key" }; string original = key.Key; key.MasterLogin = true; Check(key.Key != original, "master mode changes force row repaint");
            key.TodayNet = 50; Check(key.Key != original, "daily numeric value participates in row update key");
            var displayedActive = new CopyRow { Name = "verified", HasAccount = true, State = RowState.Active, Activity = Activity.Unknown };
            Check(DashboardSort.Apply(new[] { rows[0], displayedActive }, "Status", 1)[0] == displayedActive, "status sort follows the displayed active badge even before activity history is known");
            MasterImportChecks();
        }
        static void MasterImportChecks()
        {
            string previous = AppPaths.DataDirOverride; bool english = Lang.En;
            AppPaths.DataDirOverride = Dir("master-support", "data");
            try
            {
                var header = ImportSheetRow(1, "Name", "Platform", "Login", "Server", "Mode", "Master", "Investor", "Folder");
                var parsed = StudentImport.Plan(new[] { header,
                    ImportSheetRow(2, "Master", "MT5", "123", "Broker-Real1", "MASTER", "MasterSentinel!1", "", "Group"),
                    ImportSheetRow(3, "Investor", "MT4", "456", "Broker-Demo", "investor", "", "InvSentinel!2", ""),
                    ImportSheetRow(4, "Wrong mode", "MT4", "789", "Broker-Demo", "admin", "bad", "", "") }, null);
                Check(parsed[0].State == ImportState.Ready && parsed[0].Mode == "master" && parsed[0].SelectedPassword == "MasterSentinel!1", "Excel selects explicit master credentials");
                Check(parsed[1].State == ImportState.Ready && parsed[1].Mode == "investor", "mixed Excel file keeps investor rows supported");
                Equal(ImportState.Invalid, parsed[2].State, "unknown password mode is rejected rather than guessed");
                var inferred = StudentImport.Plan(new[] { ImportSheetRow(1, "Name", "Platform", "Login", "Server", "Master Password"), ImportSheetRow(2, "Only master", "MT4", "12", "Broker-Demo", "Master!2") }, null)[0];
                Check(inferred.State == ImportState.Ready && inferred.Mode == "master", "master-only column works without an investor column");
                var generic = StudentImport.Plan(new[] { ImportSheetRow(1, "Name", "Platform", "Login", "Server", "Password", "Mode"), ImportSheetRow(2, "Generic", "MT4", "13", "Broker-Demo", "Master!3", "master") }, null)[0];
                Check(generic.State == ImportState.Ready && generic.Master == "Master!3", "generic password follows an explicit master mode");
                parsed[0].Reason = "MasterSentinel!1 InvSentinel!2"; parsed[0].Investor = "InvSentinel!2";
                Equal("*** ***", parsed[0].Redact(parsed[0].Reason), "both master and investor secrets redact from errors");
                parsed[0].Reason = "";
                var settings = new Settings { BaseDir = Dir("master-support", "copies") }; var accounts = new AccountStore(); var folders = new FolderStore();
                using (var direct = new DirectAccountVerifier(settings, 1))
                {
                    var noPassword = direct.Verify(new Account { Mode = "master", Login = "123", Server = "Broker-Demo" }, 15000, () => false, message => { });
                    Check(!noPassword.Connected && !noPassword.Retryable, "missing master password fails before terminal discovery or provisioning");
                    Check(!Directory.Exists(Path.Combine(settings.BaseDir, "_MTManager")), "invalid master credentials never create terminal artifacts");
                }
                string observedMode = "", observedPassword = "";
                using (var queue = new ImportCoordinator(settings, accounts, folders, slot => new FakeVerifier((a, timeout, cancel) => { observedMode = a.Mode; observedPassword = a.PasswordForLogin(); return new ImportConnection { Connected = true, State = Login.Connected }; }), 1))
                {
                    queue.Register(new[] { parsed[0] }, "", () => false, r => { }); queue.Start();
                    Eventually(() => accounts.Get(parsed[0].Copy).VerifyState == "connected", "master account is eligible for automatic connection checks");
                    Equal("master", observedMode, "verification queue retains master mode"); Equal("MasterSentinel!1", observedPassword, "verifier gets master password rather than investor password");
                    Check(!File.ReadAllText(AppPaths.AccountsFile).Contains("MasterSentinel!1"), "master credentials remain encrypted at rest");
                }
                var master = accounts.Get(parsed[0].Copy); string oldKey = master.CredentialKey;
                var changed = master.Snapshot(); changed.MasterEnc = Secret.Protect("ChangedMaster!2"); accounts.Set(changed);
                Check(accounts.Get(master.Instance).CredentialKey != oldKey && accounts.Get(master.Instance).VerifyState == "queued", "editing master password invalidates old verification result");
                var data = BackupStore.Gather(settings, accounts, folders, new List<string>(), StudentDirectory.All(settings, accounts), false);
                var roundtrip = BackupFormat.Read(BackupFormat.Write(data)); var restored = BackupStore.AccountOf(roundtrip.Students[0], "MT5-restored");
                Check(restored.Mode == "master" && restored.PasswordForLogin() == "ChangedMaster!2", "backup restore preserves master mode and active password");
                string workbook = Path.Combine(AppPaths.DataDir, "master-export.xlsx");
                Spreadsheet.Write(workbook, StudentExport.Rows(StudentDirectory.All(settings, accounts), accounts, folders, true));
                var imported = StudentImport.Read(workbook, null)[0]; Check(imported.State == ImportState.Ready && imported.Mode == "master" && imported.Master == "ChangedMaster!2", "exported master accounts can be imported again with their mode");
                Lang.En = true;
                foreach (Kind kind in new[] { Kind.MT4, Kind.MT5 })
                {
                    var copy = new Instance { Kind = kind, Name = "report-test", Dir = settings.BaseDir };
                    var job = new ReportJob { Index = 0, Copy = copy, Account = new Account { Mode = "master", Login = "88", Server = "Broker-Demo", MasterEnc = Secret.Protect("MasterOnly!8") } };
                    var runner = new ReportRunner(settings, new List<ReportJob> { job }, new List<Instance> { copy }, name => job.Account, new ReportRange { From = DateTime.Today.AddDays(-1), To = DateTime.Today }, 1);
                    runner.ScriptProblems[kind] = "test unavailable compiler";
                    var result = (ReportRow)typeof(ReportRunner).GetMethod("One", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(runner, new object[] { job, 1 });
                    Check(result.Error.Contains("was not built"), kind + " report path accepts master-only credentials before script check");
                    string[] launch = ReportLaunch.StartLines(kind, job.Account, "MasterOnly!8", "EURUSD").ToArray();
                    Check(launch.Contains(kind == Kind.MT4 ? "ExpertsTrades=false" : "AllowLiveTrading=0"), kind + " report launch keeps automatic trading disabled for master accounts");
                    Check(!Regex.IsMatch(ReportScript.SourceText(kind), @"\b(OrderSend|OrderModify|OrderClose|PositionOpen|PositionClose)\s*\("), kind + " report code never places or changes trades");
                }
            }
            finally { AppPaths.DataDirOverride = previous; Lang.En = english; }
        }
    }
}
