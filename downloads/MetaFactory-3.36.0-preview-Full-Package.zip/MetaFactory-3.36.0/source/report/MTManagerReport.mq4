//+------------------------------------------------------------------+
//| MTManagerReport.mq4 - MT Manager                                  |
//| Reads the account's history once and writes it to a file, then   |
//| ends. Read-only: it never places, changes or closes an order. Run |
//| by MT Manager in its own report copy of MetaTrader, with the      |
//| investor (view-only) password.                                    |
//| MT4 keeps only the last Stop Loss of a closed order: the entry's  |
//| is written as -1 (unknown).                                       |
//|                                                                  |
//| 1.21 (MetaFactory 3.34): trade-only export; no chart bars.         |
//| Previous 1.20 (MT Manager 3.21): MT4 gives a program only the part of the  |
//| history its "Account History" tab shows (often the last month).   |
//| The script asks the terminal for "All History" - the same command |
//| as the tab's own menu, through user32.dll, only when DLL calls are|
//| allowed - and waits until the history adds up to the balance      |
//| (H line). The last trade of the whole history is written (L).     |
//+------------------------------------------------------------------+
#property copyright "MT Manager"
#property version   "1.22"
#property strict

#import "user32.dll"
int PostMessageW(int hWnd, int Msg, int wParam, int lParam);
int GetAncestor(int hWnd, int gaFlags);
#import

input string FromDate = "";                    // first server day, yyyy.mm.dd
input string OutFile  = "MTManagerReport\\report.txt"; // under MQL4\Files

input string ExpectedLogin = "";
input string ExpectedServer = "";
input string RequestToken = "";
string WorkFrom, WorkLogin, WorkServer, WorkToken;
bool SameText(string a, string b) { StringToLower(a); StringToLower(b); return a == b; }
bool ExpectedAccount()
{
   return (WorkLogin == "" || WorkLogin == IntegerToString(AccountNumber())) && (WorkServer == "" || SameText(WorkServer, AccountServer()));
}

#define SCRIPT_VERSION "1.22"
#define WM_COMMAND 0x0111
#define GA_ROOT 2
// The "All History" item of the Account History tab's menu.
#define CMD_ALL_HISTORY 33058

string N(double v) { return DoubleToString(v, 8); }
string T(datetime t) { return IntegerToString((long)t); }
void Line(int h, string s) { FileWriteString(h, s + "\r\n"); }

// A text as one field: no tab or line break in it.
string Clean(string s)
{
   string r = s;
   StringReplace(r, "\t", " ");
   StringReplace(r, "\r", " ");
   StringReplace(r, "\n", " ");
   return r;
}

// The server's clock less GMT, to the half hour, for the trading sessions. MT4's server clock stands still
// without prices (a weekend): then it is not a whole half hour away from GMT and is left out.
string Offset()
{
   long d = (long)(TimeCurrent() - TimeGMT());
   long r = (long)MathRound(d / 1800.0) * 1800;
   if(MathAbs(d - r) > 300 || MathAbs(r) > 14 * 3600) return "";
   return IntegerToString(r);
}

string Header() { return "MTR\t2\tMT4\t" + IntegerToString(TerminalInfoInteger(TERMINAL_BUILD)) + "\t" + SCRIPT_VERSION + "\r\nQ\t" + WorkToken; }

// Writes the file under a temporary name and renames it at the end: the program never reads half a file.
bool Finish(int h, string tmp)
{
   FileClose(h);
   FileDelete(OutFile);
   if(FileMove(tmp, 0, OutFile, FILE_REWRITE)) return true;
   Print("MTManagerReport: cannot finish ", OutFile);
   return false;
}

// Tells the program at once why nothing was read, instead of letting it wait.
void Fail(string why)
{
   Print("MTManagerReport: ", why);
   string tmp = OutFile + ".part";
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) return;
   Line(h, Header());
   Line(h, "ERR\t" + why);
   Finish(h, tmp);
}

// Where the script is, for the program: one line in a file beside the result ("start", "connected", "history 152", "bars EURUSD 2", "writing").
void Step(string what)
{
   int h = FileOpen(OutFile + ".step", FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) return;
   FileWriteString(h, what);
   FileClose(h);
}

// ------------------------------------------------------------------ the history adds up to the balance

double sumAll = 0;
int    histCount = 0;

void AddUp()
{
   sumAll = 0;
   histCount = OrdersHistoryTotal();
   for(int i = 0; i < histCount; i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      int type = OrderType();
      if(type == OP_BUY || type == OP_SELL) sumAll += OrderProfit() + OrderCommission() + OrderSwap();
      else if(type == 6) sumAll += OrderProfit();   // balance: deposits, withdrawals, charges (7, credit, is not in the balance)
   }
}

bool AddsUp()
{
   double balance = AccountBalance();
   return MathAbs(sumAll - balance) <= MathMax(0.02, MathAbs(balance) * 0.000001);
}

bool posted = false;

// Asks the terminal for its whole account history, as its "All History" menu item does.
void AskAllHistory()
{
   if(!IsDllsAllowed()) { Print("MTManagerReport: DLL calls are not allowed; the history is what the Account History tab shows"); return; }
   int chart = (int)ChartGetInteger(0, CHART_WINDOW_HANDLE);
   if(chart == 0) chart = WindowHandle(Symbol(), Period());
   if(chart == 0) return;
   int root = GetAncestor(chart, GA_ROOT);
   if(root == 0) return;
   posted = PostMessageW(root, WM_COMMAND, CMD_ALL_HISTORY, 0) != 0;
}

// Waits until the terminal is connected and the whole history is there: it adds up to the balance and has stopped growing.
// A history that never adds up (the broker keeps only part of it) is taken once it has not grown for 15 seconds.
bool WaitForHistory()
{
   for(int k = 0; k < 120 && !IsStopped() && (!IsConnected() || AccountNumber() == 0 || !ExpectedAccount()); k++) Sleep(500);
   if(IsStopped() || !IsConnected() || !ExpectedAccount()) return false;
   Step("connected");
   AskAllHistory();
   uint begun = GetTickCount(), still = GetTickCount();
   int last = -1; double lastSum = 0;
   while(!IsStopped() && GetTickCount() - begun < 90000)
   {
      AddUp();
      if(histCount != last || MathAbs(sumAll - lastSum) > 0.0000001) { last = histCount; lastSum = sumAll; still = GetTickCount(); Step("history " + IntegerToString(histCount)); }
      uint quiet = GetTickCount() - still, waited = GetTickCount() - begun;
      bool empty = histCount == 0 && AccountBalance() == 0;
      if(AddsUp() && quiet >= 2000 && waited >= (uint)(empty ? 8000 : 3000)) break;
      // After "All History" MT4 can take half a minute or more to load it: 45 seconds without a change then.
      if(quiet >= (uint)(posted ? 45000 : 15000)) break;
      Sleep(500);
   }
   return true;
}

// Trade-only reports intentionally collect no chart bars or historical floating estimates.
datetime base;

// ------------------------------------------------------------------ the file

void ExportReport()
{
   Step("start");
   if(!WaitForHistory() || !ExpectedAccount()) { Fail("not connected"); return; }
   AddUp();
   bool addsUp = AddsUp();

   // Now: the server's clock, never before the last record (the last price can be old after a quiet spell).
   datetime now = TimeCurrent();
   datetime lastTrade = 0, firstSeen = 0;
   for(int i = 0; i < histCount; i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      int type = OrderType();
      datetime o = OrderOpenTime(), c = OrderCloseTime();
      if(c > now) now = c;
      if(o > now) now = o;
      if(type == OP_BUY || type == OP_SELL || type == 6)
         if(firstSeen == 0 || o < firstSeen) firstSeen = o;
      if((type == OP_BUY || type == OP_SELL) && c > lastTrade) lastTrade = c;
   }
   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      int type = OrderType();
      datetime o = OrderOpenTime();
      if(o > now) now = o;
      if((type == OP_BUY || type == OP_SELL) && o > lastTrade) lastTrade = o;
   }
   base = StrToTime(WorkFrom);
   if(base <= 0) base = now - 7 * 86400;
   string tmp = OutFile + ".part";
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE) { Print("MTManagerReport: cannot write ", tmp); return; }
   Step("writing");
   Line(h, Header());
   Line(h, "A\t" + IntegerToString(AccountNumber()) + "\t" + Clean(AccountServer()) + "\t" + AccountCurrency() + "\t" + N(AccountBalance()) + "\t" + N(AccountEquity()) + "\t" +
           T(now) + "\t" + T(base) + "\t" + Clean(AccountCompany()) + "\t" + Offset() + "\t" + IntegerToString(AccountLeverage()) + "\t" + N(AccountMargin()) + "\t" +
           N(AccountFreeMargin()) + "\t" + N(AccountCredit()));
   // H: whether the history adds up to the balance, the sum, the balance, the number of history records, and whether "All History" was asked for.
   Line(h, "H\t" + (addsUp ? "1" : "0") + "\t" + N(sumAll) + "\t" + N(AccountBalance()) + "\t" + IntegerToString(histCount) + "\t" + (posted ? "1" : "0"));
   // L: the last trade of the whole history (closed, or an open position's entry) and the first record of the account.
   Line(h, "L\t" + T(lastTrade) + "\t" + T(firstSeen));
   int records = 0;
   for(int i = 0; i < histCount; i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      int type = OrderType();
      // Money in and out: time, amount, comment, kind (2 balance, 3 credit: as MT5 numbers them).
      if(type == 6 || type == 7)
      {
         if(OrderOpenTime() < base) continue;
         Line(h, "B\t" + T(OrderOpenTime()) + "\t" + N(OrderProfit()) + "\t" + Clean(OrderComment()) + "\t" + (type == 6 ? "2" : "3"));
         records++;
         continue;
      }
      if(type != OP_BUY && type != OP_SELL) continue;
      if(OrderCloseTime() < base) continue;
      Line(h, "T\t" + IntegerToString(OrderTicket()) + "\t" + OrderSymbol() + "\t" + (type == OP_BUY ? "0" : "1") + "\t" + N(OrderLots()) + "\t" + T(OrderOpenTime()) + "\t" +
              N(OrderOpenPrice()) + "\t" + T(OrderCloseTime()) + "\t" + N(OrderClosePrice()) + "\t-1\t" + N(OrderStopLoss()) + "\t" + N(OrderTakeProfit()) + "\t" +
              N(OrderCommission()) + "\t" + N(OrderSwap()) + "\t" + N(OrderProfit()) + "\t" + Clean(OrderComment()));
      records++;
   }
   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      int type = OrderType();
      if(type != OP_BUY && type != OP_SELL) continue;
      Line(h, "O\t" + IntegerToString(OrderTicket()) + "\t" + OrderSymbol() + "\t" + (type == OP_BUY ? "0" : "1") + "\t" + N(OrderLots()) + "\t" + T(OrderOpenTime()) + "\t" +
              N(OrderOpenPrice()) + "\t" + N(OrderStopLoss()) + "\t" + N(OrderTakeProfit()) + "\t" + N(OrderProfit()) + "\t" + N(OrderSwap()) + "\t-1\t" +
              N(OrderClosePrice()) + "\t" + N(OrderCommission()));
      records++;
   }
   Step("writing");
   Line(h, "M\ttrades-only");
   Line(h, "END\t" + IntegerToString(records));
   Finish(h, tmp);
}

void OnStart()
{
   WorkFrom = FromDate; WorkLogin = ExpectedLogin; WorkServer = ExpectedServer; WorkToken = RequestToken;
   ExportReport();
}
