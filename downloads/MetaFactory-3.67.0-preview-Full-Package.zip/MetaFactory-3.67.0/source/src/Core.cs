// MT Manager: creates and runs many independent copies of MetaTrader 4 and 5.
// Each copy is a plain copy of an installed terminal, started with /portable, so it keeps all of its
// data in its own folder. Nothing is installed and MetaTrader itself is never modified.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace MTManager
{
    public enum Kind { MT4, MT5 }

    public static class Kinds
    {
        public static string Exe(Kind k) { return k == Kind.MT5 ? "terminal64.exe" : "terminal.exe"; }
        public static string Mql(Kind k) { return k == Kind.MT5 ? "MQL5" : "MQL4"; }

        public static Kind? Detect(string dir)
        {
            if (File.Exists(Path.Combine(dir, "terminal64.exe"))) return Kind.MT5;
            if (File.Exists(Path.Combine(dir, "terminal.exe"))) return Kind.MT4;
            return null;
        }
    }

    public sealed class Instance
    {
        public string Name;
        public Kind Kind;
        public string Dir;
        public string Exe { get { return Path.Combine(Dir, Kinds.Exe(Kind)); } }
    }

    public static class AppInfo
    {
        public const string Version = "3.67.0";
    }

    public static class AppPaths
    {
        /// <summary>Tests point this elsewhere; normally %APPDATA%\MT Manager.</summary>
        public static string DataDirOverride;

        public static string DataDir
        {
            get
            {
                if (DataDirOverride != null)
                {
                    Directory.CreateDirectory(DataDirOverride);
                    return DataDirOverride;
                }
                try
                {
                    string d = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MT Manager");
                    Directory.CreateDirectory(d);
                    return d;
                }
                catch
                {
                    // A locked-down profile: keep working from the temp folder.
                    string t = Path.Combine(Path.GetTempPath(), "MT Manager");
                    Directory.CreateDirectory(t);
                    return t;
                }
            }
        }

        public static string SettingsFile { get { return Path.Combine(DataDir, "settings.ini"); } }
        public static string AccountsFile { get { return Path.Combine(DataDir, "accounts.dat"); } }
        public static string LogFile { get { return Path.Combine(DataDir, "log.txt"); } }
    }

    /// <summary>A plain text log for finding problems. Passwords are never written to it.</summary>
    public static class Log
    {
        static readonly object Gate = new object();

        public static void Write(string text)
        {
            try
            {
                lock (Gate)
                {
                    string path = AppPaths.LogFile;
                    var info = new FileInfo(path);
                    if (info.Exists && info.Length > 1024 * 1024)
                    {
                        File.Copy(path, path + ".old", true);
                        File.Delete(path);
                    }
                    File.AppendAllText(path, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + text + Environment.NewLine, Encoding.UTF8);
                }
            }
            catch { }
        }
    }

    /// <summary>3.27 (CHANGE-019, approved): the program's language. Persian (right to left) or English (left to right); every text
    /// shown is written in both and this picks one. Only what is shown changes.</summary>
    public static class Lang
    {
        /// <summary>English, left to right. Set at start from settings.ini (Language=en) and again when the window is made again.</summary>
        public static bool En;

        /// <summary>The Persian or the English words.</summary>
        public static string T(string fa, string en) { return En ? en : fa; }
    }

    public static class TextUtil
    {
        /// <summary>Persian and Arabic digits (typed on a Persian keyboard) become 0-9.</summary>
        public static string LatinDigits(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            var sb = new StringBuilder(s.Length);
            foreach (char ch in s)
            {
                if (ch >= '\u06F0' && ch <= '\u06F9') sb.Append((char)('0' + (ch - '\u06F0')));
                else if (ch >= '\u0660' && ch <= '\u0669') sb.Append((char)('0' + (ch - '\u0660')));
                else sb.Append(ch);
            }
            return sb.ToString();
        }

        /// <summary>0-9 become Persian digits, for numbers shown inside Persian text.</summary>
        public static string PersianDigits(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            // 3.27: English shows the Latin digits.
            if (Lang.En) return s;
            var sb = new StringBuilder(s.Length);
            foreach (char ch in s) sb.Append(ch >= '0' && ch <= '9' ? (char)('\u06F0' + (ch - '0')) : ch);
            return sb.ToString();
        }

        public static string OneLine(string s)
        {
            if (s == null) return "";
            return s.Replace("\r\n", " ").Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ').Trim();
        }

        /// <summary>Written next to the file first, then swapped in: a crash or a full disk never leaves half a file.</summary>
        public static void WriteLinesSafely(string path, IEnumerable<string> lines)
        {
            string temp = path + ".new";
            File.WriteAllLines(temp, lines, Encoding.UTF8);
            try
            {
                if (File.Exists(path)) File.Replace(temp, path, null, true); else File.Move(temp, path);
            }
            catch (IOException)
            {
                // The swap can be refused for a moment (an antivirus reading the file): the complete new file is copied over instead.
                File.Copy(temp, path, true);
                try { File.Delete(temp); } catch { }
            }
        }

        public static void WriteLinesAtomically(string path, IEnumerable<string> lines)
        {
            if (Directory.Exists(path)) throw new IOException("A directory occupies the data-file path.");
            string temp = path + "." + Guid.NewGuid().ToString("N") + ".new";
            try
            {
                File.WriteAllLines(temp, lines, Encoding.UTF8);
                for (int attempt = 0; ; attempt++)
                {
                    try { if (File.Exists(path)) File.Replace(temp, path, null, true); else File.Move(temp, path); return; }
                    catch (IOException) { if (attempt >= 2) throw; System.Threading.Thread.Sleep(100); }
                }
            }
            finally { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
        }

        public static string Size(long bytes)
        {
            if (bytes >= 1L << 30) return (bytes / (double)(1L << 30)).ToString("0.0", System.Globalization.CultureInfo.InvariantCulture) + " GB";
            return (bytes / (1L << 20)).ToString("N0", System.Globalization.CultureInfo.InvariantCulture) + " MB";
        }
    }

    // ------------------------------------------------------------------ settings

    public sealed class Settings
    {
        public string BaseDir = DefaultBase();
        public int DelaySeconds = 5;
        public bool Minimized = true;
        public bool PauseMt5Updates = true; // Explicit user request: run managed MT5 copies without automatic updates.
        public bool ManualLiveReports = true; // Existing behavior remains the default.
        /// <summary>Run terminals and their helpers at the caller's existing privilege level; never request elevation here.</summary>
        public bool NormalTerminalRights = true;
        /// <summary>Route additional manual MT4 launches through installed Sandboxie; no total launch cap.</summary>
        public bool SandboxieOverflow = true;
        public bool Light = true;
        public bool AutoStart;
        /// <summary>The program's look (colors): blue, green, violet or dark.</summary>
        public string Look = "blue";
        /// <summary>Investor accounts and copies without an account open with one chart; the copy's other charts are set aside (restorable).
        /// Kept for versions before 3.17; StartCharts says it now.</summary>
        public bool LightCharts = true;
        /// <summary>How investor copies and copies without an account open (3.17): "empty" with no chart at all (the lightest),
        /// "one" with one chart (the others set aside, restorable), "all" with their charts as they are. Trading copies are never changed.</summary>
        public string StartCharts = ChartModes.Empty;
        /// <summary>Other folders that hold copies (made there earlier). BaseDir is where new copies go by default.</summary>
        public List<string> Folders = new List<string>();
        /// <summary>MetaTraders started by the program run below normal priority, so the one in front and this program stay quick.</summary>
        public bool LowPriority = true;
        /// <summary>The memory of minimized MetaTraders is handed back to Windows every few minutes.</summary>
        public bool TrimMemory = true;
        /// <summary>Legacy report/import admission setting only. Manual opening has no count cap;
        /// this setting is not evidence of a universal native MT4 limit.</summary>
        public int MaxMt4 = Mt4Limit.Default;
        /// <summary>3.23: the list shows all copies, MT4 only or MT5 only ("all", "MT4", "MT5"); kept after closing.</summary>
        public string Platform = "all";
        /// <summary>3.27 (CHANGE-019): "fa" (Persian, right to left) or "en" (English, left to right).</summary>
        public string Language = "fa";
        /// <summary>3.26 (CHANGE-005): the list's look: "normal" (44-pixel rows) or "compact" (32). Only how it looks.</summary>
        public string Density = "normal";
        /// <summary>3.24: where backups are saved, whether one is made every day there (on by default once a backup was made by hand),
        /// the password they are locked with (Windows' encryption for this user), and when the last one was made.</summary>
        public string BackupDir = "";
        public bool BackupAuto = true;
        public string BackupPasswordEnc = "";
        public DateTime LastBackup = DateTime.MinValue;
        /// <summary>3.24.1: the day the daily backup was last looked at, and the fingerprint of what it holds (AutoBackup.Fingerprint).</summary>
        public DateTime BackupChecked = DateTime.MinValue;
        public string BackupFingerprint = "";
        /// <summary>3.25: what «متن گزارش» puts in the text (ReportText.Parse; empty: all), and the range chosen there last.</summary>
        public string ReportParts = "";
        public string ReportRange = "";
        public const int MaxReportAtOnce = 4;
        /// <summary>Report copies at once: 0 automatic, or a ceiling from 1 to 4, limited by current resources.</summary>
        public int ReportAtOnce;
        /// <summary>3.18: whether a report also saves each account's statement, and where (empty: the default folder on the desktop).</summary>
        public bool SaveStatements;
        public string StatementDir = "";
        /// <summary>The version of the data files this was read from (see DataSchema); 1 for files of 3.12 and before.</summary>
        public int SchemaVersion = DataSchema.Current;

        /// <summary>Every folder with copies: the default one first.</summary>
        public List<string> AllFolders
        {
            get
            {
                var list = new List<string>();
                foreach (string f in new[] { BaseDir }.Concat(Folders))
                {
                    string d = (f ?? "").Trim().TrimEnd('\\', '/');
                    if (d.Length > 0 && !list.Any(x => string.Equals(x, d, StringComparison.OrdinalIgnoreCase))) list.Add(d);
                }
                return list;
            }
        }

        /// <summary>New copies go to this folder from now on; the folder used before stays in the list, so its copies are still shown.</summary>
        public void UseFolder(string dir)
        {
            dir = dir.Trim().TrimEnd('\\', '/');
            if (string.Equals(dir, BaseDir.TrimEnd('\\', '/'), StringComparison.OrdinalIgnoreCase)) return;
            List<string> all = AllFolders;
            BaseDir = dir;
            Folders = all.Where(f => !string.Equals(f, dir, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public static string DefaultBase()
        {
            try
            {
                var d = new DriveInfo("D");
                if (d.IsReady && d.DriveType == DriveType.Fixed) return @"D:\MetaTrader";
            }
            catch { }
            return @"C:\MetaTrader";
        }

        /// <summary>One line of settings.ini (also the settings a backup brings: BackupFormat.PortableSettings).</summary>
        public void Set(string key, string value, ref bool said)
        {
            int n;
            switch (key)
            {
                case "BaseDir": if (value.Length > 0) BaseDir = value; break;
                case "DelaySeconds": if (int.TryParse(value, out n)) DelaySeconds = Math.Max(0, Math.Min(120, n)); break;
                case "Minimized": Minimized = value == "1"; break;
                case "PauseMt5Updates": if(value=="0"||value=="1")PauseMt5Updates=value=="1"; break;
                case "ManualLiveReports": if(value=="0"||value=="1")ManualLiveReports=value=="1"; break;
                case "NormalTerminalRights": if (value == "0" || value == "1") NormalTerminalRights = value == "1"; break;
                case "SandboxieOverflow": if (value == "0" || value == "1") SandboxieOverflow = value == "1"; break;
                case "Light": Light = value == "1"; break;
                case "AutoStart": AutoStart = value == "1"; break;
                case "Look": if (value.Length > 0) Look = value; break;
                case "LightCharts": LightCharts = value == "1"; break;
                case "StartCharts": if (ChartModes.Valid(value)) { StartCharts = value; said = true; } break;
                case "Folders": Folders = value.Split('|').Select(x => x.Trim()).Where(x => x.Length > 0).ToList(); break;
                case "LowPriority": LowPriority = value == "1"; break;
                case "TrimMemory": TrimMemory = value == "1"; break;
                case "MaxMt4": if (int.TryParse(value, out n)) MaxMt4 = Mt4Limit.Clamp(n); break;
                case "Platform": Platform = value == "MT4" || value == "MT5" ? value : "all"; break;
                case "Language": Language = value == "en" ? "en" : "fa"; break;
                case "Density": Density = value == "compact" ? "compact" : "normal"; break;
                case "SchemaVersion": if (int.TryParse(value, out n) && n > 0) SchemaVersion = n; break;
                case "ReportAtOnce": if (int.TryParse(value, out n)) ReportAtOnce = Math.Max(0, Math.Min(MaxReportAtOnce, n)); break;
                case "SaveStatements": SaveStatements = value == "1"; break;
                case "StatementDir": StatementDir = value.Trim(); break;
                case "BackupDir": BackupDir = value.Trim(); break;
                case "BackupAuto": BackupAuto = value != "0"; break;
                case "BackupPassword": BackupPasswordEnc = value.Trim(); break;
                case "LastBackup":
                case "BackupChecked":
                    DateTime t;
                    if (DateTime.TryParseExact(value, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out t))
                    {
                        if (key == "LastBackup") LastBackup = t;
                        else BackupChecked = t;
                    }
                    break;
                case "BackupFingerprint": BackupFingerprint = value.Trim(); break;
                case "ReportParts": ReportParts = value.Trim(); break;
                case "ReportRange": ReportRange = value.Trim(); break;
            }
        }

        public static Settings Load()
        {
            bool ok;
            return Load(out ok);
        }

        /// <summary>ok is false when the file is there but could not be read: then it must not be written over with defaults.</summary>
        public static Settings Load(out bool ok)
        {
            var s = new Settings();
            ok = true;
            bool chartsSaid = false;
            try
            {
                if (!File.Exists(AppPaths.SettingsFile)) return s;
                s.SchemaVersion = 1;
                foreach (string line in File.ReadAllLines(AppPaths.SettingsFile, Encoding.UTF8))
                {
                    int eq = line.IndexOf('=');
                    if (eq <= 0) continue;
                    string key = line.Substring(0, eq).Trim();
                    string value = line.Substring(eq + 1).Trim();
                    s.Set(key, value, ref chartsSaid);
                }
            }
            catch (Exception e)
            {
                ok = false;
                Log.Write("settings unreadable: " + e.Message);
            }
            // Settings of 3.16 and before: «one chart» off stays all charts; on becomes the lighter start of 3.17.
            if (!chartsSaid) s.StartCharts = s.LightCharts ? ChartModes.Empty : ChartModes.All;
            s.LightCharts = s.StartCharts != ChartModes.All;
            return s;
        }

        /// <summary>The lines of settings.ini.</summary>
        public List<string> Lines()
        {
            return new List<string>
            {
                "SchemaVersion=" + DataSchema.Current,
                "BaseDir=" + BaseDir,
                "DelaySeconds=" + DelaySeconds,
                "Minimized=" + (Minimized ? "1" : "0"),
                "PauseMt5Updates=" + (PauseMt5Updates ? "1" : "0"),
                "ManualLiveReports=" + (ManualLiveReports ? "1" : "0"),
                "Light=" + (Light ? "1" : "0"),
                "AutoStart=" + (AutoStart ? "1" : "0"),
                "Look=" + Look,
                "LightCharts=" + (StartCharts != ChartModes.All ? "1" : "0"),
                "StartCharts=" + StartCharts,
                "Folders=" + string.Join("|", AllFolders.Skip(1)),
                "LowPriority=" + (LowPriority ? "1" : "0"),
                "TrimMemory=" + (TrimMemory ? "1" : "0"),
                "NormalTerminalRights=" + (NormalTerminalRights ? "1" : "0"),
                "SandboxieOverflow=" + (SandboxieOverflow ? "1" : "0"),
                "MaxMt4=" + MaxMt4,
                "Platform=" + (Platform == "MT4" || Platform == "MT5" ? Platform : "all"),
                "Language=" + (Language == "en" ? "en" : "fa"),
                "Density=" + (Density == "compact" ? "compact" : "normal"),
                "ReportAtOnce=" + ReportAtOnce,
                "SaveStatements=" + (SaveStatements ? "1" : "0"),
                "StatementDir=" + TextUtil.OneLine(StatementDir ?? ""),
                "BackupDir=" + TextUtil.OneLine(BackupDir ?? ""),
                "BackupAuto=" + (BackupAuto ? "1" : "0"),
                "BackupPassword=" + (BackupPasswordEnc ?? ""),
                "LastBackup=" + (LastBackup == DateTime.MinValue ? "" : LastBackup.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)),
                "BackupChecked=" + (BackupChecked == DateTime.MinValue ? "" : BackupChecked.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)),
                "BackupFingerprint=" + (BackupFingerprint ?? ""),
                "ReportParts=" + (ReportParts ?? ""),
                "ReportRange=" + (ReportRange ?? ""),
            };
        }

        public void Save()
        {
            TextUtil.WriteLinesSafely(AppPaths.SettingsFile, Lines());
            SchemaVersion = DataSchema.Current;
        }
    }

    /// <summary>The ways an investor copy can open (Settings.StartCharts).</summary>
    public static class ChartModes
    {
        public const string Empty = "empty", One = "one", All = "all";
        public static bool Valid(string v) { return v == Empty || v == One || v == All; }
    }

    // ------------------------------------------------------------------ the data files' version

    /// <summary>The version of the data files in %APPDATA%\MT Manager. Files of 3.12 and before carry none (version 1);
    /// from 3.13 settings.ini says SchemaVersion=2 and accounts.dat has the same as a comment line (earlier versions
    /// skip both, so going back to 3.12 still reads everything). Before files are written in a newer version,
    /// a copy of them is kept under backup\, and nothing is written when a file could not be read.</summary>
    public static class DataSchema
    {
        public const int Current = 2;
        static readonly string[] Names = { "settings.ini", "accounts.dat", "opened.txt", "folders.txt" };

        public static string BackupRoot { get { return Path.Combine(AppPaths.DataDir, "backup"); } }

        static int Marked(string path, string prefix)
        {
            foreach (string line in File.ReadAllLines(path, Encoding.UTF8))
            {
                string l = line.Trim();
                int n;
                if (l.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) && int.TryParse(l.Substring(prefix.Length).Trim(), out n)) return n;
            }
            return 1;
        }

        /// <summary>The version of the files on disk: 0 when there are none yet (a new install).</summary>
        public static int OnDisk()
        {
            bool settings = File.Exists(AppPaths.SettingsFile), accounts = File.Exists(AppPaths.AccountsFile);
            if (!settings && !accounts) return 0;
            int a = settings ? Marked(AppPaths.SettingsFile, "SchemaVersion=") : int.MaxValue;
            int b = accounts ? Marked(AppPaths.AccountsFile, "# SchemaVersion=") : int.MaxValue;
            return Math.Min(a, b);
        }

        /// <summary>Brings older files to the current version, after copying them aside. Returns the backup folder,
        /// or null when nothing needed it (new install, already current, or files of a newer version, which are left alone).</summary>
        public static string Upgrade()
        {
            using (var m = new System.Threading.Mutex(false, "MTManager-data-upgrade"))
            {
                bool mine = false;
                try { mine = m.WaitOne(10000); }
                catch (System.Threading.AbandonedMutexException) { mine = true; }
                try
                {
                    int version = OnDisk();
                    if (version == 0 || version == Current) return null;
                    if (version > Current)
                    {
                        Log.Write("data files are version " + version + ", newer than this program (" + Current + "): left as they are");
                        return null;
                    }
                    string dir = Path.Combine(BackupRoot, "schema-" + version + "-" + DateTime.Now.ToString("yyyyMMdd-HHmmss", System.Globalization.CultureInfo.InvariantCulture));
                    Directory.CreateDirectory(dir);
                    foreach (string name in Names)
                    {
                        string from = Path.Combine(AppPaths.DataDir, name);
                        if (!File.Exists(from)) continue;
                        string to = Path.Combine(dir, name);
                        File.Copy(from, to, true);
                        if (new FileInfo(to).Length != new FileInfo(from).Length) throw new IOException("backup of " + name + " is incomplete");
                    }
                    bool settingsOk, accountsOk;
                    Settings s = Settings.Load(out settingsOk);
                    AccountStore a = AccountStore.Load(out accountsOk);
                    if (!settingsOk || !accountsOk)
                    {
                        Log.Write("data upgrade postponed: a file could not be read (backup kept in " + dir + ")");
                        return dir;
                    }
                    // Version 1 to 2: the same settings and accounts, written with their version (and safely, through a temporary file).
                    if (File.Exists(AppPaths.SettingsFile)) s.Save();
                    if (File.Exists(AppPaths.AccountsFile)) a.Save();
                    Log.Write("data files upgraded from version " + version + " to " + Current + "; the earlier files are kept in " + dir);
                    return dir;
                }
                finally { if (mine) m.ReleaseMutex(); }
            }
        }
    }

    // ------------------------------------------------------------------ accounts

    /// <summary>Windows encryption (DPAPI) for the current user: unreadable for any other user or computer.</summary>
    public static class Secret
    {
        static readonly byte[] Entropy = Encoding.UTF8.GetBytes("MTManager.accounts.v3");

        public static string Protect(string plain)
        {
            if (string.IsNullOrEmpty(plain)) return "";
            byte[] data = ProtectedData.Protect(Encoding.UTF8.GetBytes(plain), Entropy, DataProtectionScope.CurrentUser);
            return Convert.ToBase64String(data);
        }

        /// <summary>The text, "" when nothing was saved, or null when it was saved by another user or computer.</summary>
        public static string Unprotect(string enc)
        {
            if (string.IsNullOrEmpty(enc)) return "";
            try
            {
                byte[] data = ProtectedData.Unprotect(Convert.FromBase64String(enc), Entropy, DataProtectionScope.CurrentUser);
                return Encoding.UTF8.GetString(data);
            }
            catch { return null; }
        }
    }

    public sealed class Account
    {
        public string Instance = "";
        public string Trader = "";
        public string Login = "";
        public string Server = "";
        /// <summary>"master" (trading) or "investor" (read-only).</summary>
        public string Mode = "master";
        public string MasterEnc = "";
        public string InvestorEnc = "";
        // Optional columns appended to the legacy seven-column format. Passwords remain DPAPI encrypted.
        public string Platform = "", DeferredDir = "", VerifyState = "", VerifyReason = "", VerifyUtc = "", VerifyToken = "", ImportGroup = "";
        public string OriginalTrader="", ImportServers="";
        public int VerifyPass;
        public Account Snapshot() { return (Account)MemberwiseClone(); }
        public string CredentialKey { get { return Login + "\t" + Server + "\t" + ImportServers + "\t" + Mode + "\t" + (IsInvestor ? InvestorEnc : MasterEnc); } }
        public void KeepQueue(Account old)
        {
            Platform = old.Platform; DeferredDir = old.DeferredDir; VerifyState = old.VerifyState;
            VerifyReason = old.VerifyReason; VerifyUtc = old.VerifyUtc; VerifyToken = old.VerifyToken;
            VerifyPass = old.VerifyPass; ImportGroup = old.ImportGroup; OriginalTrader=old.OriginalTrader; ImportServers=old.ImportServers;
        }

        public bool HasLogin { get { return !string.IsNullOrWhiteSpace(Login); } }
        public bool IsInvestor { get { return Mode == "investor"; } }
        public string PasswordForLogin() { return Secret.Unprotect(IsInvestor ? InvestorEnc : MasterEnc); }
        public bool Readable { get { return Secret.Unprotect(MasterEnc) != null && Secret.Unprotect(InvestorEnc) != null; } }
    }

    /// <summary>What a MetaTrader password may hold, checked where a password is entered (the account window, a new student,
    /// the Excel import). The start file has one setting per line and MT4 reads it in the computer's old one-byte code page:
    /// a line break would cut the password (and could add a setting of its own), spaces at either end are almost always
    /// copied by accident, and Persian letters or digits mean the keyboard was on Persian.</summary>
    public static class PasswordRule
    {
        static bool IsPersian(char c)
        {
            return (c >= '\u0600' && c <= '\u06FF') || (c >= '\u0750' && c <= '\u077F') || (c >= '\uFB50' && c <= '\uFDFF') ||
                   (c >= '\uFE70' && c <= '\uFEFF') || c == '\u200C' || c == '\u200D';
        }

        /// <summary>Null when the password can be used (or is empty: the forms ask for it themselves); otherwise why not, in plain Persian.</summary>
        public static string Problem(string password)
        {
            if (string.IsNullOrEmpty(password)) return null;
            if (password.IndexOf('\r') >= 0 || password.IndexOf('\n') >= 0)
                return Lang.T("رمز نباید به خط بعد برود (داخلش Enter هست). رمز را دوباره، در یک خط، وارد کنید.", "The password must not go on to a new line (it has an Enter in it). Enter the password again, on one line.");
            if (password != password.Trim())
                return Lang.T("اول یا آخر رمز فاصله (Space) هست. فاصله را پاک کنید؛ رمز متاتریدر با فاصله شروع یا تمام نمی‌شود.", "There is a space at the start or end of the password. Remove it; a MetaTrader password does not start or end with a space.");
            if (password.Any(IsPersian))
                return Lang.T("رمز حرف یا عدد فارسی دارد. زبان صفحه‌کلید را انگلیسی کنید و رمز را دوباره بنویسید.", "The password has Persian letters or digits. Switch the keyboard to English and type the password again.");
            if (password.Any(c => c < ' ' || c > '~'))
                return Lang.T("رمز نویسه‌ای دارد که متاتریدر نمی‌پذیرد. فقط حروف و عددهای انگلیسی و نشانه‌های روی صفحه‌کلید (مثل @ # $ % & * !) مجازند.", "The password has a character MetaTrader does not accept. Only English letters and digits and the keyboard's symbols (like @ # $ % & * !) are allowed.");
            return null;
        }

        /// <summary>The first problem among a form's passwords, named ("رمز اینوستور: …"); null when all can be used.</summary>
        public static string Check(params KeyValuePair<string, string>[] named)
        {
            foreach (KeyValuePair<string, string> p in named)
            {
                string problem = Problem(p.Value);
                if (problem != null) return p.Key + ": " + problem;
            }
            return null;
        }
    }

    /// <summary>One line per copy, tab separated; passwords stay encrypted on disk.</summary>
    public sealed class AccountStore
    {
        public readonly object Sync = new object();
        readonly Dictionary<string, Account> map = new Dictionary<string, Account>(StringComparer.OrdinalIgnoreCase);

        public static AccountStore Load()
        {
            bool ok;
            return Load(out ok);
        }

        /// <summary>ok is false when the file is there but could not be read: then it must not be written over.</summary>
        public static AccountStore Load(out bool ok)
        {
            var store = new AccountStore();
            ok = true;
            try
            {
                if (!File.Exists(AppPaths.AccountsFile)) return store;
                foreach (string line in File.ReadAllLines(AppPaths.AccountsFile, Encoding.UTF8))
                {
                    if (line.Length == 0 || line[0] == '#') continue;
                    string[] f = line.Split('\t');
                    if (f.Length < 7 || f[0].Length == 0) continue;
                    store.map[f[0]] = new Account
                    {
                        Instance = f[0], Trader = f[1], Login = f[2], Server = f[3],
                        Mode = f[4] == "investor" ? "investor" : "master", MasterEnc = f[5], InvestorEnc = f[6],
                        Platform = Field(f, 7), DeferredDir = Field(f, 8), VerifyState = Field(f, 9), VerifyReason = Field(f, 10),
                        VerifyUtc = Field(f, 11), VerifyToken = Field(f, 12), VerifyPass = Pass(Field(f, 13)), ImportGroup = Field(f, 14), OriginalTrader=Field(f,15), ImportServers=Field(f,16),
                    };
                }
            }
            catch (Exception e)
            {
                ok = false;
                Log.Write("accounts unreadable: " + e.Message);
            }
            return store;
        }

        static string Field(string[] fields, int index) { return index < fields.Length ? fields[index] : ""; }
        static int Pass(string value) { int n; return int.TryParse(value, out n) ? Math.Max(0, Math.Min(2, n)) : 0; }
        public void Save()
        {
            lock (Sync)
            {
                var lines = new List<string> { "# MT Manager accounts: legacy fields plus background verification metadata", "# SchemaVersion=" + DataSchema.Current };
                foreach (Account a in map.Values.OrderBy(x => x.Instance, StringComparer.OrdinalIgnoreCase))
                    lines.Add(string.Join("\t", new[] { a.Instance, a.Trader, a.Login, a.Server, a.IsInvestor ? "investor" : "master", a.MasterEnc, a.InvestorEnc,
                        a.Platform, a.DeferredDir, a.VerifyState, a.VerifyReason, a.VerifyUtc, a.VerifyToken, a.VerifyPass.ToString(CultureInfo.InvariantCulture), a.ImportGroup, a.OriginalTrader, a.ImportServers }.Select(x => TextUtil.OneLine(x ?? ""))));
                TextUtil.WriteLinesAtomically(AppPaths.AccountsFile, lines);
            }
        }
        public Account Get(string instance) { lock (Sync) { Account a; return map.TryGetValue(instance, out a) ? a.Snapshot() : null; } }
        public void Set(Account a) { SetImpl(a, false); }
        public void SetQueue(Account a) { SetImpl(a, true); }
        void SetImpl(Account a, bool queueUpdate)
        {
            lock (Sync)
            {
                Account old;
                if (map.TryGetValue(a.Instance, out old) && !queueUpdate && old.VerifyState.Length > 0)
                {
                    a.KeepQueue(old);
                    if (a.CredentialKey != old.CredentialKey)
                    { a.ImportServers=""; a.VerifyState = "queued"; a.VerifyToken = ""; a.VerifyPass = 0; a.VerifyUtc = ""; a.VerifyReason = Lang.T("اطلاعات حساب تغییر کرد؛ نیاز به بررسی دوباره دارد.", "Credentials changed; verification is needed again."); }
                }
                map[a.Instance] = a.Snapshot();
            }
        }
        public bool Remove(string instance) { lock (Sync) return map.Remove(instance); }
        public IEnumerable<Account> All { get { lock (Sync) return map.Values.Select(a => a.Snapshot()).ToArray(); } }
    }

    // ------------------------------------------------------------------ folders (groups of students)

    /// <summary>A group of copies the user names ("جذب سرمایه", "چالش مرحله ۱"). Its id never changes, so a rename moves nothing.</summary>
    public sealed class Folder
    {
        public string Id = "", Name = "";
        /// <summary>Settings written after the name as key=value, kept as they are. 3.14–3.18 kept a folder's own overtrading limits
        /// there (DailyTradeLimit, WeeklyTradeLimit); 3.19 has one daily limit for everyone (TradeLimits) and leaves them unused.</summary>
        public readonly List<string> Extra = new List<string>();
    }

    /// <summary>The user's folders and who is in them. A copy can be in several folders at once, like labels;
    /// a copy in none is "بدون پوشه". Kept in %APPDATA%\MT Manager\folders.txt, one line per folder and per membership:
    /// "F id name" and "M id copy", tab separated. Removing a folder never touches the copies or their accounts.</summary>
    public sealed class FolderStore
    {
        public const int MaxName = 40;
        /// <summary>The two views of the folder row that are not folders.</summary>
        public static string AllTitle { get { return Lang.T("همه‌ی پوشه‌ها", "All folders"); } }
        public static string NoneTitle { get { return Lang.T("بدون پوشه", "No folder"); } }

        readonly List<Folder> folders = new List<Folder>();
        readonly Dictionary<string, HashSet<string>> members = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);

        public static string FilePath { get { return Path.Combine(AppPaths.DataDir, "folders.txt"); } }

        public IList<Folder> All { get { return folders.AsReadOnly(); } }

        public Folder Get(string id) { return folders.FirstOrDefault(f => f.Id == id); }

        /// <summary>The folder with this name, compared as the user sees it (spaces and the half-space do not count).</summary>
        public Folder Find(string name) { return folders.FirstOrDefault(f => Norm(f.Name) == Norm(name ?? "")); }

        public static FolderStore Load()
        {
            bool ok;
            return Load(out ok);
        }

        /// <summary>ok is false when the file is there but could not be read: then it must not be written over.</summary>
        public static FolderStore Load(out bool ok)
        {
            var store = new FolderStore();
            ok = true;
            try
            {
                if (!File.Exists(FilePath)) return store;
                foreach (string line in File.ReadAllLines(FilePath, Encoding.UTF8))
                {
                    if (line.Length == 0 || line[0] == '#') continue;
                    string[] f = line.Split('\t');
                    if (f.Length < 3 || f[1].Length == 0) continue;
                    if (f[0] == "F" && store.Get(f[1]) == null && f[2].Trim().Length > 0)
                    {
                        var folder = new Folder { Id = f[1], Name = f[2].Trim() };
                        // Settings after the name, as key=value: kept, so nothing written there before is lost.
                        for (int k = 3; k < f.Length; k++)
                            if (f[k].IndexOf('=') > 0) folder.Extra.Add(f[k].Trim());
                        store.folders.Add(folder);
                        store.members[f[1]] = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    }
                    else if (f[0] == "M" && store.members.ContainsKey(f[1]) && f[2].Trim().Length > 0) store.members[f[1]].Add(f[2].Trim());
                }
            }
            catch (Exception e)
            {
                ok = false;
                Log.Write("folders unreadable: " + e.Message);
            }
            return store;
        }

        public void Save()
        {
            var lines = new List<string> { "# MT Manager folders: F id name, M id copy (a copy can be in several folders)", "# SchemaVersion=" + DataSchema.Current };
            foreach (Folder f in folders)
            {
                lines.Add("F\t" + f.Id + "\t" + TextUtil.OneLine(f.Name) + string.Concat(f.Extra.Select(x => "\t" + TextUtil.OneLine(x))));
                foreach (string c in members[f.Id].OrderBy(x => x, StringComparer.OrdinalIgnoreCase)) lines.Add("M\t" + f.Id + "\t" + TextUtil.OneLine(c));
            }
            TextUtil.WriteLinesSafely(FilePath, lines);
        }

        static string Norm(string name) { return TextUtil.OneLine(name).Replace("‌", "").Replace(" ", "").ToLowerInvariant(); }

        /// <summary>Null when the name can be used for a new folder, or for the folder with exceptId when renaming it.</summary>
        public string NameProblem(string name, string exceptId = null)
        {
            string n = (name ?? "").Trim();
            if (n.Length == 0) return Lang.T("یک نام برای پوشه بنویسید.", "Write a name for the folder.");
            if (n.IndexOf('\n') >= 0 || n.IndexOf('\r') >= 0 || n.IndexOf('\t') >= 0) return Lang.T("نام پوشه باید در یک خط باشد.", "The folder name must be on one line.");
            if (n.Length > MaxName) return Lang.T("نام پوشه حداکثر ", "A folder name has at most ") + TextUtil.PersianDigits(MaxName.ToString()) + Lang.T(" حرف است.", " characters.");
            // These separate several folders in one cell of the Excel file.
            if (n.IndexOfAny(Csv.FolderSeparators) >= 0) return Lang.T("نام پوشه نمی‌تواند «؛» یا «;» یا «|» داشته باشد.", "A folder name cannot have “؛”, “;” or “|”.");
            if (Norm(n) == Norm(AllTitle) || Norm(n) == Norm(NoneTitle)) return Lang.T("این نام را خود برنامه به کار می‌برد؛ نام دیگری انتخاب کنید.", "The program itself uses this name; choose another name.");
            Folder same = folders.FirstOrDefault(f => f.Id != exceptId && Norm(f.Name) == Norm(n));
            if (same != null) return Lang.T("پوشه‌ای به نام «", "There is already a folder named “") + same.Name + Lang.T("» هست.", "”.");
            return null;
        }

        public Folder Create(string name)
        {
            string problem = NameProblem(name);
            if (problem != null) throw new UserMessage(problem);
            int next = 1;
            foreach (Folder f in folders)
            {
                int n;
                if (f.Id.StartsWith("f") && int.TryParse(f.Id.Substring(1), out n)) next = Math.Max(next, n + 1);
            }
            var folder = new Folder { Id = "f" + next, Name = TextUtil.OneLine(name) };
            folders.Add(folder);
            members[folder.Id] = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            return folder;
        }

        public void Rename(string id, string name)
        {
            Folder f = Get(id);
            if (f == null) return;
            string problem = NameProblem(name, id);
            if (problem != null) throw new UserMessage(problem);
            f.Name = TextUtil.OneLine(name);
        }

        /// <summary>The folder goes; its students stay, in their other folders or in "بدون پوشه".</summary>
        public void Delete(string id)
        {
            folders.RemoveAll(f => f.Id == id);
            members.Remove(id);
        }

        public bool Has(string id, string copy) { HashSet<string> m; return members.TryGetValue(id, out m) && m.Contains(copy); }

        public void Add(string id, IEnumerable<string> copies)
        {
            HashSet<string> m;
            if (!members.TryGetValue(id, out m)) return;
            foreach (string c in copies) m.Add(c);
        }

        public void Remove(string id, IEnumerable<string> copies)
        {
            HashSet<string> m;
            if (!members.TryGetValue(id, out m)) return;
            foreach (string c in copies) m.Remove(c);
        }

        /// <summary>Into one folder: out of the folder they are seen in (fromId), or out of every other folder when fromId is null.</summary>
        public void Move(IEnumerable<string> copies, string toId, string fromId = null)
        {
            List<string> list = copies.ToList();
            if (Get(toId) == null) return;
            foreach (Folder f in folders)
                if (f.Id != toId && (fromId == null || f.Id == fromId)) Remove(f.Id, list);
            Add(toId, list);
        }

        /// <summary>The folders a copy is in, in the folders' order.</summary>
        public List<Folder> Of(string copy) { return folders.Where(f => members[f.Id].Contains(copy)).ToList(); }

        /// <summary>How many of the copies given are in a folder.</summary>
        public int Count(string id, IEnumerable<string> copies) { HashSet<string> m; return members.TryGetValue(id, out m) ? copies.Count(m.Contains) : 0; }

        public bool Unfiled(string copy) { return folders.All(f => !members[f.Id].Contains(copy)); }

        /// <summary>0 when none of the copies is in the folder, 1 some, 2 all (the check mark in the menu).</summary>
        public int State(string id, IList<string> copies)
        {
            int n = Count(id, copies);
            return n == 0 ? 0 : n == copies.Count ? 2 : 1;
        }

        /// <summary>A removed copy leaves every folder. Only called when a copy is really removed: a copies folder on a drive
        /// that is not there for a moment must not empty the folders.</summary>
        public void Forget(IEnumerable<string> copies)
        {
            List<string> list = copies.ToList();
            foreach (HashSet<string> m in members.Values) foreach (string c in list) m.Remove(c);
        }
    }

    // ------------------------------------------------------------------ processes

    public static class Processes
    {
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr OpenProcess(uint access, bool inherit, int pid);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool QueryFullProcessImageName(IntPtr process, int flags, StringBuilder name, ref int size);

        [DllImport("kernel32.dll")]
        static extern bool CloseHandle(IntPtr handle);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool GetProcessTimes(IntPtr process, out long creation, out long exit, out long kernel, out long user);

        const uint QueryLimitedInformation = 0x1000;

        /// <summary>Full exe path of a process; works for 32-bit MT4 from this 64-bit program too.</summary>
        public static string PathOf(Process p)
        {
            try
            {
                IntPtr h = OpenProcess(QueryLimitedInformation, false, p.Id);
                if (h != IntPtr.Zero)
                {
                    try
                    {
                        var sb = new StringBuilder(1024);
                        int size = sb.Capacity;
                        if (QueryFullProcessImageName(h, 0, sb, ref size)) return sb.ToString(0, size);
                    }
                    finally { CloseHandle(h); }
                }
            }
            catch { }
            try { return p.MainModule.FileName; } catch { return null; }
        }

        /// <summary>When a process was created (Windows' own record, as a UTC file time); 0 when it cannot be read.
        /// With the process id it names one run of a program: an id used again later has another time.</summary>
        public static long StartOf(int pid)
        {
            try
            {
                IntPtr h = OpenProcess(QueryLimitedInformation, false, pid);
                if (h != IntPtr.Zero)
                {
                    try
                    {
                        long created, exit, kernel, user;
                        if (GetProcessTimes(h, out created, out exit, out kernel, out user) && created > 0) return created;
                    }
                    finally { CloseHandle(h); }
                }
            }
            catch { }
            try
            {
                using (Process p = Process.GetProcessById(pid)) return p.StartTime.ToUniversalTime().ToFileTimeUtc();
            }
            catch { return 0; }
        }

        /// <summary>Running terminals by exe path, lower case. The caller owns the returned Process wrappers and must
        /// dispose them after reading the snapshot; disposing a wrapper does not close its terminal.</summary>
        public static Dictionary<string, Process> Running()
        {
            var map = new Dictionary<string, Process>();
            foreach (string name in new[] { "terminal", "terminal64" })
            {
                Process[] list;
                try { list = Process.GetProcessesByName(name); } catch { continue; }
                foreach (Process p in list)
                {
                    string path = PathOf(p);
                    if (path == null) { p.Dispose(); continue; }
                    string key = path.ToLowerInvariant();
                    Process previous;
                    if (map.TryGetValue(key, out previous)) previous.Dispose();
                    map[key] = p;
                }
            }
            return map;
        }

        public static bool IsRunningNow(string path)
        {
            var snapshot=Running();
            try{return IsRunning(snapshot,path);}finally{foreach(var p in snapshot.Values)p.Dispose();}
        }

        /// <summary>3.27.3: the ids of the MetaTraders running now, in one line; only to notice that one opened or closed.</summary>
        public static string RunningKey()
        {
            var ids = new List<int>();
            foreach (string name in new[] { "terminal", "terminal64" })
            {
                Process[] list;
                try { list = Process.GetProcessesByName(name); } catch { continue; }
                foreach (Process p in list) { try { ids.Add(p.Id); } catch { } p.Dispose(); }
            }
            ids.Sort();
            return string.Join(",", ids);
        }

        public static bool IsRunning(Dictionary<string, Process> running, string exe)
        {
            return running.ContainsKey(exe.ToLowerInvariant());
        }

        /// <summary>MT4 terminals open in this Windows session: the program's copies, the broker's own install and any other.</summary>
        public static int Mt4InSession()
        {
            int session = -1;
            try { using (Process self = Process.GetCurrentProcess()) session = self.SessionId; } catch { }
            int n = 0;
            Process[] list;
            try { list = Process.GetProcessesByName(Path.GetFileNameWithoutExtension(Kinds.Exe(Kind.MT4))); } catch { return 0; }
            foreach (Process p in list)
            {
                try { if (session < 0 || p.SessionId == session) n++; }
                catch { n++; }
                finally { p.Dispose(); }
            }
            return n;
        }
    }

    /// <summary>The MetaTraders this program opened, each by its process id, its start time and its file. Kept in the data folder,
    /// so they are still known after the program is closed and opened again. Only these are ever closed from the program:
    /// a MetaTrader opened any other way (by hand, by another program, the broker's own install) is never closed or changed from here.</summary>
    public static class Owned
    {
        public sealed class Entry
        {
            public int Pid;
            /// <summary>The process's start, as a UTC file time.</summary>
            public long Start;
            public string Exe = "";
        }

        /// <summary>A terminal may close and come back for MetaTrader's own update: so long, an entry waits for it.</summary>
        public static readonly TimeSpan Grace = TimeSpan.FromMinutes(10);
        /// <summary>A terminal that MetaTrader starts again after updating itself does so within minutes of the start.</summary>
        public static readonly TimeSpan UpdateWindow = TimeSpan.FromMinutes(5);

        public static string FilePath { get { return Path.Combine(AppPaths.DataDir, "opened.txt"); } }

        static readonly object Gate = new object();

        public static List<Entry> Parse(IEnumerable<string> lines)
        {
            var list = new List<Entry>();
            foreach (string line in lines)
            {
                string[] p = line.Split('\t');
                int pid;
                long start;
                if (p.Length < 3 || !int.TryParse(p[0], out pid) || !long.TryParse(p[1], out start) || pid <= 0 || start <= 0 || p[2].Trim().Length == 0) continue;
                list.Add(new Entry { Pid = pid, Start = start, Exe = p[2].Trim() });
            }
            return list;
        }

        public static List<string> Format(IEnumerable<Entry> list)
        {
            return list.Select(e => e.Pid + "\t" + e.Start + "\t" + e.Exe).ToList();
        }

        static List<Entry> Read()
        {
            try { return File.Exists(FilePath) ? Parse(File.ReadAllLines(FilePath, Encoding.UTF8)) : new List<Entry>(); }
            catch (Exception e) { Log.Write("opened list: " + e.Message); return new List<Entry>(); }
        }

        static void Write(List<Entry> list)
        {
            try
            {
                Directory.CreateDirectory(AppPaths.DataDir);
                string temp = FilePath + ".new";
                File.WriteAllLines(temp, Format(list), Encoding.UTF8);
                if (File.Exists(FilePath)) File.Replace(temp, FilePath, null, true); else File.Move(temp, FilePath);
            }
            catch (Exception e) { Log.Write("opened list: " + e.Message); }
        }

        /// <summary>The program's window and its start without a window (with Windows) may both write: one at a time.</summary>
        static T Locked<T>(Func<T> work)
        {
            lock (Gate)
            {
                using (var m = new System.Threading.Mutex(false, "MTManager-opened-list"))
                {
                    bool mine = false;
                    try { mine = m.WaitOne(5000); }
                    catch (System.Threading.AbandonedMutexException) { mine = true; }
                    try { return work(); }
                    finally { if (mine) m.ReleaseMutex(); }
                }
            }
        }

        /// <summary>Records a MetaTrader this program has just started, or the one MetaTrader started again while updating it.</summary>
        public static void Add(int pid, long start, string exe)
        {
            if (pid <= 0 || start <= 0 || string.IsNullOrEmpty(exe)) { Log.Write("not recorded as opened here: " + exe + " (no process time)"); return; }
            Locked(() =>
            {
                List<Entry> list = Read();
                list.RemoveAll(e => string.Equals(e.Exe, exe, StringComparison.OrdinalIgnoreCase));
                list.Add(new Entry { Pid = pid, Start = start, Exe = exe });
                Write(list);
                return 0;
            });
        }

        public static void Add(Process p, string exe)
        {
            if (p == null) return;
            int pid;
            try { pid = p.Id; } catch { return; }
            Add(pid, Processes.StartOf(pid), exe);
        }

        /// <summary>Whether the program's log tells that it started this copy at about the given moment
        /// ("started MT5-01 …", or MetaTrader starting it again after its update while the program followed it).</summary>
        public static bool StartedPerLog(IEnumerable<string> logLines, string name, DateTime processStartLocal)
        {
            var persian = new System.Globalization.PersianCalendar();
            foreach (string raw in logLines)
            {
                string line = raw.TrimEnd('\r');
                if (line.Length < 21) continue;
                string text = line.Substring(19).Trim();
                bool started = text == "started " + name || text.StartsWith("started " + name + " ", StringComparison.Ordinal) ||
                               (text.StartsWith(name + " ", StringComparison.Ordinal) && text.Contains("started") && text.Contains("again") && text.Contains("MetaTrader"));
                if (!started) continue;
                DateTime at;
                if (!DateTime.TryParseExact(line.Substring(0, 19), "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out at)) continue;
                // On a Windows set to Persian the log's dates are in the Persian calendar (1405-08-19).
                if (at.Year < 1700)
                {
                    try { at = persian.ToDateTime(at.Year, at.Month, at.Day, at.Hour, at.Minute, at.Second, 0); }
                    catch { continue; }
                }
                if (Math.Abs((at - processStartLocal).TotalSeconds) <= 60) return true;
            }
            return false;
        }

        /// <summary>Once, on the first start of a version that keeps this list (3.12): the MetaTraders an earlier version opened
        /// are still running. Each is recorded when the program's own log shows it started that copy at the moment the process started;
        /// any other stays not ours. The list is written even when empty, so this happens only once.</summary>
        public static int AdoptFromLog(IEnumerable<Instance> copies, Dictionary<string, Process> running)
        {
            if (File.Exists(FilePath)) return 0;
            var lines = new List<string>();
            foreach (string f in new[] { AppPaths.LogFile + ".old", AppPaths.LogFile })
            {
                string text = TextFiles.ReadText(f);
                if (text != null) lines.AddRange(text.Split('\n'));
            }
            return Locked(() =>
            {
                if (File.Exists(FilePath)) return 0;
                var list = new List<Entry>();
                foreach (Instance i in copies)
                {
                    Process p;
                    if (!running.TryGetValue(i.Exe.ToLowerInvariant(), out p)) continue;
                    int pid;
                    try { pid = p.Id; } catch { continue; }
                    long start = Processes.StartOf(pid);
                    if (start == 0 || !StartedPerLog(lines, i.Name, DateTime.FromFileTimeUtc(start).ToLocalTime())) continue;
                    list.Add(new Entry { Pid = pid, Start = start, Exe = i.Exe });
                }
                Write(list);
                Log.Write("opened list started: " + list.Count + " running MetaTraders were opened by the earlier version");
                return list.Count;
            });
        }

        /// <summary>The running MetaTraders this program opened, by exe path (lower case).</summary>
        public static HashSet<string> Mine(Dictionary<string, Process> running)
        {
            var pids = new Dictionary<string, int>();
            foreach (KeyValuePair<string, Process> r in running)
                try { pids[r.Key] = r.Value.Id; } catch { }
            return Mine(pids, Processes.StartOf, (exe, since) =>
                SelfUpdate.Since(new Instance { Dir = Path.GetDirectoryName(exe) }, DateTime.FromFileTimeUtc(since).ToLocalTime()), DateTime.UtcNow);
        }

        /// <summary>Which running terminals (exe path, lower case → process id) are the ones this program opened.
        /// An entry matches only the same process: same id and same start time. One more case counts: when the recorded one
        /// is gone and its copy runs again in a process that started within minutes, after its journal told of MetaTrader's own
        /// update since the start; that is MetaTrader starting it again, and the entry follows it.
        /// Entries of terminals that are gone are dropped (after a grace time, as an update may be bringing them back).</summary>
        public static HashSet<string> Mine(IDictionary<string, int> running, Func<int, long> startOf, Func<string, long, bool> updatedSince, DateTime nowUtc)
        {
            return Locked(() =>
            {
                List<Entry> list = Read();
                var mine = new HashSet<string>();
                bool changed = false;
                long now = nowUtc.ToFileTimeUtc();
                foreach (Entry e in list.ToList())
                {
                    string key = e.Exe.ToLowerInvariant();
                    int pid;
                    if (!running.TryGetValue(key, out pid))
                    {
                        if (now - e.Start > Grace.Ticks) { list.Remove(e); changed = true; }
                        continue;
                    }
                    long start = startOf(pid);
                    if (pid == e.Pid && start != 0 && Math.Abs(start - e.Start) <= TimeSpan.TicksPerSecond) { mine.Add(key); continue; }
                    if (start > e.Start && start - e.Start <= UpdateWindow.Ticks && updatedSince(e.Exe, e.Start))
                    {
                        Log.Write("MetaTrader started " + e.Exe + " again after updating itself: still one opened here");
                        e.Pid = pid;
                        e.Start = start;
                        mine.Add(key);
                        changed = true;
                        continue;
                    }
                    // Another run of the same copy: opened some other way.
                    list.Remove(e);
                    changed = true;
                }
                if (changed) Write(list);
                return mine;
            });
        }
    }

    /// <summary>Legacy admission setting for report/import workers, retained for compatibility.
    /// Manual opening does not use this limit. This is not a proven universal limit of MT4.</summary>
    public static class Mt4Limit
    {
        public const int Default = 32, Max = 500;

        public static int Clamp(int n) { return Math.Max(1, Math.Min(Max, n)); }

        /// <summary>Whether one more MT4 may start now.</summary>
        public static bool Room(int open, int max) { return open < Clamp(max); }
    }

    // ------------------------------------------------------------------ finding installs and copies

    public static class Installs
    {
        /// <summary>Installed terminals of one kind: one level under the usual folders, plus every terminal
        /// Windows has run before (their AppData folders name the install folder). Copies are skipped.</summary>
        public static List<string> Find(Kind kind, Settings s) { return Find(kind, s.AllFolders); }

        public static List<string> Find(Kind kind, string baseDir) { return Find(kind, new[] { baseDir }); }

        /// <summary>The MetaTraders installed on this computer; the program's own copies (in the given folders) are not counted.</summary>
        public static List<string> Find(Kind kind, IEnumerable<string> copyFolders)
        {
            var found = new List<string>();
            string exe = Kinds.Exe(kind);
            List<string> skips = copyFolders.Where(x => !string.IsNullOrWhiteSpace(x)).Select(x => x.TrimEnd('\\', '/').ToLowerInvariant() + "\\").ToList();

            Action<string> consider = dir =>
            {
                try
                {
                    if (string.IsNullOrEmpty(dir)) return;
                    dir = dir.Trim().TrimEnd('\\', '/');
                    if (!File.Exists(Path.Combine(dir, exe))) return;
                    // An old 32-bit MT5 also has terminal.exe; it is not an MT4.
                    if (kind == Kind.MT4 && File.Exists(Path.Combine(dir, "terminal64.exe"))) return;
                    if (skips.Any(skip => (dir.ToLowerInvariant() + "\\").StartsWith(skip))) return;
                    if (!found.Any(f => string.Equals(f, dir, StringComparison.OrdinalIgnoreCase))) found.Add(dir);
                }
                catch { }
            };

            var roots = new[]
            {
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                Environment.GetEnvironmentVariable("ProgramFiles(x86)"),
                Environment.GetEnvironmentVariable("ProgramW6432"),
                @"C:\", @"D:\",
            };
            foreach (string root in roots.Where(r => !string.IsNullOrEmpty(r)).Distinct(StringComparer.OrdinalIgnoreCase))
            {
                string[] dirs;
                try { if (!Directory.Exists(root)) continue; dirs = Directory.GetDirectories(root); } catch { continue; }
                foreach (string d in dirs) consider(d);
            }
            foreach (string origin in OriginFiles()) consider(ReadOrigin(origin));
            return found;
        }

        static IEnumerable<string> OriginFiles()
        {
            string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MetaQuotes", "Terminal");
            if (!Directory.Exists(root)) yield break;
            string[] dirs;
            try { dirs = Directory.GetDirectories(root); } catch { yield break; }
            foreach (string d in dirs)
            {
                string f = Path.Combine(d, "origin.txt");
                if (File.Exists(f)) yield return f;
            }
        }

        static string ReadOrigin(string file)
        {
            try { return File.ReadAllText(file).Trim().TrimEnd('\\'); } catch { return null; }
        }

        /// <summary>The AppData data folder of a normal (non-portable) install, or null.</summary>
        public static string FindDataFolder(string installDir)
        {
            string want = installDir.TrimEnd('\\', '/');
            foreach (string origin in OriginFiles())
            {
                if (string.Equals(ReadOrigin(origin), want, StringComparison.OrdinalIgnoreCase)) return Path.GetDirectoryName(origin);
            }
            return null;
        }

        /// <summary>The copies in every folder the program knows; a name already seen in an earlier folder is left out.</summary>
        public static List<Instance> Copies(Settings s)
        {
            var list = new List<Instance>();
            foreach (string folder in s.AllFolders)
                foreach (Instance i in Copies(folder))
                {
                    if (list.Any(x => string.Equals(x.Name, i.Name, StringComparison.OrdinalIgnoreCase)))
                    {
                        Log.Write("copy name used twice, the second one is not listed: " + i.Dir);
                        continue;
                    }
                    list.Add(i);
                }
            return list;
        }

        public static List<Instance> Copies(string baseDir)
        {
            var list = new List<Instance>();
            if (!Directory.Exists(baseDir)) return list;
            string[] dirs;
            try { dirs = Directory.GetDirectories(baseDir); } catch { return list; }
            foreach (string d in dirs.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
            {
                Kind? k = Kinds.Detect(d);
                if (k.HasValue) list.Add(new Instance { Name = Path.GetFileName(d), Kind = k.Value, Dir = d });
            }
            return list;
        }
    }

    // ------------------------------------------------------------------ creating copies

    public sealed class CreateRequest
    {
        public Kind Kind;
        public string Source;
        public int Count;
        public string Prefix;
        public bool CopyData = true;
        /// <summary>Where the copies go; empty means the default folder (Settings.BaseDir).</summary>
        public string Folder;
    }

    /// <summary>Only broker endpoint catalogs travel from an installed terminal's data directory.
    /// Account stores, terminal/proxy settings, credentials, charts and history are never copied here.</summary>
    public static class PortableServers
    {
        static readonly object gate = new object();
        const long MaxCatalogBytes = 32 * 1024 * 1024;
        public static string Subdirectory(string root, string name)
        {
            string direct = Path.Combine(root, name);
            if (Directory.Exists(direct)) return direct;
            try { return Directory.GetDirectories(root).FirstOrDefault(d => string.Equals(Path.GetFileName(d), name, StringComparison.OrdinalIgnoreCase)) ?? direct; }
            catch { return direct; }
        }
        static bool Linked(string path) { return (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0; }
        public static bool Allowed(string name)
        { return string.Equals(name, "servers.dat", StringComparison.OrdinalIgnoreCase) || string.Equals(Path.GetExtension(name), ".srv", StringComparison.OrdinalIgnoreCase); }
        public static IEnumerable<string> Roots(string install, Func<string, string> dataFolder = null)
        {
            var result = new List<string> { install };
            string data = (dataFolder ?? Installs.FindDataFolder)(install);
            if (!string.IsNullOrWhiteSpace(data) && !string.Equals(Path.GetFullPath(install), Path.GetFullPath(data), StringComparison.OrdinalIgnoreCase)) result.Add(data);
            return result;
        }
        public static bool Knows(string root, Kind kind, string server)
        {
            try
            {
                if (kind == Kind.MT4)
                {
                    string config = Subdirectory(root, "config");
                    return Directory.Exists(config) && Directory.GetFiles(config).Any(f => string.Equals(Path.GetExtension(f), ".srv", StringComparison.OrdinalIgnoreCase) && string.Equals(Path.GetFileNameWithoutExtension(f), server, StringComparison.OrdinalIgnoreCase));
                }
                string bases = Subdirectory(root, "Bases");
                return Directory.Exists(bases) && Directory.GetDirectories(bases).Any(d => string.Equals(Path.GetFileName(d), server, StringComparison.OrdinalIgnoreCase));
            }
            catch { return false; }
        }
        static Dictionary<string, string> Files(string install, Kind kind, string server, Func<string, string> dataFolder)
        {
            var found = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            // AppData wins over factory defaults when both contain the same endpoint catalog.
            foreach (string root in Roots(install, dataFolder))
            {
                string config = Subdirectory(root, "config");
                if (!Directory.Exists(config) || Linked(root) || Linked(config)) continue;
                int count = 0;
                foreach (string file in Directory.EnumerateFiles(config))
                {
                    if (++count > 4096) throw new InvalidDataException("The broker configuration contains too many files.");
                    string name = Path.GetFileName(file);
                    if (!Allowed(name) || Linked(file)) continue;
                    if (server != null && kind == Kind.MT4 && !name.Equals("servers.dat", StringComparison.OrdinalIgnoreCase) && !Path.GetFileNameWithoutExtension(file).Equals(server, StringComparison.OrdinalIgnoreCase)) continue;
                    found[name] = file;
                }
            }
            return found;
        }
        static byte[] ReadStable(string path)
        {
            for (int attempt = 0; attempt < 2; attempt++)
            {
                var before = new FileInfo(path);
                if (before.Length <= 0 || before.Length > MaxCatalogBytes) throw new InvalidDataException("The broker server catalog is empty or too large.");
                long size = before.Length; DateTime time = before.LastWriteTimeUtc;
                byte[] bytes;
                using (var input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                using (var output = new MemoryStream())
                {
                    var buffer = new byte[65536]; int n;
                    while ((n = input.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        if (output.Length + n > MaxCatalogBytes) throw new InvalidDataException("The broker server catalog grew beyond its limit.");
                        output.Write(buffer, 0, n);
                    }
                    bytes = output.ToArray();
                }
                var after = new FileInfo(path);
                if (bytes.LongLength == size && after.Length == size && after.LastWriteTimeUtc == time) return bytes;
            }
            throw new IOException("The installed terminal is changing its server catalog; retry after closing it.");
        }
        // Caller owns the destination, which must be closed. Writes are atomic and keep a one-time endpoint backup.
        public static int Sync(string install, string destination, Kind kind, string server = null, Func<bool> cancel = null, Func<string, string> dataFolder = null)
        {
            lock (gate)
            {
                if (string.Equals(Path.GetFullPath(install).TrimEnd('\\', '/'), Path.GetFullPath(destination).TrimEnd('\\', '/'), StringComparison.OrdinalIgnoreCase)) return 0;
                int changed = 0;
                string targetConfig = Subdirectory(destination, "config");
                if (Directory.Exists(destination) && Linked(destination) || Directory.Exists(targetConfig) && Linked(targetConfig)) throw new IOException("A linked destination configuration was preserved.");
                foreach (var pair in Files(install, kind, server, dataFolder))
                {
                    if (cancel != null && cancel()) throw new OperationCanceledException();
                    string target = Path.Combine(targetConfig, pair.Key);
                    if (Directory.Exists(targetConfig)) target = Directory.GetFiles(targetConfig).FirstOrDefault(f => Path.GetFileName(f).Equals(pair.Key, StringComparison.OrdinalIgnoreCase)) ?? target;
                    var sourceInfo = new FileInfo(pair.Value); var targetInfo = new FileInfo(target);
                    if (sourceInfo.Length == 0) continue; // An uninitialized catalog cannot replace a working one.
                    if (targetInfo.Exists && targetInfo.Length > MaxCatalogBytes) throw new InvalidDataException("An oversized existing server catalog was preserved.");
                    if (targetInfo.Exists && Linked(target)) throw new IOException("A linked server catalog was preserved.");
                    byte[] bytes = ReadStable(pair.Value);
                    if (targetInfo.Exists && targetInfo.Length == bytes.Length && ReadStable(target).SequenceEqual(bytes)) continue;
                    Directory.CreateDirectory(targetConfig);
                    if (targetInfo.Exists && !File.Exists(target + ".mtm-server-backup")) File.Copy(target, target + ".mtm-server-backup", false);
                    string temporary = target + "." + Guid.NewGuid().ToString("N") + ".new";
                    try
                    {
                        File.WriteAllBytes(temporary, bytes);
                        if (cancel != null && cancel()) throw new OperationCanceledException();
                        if (File.Exists(target)) File.Replace(temporary, target, null, true); else File.Move(temporary, target);
                        File.SetLastWriteTimeUtc(target, sourceInfo.LastWriteTimeUtc); changed++;
                    }
                    finally { try { if (File.Exists(temporary)) File.Delete(temporary); } catch { } }
                }
                return changed;
            }
        }
        public static int RefreshClosed(Instance copy, Settings settings, Account account)
        {
            if (account == null || !account.HasLogin || !File.Exists(copy.Exe)) return 0;
            if (Processes.IsRunningNow(copy.Exe)) return 0;
            bool sure;
            string install = ServerCatalog.InstallFor(copy.Kind, account.Server, settings, out sure);
            if (install == null) return 0;
            return Sync(install, copy.Dir, copy.Kind, account.Server);
        }
    }

    public static class LaunchMemoryPolicy
    {
        public static bool StartupTimedOut(double seconds, bool hasWindow) { return !hasWindow && seconds >= 15; }
        public static ulong Reserve(ulong totalMb) { return Math.Max(768UL, Math.Min(4096UL, totalMb / 10)); }
        public static ulong Required(Kind kind, ulong measuredPeakMb)
        { return Math.Max(kind == Kind.MT4 ? 256UL : 512UL, measuredPeakMb + measuredPeakMb / 4); }
        public static bool CanStart(ulong totalMb, ulong freeMb, Kind kind, ulong measuredPeakMb)
        { return totalMb > 0 && freeMb >= Reserve(totalMb) + Required(kind, measuredPeakMb); }
    }

    public static class CopyMaker
    {
        static readonly HashSet<string> SkipDirs = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "logs" };

        public static string CleanPrefix(string prefix, Kind kind)
        {
            string p = Regex.Replace((prefix ?? "").Trim(), @"[\\/:*?""<>|\s]+", "_");
            return p.Length == 0 ? kind.ToString() : p;
        }

        public static int NextIndex(string baseDir, string prefix) { return NextIndex(new[] { baseDir }, prefix); }

        /// <summary>The next free number over every folder, so a name (the key of its account) is never used twice.</summary>
        public static int NextIndex(IEnumerable<string> folders, string prefix)
        {
            int max = 0;
            var pattern = new Regex("^" + Regex.Escape(prefix) + @"-([0-9]+)$", RegexOptions.IgnoreCase);
            foreach (string folder in folders)
            {
                if (string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder)) continue;
                foreach (string d in Directory.GetDirectories(folder))
                {
                    Match m = pattern.Match(Path.GetFileName(d));
                    if (m.Success) max = Math.Max(max, int.Parse(m.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture));
                }
            }
            return max + 1;
        }

        /// <summary>A folder to make copies in, cleaned up and checked; throws with a message for the user.
        /// A drive alone (D:\\) gets its own MetaTrader folder.</summary>
        public static string CheckFolder(string dir)
        {
            dir = (dir ?? "").Trim().Trim('"').TrimEnd('\\', '/');
            if (dir.Length == 0) throw new UserMessage(Lang.T("پوشه‌ی ساخت را انتخاب کنید.", "Choose the folder for the copies."));
            if (dir.Length <= 2) dir += @"\MetaTrader";
            if (!Path.IsPathRooted(dir)) throw new UserMessage(Lang.T("مسیر کامل پوشه را بدهید، مثلاً D:\\MetaTrader", "Give the full path of the folder, e.g. D:\\MetaTrader"));
            if (dir.IndexOf("Program Files", StringComparison.OrdinalIgnoreCase) >= 0)
                throw new UserMessage(Lang.T("داخل Program Files نه: نسخه‌ها باید بتوانند در پوشه‌ی خودشان بنویسند. پوشه‌ی دیگری انتخاب کنید.", "Not inside Program Files: the copies must be able to write in their own folder. Choose another folder."));
            if (!Checks.CanWrite(dir)) throw new UserMessage(Lang.T("در این پوشه نمی‌شود نوشت: ", "Cannot write in this folder: ") + dir + Lang.T("\nپوشه‌ی دیگری انتخاب کنید.", "\nChoose another folder."));
            return dir;
        }

        /// <summary>Bytes in a folder; with lean, without what a copy does not need at its top (see Lean).</summary>
        static void CheckCopyCancelled(Func<bool> cancelled)
        {
            if (cancelled != null && cancelled()) throw new OperationCanceledException();
        }

        public static long FolderSize(string dir, bool lean = false, Func<bool> cancelled = null)
        {
            CheckCopyCancelled(cancelled);
            if (!Directory.Exists(dir)) return 0;
            long sum = 0;
            try
            {
                foreach (string f in Directory.GetFiles(dir))
                {
                    CheckCopyCancelled(cancelled);
                    if (lean && Lean.IsExtraFile(Path.GetFileName(f))) continue;
                    try { sum += new FileInfo(f).Length; } catch { }
                }
                foreach (string d in Directory.GetDirectories(dir))
                {
                    CheckCopyCancelled(cancelled);
                    string name = Path.GetFileName(d);
                    if (SkipDirs.Contains(name) || (lean && Lean.IsExtraDir(name))) continue;
                    sum += FolderSize(d, false, cancelled);
                }
            }
            catch (OperationCanceledException) { throw; }
            catch (TimeoutException) { throw; }
            catch { }
            return sum;
        }

        /// <summary>Existing callers retain File.Copy; bulk import can cancel between file chunks.</summary>
        public static void CopyDir(string from, string to, bool lean = false, Func<bool> cancelled = null, Action<string> detail = null)
        {
            CheckCopyCancelled(cancelled);
            Directory.CreateDirectory(to);
            foreach (string f in Directory.GetFiles(from))
            {
                CheckCopyCancelled(cancelled);
                string name = Path.GetFileName(f);
                if (Path.GetFileName(from).Equals("config", StringComparison.OrdinalIgnoreCase) && name.StartsWith("accounts.", StringComparison.OrdinalIgnoreCase)) continue;
                if (lean && Lean.IsExtraFile(name)) continue;
                if (detail != null) detail(name);
                string target = Path.Combine(to, name);
                if (cancelled == null) File.Copy(f, target, true);
                else
                {
                    using (var input = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.Read))
                    using (var output = new FileStream(target, FileMode.Create, FileAccess.Write, FileShare.None))
                    {
                        byte[] buffer = new byte[256 * 1024];
                        while (true)
                        {
                            CheckCopyCancelled(cancelled);
                            int read = input.Read(buffer, 0, buffer.Length);
                            if (read == 0) break;
                            CheckCopyCancelled(cancelled);
                            output.Write(buffer, 0, read);
                        }
                    }
                }
            }
            foreach (string d in Directory.GetDirectories(from))
            {
                CheckCopyCancelled(cancelled);
                string name = Path.GetFileName(d);
                if (SkipDirs.Contains(name) || (lean && Lean.IsExtraDir(name))) continue;
                CopyDir(d, Path.Combine(to, name), false, cancelled, detail);
            }
        }

        /// <summary>Checks everything that can be checked before copying; throws with a message for the user.</summary>
        public static void Check(CreateRequest r, Settings s)
        {
            string exe = Kinds.Exe(r.Kind);
            if (string.IsNullOrWhiteSpace(r.Source) || !File.Exists(Path.Combine(r.Source, exe)))
                throw new UserMessage(Lang.T("فایل ", "File ") + exe + Lang.T(" در پوشه‌ی مبدأ پیدا نشد. پوشه‌ی نصب متاتریدر را انتخاب کنید.", " was not found in the source folder. Choose MetaTrader's installation folder."));
            if (Processes.IsRunningNow(Path.Combine(r.Source, exe)))
                throw new UserMessage(Lang.T("متاتریدر مبدأ باز است. اول آن را ببندید، بعد دوباره امتحان کنید.", "The source MetaTrader is open. Close it first, then try again."));
            if (r.Count < 1 || r.Count > 200) throw new UserMessage(Lang.T("تعداد باید بین ۱ و ۲۰۰ باشد.", "The number must be between 1 and 200."));
            string folder = string.IsNullOrWhiteSpace(r.Folder) ? s.BaseDir : r.Folder;
            if (folder.IndexOf("Program Files", StringComparison.OrdinalIgnoreCase) >= 0)
                throw new UserMessage(Lang.T("پوشه‌ی ساخت نباید داخل Program Files باشد. پوشه‌ی دیگری انتخاب کنید.", "The copies' folder must not be inside Program Files. Choose another folder."));
            string full = Path.GetFullPath(folder).TrimEnd('\\', '/') + Path.DirectorySeparatorChar, src = Path.GetFullPath(r.Source).TrimEnd('\\', '/') + Path.DirectorySeparatorChar;
            if (full.StartsWith(src, StringComparison.OrdinalIgnoreCase))
                throw new UserMessage(Lang.T("پوشه‌ی ساخت نباید داخل پوشه‌ی متاتریدر مبدأ باشد.", "The copies' folder must not be inside the source MetaTrader's folder."));
        }

        /// <summary>Creates the copies, reporting (number, total, name) before each one. Returns the names made.</summary>
        public static List<string> Create(CreateRequest r, Settings s, Action<int, int, string> progress, Func<bool> cancelled = null, Action<string> detail = null)
        {
            CheckCopyCancelled(cancelled);
            Check(r, s);
            string source = r.Source.Trim().TrimEnd('\\', '/');
            string prefix = CleanPrefix(r.Prefix, r.Kind);
            // Experts, indicators and templates of a normal install live in AppData, not in the install folder.
            string data = r.CopyData ? Installs.FindDataFolder(source) : null;
            string[] subs = { Kinds.Mql(r.Kind), "templates", "profiles" };

            string folder = string.IsNullOrWhiteSpace(r.Folder) ? s.BaseDir : r.Folder.Trim().TrimEnd('\\', '/');
            long each = FolderSize(source, true, cancelled);
            if (data != null) foreach (string sub in subs) each += FolderSize(Path.Combine(data, sub), false, cancelled);
            Directory.CreateDirectory(folder);
            long free = new DriveInfo(Path.GetPathRoot(Path.GetFullPath(folder))).AvailableFreeSpace;
            long need = each * r.Count;
            if (need > free * 0.9)
                throw new UserMessage(Lang.T("فضای خالی کافی نیست: حدود ", "Not enough free space: about ") + TextUtil.Size(need) + Lang.T(" لازم است و ", " is needed and ") + TextUtil.Size(free) + Lang.T(" آزاد است.", " is free."));

            var made = new List<string>();
            int start = NextIndex(s.AllFolders.Concat(new[] { folder }), prefix);
            for (int k = 0; k < r.Count; k++)
            {
                string name = prefix + "-" + (start + k).ToString("00");
                if (progress != null) progress(k + 1, r.Count, name);
                string dest = Path.Combine(folder, name);
                CopyDir(source, dest, true, cancelled, detail);
                PortableServers.Sync(source, dest, r.Kind, null, cancelled);
                if (data != null)
                {
                    foreach (string sub in subs)
                    {
                        string from = Path.Combine(data, sub);
                        if (Directory.Exists(from)) CopyDir(from, Path.Combine(dest, sub), false, cancelled, detail);
                    }
                }
                made.Add(name);
                Log.Write("created " + name + " from " + source);
            }
            return made;
        }
    }

    /// <summary>What a copy needs to run and show an account, and what it does not.</summary>
    public static class Lean
    {
        // The code editor, the strategy tester and the uninstaller of the original install.
        static readonly HashSet<string> Tools = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "metaeditor.exe", "metaeditor64.exe", "metatester.exe", "metatester64.exe", "uninstall.exe",
        };
        static readonly string[] Archives = { ".rar", ".zip", ".7z" };

        public static bool IsTool(string fileName) { return Tools.Contains(fileName); }

        public static bool IsArchive(string fileName)
        {
            string ext = Path.GetExtension(fileName) ?? "";
            return Archives.Any(a => string.Equals(a, ext, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>A file at the top of an install folder that copies leave out.</summary>
        public static bool IsExtraFile(string fileName) { return IsTool(fileName) || IsArchive(fileName); }

        /// <summary>Strategy tester data (MT5 "Tester", MT4 "tester"): only for backtests.</summary>
        public static bool IsExtraDir(string dirName) { return string.Equals(dirName, "tester", StringComparison.OrdinalIgnoreCase); }
    }

    public sealed class CleanupGroup
    {
        public string Id, Title, Note;
        public readonly List<string> Paths = new List<string>();
        public long Size;
    }

    /// <summary>Finds what existing copies carry without needing it. Nothing is removed here.</summary>
    public static class Cleanup
    {
        public const int LogDays = 7;

        /// <summary>workDirs: where earlier versions built their expert (under each copies folder), offered too when present.</summary>
        public static List<CleanupGroup> Scan(IEnumerable<Instance> copies, DateTime now, IEnumerable<string> workDirs = null)
        {
            var tools = new CleanupGroup { Id = "tools", Title = Lang.T("ابزارهای اضافه: MetaEditor، تست استراتژی و uninstall", "Extra tools: MetaEditor, strategy tester and uninstall"), Note = Lang.T("برای اجرا و دیدن حساب لازم نیستند. در نصب اصلی متاتریدر سر جایشان می‌مانند.", "Not needed to run and view the account. They stay in MetaTrader's main installation.") };
            var archives = new CleanupGroup { Id = "archives", Title = Lang.T("فایل‌های فشرده (rar، zip، 7z)", "Archive files (rar, zip, 7z)"), Note = Lang.T("جزو متاتریدر نیستند؛ از پوشه‌ی نصب اصلی همراه کپی آمده‌اند.", "Not part of MetaTrader; they came with the copy from the main installation folder.") };
            var tester = new CleanupGroup { Id = "tester", Title = Lang.T("داده‌های تست استراتژی (Tester)", "Strategy tester data (Tester)"), Note = Lang.T("فقط برای بک‌تست به کار می‌آیند.", "Only used for backtests.") };
            var monitor = new CleanupGroup { Id = "monitor", Title = Lang.T("اکسپرت پایش نسخه‌های قبلی برنامه و داده‌هایش", "The monitor expert of earlier versions of the program and its data"), Note = Lang.T("دیگر به کار نمی‌رود. فایل اکسپرت پیش از هر اجرا خودکار برداشته می‌شود؛ این‌جا داده‌هایی که نوشته بود (Files\\MTManager) هم می‌رود.", "Not used any more. The expert file is removed automatically before every run; here the data it wrote (Files\\MTManager) goes too.") };
            var logs = new CleanupGroup { Id = "logs", Title = Lang.T("گزارش‌های قدیمی متاتریدر (بیش از ", "Old MetaTrader logs (more than ") + TextUtil.PersianDigits(LogDays.ToString()) + Lang.T(" روز)", " days)"), Note = Lang.T("فایل‌های log روزانه‌ی خود متاتریدر.", "MetaTrader's own daily log files.") };
            foreach (Instance i in copies)
            {
                if (!Directory.Exists(i.Dir)) continue;
                try
                {
                    foreach (string f in Directory.GetFiles(i.Dir))
                    {
                        string name = Path.GetFileName(f);
                        if (Lean.IsTool(name)) Add(tools, f);
                        else if (Lean.IsArchive(name)) Add(archives, f);
                    }
                    foreach (string d in Directory.GetDirectories(i.Dir))
                    {
                        if (!Lean.IsExtraDir(Path.GetFileName(d))) continue;
                        tester.Paths.Add(d);
                        tester.Size += CopyMaker.FolderSize(d);
                    }
                    string bin = OldMonitor.Binary(i), data = OldMonitor.DataFolder(i);
                    if (File.Exists(bin)) Add(monitor, bin);
                    if (Directory.Exists(data))
                    {
                        monitor.Paths.Add(data);
                        monitor.Size += CopyMaker.FolderSize(data);
                    }
                    foreach (string dir in new[] { Path.Combine(i.Dir, "logs"), Path.Combine(i.Dir, Kinds.Mql(i.Kind), "Logs") })
                    {
                        if (!Directory.Exists(dir)) continue;
                        foreach (string f in Directory.GetFiles(dir, "*.log"))
                        {
                            try { if ((now - File.GetLastWriteTime(f)).TotalDays > LogDays) Add(logs, f); } catch { }
                        }
                    }
                }
                catch (Exception e) { Log.Write("cleanup scan " + i.Name + ": " + e.Message); }
            }
            foreach (string work in (workDirs ?? Enumerable.Empty<string>()).Where(Directory.Exists).Distinct(StringComparer.OrdinalIgnoreCase))
            {
                monitor.Paths.Add(work);
                monitor.Size += CopyMaker.FolderSize(work);
            }
            return new List<CleanupGroup> { tools, archives, tester, monitor, logs };
        }

        static void Add(CleanupGroup g, string file)
        {
            g.Paths.Add(file);
            try { g.Size += new FileInfo(file).Length; } catch { }
        }

        /// <summary>Quick look for the banner: the extra tools only (a few file checks per copy).</summary>
        public static long ToolBytes(IEnumerable<Instance> copies)
        {
            long sum = 0;
            foreach (Instance i in copies)
            {
                try
                {
                    foreach (string f in Directory.GetFiles(i.Dir))
                        if (Lean.IsExtraFile(Path.GetFileName(f))) sum += new FileInfo(f).Length;
                }
                catch { }
            }
            return sum;
        }
    }

    /// <summary>An error meant for the user, in plain Persian.</summary>
    public sealed class UserMessage : Exception
    {
        public UserMessage(string message) : base(message) { }
    }

    // ------------------------------------------------------------------ starting terminals

    /// <summary>A start file waiting for its terminal to read it (see Launcher.StartFileDone).</summary>
    /// <summary>Bounded, credential-free close requests; requests are evidence, not proof of exit causation.</summary>
    public static class TerminalCloseAudit
    {
        static readonly object Gate=new object();
        public static string FilePath { get { return Path.Combine(AppPaths.DataDir,"terminal-close-audit.txt"); } }
        static string[] Read()
        {
            lock(Gate){try{return File.Exists(FilePath)&&new FileInfo(FilePath).Length<=256*1024?File.ReadAllLines(FilePath,Encoding.UTF8):new string[0];}catch{return new string[0];}}
        }
        public static void Record(Process process,string exe,string source)
        {
            try{Record(process.Id,Processes.StartOf(process.Id),exe,source,DateTime.UtcNow);}catch(Exception e){Log.Write("close audit unavailable: "+e.GetType().Name);}
        }
        public static void Record(int pid,long processStart,string exe,string source,DateTime utc)
        {
            try
            {
                if(pid<=0||string.IsNullOrWhiteSpace(exe)||!(new[]{"manual-close","manual-force","report-helper-close","report-helper-force","probe-cleanup"}).Contains(source))return;
                string path=Path.GetFullPath(exe);if(!new[]{"terminal.exe","terminal64.exe"}.Contains(Path.GetFileName(path),StringComparer.OrdinalIgnoreCase))return;
                string line=utc.ToUniversalTime().Ticks.ToString(CultureInfo.InvariantCulture)+"\t"+pid+"\t"+processStart+"\t"+Convert.ToBase64String(Encoding.UTF8.GetBytes(path))+"\t"+source;
                lock(Gate){var existing=Read();var rows=existing.Skip(Math.Max(0,existing.Length-191)).Concat(new[]{line});TextUtil.WriteLinesAtomically(FilePath,rows);}
                Log.Write("terminal close requested: pid="+pid+" copy="+LaunchCapacityDiagnostics.SafeCopy(Path.GetFileName(Path.GetDirectoryName(path)))+" source="+source);
            }
            catch(Exception e){Log.Write("close audit unavailable: "+e.GetType().Name);}
        }
        public static string MatchingRequest(Instance copy,int pid,DateTime since,DateTime until)
        {
            if(pid<=0)return "app-close-request=unknown (PID unavailable)";
            var matches=new List<string>();string path=Path.GetFullPath(copy.Exe);
            foreach(string row in Read())try
            {
                string[] f=row.Split('\t');long ticks;int found;
                if(f.Length!=5||!long.TryParse(f[0],out ticks)||!int.TryParse(f[1],out found)||found!=pid)continue;
                var at=new DateTime(ticks,DateTimeKind.Utc);if(at<since.ToUniversalTime().AddSeconds(-2)||at>until.ToUniversalTime().AddSeconds(5))continue;
                if(!string.Equals(Encoding.UTF8.GetString(Convert.FromBase64String(f[3])),path,StringComparison.OrdinalIgnoreCase))continue;
                matches.Add(f[4]+" UTC="+at.ToString("u")+" process-start-filetime="+f[2]);
            }catch{}
            return matches.Count==0?"app-close-request=none recorded for this PID/path/time; OS, user or external requests remain possible":"app-close-request="+string.Join("; ",matches)+" (request recorded, not proof it caused exit)";
        }
        public static string FaultMatch(string[] fields,int pid,string exe)
        {
            // Windows Application Error 1000 schema; never export full event messages/command lines.
            if(fields==null||fields.Length<12||pid<=0)return null;
            if(!string.Equals(fields[10],Path.GetFullPath(exe),StringComparison.OrdinalIgnoreCase))return null;
            uint eventPid;string value=(fields[8]??"").Trim();bool hex=value.StartsWith("0x",StringComparison.OrdinalIgnoreCase);if(hex)value=value.Substring(2);
            if(!uint.TryParse(value,hex?NumberStyles.HexNumber:NumberStyles.Integer,CultureInfo.InvariantCulture,out eventPid)||eventPid!=(uint)pid)return null;
            Func<string,string> safe=s=>{var clean=Regex.Replace(s??"",@"[^A-Za-z0-9_.-]","_");return clean.Substring(0,Math.Min(64,clean.Length));};
            return "Windows Application Error 1000: app="+safe(fields[0])+" module="+safe(fields[3])+" exception="+safe(fields[6]);
        }
        public static string WindowsFaults(Instance copy,int pid,DateTime since,DateTime until)
        {
            if(Environment.OSVersion.Platform!=PlatformID.Win32NT)return "windows-fault-events=unavailable on this OS";
            if(pid<=0)return "windows-fault-events=unknown (PID unavailable)";
            try
            {
                using(var events=new EventLog("Application"))
                {
                    var clock=Stopwatch.StartNew();int scanned=0;bool limited=false;
                    for(int n=events.Entries.Count-1;n>=0;n--)
                    {
                        if(scanned++>=256||clock.ElapsedMilliseconds>750){limited=true;break;}
                        var entry=events.Entries[n];if(entry.TimeGenerated<since.AddSeconds(-2))break;
                        if(entry.TimeGenerated>until.AddSeconds(30)||(entry.InstanceId&0xFFFF)!=1000||!string.Equals(entry.Source,"Application Error",StringComparison.OrdinalIgnoreCase))continue;
                        var match=FaultMatch(entry.ReplacementStrings,pid,copy.Exe);if(match!=null)return match+" UTC="+entry.TimeGenerated.ToUniversalTime().ToString("u");
                    }
                    return "windows-fault-events=no matching Application Error1000 in bounded scan"+(limited?" (scan limit reached)":"")+"; absence does not identify cause";
                }
            }catch(Exception e){return "windows-fault-events=unavailable "+e.GetType().Name;}
        }
        public static string Evidence(Instance copy,int pid,DateTime since,DateTime until)
        {
            return "Launch evidence: copy="+LaunchCapacityDiagnostics.SafeCopy(copy.Name)+" pid="+pid+" UTC="+since.ToUniversalTime().ToString("u")+" gone-observed-UTC="+until.ToUniversalTime().ToString("u")+"\r\n  "+MatchingRequest(copy,pid,since,until)+"\r\n  "+WindowsFaults(copy,pid,since,until);
        }
    }

    public sealed class PendingStart
    {
        public string Path;
        public int MaxWaitSeconds = Launcher.StartFileSeconds;
        public bool WaitForConfigRead;
        public bool KeepForRestart;
        public const int ProtectedSeconds = 900;
        public DateTime Time;
        public Process Process;
        public Instance Copy;
        DateTime lastJournal;
        bool configurationSeen;

        /// <summary>Why the file can go now ("window", "journal", "exited", "time"), or null to wait.</summary>
        public string Ready(DateTime now)
        {
            double seconds = (now - Time).TotalSeconds;
            if(WaitForConfigRead && KeepForRestart)return ProtectedReady(seconds,false);
            bool exited = false, window = false, journal = false;
            if (Process != null)
            {
                try
                {
                    Process.Refresh();
                    exited = Process.HasExited;
                    if (!exited) window = Process.MainWindowHandle != IntPtr.Zero;
                }
                catch { }
            }
            // The journal at most once a second: only its end is read.
            if ((WaitForConfigRead || (!exited && !window)) && Copy != null && (now - lastJournal).TotalSeconds >= 1)
            {
                lastJournal = now;
                journal = ConnectionCheck.JournalTail(Copy, Time).Any(l => WaitForConfigRead ? ConfigAcknowledged(l, Path) : l.IndexOf(Launcher.StartFileName, StringComparison.OrdinalIgnoreCase) >= 0);
            }
            if (WaitForConfigRead) { configurationSeen|=journal;return ProtectedReady(seconds, configurationSeen); }
            if (!exited && !window && !journal && seconds < MaxWaitSeconds) return null;
            return exited ? "exited" : window ? "window" : journal ? "journal" : "time";
        }
        // A splash window or an exited bootstrap process does not prove that MT4 read its configuration.
        public static string ProtectedReady(double seconds, bool acknowledged)
        {
            // Filename acknowledgement can precede asynchronous credential/EA initialization.
            // This cleanup grace does not delay spawning, queue pacing, or live polling.
            return acknowledged && seconds>=15 ? "journal" : seconds >= ProtectedSeconds ? "time" : null;
        }
        public static bool ConfigAcknowledged(string line, string path)
        {
            if (string.IsNullOrEmpty(line) || string.IsNullOrEmpty(path)) return false;
            return (line.IndexOf("Started with configuration file", StringComparison.OrdinalIgnoreCase) >= 0 || line.IndexOf("successfully initialized from start config", StringComparison.OrdinalIgnoreCase) >= 0)
                && line.IndexOf(System.IO.Path.GetFileName(path), StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }

    public sealed class StartResult
    {
        public Process Process;
        public string StartFile;
        public string Warning;
        public List<string> StartupLines;
        public bool Sandboxed;
        public bool WaitForConfigRead;
    }

    /// <summary>MT4 updates itself from the build MetaTrader has already downloaded for this Windows user
    /// (%APPDATA%\MetaQuotes\WebInstall\mt4clw): it closes, asks Windows for administrator rights, copies terminal.exe
    /// and metaeditor.exe from there into the copy and starts again, without the program's start settings.
    /// The program makes the same copy before the start, so the copy opens already up to date.</summary>
    public static class TerminalUpdate
    {
        /// <summary>Tests point this elsewhere.</summary>
        public static string CacheDirOverride;

        /// <summary>Where MetaTrader keeps its downloaded build; null for MT5 (it updates in its own way).</summary>
        public static string CacheDir(Kind kind)
        {
            if (kind != Kind.MT4) return null;
            if (CacheDirOverride != null) return CacheDirOverride;
            string app = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            return string.IsNullOrEmpty(app) ? null : Path.Combine(app, "MetaQuotes", "WebInstall", "mt4clw");
        }

        /// <summary>The file's version from its version resource; null when it has none.</summary>
        public static Version FileVersion(string path)
        {
            try
            {
                if (!File.Exists(path)) return null;
                FileVersionInfo v = FileVersionInfo.GetVersionInfo(path);
                if (v.FileMajorPart == 0 && v.FileMinorPart == 0 && v.FileBuildPart == 0 && v.FilePrivatePart == 0) return null;
                return new Version(v.FileMajorPart, v.FileMinorPart, v.FileBuildPart, v.FilePrivatePart);
            }
            catch { return null; }
        }

        /// <summary>Only a newer build of the same program (same major version) is put in place; when either is unknown nothing is done.</summary>
        public static bool Newer(Version downloaded, Version have)
        {
            return downloaded != null && have != null && downloaded.Major == have.Major && downloaded > have;
        }

        /// <summary>The downloaded build, when there is one newer than this copy's; otherwise null.</summary>
        public static Version Pending(Instance i)
        {
            string dir = CacheDir(i.Kind);
            if (dir == null) return null;
            string exe = Path.Combine(dir, Kinds.Exe(i.Kind));
            try { if (!File.Exists(exe) || new FileInfo(exe).Length < 1000000) return null; }
            catch { return null; }
            Version downloaded = FileVersion(exe);
            return Newer(downloaded, FileVersion(i.Exe)) ? downloaded : null;
        }

        /// <summary>Brings a closed copy to MetaTrader's downloaded build, as MetaTrader itself would; returns the build put in place, or null.
        /// The code editor is replaced only where the copy has it (lean copies leave it out).</summary>
        public static Version Apply(Instance i)
        {
            Version downloaded = Pending(i);
            if (downloaded == null) return null;
            string dir = CacheDir(i.Kind);
            Version had = FileVersion(i.Exe);
            // The editor first: if the terminal cannot be replaced, the next start tries both again.
            string editor = Path.Combine(dir, "metaeditor.exe"), copyEditor = Path.Combine(i.Dir, "metaeditor.exe");
            if (File.Exists(editor) && File.Exists(copyEditor) && Newer(FileVersion(editor), FileVersion(copyEditor))) Put(editor, copyEditor);
            Put(Path.Combine(dir, Kinds.Exe(i.Kind)), i.Exe);
            Log.Write(i.Name + " brought to build " + downloaded + " before starting (MetaTrader's own download; it had " + had + ")");
            return downloaded;
        }

        /// <summary>Copied next to the file first, then swapped in: the copy never has half a file.</summary>
        static void Put(string source, string target)
        {
            string temp = target + ".mtm-new";
            File.Copy(source, temp, true);
            try { File.Replace(temp, target, null, true); }
            catch
            {
                try { File.Delete(temp); } catch { }
                throw;
            }
        }

        /// <summary>Copies with a trading (master) account are never changed: MetaTrader updates those itself, as before.</summary>
        public static bool Allowed(Account acc) { return acc == null || !acc.HasLogin || acc.IsInvestor; }

        /// <summary>For the start: never stops the start; a copy that could not be brought up to date updates itself as before.</summary>
        public static void BeforeStart(Instance i)
        {
            try { Apply(i); }
            catch (Exception e) { Log.Write("update " + i.Name + " before starting: " + e.Message); }
        }
    }

    /// <summary>Process-scoped compatibility policy: RunAsInvoker retains the caller's token, it grants no administrator rights.
    /// No UAC policy, registry, ACL or machine environment is changed. An updater explicitly requiring elevation may still
    /// fail or request consent; this is not an automatic clicker for the secure desktop.</summary>
    // Per-user compatibility only. Never grants elevation, clicks consent, or changes UAC policy.
    public static class ScopedUpdaterConsent
    {
        static readonly object gate=new object();
        static readonly Dictionary<string,Instance> copies=new Dictionary<string,Instance>(StringComparer.OrdinalIgnoreCase);
        static readonly Dictionary<string,long> applied=new Dictionary<string,long>(StringComparer.OrdinalIgnoreCase);
        static readonly System.Threading.Timer timer=new System.Threading.Timer(delegate{Scan();},null,2000,2000);
        public static void Watch(Instance copy,bool enabled)
        {
            if(copy.Kind!=Kind.MT5 || Environment.OSVersion.Platform!=PlatformID.Win32NT)return;
            if(!enabled){Restore();return;}
            lock(gate){copies[Path.GetFullPath(copy.Exe)]=copy;}
            Scan();
        }
        static void Scan()
        {
            if(!System.Threading.Monitor.TryEnter(gate))return;
            try
            {
                foreach(var copy in copies.Values.ToArray())
                {
                    Apply(copy.Exe);
                    foreach(string line in ConnectionCheck.JournalTail(copy,DateTime.Now.AddDays(-1)).Take(150))
                    {
                        // Accept only a cache updater whose own journal names this exact portable target.
                        if(line.IndexOf("LiveUpdate",StringComparison.OrdinalIgnoreCase)<0 || line.IndexOf("/path:\""+copy.Dir+"\"",StringComparison.OrdinalIgnoreCase)<0)continue;
                        var match=System.Text.RegularExpressions.Regex.Match(line,"start \\\"([^\\\"]+terminal64\\.exe)\\\"",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                        if(match.Success && IsOwnCache(match.Groups[1].Value))Apply(match.Groups[1].Value);
                    }
                }
            }
            catch(Exception e){Log.Write("scoped updater policy: "+e.GetType().Name);}
            finally{System.Threading.Monitor.Exit(gate);}
        }
        static void Restore()
        {
            lock(gate)
            {
                copies.Clear();applied.Clear();
                try
                {
                    using(var backup=Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\MetaFactory\ScopedUpdaterCompatibility",true))
                    using(var key=Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers",true))
                    {
                        if(backup==null || key==null)return;
                        foreach(string path in backup.GetValueNames())
                        {
                            string saved=backup.GetValue(path) as string;
                            if(saved==null || saved.Length==0)continue;
                            string before=saved=="0"?null:saved.Substring(1);
                            if(string.Equals(key.GetValue(path,null) as string,TerminalProcessPolicy.NormalLayer(before),StringComparison.Ordinal))
                            {if(before==null)key.DeleteValue(path,false);else key.SetValue(path,before);}
                            backup.DeleteValue(path,false);
                        }
                    }
                }catch(Exception e){Log.Write("scoped updater restore: "+e.GetType().Name);}
            }
        }
        public static bool IsOwnCache(string path)
        {
            try
            {
                string root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"MetaQuotes","Terminal")+Path.DirectorySeparatorChar;
                string full=Path.GetFullPath(path);
                if(!full.StartsWith(root,StringComparison.OrdinalIgnoreCase))return false;
                string relative=full.Substring(root.Length);
                return System.Text.RegularExpressions.Regex.IsMatch(relative,@"\A[0-9a-fA-F]{32}[\\/]liveupdate[\\/]terminal64\.exe\z",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            }catch{return false;}
        }
        static void Apply(string path)
        {
            if(!File.Exists(path))return;
            long stamp=File.GetLastWriteTimeUtc(path).Ticks;long previous;
            if(applied.TryGetValue(path,out previous)&&previous==stamp)return;
            // Valid Authenticode chain AND exact vendor identity, not just embedded metadata.
            applied[path]=stamp;
            if(!Trusted(path)){Log.Write("scoped updater policy: signature trust not confirmed; compatibility left unchanged");return;}
            var cert=System.Security.Cryptography.X509Certificates.X509Certificate.CreateFromSignedFile(path);
            try
            {
                if(cert.GetName().IndexOf("CN=MetaQuotes Ltd.",StringComparison.OrdinalIgnoreCase)<0)return;
            }
            finally{cert.Reset();}
            using(var key=Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers"))
            {
                string before=key.GetValue(path,null) as string;
                using(var backup=Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\MetaFactory\ScopedUpdaterCompatibility"))
                    if(backup.GetValue(path,null)==null)backup.SetValue(path,before==null?"0":"1"+before);
                key.SetValue(path,TerminalProcessPolicy.NormalLayer(before),Microsoft.Win32.RegistryValueKind.String);
            }
            applied[path]=stamp;Log.Write("scoped updater policy: trusted MetaQuotes executable configured at current user rights: "+path);
        }
        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential,CharSet=System.Runtime.InteropServices.CharSet.Unicode)]
        struct TrustFile {public uint Size;[System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)]public string Path;public IntPtr File,Subject;}
        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        struct TrustData {public uint Size;public IntPtr Policy,Sip;public uint UI,Revocation,Choice;public IntPtr File;public uint Action;public IntPtr State,Url;public uint Flags,Context;}
        [System.Runtime.InteropServices.DllImport("wintrust.dll",ExactSpelling=true,CharSet=System.Runtime.InteropServices.CharSet.Unicode)]
        static extern int WinVerifyTrust(IntPtr window,ref Guid action,ref TrustData data);
        static bool Trusted(string path)
        {
            IntPtr file=IntPtr.Zero;var action=new Guid("00AAC56B-CD44-11d0-8CC2-00C04FC295EE");var data=new TrustData();
            try
            {
                var info=new TrustFile{Size=(uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(TrustFile)),Path=path};
                file=System.Runtime.InteropServices.Marshal.AllocHGlobal((int)info.Size);System.Runtime.InteropServices.Marshal.StructureToPtr(info,file,false);
                data.Size=(uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(TrustData));data.UI=2;data.Choice=1;data.File=file;data.Action=1;data.Flags=0x1000; // cached trust only, no network/UI
                return WinVerifyTrust(new IntPtr(-1),ref action,ref data)==0;
            }
            catch{return false;}
            finally
            {
                if(data.State!=IntPtr.Zero){data.Action=2;WinVerifyTrust(new IntPtr(-1),ref action,ref data);}
                if(file!=IntPtr.Zero){System.Runtime.InteropServices.Marshal.DestroyStructure(file,typeof(TrustFile));System.Runtime.InteropServices.Marshal.FreeHGlobal(file);}
            }
        }
    }

    public static class TerminalProcessPolicy
    {
        public const string LayerVariable = "__COMPAT_LAYER";

        public static string NormalLayer(string inherited)
        {
            var layers = (inherited ?? "").Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Where(x => !x.Equals("RunAsAdmin", StringComparison.OrdinalIgnoreCase)
                         && !x.Equals("RunAsHighest", StringComparison.OrdinalIgnoreCase)
                         && !x.Equals("RunAsInvoker", StringComparison.OrdinalIgnoreCase)).ToList();
            layers.Add("RunAsInvoker");
            return string.Join(" ", layers);
        }

        public static string UpdateElevationDiagnostics()
        {
            var text=new StringBuilder("— Update elevation diagnostics (read-only) —\r\n");
            text.AppendLine("UAC is unchanged. Invoker environment does not grant administrator rights or accept secure-desktop consent. Signature subject below is embedded metadata, not a trust verdict.");
            if(Environment.OSVersion.Platform!=PlatformID.Win32NT)return text.AppendLine("Windows-only evidence unavailable.").ToString();
            try
            {
                string app=Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),root=Path.Combine(app,"MetaQuotes","Terminal");
                if(!Directory.Exists(root))return text.AppendLine("No per-user MetaQuotes terminal cache directory.").ToString();
                var candidates=Directory.GetDirectories(root).Take(256).Select(d=>Path.Combine(d,"liveupdate","terminal64.exe")).Where(File.Exists)
                    .OrderByDescending(File.GetLastWriteTimeUtc).Take(16).ToArray();
                foreach(string path in candidates)
                {
                    try
                    {
                        var info=FileVersionInfo.GetVersionInfo(path);string signer="unavailable";
                        try{var certificate=System.Security.Cryptography.X509Certificates.X509Certificate.CreateFromSignedFile(path);try{signer=certificate.Subject;}finally{certificate.Reset();}}catch{}
                        text.AppendLine("Updater="+TextUtil.OneLine(path)+" | description="+TextUtil.OneLine(info.FileDescription??"")+" | version="+info.FileVersion+" | signature-subject="+TextUtil.OneLine(signer));
                        const string layers=@"Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers";
                        foreach(var hive in new[]{RegistryHive.CurrentUser,RegistryHive.LocalMachine})
                        {
                            try{using(var baseKey=RegistryKey.OpenBaseKey(hive,RegistryView.Default))using(var key=baseKey.OpenSubKey(layers,false))
                                text.AppendLine(hive+" compatibility="+TextUtil.OneLine(key==null?"none":Convert.ToString(key.GetValue(path,"none"))));}
                            catch{text.AppendLine(hive+" compatibility=unavailable");}
                        }
                    }catch{text.AppendLine("Updater metadata unavailable: "+TextUtil.OneLine(path));}
                }
                if(candidates.Length==0)text.AppendLine("No downloaded MT5 updater binary is currently present; cached journal paths do not prove the UAC dialog target.");
            }catch(Exception e){text.AppendLine("Updater evidence unavailable: "+e.GetType().Name);}
            return text.ToString();
        }

        public static ProcessStartInfo Prepare(ProcessStartInfo info, Settings settings)
        {
            if (settings == null || !settings.NormalTerminalRights) return info;
            // EnvironmentVariables belongs to this child only; do not call Environment.SetEnvironmentVariable.
            info.UseShellExecute = false;
            info.Verb = "";
            info.EnvironmentVariables[LayerVariable] = NormalLayer(info.EnvironmentVariables[LayerVariable]);
            return info;
        }
    }

    public static class Launcher
    {
        public const string StartFileName = "mtm-start.ini";
        public static Func<Instance, Settings, Account, List<string>> PrepareLiveManual;
        /// <summary>How long the start file (which may hold a password) stays before it is deleted.</summary>
        public const int StartFileSeconds = 10;
        public const string LiveMt5ProfileName = "MetaFactoryLiveOnly";
        /// <summary>How long a MetaTrader asked to close may take (it saves its charts and settings) before it is ended.</summary>
        public const int CloseWaitSeconds = 30;
        public static int SelfUpdateWaitSeconds(Kind kind) { return kind==Kind.MT5 ? PendingStart.ProtectedSeconds : 180; }

        /// <summary>Whether MetaTraders asked to close at a time and still open should now be ended: after CloseWaitSeconds,
        /// once (forced already: no).</summary>
        public static bool ForceDue(DateTime asked, DateTime now, bool forcedAlready)
        {
            return !forcedAlready && (now - asked).TotalSeconds >= CloseWaitSeconds;
        }

        /// <summary>When a start file (it holds the password) can go: once the terminal has read it (its window is up, or its
        /// journal names the file) or has closed, and at the latest StartFileSeconds after the start.</summary>
        public static bool StartFileDone(double seconds, bool exited, bool hasWindow, bool journalRead)
        {
            return exited || hasWindow || journalRead || seconds >= StartFileSeconds;
        }

        /// <summary>Bars a chart keeps in light mode (MT5): enough to look at a chart, far below the terminal's own 100000.</summary>
        public const int LightBars = 500;

        /// <summary>The terminal's documented start configuration: login, and lighter charts. profile: the profile MT5 opens
        /// (Empty: no chart; Default: the one the program keeps to one chart); null leaves it to the terminal.</summary>
        public static List<string> StartLines(Kind kind, Account acc, string password, bool light, string profile = null)
        {
            var lines = new List<string>();
            bool login = acc != null && acc.HasLogin;
            bool privateMt5Report=kind==Kind.MT5 && profile==LiveMt5ProfileName;
            if(privateMt5Report)light=true;
            if (kind == Kind.MT5) lines.Add("[Common]");
            if (login)
            {
                lines.Add("Login=" + TextUtil.OneLine(acc.Login));
                if (!string.IsNullOrEmpty(password)) lines.Add("Password=" + password);
                if (!string.IsNullOrWhiteSpace(acc.Server)) lines.Add("Server=" + TextUtil.OneLine(acc.Server));
                lines.Add(kind == Kind.MT5 ? "KeepPrivate=1" : "KeepPrivate=true");  // MT4 writes its switches as true/false
            }
            if (light) lines.Add(kind == Kind.MT5 ? "NewsEnable=0" : "NewsEnable=false");
            if (kind == Kind.MT5 && (light || profile != null))
            {
                lines.Add("[Charts]");
                // The dedicated MT5 report profile uses the terminal's supported UI minimum.
                // Other launch modes retain their original configuration; chart bars never limit account deal history.
                if (light) lines.Add("MaxBars=" + (privateMt5Report?5000:LightBars));
                if (profile != null) lines.Add("ProfileLast=" + profile);
            }
            return lines;
        }

        public static string Arguments(Kind kind, string startFile)
        {
            if (startFile == null) return "/portable";
            return kind == Kind.MT5 ? "/portable /config:\"" + startFile + "\"" : "/portable \"" + startFile + "\"";
        }

        /// <summary>Writes the copy's start file when it has an account or light mode is on; fills StartFile and Warning.
        /// An investor copy or one without an account is first made ready: the expert of earlier versions taken out,
        /// and (with the setting) its charts kept to one. Copies with a trading (master) account are never changed.</summary>
        public static StartResult WriteStartFile(Instance inst, Settings s, AccountStore accounts, bool waitForConfigRead = false, bool plainMode = false)
        {
            var result = new StartResult();
            Account acc = accounts.Get(inst.Name);
            bool login = acc != null && acc.HasLogin;
            string profile = plainMode ? PlainLaunch.ProfileName : waitForConfigRead && inst.Kind==Kind.MT5 ? LiveMt5ProfileName : null;
            if (!plainMode && TerminalUpdate.Allowed(acc) && !waitForConfigRead && !LiveChartPolicy.HasPreservedCharts(inst))
            {
                try { OldMonitor.Remove(inst); }
                catch (Exception e) { Log.Write("old monitor " + inst.Name + ": " + e.Message); }
                try
                {
                    if (s.StartCharts == ChartModes.Empty)
                    {
                        ChartProfile.UseEmpty(inst);
                        profile = ChartProfile.EmptyName;
                    }
                    else
                    {
                        bool wasEmpty = ChartProfile.LeaveEmpty(inst);
                        if (s.StartCharts == ChartModes.One) { ChartProfile.MakeLight(inst); profile = "Default"; }
                        else if (wasEmpty) profile = "Default";
                    }
                }
                catch (Exception e) { Log.Write("light profile " + inst.Name + ": " + e.Message); }
            }
            if (!login && !s.Light && profile == null) return result;
            string password = "";
            if (login)
            {
                password = acc.PasswordForLogin();
                if (password == null)
                {
                    password = "";
                    result.Warning = Lang.T("رمز ذخیره‌شده‌ی ", "The saved password of ") + inst.Name + Lang.T(" روی این کاربر ویندوز خوانده نمی‌شود؛ دوباره واردش کنید.", " cannot be read for this Windows user; enter it again.");
                }
            }
            if (password.IndexOf('\r') >= 0 || password.IndexOf('\n') >= 0)
            {
                // One setting per line: a line break would cut the password and could add a setting of its own.
                password = "";
                result.Warning = Lang.T("رمز ذخیره‌شده‌ی ", "The saved password of ") + inst.Name + Lang.T(" به خط بعد می‌رود و استفاده نشد؛ از «حساب و رمز» دوباره واردش کنید.", " goes on to a new line and was not used; enter it again from “Account and password”.");
            }
            result.WaitForConfigRead = waitForConfigRead;
            result.StartFile = Path.Combine(inst.Dir, result.WaitForConfigRead ? "mtm-live-start-" + Guid.NewGuid().ToString("N") + ".ini" : StartFileName);
            // MT5 reads its own settings files as UTF-16; MT4 is a classic ANSI program.
            Encoding enc = inst.Kind == Kind.MT5 ? Encoding.Unicode : Encoding.Default;
            File.WriteAllLines(result.StartFile, StartLines(inst.Kind, acc, password, s.Light, inst.Kind == Kind.MT5 ? profile : null), enc);
            return result;
        }

        // A self-updater reuses the exact original /config path; never substitute mtm-start.ini.
        public static void RestoreMt5LiveStart(Instance copy,Settings settings,AccountStore accounts,string original,IEnumerable<string> startup)
        {
            if(copy.Kind!=Kind.MT5 || string.IsNullOrEmpty(original) || startup==null)throw new ArgumentException("Invalid MT5 restart context.");
            string full=Path.GetFullPath(original), directory=Path.GetFullPath(copy.Dir).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);
            if(!string.Equals(Path.GetDirectoryName(full),directory,StringComparison.OrdinalIgnoreCase) ||
               !System.Text.RegularExpressions.Regex.IsMatch(Path.GetFileName(full),@"\Amtm-live-start-[0-9a-fA-F]{32}\.ini\z"))
                throw new ArgumentException("Restart configuration must be this copy's generated live startup file.");
            StartResult fresh=WriteStartFile(copy,settings,accounts,true);
            try
            {
                File.AppendAllLines(fresh.StartFile,startup,Encoding.Unicode);
                if(File.Exists(full))File.Replace(fresh.StartFile,full,null);else File.Move(fresh.StartFile,full);
            }
            finally {DeleteStartFile(fresh.StartFile);}
        }

        public static StartResult Start(Instance inst, Settings s, AccountStore accounts)
        {
            return StartImpl(inst, s, accounts, false);
        }

        public static StartResult StartManual(Instance inst, Settings s, AccountStore accounts)
        {
            if (inst.Kind != Kind.MT4) return StartImpl(inst, s, accounts, true);
            using (SandboxLaunch.AcquireManualGate(s))
                return StartImpl(inst, s, accounts, true);
        }

        public static StartResult StartReview(Instance inst,Settings settings,AccountStore accounts)
        {
            if(inst.Kind!=Kind.MT4)return StartImpl(inst,settings,accounts,true,true);
            using(SandboxLaunch.AcquireManualGate(settings))return StartImpl(inst,settings,accounts,true,true);
        }
        internal static void PrepareReviewProfile(Instance inst)
        {
            string profileRoot=inst.Kind==Kind.MT4?Path.Combine(inst.Dir,"profiles"):Path.Combine(inst.Dir,"MQL5","Profiles","Charts");
            Directory.CreateDirectory(Path.Combine(profileRoot,PlainLaunch.ProfileName));
            if(inst.Kind==Kind.MT4)File.WriteAllText(Path.Combine(profileRoot,"lastprofile.ini"),PlainLaunch.ProfileName,Encoding.ASCII);
        }
        internal static List<string> PrepareManualLines(Instance copy,Settings settings,Account account,bool manual)
        {
            if(!manual)return null;
            if(!settings.ManualLiveReports){PlainLaunch.PrepareProfile(copy);return null;}
            return PrepareLiveManual==null?null:PrepareLiveManual(copy,settings,account);
        }

        static StartResult StartImpl(Instance inst, Settings s, AccountStore accounts, bool manual, bool review = false)
        {
            // Do not rewrite the start configuration of an already-running copy in either context.
            var existing = Processes.Running();
            try
            {
                if (Processes.IsRunning(existing, inst.Exe))
                    throw new UserMessage(Lang.T("این نسخه از قبل باز است: ", "This copy is already running: ") + inst.Name);
            }
            finally { foreach (Process p in existing.Values) p.Dispose(); }
            Account acc = accounts.Get(inst.Name);
            Mt5UpdatePolicy.Apply(inst,s);
            if(!s.PauseMt5Updates)ScopedUpdaterConsent.Watch(inst,s.NormalTerminalRights);
            PortableServers.RefreshClosed(inst, s, acc);
            bool login = acc != null && acc.HasLogin;
            if (TerminalUpdate.Allowed(acc)) TerminalUpdate.BeforeStart(inst);
            bool plainMode=review || manual && !s.ManualLiveReports;
            if(review)PrepareReviewProfile(inst);
            var liveLines = review?null:PrepareManualLines(inst,s,acc,manual);
            StartResult result = WriteStartFile(inst, s, accounts, plainMode || manual && liveLines != null && liveLines.Count > 0, plainMode);
            if(plainMode)try{File.AppendAllLines(result.StartFile,PlainLaunch.StartupLines(inst.Kind),inst.Kind==Kind.MT5?Encoding.Unicode:Encoding.Default);}catch{DeleteStartFile(result.StartFile);throw;}
            if(manual && inst.Kind==Kind.MT5 && liveLines!=null && liveLines.Count==0 && result.StartFile!=null)
            {
                try{File.AppendAllLines(result.StartFile,new[]{"[Experts]","AllowLiveTrading=0"},Encoding.Unicode);}
                catch{DeleteStartFile(result.StartFile);throw;}
            }
            if (liveLines != null && liveLines.Count > 0)
            {
                result.StartupLines=new List<string>(liveLines);
                try { File.AppendAllLines(result.StartFile, liveLines, inst.Kind == Kind.MT5 ? Encoding.Unicode : Encoding.Default); }
                catch { DeleteStartFile(result.StartFile);throw; }
            }
            var psi = new ProcessStartInfo(inst.Exe, Arguments(inst.Kind, result.StartFile))
            {
                WorkingDirectory = inst.Dir,
                UseShellExecute = true,
                WindowStyle = s.Minimized ? ProcessWindowStyle.Minimized : ProcessWindowStyle.Normal,
            };
            try
            {
                if(manual)LaunchComparison.Prepared(inst,liveLines!=null && liveLines.Count>0);
                result.Process = manual ? SandboxLaunch.Start(inst, s, TerminalProcessPolicy.Prepare(psi, s)) : Process.Start(TerminalProcessPolicy.Prepare(psi, s));
            }
            catch
            {
                if (result.StartFile != null) DeleteStartFile(result.StartFile);
                throw;
            }
            if(manual)LaunchComparison.Started(inst,result.Process);
            LaunchCapacityDiagnostics.Watch(result.Process, inst.Name);
            // Recorded as opened here: only such MetaTraders are ever closed from the program.
            if (result.Process != null) Owned.Add(result.Process, inst.Exe);
            if (manual && result.Process != null)
            {
                try { result.Sandboxed = SandboxLaunch.IsSandboxedPid(result.Process.Id); }
                catch (Exception e)
                {
                    // Identification after a verified launch must not discard ownership or its cleanup deadline.
                    result.Sandboxed = inst.Kind == Kind.MT4 && s.SandboxieOverflow;
                    Log.Write("sandbox classification unavailable after launch: " + e.GetType().Name);
                }
            }
            if (s.LowPriority && result.Process != null)
            {
                // Below normal: the MetaTrader in front and this program stay quick; the others still get every free moment.
                try { result.Process.PriorityClass = ProcessPriorityClass.BelowNormal; }
                catch (Exception e) { Log.Write("priority " + inst.Name + ": " + e.Message); }
            }
            Log.Write("started " + inst.Name + (login ? " (account " + acc.Login + ", " + acc.Mode + ")" : ""));
            return result;
        }

        /// <summary>Start files waiting to be deleted, checked every second (the window) or every half second (start with Windows).
        /// Returns the ones still waiting.</summary>
        public static List<PendingStart> CleanStartFiles(List<PendingStart> pending, DateTime now, bool all)
        {
            var left = new List<PendingStart>();
            foreach (PendingStart p in pending)
            {
                string why = all ? "closing" : p.Ready(now);
                if (why == null) { left.Add(p); continue; }
                DeleteStartFile(p.Path);
                Log.Write("start file of " + (p.Copy != null ? p.Copy.Name : "?") + " deleted after " + (now - p.Time).TotalSeconds.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture) + " s (" + why + ")");
            }
            return left;
        }

        public static void DeleteStartFile(string path)
        {
            try { if (path != null && File.Exists(path)) File.Delete(path); } catch { }
        }

        /// <summary>Start files left behind when the program was closed early.</summary>
        public static void DeleteLeftovers(IEnumerable<Instance> copies)
        {
            foreach (Instance i in copies)
            {
                DeleteStartFile(Path.Combine(i.Dir, StartFileName));
                // Only our generated files, after the maximum startup lifetime; never terminal configuration.
                try { foreach (string file in Directory.GetFiles(i.Dir, "mtm-live-start-*.ini"))
                    if (DateTime.UtcNow - File.GetLastWriteTimeUtc(file) > TimeSpan.FromSeconds(PendingStart.ProtectedSeconds)) DeleteStartFile(file); }
                catch { }
            }
        }

        public sealed class CloseReport
        {
            /// <summary>Asked to close through their window: they save charts and settings first.</summary>
            public int Asked;
            /// <summary>Ended at once: they had no window to ask (nothing on screen to save), or ending was asked for.</summary>
            public readonly List<string> Ended = new List<string>();
            /// <summary>Windows did not let this program end them: started with administrator rights (the "Yes" of Windows' question).</summary>
            public readonly List<string> Denied = new List<string>();
            /// <summary>Running, but not opened by this program (by hand, or by another program): left alone.</summary>
            public readonly List<string> NotOurs = new List<string>();
        }

        /// <summary>Closes copies, only those this program opened (see Owned): each with a window is asked to close;
        /// one without a window cannot be asked, so it is ended. With force every one is ended.
        /// A copy open in any other way is never touched, and neither is any other program.</summary>
        public static CloseReport Close(IEnumerable<Instance> list, bool force)
        {
            var report = new CloseReport();
            var running = Processes.Running();
            try
            {
            HashSet<string> mine = Owned.Mine(running);
            foreach (Instance i in list)
            {
                Process p;
                string key = i.Exe.ToLowerInvariant();
                if (!running.TryGetValue(key, out p)) continue;
                if (!mine.Contains(key))
                {
                    report.NotOurs.Add(i.Name);
                    Log.Write("left open " + i.Name + ": not opened by this program");
                    continue;
                }
                try
                {
                    TerminalCloseAudit.Record(p,i.Exe,force?"manual-force":"manual-close");
                    if (!force && p.MainWindowHandle != IntPtr.Zero && p.CloseMainWindow()) { report.Asked++; continue; }
                    p.Kill();
                    report.Ended.Add(i.Name);
                    Log.Write("ended " + i.Name + (force ? "" : " (no window to ask)"));
                }
                catch (System.ComponentModel.Win32Exception e)
                {
                    report.Denied.Add(i.Name);
                    Log.Write("stop " + i.Name + " refused: " + e.Message);
                }
                catch (Exception e) { Log.Write("stop " + i.Name + ": " + e.Message); }
            }
            return report;
            }
            finally{foreach(var process in running.Values)process.Dispose();}
        }
    }

    // ------------------------------------------------------------------ windows desktop heap

    /// <summary>Windows gives all windows of a desktop one memory pool (the "desktop heap"). When it is full,
    /// its exhaustion is one possible cause of window initialization failure, not proof of a terminal-count limit.</summary>
    public static class Heap
    {
        const string SubKey = @"SYSTEM\CurrentControlSet\Control\Session Manager\SubSystems";
        public const int Default = 20480;
        public const int Recommended = 20480;
        static readonly Regex Pattern = new Regex(@"SharedSection=([0-9]+),([0-9]+)(,([0-9]+))?");

        public static int? Interactive(string raw)
        {
            Match m = Pattern.Match(raw ?? "");
            return m.Success ? int.Parse(m.Groups[2].Value) : (int?)null;
        }

        public static string WithInteractive(string raw, int kb)
        {
            // Microsoft KB947246 advises against an interactive SharedSection value above 20480 KB.
            if (kb <= 0 || kb > Recommended) throw new UserMessage(Lang.T("مقدار حافظهٔ پنجره‌ها باید حداکثر 20480 KB باشد؛ چیزی تغییر نکرد.", "Interactive desktop heap must not exceed 20480 KB; nothing changed."));
            Match m = Pattern.Match(raw ?? "");
            if (!m.Success) throw new UserMessage(Lang.T("مقدار SharedSection در رجیستری پیدا نشد؛ چیزی تغییر نکرد.", "SharedSection was not found in the registry; nothing changed."));
            string section = "SharedSection=" + m.Groups[1].Value + "," + kb + (m.Groups[4].Success ? "," + m.Groups[4].Value : "");
            return raw.Substring(0, m.Index) + section + raw.Substring(m.Index + m.Length);
        }

        static string ReadRaw()
        {
            using (RegistryKey k = Registry.LocalMachine.OpenSubKey(SubKey, false))
            {
                // Unexpanded: the value holds %SystemRoot% and must be written back the same way.
                return k == null ? null : k.GetValue("Windows", null, RegistryValueOptions.DoNotExpandEnvironmentNames) as string;
            }
        }

        public static int? Current()
        {
            try { return Interactive(ReadRaw()); } catch { return null; }
        }

        /// <summary>Needs administrator rights. Keeps a backup of the old value in the program's data folder.</summary>
        public static void Set(int kb)
        {
            string raw = ReadRaw();
            string next = WithInteractive(raw, kb);
            File.WriteAllText(Path.Combine(AppPaths.DataDir, "heap-backup-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".txt"), raw, Encoding.UTF8);
            using (RegistryKey k = Registry.LocalMachine.OpenSubKey(SubKey, true))
            {
                RegistryValueKind kind = k.GetValueKind("Windows");
                k.SetValue("Windows", next, kind);
            }
            Log.Write("desktop heap set to " + kb + " KB");
        }
    }

    // ------------------------------------------------------------------ accounts from Excel (CSV)

    public sealed class ImportResult
    {
        public int Added;
        public List<string> Problems = new List<string>();
        /// <summary>Folders the file named that did not exist yet, made on the way.</summary>
        public List<string> NewFolders = new List<string>();
        /// <summary>How many times a copy was put into a folder.</summary>
        public int InFolders;
    }

    public static class Csv
    {
        public static readonly string[] Header = { "Copy", "Trader", "Login", "Server", "Password", "Investor", "Mode", "Folder" };

        /// <summary>Several folders in one cell are separated by these (a comma may be the file's own separator).</summary>
        public static readonly char[] FolderSeparators = { ';', '؛', '|' };

        static readonly Dictionary<string, string> Aliases = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "copy", "Copy" }, { "نسخه", "Copy" },
            { "trader", "Trader" }, { "name", "Trader" }, { "معامله‌گر", "Trader" }, { "معامله گر", "Trader" }, { "نام", "Trader" },
            { "login", "Login" }, { "account", "Login" }, { "شماره حساب", "Login" }, { "حساب", "Login" },
            { "server", "Server" }, { "سرور", "Server" },
            { "password", "Password" }, { "master", "Password" }, { "رمز اصلی", "Password" }, { "رمز", "Password" },
            { "investor", "Investor" }, { "رمز اینوستور", "Investor" }, { "اینوستور", "Investor" },
            { "mode", "Mode" }, { "ورود با", "Mode" },
            { "folder", "Folder" }, { "folders", "Folder" }, { "پوشه", "Folder" }, { "پوشه‌ها", "Folder" }, { "پوشه ها", "Folder" }, { "گروه", "Folder" },
        };

        public static char Delimiter(string firstLine)
        {
            int commas = firstLine.Count(c => c == ',');
            int semis = firstLine.Count(c => c == ';');
            int tabs = firstLine.Count(c => c == '\t');
            if (tabs > commas && tabs > semis) return '\t';
            return semis > commas ? ';' : ',';
        }

        /// <summary>CSV with quoted fields ("a,b" and "" inside quotes).</summary>
        public static List<string[]> Parse(string text, char delim)
        {
            var rows = new List<string[]>();
            var row = new List<string>();
            var field = new StringBuilder();
            bool quoted = false;
            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];
                if (quoted)
                {
                    if (c == '"')
                    {
                        if (i + 1 < text.Length && text[i + 1] == '"') { field.Append('"'); i++; }
                        else quoted = false;
                    }
                    else field.Append(c);
                }
                else if (c == '"') quoted = true;
                else if (c == delim) { row.Add(field.ToString()); field.Clear(); }
                else if (c == '\r') { }
                else if (c == '\n') { row.Add(field.ToString()); field.Clear(); rows.Add(row.ToArray()); row.Clear(); }
                else field.Append(c);
            }
            if (field.Length > 0 || row.Count > 0) { row.Add(field.ToString()); rows.Add(row.ToArray()); }
            return rows;
        }

        static string Cell(string s)
        {
            s = s ?? "";
            return s.IndexOfAny(new[] { ',', '"', '\n', '\r' }) >= 0 ? "\"" + s.Replace("\"", "\"\"") + "\"" : s;
        }

        /// <summary>One row per copy; its folders, when it is in any, already filled in (separated by "؛").</summary>
        public static string Template(IEnumerable<Instance> copies, FolderStore folders = null)
        {
            var sb = new StringBuilder();
            sb.AppendLine(string.Join(",", Header));
            bool any = false;
            foreach (Instance i in copies)
            {
                string inFolders = folders != null ? string.Join("؛", folders.Of(i.Name).Select(f => f.Name)) : "";
                sb.AppendLine(i.Name + ",,,,,,," + Cell(inFolders));
                any = true;
            }
            if (!any) sb.AppendLine(",,,,,,,");
            return sb.ToString();
        }

        /// <summary>Reads accounts into the store. A row without a copy name goes to the next copy that has no account.</summary>
        /// <summary>With folders, the optional Folder column puts each copy into the folders it names (made when missing);
        /// the copy's other folders stay.</summary>
        public static ImportResult Import(string text, List<Instance> copies, AccountStore store, FolderStore folders = null)
        {
            var result = new ImportResult();
            text = (text ?? "").TrimStart('\uFEFF');
            int firstEnd = text.IndexOf('\n');
            char delim = Delimiter(firstEnd >= 0 ? text.Substring(0, firstEnd) : text);
            List<string[]> rows = Parse(text, delim);
            if (rows.Count == 0) { result.Problems.Add(Lang.T("فایل خالی است.", "The file is empty.")); return result; }

            var columns = new Dictionary<string, int>();
            for (int c = 0; c < rows[0].Length; c++)
            {
                string key;
                if (Aliases.TryGetValue(rows[0][c].Trim(), out key) && !columns.ContainsKey(key)) columns[key] = c;
            }
            if (!columns.ContainsKey("Login"))
            {
                result.Problems.Add(Lang.T("ستون Login (شماره حساب) در سطر اول پیدا نشد. از «فایل نمونه‌ی Excel» استفاده کنید.", "The Login (account number) column was not found in the first row. Use the “sample Excel file”."));
                return result;
            }
            Func<string[], string, string> get = (row, key) =>
            {
                int c;
                return columns.TryGetValue(key, out c) && c < row.Length ? row[c] : "";
            };

            var free = copies.Where(i => { Account a = store.Get(i.Name); return a == null || !a.HasLogin; }).ToList();
            var taken = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            int freeIndex = 0;
            for (int r = 1; r < rows.Count; r++)
            {
                string[] row = rows[r];
                int line = r + 1;
                string login = TextUtil.LatinDigits(get(row, "Login").Trim());
                if (login.Length == 0) continue;
                if (!Regex.IsMatch(login, @"^[0-9]{1,20}$")) { result.Problems.Add(Lang.T("سطر ", "Row ") + line + Lang.T(": شماره حساب باید فقط عدد باشد.", ": the account number must be digits only.")); continue; }
                string server = get(row, "Server").Trim();
                if (server.Length == 0) { result.Problems.Add(Lang.T("سطر ", "Row ") + line + Lang.T(": سرور خالی است.", ": the server is empty.")); continue; }
                string master = get(row, "Password");
                string investor = get(row, "Investor");
                string modeRaw = get(row, "Mode").Trim().ToLowerInvariant();
                string mode;
                if (modeRaw == "master" || modeRaw == "اصلی") mode = "master";
                else if (modeRaw == "investor" || modeRaw == "اینوستور") mode = "investor";
                else mode = master.Length > 0 ? "master" : "investor";
                if ((mode == "master" ? master : investor).Length == 0)
                {
                    result.Problems.Add(Lang.T("سطر ", "Row ") + line + Lang.T(": رمز لازم برای ورود خالی است.", ": the password needed to sign in is empty."));
                    continue;
                }
                string bad = PasswordRule.Check(new KeyValuePair<string, string>(Lang.T("رمز اصلی", "Master password"), master), new KeyValuePair<string, string>(Lang.T("رمز اینوستور", "Investor password"), investor));
                if (bad != null) { result.Problems.Add(Lang.T("سطر ", "Row ") + line + Lang.T("، ", ", ") + bad); continue; }

                string copyName = get(row, "Copy").Trim();
                Instance inst;
                if (copyName.Length > 0)
                {
                    inst = copies.FirstOrDefault(i => string.Equals(i.Name, copyName, StringComparison.OrdinalIgnoreCase));
                    if (inst == null) { result.Problems.Add(Lang.T("سطر ", "Row ") + line + Lang.T(": نسخه‌ای به نام ", ": there is no copy named ") + copyName + Lang.T(" وجود ندارد.", ".")); continue; }
                }
                else
                {
                    while (freeIndex < free.Count && taken.Contains(free[freeIndex].Name)) freeIndex++;
                    if (freeIndex >= free.Count) { result.Problems.Add(Lang.T("سطر ", "Row ") + line + Lang.T(": نسخه‌ی بدون حساب باقی نمانده. اول نسخه‌ی بیشتری بسازید.", ": no copy without an account is left. Make more copies first.")); continue; }
                    inst = free[freeIndex++];
                }
                taken.Add(inst.Name);
                store.Set(new Account
                {
                    Instance = inst.Name, Trader = TextUtil.OneLine(get(row, "Trader")), Login = login, Server = TextUtil.OneLine(server),
                    Mode = mode, MasterEnc = Secret.Protect(master), InvestorEnc = Secret.Protect(investor),
                });
                result.Added++;
                if (folders == null) continue;
                foreach (string raw in get(row, "Folder").Split(FolderSeparators))
                {
                    string name = TextUtil.OneLine(raw);
                    if (name.Length == 0) continue;
                    Folder f = folders.Find(name);
                    if (f == null)
                    {
                        string problem = folders.NameProblem(name);
                        if (problem != null) { result.Problems.Add(Lang.T("سطر ", "Row ") + line + Lang.T("، پوشه‌ی «", ", folder “") + name + "»: " + problem); continue; }
                        f = folders.Create(name);
                        result.NewFolders.Add(f.Name);
                    }
                    if (!folders.Has(f.Id, inst.Name)) { folders.Add(f.Id, new[] { inst.Name }); result.InFolders++; }
                }
            }
            return result;
        }
    }

    // ------------------------------------------------------------------ problems the program can see

    public enum Fix { None, Create, Heap, Settings, Report, Cleanup }

    public sealed class Issue
    {
        public string Text;
        public Fix Fix;
        public string FixText;
    }

    /// <summary>When the next copy in the start queue may open: as soon as the one before has its window and has settled
    /// (little processor use), and never later than the set delay; never sooner than a moment after it.</summary>
    public static class StartPace
    {
        /// <summary>Processor use (share of one core) under which a terminal counts as settled.</summary>
        public const double Settled = 0.25;

        public static double MinSeconds(int delay) { return Math.Min(2, Math.Max(0, delay)); }

        public static bool Ready(double elapsed, int delay, bool exited, bool hasWindow, double cpuShare)
        {
            if (elapsed < MinSeconds(delay)) return false;
            if (exited || elapsed >= Math.Max(0, delay)) return true;
            return hasWindow && cpuShare < Settled;
        }
    }

    // ------------------------------------------------------------------ 3.19: ending a MetaTrader this program opened

    /// <summary>How the program ends a report MetaTrader it opened: every window of that one process is asked to close (WM_CLOSE, as a
    /// click on its ×: the terminal saves and logs out), it has GraceSeconds, and only then is it ended. Only a process the caller
    /// tracks (started by this program) is touched; none is ever looked up by its name.</summary>
    public static class SafeClose
    {
        public const int GraceSeconds = 15;

        /// <summary>One running process, as SafeClose needs it (a test can stand in for a MetaTrader).</summary>
        public interface ITarget
        {
            int Id { get; }
            bool Exited { get; }
            /// <summary>Asks each of its windows to close; how many were asked (0: none, or Windows could not be asked).</summary>
            int AskToClose();
            bool WaitExit(int milliseconds);
            void Kill();
        }

        public enum Result { Gone, NotOurs, Closed, Ended, Failed }

        /// <summary>ours: whether the program tracks this process id as one it started. Without a window to ask, it is ended at once.</summary>
        public static Result Close(ITarget p, Func<int, bool> ours, int graceSeconds, Action<string> log)
        {
            if (p == null || p.Exited) return Result.Gone;
            int id = p.Id;
            if (ours == null || !ours(id))
            {
                if (log != null) log("left open: process " + id + " was not opened by this program");
                return Result.NotOurs;
            }
            int asked = 0;
            try { asked = p.AskToClose(); }
            catch (Exception e) { if (log != null) log("close " + id + ": " + e.Message); }
            if (asked > 0 && p.WaitExit(Math.Max(0, graceSeconds) * 1000)) return Result.Closed;
            if (p.Exited) return Result.Closed;
            try
            {
                p.Kill();
                p.WaitExit(5000);
                return Result.Ended;
            }
            catch (Exception e)
            {
                if (log != null) log("end " + id + ": " + e.Message);
                return p.Exited ? Result.Ended : Result.Failed;
            }
        }
    }

    /// <summary>A real process for SafeClose.</summary>
    public sealed class ProcessTarget : SafeClose.ITarget
    {
        readonly Process p;
        readonly bool hidden;
        public ProcessTarget(Process p) : this(p, false) { }
        public ProcessTarget(Process p, bool hidden) { this.p = p; this.hidden = hidden; }
        public int Id { get { return p.Id; } }
        public bool Exited { get { try { p.Refresh(); return p.HasExited; } catch { return true; } } }
        public int AskToClose()
        {
            IntPtr main = IntPtr.Zero;
            try { main = p.MainWindowHandle; } catch { }
            TerminalCloseAudit.Record(p,Processes.PathOf(p),"report-helper-close");
            return Native.CloseWindowsOf(p.Id, main, hidden);
        }
        public bool WaitExit(int milliseconds) { try { return p.HasExited || (milliseconds > 0 && p.WaitForExit(milliseconds)); } catch { return true; } }
        public void Kill() { TerminalCloseAudit.Record(p,Processes.PathOf(p),"report-helper-force");p.Kill(); }
    }

    /// <summary>3.19: report MetaTraders start at least GapMs apart, two at once included (each start reads a lot from the disk).</summary>
    public sealed class StartPacer
    {
        public const int GapMs = 1500;
        readonly object gate = new object();
        readonly Func<DateTime> clock;
        readonly Action<int> sleep;
        DateTime last = DateTime.MinValue;

        public StartPacer(Func<DateTime> clock = null, Action<int> sleep = null)
        {
            this.clock = clock ?? (() => DateTime.UtcNow);
            this.sleep = sleep ?? (ms => System.Threading.Thread.Sleep(ms));
        }

        /// <summary>Waits until GapMs have passed since the start before; the milliseconds waited.</summary>
        public int Turn()
        {
            lock (gate)
            {
                DateTime now = clock();
                int wait = last == DateTime.MinValue ? 0 : (int)Math.Ceiling(Math.Max(0, GapMs - (now - last).TotalMilliseconds));
                if (wait > 0) sleep(wait);
                last = clock();
                return wait;
            }
        }
    }

    public static class Native
    {
        [DllImport("user32.dll")]
        static extern IntPtr SendMessage(IntPtr window, int message, IntPtr w, IntPtr l);

        [DllImport("user32.dll")]
        static extern bool RedrawWindow(IntPtr window, IntPtr rect, IntPtr region, uint flags);

        sealed class Frozen : IDisposable
        {
            readonly System.Windows.Forms.Control control;
            readonly bool on;

            public Frozen(System.Windows.Forms.Control c)
            {
                control = c;
                if (c == null || !c.IsHandleCreated || Environment.OSVersion.Platform != PlatformID.Win32NT) return;
                try { SendMessage(c.Handle, 0x000B, IntPtr.Zero, IntPtr.Zero); on = true; } catch { }
            }

            public void Dispose()
            {
                if (control == null) return;
                if (on)
                    try
                    {
                        SendMessage(control.Handle, 0x000B, (IntPtr)1, IntPtr.Zero);
                        // Invalidate, erase, frame, all children, now.
                        RedrawWindow(control.Handle, IntPtr.Zero, IntPtr.Zero, 0x0001 | 0x0004 | 0x0400 | 0x0080 | 0x0100);
                        return;
                    }
                    catch { }
                control.Invalidate(true);
            }
        }

        /// <summary>3.25: nothing in a window is drawn while it changes; when it is done, it is drawn once, whole (WM_SETREDRAW).
        /// Elsewhere than Windows it only draws again at the end.</summary>
        public static IDisposable Freeze(System.Windows.Forms.Control c) { return new Frozen(c); }

        [DllImport("psapi.dll", SetLastError = true)]
        static extern bool EmptyWorkingSet(IntPtr process);

        delegate bool EnumWindowsProc(IntPtr window, IntPtr data);

        [DllImport("user32.dll")]
        static extern bool EnumWindows(EnumWindowsProc callback, IntPtr data);

        [DllImport("user32.dll")]
        static extern uint GetWindowThreadProcessId(IntPtr window, out uint pid);

        [DllImport("user32.dll")]
        static extern bool IsWindowVisible(IntPtr window);

        [DllImport("user32.dll", SetLastError = true)]
        static extern bool PostMessage(IntPtr window, uint message, IntPtr w, IntPtr l);

        const uint WmClose = 0x0010;

        /// <summary>3.19: asks every visible top-level window of one process to close (WM_CLOSE), and its main window even when hidden;
        /// the main window last, so a dialog in front of it goes first. How many were asked; 0 when there were none or Windows could not
        /// be asked. Windows of any other process are never touched.</summary>
        [DllImport("user32.dll")] static extern bool ShowWindowAsync(IntPtr window, int command);
        public static void HideWindowsOf(int pid)
        {
            try
            {
                EnumWindowsProc each = (w, data) => { uint owner; GetWindowThreadProcessId(w, out owner); if (owner == (uint)pid && IsWindowVisible(w)) ShowWindowAsync(w, 0); return true; };
                EnumWindows(each, IntPtr.Zero); GC.KeepAlive(each);
            }
            catch { }
        }

        public static int CloseWindowsOf(int pid, IntPtr main) { return CloseWindowsOf(pid, main, false); }
        public static int CloseWindowsOf(int pid, IntPtr main, bool hidden)
        {
            var windows = new List<IntPtr>();
            try
            {
                EnumWindowsProc each = (w, d) =>
                {
                    uint owner;
                    GetWindowThreadProcessId(w, out owner);
                    if (owner == (uint)pid && w != main && (hidden || IsWindowVisible(w))) windows.Add(w);
                    return true;
                };
                EnumWindows(each, IntPtr.Zero);
                GC.KeepAlive(each);
                if (main != IntPtr.Zero)
                {
                    uint owner;
                    GetWindowThreadProcessId(main, out owner);
                    if (owner == (uint)pid) windows.Add(main);
                }
            }
            catch { return 0; }
            int asked = 0;
            foreach (IntPtr w in windows)
            {
                try { if (PostMessage(w, WmClose, IntPtr.Zero, IntPtr.Zero)) asked++; }
                catch { }
            }
            return asked;
        }

        /// <summary>3.19: the most memory a process has held in RAM (its peak working set), in MB; 0 when it cannot be read.</summary>
        public static long PeakMb(Process p)
        {
            try { p.Refresh(); return p.PeakWorkingSet64 / (1024 * 1024); }
            catch { return 0; }
        }

        [DllImport("user32.dll")]
        static extern uint GetGuiResources(IntPtr process, uint flags);

        /// <summary>How many window objects (windows, menus, hooks…) a process holds; these live in the limited window memory. -1 when unknown.</summary>
        public static int WindowObjects(Process p)
        {
            try { return (int)GetGuiResources(p.Handle, 1); }
            catch { return -1; }
        }

        [DllImport("user32.dll")]
        static extern bool IsIconic(IntPtr window);

        /// <summary>After heavy work (a report, closing or making many copies): the program's own unused memory is collected and
        /// handed back to Windows. Only this program's memory; the MetaTraders have their own (see TrimIfMinimized).</summary>
        public static void TrimSelf(string why)
        {
            try
            {
                long before = GC.GetTotalMemory(false);
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                using (Process me = Process.GetCurrentProcess()) EmptyWorkingSet(me.Handle);
                Log.Write("memory handed back after " + why + ": " + ((before - GC.GetTotalMemory(false)) / (1024 * 1024)) + " MB collected");
            }
            catch { }
        }

        /// <summary>Hands the memory of a minimized terminal back to Windows (it comes back by itself when used). False when not minimized.</summary>
        public static bool TrimIfMinimized(Process p)
        {
            try
            {
                IntPtr w = p.MainWindowHandle;
                if (w == IntPtr.Zero || !IsIconic(w)) return false;
                return EmptyWorkingSet(p.Handle);
            }
            catch { return false; }
        }

        [StructLayout(LayoutKind.Sequential)]
        struct MemoryStatus
        {
            public uint Length, Load;
            public ulong TotalPhys, AvailPhys, TotalPageFile, AvailPageFile, TotalVirtual, AvailVirtual, AvailExtendedVirtual;
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool GlobalMemoryStatusEx(ref MemoryStatus status);

        /// <summary>Total and free RAM in MB; zeros when Windows cannot tell.</summary>
        public static void Ram(out ulong totalMb, out ulong freeMb)
        {
            totalMb = 0;
            freeMb = 0;
            try
            {
                var m = new MemoryStatus { Length = (uint)Marshal.SizeOf(typeof(MemoryStatus)) };
                if (GlobalMemoryStatusEx(ref m))
                {
                    totalMb = m.TotalPhys / (1024 * 1024);
                    freeMb = m.AvailPhys / (1024 * 1024);
                }
            }
            catch { }
        }

        // SHFILEOPSTRUCT is packed to 1 byte in 32-bit Windows and to 8 in 64-bit.
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct FileOp64
        {
            public IntPtr Hwnd; public uint Func; public string From; public string To; public ushort Flags;
            public bool Aborted; public IntPtr NameMappings; public string Title;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
        struct FileOp32
        {
            public IntPtr Hwnd; public uint Func; public string From; public string To; public ushort Flags;
            public bool Aborted; public IntPtr NameMappings; public string Title;
        }

        [DllImport("shell32.dll", CharSet = CharSet.Unicode, EntryPoint = "SHFileOperationW")]
        static extern int FileOperation64(ref FileOp64 op);

        [DllImport("shell32.dll", CharSet = CharSet.Unicode, EntryPoint = "SHFileOperationW")]
        static extern int FileOperation32(ref FileOp32 op);

        /// <summary>Moves files and folders to the Recycle Bin in one go. Windows itself warns before anything would be
        /// deleted for good (for example an item too big for the Recycle Bin). Returns the paths that are gone.</summary>
        public static List<string> ToRecycleBin(IList<string> paths, IntPtr owner)
        {
            const uint Delete = 3;
            const ushort AllowUndo = 0x40, NoConfirmation = 0x10, NoErrorUi = 0x400, WantNukeWarning = 0x4000;
            var gone = new List<string>();
            if (paths.Count == 0) return gone;
            string from = string.Join("\0", paths.Select(p => Path.GetFullPath(p).TrimEnd('\\'))) + "\0\0";
            ushort flags = AllowUndo | NoConfirmation | NoErrorUi | WantNukeWarning;
            if (IntPtr.Size == 8)
            {
                var op = new FileOp64 { Hwnd = owner, Func = Delete, From = from, Flags = flags };
                FileOperation64(ref op);
            }
            else
            {
                var op = new FileOp32 { Hwnd = owner, Func = Delete, From = from, Flags = flags };
                FileOperation32(ref op);
            }
            foreach (string p in paths) if (!File.Exists(p) && !Directory.Exists(p)) gone.Add(p);
            return gone;
        }

        /// <summary>Moves a folder to the Recycle Bin, so it can be restored. True when it is gone.</summary>
        public static bool ToRecycleBin(string dir)
        {
            const uint Delete = 3;
            const ushort AllowUndo = 0x40, NoConfirmation = 0x10, Silent = 0x4, NoErrorUi = 0x400;
            string from = Path.GetFullPath(dir).TrimEnd('\\') + "\0\0";
            ushort flags = AllowUndo | NoConfirmation | Silent | NoErrorUi;
            int result;
            if (IntPtr.Size == 8)
            {
                var op = new FileOp64 { Func = Delete, From = from, Flags = flags };
                result = FileOperation64(ref op);
            }
            else
            {
                var op = new FileOp32 { Func = Delete, From = from, Flags = flags };
                result = FileOperation32(ref op);
            }
            return result == 0 && !Directory.Exists(dir);
        }
    }

    public static class Checks
    {
        public static ulong TotalRamMb()
        {
            ulong total, free;
            Native.Ram(out total, out free);
            return total;
        }

        public static ulong FreeRamMb()
        {
            ulong total, free;
            Native.Ram(out total, out free);
            return free;
        }

        /// <summary>Rough RAM per terminal with light settings, in MB.</summary>
        public const int LightMt4Mb = 150, LightMt5Mb = 250;

        public static bool CanWrite(string dir)
        {
            try
            {
                Directory.CreateDirectory(dir);
                string probe = Path.Combine(dir, "mtm-probe-" + Guid.NewGuid().ToString("N") + ".tmp");
                File.WriteAllText(probe, "x");
                File.Delete(probe);
                return true;
            }
            catch { return false; }
        }

        /// <summary>What the start screen warns about, each with the button that fixes it.</summary>
        public static List<Issue> Quick(Settings s, List<Instance> copies, AccountStore accounts, int? heap, bool installsFound)
        {
            var list = new List<Issue>();
            if (copies.Count == 0 && !installsFound)
                list.Add(new Issue { Text = Lang.T("روی این ویندوز متاتریدر نصب‌شده‌ای پیدا نشد. اول یک بار MT4 یا MT5 را از سایت بروکر خود نصب کنید.", "No installed MetaTrader was found on this Windows. First install MT4 or MT5 once from your broker's website."), Fix = Fix.Create, FixText = Lang.T("راهنمای نصب", "Installation guide") });
            if (!CanWrite(s.BaseDir))
                list.Add(new Issue { Text = Lang.T("در پوشه‌ی نسخه‌ها (", "Cannot write in the copies' folder (") + s.BaseDir + Lang.T(") نمی‌شود نوشت.", ")."), Fix = Fix.Settings, FixText = Lang.T("تغییر پوشه", "Change folder") });
            ulong ram = TotalRamMb();
            if (ram > 0)
            {
                ulong need = (ulong)(copies.Count(c => c.Kind == Kind.MT4) * LightMt4Mb + copies.Count(c => c.Kind == Kind.MT5) * LightMt5Mb) + 2048;
                if (need > ram)
                    list.Add(new Issue { Text = Lang.T("حافظه‌ی این کامپیوتر (", "This computer's memory (") + (ram / 1024.0).ToString("0.#") + Lang.T(" گیگابایت) برای اجرای هم‌زمان همه‌ی نسخه‌ها کم است. بازکردن متوقف نمی‌شود؛ ممکن است ویندوز کند شود.", " GB) is small for running all copies together. Opening is not blocked; Windows may slow down."), Fix = Fix.Report, FixText = Lang.T("جزئیات", "Details") });
            }
            // 3.21: no warning about unneeded files any more: the program deletes them from closed copies by itself (AutoCleanup).
            int unreadable = accounts.All.Count(a => a.HasLogin && !a.Readable);
            if (unreadable > 0)
                list.Add(new Issue { Text = Lang.T("رمز ", "The password of ") + unreadable + Lang.T(" حساب روی این کاربر ویندوز خوانده نمی‌شود (احتمالاً روی کامپیوتر دیگری ذخیره شده). دوباره واردشان کنید.", " accounts cannot be read for this Windows user (probably saved on another computer). Enter them again."), Fix = Fix.None });
            return list;
        }

        public static string Report(Settings s, List<Instance> copies, AccountStore accounts,IEnumerable<Instance> reviewCopies=null)
        {
            var sb = new StringBuilder();
            sb.AppendLine(Ui.Title + " " + AppInfo.Version);
            sb.AppendLine(Lang.T("ویندوز: ", "Windows: ") + Environment.OSVersion + (Environment.Is64BitOperatingSystem ? Lang.T(" (۶۴ بیتی)", " (64-bit)") : Lang.T(" (۳۲ بیتی)", " (32-bit)")));
            sb.AppendLine(".NET: " + Environment.Version);
            sb.AppendLine(Lang.T("پردازنده: ", "Processor: ") + Environment.ProcessorCount + Lang.T(" هسته‌ی منطقی", " logical cores"));
            ulong ram = TotalRamMb(), free = FreeRamMb();
            sb.AppendLine(Lang.T("حافظه: ", "Memory: ") + (ram / 1024.0).ToString("0.0") + Lang.T(" گیگابایت، آزاد ", " GB, free ") + (free / 1024.0).ToString("0.0"));
            if (ram > 2048)
            {
                ulong usable = ram - 2048;
                sb.AppendLine(Lang.T("ظرفیت تقریبی با حالت سبک: حدود ", "Rough capacity in light mode: about ") + (usable / LightMt4Mb) + Lang.T(" نسخه‌ی MT4 یا ", " MT4 copies or ") + (usable / LightMt5Mb) + Lang.T(" نسخه‌ی MT5", " MT5 copies"));
            }
            sb.AppendLine(Lang.T("پوشه‌ی نسخه‌ها: ", "Copies folder: ") + s.BaseDir + (CanWrite(s.BaseDir) ? Lang.T(" (نوشتن ممکن است)", " (writable)") : Lang.T(" (نوشتن ممکن نیست)", " (not writable)")));
            if (s.AllFolders.Count > 1) sb.AppendLine(Lang.T("پوشه‌های دیگرِ نسخه‌ها: ", "Other copies folders: ") + string.Join(Lang.T("، ", ", "), s.AllFolders.Skip(1)));
            try
            {
                var drive = new DriveInfo(Path.GetPathRoot(Path.GetFullPath(s.BaseDir)));
                sb.AppendLine(Lang.T("فضای آزاد دیسک: ", "Free disk space: ") + TextUtil.Size(drive.AvailableFreeSpace));
            }
            catch { }
            foreach (Kind k in new[] { Kind.MT4, Kind.MT5 })
            {
                List<string> found = Installs.Find(k, s);
                if (found.Count == 0) sb.AppendLine(k + Lang.T(" نصب‌شده: پیدا نشد", " installed: not found"));
                foreach (string f in found)
                {
                    Version v = TerminalUpdate.FileVersion(Path.Combine(f, Kinds.Exe(k)));
                    sb.AppendLine(k + Lang.T(" نصب‌شده: ", " installed: ") + f + (v != null ? " (" + v + ")" : ""));
                }
            }
            // The MT4 build MetaTrader has downloaded: older copies are brought to it before they start.
            string mt4Cache = TerminalUpdate.CacheDir(Kind.MT4);
            Version downloaded = mt4Cache != null ? TerminalUpdate.FileVersion(Path.Combine(mt4Cache, Kinds.Exe(Kind.MT4))) : null;
            if (downloaded != null)
            {
                int older = copies.Count(c => c.Kind == Kind.MT4 && TerminalUpdate.Newer(downloaded, TerminalUpdate.FileVersion(c.Exe)));
                sb.AppendLine(Lang.T("MT4 دانلودشده‌ی خود متاتریدر: ", "MT4 downloaded by MetaTrader itself: ") + downloaded +
                              (older > 0 ? " | " + older + Lang.T(" نسخه‌ی MT4 قدیمی‌ترند و پیش از اجرا به‌روز می‌شوند", " MT4 copies are older and are updated before they run") : Lang.T(" | نسخه‌های MT4 به‌روزند", " | MT4 copies are up to date")));
            }
            var running = Processes.Running();
            try
            {
            HashSet<string> mine = Owned.Mine(running);
            var reviews=(reviewCopies??new Instance[0]).ToList();
            var runtime=copies.Concat(reviews).GroupBy(c=>c.Exe,StringComparer.OrdinalIgnoreCase).Select(g=>g.First()).ToList();
            int primaryOpen=copies.Count(c=>Processes.IsRunning(running,c.Exe)),reviewOpen=reviews.Count(c=>Processes.IsRunning(running,c.Exe));
            int open = runtime.Count(c => Processes.IsRunning(running, c.Exe)), ours = runtime.Count(c => mine.Contains(c.Exe.ToLowerInvariant()));
            sb.AppendLine("Runtime by role: primary/live="+primaryOpen+" chart-review="+(reviewCopies==null?"not enumerated":reviewOpen.ToString(CultureInfo.InvariantCulture))+"; a running review is not proof of live reporting.");
            sb.AppendLine(Lang.T("نسخه‌ها: ", "Copies: ") + copies.Count(c => c.Kind == Kind.MT4) + Lang.T(" MT4، ", " MT4, ") + copies.Count(c => c.Kind == Kind.MT5) + Lang.T(" MT5 | در حال اجرا: ", " MT5 | running: ") + open +
                          " (" + ours + Lang.T(" تا با این برنامه باز شده و از این‌جا بسته می‌شوند", " opened by this program and closed from here") + (open > ours ? Lang.T("؛ ", "; ") + (open - ours) + Lang.T(" تا جور دیگری باز شده و دست نمی‌خورند", " opened another way and left alone") : "") + ")");
            sb.AppendLine(Lang.T("MT4 باز در این کاربر ویندوز: ", "MT4 open for this Windows user: ") + Processes.Mt4InSession() + Lang.T(" | بازکردن دستی MT4 / MT5: بدون سقف تعداد؛ حافظه فقط هشدار می‌دهد.", " | Manual MT4 / MT5 opening: no count cap; memory is advisory only."));
            sb.AppendLine(Lang.T("سقف قدیمی فقط برای بررسی حساب و گزارش MT4: ", "Legacy MT4 limit for account checks and reports only: ") + Mt4Limit.Clamp(s.MaxMt4));
            sb.AppendLine("Managed MT5 automatic updates paused="+s.PauseMt5Updates+"; "+Mt5UpdatePolicy.Summary());
            sb.AppendLine(Lang.T("اجرای متاتریدر با دسترسی فعلی: ", "Terminal launch at current privilege level: ") + (s.NormalTerminalRights ? "ON (process-scoped RunAsInvoker; UAC unchanged)" : "OFF (legacy launch behavior)"));
            sb.AppendLine("Sandboxie manual MT4 routing: " + (s.SandboxieOverflow ? "ON" : "OFF") + " | " + SandboxLaunch.Describe());
            try { sb.AppendLine("Native-context MT4: " + SandboxLaunch.NativeMt4Count() + " | report admission limit: " + SandboxLaunch.ReportLimit(s)); }
            catch (Exception e) { sb.AppendLine("Sandboxie runtime check: " + e.Message); }
            int? heap = Heap.Current();
            sb.AppendLine(Lang.T("حافظهٔ پنجره‌ها در رجیستری (نیازمند راه‌اندازی مجدد برای اعمال): ", "Configured desktop heap in registry (restart required to apply): ") + (heap.HasValue ? heap.Value + " KB" + (heap.Value > Heap.Recommended ? Lang.T(" (بالاتر از توصیهٔ مایکروسافت)", " (above Microsoft guidance)") : "") : Lang.T("خوانده نشد", "Not read")));
            // USER objects per process; their aggregate is NOT the per-process quota or actual heap usage.
            foreach (Kind k in new[] { Kind.MT4, Kind.MT5 })
            {
                List<int> counts = runtime.Where(c => c.Kind == k).Select(c => { Process p; return running.TryGetValue(c.Exe.ToLowerInvariant(), out p) ? Native.WindowObjects(p) : -1; })
                    .Where(n => n > 0).ToList();
                if (counts.Count > 0)
                    sb.AppendLine(Lang.T("اشیای پنجره‌ای هر ", "Window objects per ") + k + Lang.T(" (باز): میانگین ", " (open): average ") + (int)counts.Average() + Lang.T("، بیشترین ", ", most ") + counts.Max() + Lang.T("، جمع ", ", total ") + counts.Sum());
            }
            int withLogin = accounts.All.Count(a => a.HasLogin);
            sb.AppendLine(Lang.T("حساب‌های ثبت‌شده: ", "Saved accounts: ") + withLogin + Lang.T(" | رمز خوانده‌نشده: ", " | unreadable passwords: ") + accounts.All.Count(a => a.HasLogin && !a.Readable));
            sb.AppendLine(Lang.T("اجرای کوچک‌شده: ", "Start minimized: ") + (s.Minimized ? Lang.T("بله", "Yes") : Lang.T("خیر", "No")) + Lang.T(" | حالت سبک: ", " | light mode: ") + (s.Light ? Lang.T("بله", "Yes") : Lang.T("خیر", "No")) + Lang.T(" | فاصله‌ی اجرا: ", " | start interval: ") + s.DelaySeconds + Lang.T(" ثانیه", " seconds"));
            sb.AppendLine(Lang.T("فایل گزارش: ", "Log file: ") + AppPaths.LogFile);
            sb.AppendLine(LaunchCapacityDiagnostics.Summary());
            sb.AppendLine(LaunchComparison.Summary());
            sb.AppendLine(TerminalProcessPolicy.UpdateElevationDiagnostics());
            return sb.ToString();
            }
            finally { foreach (Process process in running.Values) process.Dispose(); }
        }
    }

    // ------------------------------------------------------------------ starting with Windows

    public static class AutoStart
    {
        const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
        const string ValueName = "MTManager";

        public static void Set(bool on, string exePath)
        {
            using (RegistryKey k = Registry.CurrentUser.OpenSubKey(RunKey, true) ?? Registry.CurrentUser.CreateSubKey(RunKey))
            {
                if (on) k.SetValue(ValueName, "\"" + exePath + "\" --startall");
                else if (k.GetValue(ValueName) != null) k.DeleteValue(ValueName, false);
            }
        }
    }
}
