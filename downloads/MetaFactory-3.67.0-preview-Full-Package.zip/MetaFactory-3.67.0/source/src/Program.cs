using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

[assembly: AssemblyTitle("MetaFactory")]
[assembly: AssemblyProduct("MetaFactory")]
[assembly: AssemblyDescription("Creates and runs many independent copies of MetaTrader 4 and 5")]
[assembly: AssemblyVersion("3.67.0.0")]
[assembly: AssemblyFileVersion("3.67.0.0")]

namespace MTManager
{
    static class Program
    {
        public const string Version = AppInfo.Version;

        /// <summary>3.27: set when the language was changed: the window closes and is made again in the new language.</summary>
        public static bool Rebuild;

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr window, int command);

        [DllImport("user32.dll")]
        static extern bool SetForegroundWindow(IntPtr window);

        [DllImport("user32.dll")]
        static extern bool IsIconic(IntPtr window);

        // Kept tiny on purpose: anything that fails while the program starts, even loading its own code,
        // ends up in Crash() and is shown, instead of Windows closing the program without a word.
        [STAThread]
        static int Main(string[] args)
        {
            try { return Run(args); }
            catch (Exception e)
            {
                Crash(e);
                return 1;
            }
        }

        static int Run(string[] args)
        {
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                Exception ex = e.ExceptionObject as Exception;
                if (ex != null) Crash(ex); else Log.Write("unhandled: " + e.ExceptionObject);
            };
            string command = args.Length > 0 ? args[0].ToLowerInvariant() : "";
            Log.Write("start " + Version + " " + command + " · " + Environment.OSVersion + " · .NET " + Environment.Version + " · " + (Environment.Is64BitProcess ? "64" : "32") + "-bit");
            // Data files of earlier versions are brought to the current one first (after a copy is kept aside).
            // Not in the elevated helper run: files written there would belong to the administrator.
            if (command != "--heap")
            {
                try { DataSchema.Upgrade(); }
                catch (Exception e) { Log.Write("data upgrade: " + e.Message + " (the files stay as they were)"); }
            }
            try
            {
                switch (command)
                {
                    case "--heap": return SetHeap(args.Length > 1 ? args[1] : "");
                    case "--startall": StartHeadless(null); return 0;
                    case "--start": StartHeadless(args.Length > 1 ? args[1] : ""); return 0;
                }
            }
            catch (Exception e)
            {
                Log.Write(command + " failed: " + e);
                return 1;
            }

            // 3.27: the language before any window or font.
            try { Lang.En = Settings.Load().Language == "en"; } catch (Exception e) { Log.Write("language: " + e.Message); }
#if SNAPSHOT
            if (Environment.GetEnvironmentVariable("MTM_LANG") == "en") Lang.En = true;
#endif
            Theme.Init();
            try { Theme.Apply(Settings.Load().Look); } catch (Exception e) { Log.Write("look: " + e.Message); }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            ThreadExceptionEventHandler onError = (s, e) => Ui.Error(null, e.Exception);
            Application.ThreadException += onError;

            if (command == "--diagnose") return Diagnose();
            if (command == "--uninstall") return Uninstall();
#if SNAPSHOT
            if (command == "--crash-test") throw new InvalidOperationException("crash test");
            if (command == "--snapshot" && args.Length >= 3)
            {
                // Build check: shows the windows with a test data folder and captures them, then exits.
                AppPaths.DataDirOverride = args[2];
                Settings snap = Settings.Load();
                string look = Environment.GetEnvironmentVariable("MTM_LOOK");
                if (!string.IsNullOrEmpty(look)) snap.Look = look;
                Theme.Apply(snap.Look);
                using (var f = new MainForm(snap, AccountStore.Load())) f.Snapshot(args[1]);
                return 0;
            }
#endif

            bool first;
            using (var single = new Mutex(true, "MTManager.SingleWindow", out first))
            {
                // Another run has the window: bring it forward. If that run has ended meanwhile, this one carries on.
                if (!first && !ShowOtherWindow(single)) return 0;
                WritePid();
                DeleteReplacedExe();
                // 3.27: a new language makes the window again in the same run (MetaTraders stay open; the window's own closing
                // transfers protected start-file cleanup to the next window in the same process).
                do
                {
                    Rebuild = false;
                    Settings settings = Settings.Load();
                    Lang.En = settings.Language == "en";
                    Theme.Fonts();
                    AccountStore accounts = AccountStore.Load();
                    var form = new MainForm(settings, accounts);
                    Application.Run(form);
                    if (Rebuild) Log.Write("window made again for the language: " + (Lang.En ? "en" : "fa"));
                }
                while (Rebuild);
            }
            try { File.Delete(PidFile); } catch { }
            Log.Write("closed");
            return 0;
        }

        static string PidFile { get { return Path.Combine(AppPaths.DataDir, "window.pid"); } }

        /// <summary>Which process holds the window, so a second start can tell it from a windowless autostart run.</summary>
        static void WritePid()
        {
            try { File.WriteAllText(PidFile, Process.GetCurrentProcess().Id.ToString(System.Globalization.CultureInfo.InvariantCulture)); }
            catch (Exception e) { Log.Write("pid: " + e.Message); }
        }

        static Process WindowRun()
        {
            try
            {
                int pid;
                if (!int.TryParse(File.ReadAllText(PidFile).Trim(), out pid) || pid == Process.GetCurrentProcess().Id) return null;
                Process p = Process.GetProcessById(pid);
                return string.Equals(p.ProcessName, Process.GetCurrentProcess().ProcessName, StringComparison.OrdinalIgnoreCase) ? p : null;
            }
            catch { return null; }
        }

        /// <summary>The program is already open: bring its window forward (without changing its size).
        /// Returns true when the other run has ended in the meantime and this one should become the program.</summary>
        static bool ShowOtherWindow(Mutex single)
        {
            DateTime until = DateTime.Now.AddSeconds(6);
            while (true)
            {
                try { if (single.WaitOne(0)) return true; }
                catch (AbandonedMutexException) { return true; }  // it ended without closing properly; the mutex is ours now
                Process other = WindowRun();
                IntPtr window = other != null ? other.MainWindowHandle : IntPtr.Zero;
                if (window != IntPtr.Zero)
                {
                    if (IsIconic(window)) ShowWindow(window, 9);  // restore only when minimized, so a maximized window stays so
                    SetForegroundWindow(window);
                    return false;
                }
                // Starting, or reopening in a new look: give it a few seconds to show its window.
                if (DateTime.Now > until) break;
                Thread.Sleep(250);
            }
            Process stuck = WindowRun();
            if (stuck == null)
            {
                Ui.Message(null, Lang.T("برنامه همین حالا در حال باز یا بسته شدن است. چند ثانیه بعد دوباره امتحان کنید.", "The program is opening or closing right now. Try again in a few seconds."));
                return false;
            }
            if (Ui.Confirm(null, Lang.T("یک اجرای قبلی برنامه بدون پنجره مانده و جلوی باز شدن را گرفته. بسته شود و برنامه دوباره باز شود؟", "An earlier run of the program was left without a window and is blocking the start. Close it and open the program again?")))
            {
                Log.Write("ended a stuck run (pid " + stuck.Id + ")");
                try { stuck.Kill(); stuck.WaitForExit(5000); } catch (Exception e) { Log.Write("kill: " + e.Message); }
                try { if (single.WaitOne(3000)) return true; }
                catch (AbandonedMutexException) { return true; }
            }
            return false;
        }

        /// <summary>A check that needs no main window: saves the system report on the desktop and shows where.</summary>
        static int Diagnose()
        {
            Settings s = Settings.Load();
            var saved=AccountStore.Load();var mainCopies=StudentDirectory.All(s,saved);
            string text = Checks.Report(s,mainCopies,saved,mainCopies.SelectMany(ReviewCopies.Existing).ToList())+ReportCopyRepair.Diagnostics();
            try { text += LiveAutoStart.Diagnostics(Installs.Copies(s)); } catch (Exception e) { text += "\r\nLive diagnostics: " + e.Message; }
            try { text += ReportTrace.Summary(s); } catch (Exception e) { text += Lang.T("\r\nگزارش معاملات: ", "\r\nTrade report: ") + e.Message; }
            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "MTManager-check.txt");
            File.WriteAllText(path, text, System.Text.Encoding.UTF8);
            Log.Write("diagnose\r\n" + text);
            Ui.Message(null, Lang.T("گزارش بررسی سیستم روی دسکتاپ ذخیره شد:\n", "The system check was saved on the desktop:\n") + path + Lang.T("\n\nآن فایل را بفرستید.", "\n\nSend that file."));
            return 0;
        }

        /// <summary>Saves what went wrong on the desktop (easy to find and send) and in the log, and says so.</summary>
        static void Crash(Exception e)
        {
            string details =
                "MetaFactory " + Version + " · " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\r\n" +
                Environment.OSVersion + " · .NET " + Environment.Version + " · " + (Environment.Is64BitProcess ? "64" : "32") + "-bit\r\n\r\n" + e;
            string file = null;
            try
            {
                file = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "MTManager-error.txt");
                File.WriteAllText(file, details);
            }
            catch { file = null; }
            try { Log.Write("crash: " + e); } catch { }
            try
            {
                MessageBox.Show(
                    Lang.T("برنامه هنگام شروع به خطا خورد و باز نشد.\n\n", "The program hit an error while starting and did not open.\n\n") + e.GetType().Name + ": " + e.Message +
                    (file != null ? Lang.T("\n\nجزئیات در این فایل روی دسکتاپ ذخیره شد؛ آن را بفرستید:\n", "\n\nThe details were saved in this file on the desktop; send it:\n") + file : ""),
                    Ui.Title, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.RtlReading | MessageBoxOptions.RightAlign);
            }
            catch { }
        }

        /// <summary>The setup renames a running old version instead of failing on it; that file can go now.</summary>
        static void DeleteReplacedExe()
        {
            string dir = Path.GetDirectoryName(Application.ExecutablePath);
            string name = Path.GetFileName(Application.ExecutablePath);
            try
            {
                foreach (string old in Directory.GetFiles(dir, name + ".old*"))
                    try { File.Delete(old); } catch (Exception e) { Log.Write("old exe: " + e.Message); }
            }
            catch (Exception e) { Log.Write("old exe: " + e.Message); }
        }

        /// <summary>From Windows Settings > Apps: removes the program, never the copies, accounts or settings.</summary>
        static int Uninstall()
        {
            string dir = Path.GetDirectoryName(Application.ExecutablePath);
            if (!Ui.Confirm(null, "«" + Ui.Title + Lang.T("» از این کامپیوتر حذف شود؟\n\nنسخه‌های متاتریدری که ساخته‌اید، حساب‌ها و تنظیمات دست نمی‌خورند؛ اگر دوباره نصبش کنید، همه سر جایشان هستند.", "” be removed from this computer?\n\nThe MetaTrader copies you made, the accounts and the settings are not touched; if you install it again, everything is in its place.")))
                return 0;
            Log.Write("uninstall from " + dir);
            Installation.Close(Installation.Running(dir), () => Application.DoEvents());
            // A run ended mid-way may have left start files, which can hold a password.
            try { Launcher.DeleteLeftovers(Installs.Copies(Settings.Load())); } catch (Exception e) { Log.Write("leftovers: " + e.Message); }
            try { ReportCopies.DeleteLeftovers(Settings.Load()); } catch (Exception e) { Log.Write("report leftovers: " + e.Message); }
            Installation.RemoveShortcuts();
            Installation.Unregister();
            Ui.Message(null, Lang.T("حذف شد.\n\nاطلاعات شما (حساب‌ها و تنظیمات) در این پوشه مانده است:\n", "Removed.\n\nYour data (accounts and settings) stays in this folder:\n") + AppPaths.DataDir);
            try { Installation.RemoveFilesAfterExit(dir); } catch (Exception e) { Log.Write("remove files: " + e.Message); }
            return 0;
        }

        /// <summary>Runs elevated (the window asks Windows for it) to change the desktop heap.</summary>
        static int SetHeap(string arg)
        {
            int kb;
            if (!int.TryParse(arg, out kb) || (kb != 3072 && kb != 6144 && kb != 12288 && kb != Heap.Recommended)) return 2;
            Heap.Set(kb);
            return 0;
        }

        /// <summary>No window: for starting with Windows (--startall) or one copy (--start NAME).</summary>
        static void StartHeadless(string only)
        {
            Settings s = Settings.Load();
            AccountStore accounts = AccountStore.Load();
            List<Instance> list = StudentDirectory.All(s, accounts);
            if (only != null) list = list.Where(i => string.Equals(i.Name, only, StringComparison.OrdinalIgnoreCase)).ToList();
            var running = Processes.Running();
            try { Owned.AdoptFromLog(Installs.Copies(s), running); } catch (Exception e) { Log.Write("opened list: " + e.Message); }
            var pending = new List<PendingStart>();
            // While waiting between starts, each start file goes as soon as its terminal has read it.
            Action<double> wait = seconds =>
            {
                DateTime until = DateTime.Now.AddSeconds(seconds);
                do
                {
                    pending = Launcher.CleanStartFiles(pending, DateTime.Now, false);
                    if (DateTime.Now >= until) break;
                    Thread.Sleep(250);
                } while (true);
            };
            foreach (Instance i in list)
            {
                if (Processes.IsRunning(running, i.Exe)) continue;
                try
                {
                    StudentDirectory.EnsureCopy(s, i, accounts.Get(i.Name), () => false);
                    StartResult r = Launcher.StartManual(i, s, accounts);
                    if (r.StartFile != null) pending.Add(new PendingStart { Path = r.StartFile, Time = DateTime.Now, Process = r.Process, Copy = i, MaxWaitSeconds = r.Sandboxed ? 120 : Launcher.StartFileSeconds });
                    if (r.Warning != null) Log.Write(r.Warning);
                }
                catch (Exception e) { LaunchCapacityDiagnostics.Failure(i.Name, e); Log.Write("start " + i.Name + " failed: " + e.Message); }
                if (list.Count > 1) wait(Math.Max(1, s.DelaySeconds));
            }
            // The last ones: at most StartFileSeconds more.
            DateTime last = DateTime.Now.AddSeconds(pending.Count == 0 ? Launcher.StartFileSeconds + 1 : pending.Max(p => p.MaxWaitSeconds) + 1);
            while (pending.Count > 0 && DateTime.Now < last) wait(0.25);
            pending = Launcher.CleanStartFiles(pending, DateTime.Now, true);
        }
    }
}
