using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MTManager
{
    public enum LiveFeedStatus { Waiting, Live, HistoryPending, Disconnected, IdentityMismatch, Stopped, Stale, Invalid }

    public sealed class LivePosition
    {
        public long Ticket { get; private set; }
        public string Symbol { get; private set; }
        public bool Buy { get; private set; }
        public double Volume { get; private set; }
        public DateTime Open { get; private set; }
        public double OpenPrice { get; private set; }
        public double Sl { get; private set; }
        public double Tp { get; private set; }
        public double Profit { get; private set; }
        public double Swap { get; private set; }
        public double SlEntry { get; private set; }
        public double Price { get; private set; }
        public double Commission { get; private set; }
        public double Net { get { return Profit + Swap + Commission; } }
        internal LivePosition(long ticket, string symbol, bool buy, double volume, DateTime open, double[] n)
        { Ticket = ticket; Symbol = symbol; Buy = buy; Volume = volume; Open = open; OpenPrice = n[0]; Sl = n[1]; Tp = n[2]; Profit = n[3]; Swap = n[4]; SlEntry = n[5]; Price = n[6]; Commission = n[7]; }
    }

    public sealed class LiveFeedSnapshot
    {
        public LiveFeedStatus Status { get; private set; }
        public bool IsLive { get { return Status == LiveFeedStatus.Live || Status == LiveFeedStatus.HistoryPending; } }
        public string Reason { get; private set; }
        public string Version { get; private set; }
        public string RunId { get; private set; }
        public string NativeState { get; private set; }
        public long Sequence { get; private set; }
        public long HistoryRevision { get; private set; }
        public DateTime HeartbeatUtc { get; private set; }
        public string Platform { get; private set; }
        public string Login { get; private set; }
        public string Server { get; private set; }
        public string Currency { get; private set; }
        public double Balance { get; private set; }
        public double Equity { get; private set; }
        public double Margin { get; private set; }
        public double FreeMargin { get; private set; }
        public double Credit { get; private set; }
        public IReadOnlyList<LivePosition> Positions { get; private set; }
        /// <summary>Cached immutable-by-contract baseline, never the manual journal cache. Null unless current/ready/proven.</summary>
        public AccountJournal History { get; private set; }
        internal LiveFeedSnapshot(LiveFeedStatus status, string reason, string platform, string login, string server, LiveFeedFrame data, AccountJournal history)
        {
            Status = status; Reason = reason; Platform = platform; Login = login; Server = server;
            RunId = data == null ? "" : data.Run; Sequence = data == null ? 0 : data.Sequence;
            NativeState = data == null ? "" : data.State;
            HistoryRevision = data == null ? 0 : data.Revision; HeartbeatUtc = data == null ? DateTime.MinValue : data.Heartbeat;
            Version = RunId + ":" + Sequence + ":" + HistoryRevision + ":" + status + ":" + reason;
            Currency = IsLive && data != null ? data.Currency : "";
            Balance = Equity = Margin = FreeMargin = Credit = double.NaN;
            Positions = new ReadOnlyCollection<LivePosition>(new List<LivePosition>());
            if (IsLive && data != null)
            {
                Balance = data.Values[0]; Equity = data.Values[1]; Margin = data.Values[2]; FreeMargin = data.Values[3]; Credit = data.Values[4];
                Positions = new ReadOnlyCollection<LivePosition>(data.Positions.ToArray()); History = history;
            }
        }
    }

    internal sealed class LiveFeedFrame
    {
        internal string Token, Run, Platform, Login, Server, Currency, State;
        internal long Sequence, Revision;
        internal int Slot;
        internal DateTime Heartbeat;
        internal bool Connected;
        internal double[] Values;
        internal readonly List<LivePosition> Positions = new List<LivePosition>();
    }

    /// <summary>One background-owned reader per opted-in copy. No terminal launch, network, manual cache writes, or UI calls.</summary>
    public sealed class LiveFeedReader
    {
        public const int MaximumSnapshotBytes = 2 * 1024 * 1024, MaximumHistoryBytes = 64 * 1024 * 1024, MaximumPositions = 10000;
        public const int StaleSeconds = 10, FutureSeconds = 5;
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
        static readonly DateTime Epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        readonly string platform, login, server, token, directory;
        readonly object gate = new object();
        readonly HashSet<string> retired = new HashSet<string>(StringComparer.Ordinal);
        readonly Queue<string> retiredOrder = new Queue<string>();
        LiveFeedFrame current;
        DateTime observedUtc, historyAttemptUtc = DateTime.MinValue, snapshotWriteUtc = DateTime.MinValue;
        long snapshotLength = -1;
        string snapshotText, historyKey;
        AccountJournal baseline;
        public LiveFeedReader(Kind kind, string login, string server, string token, string directory)
        {
            if (!Regex.IsMatch(token ?? "", "\\A[0-9a-fA-F]{32}\\z")) throw new ArgumentException("Invalid live session token.");
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(server)) throw new ArgumentException("Live account identity is required.");
            this.platform = kind.ToString(); this.login = login.Trim(); this.server = server.Trim(); this.token = token;
            this.directory = Path.GetFullPath(directory);
        }
        static bool Number(string text, out double value)
        { return double.TryParse(text, NumberStyles.Float, Inv, out value) && !double.IsNaN(value) && !double.IsInfinity(value); }
        static bool Integer(string text, out long value) { return long.TryParse(text, NumberStyles.None, Inv, out value); }
        static bool OneLine(string value, int max) { return value != null && value.Length <= max && !value.Any(char.IsControl); }
        static string[] Lines(string text) { return text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries); }

        internal static LiveFeedFrame Parse(string text)
        {
            if (string.IsNullOrEmpty(text)) return null;
            var frame = new LiveFeedFrame(); var seen = new HashSet<string>(); var tickets = new HashSet<long>();
            bool ended = false; int count = -1;
            string[] snapshotLines = Lines(text);
            if (snapshotLines.Length == 0 || !snapshotLines[0].StartsWith("MLIVE\t", StringComparison.Ordinal)) return null;
            foreach (string line in snapshotLines)
            {
                if (ended) return null;
                string[] f = line.Split('\t');
                if (f[0] != "O" && !seen.Add(f[0])) return null;
                long n;
                switch (f[0])
                {
                    case "MLIVE": if (f.Length != 3 || f[1] != "1" || (f[2] != "MT4" && f[2] != "MT5")) return null; frame.Platform = f[2]; break;
                    case "Q": if (f.Length != 2 || !Regex.IsMatch(f[1], "\\A[0-9a-fA-F]{32}\\z")) return null; frame.Token = f[1]; break;
                    case "R":
                        if (f.Length != 4 || !Regex.IsMatch(f[1], "\\A[A-Za-z0-9-]{1,96}\\z") || !Integer(f[2], out n) || n <= 0) return null;
                        frame.Run = f[1]; frame.Sequence = n;
                        if (!Integer(f[3], out n) || n <= 0 || n > 253402300799L) return null;
                        frame.Heartbeat = Epoch.AddSeconds(n); break;
                    case "A":
                        if (f.Length != 4 || !Integer(f[1], out n) || !OneLine(f[2], 256) || !OneLine(f[3], 32)) return null;
                        frame.Login = f[1]; frame.Server = f[2]; frame.Currency = f[3]; break;
                    case "S":
                        if (f.Length != 3 || (f[1] != "0" && f[1] != "1") || !new[] { "bootstrap", "ready", "history-pending", "history-unconfirmed", "disconnected", "identity-mismatch", "stopped", "error" }.Contains(f[2])) return null;
                        frame.Connected = f[1] == "1"; frame.State = f[2]; break;
                    case "V":
                        if (f.Length != 6) return null;
                        frame.Values = new double[5];
                        for (int i = 0; i < 5; i++) if (!Number(f[i + 1], out frame.Values[i])) return null;
                        break;
                    case "H":
                        if (f.Length != 3 || !Integer(f[1], out n) || (f[2] != "0" && f[2] != "1")) return null;
                        frame.Revision = n; frame.Slot = f[2] == "0" ? 0 : 1; break;
                    case "O":
                        if (frame.Positions.Count >= MaximumPositions || f.Length != 14 || !Integer(f[1], out n) || n <= 0 || !tickets.Add(n)
                            || !OneLine(f[2], 128) || f[2].Length == 0 || (f[3] != "0" && f[3] != "1")) return null;
                        long ticket = n, opened; double volume;
                        if (!Number(f[4], out volume) || volume <= 0 || !Integer(f[5], out opened) || opened <= 0 || opened > 253402300799L) return null;
                        var values = new double[8];
                        for (int i = 0; i < 8; i++) if (!Number(f[i + 6], out values[i])) return null;
                        double net = values[3] + values[4] + values[7];
                        if (double.IsNaN(net) || double.IsInfinity(net)) return null;
                        frame.Positions.Add(new LivePosition(ticket, f[2], f[3] == "0", volume, Epoch.AddSeconds(opened), values)); break;
                    case "END":
                        if (f.Length != 2 || !int.TryParse(f[1], NumberStyles.None, Inv, out count)) return null;
                        ended = true; break;
                    default: return null;
                }
            }
            return ended && count == frame.Positions.Count && new[] { "MLIVE", "Q", "R", "A", "S", "V", "H", "END" }.All(seen.Contains) ? frame : null;
        }

        static string ReadBounded(string path, int limit, Func<bool> cancelled)
        {
            using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            {
                if (stream.Length <= 0 || stream.Length > limit) return null;
                using (var bytes = new MemoryStream((int)stream.Length))
                {
                    byte[] buffer = new byte[65536]; int n;
                    while ((n = stream.Read(buffer, 0, buffer.Length)) > 0)
                    { if (cancelled()) throw new OperationCanceledException(); if (bytes.Length + n > limit) return null; bytes.Write(buffer, 0, n); }
                    byte[] data = bytes.ToArray();
                    if (data.Length >= 2 && data[0] == 255 && data[1] == 254) return new UnicodeEncoding(false, false, true).GetString(data, 2, data.Length - 2);
                    int skip = data.Length >= 3 && data[0] == 239 && data[1] == 187 && data[2] == 191 ? 3 : 0;
                    return new UTF8Encoding(false, true).GetString(data, skip, data.Length - skip);
                }
            }
        }
        LiveFeedSnapshot Result(LiveFeedStatus status, string reason, AccountJournal history = null)
        { return new LiveFeedSnapshot(status, reason, platform, login, server, current, history); }
        bool Identity(LiveFeedFrame frame)
        { return frame.Token == token && frame.Platform == platform && frame.Login == login && string.Equals(frame.Server.Trim(), server, StringComparison.OrdinalIgnoreCase); }
        bool Fresh(DateTime heartbeat, DateTime now)
        { return now - heartbeat <= TimeSpan.FromSeconds(StaleSeconds) && heartbeat - now <= TimeSpan.FromSeconds(FutureSeconds); }

        public LiveFeedSnapshot Poll(DateTime utcNow, Func<bool> cancelled = null)
        {
            lock (gate)
            {
                cancelled = cancelled ?? (() => false);
                if (cancelled()) return Result(LiveFeedStatus.Stopped, "cancelled");
                try
                {
                    string path = Path.Combine(directory, "snapshot.txt");
                    var info = new FileInfo(path);
                    if (!info.Exists) return Result(LiveFeedStatus.Waiting, "snapshot-missing");
                    if (info.Length > MaximumSnapshotBytes || info.Length == 0) return Result(LiveFeedStatus.Invalid, "snapshot-size");
                    string text;
                    if (snapshotText != null && info.LastWriteTimeUtc == snapshotWriteUtc && info.Length == snapshotLength) text = snapshotText;
                    else
                    {
                        text = ReadBounded(path, MaximumSnapshotBytes, cancelled);
                        snapshotText = text; snapshotWriteUtc = info.LastWriteTimeUtc; snapshotLength = info.Length;
                    }
                    LiveFeedFrame incoming = Parse(text);
                    if (incoming == null) return Result(LiveFeedStatus.Invalid, "snapshot-incomplete-or-invalid");
                    if (!Identity(incoming)) return Result(LiveFeedStatus.IdentityMismatch, "account-or-session-mismatch");
                    if (!Fresh(incoming.Heartbeat, utcNow)) return Result(LiveFeedStatus.Stale, "heartbeat-expired-or-future");
                    if (current != null && incoming.Run == current.Run && incoming.Sequence < current.Sequence) return Result(LiveFeedStatus.Invalid, "sequence-replay");
                    if (current != null && incoming.Run == current.Run && incoming.Revision < current.Revision) return Result(LiveFeedStatus.Invalid, "history-revision-replay");
                    if (current == null || incoming.Run != current.Run || incoming.Sequence > current.Sequence)
                    {
                        if (current != null && incoming.Run != current.Run)
                        {
                            if (retired.Contains(incoming.Run) || incoming.Heartbeat < current.Heartbeat) return Result(LiveFeedStatus.Invalid, "retired-or-older-run");
                            retired.Add(current.Run); retiredOrder.Enqueue(current.Run);
                            if (retiredOrder.Count > 64) retired.Remove(retiredOrder.Dequeue());
                        }
                        if (current != null && incoming.Run == current.Run && incoming.Heartbeat < current.Heartbeat) return Result(LiveFeedStatus.Invalid, "heartbeat-regressed");
                        current = incoming; observedUtc = utcNow;
                    }
                    if (!Fresh(current.Heartbeat, utcNow) || utcNow - observedUtc > TimeSpan.FromSeconds(StaleSeconds)) return Result(LiveFeedStatus.Stale, "heartbeat-not-advancing");
                    if (current.State == "stopped") return Result(LiveFeedStatus.Stopped, "native-stopped");
                    if (current.State == "identity-mismatch") return Result(LiveFeedStatus.IdentityMismatch, "native-account-mismatch");
                    if (current.State == "error") return Result(LiveFeedStatus.Invalid, "native-error");
                    if (!current.Connected || current.State == "disconnected") return Result(LiveFeedStatus.Disconnected, "broker-disconnected");
                    if (current.State != "ready" || current.Revision == 0) return Result(LiveFeedStatus.HistoryPending, "history-" + current.State);
                    string key = current.Run + ":" + current.Revision + ":" + current.Slot;
                    if (key != historyKey || baseline == null && utcNow - historyAttemptUtc >= TimeSpan.FromSeconds(2))
                    {
                        historyKey = key; historyAttemptUtc = utcNow; baseline = null;
                        try
                        {
                            string raw = ReadBounded(Path.Combine(directory, "history-" + current.Slot + ".txt"), MaximumHistoryBytes, cancelled);
                            if (cancelled()) throw new OperationCanceledException();
                            baseline = ReadHistory(raw, current);
                            if (cancelled()) throw new OperationCanceledException();
                        }
                        catch (IOException) { baseline = null; }
                    }
                    double tolerance = Math.Max(0.02, Math.Abs(current.Values[0]) * 0.000001);
                    if (baseline == null || Math.Abs(baseline.Balance - current.Values[0]) > tolerance)
                        return Result(LiveFeedStatus.HistoryPending, "history-proof-or-revision-pending");
                    return Result(LiveFeedStatus.Live, "ready", baseline);
                }
                catch (OperationCanceledException) { return Result(LiveFeedStatus.Stopped, "cancelled"); }
                catch (FileNotFoundException) { return Result(LiveFeedStatus.Waiting, "file-replacement-pending"); }
                catch (DirectoryNotFoundException) { return Result(LiveFeedStatus.Waiting, "feed-directory-missing"); }
                catch (Exception) { return Result(LiveFeedStatus.Invalid, "feed-read-failed"); }
            }
        }

        AccountJournal ReadHistory(string text, LiveFeedFrame frame)
        {
            if (text == null) return null;
            string[] lines = Lines(text), live = lines.Where(x => x.StartsWith("LIVE\t", StringComparison.Ordinal)).ToArray(), q = lines.Where(x => x.StartsWith("Q\t", StringComparison.Ordinal)).ToArray();
            if (lines.Length == 0 || !lines[0].StartsWith("MTR\t2\t", StringComparison.Ordinal) || !lines[lines.Length - 1].StartsWith("END\t", StringComparison.Ordinal)
                || lines.Count(x => x.StartsWith("END\t", StringComparison.Ordinal)) != 1
                || live.Length != 1 || q.Length != 1 || q[0] != "Q\t" + token) return null;
            string[] f = live[0].Split('\t'); long revision;
            if (f.Length != 5 || f[1] != "1" || f[2] != token || f[3] != frame.Run || !Integer(f[4], out revision) || revision != frame.Revision) return null;
            AccountJournal journal = JournalFile.Parse(text);
            return journal != null && journal.Complete && journal.FullHistoryValid && journal.RequestToken == token
                && journal.Platform == platform && journal.Login == login && string.Equals(journal.Server.Trim(), server, StringComparison.OrdinalIgnoreCase)
                ? journal : null;
        }
    }
}
