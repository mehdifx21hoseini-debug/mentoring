using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MTManager
{
    internal sealed class LiveMonitorDialog : Form
    {
        readonly Settings settings;
        readonly Func<List<LiveMonitorCandidate>> allCandidates, selectedCandidates;
        readonly LiveMonitorController controller = new LiveMonitorController();
        readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer { Interval = 1000 };
        readonly CheckBox enabled = new CheckBox { AutoSize = true };
        readonly Button prepareSelected = new Button(), prepareOpen = new Button(), copySummary = new Button(), cancelSetup = new Button(), setupGuide = new Button();
        readonly Label status = new Label { AutoSize = true };
        readonly TextBox detail = new TextBox { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Bottom };
        readonly DataGridView grid = new DataGridView();
        readonly Dictionary<string, string> instructions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        List<LiveMonitorTarget> targets;
        Task<PreparationResult> preparation;
        volatile bool cancelPreparation;
        bool closing, showingGuides, applyingRows;
        sealed class PreparationResult
        {
            public readonly List<LiveMonitorTarget> Targets = new List<LiveMonitorTarget>();
            public readonly Dictionary<string, string> Instructions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            public string Message;
        }
        internal LiveMonitorDialog(Settings settings, Func<List<LiveMonitorCandidate>> all, Func<List<LiveMonitorCandidate>> selected)
        {
            this.settings = settings; allCandidates = all; selectedCandidates = selected;
            string problem; targets = LiveMonitorStore.Load(out problem);
            foreach (var target in targets) if (!string.IsNullOrEmpty(target.Guide)) instructions[target.CopyName] = target.Guide;
            Text = Lang.T("پایش زندهٔ حساب‌ها", "Live account monitoring"); Font = Theme.Font; BackColor = Theme.Surface; ForeColor = Theme.Text;
            StartPosition = FormStartPosition.CenterParent; ClientSize = Theme.Sz(1320, 680); MinimumSize = Theme.Sz(780, 480);
            RightToLeft = Lang.En ? RightToLeft.No : RightToLeft.Yes;
            var header = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 1, Padding = Theme.Pad(16, 12) };
            var title = Theme.Label(Lang.T("پایش زنده، جدا از گزارش‌گیری دستی", "Live monitoring, separate from manual reports"), 0, Theme.Heading); title.AutoSize = true;
            var note = Theme.Label(Lang.T("متاتریدرها را از دکمهٔ «اجرا» در متافکتوری باز کنید؛ گزارش‌خوان هنگام شروع خودکار آماده می‌شود. برای نسخه‌های از قبل باز، ابتدا خودتان ببندید و دوباره اجرا کنید. خاموش‌کردن پایش، اکسپرت را حذف نمی‌کند.",
                "Open terminals using Run in MetaFactory; the reporter is prepared for automatic startup. For already-open copies, close them yourself and Run again. Turning monitoring off does not detach the EA."), 0, Theme.Small, Theme.Muted); note.AutoSize = true;
            header.Controls.Add(title); header.Controls.Add(note);
            var actions = new FlowLayoutPanel { AutoSize = true, Dock = DockStyle.Fill, WrapContents = true, FlowDirection = Lang.En ? FlowDirection.LeftToRight : FlowDirection.RightToLeft };
            enabled.Text = Lang.T("پایش زنده فعال باشد", "Enable live monitoring"); enabled.Margin = Theme.Pad(8, 10); enabled.CheckedChanged += (s, e) => {
                controller.Enable(enabled.Checked); grid.Rows.Clear(); detail.Clear();
                status.Text = enabled.Checked ? Lang.T("منتظر دریافت دادهٔ تازه…", "Waiting for new live data…") : Lang.T("پایش خاموش است؛ گزارش دستی تغییری نکرده است.", "Monitoring is off; manual reports are unchanged.");
                if (enabled.Checked) TickMonitor();
            };
            actions.Controls.Add(enabled);
            ButtonStyle(prepareSelected, Lang.T("آماده‌سازی انتخاب‌شده‌ها", "Prepare selected"));
            ButtonStyle(prepareOpen, Lang.T("آماده‌سازی متاتریدرهای باز", "Prepare open terminals"));
            ButtonStyle(copySummary, Lang.T("کپی خلاصهٔ زنده", "Copy live summary"));
            ButtonStyle(setupGuide, Lang.T("راهنما و نتیجهٔ آماده‌سازی", "Instructions / setup results"));
            setupGuide.Click += (s, e) => ShowGuides();
            ButtonStyle(cancelSetup, Lang.T("توقف آماده‌سازی", "Cancel preparation")); cancelSetup.Visible = false;
            prepareSelected.Click += (s, e) => Prepare(selectedCandidates()); prepareOpen.Click += (s, e) => Prepare(allCandidates());
            cancelSetup.Click += (s, e) => { cancelPreparation = true; cancelSetup.Enabled = false; status.Text = Lang.T("در حال توقف آماده‌سازی…", "Stopping preparation…"); };
            copySummary.Click += (s, e) => CopySummary();
            foreach (var button in new[] { prepareSelected, prepareOpen, copySummary, setupGuide, cancelSetup }) actions.Controls.Add(button);
            header.Controls.Add(actions); status.ForeColor = Theme.Muted; status.Margin = Theme.Pad(4, 8); header.Controls.Add(status);
            Controls.Add(header);
            grid.Dock = DockStyle.Fill; grid.BackgroundColor = Theme.Surface; grid.BorderStyle = BorderStyle.None;
            grid.AllowUserToAddRows = grid.AllowUserToDeleteRows = grid.AllowUserToResizeRows = false; grid.ReadOnly = true; grid.RowHeadersVisible = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; grid.MultiSelect = false; grid.AutoGenerateColumns = false;
            grid.EnableHeadersVisualStyles = false; grid.ColumnHeadersDefaultCellStyle.BackColor = Theme.Alt; grid.ColumnHeadersDefaultCellStyle.ForeColor = Theme.Text;
            grid.DefaultCellStyle.BackColor = Theme.Surface; grid.DefaultCellStyle.ForeColor = Theme.Text;
            grid.DefaultCellStyle.SelectionBackColor = Theme.AccentSoft; grid.DefaultCellStyle.SelectionForeColor = Theme.Text;
            grid.GridColor = Theme.Border; grid.RowTemplate.Height = Theme.S(38);
            AddColumn("name", Lang.T("دانشجو", "Student"), 150); AddColumn("copy", Lang.T("نسخه", "Copy"), 76); AddColumn("platform", "MT", 48);
            AddColumn("state", Lang.T("وضعیت", "Status"), 170); AddColumn("updated", Lang.T("آخرین دریافت", "Last received"), 88);
            AddColumn("balance", Lang.T("بالانس", "Balance"), 108); AddColumn("equity", Lang.T("اکوییتی", "Equity"), 108);
            AddColumn("positions", Lang.T("باز", "Open"), 48); AddColumn("floating", Lang.T("شناور + سواپ", "Floating + swap"), 108);
            AddColumn("nosl", Lang.T("بدون SL", "No SL"), 55); AddColumn("today", Lang.T("تحقق‌یافتهٔ امروز", "Realized today"), 130);
            grid.Columns["today"].ToolTipText = Lang.T("MT4: سفارش‌های بسته‌شده؛ MT5: معاملات خروج و نتیجهٔ تحقق‌یافتهٔ روز سرور، شامل کارمزد ورود.", "MT4: closed orders; MT5: closing deals and broker-day realized result, including entry fees."); AddColumn("dd", Lang.T("افت بالانس", "Balance DD"), 90);
            grid.SelectionChanged += (s, e) => { if (!applyingRows) { showingGuides = false; ShowDetails(); } };
            detail.Height = Theme.S(145); detail.BorderStyle = BorderStyle.FixedSingle; detail.BackColor = Theme.Alt; detail.ForeColor = Theme.Text;
            Controls.Add(grid); Controls.Add(detail); grid.BringToFront();
            Resize += (s, e) => { note.MaximumSize = new Size(Math.Max(200, ClientSize.Width - Theme.S(48)), 0); };
            note.MaximumSize = new Size(ClientSize.Width - Theme.S(48), 0);
            status.Text = problem ?? Lang.T("پایش خاموش است. برای شروع، حساب‌های باز را آماده و پایش را فعال کنید.", "Monitoring is off. Prepare the open accounts, then enable monitoring.");
            timer.Tick += (s, e) => TickMonitor(); timer.Start();
            enabled.Checked = true;
            FormClosed += (s, e) => { closing = true; cancelPreparation = true; timer.Stop(); timer.Dispose(); controller.Dispose(); };
        }
        void AddColumn(string key, string title, int width)
        {
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = key, HeaderText = title, Width = Theme.S(width), SortMode = DataGridViewColumnSortMode.NotSortable });
        }
        static void ButtonStyle(Button button, string text)
        {
            button.Text = text; button.AutoSize = true; button.Height = Theme.S(34); button.Padding = Theme.Pad(8, 3); button.Margin = Theme.Pad(4, 6);
            button.FlatStyle = FlatStyle.Flat; button.FlatAppearance.BorderColor = Theme.BorderStrong; button.BackColor = Theme.Surface; button.ForeColor = Theme.Text;
        }
        void Prepare(List<LiveMonitorCandidate> selected)
        {
            if (preparation != null) return;
            if (selected.Count == 0) { status.Text = Lang.T("ابتدا دانشجو را در صفحهٔ اصلی انتخاب کنید.", "Select students on the main page first."); return; }
            var existing = targets.Select(t => t.Snapshot()).ToList(); cancelPreparation = false;
            prepareSelected.Enabled = prepareOpen.Enabled = false; cancelSetup.Visible = true; cancelSetup.Enabled = true;
            status.Text = Lang.T("آماده‌سازی گزارش‌خوان؛ متاتریدرها باز یا بسته نمی‌شوند…", "Preparing reporters; terminals will not be opened or closed…");
            preparation = Task.Factory.StartNew(() => {
                var result = new PreparationResult(); int skipped = 0, failed = 0;
                foreach (var candidate in selected)
                {
                    if (cancelPreparation) break;
                    try
                    {
                        if (!LiveMonitorController.OpenPaths().Contains(candidate.Copy.Exe)) { skipped++; continue; }
                        var target = existing.FirstOrDefault(t => t.Matches(candidate.Copy, candidate.Account)) ?? LiveMonitorTarget.Create(candidate.Copy, candidate.Account);
                        var deployment = LiveReporter.Prepare(settings, candidate.Copy, candidate.Account, target.Token, () => cancelPreparation);
                        if (cancelPreparation) break;
                        target.Guide = deployment.Instructions; target.Name = candidate.Account.Trader;
                        result.Targets.Add(target); result.Instructions[target.CopyName] = deployment.Instructions;
                    }
                    catch (OperationCanceledException) { break; }
                    catch (Exception error)
                    {
                        failed++;
                        result.Instructions[candidate.Copy.Name] = Lang.T("آماده‌سازی انجام نشد: ", "Preparation failed: ") + error.Message;
                    }
                }
                result.Message = Lang.T("آماده: ", "Prepared: ") + result.Targets.Count + " · " + Lang.T("بسته/ردشده: ", "Closed/skipped: ") + skipped + " · " + Lang.T("خطا: ", "Failed: ") + failed
                    + (cancelPreparation ? Lang.T(" · متوقف شد", " · cancelled") : "") + "\r\n"
                    + Lang.T("آماده‌سازی به‌تنهایی گزارش‌خوان را فعال نمی‌کند. راهنمای اتصال روی نمودار تازه را در پایین بخوانید.", "Preparation alone does not attach the reporter. Follow the new-chart attachment instructions below.");
                return result;
            });
        }
        void TickMonitor()
        {
            if (closing) return;
            if (preparation != null && preparation.IsCompleted)
            {
                try
                {
                    var result = preparation.Result;
                    foreach (var target in result.Targets) { targets.RemoveAll(t => string.Equals(t.CopyName, target.CopyName, StringComparison.OrdinalIgnoreCase)); targets.Add(target); }
                    foreach (var item in result.Instructions) instructions[item.Key] = item.Value;
                    try { LiveMonitorStore.Save(targets); status.Text = result.Message; }
                    catch { status.Text = Lang.T("ذخیرهٔ تنظیمات پایش انجام نشد؛ پیش از بستن برنامه دوباره آماده‌سازی کنید.", "Live settings could not be saved; prepare again before closing the app."); }
                    ShowGuides();
                }
                catch { status.Text = Lang.T("آماده‌سازی کامل نشد؛ دوباره تلاش کنید.", "Preparation did not complete; try again."); }
                preparation = null; prepareSelected.Enabled = prepareOpen.Enabled = true; cancelSetup.Visible = false;
            }
            if (!enabled.Checked) return;
            string loadProblem; var latestTargets = LiveMonitorStore.Load(out loadProblem);
            if (loadProblem == null) targets = latestTargets;
            Apply(controller.Snapshot());
            controller.Poll(targets, allCandidates());
            if (targets.Count == 0 && preparation == null) status.Text = Lang.T("هنوز حسابی آماده نشده؛ انتخاب‌شده‌ها یا متاتریدرهای باز را آماده کنید.", "No accounts prepared yet; prepare selected students or open terminals.");
        }
        void Apply(List<LiveMonitorView> views)
        {
            applyingRows = true;
            try
            {
            var keys = new HashSet<string>(views.Select(v => v.CopyName), StringComparer.OrdinalIgnoreCase);
            for (int n = grid.Rows.Count - 1; n >= 0; n--) if (!keys.Contains(((LiveMonitorView)grid.Rows[n].Tag).CopyName)) grid.Rows.RemoveAt(n);
            foreach (var view in views)
            {
                var row = grid.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => string.Equals(((LiveMonitorView)r.Tag).CopyName, view.CopyName, StringComparison.OrdinalIgnoreCase));
                if (row != null && ((LiveMonitorView)row.Tag).Signature == view.Signature) continue;
                if (row == null) { int index = grid.Rows.Add(); row = grid.Rows[index]; }
                row.Tag = view; row.SetValues(view.Name + " (" + view.Login + ")", view.CopyName, view.Platform, view.State, view.Updated, view.Balance, view.Equity, view.Positions, view.Floating, view.NoSl, view.Today, view.Drawdown);
            }
            if (!showingGuides && grid.SelectedRows.Count > 0) ShowDetails();
            }
            finally { applyingRows = false; }
        }
        void ShowGuides()
        {
            showingGuides = true;
            detail.Text = instructions.Count == 0 ? Lang.T("پس از آماده‌سازی، راهنمای اتصال گزارش‌خوان اینجا نمایش داده می‌شود.", "Prepare reporters to see attachment instructions here.")
                : string.Join("\r\n\r\n", instructions.Select(p => p.Key + "\r\n" + p.Value));
        }
        void ShowDetails()
        {
            if (grid.SelectedRows.Count == 0) return;
            var view = grid.SelectedRows[0].Tag as LiveMonitorView; if (view == null) return;
            string guide; instructions.TryGetValue(view.CopyName, out guide);
            string text = view.Name + " · " + view.Login + " · " + view.State + "\r\n" + view.Detail + (string.IsNullOrEmpty(guide) ? "" : "\r\n\r\n" + guide);
            if (detail.Text != text) detail.Text = text;
        }
        void CopySummary()
        {
            var views = enabled.Checked ? controller.Snapshot() : new List<LiveMonitorView>();
            if (views.Count == 0) { status.Text = Lang.T("دادهٔ زنده‌ای برای کپی موجود نیست.", "There is no live summary to copy."); return; }
            string text = "MetaFactory · " + Lang.T("پایش زنده", "Live monitoring") + " · " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + "\r\n"
                + string.Join("\r\n", views.Select(v => v.Name + " | " + v.Login + " | " + v.Platform + " | " + v.State + " | " + v.Updated
                    + " | " + Lang.T("بالانس ", "Balance ") + v.Balance + " | " + Lang.T("اکوییتی ", "Equity ") + v.Equity + " | " + Lang.T("باز ", "Open ") + v.Positions + " | " + Lang.T("شناور+سواپ ", "Floating+swap ") + v.Floating + " | " + Lang.T("بدون SL ", "No SL ") + v.NoSl
                    + " | " + Lang.T("تحقق‌یافتهٔ امروز ", "Realized today ") + v.Today + " | " + Lang.T("افت بالانس ", "Balance DD ") + v.Drawdown + " | " + v.History));
            try { Clipboard.SetText(text); status.Text = Lang.T("خلاصهٔ زنده کپی شد؛ این متن گزارش دستی نیست.", "Live summary copied; this is separate from the manual report."); }
            catch { status.Text = Lang.T("کپی در کلیپ‌بورد انجام نشد.", "Could not copy to the clipboard."); }
        }
    }
}
