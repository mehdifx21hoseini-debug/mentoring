using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;

namespace MTManager
{
    static partial class Tests
    {
        static AccountJournal LiveAccuracyHistory(DateTime serverNow)
        {
            var j = new AccountJournal { Platform = "MT5", Login = "12345", Server = "Synthetic-Demo", Currency = "USD", Complete = true,
                From = serverNow.Date.AddDays(-7), Exported = serverNow, GmtOffset = 7200, RequestToken = new string('a', 32), ScriptVersion = "1.28", FloatingBars = AccountJournal.TradesOnly };
            ProveDdCurve(j, DdEvent(1, serverNow.AddDays(-8), 2, 1000), DdEvent(2, serverNow.AddMinutes(-3), 0, -100));
            j.Trades.Add(new JournalTrade { Ticket = 2, Symbol = "SYNTH", Open = serverNow.AddHours(-2), Close = serverNow.AddMinutes(-3), Profit = -90, Swap = -4, Commission = -6, Volume = 1 });
            j.Deals.Add(new JournalDeal { Ticket = 2, Position = 9, Type = 0, Entry = 1, Time = serverNow.AddMinutes(-3), Profit = -90, Swap = -4, Commission = -6, Symbol = "SYNTH", Volume = 1 });
            j.Equity = j.Balance + 48;
            return j;
        }
        static LiveFeedSnapshot LiveAccuracySample(AccountJournal j, DateTime utc, long sequence, long revision, LiveFeedStatus status, double profit, string run = "test-run")
        {
            var frame = new LiveFeedFrame { Token = new string('a', 32), Run = run, Sequence = sequence, Revision = revision, Heartbeat = utc,
                Platform = "MT5", Login = "12345", Server = "Synthetic-Demo", Currency = "USD", Connected = true, State = status == LiveFeedStatus.Live ? "ready" : "history-pending",
                Values = new[] { 900.0, 948.0, 20.0, 928.0, 0.0 } };
            // Current SL removed, original entry SL still present. Current no-SL warning must survive.
            frame.Positions.Add(new LivePosition(8, "SYNTH", true, 1, utc.AddHours(-1), new[] { 100.0, 0.0, 120.0, profit, -2.0, 90.0, 110.0, -3.0 }));
            return new LiveFeedSnapshot(status, "test", "MT5", "12345", "Synthetic-Demo", frame, j);
        }
        static void LiveAccuracyChecks()
        {
            foreach (Kind kind in new[] { Kind.MT4, Kind.MT5 })
            {
                string native = LiveReporter.SourceText(kind);
                Check(native.Contains("EventSetTimer(1)") && native.Contains("EventKillTimer()"), "live observer uses bounded one-second timer with cleanup for " + kind);
                Check(native.Contains("owner.lock") && native.Contains("FILE_READ|FILE_WRITE|FILE_BIN"), "live session owns an exclusive writer lock for " + kind);
                Check(!System.Text.RegularExpressions.Regex.IsMatch(native, @"\b(OrderSend|OrderSendAsync|OrderClose|OrderModify|PositionClose|Sleep|ChartApplyTemplate|TerminalClose)\s*\("), "live observer contains no trading, blocking sleep or terminal/template mutation call for " + kind);
                Check(native.Contains("LIVE\\t1\\t") && native.Contains("JC\\t1\\t") && native.Contains("FileMove("), "live native writes separate revision-bound full proof with atomic publication for " + kind);
                int proofGuard = native.IndexOf("!ValidateExport(", StringComparison.Ordinal);
                int publish = native.IndexOf("bool finished = Finish(", StringComparison.Ordinal);
                Check(proofGuard >= 0 && publish > proofGuard, "live full-history fingerprint is revalidated before publication for " + kind);
            }
            DateTime utc = new DateTime(2026, 11, 20, 9, 0, 0, DateTimeKind.Utc);
            AccountJournal journal = LiveAccuracyHistory(utc.AddHours(2));
            var cache = new LiveReportSummaryCache();
            LiveReportSummary first = cache.Update(LiveAccuracySample(journal, utc, 1, 1, LiveFeedStatus.Live, 50), utc);
            Check(first.TodayKnown && first.TodayClosedCount == 1 && Math.Abs(first.TodayClosedNet + 100) < 1e-9, "live closed result includes its fee and swap exactly once");
            Check(first.FloatingProfitSwap == 48 && first.PositionNetKnown && first.PositionNet == 45, "live profit plus swap is distinct from position net including allocated entry cost");
            Check(first.PositionCount == 1 && first.NoSlCount == 1, "live no-SL warning uses current protection even when entry had SL");
            Check(Math.Abs(first.AccountDdPct - 10) < 1e-9 && !string.IsNullOrEmpty(first.AccountDdBasis), "live DD uses proven entire realized curve, never current floating equity");
            LiveReportSummary later = cache.Update(LiveAccuracySample(journal, utc.AddSeconds(1), 2, 1, LiveFeedStatus.Live, 80), utc.AddSeconds(1));
            Check(later.FloatingProfitSwap == 78 && later.PositionNet == 75 && cache.HistoryCalculations == 1, "new pulse updates money without recomputing unchanged full history");
            LiveReportSummary dirty = cache.Update(LiveAccuracySample(null, utc.AddSeconds(2), 3, 1, LiveFeedStatus.HistoryPending, 80), utc.AddSeconds(2));
            Check(dirty.IsLive && dirty.FloatingProfitSwap == 78 && !dirty.PositionNetKnown && double.IsNaN(dirty.PositionNet), "pending history never treats cached MT5 commission as current known cost");
            Check(!dirty.TodayKnown && !dirty.HistoryReady && double.IsNaN(dirty.AccountDdPct), "same-balance dirty history never leaks prior ready DD or closed result");
            LiveReportSummary stopped = cache.Update(LiveAccuracySample(journal, utc, 4, 1, LiveFeedStatus.Stale, 80), utc.AddSeconds(12));
            Check(!stopped.IsLive && stopped.PositionCount == 0 && double.IsNaN(stopped.FloatingProfitSwap), "stale feed cannot expose old money as current");
            cache.Update(LiveAccuracySample(journal, utc, 5, 2, LiveFeedStatus.Live, 80), utc);
            Equal(2, cache.HistoryCalculations, "new baseline revision recomputes full DD once");
            cache.Update(LiveAccuracySample(journal, utc, 1, 2, LiveFeedStatus.Live, 80, "new-run"), utc);
            Equal(3, cache.HistoryCalculations, "restarted native run invalidates summary history cache");

            var unknownClock = LiveAccuracyHistory(utc.AddHours(2)); unknownClock.GmtOffset = null;
            LiveReportSummary unknown = new LiveReportSummaryCache().Update(LiveAccuracySample(unknownClock, utc, 1, 1, LiveFeedStatus.Live, 0), utc);
            Check(!unknown.TodayKnown && double.IsNaN(unknown.TodayClosedNet) && !double.IsNaN(unknown.AccountDdPct), "unknown broker clock hides today only, preserving proven overall DD");
            DateTime nearMidnight = new DateTime(2026, 11, 20, 21, 59, 59, DateTimeKind.Utc);
            var atMidnight = LiveAccuracyHistory(nearMidnight.AddHours(2)); var midnightCache = new LiveReportSummaryCache();
            Check(midnightCache.Update(LiveAccuracySample(atMidnight, nearMidnight, 1, 1, LiveFeedStatus.Live, 0), nearMidnight).TodayKnown, "live today uses broker day before midnight");
            LiveReportSummary nextDay = midnightCache.Update(LiveAccuracySample(atMidnight, nearMidnight.AddSeconds(2), 2, 1, LiveFeedStatus.Live, 0), nearMidnight.AddSeconds(2));
            Check(!nextDay.TodayKnown && double.IsNaN(nextDay.TodayClosedNet) && midnightCache.HistoryCalculations == 1, "broker midnight invalidates daily cache without falsely zeroing new day or rescanning DD");
            var clipped = LiveAccuracyHistory(utc.AddHours(2)); clipped.From = clipped.Exported.Date.AddHours(1);
            Check(!new LiveReportSummaryCache().Update(LiveAccuracySample(clipped, utc, 1, 1, LiveFeedStatus.Live, 0), utc).TodayKnown, "partial-day history cannot masquerade as complete today's result");

            var partial = LiveAccuracyHistory(utc.AddHours(2)); partial.Deals.Clear();
            DateTime today = partial.Exported.Date;
            ProveDdCurve(partial, DdEvent(1, today.AddDays(-5), 2, 1000), DdEvent(2, today.AddDays(-1).AddHours(10), 0, -50),
                DdEvent(3, today.AddHours(1), 1, 18), DdEvent(4, today.AddHours(2), 0, -3), DdEvent(5, today.AddHours(3), 1, -12), DdEvent(6, today.AddHours(4), 2, 500));
            partial.Deals.Add(new JournalDeal { Ticket = 2, Position = 7, Type = 0, Entry = 1, Time = today.AddDays(-1).AddHours(10), Profit = -50 });
            partial.Deals.Add(new JournalDeal { Ticket = 3, Position = 7, Type = 1, Entry = 1, Time = today.AddHours(1), Profit = 20, Commission = -2 });
            partial.Deals.Add(new JournalDeal { Ticket = 4, Position = 8, Type = 0, Entry = 0, Time = today.AddHours(2), Fee = -3 });
            partial.Deals.Add(new JournalDeal { Ticket = 5, Position = 8, Type = 1, Entry = 2, Time = today.AddHours(3), Profit = -10, Fee = -2 });
            partial.Deals.Add(new JournalDeal { Ticket = 6, Type = 2, Time = today.AddHours(4), Profit = 500 });
            LiveReportSummary realized = new LiveReportSummaryCache().Update(LiveAccuracySample(partial, utc, 1, 1, LiveFeedStatus.Live, 50), utc);
            Check(realized.TodayKnown && realized.TodayClosedCount == 2 && realized.TodayClosedNet == 3,
                "MT5 realized day counts partial/reversal exits and today's opening fees exactly, excluding old partial loss and deposit");
            partial.Deals.RemoveAt(1);
            Check(!new LiveReportSummaryCache().Update(LiveAccuracySample(partial, utc, 1, 1, LiveFeedStatus.Live, 50), utc).TodayKnown,
                "missing current-day deal cannot silently understate daily realized result despite valid full DD curve");

            // Reader roundtrip uses exactly the native fourteen-field O layout, including commission last.
            string directory = Dir("live-accuracy");
            string baseText = JournalFile.Write(journal).Replace("END\t", "Q\t" + new string('a', 32) + "\r\nLIVE\t1\t" + new string('a', 32) + "\ttest-run\t1\r\nEND\t");
            File.WriteAllText(Path.Combine(directory, "history-1.txt"), baseText, Encoding.Unicode);
            long epoch = (long)(utc - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
            string snapshot = "MLIVE\t1\tMT5\nQ\t" + new string('a', 32) + "\nR\ttest-run\t1\t" + epoch
                + "\nA\t12345\tSynthetic-Demo\tUSD\nS\t1\tready\nV\t900\t948\t20\t928\t0\nH\t1\t1\nO\t8\tSYNTH\t0\t1\t" + (epoch - 3600)
                + "\t100\t0\t120\t50\t-2\t90\t110\t-3\nEND\t1\n";
            File.WriteAllText(Path.Combine(directory, "snapshot.txt"), snapshot, Encoding.Unicode);
            var reader = new LiveFeedReader(Kind.MT5, "12345", "Synthetic-Demo", new string('a', 32), directory);
            LiveFeedSnapshot parsed = reader.Poll(utc);
            Check(parsed.IsLive && parsed.Positions.Count == 1 && parsed.Positions[0].SlEntry == 90 && parsed.Positions[0].Price == 110
                && parsed.Positions[0].Commission == -3 && parsed.Positions[0].Net == 45, "real native O14 roundtrip preserves entry stop, current price and commission fields");
            Check(parsed.History != null, "live accuracy baseline passes strict journal proof and revision matching");
            File.WriteAllText(Path.Combine(directory, "snapshot.txt"), snapshot.Replace("\ttest-run\t1\t", "\ttest-run\t2\t").Replace("\tready\n", "\thistory-pending\n"), Encoding.Unicode);
            LiveFeedSnapshot pending = reader.Poll(utc.AddSeconds(1));
            Check(pending.IsLive && pending.History == null, "zero-balance-change pending snapshot with old revision cannot return stale historical summary");
        }
    }
}
