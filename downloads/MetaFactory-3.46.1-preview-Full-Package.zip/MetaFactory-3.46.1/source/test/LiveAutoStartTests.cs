using System;
using System.Linq;
namespace MTManager { static partial class Tests {
static void LiveAutoStartChecks() {
 Equal("5",LiveAutoStart.FreePeriod(new[]{"symbol=EURUSD\nperiod=1\n<expert>OtherEA</expert>"},"EURUSD",new string('a',32)),"automatic observer chooses separate timeframe from existing EA chart");
 Equal("1",LiveAutoStart.FreePeriod(new[]{"symbol=EURUSD\nperiod=1\nMTManagerLive\n"+new string('a',32)},"EURUSD",new string('a',32)),"same account live chart can be reused");
 foreach (Kind kind in new[] { Kind.MT4, Kind.MT5 }) {
  var lines = LiveAutoStart.Lines(kind, @"MetaFactoryLive\version\MTManagerLive", "session.set", "EURUSD.m");
  Check(lines.Contains(@"Expert=MetaFactoryLive\version\MTManagerLive") && lines.Contains("ExpertParameters=session.set"), "automatic live startup binds independent EA and preset for " + kind);
  Check(lines.Contains("Symbol=EURUSD.m"), "automatic startup keeps broker symbol suffix for " + kind);
  Check(!lines.Any(x => x.StartsWith("Script=") || x.StartsWith("AllowLiveTrading=") || x.StartsWith("ExpertsTrades=") || x.StartsWith("ExpertsDllImport=")), "live auto startup does not change terminal trading/DLL permissions for " + kind);
  Check(kind != Kind.MT5 || lines.First()=="[StartUp]" && lines.Contains("ShutdownTerminal=0"), "MT5 live startup stays open");
 }
 Throws<ArgumentException>(() => LiveAutoStart.Lines(Kind.MT4,"EA\nExpert=bad","s.set","EURUSD"), "automatic EA setting rejects newline injection");
 Check(LiveAutoStart.Prepare(new Instance(),new Settings(),null).Count==0,"copies without stored account do not attempt live compilation");
}
}}
