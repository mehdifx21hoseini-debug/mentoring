"""Run actual MT4 clock/recovery bodies in C++ with synthetic terminal inputs.
Not a substitute for MetaEditor compilation or a real broker session.
"""
from pathlib import Path
import subprocess, tempfile

source=(Path(__file__).resolve().parents[1]/'report/MTManagerLive.mq4').read_text()
def function(signature):
    start=source.index(signature); brace=source.index('{',start); depth=1; end=brace+1
    while depth:
        depth += (source[end]=='{')-(source[end]=='}'); end+=1
    return source[start:end]

code=r'''
#include <string>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <stdexcept>
using string=std::string;using uint=uint32_t;using datetime=long;
uint tick=1000,clockTick=0;datetime utc=1795800000,quote=utc+7200,clockLastServer=0,clockServer=0;
long clockOffset=0;bool clockKnown=false;
uint GetTickCount(){return tick;}datetime TimeCurrent(){return quote;}datetime TimeGMT(){return utc;}
double MathRound(double x){return std::round(x);}double MathAbs(double x){return std::abs(x);}
string IntegerToString(long v){return std::to_string(v);}
'''
code+='\n'.join(function(s) for s in ['void SampleBrokerClock(', 'bool BrokerClockKnown()', 'string Offset()', 'datetime ServerNow()'])
code+=r'''
int checks=0;void check(bool ok,string why){if(!ok)throw std::runtime_error(why);++checks;std::cout<<"PASS "<<why<<"\n";}
void reset(){tick=1000;utc=1795800000;quote=utc+7200;clockLastServer=clockServer=clockTick=clockOffset=0;clockKnown=false;}
int main(){
 reset();quote-=3600*8;SampleBrokerClock();check(!BrokerClockKnown()&&Offset()=="","cold stale quote cannot manufacture a plausible timezone");
 tick+=1000;utc++;SampleBrokerClock();check(!BrokerClockKnown(),"unchanged quote remains uncalibrated");
 quote=utc+7200;SampleBrokerClock();check(BrokerClockKnown()&&Offset()=="7200","advancing server quote repairs unknown offset");
 check(ServerNow()==quote,"calibration preserves broker timestamp");
 tick+=10000;utc+=10;check(ServerNow()==quote+10&&Offset()=="7200","quiet market advances clock without drifting timezone");
 quote=utc+7200;SampleBrokerClock(true);check(BrokerClockKnown(),"actual tick explicitly calibrates a fresh quote");
 reset();quote=utc+3600+901;SampleBrokerClock(true);check(!BrokerClockKnown(),"nonconforming server/UTC difference cannot certify a clock");
 reset();quote=utc+15*3600;SampleBrokerClock(true);check(!BrokerClockKnown(),"impossible timezone rejected");
 reset();SampleBrokerClock(true);utc+=600;check(!BrokerClockKnown(),"system UTC jump invalidates old calibration");
 quote=utc+7200;SampleBrokerClock(true);check(BrokerClockKnown(),"fresh broker tick restores calibration after clock jump");
 reset();tick=UINT32_MAX-2000;SampleBrokerClock(true);tick+=5000;utc+=5;check(BrokerClockKnown()&&ServerNow()==quote+5,"monotonic projection handles tick counter wrap");
 reset();SampleBrokerClock(true);tick+=86400001;utc+=86400;check(!BrokerClockKnown(),"day-long absent quotes expire calibration instead of claiming perpetual accuracy");
 reset();quote=utc-12600;SampleBrokerClock(true);check(Offset()=="-12600","negative half-hour timezone preserved");
 std::cout<<"MT4 CLOCK MOCK PASS "<<checks<<"\n";
}
'''
with tempfile.TemporaryDirectory(prefix='mf-clock-') as tmp:
    p=Path(tmp);(p/'test.cpp').write_text(code)
    subprocess.run(['g++','-std=c++17','-Wall','-Wextra',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
    subprocess.run([str(p/'test')],check=True)

# Extend the native recovery harness with a timezone-only change. Financial proof
# and trade counts stay unchanged, but a new report must be published once stable.
harness=(Path(__file__).parent/'LiveHistoryRecoveryNative.py').read_text()
harness=harness.replace('string Offset(){return "";}', 'string brokerOffset="";string Offset(){return brokerOffset;}')
harness=harness.replace(' std::cout<<"NATIVE RECOVERY MOCK PASS', '''
 reset();brokerOffset="";PollHistory();tick=4000;PollHistory();check(revision==1,"unknown-offset financial history still requires independent proof");
 brokerOffset="7200";tick=6000;PollHistory();check(revision==1&&dirty,"timezone-only recovery invalidates old metadata");
 tick=8000;PollHistory();check(revision==2&&exports==2&&!dirty,"fresh timezone republishes unchanged financial history");
 tick=10000;PollHistory();check(revision==2&&exports==2,"stable timezone avoids redundant full exports");
 previousDay="2026.11.28";tick=12000;PollHistory();tick=14000;PollHistory();check(revision==3&&exports==3,"broker-day rollover republishes verified history even without trades");
 std::cout<<"NATIVE RECOVERY MOCK PASS''')
exec(compile(harness,str(Path(__file__).parent/'LiveHistoryRecoveryNative.py'),'exec'),{'__file__':str(Path(__file__).parent/'LiveHistoryRecoveryNative.py')})
