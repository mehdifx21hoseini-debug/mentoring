MetaFactory Update Check 1.0
Extract the ZIP into a folder. Double-click START.cmd as the normal Windows user (do not choose Run as administrator).
A MetaFactory-Update-Check-*.txt file is saved on the Desktop. Send it to the assistant.
This is an evidence collector, NOT an automatic UAC approver. It does not launch or close MetaTrader, change UAC or compatibility/ACL settings, install a task/service, or read account passwords/start configurations.
It reads signatures, PE manifest execution level, file permissions/compatibility, drive E filesystem and recent updater paths for E:\MetaTrader\MT5-03 and MT5-05. It creates/deletes one empty unique write-test file in each target folder. Signature verification may consult Windows certificate trust services.
Windows PowerShell 5.1 is required (included in Windows10). The command wrapper's execution policy override applies only to that PowerShell process; it does not change the machine's saved policy.
Inspect the .ps1 source before running if desired. It contains no elevation command or external download/upload.
If a cache updater is missing, run again while its update prompt is present if you can switch to this normal-desktop tool; do not close healthy accounts solely to trigger a prompt. Existing file metadata still helps.
