# MetaFactory Update Check 1.0 -- no elevation, no updater execution, no settings changes.
$ErrorActionPreference = 'Stop'
$mfOutput = New-Object System.Collections.Generic.List[string]
function Mf-Line([string]$value) { $mfOutput.Add($value) }
function Mf-Try([string]$label, [scriptblock]$action) {
    try { & $action } catch { Mf-Line ($label + ': unavailable (' + $_.Exception.GetType().Name + ')') }
}
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class MfManifest {
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern IntPtr LoadLibraryEx(string p, IntPtr f,uint flags);
 [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr FindResource(IntPtr m,IntPtr name,IntPtr type);
 [DllImport("kernel32.dll")] static extern IntPtr LoadResource(IntPtr m,IntPtr r);
 [DllImport("kernel32.dll")] static extern IntPtr LockResource(IntPtr r);
 [DllImport("kernel32.dll")] static extern uint SizeofResource(IntPtr m,IntPtr r);
 [DllImport("kernel32.dll")] static extern bool FreeLibrary(IntPtr m);
 public static string Read(string p) {
  IntPtr m=LoadLibraryEx(p,IntPtr.Zero,2); // AS_DATAFILE: never execute DLL/EXE initialization
  if(m==IntPtr.Zero)return "unavailable";
  try {for(int i=1;i<=3;i++) {
   IntPtr r=FindResource(m,new IntPtr(i),new IntPtr(24));if(r==IntPtr.Zero)continue;
   uint n=SizeofResource(m,r);if(n==0 || n>131072)return "invalid-size";
   IntPtr b=LockResource(LoadResource(m,r));if(b==IntPtr.Zero)return "unavailable";
   byte[] data=new byte[n];Marshal.Copy(b,data,0,(int)n);
   return n>1 && data[0]==255 && data[1]==254 ? Encoding.Unicode.GetString(data) : Encoding.UTF8.GetString(data);
  }return "absent";} finally {FreeLibrary(m);}
 }
}
'@
function Mf-File([string]$path) {
    Mf-Line ('File=' + $path)
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { Mf-Line 'present=False'; return }
    Mf-Try 'file evidence' {
        $item = Get-Item -LiteralPath $path
        Mf-Line ('size=' + $item.Length + '; last-write-UTC=' + $item.LastWriteTimeUtc.ToString('o'))
        Mf-Line ('description=' + $item.VersionInfo.FileDescription + '; version=' + $item.VersionInfo.FileVersion)
        Mf-Line ('sha256=' + (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash)
        $sig = Get-AuthenticodeSignature -LiteralPath $path
        Mf-Line ('signature-status=' + $sig.Status)
        if ($null -ne $sig.SignerCertificate) {
            Mf-Line ('signer=' + $sig.SignerCertificate.Subject)
            Mf-Line ('signer-thumbprint=' + $sig.SignerCertificate.Thumbprint)
        }
        $manifest = [MfManifest]::Read($path)
        $level = [regex]::Match($manifest, 'requestedExecutionLevel\s+[^>]*level\s*=\s*["'']([^"'']+)["'']')
        Mf-Line ('manifest-execution-level=' + $(if ($level.Success) { $level.Groups[1].Value } else { 'not-found' }))
        foreach ($hive in @('HKCU:','HKLM:')) {
            Mf-Try 'compatibility' {
                $reg = Get-Item -LiteralPath ($hive + '\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers')
                Mf-Line ($hive + ' compatibility=' + [string]$reg.GetValue($path,'none'))
            }
        }
        Mf-Try 'file access' {
            $acl = Get-Acl -LiteralPath $path
            Mf-Line ('owner=' + $acl.Owner + '; read-only=' + $item.IsReadOnly)
            foreach ($rule in $acl.Access) {
                Mf-Line ('acl=' + $rule.IdentityReference + '; rights=' + $rule.FileSystemRights + '; type=' + $rule.AccessControlType + '; inherited=' + $rule.IsInherited)
            }
        }
    }
}
Mf-Line 'MetaFactory Update Check 1.0'
Mf-Line ('UTC=' + [DateTime]::UtcNow.ToString('o'))
Mf-Line 'Only inspects MT5-03/05 and their own updater caches. Does not launch/stop MetaTrader, request admin rights, or change UAC/registry/ACLs. No passwords/configuration contents collected. Temporary empty write-test files are removed.'
Mf-Try 'Windows' {
    Mf-Line ('OS=' + [Environment]::OSVersion.VersionString + '; 64bit=' + [Environment]::Is64BitOperatingSystem)
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    Mf-Line ('running-elevated=' + $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))
}
Mf-Try 'drive E' {
    $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='E:'"
    Mf-Line ('E filesystem=' + $disk.FileSystem + '; free-GB=' + [Math]::Round($disk.FreeSpace/1073741824,2))
}
$mfCache = Join-Path $env:APPDATA 'MetaQuotes\Terminal'
$mfSeen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach ($name in @('MT5-03','MT5-05')) {
    $dir = Join-Path 'E:\MetaTrader' $name
    Mf-Line ('--- Target=' + $dir + ' ---')
    if (-not (Test-Path -LiteralPath $dir -PathType Container)) { Mf-Line 'target-missing'; continue }
    Mf-Try 'directory access' {
        $probe = Join-Path $dir ('mf-write-check-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        $stream = $null
        try {
            $stream = New-Object IO.FileStream($probe,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None,4096,[IO.FileOptions]::DeleteOnClose)
            Mf-Line 'directory-current-user-write=True'
        } finally { if ($null -ne $stream) { $stream.Dispose() }; if (Test-Path -LiteralPath $probe) { Remove-Item -LiteralPath $probe -Force } }
    }
    Mf-File (Join-Path $dir 'terminal64.exe')
    Mf-Try 'own journal updater paths' {
        $logs = @(Get-ChildItem -LiteralPath (Join-Path $dir 'logs') -Filter '*.log' -File | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 2)
        foreach ($log in $logs) {
            foreach ($line in (Get-Content -LiteralPath $log.FullName -Tail 350)) {
                if ($line -notmatch 'LiveUpdate|updateadmin|cannot load config') { continue }
                # Keep only time, phase and paths; never output arbitrary terminal log/config contents.
                $time = [regex]::Match($line,'\d\d:\d\d:\d\d\.\d\d\d').Value
                if ($line -match 'cannot load config') { Mf-Line ('journal=' + $log.Name + '; time=' + $time + '; startup-config-missing=True'); continue }
                $match = [regex]::Match($line,'"([^"\r\n]+\\liveupdate\\terminal64\.exe)"',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
                if (-not $match.Success) { continue }
                $path = [IO.Path]::GetFullPath($match.Groups[1].Value)
                if (-not $path.StartsWith($mfCache + '\',[StringComparison]::OrdinalIgnoreCase)) { continue }
                $relative = $path.Substring($mfCache.Length+1)
                if ($relative -notmatch '^[0-9a-fA-F]{32}\\liveupdate\\terminal64\.exe$') { continue }
                Mf-Line ('journal=' + $log.Name + '; time=' + $time + '; updateadmin=' + ($line -match '/updateadmin'))
                if ($mfSeen.Add($path)) { Mf-File $path }
            }
        }
    }
}
# Exact target from user's expanded UAC screenshot; cache can disappear after update.
$mfExact = Join-Path $mfCache 'C5357C285E6755F83E975D3FF5055739\liveupdate\terminal64.exe'
if ($mfSeen.Add($mfExact)) { Mf-File $mfExact }
$mfDesktop = [Environment]::GetFolderPath('DesktopDirectory')
$mfReport = Join-Path $mfDesktop ('MetaFactory-Update-Check-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt')
$mfOutput | Set-Content -LiteralPath $mfReport -Encoding UTF8
Write-Host ('Report saved: ' + $mfReport)
Write-Host 'Send this text report back. No update or UAC automation was performed.'
