@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Check-MetaFactory-Update.ps1"
echo.
pause
