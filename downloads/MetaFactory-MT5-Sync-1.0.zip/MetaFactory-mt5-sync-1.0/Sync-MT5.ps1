param([switch]$Apply,[string]$SourceDir='C:\Program Files\WM Markets MT5 Terminal',[string]$CopiesRoot='E:\MetaTrader')
$ErrorActionPreference='Stop'
$mfLines=New-Object System.Collections.Generic.List[string]
$mfDesktop=[Environment]::GetFolderPath('DesktopDirectory')
if (-not (Test-Path -LiteralPath $mfDesktop -PathType Container)) { $mfDesktop=$env:TEMP }
$mfReport=Join-Path $mfDesktop ('MetaFactory-MT5-Sync-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.txt')
function Mf-Log([string]$s) { $mfLines.Add($s); Write-Host $s; $mfLines | Set-Content -LiteralPath $mfReport -Encoding UTF8 }
function Mf-SafeDir([string]$dir) {
    $full=[IO.Path]::GetFullPath($dir)
    $item=Get-Item -LiteralPath $full
    while ($null -ne $item) { if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Junction/symbolic-link paths are not supported.' }; $item=$item.Parent }
    return $full.TrimEnd('\')
}
function Mf-Trusted([string]$path) {
    $sig=Get-AuthenticodeSignature -LiteralPath $path
    if ($sig.Status -ne 'Valid' -or $null -eq $sig.SignerCertificate -or $sig.SignerCertificate.Subject -notmatch '(^|,\s*)CN=MetaQuotes Ltd\.(,|$)') { throw ('Valid MetaQuotes signature required: '+$path) }
    $info=(Get-Item -LiteralPath $path).VersionInfo
    if ($info.FileMajorPart -ne 5) { throw ('Not an MT5 executable: '+$path) }
    return New-Object Version($info.FileMajorPart,$info.FileMinorPart,$info.FileBuildPart,$info.FilePrivatePart)
}
function Mf-Running([string]$exe) {
    foreach ($process in @(Get-CimInstance Win32_Process -Filter "Name='terminal64.exe'")) {
        if ([string]::IsNullOrEmpty($process.ExecutablePath)) { throw 'Cannot establish all MT5 process paths; replacement refused.' }
        if ([string]::Equals([IO.Path]::GetFullPath($process.ExecutablePath),$exe,[StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    return $false
}
$mfChanges=0
try {
    Mf-Log 'MetaFactory MT5 Sync 1.0 -- controlled single-copy maintenance trial'
    Mf-Log ('Mode='+$(if ($Apply) { 'APPLY' } else { 'PLAN ONLY' }))
    Mf-Log 'No updater execution, UAC/registry/ACL changes or account/config/EA/profile copying. Signed terminal64.exe only; existing originals backed up.'
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    $principal=New-Object Security.Principal.WindowsPrincipal($identity)
    if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run as the normal user, NOT administrator.' }
    $SourceDir=Mf-SafeDir $SourceDir
    $CopiesRoot=Mf-SafeDir $CopiesRoot
    $sourceExe=Join-Path $SourceDir 'terminal64.exe'
    if ((Get-Item -LiteralPath $sourceExe).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Source executable is a link.' }
    $sourceVersion=Mf-Trusted $sourceExe
    if (Mf-Running $sourceExe) { throw 'Close the source WM Markets MT5 after its official update completes.' }
    $sourceHash=(Get-FileHash -LiteralPath $sourceExe -Algorithm SHA256).Hash
    Mf-Log ('Source='+$sourceExe+'; version='+$sourceVersion+'; SHA256='+$sourceHash)
    $dirs=@(Get-ChildItem -LiteralPath $CopiesRoot -Directory | Where-Object { $_.Name -match '^MT5-[0-9]+$' } | Sort-Object Name)
    foreach ($dir in $dirs) {
        $temp=$null
        try {
            $targetDir=Mf-SafeDir $dir.FullName
            $target=Join-Path $targetDir 'terminal64.exe'
            if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { continue }
            if ([string]::Equals($sourceExe,$target,[StringComparison]::OrdinalIgnoreCase)) { continue }
            if (Mf-Running $target) { Mf-Log ($dir.Name+': SKIPPED running'); continue }
            if ((Get-Item -LiteralPath $target).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Target executable is a link.' }
            $version=Mf-Trusted $target
            if ($sourceVersion -le $version) { Mf-Log ($dir.Name+': SKIPPED source is not newer ('+$version+')'); continue }
            $oldHash=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
            Mf-Log ($dir.Name+': newer signed source available '+$version+' -> '+$sourceVersion)
            if (-not $Apply) { continue }
            # First-trial cap: at most ONE executable changed per invocation.
            if ($mfChanges -ge 1) { Mf-Log ($dir.Name+': SKIPPED one-copy trial limit'); continue }
            $temp=Join-Path $targetDir ('terminal64.mfsync-'+[Guid]::NewGuid().ToString('N')+'.exe')
            Copy-Item -LiteralPath $sourceExe -Destination $temp
            $copiedVersion=Mf-Trusted $temp
            if ($copiedVersion -ne $sourceVersion -or (Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash -ne $sourceHash) { throw 'Source changed during copy; refused.' }
            if (Mf-Running $target) { throw 'Terminal started during preparation; refused.' }
            if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $oldHash) { throw 'Target changed during preparation; refused.' }
            $backup=Join-Path $targetDir ('terminal64.before-sync-'+[Guid]::NewGuid().ToString('N')+'.bak')
            [IO.File]::Replace($temp,$target,$backup,$false)
            $temp=$null
            $mfChanges++
            Mf-Log ($dir.Name+': UPDATED; original-backup='+$backup)
        } catch { Mf-Log ($dir.Name+': SKIPPED/FAILED: '+$_.Exception.Message) }
        finally { if ($null -ne $temp -and (Test-Path -LiteralPath $temp)) { Remove-Item -LiteralPath $temp -Force } }
    }
    Mf-Log ('Finished; changed-copies='+$mfChanges)
    if ($mfChanges -eq 0) { Mf-Log 'No update applied. A strictly newer source and a closed target are required. This does NOT mean UAC is solved.' }
} catch { Mf-Log ('STOPPED: '+$_.Exception.Message); exit 1 }
Mf-Log ('Report='+$mfReport)
