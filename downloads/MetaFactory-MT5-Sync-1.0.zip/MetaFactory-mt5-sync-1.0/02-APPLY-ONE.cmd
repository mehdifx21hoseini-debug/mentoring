@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Sync-MT5.ps1" -Apply
echo.
pause
