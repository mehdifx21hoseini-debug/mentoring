MetaFactory MT5 Sync 1.0 -- one-copy maintenance TRIAL, not an automatic UAC approver.

Goal: update ONE main installed WM Markets MT5 through its official updater, then use ordinary-user file copying to prepare a CLOSED portable copy before launch. No elevated task/service and no global UAC changes. This does NOT guarantee removal of all future vendor update prompts.

Source defaults to C:\Program Files\WM Markets MT5 Terminal; targets E:\MetaTrader\MT5-[digits]. The supplied reports show build6295 in both. If the source is still6295, NOTHING WILL CHANGE. Update the official main terminal first; that may need one manual Yes. Close it after completion. Do not copy data from an old or unknown terminal.

Extract ALL files. Run01-PLAN.cmd as normal user (NOT administrator). It only reads signatures/versions/process paths and writes a Desktop report. Send MetaFactory-MT5-Sync-*.txt to the assistant. It does not close terminals. Running portable copies are skipped.

02-APPLY-ONE.cmd is included for a subsequent controlled trial after a newer signed source is confirmed. It repeats all checks, changes at most ONE closed copy per invocation and keeps an original backup. It does not run any executable, touch configuration/account/profile/EA files, clear vendor caches, or update other package components. It copies onlyterminal64.exe. Complete compatibility with a newer vendor package is NOT guaranteed: verify a single copy's login/live report before broader use.

Safety boundaries: source+target valid Authenticode MetaQuotes Ltd. signatures/major5; strictly newer source (same-version/different-architecture skipped); reject links/junctions; never kill processes; refuse if process paths cannot be established; copy to unique temp, recheck signature/hash/version, recheck target closed and unchanged, atomic File.Replace with original backup, no delete-then-copy fallback. A race with an externally launched terminal remains possible; close MetaFactory during the later APPLY trial to avoid user launches. No administrator elevation requested; elevated execution refused.

Rollback: close that MT5. Rename currentterminal64.exe toterminal64.after-sync.exe, COPY the matchingterminal64.before-sync-*.bak back asterminal64.exe. Keep backup. Do not delete/rename MQL5/config/account files.

WindowsPowerShell5.1 required. ExecutionPolicy override applies only to the one process. Actual Windows MT5 update compatibility has not been tested here. PLAN is the immediate next step; APPLY is not an established fix for UAC.
