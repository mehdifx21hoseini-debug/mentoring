using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace MTManager
{
    static class TerminalWindow
    {
        [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr window, int command);
        [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr window);
        [DllImport("user32.dll")] static extern bool IsIconic(IntPtr window);

        /// <summary>Brings a running terminal's window forward (restored if minimized). False when it has no window.</summary>
        public static bool Bring(Process p)
        {
            try
            {
                IntPtr w = p.MainWindowHandle;
                if (w == IntPtr.Zero) return false;
                if (IsIconic(w)) ShowWindow(w, 9);
                SetForegroundWindow(w);
                return true;
            }
            catch { return false; }
        }
    }

    /// <summary>A new student in one step: a lean copy of an installed MetaTrader and the investor account.</summary>
    sealed class StudentDialog : FormDialog
    {
        // 3.26 (CHANGE-009, approved): MT5/MT4 as a small two-way choice with the account number beside it, an eye inside the password
        // box, the copies' folder as one line («تغییر» opens the same folder field), and a shorter note. Every field is still there.
        readonly Segmented kinds = new Segmented("MetaTrader 5", "MetaTrader 4");
        readonly TextBox name = new TextBox { Width = Theme.S(420) };
        readonly TextBox login = new TextBox { Width = Theme.S(150), RightToLeft = RightToLeft.No };
        readonly ServerPicker server;
        readonly PasswordBox investor = new PasswordBox(420);
        readonly FolderField folder;
        readonly Label at;
        public string StudentName, Login, Server, Investor, Folder;
        public Kind Kind { get { return kinds.Selected == 1 ? Kind.MT4 : Kind.MT5; } }

        public StudentDialog(AccountStore store, Settings settings)
            : base(Lang.T("افزودن دانشجو", "Add student"), Lang.T("یک نسخه‌ی سبک متاتریدر برای این دانشجو ساخته می‌شود و با رمز اینوستور (فقط مشاهده) وارد می‌شود.", "A light MetaTrader copy is made for this student and signs in with the investor password (view only)."))
        {
            server = new ServerPicker(settings, store, 420);
            folder = new FolderField(settings, 300) { Visible = false };
            server.Load(Kind.MT5);
            kinds.Changed += (s, e) => server.Load(Kind);
            var kindRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = Padding.Empty };
            kinds.Margin = Theme.Pad(0, 3, 0, 0);
            kindRow.Controls.Add(kinds);
            Label loginLabel = Theme.Label(Lang.T("شماره حساب", "Account"));
            loginLabel.Margin = Theme.Pad(18, 9, 10, 0);
            kindRow.Controls.Add(loginLabel);
            kindRow.Controls.Add(login);
            // The folder: one muted line; «تغییر» puts the folder field in its place.
            var where = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false, Margin = Padding.Empty };
            var line = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = Padding.Empty };
            at = Theme.Label(Lang.T("ساخته می‌شود در ", "Created in ") + folder.Value, 0, Theme.Small, Theme.Muted);
            at.AutoSize = false;
            at.AutoEllipsis = true;
            at.Size = new Size(Math.Min(Theme.S(360), TextRenderer.MeasureText(at.Text, Theme.Small).Width + Theme.S(4)), Theme.S(22));
            at.Margin = Padding.Empty;
            line.Controls.Add(at);
            LinkLabel change = Art.Link(Lang.T("· تغییر", "· Change"));
            change.Font = Theme.Small;
            change.Margin = Theme.Pad(4, 2, 0, 0);
            change.LinkClicked += (s, e) => { line.Visible = false; folder.Visible = true; folder.Box.Box.Focus(); };
            line.Controls.Add(change);
            where.Controls.Add(line);
            where.Controls.Add(folder);
            Row(Lang.T("نام دانشجو", "Student name"), name);
            Row(Lang.T("متاتریدر", "MetaTrader"), kindRow);
            Row(Lang.T("سرور", "Server"), server);
            Row(Lang.T("رمز اینوستور", "Investor password"), investor);
            Row("", where);
            var note = new NoteBox(Lang.T("فهرست سرورها از MetaQuotes گرفته می‌شود و چیزی از شما فرستاده نمی‌شود. رمز رمزگذاری‌شده و فقط روی همین کامپیوتر می‌ماند.", "The server list comes from MetaQuotes; nothing of yours is sent. The password is stored encrypted, only on this computer."), 540)
                { Margin = Theme.Pad(0, 8, 0, 0) };
            Wide(note);
            Button ok = AddButton(Lang.T("افزودن و اتصال", "Add and connect"), Save, true);
            Button cancel = AddButton(Lang.T("انصراف", "Cancel"), (s, e) => Close(DialogResult.Cancel));
            Finish();
            AcceptButton = ok;
            CancelButton = cancel;
        }

#if SNAPSHOT
        public void Preview(string typed)
        {
            name.Text = "علی رضایی";
            login.Text = "51234567";
            investor.Value = "secret";
            // A Windows folder in the picture, not the build machine's.
            at.Text = Lang.T(@"ساخته می‌شود در D:\MetaTrader", @"Created in D:\MetaTrader");
            at.Width = TextRenderer.MeasureText(at.Text, Theme.Small).Width + Theme.S(4);
            server.Server = typed ?? "WMMarkets-Real1";
            // The server list open, as when the box is clicked (null: closed).
            if (typed != null) Shown += (s, e) => { server.Box.Focus(); server.Open(); };
        }
#endif

        void Save(object sender, EventArgs e)
        {
            string number = TextUtil.LatinDigits(login.Text.Trim());
            if (name.Text.Trim().Length == 0) { Ui.Message(this, Lang.T("نام دانشجو را وارد کنید.", "Enter the student's name."), MessageBoxIcon.Warning); return; }
            if (!System.Text.RegularExpressions.Regex.IsMatch(number, @"^[0-9]{1,20}$")) { Ui.Message(this, Lang.T("شماره حساب باید فقط عدد باشد.", "The account number must be digits only."), MessageBoxIcon.Warning); return; }
            if (server.Server.Length == 0) { Ui.Message(this, Lang.T("سرور را انتخاب کنید؛ نام بروکر را بنویسید و سرور حساب را از فهرست بزنید.", "Choose the server: type the broker's name and pick the account's server from the list."), MessageBoxIcon.Warning); server.Box.Focus(); return; }
            if (investor.Value.Length == 0) { Ui.Message(this, Lang.T("رمز اینوستور را وارد کنید.", "Enter the investor password."), MessageBoxIcon.Warning); return; }
            string problem = PasswordRule.Problem(investor.Value);
            if (problem != null) { Ui.Message(this, Lang.T("رمز اینوستور: ", "Investor password: ") + problem, MessageBoxIcon.Warning); investor.Box.Focus(); return; }
            try { Folder = CopyMaker.CheckFolder(folder.Value); }
            catch (Exception ex) { Ui.Error(this, ex); return; }
            StudentName = TextUtil.OneLine(name.Text);
            Login = number;
            Server = TextUtil.OneLine(server.Server);
            Investor = investor.Value;
            Close(DialogResult.OK);
        }
    }
}
