using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using Microsoft.Win32;

namespace MTManager
{
    /// <summary>Where the program lives and what Windows shows for it (Start menu, desktop, Settings > Apps).
    /// Shared by the setup and by the program itself, which also removes it.</summary>
    public static class Installation
    {
        public const string AppName = "MetaFactory";
        /// <summary>The name before 3.22: its shortcuts and Start menu folder are removed when the new ones are made.</summary>
        public const string OldAppName = "مدیر متاتریدر";
        public const string ExeName = "MTManager.exe";
        public const string GuideName = "Guide-fa.txt";
        /// <summary>3.27: the guide in English, beside the Persian one.</summary>
        public const string GuideEnName = "Guide-en.txt";
        public const string FontLicenseName = "Vazirmatn-OFL.txt";
        const string UninstallKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\MTManager";
        const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";

        public static string DefaultDir
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "MT Manager"); }
        }

        static RegistryKey Open(bool write = false)
        {
            try { return Registry.CurrentUser.OpenSubKey(UninstallKey, write); } catch { return null; }
        }

        /// <summary>The folder of the installed program: the earlier setup let people choose it.</summary>
        public static string Dir()
        {
            using (RegistryKey k = Open())
            {
                string dir = k == null ? null : k.GetValue("InstallLocation") as string;
                if (!string.IsNullOrEmpty(dir))
                {
                    dir = dir.Trim().Trim('"');
                    if (Directory.Exists(dir)) return dir;
                }
            }
            return DefaultDir;
        }

        /// <summary>The installed version, or null when the program is not installed.</summary>
        public static string InstalledVersion()
        {
            using (RegistryKey k = Open())
                return k == null ? null : k.GetValue("DisplayVersion") as string;
        }

        public static string DesktopLink
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), AppName + ".lnk"); }
        }

        public static string MenuDir
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), AppName); }
        }

        static string[] MenuLinks
        {
            get { return new[] { AppName + ".lnk", "راهنما.lnk", "عیب‌یابی " + AppName + ".lnk", "حذف " + AppName + ".lnk" }; }
        }

        /// <summary>Start menu entries, and the desktop one if wanted. Problems are returned, not thrown: the program works without them.</summary>
        public static List<string> CreateShortcuts(string dir, bool desktop)
        {
            var problems = new List<string>();
            string exe = Path.Combine(dir, ExeName);
            Action<string, Action> attempt = (what, a) =>
            {
                try { a(); }
                catch (Exception e) { problems.Add(what + ": " + e.Message); Log.Write("shortcut " + what + ": " + e); }
            };
            attempt("old name", () =>
            {
                // 3.22: the program was called «مدیر متاتریدر»: its desktop shortcut and Start menu folder go, the new ones take their place.
                DeleteQuietly(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), OldAppName + ".lnk"));
                string oldMenu = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), OldAppName);
                foreach (string name in new[] { OldAppName + ".lnk", "راهنما.lnk", "عیب‌یابی " + OldAppName + ".lnk", "حذف " + OldAppName + ".lnk" })
                    DeleteQuietly(Path.Combine(oldMenu, name));
                if (Directory.Exists(oldMenu) && !Directory.EnumerateFileSystemEntries(oldMenu).Any()) Directory.Delete(oldMenu);
            });
            attempt("menu", () =>
            {
                Directory.CreateDirectory(MenuDir);
                // The earlier setup's uninstaller entry: removing now goes through Windows Settings or the program itself.
                DeleteQuietly(Path.Combine(MenuDir, "حذف " + AppName + ".lnk"));
                Shortcut.Create(Path.Combine(MenuDir, AppName + ".lnk"), exe, "", dir, "ساخت و اجرای نسخه‌های مستقل MT4 و MT5");
                Shortcut.Create(Path.Combine(MenuDir, "راهنما.lnk"), Path.Combine(dir, GuideName), "", dir, "راهنمای کوتاه " + AppName);
                Shortcut.Create(Path.Combine(MenuDir, "عیب‌یابی " + AppName + ".lnk"), exe, "--diagnose", dir, "گزارش بررسی سیستم روی دسکتاپ");
            });
            attempt("desktop", () =>
            {
                if (desktop) Shortcut.Create(DesktopLink, exe, "", dir, "ساخت و اجرای نسخه‌های مستقل MT4 و MT5");
                else DeleteQuietly(DesktopLink);
            });
            // 3.22.3: Windows keeps the icons it has drawn; told that they changed, it draws the new logo now instead of after a restart.
            attempt("icons", () => SHChangeNotify(0x08000000 /* SHCNE_ASSOCCHANGED */, 0 /* SHCNF_IDLIST */, IntPtr.Zero, IntPtr.Zero));
            return problems;
        }

        [DllImport("shell32.dll")]
        static extern void SHChangeNotify(int eventId, uint flags, IntPtr item1, IntPtr item2);

        public static void RemoveShortcuts()
        {
            DeleteQuietly(DesktopLink);
            DeleteQuietly(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), OldAppName + ".lnk"));
            foreach (string name in MenuLinks) DeleteQuietly(Path.Combine(MenuDir, name));
            try { if (Directory.Exists(MenuDir) && !Directory.EnumerateFileSystemEntries(MenuDir).Any()) Directory.Delete(MenuDir); } catch { }
        }

        public static void Register(string dir)
        {
            string exe = Path.Combine(dir, ExeName);
            long bytes = 0;
            foreach (string f in new[] { ExeName, GuideName, GuideEnName, FontLicenseName })
                try { bytes += new FileInfo(Path.Combine(dir, f)).Length; } catch { }
            using (RegistryKey k = Registry.CurrentUser.CreateSubKey(UninstallKey))
            {
                k.SetValue("DisplayName", AppName);
                k.SetValue("DisplayVersion", AppInfo.Version);
                k.SetValue("Publisher", "MetaFactory");
                k.SetValue("DisplayIcon", exe + ",0");
                k.SetValue("InstallLocation", dir);
                k.SetValue("UninstallString", "\"" + exe + "\" --uninstall");
                k.SetValue("InstallDate", DateTime.Now.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
                k.SetValue("EstimatedSize", (int)Math.Max(1, bytes / 1024), RegistryValueKind.DWord);
                k.SetValue("NoModify", 1, RegistryValueKind.DWord);
                k.SetValue("NoRepair", 1, RegistryValueKind.DWord);
            }
        }

        public static void Unregister()
        {
            try { Registry.CurrentUser.DeleteSubKeyTree(UninstallKey, false); } catch (Exception e) { Log.Write("unregister: " + e.Message); }
            try
            {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(RunKey, true))
                    if (k != null && k.GetValue("MTManager") != null) k.DeleteValue("MTManager", false);
            }
            catch (Exception e) { Log.Write("run key: " + e.Message); }
        }

        /// <summary>The program's own files in its folder (never anything else that may be there).</summary>
        public static string[] OwnFiles(string dir)
        {
            return new[] { ExeName, GuideName, GuideEnName, FontLicenseName, "Uninstall.exe", ExeName + ".old", ExeName + ".new" }.Select(f => Path.Combine(dir, f)).ToArray();
        }

        /// <summary>Other running copies of this program from the given folder.</summary>
        public static List<Process> Running(string dir)
        {
            var list = new List<Process>();
            int me = Process.GetCurrentProcess().Id;
            string exe = Path.GetFullPath(Path.Combine(dir, ExeName));
            foreach (Process p in Process.GetProcessesByName(Path.GetFileNameWithoutExtension(ExeName)))
            {
                if (p.Id == me) continue;
                string path = Processes.PathOf(p);
                if (path != null && string.Equals(Path.GetFullPath(path), exe, StringComparison.OrdinalIgnoreCase)) list.Add(p);
            }
            return list;
        }

        /// <summary>Asks each to close (it saves and cleans up), then ends the ones that do not.</summary>
        public static void Close(List<Process> list, Action wait)
        {
            foreach (Process p in list) try { p.CloseMainWindow(); } catch { }
            DateTime until = DateTime.Now.AddSeconds(10);
            while (DateTime.Now < until && list.Any(p => { try { return !p.HasExited; } catch { return false; } }))
            {
                wait();
                System.Threading.Thread.Sleep(100);
            }
            foreach (Process p in list)
            {
                try { if (!p.HasExited) { p.Kill(); p.WaitForExit(3000); } }
                catch (Exception e) { Log.Write("end " + p.Id + ": " + e.Message); }
            }
        }

        /// <summary>The running program cannot delete itself: a hidden command removes its files a moment after it exits.</summary>
        public static void RemoveFilesAfterExit(string dir)
        {
            var cmd = new StringBuilder("/c ping 127.0.0.1 -n 4 >nul");
            foreach (string f in OwnFiles(dir)) cmd.Append(" & del /f /q \"" + f + "\"");
            cmd.Append(" & del /f /q \"" + Path.Combine(dir, ExeName) + ".old*\"");  // renamed by an update while running
            cmd.Append(" & rmdir \"" + dir + "\"");
            Process.Start(new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, "cmd.exe"), cmd.ToString())
            {
                CreateNoWindow = true, UseShellExecute = false, WindowStyle = ProcessWindowStyle.Hidden, WorkingDirectory = Path.GetTempPath(),
            });
        }

        static void DeleteQuietly(string path)
        {
            try { if (File.Exists(path)) File.Delete(path); } catch (Exception e) { Log.Write("delete " + path + ": " + e.Message); }
        }
    }

    /// <summary>Windows .lnk files, through the shell's own ShellLink object (with Windows Script Host as a second way).</summary>
    static class Shortcut
    {
        [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("000214F9-0000-0000-C000-000000000046")]
        interface IShellLinkW
        {
            void GetPath([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder file, int max, IntPtr findData, uint flags);
            void GetIDList(out IntPtr idList);
            void SetIDList(IntPtr idList);
            void GetDescription([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder name, int max);
            void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string name);
            void GetWorkingDirectory([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder dir, int max);
            void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string dir);
            void GetArguments([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder args, int max);
            void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string args);
            void GetHotkey(out short hotkey);
            void SetHotkey(short hotkey);
            void GetShowCmd(out int showCmd);
            void SetShowCmd(int showCmd);
            void GetIconLocation([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder path, int max, out int index);
            void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string path, int index);
            void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string path, uint reserved);
            void Resolve(IntPtr window, uint flags);
            void SetPath([MarshalAs(UnmanagedType.LPWStr)] string file);
        }

        public static void Create(string link, string target, string args, string workDir, string description)
        {
            try
            {
                // Created inside the try, so any failure falls back to Windows Script Host below.
                var shell = (IShellLinkW)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("00021401-0000-0000-C000-000000000046"), true));
                try
                {
                    shell.SetPath(target);
                    shell.SetArguments(args ?? "");
                    shell.SetWorkingDirectory(workDir);
                    shell.SetDescription(description ?? "");
                    if (target.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) shell.SetIconLocation(target, 0);
                    ((IPersistFile)shell).Save(link, true);
                }
                finally { Marshal.ReleaseComObject(shell); }
            }
            catch (Exception first)
            {
                Log.Write("shell link (" + Path.GetFileName(link) + "): " + first.Message + "; trying Windows Script Host");
                CreateWithScriptHost(link, target, args, workDir, description);
            }
        }

        static void CreateWithScriptHost(string link, string target, string args, string workDir, string description)
        {
            Type type = Type.GetTypeFromProgID("WScript.Shell", true);
            object shell = Activator.CreateInstance(type);
            try
            {
                object lnk = type.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { link });
                Type t = lnk.GetType();
                t.InvokeMember("TargetPath", BindingFlags.SetProperty, null, lnk, new object[] { target });
                t.InvokeMember("Arguments", BindingFlags.SetProperty, null, lnk, new object[] { args ?? "" });
                t.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, lnk, new object[] { workDir });
                t.InvokeMember("Description", BindingFlags.SetProperty, null, lnk, new object[] { description ?? "" });
                if (target.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
                    t.InvokeMember("IconLocation", BindingFlags.SetProperty, null, lnk, new object[] { target + ",0" });
                t.InvokeMember("Save", BindingFlags.InvokeMethod, null, lnk, null);
                Marshal.ReleaseComObject(lnk);
            }
            finally { Marshal.ReleaseComObject(shell); }
        }
    }
}
