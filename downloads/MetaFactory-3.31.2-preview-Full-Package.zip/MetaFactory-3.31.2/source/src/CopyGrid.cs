using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace MTManager
{
    /// <summary>3.21: Active and Inactive are the student's trading (a trade within 14 trading days or not), shown while closed.</summary>
    public enum RowState { Off, On, Open, Pending, Warn, Bad, Active, Inactive }

    /// <summary>What one row of the list shows: the copy, its account and whether its MetaTrader is open and logged in.</summary>
    sealed class CopyRow
    {
        public string Name = "", Kind = "", Trader = "", Login = "", Server = "", Status = "";
        public RowState State;
        public bool HasAccount, Running;
        /// <summary>3.21: whether the student still trades (for the tabs and the counts; also while MetaTrader is open).</summary>
        public Activity Activity;
        /// <summary>Ticked in the list's first column: the group that "run" and "close" act on.</summary>
        public bool Checked;
        /// <summary>The names of the folders the copy is in (it can be in several).</summary>
        public string[] Folders = new string[0];
        /// <summary>3.21, the «امروز» column: the day in a few words ("3 trades · +$38.20 · 1 No SL"), with the money's sign
        /// (TodayTone), whether a trade had no Stop Loss, and under it when it was read; or that it is being read, was not read,
        /// or could not be.</summary>
        public string TodayText = "", TodayAgo = "";
        /// <summary>3.26 (CHANGE-003): the whole message behind a shortened «امروز» text, for its tip; empty when there is none.</summary>
        public string TodayTip = "";
        public int TodayTone;
        public bool TodayNoSl, TodayBusy, TodayFailed, TodayNone;
        /// <summary>The report is open under this row.</summary>
        public bool Expanded;

        public string Key
        {
            get
            {
                return string.Join("\u0001", new[] { Name, Kind, Trader, Login, Server, Status, State.ToString(), HasAccount ? "1" : "0", Running ? "1" : "0", Checked ? "1" : "0",
                                                     string.Join("\u0002", Folders), TodayText, TodayTip, TodayAgo, TodayTone.ToString(), TodayNoSl ? "1" : "0", TodayBusy ? "1" : "0",
                                                     TodayFailed ? "1" : "0", TodayNone ? "1" : "0", Expanded ? "1" : "0" });
            }
        }
    }

    enum RowPart { None, Open, More, Check, Name }

    /// <summary>The ticked copies of the list, by name. They stay ticked while the view or the search changes.</summary>
    sealed class Ticked
    {
        readonly HashSet<string> names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        public int Count { get { return names.Count; } }

        public bool Has(string name) { return names.Contains(name); }

        public void Toggle(string name) { if (!names.Remove(name)) names.Add(name); }

        public void Clear() { names.Clear(); }

        /// <summary>The header's box: when all the rows shown are ticked it unticks them, otherwise it ticks them all.</summary>
        public void ToggleAll(IEnumerable<string> shown)
        {
            List<string> list = shown.ToList();
            if (list.Count > 0 && list.All(names.Contains)) foreach (string n in list) names.Remove(n);
            else foreach (string n in list) names.Add(n);
        }

        /// <summary>Copies that are gone (removed) leave the choice.</summary>
        public void Keep(IEnumerable<string> existing)
        {
            var all = new HashSet<string>(existing, StringComparer.OrdinalIgnoreCase);
            names.RemoveWhere(n => !all.Contains(n));
        }

        /// <summary>The header's box for the rows shown: 0 none ticked, 1 some, 2 all.</summary>
        public int State(IEnumerable<string> shown)
        {
            List<string> list = shown.ToList();
            int n = list.Count(names.Contains);
            return n == 0 ? 0 : n == list.Count ? 2 : 1;
        }
    }

    /// <summary>The list of copies, painted like a Windows 11 list: roomy rows, thin dividers, no grid lines,
    /// and on each row a "باز کردن متاتریدر" button and a "⋯" button for everything else.</summary>
    sealed class CopyGrid : DataGridView
    {
        // 3.27.2: a property, so the headers follow a language change made while the program runs.
        static string[][] Spec { get { return new[]
        {
            // 3.26 (CHANGE-001): «نسخه» gives room to the name, the server and the folders; «عمل‌ها» (CHANGE-002) is narrower and fixed.
            new[] { "Check", "", "4" }, new[] { "Trader", Lang.T("دانشجو", "Student"), "152" }, new[] { "Copy", Lang.T("نسخه", "Copy"), "74" }, new[] { "Login", Lang.T("شماره حساب", "Account"), "94" },
            new[] { "Server", Lang.T("سرور", "Server"), "134" }, new[] { "Folders", Lang.T("پوشه‌ها", "Folders"), "130" }, new[] { "Today", Lang.T("امروز", "Today"), "250" }, new[] { "Status", Lang.T("وضعیت", "Status"), "150" }, new[] { "Action", "", "130" },
        }; } }

        public static readonly Color SelBack = Color.FromArgb(0xF2, 0xF7, 0xFD), HoverBack = Color.FromArgb(0xF8, 0xF8, 0xF8), Divider = Color.FromArgb(0xEF, 0xEF, 0xEF),
            HeadBack = Color.FromArgb(0xFA, 0xFA, 0xFA), HeadLine = Color.FromArgb(0xE5, 0xE5, 0xE5),
            OkDot = Color.FromArgb(0x13, 0xA1, 0x0E), WarnDot = Color.FromArgb(0xC2, 0x7C, 0x0E);
        static Color OffDot { get { return Theme.Mix(Theme.Faint, Theme.Surface, 0.2f); } }

        public event Action<CopyRow> OpenClicked;
        /// <summary>3.24.2: the student's name was clicked (only the name, not the rest of the row) or Enter pressed: the student's page opens.</summary>
        public event Action<CopyRow> RowClicked;

        /// <summary>3.21: the report under a row (one at a time): the panel, the copy it is under and how tall it is.</summary>
        public ReportPanel Detail;
        public string ExpandedName;
        public int DetailHeight;
        public int BaseHeight { get { return RowTemplate.Height; } }
        /// <summary>A row's box was clicked (or Space pressed on the row).</summary>
        public event Action<CopyRow> CheckClicked;
        /// <summary>The box in the column title was clicked.</summary>
        public event Action CheckAllClicked;

        int headerCheck;
        /// <summary>The box in the column title: 0 none of the rows shown is ticked, 1 some, 2 all.</summary>
        public int HeaderCheck
        {
            get { return headerCheck; }
            set { if (headerCheck != value) { headerCheck = value; InvalidateCell(Columns["Check"].Index, -1); } }
        }
        /// <summary>The row's menu, at a point on the screen.</summary>
        public event Action<CopyRow, Point> MenuWanted;

        /// <summary>Shown in the empty list (when the search finds nothing).</summary>
        public string EmptyText;

        int hoverRow = -1;
        RowPart hoverPart;

        public CopyGrid()
        {
            DoubleBuffered = true;
            BorderStyle = BorderStyle.None;
            CellBorderStyle = DataGridViewCellBorderStyle.None;
            ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            RowHeadersVisible = false;
            AllowUserToAddRows = false;
            AllowUserToDeleteRows = false;
            AllowUserToResizeRows = false;
            AllowUserToResizeColumns = false;
            AllowUserToOrderColumns = false;
            ReadOnly = true;
            SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            // One row is marked at a time; several are chosen with the boxes of the first column.
            MultiSelect = false;
            StandardTab = true;
            ShowCellToolTips = false;
            BackgroundColor = Theme.Surface;
            GridColor = Divider;
            EnableHeadersVisualStyles = false;
            ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            ColumnHeadersHeight = Theme.S(36);
            RowTemplate.Height = Theme.S(44);
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            // The columns always fit the width: never a sideways scroll bar.
            ScrollBars = ScrollBars.Vertical;
            Font = Theme.Font;
            DefaultCellStyle.BackColor = Theme.Surface;
            DefaultCellStyle.ForeColor = Theme.Text;
            DefaultCellStyle.SelectionBackColor = SelBack;
            DefaultCellStyle.SelectionForeColor = Theme.Text;
            ColumnHeadersDefaultCellStyle.BackColor = Theme.Surface;
            ColumnHeadersDefaultCellStyle.ForeColor = Theme.Muted;
            // The grid itself runs left to right with its columns in reverse order, so the first one is on the right.
            // (In right-to-left mode, Windows leaves one-pixel gaps between cells that nothing paints: dark lines.)
            RightToLeft = RightToLeft.No;
            // 3.27: in English the first column is at the left.
            IEnumerable<string[]> order = Lang.En ? Spec : Spec.Reverse();
            foreach (string[] c in order)
            {
                var col = new DataGridViewTextBoxColumn
                {
                    Name = c[0], HeaderText = c[1], FillWeight = float.Parse(c[2], CultureInfo.InvariantCulture),
                    SortMode = DataGridViewColumnSortMode.NotSortable, MinimumWidth = Theme.S(60),
                };
                Columns.Add(col);
            }
            DataGridViewColumn check = Columns["Check"];
            check.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            check.MinimumWidth = Theme.S(44);
            check.Width = Theme.S(44);
            check.Resizable = DataGridViewTriState.False;
            DataGridViewColumn action = Columns["Action"];
            action.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            action.MinimumWidth = Theme.S(132);
            action.Width = Theme.S(132);
            action.Resizable = DataGridViewTriState.False;
            Columns["Trader"].MinimumWidth = Theme.S(130);
            Columns["Status"].MinimumWidth = Theme.S(150);  // 3.22.4: room for «رمز یا حساب اشتباه» and the like
            Columns["Today"].MinimumWidth = Theme.S(200);
            Columns["Server"].MinimumWidth = Theme.S(110);
            Columns["Copy"].MinimumWidth = Theme.S(70);
            Columns["Login"].MinimumWidth = Theme.S(90);
            Columns["Folders"].MinimumWidth = Theme.S(110);
            tip = new ToolTip { InitialDelay = 400, ReshowDelay = 100, AutoPopDelay = 15000, ShowAlways = true };
        }

        readonly ToolTip tip;
        string tipText = "";


        protected override void Dispose(bool disposing)
        {
            if (disposing) tip.Dispose();
            base.Dispose(disposing);
        }

        public CopyRow RowAt(int index) { return index >= 0 && index < Rows.Count ? Rows[index].Tag as CopyRow : null; }

        /// <summary>Puts a row's data in place; the cells also get the text, for copying (Ctrl+C) and screen readers.</summary>
        public void SetRow(int index, CopyRow r)
        {
            DataGridViewRow row = Rows[index];
            var old = row.Tag as CopyRow;
            if (old != null && old.Key == r.Key) return;
            row.Tag = r;
            row.Cells["Check"].Value = r.Checked ? Lang.T("انتخاب‌شده", "Selected") : "";
            row.Cells["Trader"].Value = r.Trader;
            row.Cells["Copy"].Value = r.Kind + " " + r.Name;
            row.Cells["Login"].Value = r.Login;
            row.Cells["Server"].Value = r.Server;
            row.Cells["Status"].Value = r.Status;
            row.Cells["Folders"].Value = string.Join(Lang.T("، ", ", "), r.Folders);
            row.Cells["Today"].Value = r.TodayText;
            row.Cells["Action"].Value = r.Running ? Lang.T("نمایش متاتریدر", "Show MetaTrader") : Lang.T("باز کردن متاتریدر", "Open MetaTrader");
            int want = r.Expanded && Detail != null ? BaseHeight + DetailHeight : BaseHeight;
            if (row.Height != want) row.Height = want;
            InvalidateRow(index);
            PlaceDetail();
        }

        /// <summary>The panel sits in the lower part of its row, and goes with it as the list scrolls; hidden when its row is not shown.</summary>
        public void PlaceDetail()
        {
            if (Detail == null) return;
            int k = -1;
            if (ExpandedName != null)
                for (int n = 0; n < Rows.Count; n++)
                {
                    CopyRow r = RowAt(n);
                    if (r != null && r.Expanded && string.Equals(r.Name, ExpandedName, StringComparison.OrdinalIgnoreCase)) { k = n; break; }
                }
            Rectangle rect = k >= 0 ? GetRowDisplayRectangle(k, false) : Rectangle.Empty;
            if (k < 0 || rect.Height <= 0 || Rows[k].Height <= BaseHeight)
            {
                if (Detail.Visible) Detail.Visible = false;
                return;
            }
            var b = new Rectangle(0, rect.Y + BaseHeight, DisplayRectangle.Width, DetailHeight);
            if (Detail.Bounds != b) Detail.Bounds = b;
            if (!Detail.Visible) Detail.Visible = true;
        }

        protected override void OnScroll(ScrollEventArgs e) { base.OnScroll(e); PlaceDetail(); }
        protected override void OnSizeChanged(EventArgs e) { base.OnSizeChanged(e); PlaceDetail(); }
        protected override void OnRowHeightChanged(DataGridViewRowEventArgs e) { base.OnRowHeightChanged(e); PlaceDetail(); }

        public List<CopyRow> SelectedCopies { get { return SelectedRows.Cast<DataGridViewRow>().Select(r => r.Tag as CopyRow).Where(r => r != null).ToList(); } }

        // ------------------------------------------------------------- painting

        static Rectangle Inner(Rectangle cell) { return new Rectangle(cell.X + Theme.S(14), cell.Y, Math.Max(0, cell.Width - Theme.S(28)), cell.Height); }

        /// <summary>3.26 (CHANGE-002): short words on a small button.</summary>
        static string OpenText(CopyRow r) { return r.Running ? Lang.T("نمایش", "Show") : Lang.T("باز کردن", "Open"); }

        /// <summary>Where the two buttons sit in the action cell: "⋯" at the reading end (left), the main button next to it.</summary>
        void ActionRects(Rectangle cell, CopyRow r, out Rectangle open, out Rectangle more)
        {
            if (cell.Height > BaseHeight) cell.Height = BaseHeight;
            int h = Theme.S(26), y = cell.Y + (cell.Height - h) / 2;
            more = new Rectangle(cell.X + Theme.S(8), y, Theme.S(28), h);
            int w = Theme.Measure(OpenText(r), Theme.Small).Width + Theme.S(10) * 2 + Theme.S(12) + Theme.S(6);
            open = new Rectangle(more.Right + Theme.S(6), y, w, h);
            // 3.27: English: «···» at the row's end (right), the button before it.
            more = Theme.Flip(more, cell);
            open = Theme.Flip(open, cell);
        }

        protected override void OnCellPainting(DataGridViewCellPaintingEventArgs e)
        {
            base.OnCellPainting(e);
            if (e.ColumnIndex < 0) return;
            e.Handled = true;
            Graphics g = e.Graphics;
            Rectangle cell = e.CellBounds;
            string col = Columns[e.ColumnIndex].Name;
            if (e.RowIndex < 0)
            {
                using (var b = new SolidBrush(HeadBack)) g.FillRectangle(b, cell.X, cell.Y, cell.Width + 1, cell.Height);
                if (col == "Check") PaintBox(g, cell, headerCheck, false);
                else Theme.Line(g, Columns[e.ColumnIndex].HeaderText, Theme.SmallBold, Inner(cell), Theme.Muted);
                using (var pen = new Pen(HeadLine)) g.DrawLine(pen, cell.Left, cell.Bottom - 1, cell.Right, cell.Bottom - 1);
                // A short separator between column titles keeps the columns readable as a table.
                if (Lang.En ? col != "Status" && col != "Action" && col != "Check" : col != "Trader" && col != "Action" && col != "Check")
                    using (var pen = new Pen(HeadLine)) g.DrawLine(pen, cell.Right - 1, cell.Top + Theme.S(10), cell.Right - 1, cell.Bottom - Theme.S(10));
                return;
            }
            CopyRow r = RowAt(e.RowIndex);
            bool sel = Rows[e.RowIndex].Selected;
            // An open report takes the lower part of its row: the cells keep the top part, as tall as any other row.
            if (cell.Height > BaseHeight) cell = new Rectangle(cell.X, cell.Y, cell.Width, BaseHeight);
            using (var b = new SolidBrush(RowBack(e.RowIndex))) g.FillRectangle(b, cell.X, cell.Y, cell.Width + 1, cell.Height);
            using (var pen = new Pen(Divider)) g.DrawLine(pen, cell.Left, cell.Bottom - 1, cell.Right + 1, cell.Bottom - 1);
            if (r == null) return;
            Rectangle inner = Inner(cell);
            switch (col)
            {
                case "Check":
                    // The marked row has an accent bar at its start (the right edge).
                    if (sel) using (var b = new SolidBrush(Theme.Accent)) g.FillRectangle(b, Lang.En ? cell.Left : cell.Right - Theme.S(3), cell.Top, Theme.S(3), cell.Height - 1);
                    PaintBox(g, cell, r.Checked ? 2 : 0, e.RowIndex == hoverRow && hoverPart == RowPart.Check);
                    break;
                case "Trader":
                    {
                        // 3.21: a small mark of the report under the row (open or closed) for students, then the name.
                        // 3.24.2: the name (and its mark) takes the accent colour while the mouse is on it: it opens the student's page.
                        bool onName = e.RowIndex == hoverRow && hoverPart == RowPart.Name;
                        int m = Theme.S(10);
                        if (r.HasAccount)
                            Glyphs.Draw(g, r.Expanded ? Glyph.Chevron : Lang.En ? Glyph.ChevronRight : Glyph.ChevronLeft, Theme.Flip(new RectangleF(inner.Right - m, inner.Y + (inner.Height - m) / 2f, m, m), inner),
                                        r.Expanded || onName ? Theme.Accent : Theme.Faint);
                        var t = Theme.Flip(new Rectangle(inner.X, inner.Y, Math.Max(0, inner.Width - (r.HasAccount ? m + Theme.S(7) : 0)), inner.Height), inner);
                        Theme.Line(g, r.Trader, r.HasAccount ? Theme.Bold : Theme.Font, t, onName ? Theme.Accent : r.HasAccount ? Theme.Text : Theme.Faint);
                    }
                    break;
                case "Copy":
                    {
                        // 3.23 (approved): one badge, the copy's name, which says its platform too ("MT4-01").
                        Size t = Theme.Measure(r.Name, Theme.SmallBold);
                        int bw = Math.Min(inner.Width, t.Width + Theme.S(14)), bh = Theme.S(20);
                        var badge = Theme.Flip(new Rectangle(inner.Right - bw, cell.Y + (cell.Height - bh) / 2, bw, bh), inner);
                        Theme.Box(g, badge, Theme.Sf(3), Color.FromArgb(0xEE, 0xEF, 0xF1), Color.Transparent);
                        Theme.Line(g, r.Name, Theme.SmallBold, badge, Theme.Mix(Theme.Text, Theme.Muted, 0.35f), true);
                    }
                    break;
                case "Login":
                    Ltr(g, r.Login, inner);
                    break;
                case "Server":
                    Ltr(g, r.Server, inner);
                    break;
                case "Status":
                    PaintStatus(g, r, inner);
                    break;
                case "Today":
                    PaintToday(g, r, inner);
                    break;
                case "Folders":
                    PaintFolders(g, r, inner);
                    break;
                case "Action":
                    PaintActions(g, r, cell, e.RowIndex);
                    break;
            }
        }

        /// <summary>A number or a server name, left to right at the right of its cell; one too long for it starts at the left and ends
        /// in "…" (right-aligned, its start would be cut off).</summary>
        static void Ltr(Graphics g, string text, Rectangle r)
        {
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis;
            bool fits = TextRenderer.MeasureText(text ?? "", Theme.Font, Size.Empty, f).Width <= r.Width;
            // 3.27: English: at the start (left) like the rest.
            TextRenderer.DrawText(g, text ?? "", Theme.Font, r, Theme.Text, f | (fits && !Lang.En ? TextFormatFlags.Right : TextFormatFlags.Left));
        }

        Color RowBack(int row)
        {
            CopyRow r = RowAt(row);
            return Rows[row].Selected ? SelBack : r != null && r.Checked ? CheckedBack : row == hoverRow ? HoverBack : Theme.Surface;
        }

        static readonly Color CheckedBack = Color.FromArgb(0xF7, 0xFA, 0xFE);

        /// <summary>A square box in the middle of the cell: empty, a dash (some), or filled with a tick (all / this one).</summary>
        static void PaintBox(Graphics g, Rectangle cell, int state, bool hover)
        {
            int size = Theme.S(16);
            Theme.TickBox(g, new Rectangle(cell.X + (cell.Width - size) / 2, cell.Y + (cell.Height - size) / 2, size, size), state, hover);
        }

        /// <summary>The whole row first, so no gap between cells can show through.</summary>
        protected override void OnRowPrePaint(DataGridViewRowPrePaintEventArgs e)
        {
            base.OnRowPrePaint(e);
            using (var b = new SolidBrush(RowBack(e.RowIndex))) e.Graphics.FillRectangle(b, e.RowBounds);
        }

        // 3.17: white capsules with a thin frame and gently rounded corners, like the folder row above the list.
        static Color TagBack { get { return Theme.Surface; } }
        static Color TagLine { get { return Theme.BorderStrong; } }
        static Color TagText { get { return Theme.LabelColor; } }
        static float TagRadius { get { return Theme.Square ? 0 : Theme.Sf(6); } }

        /// <summary>The copy's folders as small labels from the right; what does not fit becomes "+N".</summary>
        static void PaintFolders(Graphics g, CopyRow r, Rectangle inner)
        {
            if (r.Folders.Length == 0) return;
            int h = Theme.S(20), y = inner.Y + (inner.Height - h) / 2, x = inner.Right, gap = Theme.S(4), pad = Theme.S(8);
            for (int k = 0; k < r.Folders.Length; k++)
            {
                string t = r.Folders[k];
                int w = Theme.Measure(t, Theme.Small).Width + pad * 2;
                int left = r.Folders.Length - k - 1;
                int moreW = left > 0 ? Theme.Measure("+" + Fa.N(left), Theme.Small).Width + pad * 2 + gap : 0;
                bool fits = x - w - moreW >= inner.X;
                if (!fits)
                {
                    string m = "+" + Fa.N(r.Folders.Length - k);
                    int mw = Theme.Measure(m, Theme.Small).Width + pad * 2;
                    if (k == 0)
                    {
                        // Not even one fits whole: the first, shortened, then the rest as "+N".
                        w = Math.Max(Theme.S(30), inner.Width - (r.Folders.Length > 1 ? mw + gap : 0));
                        var b0 = Theme.Flip(new Rectangle(x - w, y, w, h), inner);
                        Theme.Box(g, b0, TagRadius, TagBack, TagLine);
                        // 3.26 (CHANGE-001): shortened from its end with "…" (centred, it was cut on both sides).
                        Theme.Line(g, t, Theme.Small, new Rectangle(b0.X + pad / 2, b0.Y, b0.Width - pad, b0.Height), TagText);
                        x -= w + gap;
                        if (r.Folders.Length == 1) return;
                        m = "+" + Fa.N(r.Folders.Length - 1);
                        mw = Theme.Measure(m, Theme.Small).Width + pad * 2;
                    }
                    var mb = Theme.Flip(new Rectangle(x - mw, y, mw, h), inner);
                    Theme.Box(g, mb, TagRadius, Theme.Surface, TagLine);
                    Theme.Line(g, m, Theme.Small, mb, Theme.Muted, true);
                    return;
                }
                var b = Theme.Flip(new Rectangle(x - w, y, w, h), inner);
                Theme.Box(g, b, TagRadius, TagBack, TagLine);
                Theme.Line(g, t, Theme.Small, b, TagText, true);
                x -= w + gap;
            }
        }

        /// <summary>3.21: the «امروز» cell: the day in a few words (left to right, the money green or red, "No SL" red) at the right,
        /// and when it was read under it; or that it is being read, was not read, or could not be.</summary>
        static void PaintToday(Graphics g, CopyRow r, Rectangle inner)
        {
            if (!r.HasAccount) return;
            int line = Theme.S(18), top = inner.Y + (inner.Height - line * 2) / 2;
            if (r.TodayBusy)
            {
                int dot = Theme.S(10);
                var d = Theme.Flip(new RectangleF(inner.Right - dot, inner.Y + (inner.Height - dot) / 2f, dot, dot), inner);
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using (var pen = new Pen(Theme.Accent, Math.Max(1.4f, Theme.Sf(1.6f)))) g.DrawArc(pen, d.X + 0.5f, d.Y + 0.5f, d.Width - 1, d.Height - 1, -90, 270);
                Theme.Line(g, r.TodayAgo.Length > 0 ? r.TodayAgo : Lang.T("در حال خواندن…", "Reading…"), Theme.Small, Theme.Flip(new Rectangle(inner.X, inner.Y, inner.Width - dot - Theme.S(7), inner.Height), inner), Theme.Accent);
                return;
            }
            if (r.TodayNone)
            {
                Theme.Line(g, r.TodayText, Theme.Small, new Rectangle(inner.X, top, inner.Width, line), r.TodayFailed ? Theme.Bad : Theme.Faint);
                if (r.TodayAgo.Length > 0) Theme.Line(g, r.TodayAgo, Theme.Small, new Rectangle(inner.X, top + line, inner.Width, line), Theme.Faint);
                return;
            }
            // "3 trades · +$38.20 · 1 No SL": three parts, measured and drawn from the left of where the line starts.
            string[] parts = r.TodayText.Split(new[] { " · " }, StringSplitOptions.None);
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter;
            // Between the parts a dot in a fixed gap (a measured " · " loses its spaces).
            int gap = Theme.S(15);
            int total = 0;
            for (int k = 0; k < parts.Length; k++) total += TextRenderer.MeasureText(parts[k], Theme.Small, Size.Empty, f).Width + (k > 0 ? gap : 0);
            // 3.27: the parts read left to right: at the right end in Persian, at the start (left) in English.
            int x = Lang.En ? inner.X : Math.Max(inner.X, inner.Right - total);
            for (int k = 0; k < parts.Length; k++)
            {
                if (k > 0)
                {
                    TextRenderer.DrawText(g, "·", Theme.Small, new Rectangle(x, top, gap, line), Theme.Faint, f | TextFormatFlags.HorizontalCenter);
                    x += gap;
                }
                Color c = k == 1 && parts.Length > 1 ? (r.TodayTone > 0 ? Theme.Ok : r.TodayTone < 0 ? Theme.Bad : Theme.Text)
                        : k == 2 && r.TodayNoSl ? Theme.Bad : r.TodayFailed ? Theme.Bad : parts.Length == 1 ? Theme.Faint : Theme.Text;
                int w = TextRenderer.MeasureText(parts[k], Theme.Small, Size.Empty, f).Width;
                TextRenderer.DrawText(g, parts[k], Theme.Small, new Rectangle(x, top, Math.Min(w + 1, inner.Right - x), line), c, f | TextFormatFlags.EndEllipsis);
                x += w;
            }
            if (r.TodayAgo.Length > 0) Theme.Line(g, r.TodayAgo, Theme.Small, new Rectangle(inner.X, top + line, inner.Width, line), r.TodayFailed ? Theme.Bad : Theme.Faint);
        }

        /// <summary>3.26 (CHANGE-004): the state as a small label with a pale background and its dot inside.</summary>
        void PaintStatus(Graphics g, CopyRow r, Rectangle inner)
        {
            Color back, text, dotColor;
            switch (r.State)
            {
                case RowState.On: back = Color.FromArgb(0xE6, 0xF4, 0xE6); text = Color.FromArgb(0x0E, 0x6E, 0x0B); dotColor = OkDot; break;
                case RowState.Open: back = Color.FromArgb(0xEC, 0xF7, 0xEC); text = Color.FromArgb(0x2F, 0x6B, 0x2D); dotColor = Theme.Mix(OkDot, Color.White, 0.35f); break;
                case RowState.Bad: back = Color.FromArgb(0xFD, 0xE7, 0xE7); text = Theme.Bad; dotColor = Theme.Bad; break;
                case RowState.Warn: back = Color.FromArgb(0xFD, 0xF1, 0xDC); text = Color.FromArgb(0x8A, 0x55, 0x00); dotColor = WarnDot; break;
                case RowState.Active: back = Theme.AccentSoft; text = Theme.Accent; dotColor = Theme.Accent; break;
                default: back = Color.FromArgb(0xF0, 0xF0, 0xF0); text = Theme.Muted; dotColor = OffDot; break;
            }
            int dot = Theme.S(7), padIn = Theme.S(9), gap = Theme.S(6), h = Theme.S(22);
            Font font = Theme.SmallBold;
            int w = Math.Min(inner.Width, Theme.Measure(r.Status ?? "", font).Width + padIn * 2 + dot + gap);
            var chip = Theme.Flip(new Rectangle(inner.Right - w, inner.Y + (inner.Height - h) / 2, w, h), inner);
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Theme.Box(g, chip, Theme.Square ? 0 : h / 2f, back, Color.Transparent);
            var dd = new RectangleF(chip.Right - padIn - dot, chip.Y + (chip.Height - dot) / 2f, dot, dot);
            var d = Theme.Flip(dd, chip);
            if (r.State == RowState.Pending)
                using (var pen = new Pen(Theme.Accent, Math.Max(1.4f, Theme.Sf(1.5f)))) g.DrawArc(pen, d.X - 1, d.Y - 1, d.Width + 1, d.Height + 1, -90, 270);
            else
                using (var b = new SolidBrush(dotColor)) g.FillEllipse(b, d);
            Theme.Line(g, r.Status, font, Theme.Flip(new Rectangle(chip.X + padIn, chip.Y, Math.Max(0, (int)dd.X - gap - chip.X - padIn), chip.Height), chip), text);
        }

        void PaintActions(Graphics g, CopyRow r, Rectangle cell, int row)
        {
            Rectangle open, more;
            ActionRects(cell, r, out open, out more);
            bool hoverOpen = row == hoverRow && hoverPart == RowPart.Open, hoverMore = row == hoverRow && hoverPart == RowPart.More;
            // 3.26 (CHANGE-002): a small white button on every row; blue (the main one) only on the marked row or the row under the mouse.
            bool strong = Rows[row].Selected || row == hoverRow;
            Color fill, border, fore, glyph;
            if (strong)
            {
                fill = hoverOpen ? Theme.Mix(Theme.Accent, Color.Black, 0.10f) : Theme.Accent;
                border = fill;
                fore = glyph = Theme.OnAccent;
            }
            else
            {
                fill = Theme.Surface;
                border = Theme.BorderStrong;
                fore = Theme.Text;
                glyph = r.Running ? Theme.Muted : Theme.Accent;
            }
            Theme.Box(g, open, Theme.Sf(4), fill, border);
            int icon = Theme.S(11);
            var ir = new RectangleF(open.Right - Theme.S(10) - icon, open.Y + (open.Height - icon) / 2f, icon, icon);
            Glyphs.Draw(g, r.Running ? Glyph.Window : Glyph.Play, Theme.Flip(ir, open), glyph);
            Theme.Line(g, OpenText(r), Theme.Small, Theme.Flip(new Rectangle(open.X + Theme.S(8), open.Y, (int)ir.X - Theme.S(6) - open.X - Theme.S(8), open.Height), open), fore);
            if (hoverMore) Theme.Box(g, more, Theme.Sf(4), Theme.Mix(Theme.Hover, Color.Black, 0.04f), Color.Transparent);
            int m = Theme.S(15);
            Glyphs.Draw(g, Glyph.More, new RectangleF(more.X + (more.Width - m) / 2f, more.Y + (more.Height - m) / 2f, m, m), Theme.Muted);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Rows.Count == 0 && !string.IsNullOrEmpty(EmptyText))
                Theme.Line(e.Graphics, EmptyText, Theme.Font, new Rectangle(0, ColumnHeadersHeight + Theme.S(24), Width, Theme.S(30)), Theme.Muted, true);
        }

        // ------------------------------------------------------------- mouse and keys

        RowPart PartAt(Point p, out int row)
        {
            HitTestInfo h = HitTest(p.X, p.Y);
            row = h.Type == DataGridViewHitTestType.Cell ? h.RowIndex : -1;
            CopyRow r = RowAt(row);
            // The whole first cell is the box: easy to hit.
            if (row >= 0 && r != null && h.ColumnIndex == Columns["Check"].Index) return RowPart.Check;
            if (row >= 0 && r != null && h.ColumnIndex == Columns["Trader"].Index) return NameRect(row, r).Contains(p) ? RowPart.Name : RowPart.None;
            if (row < 0 || h.ColumnIndex != Columns["Action"].Index || r == null) return RowPart.None;
            Rectangle open, more;
            ActionRects(GetCellDisplayRectangle(h.ColumnIndex, row, false), RowAt(row), out open, out more);
            return open.Contains(p) ? RowPart.Open : more.Contains(p) ? RowPart.More : RowPart.None;
        }

        /// <summary>3.24.2: where the student's name is written in its row (with the small mark beside it): only there a click opens the
        /// student's page. A copy without an account has none.</summary>
        Rectangle NameRect(int row, CopyRow r)
        {
            if (r == null || !r.HasAccount) return Rectangle.Empty;
            Rectangle cell = GetCellDisplayRectangle(Columns["Trader"].Index, row, false);
            if (cell.Height > BaseHeight) cell.Height = BaseHeight;
            Rectangle inner = Inner(cell);
            int mark = Theme.S(10) + Theme.S(7), pad = Theme.S(3), h = Theme.S(26);
            int w = Math.Min(Math.Max(0, inner.Width - mark), Theme.Measure(r.Trader ?? "", Theme.Bold).Width);
            return Theme.Flip(new Rectangle(inner.Right - mark - w - pad, cell.Y + (cell.Height - h) / 2, w + mark + pad * 2, h), inner);
        }

        void SetHover(int row, RowPart part)
        {
            if (row == hoverRow && part == hoverPart) return;
            int old = hoverRow;
            hoverRow = row;
            hoverPart = part;
            if (old >= 0 && old < Rows.Count) InvalidateRow(old);
            if (row >= 0 && row < Rows.Count && row != old) InvalidateRow(row);
            else if (row >= 0 && row < Rows.Count) InvalidateRow(row);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            int row;
            RowPart part = PartAt(e.Location, out row);
            SetHover(row, part);
            HitTestInfo h = HitTest(e.X, e.Y);
            bool headBox = h.Type == DataGridViewHitTestType.ColumnHeader && h.ColumnIndex == Columns["Check"].Index;
            Cursor want = part != RowPart.None || headBox ? Cursors.Hand : Cursors.Default;
            if (Cursor != want) Cursor = want;
            string t = TipAt(h);
            if (t != tipText)
            {
                tipText = t;
                tip.SetToolTip(this, t.Length > 0 ? t : null);
            }
        }

        /// <summary>3.26 (CHANGE-001/003): the whole text of a shortened server name or «امروز» line.</summary>
        string TipAt(HitTestInfo h)
        {
            if (h.Type != DataGridViewHitTestType.Cell) return "";
            CopyRow r = RowAt(h.RowIndex);
            if (r == null) return "";
            string col = Columns[h.ColumnIndex].Name;
            Rectangle cell = GetCellDisplayRectangle(h.ColumnIndex, h.RowIndex, false);
            if (cell.Height > BaseHeight) cell.Height = BaseHeight;
            int room = Inner(cell).Width;
            if (col == "Server")
                return Theme.Measure(r.Server ?? "", Theme.Font).Width > room ? r.Server : "";
            if (col == "Today")
            {
                if (r.TodayTip.Length > 0) return r.TodayTip;
                string line = r.TodayText;
                return Theme.Measure(line ?? "", Theme.Small).Width > room - Theme.S(30) ? line : "";
            }
            return "";
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            if (tipText.Length > 0) { tipText = ""; tip.SetToolTip(this, null); }
            SetHover(-1, RowPart.None);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            HitTestInfo h = HitTest(e.X, e.Y);
            if (e.Button == MouseButtons.Right && h.RowIndex >= 0 && !Rows[h.RowIndex].Selected)
            {
                ClearSelection();
                Rows[h.RowIndex].Selected = true;
                CurrentCell = Rows[h.RowIndex].Cells[Columns["Trader"].Index];
            }
            base.OnMouseDown(e);
        }

#if SNAPSHOT
        /// <summary>For the screenshots: the mouse on a row's name (-1: nowhere).</summary>
        public void PreviewNameHover(int row) { SetHover(row, row >= 0 ? RowPart.Name : RowPart.None); }
#endif

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            int row;
            RowPart part = PartAt(e.Location, out row);
            CopyRow r = RowAt(row);
            if (r == null) return;
            if (e.Button == MouseButtons.Right) { if (MenuWanted != null) MenuWanted(r, PointToScreen(e.Location)); return; }
            // A click below the cells of an open row is the report's own (it has its own control there).
            if (row >= 0 && e.Y >= GetRowDisplayRectangle(row, false).Y + BaseHeight) return;
            // 3.24.2: only the name opens the student's page; a click anywhere else in the row only marks it.
            if (part == RowPart.None) return;
            if (part == RowPart.Name) { if (e.Button == MouseButtons.Left && RowClicked != null) RowClicked(r); return; }
            if (part == RowPart.Check && CheckClicked != null) CheckClicked(r);
            else if (part == RowPart.Open && OpenClicked != null) OpenClicked(r);
            else if (part == RowPart.More && MenuWanted != null)
            {
                Rectangle open, more;
                ActionRects(GetCellDisplayRectangle(Columns["Action"].Index, row, false), r, out open, out more);
                MenuWanted(r, PointToScreen(new Point(more.Left, more.Bottom + Theme.S(2))));
            }
        }

        protected override void OnColumnHeaderMouseClick(DataGridViewCellMouseEventArgs e)
        {
            base.OnColumnHeaderMouseClick(e);
            if (e.Button == MouseButtons.Left && e.ColumnIndex == Columns["Check"].Index && CheckAllClicked != null) CheckAllClicked();
        }

        // 3.21: a double click no longer opens MetaTrader (approved): a click on the name opens the report, MetaTrader opens from its button only.

        protected override bool ProcessDataGridViewKey(KeyEventArgs e)
        {
            CopyRow r = CurrentRow != null ? RowAt(CurrentRow.Index) : null;
            if (r != null && e.KeyCode == Keys.Enter && !e.Control && !e.Shift)
            {
                if (RowClicked != null) RowClicked(r);
                return true;
            }
            if (r != null && e.KeyCode == Keys.Space && !e.Control)
            {
                if (CheckClicked != null) CheckClicked(r);
                return true;
            }
            if (r != null && (e.KeyCode == Keys.Apps || (e.Shift && e.KeyCode == Keys.F10)))
            {
                Rectangle cell = GetCellDisplayRectangle(Columns["Action"].Index, CurrentRow.Index, false);
                if (MenuWanted != null) MenuWanted(r, PointToScreen(new Point(cell.Left + Theme.S(10), cell.Bottom)));
                return true;
            }
            return base.ProcessDataGridViewKey(e);
        }
    }
}
