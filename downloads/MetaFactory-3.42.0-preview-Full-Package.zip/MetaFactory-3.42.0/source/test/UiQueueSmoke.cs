using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using MTManager;

static class UiQueueSmoke
{
    static int count;
    static void Assert(bool result, string text) { if (!result) throw new Exception(text); count++; }
    static FieldInfo Field(object x, string name) { return x.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic); }
    static void Call(object x, string name, params object[] args) { x.GetType().GetMethod(name, BindingFlags.Instance | BindingFlags.NonPublic).Invoke(x, args); }
    static void Pump(int ms) { var clock = Stopwatch.StartNew(); do { Application.DoEvents(); Thread.Sleep(10); } while (clock.ElapsedMilliseconds < ms); }
    static readonly ManualResetEvent allow = new ManualResetEvent(false);
    sealed class Fake : IAccountVerifier
    {
        public ImportConnection Verify(Account a, int timeout, Func<bool> cancel, Action<string> stage) { while (!allow.WaitOne(10) && !cancel()) { } return new ImportConnection { Connected = true, State = Login.Connected }; }
        public void Dispose() { }
    }
    [STAThread] static int Main(string[] args)
    {
        string root = Path.Combine(Path.GetTempPath(), "mtm-ui-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root); AppPaths.DataDirOverride = root; Lang.En = args.Contains("en");
        Application.EnableVisualStyles(); typeof(Account).Assembly.GetType("MTManager.Theme").GetMethod("Init").Invoke(null, null);
        var settings = new Settings { BaseDir = Path.Combine(root, "copies") }; Directory.CreateDirectory(settings.BaseDir);
        var accounts = new AccountStore(); var folders = new FolderStore();
        var assembly = typeof(Account).Assembly;
        try
        {
            using (var queue = new ImportCoordinator(settings, accounts, folders, slot => new Fake(), 1))
            {
                Type dialogType = assembly.GetType("MTManager.StudentImportDialog");
                using (var dialog = (Form)Activator.CreateInstance(dialogType, new object[] { settings, accounts, folders, "", queue }))
                {
                    var rows = Enumerable.Range(1, 100).Select(n => new StudentImportRow { Name = "UI student " + n, Login = (20000000 + n).ToString(), Server = "WMMarkets-Demo", Platform = "MT5", Kind = Kind.MT5, Investor = "FakePass!123", State = ImportState.Ready }).ToList();
                    Field(dialog, "rows").SetValue(dialog, rows);
                    var grid = (DataGridView)Field(dialog, "grid").GetValue(dialog);
                    foreach (var row in rows) grid.Rows.Add(row.Line, row.Name, row.Platform, row.Login, row.Server, row.Folder, row.Copy, "Ready", "");
                    dialog.Show(); Pump(150); var clock = Stopwatch.StartNew(); Call(dialog, "Begin", null, EventArgs.Empty);
                    while (accounts.All.Count() != 100 && clock.ElapsedMilliseconds < 10000) Pump(50);
                    Pump(300);
                    Assert(dialog.Visible, "Excel dialog stays open during checks");
                    Assert(accounts.All.Count() == 100, "100 students registered through production UI");
                    Assert(rows.Any(r => r.State == ImportState.Registered || r.State == ImportState.Checking), "pending accounts are not mislabeled as connected");
                    Assert(Directory.GetDirectories(settings.BaseDir).Length == 0, "registration creates no personal terminal copies");
                    Console.WriteLine("100-row UI registration: " + clock.ElapsedMilliseconds + " ms (no live broker check)");
                    Call(dialog, "RequestStop"); Pump(300);
                    Assert(queue.Paused, "Excel stop button pauses background checks");
                    Assert(rows.All(r => r.State == ImportState.Cancelled), "paused rows shown in same Excel table");
                    Call(dialog, "Retry", null, EventArgs.Empty); allow.Set();
                    var done = Stopwatch.StartNew();
                    while (!rows.All(r => r.State == ImportState.Connected) && done.ElapsedMilliseconds < 10000) Pump(50);
                    Assert(rows.All(r => r.State == ImportState.Connected), "same Excel table shows every connection result");
                    Assert(dialog.Visible, "results stay visible after completion");
                    Assert(((DataGridView)Field(dialog, "grid").GetValue(dialog)).Rows.Count == 100, "Excel table retains all rows");
                    Assert(accounts.All.Count() == 100, "retry does not duplicate registered students");
                    string autoResult = (string)Field(dialog, "automaticResultPath").GetValue(dialog);
                    Assert(Spreadsheet.Read(autoResult).Skip(1).All(r => r.Cells[8] == StudentImport.Status(ImportState.Connected)), "automatic result export contains final connection outcomes");
                    dialog.Close(); Pump(100);
                }
                Assert(accounts.All.All(a => a.VerifyState == "connected"), "background verifier processes durable jobs");
                Type queueType = assembly.GetType("MTManager.VerificationQueueDialog");
                using (var view = (Form)Activator.CreateInstance(queueType, new object[] { accounts, queue }))
                {
                    view.Show(); Pump(200);
                    var grid = (DataGridView)Field(view, "grid").GetValue(view);
                    Assert(grid.Rows.Count == 100, "queue displays all students");
                    Assert(!grid.Columns.Cast<DataGridViewColumn>().Any(c => c.HeaderText.Contains("Password")), "queue hides passwords");
                    queue.Pause(); Pump(1100); Assert(queue.Paused, "queue pauses without blocking window");
                    queue.Resume(false); Pump(100); Assert(!queue.Paused, "queue resumes");
                    view.Close(); Assert(!queue.Paused, "closing queue view does not pause service");
                }
            }
            // Recovered students remain visible in the main directory without terminal directories.
            var seeded = accounts.All.OrderBy(a => a.Instance).Take(3).ToArray();
            seeded[0].Mode = "master"; seeded[0].MasterEnc = Secret.Protect("MasterUiOnly!1"); seeded[0].Server = "Broker-Real2";
            seeded[1].Server = "Broker-Demo3"; seeded[2].Server = "WingoGroupLtd-server";
            foreach (var a in seeded) accounts.SetQueue(a);
            Type mainType = assembly.GetType("MTManager.MainForm");
            using (var main = (Form)Activator.CreateInstance(mainType, new object[] { settings, accounts }))
            {
                main.Show(); Pump(500);
                var list = (List<Instance>)Field(main, "copies").GetValue(main);
                Assert(list.Count == 100, "main screen includes unprovisioned students");
                var mainGrid = (DataGridView)Field(main, "grid").GetValue(main);
                Func<DataGridViewRow, string, object> rowValue = (r, name) => r.Tag.GetType().GetField(name).GetValue(r.Tag);
                Assert(mainGrid.Rows.Cast<DataGridViewRow>().Count(r => (bool)rowValue(r, "MasterLogin")) == 1, "only master accounts receive the M indicator");
                var choice = Field(main, "chosen").GetValue(main);
                choice.GetType().GetMethod("Toggle").Invoke(choice, new object[] { seeded[0].Instance }); Call(main, "RefreshGrid", false);
                var baseline = ((List<Instance>)Field(main, "shown").GetValue(main)).Select(i => i.Name).ToArray();
                var cycle = mainGrid.GetType().GetMethod("CycleHeaderSort");
                string focusBefore = mainGrid.CurrentRow == null ? "" : (string)rowValue(mainGrid.CurrentRow, "Name");
                cycle.Invoke(mainGrid, new object[] { "Server" }); Pump(50);
                Assert(focusBefore == (string)rowValue(mainGrid.CurrentRow, "Name"), "header sorting preserves focused student for keyboard actions");
                var categories = mainGrid.Rows.Cast<DataGridViewRow>().Select(r => ServerCategories.Of((string)rowValue(r, "Server"))).ToArray();
                Assert(categories[0] == ServerCategory.Demo && categories.Last() == ServerCategory.Unknown, "header server sort groups Demo then Real and unknown at end");
                Assert((bool)rowValue(mainGrid.Rows.Cast<DataGridViewRow>().First(r => (string)rowValue(r, "Name") == seeded[0].Instance), "Checked"), "sorting preserves student checkboxes");
                cycle.Invoke(mainGrid, new object[] { "Server" }); Pump(50);
                Assert(ServerCategories.Of((string)rowValue(mainGrid.Rows[0], "Server")) == ServerCategory.Real, "second header click reverses recognized server categories");
                cycle.Invoke(mainGrid, new object[] { "Server" }); Pump(50);
                Assert(((List<Instance>)Field(main, "shown").GetValue(main)).Select(i => i.Name).SequenceEqual(baseline), "third header click restores original row order");
                foreach (string column in new[] { "Trader", "Copy", "Login", "Folders", "Today", "Status" })
                {
                    cycle.Invoke(mainGrid, new object[] { column }); cycle.Invoke(mainGrid, new object[] { column }); cycle.Invoke(mainGrid, new object[] { column });
                    Assert(mainGrid.Rows.Count == 100, column + " header sorts in both directions without losing rows");
                }
                var results = (ReportRunSummary)Field(main, "reportResults").GetValue(main); results.Begin(); results.Add(seeded[0].Instance, seeded[0], Kind.MT5);
                var model = (ReportWorkProgress)Field(main, "reportWork").GetValue(main); model.Begin(); model.Add(seeded[0].Instance);
                Call(main, "ReadStep", seeded[0].Instance, StepState.Starting, "Starting test"); Pump(100);
                var strip = (Control)Field(main, "reportProgress").GetValue(main); var footer = (Control)Field(main, "statusLine").GetValue(main);
                Assert(strip.Visible && strip.Bottom <= footer.Top + 1, "continuous progress strip sits above original status footer");
                string initialCaption = (string)Field(strip, "caption").GetValue(strip);
                Pump(1200);
                Assert((string)Field(strip, "caption").GetValue(strip) != initialCaption, "elapsed time advances while an account stage stays unchanged");
                Assert(((System.Windows.Forms.Timer)Field(strip, "elapsedTimer").GetValue(strip)).Enabled, "elapsed timer runs independently of progress animation");
                Assert(model.Fraction > 0 && model.Fraction < 1, "single-student progress starts before the report finishes");
                Call(main, "ReadStep", seeded[0].Instance, StepState.Reading, "Reading test");
                Call(main, "ReadStep", seeded[0].Instance, StepState.Done, "Done");
                var fakeJob = new ReportJob { Copy = list.First(i => i.Name == seeded[0].Instance), Account = seeded[0] };
                Call(main, "ReadResult", null, fakeJob, new ReportRow { Journal = new AccountJournal() }); Pump(300);
                Assert(model.Complete && model.Fraction == 1, "single report fills the bar when done");
                results.Begin(); results.Add(seeded[0].Instance, seeded[0], Kind.MT5); results.Add(seeded[1].Instance, seeded[1], Kind.MT5);
                model.Begin(); model.Add(seeded[0].Instance); model.Add(seeded[1].Instance);
                Call(main, "ReadStep", seeded[0].Instance, StepState.Done, "Done");
                Call(main, "ReadResult", null, fakeJob, new ReportRow { Journal = new AccountJournal() }); Pump(700);
                Assert(results.Fresh == 1 && results.Pending == 1, "live progress counts distinguish fresh reports from remaining accounts");
                var failureJob = new ReportJob { Copy = list.First(i => i.Name == seeded[1].Instance), Account = seeded[1] };
                Call(main, "ReadResult", null, failureJob, new ReportRow { Error = "Could not connect" }); Pump(50);
                var failedRow = mainGrid.Rows.Cast<DataGridViewRow>().First(r => (string)rowValue(r, "Name") == seeded[1].Instance);
                Assert((string)rowValue(failedRow, "Status") != (Lang.En ? "Active" : "فعال"), "failed report never leaves an Active badge");
                Assert(results.Failed == 1 && results.Fresh == 1, "failed reports have a separate live count");
                results.Begin(); results.Add(seeded[0].Instance, seeded[0], Kind.MT5); results.Add(seeded[1].Instance, seeded[1], Kind.MT5);
                model.Begin(); model.Add(seeded[0].Instance); model.Add(seeded[1].Instance);
                results.Record(seeded[0].Instance, new ReportRow { Journal = new AccountJournal() }); model.Update(seeded[0].Instance, StepState.Done);
                Call(main, "StopReports"); Pump(100);
                Assert(results.Finished && results.Fresh == 1 && results.Stopped == 1, "stop retains the completed report and counts the unattempted student");
                string stoppedCaption = (string)Field(strip, "caption").GetValue(strip);
                long stoppedElapsed = results.ElapsedMs; Pump(1100);
                Assert(results.ElapsedMs == stoppedElapsed && (string)Field(strip, "caption").GetValue(strip) == stoppedCaption, "stopped run keeps its final elapsed time");
                Assert(!((System.Windows.Forms.Timer)Field(strip, "elapsedTimer").GetValue(strip)).Enabled, "elapsed timer stops after batch cleanup completes");
                Assert(stoppedCaption.Contains(results.ElapsedText), "final elapsed duration stays visible in the inline result");
                Assert(File.Exists(results.SavedPath), "stopped summary is saved to Excel automatically");
                Assert(main.OwnedForms.Length == 0, "stopping reports does not open another window");
                Assert(strip.Controls.Cast<Control>().All(c => c.Text != "Results" && c.Text != "نتیجه‌ها"), "no result button is shown in the progress strip");
                Assert(results.Counts().Contains("1") || results.Counts().Contains("۱"), "stopped report counts remain available inline");
                // Recreate a half-complete live preview after validating stop behavior.
                results.Begin(); results.Add(seeded[0].Instance, seeded[0], Kind.MT5); results.Add(seeded[1].Instance, seeded[1], Kind.MT5);
                model.Begin(); model.Add(seeded[0].Instance); model.Add(seeded[1].Instance);
                model.Update(seeded[0].Instance, StepState.Done); results.Record(seeded[0].Instance, new ReportRow { Journal = new AccountJournal() });
                Call(main, "ReadStep", seeded[0].Instance, StepState.Done, "Done"); Pump(700);
                Assert(Math.Abs(model.Fraction - 0.5) < 0.001, "one completed out of two reports shows half-full progress");
                cycle.Invoke(mainGrid, new object[] { "Server" }); Pump(200);
                using (var shot = new System.Drawing.Bitmap(main.Width, main.Height))
                {
                    using (var graphics = System.Drawing.Graphics.FromImage(shot)) graphics.CopyFromScreen(main.Location, System.Drawing.Point.Empty, main.Size);
                    shot.Save("/workspace/MetaFactory-delivery/MetaFactory-3.42.0-preview-ui-" + (Lang.En ? "en" : "fa") + ".png");
                }
                var mainFolders = (FolderStore)Field(main, "folders").GetValue(main);
                var folderA = mainFolders.Create("Folder A"); var folderB = mainFolders.Create("Folder B"); mainFolders.Save();
                var subject = mainGrid.Rows.Cast<DataGridViewRow>().First(r => (string)rowValue(r, "Name") == seeded[0].Instance).Tag;
                Call(main, "ShowRowMenu", subject, mainGrid.PointToScreen(new System.Drawing.Point(50, 60))); Pump(60);
                var menu = (ContextMenuStrip)Field(main, "rowMenu").GetValue(main);
                var add = (ToolStripMenuItem)Field(main, "miAddTo").GetValue(main);
                Assert(menu.Items.Contains(add), "Add to folder is directly in the student menu");
                Assert(!menu.Items.OfType<ToolStripMenuItem>().Any(i => i.Text == "Folder" || i.Text == "پوشه" || i.Text.Contains("Move to folder") || i.Text.Contains("انتقال به پوشه")), "old Folder nesting and Move command are absent");
                add.ShowDropDown(); Pump(100);
                Assert(Math.Min(Math.Abs(add.DropDown.Left - menu.Right), Math.Abs(add.DropDown.Right - menu.Left)) <= 1, "folder submenu shares its parent's edge with no gap");
                add.DropDown.Location = new System.Drawing.Point(add.DropDown.Left + 24, add.DropDown.Top); Pump(150);
                Assert(Math.Min(Math.Abs(add.DropDown.Left - menu.Right), Math.Abs(add.DropDown.Right - menu.Left)) <= 1, "submenu realigns after a late framework placement offset");
                var checks = add.DropDownItems.OfType<ToolStripMenuItem>().Where(i => i.Tag is Folder).ToArray();
                checks.First(i => ((Folder)i.Tag).Id == folderA.Id).PerformClick(); Pump(100);
                Assert(menu.Visible && add.DropDown.Visible, "folder checkbox leaves the menu open for more selections");
                checks.First(i => ((Folder)i.Tag).Id == folderB.Id).PerformClick(); Pump(100);
                Assert(mainFolders.Has(folderA.Id, seeded[0].Instance) && mainFolders.Has(folderB.Id, seeded[0].Instance), "one student can be added to two folders without moving out of the first");
                checks.First(i => ((Folder)i.Tag).Id == folderA.Id).PerformClick(); Pump(100);
                Assert(!mainFolders.Has(folderA.Id, seeded[0].Instance) && mainFolders.Has(folderB.Id, seeded[0].Instance), "unticking one folder preserves other memberships");
                var storedFolders = FolderStore.Load(); Assert(storedFolders.Has(folderB.Id, seeded[0].Instance) && !storedFolders.Has(folderA.Id, seeded[0].Instance), "folder checkbox changes persist on disk");
                using (var shot = new System.Drawing.Bitmap(main.Width, main.Height))
                {
                    using (var graphics = System.Drawing.Graphics.FromImage(shot)) graphics.CopyFromScreen(main.Location, System.Drawing.Point.Empty, main.Size);
                    shot.Save("/workspace/MetaFactory-delivery/MetaFactory-3.42.0-folders-" + (Lang.En ? "en" : "fa") + ".png");
                }
                menu.Close(ToolStripDropDownCloseReason.Keyboard); Pump(50);
                Assert(!menu.Visible, "folder checkbox menu still closes with Escape/outside close reasons");
                var tools = (ContextMenuStrip)Field(main, "toolsMenu").GetValue(main);
                Assert(!tools.Items.OfType<ToolStripMenuItem>().Any(i => i.Text.Contains("set aside") || i.Text.Contains("کنار گذاشته") || i.Text.Contains("Latest report results")), "tools no longer includes the removed chart and result commands");
                Assert(tools.Items.OfType<ToolStripMenuItem>().Any(i => i.Text.Contains("Export report diagnostics") || i.Text.Contains("خروجی عیب‌یابی گزارش")), "tools exposes one report diagnostics export command in the current language");
                var configured = new Settings { BaseDir = settings.BaseDir, ReportAtOnce = 4 };
                using (var preferences = (Form)Activator.CreateInstance(assembly.GetType("MTManager.SettingsDialog"), new object[] { configured }))
                {
                    preferences.Show(main); Pump(80);
                    object dropdown = Field(preferences, "reportAtOnce").GetValue(preferences);
                    var selectedProperty = dropdown.GetType().GetProperty("SelectedIndex");
                    Assert((int)dropdown.GetType().GetProperty("Count").GetValue(dropdown, null) == 5, "report settings offer automatic plus one, two, three and four workers");
                    Assert((int)selectedProperty.GetValue(dropdown, null) == 4, "saved four-worker ceiling remains selected in settings");
                    selectedProperty.SetValue(dropdown, 3, null);
                    Assert((int)selectedProperty.GetValue(dropdown, null) == 3, "three-worker ceiling can be selected");
                    preferences.Close(); Pump(30);
                }
                var busyRun = new ReportRunner(settings, new List<ReportJob>(), new List<Instance>(), name => null, new ReportRange(), 1);
                Field(main, "report").SetValue(main, busyRun); Call(main, "ReadMany", list, "Current list");
                Assert(ReferenceEquals(Field(main, "report").GetValue(main), busyRun) && ((List<string>)Field(main, "readQueue").GetValue(main)).Count == 0, "separate platform selection never appends accounts to an active run");
                Field(main, "report").SetValue(main, null);
                Type scopeType = assembly.GetType("MTManager.ReportScopeDialog");
                foreach (string field in new[] { "mt4", "mt5", "all" })
                using (var scopeDialog = (Form)Activator.CreateInstance(scopeType, new object[] { 2, 3, Lang.En ? "Selected students" : "انتخاب‌شده‌ها" }))
                {
                    scopeDialog.Show(main); Pump(60);
                    if (field == "mt4") using (var capture = new System.Drawing.Bitmap(scopeDialog.Width, scopeDialog.Height))
                    {
                        using (var graphics = System.Drawing.Graphics.FromImage(capture)) graphics.CopyFromScreen(scopeDialog.Location, System.Drawing.Point.Empty, scopeDialog.Size);
                        capture.Save("/workspace/MetaFactory-delivery/MetaFactory-3.42.0-report-platforms-" + (Lang.En ? "en" : "fa") + ".png");
                    }
                    var button = (Button)Field(scopeDialog, field).GetValue(scopeDialog); Assert(button.Enabled, "available platform scopeDialog is enabled: " + field);
                    button.PerformClick(); Pump(40);
                    object picked = scopeType.GetProperty("Platform").GetValue(scopeDialog, null);
                    Assert(scopeDialog.DialogResult == DialogResult.OK && (field == "all" ? picked == null : (Kind)picked == (field == "mt4" ? Kind.MT4 : Kind.MT5)), "report confirmation applies platform scopeDialog: " + field);
                    scopeDialog.Close();
                }
                using (var scopeDialog = (Form)Activator.CreateInstance(scopeType, new object[] { 0, 3, "Current list" }))
                {
                    scopeDialog.Show(main); Pump(50);
                    Assert(!((Button)Field(scopeDialog, "mt4").GetValue(scopeDialog)).Enabled && ((Button)Field(scopeDialog, "mt5").GetValue(scopeDialog)).Enabled, "platform without eligible accounts is disabled");
                    ((Button)scopeDialog.CancelButton).PerformClick(); Assert(scopeDialog.DialogResult == DialogResult.Cancel, "platform confirmation supports cancel without selecting a run"); scopeDialog.Close();
                }
                bool scopeReservedDuringDialog = false;
                using (var cancelScope = new System.Windows.Forms.Timer { Interval = 100 })
                {
                    cancelScope.Tick += (s, e) => {
                        Form scopeDialog = Application.OpenForms.Cast<Form>().FirstOrDefault(f => f.GetType() == scopeType);
                        if (scopeDialog != null) { scopeReservedDuringDialog = (bool)Field(main, "isolateManualReports").GetValue(main); cancelScope.Stop(); ((Button)scopeDialog.CancelButton).PerformClick(); }
                    };
                    cancelScope.Start(); Call(main, "ReadMany", list, "Current list");
                    Assert(Field(main, "report").GetValue(main) == null && ((List<string>)Field(main, "readQueue").GetValue(main)).Count == 0, "cancel from the real main report command does not queue accounts or start terminals");
                }
                Assert(scopeReservedDuringDialog && !(bool)Field(main, "isolateManualReports").GetValue(main), "manual platform confirmation excludes automatic folder batches and releases isolation on cancel");
                main.Close(); Pump(100);
            }
            Console.WriteLine(count + " UI checks passed"); return 0;
        }
        catch (Exception e) { Console.WriteLine(e); return 1; }
        finally { try { Directory.Delete(root, true); } catch { } }
    }
}
