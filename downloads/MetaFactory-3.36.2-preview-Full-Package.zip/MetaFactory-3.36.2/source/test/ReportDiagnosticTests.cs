using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;

namespace MTManager
{
    static partial class Tests
    {
        static void ReportDiagnosticChecks()
        {
            string previous = AppPaths.DataDirOverride;
            try
            {
                AppPaths.DataDirOverride = Dir("report-diagnostic-store");
                const string master = "MasterSecret!901", investor = "InvestorSecret@902";
                var job = new ReportJob
                {
                    Index = 3, Attempt = 1, Name = "Synthetic student",
                    Copy = new Instance { Name = "MT5-12", Kind = Kind.MT5, Dir = Dir("diagnostic-student") },
                    Account = new Account { Login = "123456", Server = "Broker-Demo", MasterEnc = Secret.Protect(master), InvestorEnc = Secret.Protect(investor) }
                };
                var run = new ReportDiagnostics(new[] { job }, 4);
                Check(Directory.Exists(run.DirectoryPath), "diagnostic run is persisted separately from credentials");
                Equal("[REDACTED] / [REDACTED]", run.Redact(master + " / " + investor), "diagnostics scrub both saved password modes, not just current login mode");
                Check(!run.Redact("Password=an-unregistered-secret\naccess_token: another-secret").Contains("an-unregistered-secret") && !run.Redact("access_token: another-secret").Contains("another-secret"), "diagnostics scrub explicit credential assignments even when not registered");
                run.BeginAttempt(job, DateTime.Now.AddMinutes(-30));
                run.Timing(job, "login", 1250, "fresh IPC login");
                run.Timing(job, "reporter-start", 45000, "no first native progress");
                run.Result(job, new ReportRow { Error = "reporter did not start", TotalMs = 60000 }, "REPORTER_START_TIMEOUT");
                Check(File.ReadAllText(Path.Combine(run.DirectoryPath, "summary.txt")).Contains("MT5: requested=1; fresh=0; failed=1"), "each completed attempt persists a readable summary checkpoint before export or Finish");
                run.Stage(job, "native.ready", "A report may fail although a previous report succeeded. " + master);
                run.Stage(job, "large-event", new string('z', 100000));
                Check(new FileInfo(Path.Combine(run.DirectoryPath, "events.tsv")).Length < 6000, "a large diagnostic detail is bounded before it is written");
                var privateCopy = new Instance { Kind = Kind.MT5, Name = "private", Dir = Dir("diagnostic-base", "_MTManager", "report", "MT5-Broker-Demo-1") };
                DateTime begun = DateTime.Today.AddHours(1);
                Directory.CreateDirectory(Path.Combine(privateCopy.Dir, "logs"));
                Directory.CreateDirectory(Path.Combine(privateCopy.Dir, "MQL5", "Logs"));
                string journal = ConnectionCheck.JournalFile(privateCopy, DateTime.Today), experts = ReportTrace.ProgramsLog(privateCopy, DateTime.Today);
                File.WriteAllText(journal, "00:01:00 old attempt\n01:01:00 authorized with " + investor + "\n01:01:01 password=unregistered-secret\n", Encoding.Unicode);
                File.WriteAllText(experts, "01:01:03 MTManagerReport initialization failed\n", Encoding.Unicode);
                run.Capture(job, privateCopy, begun, "warm");
                job.Attempt = 2;
                run.BeginAttempt(job);
                run.Timing(job, "history", 12000, "history request still waiting");
                run.Capture(job, privateCopy, begun, "cold-retry");
                string[] snapshots = Directory.GetFiles(run.DirectoryPath, "native-*.txt");
                Equal(2, snapshots.Length, "each native capture retains a separate attempt snapshot even for a reused private terminal");
                string evidence = string.Join("\n", snapshots.Select(File.ReadAllText));
                Check(evidence.Contains("authorized") && evidence.Contains("initialization failed") && !evidence.Contains("old attempt"), "native diagnostics retain Journal and Experts for the actual attempt only");
                Check(!evidence.Contains(master) && !evidence.Contains(investor) && !evidence.Contains("unregistered-secret"), "native credentials are redacted before persistence");
                run.Capture(job, job.Copy, begun, "student-terminal");
                Equal(2, Directory.GetFiles(run.DirectoryPath, "native-*.txt").Length, "diagnostics refuse student terminals outside the private report folder");
                run.Result(job, new ReportRow { Cached = true, Journal = new AccountJournal { Exported = DateTime.Now.AddMinutes(-30) }, Note = "no fresh result", ReadMs = 0, TotalMs = 45000 }, "REPORTER_START_TIMEOUT");
                // Receiving the same final accounting result again must not double service totals.
                run.Result(job, new ReportRow { Cached = true, Journal = new AccountJournal { Exported = DateTime.Now.AddMinutes(-30) }, Note = "no fresh result", ReadMs = 0, TotalMs = 45000 }, "REPORTER_START_TIMEOUT");
                Check(File.ReadAllText(Path.Combine(run.DirectoryPath, "results.tsv")).Contains("previous-only") && File.ReadAllText(Path.Combine(run.DirectoryPath, "results.tsv")).Contains("REPORTER_START_TIMEOUT"), "cached previous success remains distinct from this attempt's fresh failure and reason code");
                string token = new string('a', 32), pulsePath = ReportLaunch.OutputPath(privateCopy) + ".pulse";
                Directory.CreateDirectory(Path.GetDirectoryName(pulsePath));
                File.WriteAllText(pulsePath, "MTP\t1\nQ\t" + token + "\nA\t123456\tBroker-Demo\nS\thistory-select\nT\t1794900000\t12000\nC\t123456\tBroker-Demo\t1\nEND\n", Encoding.Unicode);
                run.Capture(job, privateCopy, begun, "pulse-current", token);
                string pulseCapture = Directory.GetFiles(run.DirectoryPath, "native-*.txt").OrderBy(f => f).Select(File.ReadAllText).Last();
                Check(pulseCapture.Contains("current-request-pulse") && pulseCapture.Contains("stage=history-select") && pulseCapture.Contains("matching_account_connected=True"), "diagnostic native pulse requires and records matching current request identity and exact history stage");
                run.Capture(job, privateCopy, begun, "pulse-old", new string('b', 32));
                string staleCapture = Directory.GetFiles(run.DirectoryPath, "native-*.txt").OrderBy(f => f).Select(File.ReadAllText).Last();
                Check(staleCapture.Contains("pulse-unverified") && !staleCapture.Contains("current-request-pulse"), "previous request pulse cannot become fresh current-account evidence");
                File.WriteAllText(Path.Combine(run.DirectoryPath, "accounts.ini"), "Password=DO-NOT-EXPORT");
                File.WriteAllText(Path.Combine(run.DirectoryPath, "unrelated.txt"), "DO-NOT-EXPORT");
                string archive = Path.Combine(AppPaths.DataDir, "support.zip");
                ReportDiagnostics.ExportLatest(archive);
                using (var file = File.OpenRead(archive))
                using (var zip = new ZipArchive(file, ZipArchiveMode.Read))
                {
                    Check(zip.GetEntry("manifest.txt") != null && zip.GetEntry("events.tsv") != null && zip.GetEntry("results.tsv") != null, "active-run ZIP includes consistent generated manifest/events/results");
                    Check(zip.GetEntry("summary.txt") != null && zip.GetEntry("timings.tsv") != null && zip.GetEntry("evidence.tsv") != null, "ZIP includes readable summary, explicit timing spans and structured observed evidence");
                    Check(zip.GetEntry("accounts.ini") == null && zip.GetEntry("unrelated.txt") == null, "diagnostic ZIP exports only generated whitelist files, never stray account configuration");
                    foreach (var entry in zip.Entries)
                        using (var reader = new StreamReader(entry.Open()))
                        {
                            string contents = reader.ReadToEnd();
                            Check(!contents.Contains(master) && !contents.Contains(investor) && !contents.Contains("DO-NOT-EXPORT"), "export is password-safe: " + entry.FullName);
                        }
                }
                run.Finish(); run.Stage(job, "late", "must not be written");
                string summary = File.ReadAllText(Path.Combine(run.DirectoryPath, "summary.txt"));
                Check(summary.Contains("State: finished") && summary.Contains("MT5: requested=1; fresh=0; failed=0; previous-only=1") && summary.Contains("Started attempts=2; additional retry passes=1"), "summary separates final cached outcome from both actual attempts and retry count");
                Check(summary.Contains("Completed attempt service time=1m 45s") && summary.Contains("unsuccessful attempt service time=1m 45s"), "repeated results do not double-count attempt service totals");
                Check(summary.Contains("MT5 / reporter-start = 0m 45s (45000 ms)") && summary.Contains("Wall-clock elapsed"), "summary distinguishes precisely measured startup time from real whole-run wall time");
                Check(!File.ReadAllText(Path.Combine(run.DirectoryPath, "events.tsv")).Contains("must not be written"), "finished diagnostic runs reject late stage events");
                string large = string.Join("\n", Enumerable.Range(0, 1000).Select(n => "01:02:03 line " + n + " " + new string('x', 500)));
                File.WriteAllText(journal, large, Encoding.Unicode);
                var tail = ReportDiagnostics.Tail(journal, DateTime.Today, begun);
                Check(tail.Count <= 96 && tail.Last().Contains("line 999") && !tail.Any(l => l.Contains("line 0 ")), "native log reads are bounded to a tail and retain newest evidence");
                var timeoutEvidence = ReportDiagnostics.NativeEvidence(new[] { "Journal: '123456': authorization failed (No connection)", "Experts: MTManagerReport start timed out" }, "123456");
                Check(!timeoutEvidence.ContainsKey("login-rejected-explicit") && timeoutEvidence.ContainsKey("connection-failure-observed"), "network/startup timeouts never diagnose a wrong password or explicit login rejection");
                var otherAccount = ReportDiagnostics.NativeEvidence(new[] { "Journal: '999': invalid password", "Journal: '123456': authorized on Broker-Demo", "Experts: MTManagerReport initialization failed" }, "123456");
                Check(!otherAccount.ContainsKey("login-rejected-explicit") && otherAccount.ContainsKey("login-confirmed-observed") && otherAccount.ContainsKey("reporter-initialization-failed"), "evidence distinguishes successful current-account login plus reporter failure from another account's rejection");
                Check(ReportDiagnostics.NativeEvidence(new[] { "Journal: '123456': invalid password" }, "123456").ContainsKey("login-rejected-explicit"), "explicit current-account rejection remains visible as observed evidence");
                var unclear = ReportDiagnostics.NativeEvidence(new[] { "Journal: '123456': authorization failed (unexpected error)" }, "123456");
                Check(unclear.ContainsKey("login-failure-unclassified") && !unclear.ContainsKey("login-rejected-explicit"), "generic authorization failure stays unclassified rather than being called bad credentials");
                Check(ReportDiagnostics.NativeEvidence(new[] { "terminal still running" }, "123456").ContainsKey("unknown"), "insufficient evidence remains explicitly unknown");
                var lifecycle = ReportDiagnostics.NativeEvidence(new[] { "Experts: MTManagerReport lifecycle: OnInit, build 6295; symbol EURUSD@", "Experts: MTManagerReport lifecycle: OnDeinit, reason 6" }, "123456");
                Check(lifecycle.ContainsKey("reporter-init-observed") && lifecycle.ContainsKey("reporter-deinit-observed"), "native lifecycle prints distinguish reporter initialization and deinitialization when pulse evidence is missing");
                Check(!lifecycle.ContainsKey("reporter-initialization-failed") && !lifecycle.ContainsKey("login-rejected-explicit"), "normal OnInit and OnDeinit observations are not treated as initialization or login failures");
                var four = new ReportJob { Index = 8, Attempt = 1, Name = "MT4 test", Copy = new Instance { Kind = Kind.MT4, Name = "MT4-test" }, Account = new Account { Login = "44", Server = "Broker-Demo" } };
                var mixed = new ReportDiagnostics(new[] { job, four }, 2);
                mixed.BeginAttempt(four); mixed.BeginAttempt(job);
                mixed.Result(four, new ReportRow { Journal = new AccountJournal(), TotalMs = 9000, ReadMs = 7000 });
                mixed.Result(job, new ReportRow { Error = "unknown history wait", TotalMs = 31000 }, "history-timeout");
                mixed.Finish();
                string mixedSummary = File.ReadAllText(Path.Combine(mixed.DirectoryPath, "summary.txt"));
                Check(mixedSummary.Contains("MT4: requested=1; fresh=1; failed=0") && mixedSummary.Contains("MT5: requested=1; fresh=0; failed=1"), "diagnostic summary keeps MT4 success counts separate from MT5 failures");
                for (int i = 0; i < 6; i++) new ReportDiagnostics(new[] { job }, 1).Finish();
                int manifests = Directory.GetDirectories(Path.Combine(AppPaths.DataDir, "report-diagnostics")).Count(d => File.Exists(Path.Combine(d, "manifest.txt")));
                Equal(5, manifests, "diagnostics retain at most five generated runs");
                Check(File.Exists(Path.Combine(run.DirectoryPath, "unrelated.txt")), "retention never deletes unrelated user-added files");
            }
            finally { AppPaths.DataDirOverride = previous; }
        }
    }
}
