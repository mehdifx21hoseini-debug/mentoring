using System;using System.Globalization;using System.Linq;
namespace MTManager
{
    internal static class AccountRowPresentation
    {
        static bool Finite(double n){return !double.IsNaN(n)&&!double.IsInfinity(n);}
        static string Number(double n){return double.IsNaN(n)||n<0?"—":double.IsPositiveInfinity(n)?"∞":Finite(n)?n.ToString("0.00",CultureInfo.InvariantCulture):"—";}
        internal static bool Bound(Instance copy,Account account,AccountJournal journal)
        {return copy!=null&&account!=null&&account.HasLogin&&journal!=null&&journal.Complete&&journal.Platform==copy.Kind.ToString()&&journal.Login==(account.Login??"").Trim()&&string.Equals(journal.Server,(account.Server??"").Trim(),StringComparison.OrdinalIgnoreCase);}
        internal static DateTime UtcTrade(DateTime trade,AccountJournal journal)
        {if(trade==DateTime.MinValue||!journal.GmtOffset.HasValue||Math.Abs((long)journal.GmtOffset.Value)>18*3600)return DateTime.MinValue;try{return DateTime.SpecifyKind(trade.AddSeconds(-journal.GmtOffset.Value),DateTimeKind.Utc);}catch(ArgumentOutOfRangeException){return DateTime.MinValue;}}
        internal static void Apply(CopyRow row,Instance copy,Account account,AccountJournal journal,PanelView view,DateTime readAt)
        {
            row.AccountBalance="Balance —";row.AccountDrawdown="Overall DD —";row.AccountInfoTip=Lang.T("گزارش معتبر در دسترس نیست.","No verified report available.");row.TradeOpen=false;row.LastTradeUtc=DateTime.MinValue;
            if(!Bound(copy,account,journal))return;
            if(Finite(journal.Balance))row.AccountBalance="Balance "+PanelMath.Amount(journal.Balance,journal.Currency);
            bool full=Finite(journal.Balance)&&journal.HistoryChecked&&journal.HistoryOk&&journal.FullHistoryPresent&&journal.FullHistoryValid&&journal.FullHistoryReconciled&&journal.FullHistoryScanOk&&view!=null&&view.ReadAt==journal.Exported;
            double dd=full&&view!=null&&view.AccountDdComplete&&Finite(view.AccountDdPct)&&view.AccountDdPct>=0?view.AccountDdPct:double.NaN;
            if(!double.IsNaN(dd))row.AccountDrawdown="Overall DD "+dd.ToString("0.00",CultureInfo.InvariantCulture)+"%";
            string factor=full&&(copy.Kind==Kind.MT4||journal.AccountPfPresent&&journal.AccountPfValid)?Number(view.ProfitFactor):"—";
            bool history=journal.HistoryChecked&&journal.HistoryOk;
            if(history)
            {
                row.TradeOpen=journal.Open.Count>0;
                DateTime recent=journal.Trades.Select(t=>t.Close).Where(t=>t<=journal.Exported).DefaultIfEmpty(DateTime.MinValue).Max();
                if(journal.LastTrade<=journal.Exported&&journal.LastTrade>recent)recent=journal.LastTrade;
                if(row.TradeOpen){var opened=journal.Open.Select(t=>t.Open).Where(t=>t<=journal.Exported).DefaultIfEmpty(DateTime.MinValue).Max();if(opened>recent)recent=opened;}
                row.LastTradeUtc=UtcTrade(recent,journal);
            }
            row.AccountInfoTip=Lang.T("بالانس: ","Balance: ")+(Finite(journal.Balance)?PanelMath.Amount(journal.Balance,journal.Currency):"—")+"\r\n"+Lang.T("دراودان کل حساب: ","Overall account DD: ")+(double.IsNaN(dd)?"—":dd.ToString("0.00",CultureInfo.InvariantCulture)+"%")+"\r\n"+Lang.T("پروفیت فاکتور کل: ","Overall profit factor: ")+factor+"\r\n"+Lang.T("معاملات باز در گزارش: ","Open positions in report: ")+(history?Fa.N(journal.Open.Count):"—")+"\r\n"+Lang.T("زمان گزارش: ","Report time: ")+(readAt==DateTime.MinValue?"—":readAt.ToString("yyyy-MM-dd HH:mm",CultureInfo.InvariantCulture));
            if(!double.IsNaN(dd))row.AccountInfoTip+="\r\n"+Lang.T("افت نسبی بالانس؛ کل تاریخچهٔ تأییدشده","Relative balance drawdown; verified whole history");
        }
        internal static string TradeCounts(int? closed,int? open)
        {return Lang.T("بسته: ","Closed: ")+(closed.HasValue?Fa.N(closed.Value):"—")+" · "+Lang.T("باز: ","Open: ")+(open.HasValue?Fa.N(open.Value):"—");}
        internal static string ClosedToday(PanelView view)
        {if(view==null||!Finite(view.ClosedNet))return "—";return view.Closed==0?Lang.T("بدون معاملهٔ بسته","No closed trades"):PanelMath.Money(view.ClosedNet,view.Currency)+" · "+Fa.N(view.Closed)+Lang.T(" معامله"," trades");}
    }
}
