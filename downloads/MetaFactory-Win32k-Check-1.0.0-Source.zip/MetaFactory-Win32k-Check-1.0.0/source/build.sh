#!/bin/sh
set -e
R="-r:System.Core -r:System.Web.Extensions"
if [ -n "${MF_REF45:-}" ]; then
 R="-nostdlib -noconfig -r:$MF_REF45/mscorlib.dll -r:$MF_REF45/System.dll -r:$MF_REF45/System.Core.dll -r:$MF_REF45/System.Web.Extensions.dll"
fi
mcs -optimize+ -platform:anycpu -target:winexe $R -out:MetaFactory-Win32k-Check-1.0.0.exe Win32kCheck.cs
mcs -optimize+ $R -r:MetaFactory-Win32k-Check-1.0.0.exe -out:Tests.exe Tests.cs
mono Tests.exe
