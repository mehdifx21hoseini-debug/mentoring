using System;using System.IO;using System.Linq;using System.Collections.Generic;using MetaFactoryWin32kCheck;
class Tests
{
 sealed class Reader:IReader
 {
  public Queue<Row> Rows=new Queue<Row>();public bool Disposed;public Exception Failure;
  public Row Next(){if(Failure!=null)throw Failure;return Rows.Count>0?Rows.Dequeue():null;}public void Dispose(){Disposed=true;}
 }
 static int checks;static void Check(bool yes,string why){if(!yes)throw new Exception(why);checks++;Console.WriteLine("PASS "+why);}
 static int Main()
 {
  string root=Path.Combine(Path.GetTempPath(),"mf-win32k-test-"+Guid.NewGuid().ToString("N"));
  try
  {
   var reader=new Reader();reader.Rows.Enqueue(new Row{Id=243,Provider="OtherProvider",Description="PRIVATE_CANARY"});reader.Rows.Enqueue(new Row{Id=243,Provider="Win32k",TimeUtc="2026-11-25T12:00:00Z",Description="A desktop heap allocation failed. Session ID:1"});
   var r=Collector.Collect(()=>reader);
   Check(r.Events.Count==1&&!r.Events.Any(x=>x.Provider=="OtherProvider"),"only exact Windows provider243 collected");
   Check(r.Events[0].TimeUtc.StartsWith("2026-11-25"),"older retained session event is not excluded by current launch time");
   Check(r.Completed&&!r.LimitReached&&reader.Disposed,"completed scan releases event reader");
   Check(Collector.Relevant(new Row{Id=243,Provider="Microsoft-Windows-Win32k"}),"modern Win32k provider accepted");
   Check(!Collector.Relevant(new Row{Id=1000,Provider="Win32k"}),"other event IDs never included");
   var none=Collector.Collect(()=>new Reader());Check(none.Status.Contains("not_proof_of_absence"),"no matching events is not clean bill of health");
   var denied=Collector.Collect(()=>{throw new System.ComponentModel.Win32Exception(5);});Check(denied.NativeError==5&&denied.Status.Contains("read_failed"),"access denial distinct from missing events");
   var bad=new Reader{Failure=new InvalidOperationException()};var partial=Collector.Collect(()=>bad);Check(bad.Disposed&&partial.ErrorType=="InvalidOperationException","read failure still closes reader and is explicit");
   var many=new Reader();for(int i=0;i<100;i++)many.Rows.Enqueue(new Row{Id=243,Provider="Win32k"});var limited=Collector.Collect(()=>many);
   Check(limited.Events.Count==64&&limited.LimitReached,"matching history is bounded and marked incomplete");
   var other=new Reader();for(int i=0;i<300;i++)other.Rows.Enqueue(new Row{Id=243,Provider="Other"});limited=Collector.Collect(()=>other);Check(limited.Examined==256&&limited.LimitReached,"candidate scan is bounded even for other providers");
   string path=Collector.Write(root,r);Check(!File.ReadAllText(path).Contains("PRIVATE_CANARY"),"unrelated-provider descriptions excluded from exported file");
   Check(new FileInfo(path).Length<=256*1024,"output file within256KB");
   Collector.Write(root,none);Check(File.Exists(Path.Combine(root,"MetaFactory-Win32k-Events-previous.txt")),"one owned previous report retained");
   string foreign=Path.Combine(root,"foreign");Directory.CreateDirectory(foreign);string f=Path.Combine(foreign,"MetaFactory-Win32k-Events.txt");File.WriteAllText(f,"USER_FILE");bool stopped=false;try{Collector.Write(foreign,r);}catch(IOException){stopped=true;}Check(stopped&&File.ReadAllText(f)=="USER_FILE","unknown file ownership preserved");
   Console.WriteLine("WIN32K CHECK PASS "+checks+" (synthetic reader; actual Windows event retrieval not run)");return 0;
  }
  catch(Exception e){Console.Error.WriteLine(e);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
