using System;using System.IO;using System.Text;using System.Linq;using System.Diagnostics;using System.Diagnostics.Eventing.Reader;using System.Collections.Generic;using System.Globalization;using System.Runtime.InteropServices;using System.Web.Script.Serialization;using System.Reflection;
[assembly:AssemblyTitle("MetaFactory Win32k Event Check")]
[assembly:AssemblyVersion("1.0.0.0")]
[assembly:AssemblyFileVersion("1.0.0.0")]
namespace MetaFactoryWin32kCheck
{
 public sealed class Row
 {
  public string Provider,TimeUtc,Description,DescriptionError;
  public int Id;public long? RecordId;public int? EventProcessId,EventThreadId;
 }
 public interface IReader:IDisposable{Row Next();}
 public sealed class WindowsReader:IReader
 {
  readonly EventLogReader reader;
  public WindowsReader(){reader=new EventLogReader(new EventLogQuery("System",PathType.LogName,"*[System[(EventID=243)]]"){ReverseDirection=true,TolerateQueryErrors=false});}
  public Row Next()
  {
   using(EventRecord e=reader.ReadEvent(TimeSpan.FromSeconds(2)))
   {
    if(e==null)return null;
    var row=new Row{Provider=e.ProviderName,Id=e.Id,RecordId=e.RecordId,TimeUtc=e.TimeCreated.HasValue?e.TimeCreated.Value.ToUniversalTime().ToString("o",CultureInfo.InvariantCulture):"unknown",EventProcessId=e.ProcessId,EventThreadId=e.ThreadId};
    // Fetch description only for the specific Windows provider/event under investigation.
    if(Collector.Relevant(row))try{string s=e.FormatDescription()??"";row.Description=s.Length<=2048?s:s.Substring(0,2048)+" [clipped]";}catch(Exception error){row.DescriptionError=error.GetType().Name;}
    return row;
   }
  }
  public void Dispose(){reader.Dispose();}
 }
 public sealed class Result
 {
  public string Schema="MF_WIN32K_EVENT_REPORT_1",Version="1.0.0",CapturedUtc,Status,ErrorType,HResult;
  public int? NativeError;
  public int Examined;public bool LimitReached,Completed;
  public List<Row> Events=new List<Row>();
  public string Scope="Existing System-log Win32k event243 only; no rerun/registry/process/window/network changes. At most256 matching-ID candidates/64Win32k events/10seconds; reads retained history, not just latest MetaFactory batch.";
  public string Interpretation="Presence must be checked against event time, process and session before attribution. Absence/limited access cannot rule out resource exhaustion. EventProcessId may identify the event writer, not the failing terminal; inspect the Windows description.";
 }
 public static class Collector
 {
  public static bool Relevant(Row r){return r!=null&&r.Id==243&&(string.Equals(r.Provider,"Win32k",StringComparison.OrdinalIgnoreCase)||string.Equals(r.Provider,"Microsoft-Windows-Win32k",StringComparison.OrdinalIgnoreCase));}
  public static Result Collect(Func<IReader> open)
  {
   var result=new Result{CapturedUtc=DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture)};var time=Stopwatch.StartNew();
   try
   {
    using(var reader=open())
    {
     while(result.Examined<256&&result.Events.Count<64&&time.Elapsed<TimeSpan.FromSeconds(10))
     {
      Row row=reader.Next();if(row==null){result.Completed=true;break;}result.Examined++;
      if(Relevant(row))result.Events.Add(row);
     }
    }
    result.LimitReached=!result.Completed;
    result.Status=result.Events.Count>0?"matching_events_found_check_time_and_session":"no_matching_event_in_available_scan_not_proof_of_absence";
   }
   catch(Exception error)
   {
    result.Status="event_log_read_failed_not_a_heap_diagnosis";result.ErrorType=error.GetType().Name;result.HResult="0x"+error.HResult.ToString("X8");
    var win=error as System.ComponentModel.Win32Exception;
    if(win!=null)result.NativeError=win.NativeErrorCode;

   }
   return result;
  }
  public static string Write(string directory,Result result)
  {
   Directory.CreateDirectory(directory);string path=Path.Combine(directory,"MetaFactory-Win32k-Events.txt"),previous=Path.Combine(directory,"MetaFactory-Win32k-Events-previous.txt");
   string content=new JavaScriptSerializer().Serialize(result)+"\r\n";
   if(Encoding.UTF8.GetByteCount(content)>256*1024)throw new IOException("Output exceeds diagnostic storage budget.");
   if(File.Exists(path))
   {
    if(!Owned(path)||File.Exists(previous)&&!Owned(previous))throw new IOException("Unknown file ownership; no file overwritten.");
    if(File.Exists(previous))File.Delete(previous);File.Move(path,previous);
   }
   File.WriteAllText(path,content,Encoding.UTF8);return path;
  }
  static bool Owned(string path){using(var f=new StreamReader(path,Encoding.UTF8,true)){char[] c=new char[256];int n=f.Read(c,0,c.Length);return new string(c,0,n).Contains("MF_WIN32K_EVENT_REPORT_1");}}
 }
 static class Program
 {
  [STAThread]static int Main()
  {
   try
   {
    if(Environment.OSVersion.Platform!=PlatformID.Win32NT)return 2;
    Result result=Collector.Collect(()=>new WindowsReader());
    try{Collector.Write(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),result);}
    catch{Collector.Write(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"MT Manager"),result);}
    return result.Status=="event_log_read_failed_not_a_heap_diagnosis"?1:0;
   }
   catch{return 3;}
  }
 }
}
