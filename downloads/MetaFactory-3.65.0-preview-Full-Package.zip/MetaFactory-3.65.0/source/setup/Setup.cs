using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

[assembly: AssemblyTitle("MetaFactory Setup")]
[assembly: AssemblyProduct("MetaFactory")]
[assembly: AssemblyDescription("Installs MT Manager for the current Windows user")]
[assembly: AssemblyVersion("3.65.0.0")]
[assembly: AssemblyFileVersion("3.65.0.0")]

namespace MTManager
{
    static class SetupProgram
    {
        [STAThread]
        static int Main(string[] args)
        {
            try { return Run(args); }
            catch (Exception e)
            {
                Crash(e);
                return 1;
            }
        }

        static int Run(string[] args)
        {
            Log.Write("setup " + AppInfo.Version + " · " + Environment.OSVersion + " · .NET " + Environment.Version + " · " + (Environment.Is64BitProcess ? "64" : "32") + "-bit");
            // 3.27: the installer speaks the program's language (Persian unless English was chosen in the program).
            try { Lang.En = Settings.Load().Language == "en"; } catch { }
#if SNAPSHOT
            if (Environment.GetEnvironmentVariable("MTM_LANG") == "en") Lang.En = true;
#endif
            Theme.Init();
            // An update keeps the look the program already has.
            try
            {
                string look = Settings.Load().Look;
#if SNAPSHOT
                look = Environment.GetEnvironmentVariable("MTM_LOOK") ?? look;
#endif
                Theme.Apply(look);
            }
            catch (Exception e) { Log.Write("look: " + e.Message); }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (s, e) => Ui.Error(null, e.Exception);
#if SNAPSHOT
            if (args.Length >= 2 && args[0] == "--snapshot")
            {
                using (var f = new SetupForm()) f.Snapshot(args[1]);
                return 0;
            }
#endif
            Application.Run(new SetupForm());
            return 0;
        }

        static void Crash(Exception e)
        {
            string details = "MetaFactory Setup " + AppInfo.Version + "\r\n" + Environment.OSVersion + " · .NET " + Environment.Version + "\r\n\r\n" + e;
            string file = null;
            try
            {
                file = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "MTManager-setup-error.txt");
                File.WriteAllText(file, details);
            }
            catch { file = null; }
            try { Log.Write("setup crash: " + e); } catch { }
            try
            {
                MessageBox.Show(Lang.T("نصب با خطا متوقف شد.\n\n", "The installation stopped with an error.\n\n") + e.GetType().Name + ": " + e.Message +
                    (file != null ? Lang.T("\n\nجزئیات در این فایل روی دسکتاپ ذخیره شد؛ آن را بفرستید:\n", "\n\nThe details were saved in this file on the desktop; send it:\n") + file : ""),
                    Lang.T("نصب ", "Install ") + Ui.Title, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.RtlReading | MessageBoxOptions.RightAlign);
            }
            catch { }
        }
    }

    /// <summary>The top of the setup window: the mark, the name and the version on a soft blue band.</summary>
    sealed class Hero : Control
    {
        public Glyph Mark = Glyph.Logo;
        public string Title = Ui.Title;
        public string Note = "";

        public Hero()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Height = Theme.S(190);
            TabStop = false;
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (Width <= 0 || Height <= 0) return;
            using (var b = new LinearGradientBrush(ClientRectangle, Theme.HeroTop, Theme.Surface, LinearGradientMode.Vertical))
                g.FillRectangle(b, ClientRectangle);
            int logo = Theme.S(72);
            Glyphs.Draw(g, Mark, new RectangleF((Width - logo) / 2f, Theme.S(28), logo, logo), Theme.Accent);
            Theme.Line(g, Title, Theme.Title, new Rectangle(0, Theme.S(112), Width, Theme.S(34)), Theme.Text, true);
            Theme.Line(g, Note, Theme.Small, new Rectangle(0, Theme.S(148), Width, Theme.S(22)), Theme.Muted, true);
        }
    }

    /// <summary>Children one under another, each at the reading start (right for Persian); labels wrap to the width.</summary>
    sealed class Stack : Panel
    {
        public readonly HashSet<Control> Stretch = new HashSet<Control>();
        public readonly HashSet<Control> Center = new HashSet<Control>();
        bool laying;

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            if (laying) return;
            laying = true;
            try
            {
                bool rtl = RightToLeft == RightToLeft.Yes;
                int y = Padding.Top, w = ClientSize.Width - Padding.Horizontal;
                foreach (Control c in Controls)
                {
                    if (!c.Visible) continue;
                    Size s;
                    if (Stretch.Contains(c)) s = new Size(w, c.Height);
                    else if (c is Label)
                    {
                        // Measured here rather than left to AutoSize, so long lines wrap the same everywhere.
                        c.AutoSize = false;
                        s = Theme.WrapSize(c, w);
                    }
                    else s = c.AutoSize ? c.GetPreferredSize(new Size(w, 0)) : c.Size;
                    int x = Center.Contains(c) ? Padding.Left + (w - s.Width) / 2 : rtl ? Padding.Left + w - s.Width : Padding.Left;
                    y += c.Margin.Top;
                    c.Bounds = new Rectangle(x, y, s.Width, s.Height);
                    y += s.Height + c.Margin.Bottom;
                }
            }
            finally { laying = false; }
        }
    }

    sealed class SetupForm : Form
    {
        enum Step { Ready, Working, Done, Failed }

        readonly Hero hero = new Hero { Dock = DockStyle.Top };
        readonly Stack body = new Stack { Dock = DockStyle.Fill };
        readonly Label intro = Theme.Label("", 0, Theme.Font, Theme.Text);
        readonly CheckBox desktop = new CheckBox { Text = Lang.T("میانبر روی دسکتاپ", "Desktop shortcut"), AutoSize = true, Checked = true };
        readonly CheckBox openAfter = new CheckBox { Text = Lang.T("بعد از نصب، برنامه باز شود", "Open the program after installing"), AutoSize = true, Checked = true };
        readonly Label place = Theme.Label("", 0, Theme.Small, Theme.Muted);
        readonly Label status = Theme.Label("", 0, Theme.Small, Theme.Muted);
        readonly ProgressLine progress = new ProgressLine();
        readonly ButtonRow buttons = new ButtonRow { Dock = DockStyle.Bottom };
        readonly ModernButton main = new ModernButton(Lang.T("نصب", "Install"), ButtonKind.Primary) { MinimumSize = new Size(Theme.S(130), 0) };
        readonly ModernButton second = new ModernButton(Lang.T("انصراف", "Cancel")) { MinimumSize = new Size(Theme.S(100), 0) };
        readonly string dir;
        string installed;
        Step step;

        public SetupForm()
        {
            Text = Lang.T("نصب ", "Install ") + Ui.Title;
            Font = Theme.Font;
            ForeColor = Theme.Text;
            BackColor = Theme.Surface;
            RightToLeft = RightToLeft.Yes;
            RightToLeftLayout = false;  // the window frame stays as in every Windows program: buttons at the top right
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            Icon = Art.AppIcon();
            Theme.Window(this);
            ClientSize = Theme.Sz(580, 520);

            dir = Installation.Dir();
            installed = Installation.InstalledVersion();
            desktop.Checked = installed == null || Installation.HasDesktopShortcut;

            body.Padding = Theme.Pad(44, 22, 44, 8);
            intro.Margin = Theme.Pad(0, 0, 0, 16);
            desktop.Margin = Theme.Pad(0, 2, 0, 4);
            openAfter.Margin = Theme.Pad(0, 2, 0, 14);
            place.Margin = Theme.Pad(0, 4, 0, 0);
            status.Margin = Theme.Pad(0, 6, 0, 10);
            progress.Margin = Theme.Pad(0, 4, 0, 0);
            body.Controls.Add(intro);
            body.Controls.Add(desktop);
            body.Controls.Add(openAfter);
            body.Controls.Add(place);
            body.Controls.Add(status);
            body.Controls.Add(progress);
            body.Stretch.Add(progress);

            buttons.Add(main);
            buttons.Add(second);
            buttons.AutoSize = false;
            buttons.Height = buttons.GetPreferredSize(Size.Empty).Height + Theme.S(6);
            main.Click += (s, e) => OnMain();
            second.Click += (s, e) => Close();
            AcceptButton = main;
            CancelButton = second;

            Controls.Add(body);
            Controls.Add(hero);
            Controls.Add(buttons);
            Theme.StyleInputs(this);
            Show(Step.Ready, null);
            FormClosing += (s, e) => { if (step == Step.Working) e.Cancel = true; };
        }

        void Show(Step next, string detail)
        {
            step = next;
            bool upgrade = installed != null;
            desktop.Visible = openAfter.Visible = place.Visible = next == Step.Ready;
            status.Visible = progress.Visible = next == Step.Working;
            intro.ForeColor = Theme.Text;
            hero.Mark = Glyph.Logo;
            hero.Title = Ui.Title;
            hero.Note = Lang.T("نسخه‌ی ", "Version ") + AppInfo.Version + Lang.T("  |  ساخت و باز کردن ده‌ها MT5 و MT4 مستقل", "  |  make and open dozens of independent MT5 and MT4");
            switch (next)
            {
                case Step.Ready:
                    intro.Text = upgrade
                        ? Lang.T("نسخه‌ی ", "Version ") + installed + Lang.T(" روی این کامپیوتر نصب است و به نسخه‌ی ", " is installed on this computer and is updated to version ") + AppInfo.Version + Lang.T(" به‌روز می‌شود. نسخه‌های ساخته‌شده، دانشجوها، حساب‌ها و تنظیمات سر جایشان می‌مانند.", ". The copies made, students, accounts and settings stay in place.")
                        : Lang.T("برای هر دانشجو یک نسخه‌ی سبک متاتریدر می‌سازد و با یک کلیک با حساب خودش باز می‌کند. خود متاتریدرِ نصب‌شده تغییری نمی‌کند.", "Makes a light MetaTrader copy for each student and opens it with their own account in one click. The installed MetaTrader itself does not change.");
                    place.Text = Lang.T("برای همین کاربر ویندوز نصب می‌شود و دسترسی مدیر سیستم لازم ندارد.\n", "Installed for this Windows user only; no administrator access is needed.\n") + dir;
                    main.Text = upgrade ? Lang.T("به‌روزرسانی", "Refresh") : Lang.T("نصب", "Install");
                    second.Text = Lang.T("انصراف", "Cancel");
                    break;
                case Step.Working:
                    intro.Text = upgrade ? Lang.T("در حال به‌روزرسانی…", "Updating…") : Lang.T("در حال نصب…", "Installing…");
                    break;
                case Step.Done:
                    hero.Mark = Glyph.Success;
                    hero.Title = upgrade ? Lang.T("به‌روز شد", "Updated") : Lang.T("نصب شد", "Installed");
                    intro.Text = "«" + Ui.Title + Lang.T("» آماده است. از منوی Start", "” is ready. It opens from the Start menu") + (desktop.Checked ? Lang.T(" یا میانبر روی دسکتاپ", " or the desktop shortcut") : "") + Lang.T(" هم باز می‌شود.", " too.") +
                                 (detail != null ? "\n\n" + detail : "");
                    main.Text = Lang.T("باز کردن برنامه", "Open the program");
                    second.Text = Lang.T("بستن", "Close");
                    break;
                case Step.Failed:
                    hero.Mark = Glyph.Error;
                    hero.Title = Lang.T("نصب کامل نشد", "The installation did not finish");
                    intro.ForeColor = Theme.Bad;
                    intro.Text = detail + Lang.T("\n\nاگر تکرار شد، فایل log.txt را از پوشه‌ی «%APPDATA%\\MT Manager» بفرستید.", "\n\nIf it happens again, send the file log.txt from the folder “%APPDATA%\\MT Manager”.");
                    main.Text = Lang.T("دوباره", "Again");
                    second.Text = Lang.T("بستن", "Close");
                    break;
            }
            main.Enabled = second.Enabled = next != Step.Working;
            buttons.PerformLayout();
            body.PerformLayout();
            hero.Invalidate();
        }

        void OnMain()
        {
            switch (step)
            {
                case Step.Ready:
                case Step.Failed:
                    Install();
                    break;
                case Step.Done:
                    try
                    {
                        Process.Start(new ProcessStartInfo(Path.Combine(dir, Installation.ExeName)) { WorkingDirectory = dir, UseShellExecute = true });
                    }
                    catch (Exception e) { Ui.Error(this, e); return; }
                    Close();
                    break;
            }
        }

        void Progress(int value, string text)
        {
            progress.Value = value;
            status.Text = text;
            body.PerformLayout();
            Update();
            // A short pause per step so the progress can be seen; the work itself takes a moment.
            DateTime until = DateTime.Now.AddMilliseconds(180);
            while (DateTime.Now < until)
            {
                Application.DoEvents();
                System.Threading.Thread.Sleep(15);
            }
        }

        void Install()
        {
            Show(Step.Working, null);
            try
            {
                Progress(5, Lang.T("بررسی برنامه‌ی در حال اجرا…", "Checking for a running program…"));
                List<Process> open = Installation.Running(dir);
                if (open.Count > 0)
                {
                    if (!Ui.Confirm(this, "«" + Ui.Title + Lang.T("» باز است و برای به‌روزرسانی باید بسته شود. بسته شود؟\n\nنسخه‌های متاتریدرِ در حال اجرا باز می‌مانند.", "” is open and must close for the update. Close it?\n\nRunning MetaTrader copies stay open.")))
                    {
                        Show(Step.Ready, null);
                        return;
                    }
                    Progress(15, Lang.T("در حال بستن برنامه…", "Closing the program…"));
                    Installation.Close(open, () => Application.DoEvents());
                }
                Progress(35, Lang.T("در حال کپی فایل‌ها…", "Copying files…"));
                Directory.CreateDirectory(dir);
                string exe = Path.Combine(dir, Installation.ExeName);
                ReplaceExe(exe);
                Extract("Guide-fa.txt", Path.Combine(dir, Installation.GuideName));
                Extract("Guide-en.txt", Path.Combine(dir, Installation.GuideEnName));
                Extract("Vazirmatn-OFL.txt", Path.Combine(dir, Installation.FontLicenseName));
                string oldUninstaller = Path.Combine(dir, "Uninstall.exe");
                try { if (File.Exists(oldUninstaller)) File.Delete(oldUninstaller); } catch (Exception e) { Log.Write("old uninstaller: " + e.Message); }
                Progress(65, Lang.T("در حال ساخت میانبرها…", "Making shortcuts…"));
                List<string> problems = Installation.CreateShortcuts(dir, desktop.Checked);
                Progress(85, Lang.T("ثبت در ویندوز…", "Registering in Windows…"));
                Installation.Register(dir);
                Progress(100, Lang.T("تمام شد.", "Done."));
                Log.Write("installed " + AppInfo.Version + " to " + dir + (problems.Count > 0 ? " · shortcut problems: " + string.Join("; ", problems) : ""));
                bool launch = openAfter.Checked;
                Show(Step.Done, problems.Count > 0 ? Lang.T("میانبرها ساخته نشدند؛ برنامه را از این پوشه باز کنید:\n", "The shortcuts were not made; open the program from this folder:\n") + dir : null);
                if (launch) OnMain();
            }
            catch (Exception e)
            {
                Log.Write("setup failed: " + e);
                Show(Step.Failed, e is UnauthorizedAccessException || e is IOException
                    ? Lang.T("نوشتن در پوشه‌ی برنامه ممکن نشد: ", "Could not write in the program folder: ") + e.Message
                    : Lang.T("خطا: ", "Error: ") + e.Message);
            }
        }

        /// <summary>Puts the new program in place; an old one that is still running is renamed instead (Windows allows that).</summary>
        static void ReplaceExe(string exe)
        {
            string fresh = exe + ".new";
            Extract("MTManager.exe", fresh);
            if (File.Exists(exe))
            {
                try { File.Delete(exe); }
                catch (Exception)
                {
                    string old = exe + ".old";
                    try { if (File.Exists(old)) File.Delete(old); }
                    catch { old = exe + ".old" + DateTime.Now.Ticks; }
                    File.Move(exe, old);
                    Log.Write("program in use; renamed to " + Path.GetFileName(old));
                }
            }
            File.Move(fresh, exe);
        }

        static void Extract(string resource, string path)
        {
            using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource))
            {
                if (s == null) throw new InvalidOperationException(Lang.T("فایل «", "The file “") + resource + Lang.T("» داخل برنامه‌ی نصب نیست.", "” is not inside the installer."));
                using (FileStream f = File.Create(path)) s.CopyTo(f);
            }
        }

#if SNAPSHOT
        public void Snapshot(string outDir)
        {
            Directory.CreateDirectory(outDir);
            Shots.Draw(this, Path.Combine(outDir, "setup-ready.png"), false);
            installed = "3.0.2";
            Show(Step.Ready, null);
            Shots.Draw(this, Path.Combine(outDir, "setup-update.png"), false);
            Show(Step.Working, null);
            progress.Value = 65;
            status.Text = Lang.T("در حال ساخت میانبرها…", "Making shortcuts…");
            body.PerformLayout();
            Shots.Draw(this, Path.Combine(outDir, "setup-working.png"), false);
            Show(Step.Done, null);
            Shots.Draw(this, Path.Combine(outDir, "setup-done.png"), false);
            Show(Step.Failed, Lang.T("نوشتن در پوشه‌ی برنامه ممکن نشد: Access to the path is denied.", "Could not write in the program folder: Access to the path is denied."));
            Shots.Draw(this, Path.Combine(outDir, "setup-failed.png"), false);
        }
#endif
    }
}
