using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
namespace MTManager
{
    // Main-list presentation only. Does not alter account/period arithmetic or report acceptance.
    internal static class LiveRowMetrics
    {
        internal const string Mt4ObserverVersion="1.07";
        sealed class StopCounts { internal DateTime From,To;internal int Expected,SourceCount,DealCount,Missing,Unknown;internal object Deals; }
        static readonly ConditionalWeakTable<List<JournalTrade>,StopCounts> closedStops=new ConditionalWeakTable<List<JournalTrade>,StopCounts>();
        static bool Finite(double n){return !double.IsNaN(n)&&!double.IsInfinity(n);}
        static string Count(int? n){return n.HasValue?n.Value.ToString(CultureInfo.InvariantCulture):"—";}
        internal static bool Fresh(Instance copy,Account account,LiveFeedSnapshot feed,DateTime utc)
        {return copy!=null&&account!=null&&feed!=null&&feed.IsLive&&feed.Platform==copy.Kind.ToString()&&feed.Login==(account.Login??"").Trim()&&string.Equals(feed.Server,(account.Server??"").Trim(),StringComparison.OrdinalIgnoreCase)&&utc>=feed.HeartbeatUtc.AddSeconds(-5)&&utc<=feed.HeartbeatUtc.AddSeconds(LiveFeedReader.StaleSeconds);}
        internal static bool ReporterUpdateNeeded(LiveFeedSnapshot feed)
        {return feed!=null&&feed.Platform=="MT4"&&feed.ObserverVersion!=Mt4ObserverVersion;}
        static StopCounts ClosedStops(AccountJournal journal,PanelView view,int expected)
        {
            StopCounts c=closedStops.GetValue(journal.Trades,key=>new StopCounts());
            if(c.From==view.Range.From&&c.To==view.Range.To&&c.Expected==expected&&c.SourceCount==journal.Trades.Count&&c.DealCount==journal.Deals.Count&&object.ReferenceEquals(c.Deals,journal.Deals))return c;
            c.From=view.Range.From;c.To=view.Range.To;c.Expected=expected;c.SourceCount=journal.Trades.Count;c.DealCount=journal.Deals.Count;c.Deals=journal.Deals;c.Missing=0;c.Unknown=0;
            var trades=journal.Trades.Where(t=>t.Close>=c.From&&t.Close<c.To).ToArray();
            bool aligned=trades.Length==expected;
            if(journal.Platform=="MT5")
            {
                var exits=journal.Deals.Where(d=>d.Time>=c.From&&d.Time<c.To&&(d.Type==0||d.Type==1)&&(d.Entry==1||d.Entry==2||d.Entry==3)).ToArray();
                aligned=aligned&&exits.Length==expected&&exits.All(d=>d.Position>0)&&exits.Select(d=>d.Position).Distinct().Count()==expected&&new HashSet<long>(trades.Select(t=>t.Ticket)).SetEquals(exits.Select(d=>d.Position));
            }
            if(!aligned){c.Unknown=expected;return c;}
            foreach(var trade in trades)
                if(trade.FinalSlKnown!=true||!Finite(trade.SlFinal)||trade.SlFinal<0)c.Unknown++;
                else if(trade.SlFinal==0)c.Missing++;
            return c;
        }
        internal static void Apply(CopyRow row,Instance copy,Account account,AccountJournal journal,PanelView view,LiveFeedSnapshot feed,bool pending,bool current,DateTime utc)
        {
            if(row.TodayBusy)return;
            bool fresh=Fresh(copy,account,feed,utc),bound=AccountRowPresentation.Bound(copy,account,journal);
            if(pending&&!fresh || !pending&&!bound)return;
            int? open=pending?(int?)feed.Positions.Count:row.TodayOpenCount;
            bool hasOpen=open.GetValueOrDefault()>0;
            double? net=null;int? count=null,missing=null;int unknown=0;
            if(hasOpen)
            {
                net=pending?feed.Positions.Sum(p=>p.Profit+p.Swap+(feed.Platform=="MT4"?p.Commission:0)):journal.Open.Sum(p=>p.Profit+p.Swap+p.Commission);
                count=open;missing=row.TodayOpenNoSlCount;unknown=row.TodayOpenSlUnknownCount.GetValueOrDefault();
            }
            else if(!pending&&row.TodayClosedCount.HasValue&&view!=null)
            {
                count=row.TodayClosedCount;net=view.ClosedNet;
                var stops=ClosedStops(journal,view,count.Value);unknown=stops.Unknown;missing=stops.Missing>0||unknown==0?(int?)stops.Missing:null;
            }
            row.TodayCompactMetrics=true;row.TodayNet=net.HasValue&&Finite(net.Value)?net:null;row.TodayTone=row.TodayNet>0?1:row.TodayNet<0?-1:0;
            row.TodayText=(hasOpen?"Open ":"Day ")+(row.TodayNet.HasValue?PanelMath.Money(row.TodayNet.Value,pending?feed.Currency:journal.Currency):"—")+" · "+Count(count)+(hasOpen?" open":count==1?" trade":" trades");
            if(missing.GetValueOrDefault()>0||unknown>0)row.TodayText+=" · No SL: "+(missing.HasValue?(unknown>0?"≥":"")+Count(missing):"—");
            row.TodayNone=!net.HasValue&&!count.HasValue;row.TodayHasTrades=count.GetValueOrDefault()>0;
            row.TodayClosedNoSlCount=hasOpen?null:missing;row.TodayClosedSlUnknownCount=hasOpen?null:(int?)unknown;
            row.TodayTip+=(row.TodayTip.Length>0?"\r\n":"")+(hasOpen?"Displayed amount: current open-position floating P/L only; closed-day P/L is excluded.":"Displayed amount: today's verified closed trading result only; funding and credit are excluded.")
                +"\r\n"+(hasOpen?"No SL counts current open-position stops.":"No SL counts verified trades closed today with a recorded zero SL at close. MT4 does not retain the entire stop-change history.")
                +(unknown>0?" Unknown stop evidence: "+unknown.ToString(CultureInfo.InvariantCulture)+".":"");
            if(fresh&&(pending||current))
            {
                row.TodayLive=true;
                string age=Math.Max(0,(int)(utc-feed.HeartbeatUtc).TotalSeconds).ToString(CultureInfo.InvariantCulture)+"s";
                row.TodayAgo="Live · "+age+(ReporterUpdateNeeded(feed)?" · Restart reporter":pending?" · History pending":"");
                if(ReporterUpdateNeeded(feed))row.TodayTip+="\r\nThe MT4 observer running inside this terminal has not confirmed version "+Mt4ObserverVersion+". Updating MetaFactory does not reload an already-running EA. Close and reopen this reporting terminal through MetaFactory once; the startup path deploys the current observer. This notice does not invalidate its separately verified report data.";
            }
        }
    }
}
