using System;
using System.Linq;
namespace MTManager { static partial class Tests {
static void LiveAutoStartChecks() {
 var emptyCopy=new Instance{Name="MT4-empty-live",Kind=Kind.MT4,Dir=Dir("mt4-empty-live")};
 ChartProfile.UseEmpty(emptyCopy);LiveAutoStart.EnsureMt4Chart(emptyCopy,"EURUSD.m","5");
 string lastProfile=System.IO.Path.Combine(emptyCopy.Dir,"profiles","lastprofile.ini");
 Equal("MetaFactoryLive",System.IO.File.ReadAllText(lastProfile).Trim(),"empty MT4 profile switches to observer chart");
 string observerChart=System.IO.Path.Combine(emptyCopy.Dir,"profiles","MetaFactoryLive","chart01.chr");
 string observerText=System.IO.File.ReadAllText(observerChart);
 var startResult=Launcher.WriteStartFile(emptyCopy,new Settings{Light=true,StartCharts=ChartModes.Empty},new AccountStore(),true);
 Equal("MetaFactoryLive",System.IO.File.ReadAllText(lastProfile).Trim(),"live manual start bypasses empty chart mode");
 Check(System.IO.File.Exists(observerChart),"startup preserves observer chart despite empty profile setting");
 Launcher.DeleteStartFile(startResult.StartFile);
 Check(System.IO.File.ReadAllBytes(lastProfile)[0]==(byte)'M',"MT4 profile selector uses plain ANSI without BOM");
 Check(observerText.Contains("symbol=EURUSD.m") && observerText.Contains("period=5") && !observerText.Contains("<expert>"),"fallback chart uses broker symbol and adds no second EA");
 LiveAutoStart.EnsureMt4Chart(emptyCopy,"GBPUSD","1");
 Equal(observerText,System.IO.File.ReadAllText(observerChart),"repeated startup preserves chart");
 string userDir=System.IO.Path.Combine(emptyCopy.Dir,"profiles","UserProfile");System.IO.Directory.CreateDirectory(userDir);
 string userChart=System.IO.Path.Combine(userDir,"chart01.chr");System.IO.File.WriteAllText(userChart,"<expert>MyOtherEA</expert>");
 System.IO.File.WriteAllText(lastProfile,"UserProfile");LiveAutoStart.EnsureMt4Chart(emptyCopy,"EURUSD","1");
 Equal("UserProfile",System.IO.File.ReadAllText(lastProfile),"existing profile selection preserved");
 Equal("<expert>MyOtherEA</expert>",System.IO.File.ReadAllText(userChart),"existing user EA chart unchanged");
 Throws<ArgumentException>(()=>LiveAutoStart.EnsureMt4Chart(emptyCopy,"EURUSD\nperiod=60","1"),"chart rejects injected settings");

 Equal(null,PendingStart.ProtectedReady(11,false),"MT4 retains startup beyond old ten-second deadline");
 Equal(null,PendingStart.ProtectedReady(120,false),"MT4 allows slow bootstrap without configuration acknowledgement");
 Equal("time",PendingStart.ProtectedReady(180,false),"MT4 credential retention has bounded deadline");
 Equal("journal",PendingStart.ProtectedReady(2,true),"MT4 removes startup immediately after acknowledgement");
 Check(PendingStart.ConfigAcknowledged("Started with configuration file 'mtm-live-start-abc.ini'","/tmp/mtm-live-start-abc.ini"),"exact startup configuration acknowledgement accepted");
 Check(!PendingStart.ConfigAcknowledged("cannot load configuration file mtm-live-start-abc.ini","/tmp/mtm-live-start-abc.ini"),"configuration failure does not delete startup early");
 Check(!PendingStart.ConfigAcknowledged("Started with configuration file mtm-live-start-old.ini","/tmp/mtm-live-start-abc.ini"),"previous run acknowledgement cannot delete new startup");
 var protectedPending=new PendingStart {Time=DateTime.Now,WaitForConfigRead=true};
 Equal(null,protectedPending.Ready(protectedPending.Time.AddSeconds(90)),"missing parent process does not delete protected configuration");

 var bootstrapAccount=new Account {Login="12345",Server="Synthetic-Demo"};
 string token=new string('a',32), binding=LiveAutoStart.BootstrapText(bootstrapAccount,token);
 Check(binding=="MLBOOT\t1\r\n"+token+"\r\n12345\r\nSynthetic-Demo\r\n","fallback binding has exact bounded account-specific UTF16 text schema");
 var bootstrapCopy=new Instance {Name="MT4-bootstrap",Kind=Kind.MT4,Dir=Dir("live-bootstrap")};
 LiveAutoStart.WriteBootstrap(bootstrapCopy,bootstrapAccount,token);
 string bootstrapPath=System.IO.Path.Combine(bootstrapCopy.Dir,"MQL4","Files","MetaFactoryLive","bootstrap.txt");
 Equal(binding,System.IO.File.ReadAllText(bootstrapPath,System.Text.Encoding.Unicode),"atomic bootstrap is readable in native FILE_UNICODE form");
 bootstrapAccount.Login="67890";LiveAutoStart.WriteBootstrap(bootstrapCopy,bootstrapAccount,new string('b',32));
 Check(System.IO.File.ReadAllText(bootstrapPath).Contains("67890")&&!System.IO.File.ReadAllText(bootstrapPath).Contains(token),"closed-copy binding update replaces previous account atomically");
 Throws<UserMessage>(()=>LiveAutoStart.BootstrapText(new Account{Login="123",Server="Demo\nOther=bad"},token),"bootstrap server cannot inject extra binding lines");
 foreach(Kind nativeKind in new[]{Kind.MT4,Kind.MT5}) {
  string source=LiveReporter.SourceText(nativeKind);
  Check(source.Contains("bool ResolveSession()") && source.Contains("MLBOOT\\t1") && source.Contains("WorkToken==\"\" && WorkLogin==\"\" && WorkServer==\"\""),"native fallback only applies to wholly absent explicit inputs for "+nativeKind);
  Check(source.Contains("GlobalVariableSetOnCondition(ownerKey,ownerId,previous)") && source.Contains("observer-renewed-during-claim") && source.Contains("if(!RefreshLease()){FileDelete(tmp);return false;}"),"native atomic lease handles renewal races and rechecks ownership before publishing for "+nativeKind);
  Check(source.Contains("retryInitAt>=5000") && source.Contains("BeginLiveSession();retryInitAt=GetTickCount();return INIT_SUCCEEDED;"),"recoverable native session failure keeps terminal initialized and retries for "+nativeKind);
 }

 Equal("5",LiveAutoStart.FreePeriod(new[]{"symbol=EURUSD\nperiod=1\n<expert>OtherEA</expert>"},"EURUSD",new string('a',32)),"automatic observer chooses separate timeframe from existing EA chart");
 Equal("1",LiveAutoStart.FreePeriod(new[]{"symbol=EURUSD\nperiod=1\nMTManagerLive\n"+new string('a',32)},"EURUSD",new string('a',32)),"same account live chart can be reused");
 foreach (Kind kind in new[] { Kind.MT4, Kind.MT5 }) {
  var lines = LiveAutoStart.Lines(kind, @"MetaFactoryLive\version\MTManagerLive", "session.set", "EURUSD.m");
  Check(lines.Contains(@"Expert=MetaFactoryLive\version\MTManagerLive") && lines.Contains("ExpertParameters=session.set"), "automatic live startup binds independent EA and preset for " + kind);
  Check(lines.Contains("Symbol=EURUSD.m"), "automatic startup keeps broker symbol suffix for " + kind);
  Check(!lines.Any(x => x.StartsWith("Script=") || x.StartsWith("AllowLiveTrading=") || x.StartsWith("ExpertsTrades=")), "live auto startup does not change trading permissions for " + kind);
  Check(kind != Kind.MT4 || lines.Contains("ExpertsDllImport=true"),"MT4 live startup enables history DLL access");
  Check(kind != Kind.MT5 || !lines.Any(x=>x.StartsWith("ExpertsDllImport=")),"MT5 DLL policy unchanged");
  Check(kind != Kind.MT4 || lines.Contains("ShutdownTerminal=false"),"MT4 auto-run explicitly disables startup terminal shutdown");
  Check(kind != Kind.MT5 || lines.First()=="[StartUp]" && lines.Contains("ShutdownTerminal=0"), "MT5 live startup stays open");
 }
 Throws<ArgumentException>(() => LiveAutoStart.Lines(Kind.MT4,"EA\nExpert=bad","s.set","EURUSD"), "automatic EA setting rejects newline injection");
 Check(LiveAutoStart.Prepare(new Instance(),new Settings(),null).Count==0,"copies without stored account do not attempt live compilation");
}
}}
