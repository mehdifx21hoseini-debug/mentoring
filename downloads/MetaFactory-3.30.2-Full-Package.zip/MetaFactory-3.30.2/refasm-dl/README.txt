Download and extract Microsoft.NETFramework.ReferenceAssemblies.net45 1.0.3 into x45 as documented in ../docs/BUILD-fa.md. Compiler reference dependencies are not bundled.
