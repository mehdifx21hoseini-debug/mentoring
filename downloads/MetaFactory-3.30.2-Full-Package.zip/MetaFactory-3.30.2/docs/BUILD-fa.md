# ساخت نسخهٔ ۳٫۳۰٫۲

کد برنامه C# و Windows Forms است و برای Microsoft .NET Framework 4.5 کامپایل می‌شود. ساخت ثبت‌شده با Mono 6.12 و منابع ویندوز با llvm-rc انجام شده است. اجرای نهایی برنامه و نصب‌کننده روی ویندوز است.

## وابستگی‌ها

- کامپایلر `mcs` و `mono`، مثلاً با نصب `mono-devel` روی لینوکس/WSL.
- `llvm-rc` در PATH؛ از بستهٔ LLVM.
- ابزارهای `curl` و `unzip` برای آماده‌کردن کتابخانه‌های مرجع.
- بستهٔ رسمی NuGet با شناسهٔ `Microsoft.NETFramework.ReferenceAssemblies.net45` نسخهٔ `1.0.3`.

وابستگی‌های کامپایلر و کتابخانه‌های مرجع داخل ZIP نیستند؛ سورس، منابع و خروجی کامپایل‌شده داخل بسته‌اند.

از ریشهٔ همین بسته اجرا کنید:

```sh
curl -fL https://api.nuget.org/v3-flatcontainer/microsoft.netframework.referenceassemblies.net45/1.0.3/microsoft.netframework.referenceassemblies.net45.1.0.3.nupkg -o reference-assemblies.nupkg
mkdir -p refasm-dl/x45
unzip reference-assemblies.nupkg -d refasm-dl/x45
cd source
sh build.sh
mono tests.exe
```

اسکریپت اصلی `source/build.sh` مسیر مرجع را نسبت به پوشهٔ source به صورت `../refasm-dl/x45/build/.NETFramework/v4.5` می‌خواند. اگر `llvm-rc` با پسوند نسخه نصب شده، مسیر باینری LLVM را به PATH اضافه کنید.

خروجی‌ها: `MTManager.exe` برنامه، `MTManager-Setup.exe` نصب‌کننده، `tests.exe` آزمون منطق، و `snapshot.exe` و `setup-snapshot.exe` برای بررسی رابط.

اسکریپت‌های MQL داخل برنامه قرار می‌گیرند و با MetaEditor نصب‌شده روی ویندوز کاربر ساخته می‌شوند. فایل‌های فونت و لوگو و manifest در source حفظ شده‌اند.

آزمون‌های کمکی در `verification/harness` نیز آمده‌اند؛ این فایل‌ها ابزار توسعه‌اند و مسیرهای `/workspace` داخل آن‌ها باید برای محیط جدید تنظیم شوند. آزمون رابط به X11/Xvfb و فونت Vazirmatn نیاز دارد؛ نتیجهٔ Mono جای آزمون نهایی ویندوز و بروکر را نمی‌گیرد.

در آخرین بررسی ۱۰۵۴ آزمون منطق و ۹۲ آزمون رابط موفق بودند؛ یک آزمون قدیمی chart retry به دلیل نبود Python3 در کانتینر Mono اجرا نشد.
