using System;
using System.IO;
using System.Diagnostics;
using System.Reflection;
using System.Security.Cryptography;
using System.Linq;
using MTManager;
class VerifyRelease
{
 static int Main()
 {
  if(AppInfo.Version!="3.30.2")throw new Exception("Wrong app version");
  var setup=Assembly.LoadFrom("MTManager-Setup.exe");
  using(var s=setup.GetManifestResourceStream("MTManager.exe"))
  using(var sha=SHA256.Create())
  {
   byte[] embedded=sha.ComputeHash(s);
   using(var f=File.OpenRead("MTManager.exe"))if(!embedded.SequenceEqual(sha.ComputeHash(f)))throw new Exception("Installer embeds a different app");
  }
  foreach(var f in new[]{"MTManager.exe","MTManager-Setup.exe"})
  {
   string version=FileVersionInfo.GetVersionInfo(f).FileVersion;
   if(version!="3.30.2.0")throw new Exception("Wrong PE version: "+version);
   Console.WriteLine(f+": PE version "+version);
  }
  StudentImport.Template("MetaFactory-students.xlsx");
  Console.WriteLine("Installer payload hash matches app; template generated.");return 0;
 }
}
