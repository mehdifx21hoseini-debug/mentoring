using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using MTManager;
class BulkUiFlowTest
{
 static BindingFlags flags=BindingFlags.Instance|BindingFlags.NonPublic;
 static int checks;
 static void Check(bool b,string label){if(!b)throw new Exception(label);checks++;}
 static object Field(object o,string n){return o.GetType().GetField(n,flags).GetValue(o);}
 static void Pump(int ms){var c=System.Diagnostics.Stopwatch.StartNew();while(c.ElapsedMilliseconds<ms){Application.DoEvents();Thread.Sleep(10);}}
 static void Until(Func<bool> ok,int ms,string label){var c=System.Diagnostics.Stopwatch.StartNew();while(!ok()&&c.ElapsedMilliseconds<ms)Pump(20);Check(ok(),label);}
 sealed class Fake : IStudentImportRuntime,IStudentImportProgress,IDisposable
 {
  public int Saves,Connections;public bool Slow,Unknown,Disposed,PreviousBusy;
  public void Dispose(){Disposed=true;}Func<bool> cancel;Action<string> stage;static int copy;
  public void Configure(Func<bool> c,Action<string> p){cancel=c;stage=p;}
  public string Save(StudentImportRow r){Saves++;stage("Preparing sample copy");Thread.Sleep(80);return "MT5-Test-"+Interlocked.Increment(ref copy);}
  public ImportConnection Connect(StudentImportRow r,Func<bool> c){Connections++;stage("Waiting for sample server");if(PreviousBusy)StudentImportRuntime.WaitForRelease(()=>true,c,()=>stage("Waiting for previous terminal to close"));if(Slow){for(int i=0;i<200&&!cancel();i++)Thread.Sleep(20);if(cancel())return new ImportConnection{Reason="Stopped by test"};}if(Unknown)return new ImportConnection{Reason="No conclusive login message"};return new ImportConnection{Connected=true,State=Login.Connected,Reason="Sample confirmed"};}
 }
 [STAThread] static int Main(string[] args)
 {
  AppPaths.DataDirOverride="/workspace/metafactory-tools/ui-flow-data-"+args[1]+"-"+args[2]+"-"+Guid.NewGuid().ToString("N");
  Lang.En=args[1]=="en";
  var asm=typeof(Settings).Assembly;var theme=asm.GetType("MTManager.Theme");
  theme.GetMethod("Init",BindingFlags.Static|BindingFlags.Public).Invoke(null,null);
  theme.GetMethod("Apply",BindingFlags.Static|BindingFlags.Public).Invoke(null,new object[]{args[2]});
  Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
  var type=asm.GetType("MTManager.StudentImportDialog");
  using(var form=(Form)Activator.CreateInstance(type,new object[]{new Settings{BaseDir="/workspace/metafactory-tools/ui-fake-copies"},new AccountStore(),new FolderStore(),""}))
  {
   var rows=(List<StudentImportRow>)Field(form,"rows");
   rows.Add(new StudentImportRow{Line=2,Name=Lang.En?"Already present":"دانشجوی موجود",Login="100",Platform="MT5",Server="Demo",State=ImportState.Duplicate,Reason=Lang.En?"Already exists; skipped":"این حساب از قبل ثبت شده است."});
   rows.Add(new StudentImportRow{Line=3,Name=Lang.En?"First student":"دانشجوی اول",Login="101",Investor="FAKE-INVESTOR-123",Platform="MT5",Server="Demo",State=ImportState.Ready});
   rows.Add(new StudentImportRow{Line=4,Name=Lang.En?"Second student":"دانشجوی دوم",Login="102",Investor="FAKE-INVESTOR-123",Platform="MT5",Server="Demo",State=ImportState.Ready});
   var grid=(DataGridView)Field(form,"grid");
   foreach(var r in rows){grid.Rows.Add(r.Line,r.Name,r.Platform,r.Login,r.Server,r.Folder,r.Copy,StudentImport.Status(r.State),r.Reason);type.GetMethod("Render",flags).Invoke(form,new object[]{r});}
   type.GetMethod("Counts",flags).Invoke(form,null);form.Show();Pump(200);
   ((Label)Field(form,"fileName")).Text="mentoring-students.xlsx";
   Check(((Label)Field(form,"totals")).Text.StartsWith(Lang.En?"3":"۳"),"compact summary reflects loaded rows");
   Check(!form.Controls.Cast<Control>().SelectMany(c=>c.Controls.Cast<Control>()).Any(c=>c.GetType().Name=="ImportSteps"),"no stepper in minimal layout");
   Check(!grid.Columns[0].Visible&&!grid.Columns[5].Visible&&!grid.Columns[6].Visible,"mockup table shows the six useful columns without losing stored data");
   var bar=Field(form,"progress");
   Func<int> value=()=> (int)bar.GetType().GetProperty("Value").GetValue(bar,null);
   Check(value()==0,"preview must not count duplicates as completed progress");
   var barControl=(Control)bar;
   Check(barControl.Width>5&&barControl.Height>3,"live-strip progress track has visible dimensions");
   bar.GetType().GetProperty("Maximum").SetValue(bar,2,null);bar.GetType().GetProperty("Value").SetValue(bar,1,null);
   using(var track=new Bitmap(barControl.Width,barControl.Height))
   {
    barControl.DrawToBitmap(track,barControl.ClientRectangle);
    int accent=((Color)theme.GetField("Accent").GetValue(null)).ToArgb();
    bool left=track.GetPixel(track.Width/4,track.Height/2).ToArgb()==accent,right=track.GetPixel(track.Width*3/4,track.Height/2).ToArgb()==accent;
    Check(Lang.En?left&&!right:right&&!left,"progress fills in the correct reading direction");
   }
   bar.GetType().GetProperty("Value").SetValue(bar,0,null);
   var stage=(Label)Field(form,"stageLine");
   Check(stage.Text.Contains(Lang.En?"nothing has started":"هنوز شروع نشده"),"preview clearly says operation has not started");
   var start=(Button)Field(form,"start");var close=(Button)Field(form,"close");var export=(Button)Field(form,"export");var retry=(Button)Field(form,"retry");
   Check(start.GetType().Name=="ModernButton"&&close.GetType().Name=="ModernButton"&&export.GetType().Name=="ModernButton","all action buttons use the existing shared theme component");
   Check(close.Parent.GetType().Name=="ButtonRow","footer reuses the shared dialog footer");
   Check((bool)close.GetType().GetProperty("Outline").GetValue(close,null)&&(bool)export.GetType().GetProperty("Outline").GetValue(export,null),"stop and export use the approved outlined button style");
   Check(!form.RightToLeftLayout,"standard Windows caption buttons stay on the right");
   foreach(Control b in new Control[]{start,close,export,(Button)Field(form,"dismiss"),(Button)Field(form,"open"),(Button)Field(form,"template")}){Rectangle bounds=b.RectangleToScreen(b.ClientRectangle);Check(!b.Visible||form.RectangleToScreen(form.ClientRectangle).Contains(bounds),"action button fully inside viewport: "+b.Name);}
   using(var bmp=new Bitmap(form.ClientSize.Width,form.ClientSize.Height)){using(var capture=Graphics.FromImage(bmp))capture.CopyFromScreen(form.PointToScreen(Point.Empty),Point.Empty,form.ClientSize);bmp.Save(args[0]+"-preview.png");}
   var slow=new Fake{Slow=true};type.GetField("RuntimeFactory",flags).SetValue(form,new Func<IStudentImportRuntime>(()=>slow));
   start.PerformClick();
   Until(()=>rows[1].State==ImportState.Checking,6000,"primary Start click actually starts the asynchronous importer");Pump(300);
   Check(close.Text==(Lang.En?"Stop checks":"توقف بررسی")&&!start.Enabled,"running state shows Stop and disables starting a second worker");
   Check(stage.Text.Contains("Waiting for sample server"),"live phase is visible while waiting for connection");
   Check(value()==0,"pre-existing duplicate is excluded from this run's progress");
   Check(((Control)Field(form,"activeStudent")).Text.Contains(rows[1].Name)&&close.Visible,"current student and Stop visible while running");
   Check(!((Button)Field(form,"dismiss")).Enabled,"closing is unavailable until the operation is stopped safely");
   using(var bmp=new Bitmap(form.ClientSize.Width,form.ClientSize.Height)){using(var capture=Graphics.FromImage(bmp))capture.CopyFromScreen(form.PointToScreen(Point.Empty),Point.Empty,form.ClientSize);bmp.Save(args[0]+"-running.png");}
   close.PerformClick();Until(()=>!(bool)Field(form,"running"),6000,"Stop completes without freezing the UI");
   Check(slow.Saves==1&&slow.Connections==1&&rows[2].State==ImportState.Cancelled&&!rows[2].Saved,"Stop prevents the next row from being created");
   Check(slow.Disposed,"cancellation drains runtime teardown before worker completion");
   Check(stage.Text.Contains(Lang.En?"Stopped":"متوقف"),"completed cancellation is clearly labelled");
   var fast=new Fake();type.GetField("RuntimeFactory",flags).SetValue(form,new Func<IStudentImportRuntime>(()=>fast));
   retry.PerformClick();Until(()=>!(bool)Field(form,"running"),6000,"Retry completes");
   Check(fast.Saves==1&&fast.Connections==2&&rows.Skip(1).All(r=>r.State==ImportState.Connected),"Retry reuses saved copy and creates only the previously unattempted row");
   Check(value()==2&&!retry.Enabled&&!start.Enabled,"completed run is fully progressed and has no pending ready rows");
   Check(fast.Disposed,"successful import drains runtime teardown before completion");
   Check(((Label)Field(form,"totals")).Text.Contains(Lang.En?"2 connected":"۲ متصل")&&!close.Visible,"compact connected count updates; Stop hidden after completion");
   var unknown=new Fake{Unknown=true};type.GetField("RuntimeFactory",flags).SetValue(form,new Func<IStudentImportRuntime>(()=>unknown));
   rows[1].State=ImportState.Ready;type.GetMethod("Counts",flags).Invoke(form,null);start.PerformClick();
   Until(()=>!(bool)Field(form,"running"),6000,"inconclusive login run completes");
   Check(rows[1].State==ImportState.Unconfirmed&&retry.Enabled&&unknown.Saves==0,"no confirmation is shown as Unconfirmed and can be retried without adding an account");
   Check(((Label)Field(form,"totals")).Text.Contains(Lang.En?"1 need review":"۱ نیاز به بررسی"),"compact review count includes unconfirmed connection");
   var recovered=new Fake();type.GetField("RuntimeFactory",flags).SetValue(form,new Func<IStudentImportRuntime>(()=>recovered));retry.PerformClick();
   Until(()=>!(bool)Field(form,"running"),6000,"retry of unconfirmed connection completes");
   Check(rows[1].State==ImportState.Connected&&recovered.Saves==0,"a later confirmed connection replaces unconfirmed status and reuses the saved copy");
   Check(Directory.GetFiles(Path.Combine(AppPaths.DataDir,"imports"),"*.xlsx").Length==4,"stopped, successful, unconfirmed and recovered runs all save results");
   foreach(var path in Directory.GetFiles(Path.Combine(AppPaths.DataDir,"imports"),"*.xlsx"))
    Check(!Spreadsheet.Read(path).SelectMany(r=>r.Cells.Values).Any(t=>t.Contains("FAKE-INVESTOR-123")),"saved result never contains the test password");
   rows[1].State=ImportState.Ready;type.GetMethod("Counts",flags).Invoke(form,null);
   var previous=new Fake{PreviousBusy=true};type.GetField("RuntimeFactory",flags).SetValue(form,new Func<IStudentImportRuntime>(()=>previous));start.PerformClick();
   Until(()=>stage.Text.Contains("Waiting for previous terminal"),6000,"previous-terminal wait is shown in the live details");
   Check(rows[1].State==ImportState.Checking&&close.Enabled&&close.Visible,"waiting for teardown stays in progress with Stop available");
   using(var bmp=new Bitmap(form.ClientSize.Width,form.ClientSize.Height)){using(var capture=Graphics.FromImage(bmp))capture.CopyFromScreen(form.PointToScreen(Point.Empty),Point.Empty,form.ClientSize);bmp.Save(args[0]+"-waiting.png");}
   close.PerformClick();Until(()=>!(bool)Field(form,"running"),6000,"Stop exits previous-terminal wait without freezing the dialog");
   Check(rows[1].State==ImportState.Cancelled&&previous.Disposed,"waiting cancellation completes runtime disposal and is not a failed login");
   form.Close();
  }
  Console.WriteLine("UI flow: "+checks+" checks passed ("+args[1]+", "+args[2]+", scale="+theme.GetField("Scale").GetValue(null)+"). No broker login attempted.");return 0;
 }
}
