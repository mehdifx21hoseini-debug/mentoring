using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Drawing;
using System.Windows.Forms;
using MTManager;
class ExportUiTest
{
 static BindingFlags flags=BindingFlags.Instance|BindingFlags.NonPublic;
 static object Field(object o,string n){return o.GetType().GetField(n,flags).GetValue(o);}
 static int count;
 static void Check(bool b,string name){if(!b)throw new Exception(name);count++;}
 static void Pump(){for(int i=0;i<12;i++){Application.DoEvents();System.Threading.Thread.Sleep(10);}}
 static void Shot(Form f,string path){using(var b=new Bitmap(f.ClientSize.Width,f.ClientSize.Height)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(f.PointToScreen(Point.Empty),Point.Empty,f.ClientSize);b.Save(path);}}
 [STAThread] static int Main(string[] args)
 {
  Lang.En=args[1]=="en";
  AppPaths.DataDirOverride="/workspace/metafactory-tools/export-ui-data-"+Guid.NewGuid().ToString("N");Directory.CreateDirectory(AppPaths.DataDirOverride);
  var asm=typeof(Settings).Assembly;var theme=asm.GetType("MTManager.Theme");theme.GetMethod("Init").Invoke(null,null);theme.GetMethod("Apply").Invoke(null,new object[]{"classic"});
  Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
  var s=new Settings();s.UseFolder(Path.Combine(AppPaths.DataDirOverride,"copies"));
  using(var form=(Form)Activator.CreateInstance(asm.GetType("MTManager.MainForm"),new object[]{s,new AccountStore()}))
  {
   form.Show();Pump();
   var export=(Control)Field(form,"exportButton");var text=(Control)Field(form,"textButton");var tools=(Control)Field(form,"toolsButton");var band=(Control)Field(form,"band");
   Check(export.Visible&&export.Text.Length>0,"export button visible in main toolbar");
   Check(Lang.En?text.Right<=export.Left&&export.Right<=tools.Left:tools.Right<=export.Left&&export.Right<=text.Left,"export positioned between Report text and Tools");
   Check(band.ClientRectangle.Contains(export.Bounds),"export action fits toolbar");
   Shot(form,args[0]+"-main.png");
   var chosen=Field(form,"chosen");chosen.GetType().GetMethod("Toggle").Invoke(chosen,new object[]{"MT4-test"});form.GetType().GetMethod("ShowChoice",flags).Invoke(form,null);Pump();
   Check(!export.Visible&&!tools.Visible,"whole-directory actions follow Tools visibility in selection mode");
   foreach(Control c in band.Controls)if(c.Visible&&c.GetType().Name=="BandButton")Check(band.ClientRectangle.Contains(c.Bounds),"toolbar action fits selection layout: "+c.Text);
   form.Close();
  }
  using(var dialog=(Form)Activator.CreateInstance(asm.GetType("MTManager.StudentExportDialog"),new object[]{39}))
  {
   dialog.Show();Pump();
   Check((bool)dialog.GetType().GetProperty("IncludePasswords").GetValue(dialog,null),"complete export includes saved passwords with a visible option");
   var box=(CheckBox)Field(dialog,"passwords");Check(box.Visible,"password choice is visible");box.Checked=false;
   Check(!(bool)dialog.GetType().GetProperty("IncludePasswords").GetValue(dialog,null),"passwords can be excluded before saving");
   Check(Screen.FromControl(dialog).WorkingArea.Contains(dialog.Bounds),"export options dialog fits display");Shot(dialog,args[0]+"-options.png");dialog.Close();
  }
  Console.WriteLine("Export UI: "+count+" checks passed ("+args[1]+").");return 0;
 }
}
