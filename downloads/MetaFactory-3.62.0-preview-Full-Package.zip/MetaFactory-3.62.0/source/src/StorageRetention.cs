using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
namespace MTManager
{
    // Only explicitly owned locations; never the account journal, broker price history, or current chart profiles.
    public static class StorageRetention
    {
        public const long LogBudget = 50L * 1024 * 1024;
        public const int LogDays = 7, BackupDays = 7, KeepProfiles = 2, TempDays = 2;
        static readonly Regex SnapshotName = new Regex(@"^\d{8}-\d{6}-[a-fA-F0-9]{32}$");
        static readonly Regex SessionName = new Regex(@"^[a-fA-F0-9]{32}$");
        static readonly Regex PartName = new Regex(@"^(snapshot\.txt|history-[01]\.txt)\.[a-zA-Z0-9-]+\.part$");
        public sealed class Item
        {
            public string Root { get; internal set; }
            public string Path { get; internal set; }
            public string Group { get; internal set; }
            public long Bytes { get; internal set; }
            public bool Automatic { get; internal set; }
            internal DateTime Stamp, Cutoff;
        }
        public sealed class Result { public long Bytes; public int Removed, Skipped, Pending; public bool Cancelled; }
        static bool Linked(string p) { return (File.GetAttributes(p) & FileAttributes.ReparsePoint) != 0; }
        public static bool Safe(string path, string root)
        {
            try
            {
                string full=System.IO.Path.GetFullPath(path), boundary=System.IO.Path.GetFullPath(root).TrimEnd(System.IO.Path.DirectorySeparatorChar,System.IO.Path.AltDirectorySeparatorChar);
                if(!full.Equals(boundary,StringComparison.OrdinalIgnoreCase) && !full.StartsWith(boundary+System.IO.Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))return false;
                for(string p=full;!string.IsNullOrEmpty(p);p=System.IO.Path.GetDirectoryName(p)) if(Linked(p))return false;
                return true;
            } catch { return false; }
        }
        static long TreeSize(string path,string root,ref int count,int depth,ref DateTime newest)
        {
            if(depth>32 || ++count>200000 || !Safe(path,root))throw new IOException("Storage scan boundary.");
            if(File.Exists(path)){newest=Max(newest,File.GetLastWriteTimeUtc(path));return new FileInfo(path).Length;}
            long bytes=0;
            foreach(string child in Directory.EnumerateFileSystemEntries(path))bytes=checked(bytes+TreeSize(child,root,ref count,depth+1,ref newest));
            return bytes;
        }
        static DateTime Max(DateTime a,DateTime b){return a>b?a:b;}
        static Item Candidate(string path,string root,string group,bool automatic,DateTime cutoff)
        {
            try
            {
                if(!Safe(path,root))return null;
                DateTime newest=File.GetLastWriteTimeUtc(path);int count=0;
                long bytes=TreeSize(path,root,ref count,0,ref newest);
                if(newest>cutoff)return null;
                return new Item{Root=root,Path=path,Group=group,Automatic=automatic,Bytes=bytes,Stamp=File.GetLastWriteTimeUtc(path),Cutoff=cutoff};
            } catch {return null;}
        }
        static void Add(List<Item> list,Item item){if(item!=null)list.Add(item);}
        static bool DailyLog(string path,DateTime utc)
        {
            DateTime day;
            return DateTime.TryParseExact(System.IO.Path.GetFileNameWithoutExtension(path),"yyyyMMdd",CultureInfo.InvariantCulture,DateTimeStyles.None,out day) && day.Date<utc.Date.AddDays(-1);
        }
        static void Logs(Instance copy,DateTime now,List<Item> result)
        {
            var files=new List<FileInfo>();
            foreach(string root in new[]{System.IO.Path.Combine(copy.Dir,"logs"),System.IO.Path.Combine(copy.Dir,Kinds.Mql(copy.Kind),"Logs")})
                if(Directory.Exists(root)&&Safe(root,copy.Dir))
                    foreach(string p in Directory.EnumerateFiles(root,"*.log"))if(Safe(p,copy.Dir))try{files.Add(new FileInfo(p));}catch{}
            long total=files.Sum(f=>f.Length);
            foreach(var f in files.OrderBy(f=>f.LastWriteTimeUtc).ThenBy(f=>f.FullName,StringComparer.OrdinalIgnoreCase))
            {
                if(!DailyLog(f.FullName,now)||f.LastWriteTimeUtc>now.AddDays(-1))continue;
                if(f.LastWriteTimeUtc>now.AddDays(-LogDays)&&total<=LogBudget)continue;
                var item=Candidate(f.FullName,copy.Dir,"storage-logs",true,now.AddDays(-1));
                if(item!=null){result.Add(item);total-=item.Bytes;}
            }
        }
        static void Backups(string root,string boundary,DateTime now,bool repair,List<Item> result)
        {
            if(!Directory.Exists(root)||!Safe(root,boundary))return;
            var paths=Directory.EnumerateDirectories(root).Where(p=>SnapshotName.IsMatch(System.IO.Path.GetFileName(p))).Where(p=>Safe(p,boundary)).ToList();
            foreach(string p in paths.OrderByDescending(p=>System.IO.Path.GetFileName(p),StringComparer.Ordinal).Skip(KeepProfiles))
            {
                DateTime made;
                if(!DateTime.TryParseExact(System.IO.Path.GetFileName(p).Substring(0,15),"yyyyMMdd-HHmmss",CultureInfo.InvariantCulture,DateTimeStyles.AssumeUniversal|DateTimeStyles.AdjustToUniversal,out made)||made>now.AddDays(-BackupDays))continue;
                Add(result,Candidate(p,boundary,repair?"storage-repair":"storage-profiles",!repair,now.AddDays(-BackupDays)));
            }
            if(!repair)
                foreach(string p in Directory.EnumerateFiles(root,"lastprofile-*.ini.bak").Where(p=>Regex.IsMatch(System.IO.Path.GetFileName(p),@"^lastprofile-[a-fA-F0-9]{32}\.ini\.bak$")).Where(p=>Safe(p,boundary)).OrderByDescending(File.GetLastWriteTimeUtc).Skip(KeepProfiles))
                    Add(result,Candidate(p,boundary,"storage-profiles",true,now.AddDays(-BackupDays)));
        }
        public static List<Item> Scan(IEnumerable<Instance> copies,DateTime utcNow,IEnumerable<string> protectedSessionDirectories=null,bool automaticOnly=false,Func<bool> cancelled=null)
        {
            var result=new List<Item>();DateTime now=utcNow.Kind==DateTimeKind.Local?utcNow.ToUniversalTime():utcNow;
            var active=protectedSessionDirectories==null?null:new HashSet<string>(protectedSessionDirectories.Select(System.IO.Path.GetFullPath),StringComparer.OrdinalIgnoreCase);
            foreach(var c in copies.GroupBy(c=>System.IO.Path.GetFullPath(c.Dir),StringComparer.OrdinalIgnoreCase).Select(g=>g.First()))
            {
                if(cancelled!=null&&cancelled())break;
                if(!Directory.Exists(c.Dir)||!Safe(c.Dir,c.Dir))continue;
                try
                {
                    Logs(c,now,result);
                    foreach(string name in new[]{"single-live-profile","mt5-live-profile"})Backups(System.IO.Path.Combine(c.Dir,"MTManager-backup",name),c.Dir,now,false,result);
                    string parent=System.IO.Path.GetDirectoryName(System.IO.Path.GetFullPath(c.Dir));
                    // Full terminal backups may contain personal files: manual selection only, last two always retained.
                    if(!automaticOnly)Backups(System.IO.Path.Combine(parent,"_MTManager","repair-backups",c.Name),parent,now,true,result);
                    string live=System.IO.Path.Combine(c.Dir,Kinds.Mql(c.Kind),"Files","MetaFactoryLive");
                    if(!Directory.Exists(live)||!Safe(live,c.Dir))continue;
                    foreach(string session in Directory.EnumerateDirectories(live).Where(p=>SessionName.IsMatch(System.IO.Path.GetFileName(p))))
                    {
                        if(!Safe(session,c.Dir))continue;
                        foreach(string p in Directory.EnumerateFiles(session))
                        {
                            string name=System.IO.Path.GetFileName(p);
                            if(PartName.IsMatch(name))Add(result,Candidate(p,c.Dir,"storage-temp",true,now.AddDays(-TempDays)));
                            else if(!automaticOnly&&active!=null&&!active.Contains(System.IO.Path.GetFullPath(session)) && new[]{"snapshot.txt","snapshot.txt.fallback","history-0.txt","history-1.txt"}.Contains(name))
                                Add(result,Candidate(p,c.Dir,"storage-sessions",false,now.AddDays(-BackupDays)));
                        }
                    }
                } catch(Exception e){Log.Write("storage scan "+c.Name+": "+e.GetType().Name);}
            }
            return result.GroupBy(i=>System.IO.Path.GetFullPath(i.Path),StringComparer.OrdinalIgnoreCase).Select(g=>g.First()).ToList();
        }
        static bool DeleteTree(string path,string root,DateTime cutoff,ref long freed)
        {
            if(!Safe(path,root))return false;
            if(File.Exists(path))
            {
                try
                {
                    using(var handle=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Delete))
                    {
                        if(!Safe(path,root)||File.GetLastWriteTimeUtc(path)>cutoff)return false;
                        long bytes=handle.Length;File.Delete(path);freed+=bytes;return true;
                    }
                }catch{return false;}
            }
            bool complete=true;
            try
            {
                foreach(string child in Directory.GetFileSystemEntries(path))if(!DeleteTree(child,root,cutoff,ref freed))complete=false;
                if(complete&&Safe(path,root)&&!Directory.EnumerateFileSystemEntries(path).Any())Directory.Delete(path,false);
            }catch{complete=false;}
            return complete;
        }
        public static long Measure(string path)
        { try { int count=0;DateTime newest=DateTime.MinValue;return TreeSize(path,path,ref count,0,ref newest); } catch {return 0;} }
        static bool StillExcess(Item item)
        {
            if(item.Group!="storage-profiles")return true;
            string parent=System.IO.Path.GetDirectoryName(item.Path);
            if(Directory.Exists(item.Path))
                return !Directory.EnumerateDirectories(parent).Where(p=>SnapshotName.IsMatch(System.IO.Path.GetFileName(p))).Where(p=>Safe(p,item.Root)).OrderByDescending(System.IO.Path.GetFileName,StringComparer.Ordinal).Take(KeepProfiles).Contains(item.Path,StringComparer.OrdinalIgnoreCase);
            return !Directory.EnumerateFiles(parent,"lastprofile-*.ini.bak").Where(p=>Regex.IsMatch(System.IO.Path.GetFileName(p),@"^lastprofile-[a-fA-F0-9]{32}\.ini\.bak$")).Where(p=>Safe(p,item.Root)).OrderByDescending(File.GetLastWriteTimeUtc).Take(KeepProfiles).Contains(item.Path,StringComparer.OrdinalIgnoreCase);
        }
        public static Result RunAutomatic(IEnumerable<Instance> copies,DateTime utcNow,IEnumerable<string> active=null,Func<bool> cancelled=null)
        {
            var result=new Result();var snapshot=copies.ToList();
            // Never walk full repair archives or inactive history just to perform a light automatic sweep.
            var candidates=Scan(snapshot,utcNow,active,true,cancelled).Where(i=>i.Automatic).ToList();int processed=0;
            if(cancelled!=null&&cancelled()){result.Cancelled=true;result.Pending=candidates.Count;return result;}
            foreach(var item in candidates.Take(2000))
            {
                if(cancelled!=null&&cancelled()){result.Cancelled=true;break;}
                processed++;
                // A late write protects the candidate; no recursive wildcard deletion or linked traversal.
                try
                {
                    if(!Safe(item.Path,item.Root)||File.GetLastWriteTimeUtc(item.Path)!=item.Stamp||!StillExcess(item)){result.Skipped++;continue;}
                    if(DeleteTree(item.Path,item.Root,item.Cutoff,ref result.Bytes))result.Removed++;else result.Skipped++;
                }catch{result.Skipped++;}
            }
            result.Pending=Math.Max(0,candidates.Count-processed);
            return result;
        }
        public static List<CleanupGroup> Groups(IEnumerable<Instance> copies,DateTime now,IEnumerable<string> active=null,IEnumerable<string> copyRoots=null)
        {
            var items=Scan(copies,now,active);
            foreach(string boundary in (copyRoots??Enumerable.Empty<string>()).Distinct(StringComparer.OrdinalIgnoreCase))
            {
                try
                {
                    string repairs=System.IO.Path.Combine(boundary,"_MTManager","repair-backups");
                    if(Directory.Exists(repairs)&&Safe(repairs,boundary))
                        foreach(string bucket in Directory.EnumerateDirectories(repairs))if(Safe(bucket,boundary))Backups(bucket,boundary,now,true,items);
                    string stages=System.IO.Path.Combine(boundary,"_MTManager","repair-stage");
                    if(Directory.Exists(stages)&&Safe(stages,boundary))
                        foreach(string stage in Directory.EnumerateDirectories(stages).Where(p=>SessionName.IsMatch(System.IO.Path.GetFileName(p))))
                            Add(items,Candidate(stage,boundary,"storage-stage",false,now.AddDays(-TempDays)));
                }catch{}
            }
            items=items.GroupBy(i=>System.IO.Path.GetFullPath(i.Path),StringComparer.OrdinalIgnoreCase).Select(g=>g.First()).ToList();
            string[][] descriptions={
                new[]{"storage-logs",Lang.T("لاگ‌های قدیمی و اضافی متاتریدر","Old / excess MetaTrader logs"),Lang.T("خودکار: نگهداری ۷ روز، با بودجهٔ ۵۰ مگابایت برای لاگ‌های هر نسخه؛ امروز، دیروز و فایلِ در حال استفاده حفظ می‌شوند.","Automatic: 7 days / 50 MB per copy; today, yesterday and in-use files are preserved.")},
                new[]{"storage-temp",Lang.T("فایل‌های موقت رهاشدهٔ لایو","Abandoned live temporary files"),Lang.T("خودکار: فقط فایل موقتِ شناخته‌شده که بیش از ۲ روز نوشته نشده است.","Automatic: known temporary files untouched for over 2 days only.")},
                new[]{"storage-profiles",Lang.T("پشتیبان‌های اضافی پروفایل مدیریت‌شده","Excess managed profile backups"),Lang.T("خودکار: ۲ پشتیبان آخر حفظ می‌شود؛ اضافی‌های قدیمی‌تر از ۷ روز پاک می‌شوند. پروفایل و چارت فعلی حفظ می‌شود.","Automatic: keep the latest 2; extra backups older than 7 days expire. Current profiles/charts are preserved.")},
                new[]{"storage-repair",Lang.T("پشتیبان‌های قدیمی بازسازی نسخه‌ها","Old full repair backups"),Lang.T("فقط با انتخاب شما؛ ممکن است فایل شخصی داشته باشند. دو نسخهٔ آخر و پشتیبان‌های ۷ روز اخیر حفظ می‌شوند.","Manual selection only: may contain personal files. Latest 2 and backups from the last 7 days are preserved.")},
                new[]{"storage-stage",Lang.T("فایل‌های موقت بازسازیِ نیمه‌تمام","Abandoned repair staging folders"),Lang.T("فقط با انتخاب شما؛ پوشه‌های کاری مدیریت‌شده که بیش از ۲ روز تغییری نداشته‌اند.","Manual selection only: managed staging folders untouched for more than 2 days.")},
                new[]{"storage-sessions",Lang.T("خروجی قدیمی اتصال‌های قبلی لایو","Old output from previous live bindings"),Lang.T("فقط با انتخاب شما؛ اتصال فعلی و گزارش ذخیره‌شدهٔ حساب دست‌نخورده می‌ماند.","Manual selection only; current binding and stored account journal are preserved.")}
            };
            return descriptions.Select(d=>{var g=new CleanupGroup{Id=d[0],Title=d[1],Note=d[2]};foreach(var i in items.Where(i=>i.Group==g.Id)){g.Paths.Add(i.Path);g.Size+=i.Bytes;}return g;}).ToList();
        }
    }
}
