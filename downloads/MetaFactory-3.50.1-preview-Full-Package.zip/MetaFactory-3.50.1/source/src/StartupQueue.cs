using System;using System.Collections.Generic;using System.Diagnostics;using System.Linq;
namespace MTManager
{
    public static class StartupAdmission
    {
        public const int DeadlineSeconds=90;
        public static int Parallel(ulong freeMb){return freeMb>=1536?2:1;}
        public static bool Wait(int initializing,ulong freeMb){return initializing>=Parallel(freeMb);}
    }
    sealed partial class MainForm
    {
        sealed class StartingMt5
        {
            public Instance Copy;public Process Process;public DateTime Began=DateTime.UtcNow,SampleAt=DateTime.UtcNow,QuietSince=DateTime.MinValue;
            public TimeSpan Cpu;
        }
        readonly List<StartingMt5> startingMt5=new List<StartingMt5>();
        string startupWaitKey="";
        int startupWaits,startupDeadlines;
        string StartupQueueSummary(){return "\r\n— MT5 staged startup —\r\nMax initializers: 2 when free RAM >=1536MB, otherwise1; total terminal count unlimited. Ready=verified fresh dashboard OR window+3s quiet CPU. Observation deadline=90s; expired processes are left running, never assumed ready.\r\nWait transitions="+startupWaits+" observation deadlines="+startupDeadlines+" currently observed="+startingMt5.Count+"\r\n";}
        void TrackMt5Startup(Instance copy,StartResult result)
        {
            if(copy.Kind!=Kind.MT5 || result.Process==null)return;
            startingMt5.RemoveAll(v=>v.Copy.Name==copy.Name);
            var item=new StartingMt5{Copy=copy,Process=result.Process};try{item.Cpu=item.Process.TotalProcessorTime;}catch{}
            startingMt5.Add(item);
        }
        void UpdateMt5StartupProcess(Instance copy,Process process)
        {
            var item=startingMt5.FirstOrDefault(v=>v.Copy.Name==copy.Name);if(item==null || process==null)return;
            item.Process=process;item.SampleAt=DateTime.UtcNow;item.QuietSince=DateTime.MinValue;try{item.Cpu=process.TotalProcessorTime;}catch{}
        }
        bool WaitForStartupSlot(Instance next)
        {
            if(next.Kind!=Kind.MT5)return false;
            DateTime now=DateTime.UtcNow;
            foreach(var item in startingMt5.ToArray())
            {
                double age=(now-item.Began).TotalSeconds;
                if(age>=StartupAdmission.DeadlineSeconds)
                {startingMt5.Remove(item);startupDeadlines++;Log.Write("MT5 startup observation deadline: "+item.Copy.Name+"; process left running, readiness not assumed; queue continues");continue;}
                try
                {
                    LiveMonitorView view;var account=accounts.Get(item.Copy.Name);
                    if(dashboardRows.TryGetValue(item.Copy.Name,out view) && view.Dashboard!=null && view.Feed!=null && view.Feed.HeartbeatUtc>=item.Began && account!=null && view.Dashboard.Matches(item.Copy,account,now))
                    {startingMt5.Remove(item);continue;}
                    item.Process.Refresh();
                    if(item.Process.HasExited)
                    {
                        // Preserve a slot during the native updater's hand-off. Never kill or start a second copy here.
                        if(age>=15 && !Updating(item.Copy))startingMt5.Remove(item);
                        continue;
                    }
                    double seconds=(now-item.SampleAt).TotalSeconds;
                    if(seconds<.8)continue;
                    var cpu=item.Process.TotalProcessorTime;double share=(cpu-item.Cpu).TotalSeconds/seconds;item.Cpu=cpu;item.SampleAt=now;
                    if(item.Process.MainWindowHandle!=IntPtr.Zero && share>=0 && share<StartPace.Settled)
                    {if(item.QuietSince==DateTime.MinValue)item.QuietSince=now;else if((now-item.QuietSince).TotalSeconds>=3)startingMt5.Remove(item);}
                    else item.QuietSince=DateTime.MinValue;
                }
                catch { if(age>=15)startingMt5.Remove(item); }
            }
            ulong free=launchFreeRam();bool wait=StartupAdmission.Wait(startingMt5.Count,free);
            string key=wait?string.Join(",",startingMt5.Select(v=>v.Copy.Name))+":"+StartupAdmission.Parallel(free):"";
            if(key!=startupWaitKey)
            {
                startupWaitKey=key;
                if(wait){startupWaits++;Log.Write("MT5 staged startup wait: initializing="+startingMt5.Count+" allowance="+StartupAdmission.Parallel(free)+"; no total terminal cap");SetStatus(Lang.T("شروع مرحله‌ای MT5؛ منتظر آماده‌شدن نسخه‌های قبلی…","Staged MT5 launch; waiting for earlier initializers…"));}
            }
            return wait;
        }
    }
}
