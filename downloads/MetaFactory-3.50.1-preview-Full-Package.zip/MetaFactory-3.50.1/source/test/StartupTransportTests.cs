using System;using System.IO;using System.Linq;using System.Text;
namespace MTManager {static partial class Tests {
static void StartupTransportChecks()
{
    Equal(2,StartupAdmission.Parallel(2000),"healthy RAM allows two MT5 initializers");
    Equal(1,StartupAdmission.Parallel(700),"low RAM limits initializers, not total terminals");
    Equal(1,StartupAdmission.Parallel(0),"unknown RAM uses conservative startup staging");
    Check(StartupAdmission.Wait(2,2000)&&!StartupAdmission.Wait(1,2000),"two pending starts wait for readiness");
    Check(StartupAdmission.Wait(1,700)&&!StartupAdmission.Wait(0,700),"low-memory staging still allows the next first initializer");
    Equal("OwnRecent",LiveAutoStart.StartupHint("OwnRecent",null,new string[0]),"recent account symbol is a local hint");
    Equal("Suffix_EURUSD",LiveAutoStart.StartupHint(null,"Suffix_EURUSD",new[]{"Other","Suffix_EURUSD"}),"cached chart symbol retained when known locally");
    Equal("BrokerOnly",LiveAutoStart.StartupHint(null,"OldBad",new[]{"BrokerOnly"}),"own broker symbols preferred to an unknown chart");
    Check(!LiveAutoStart.StartupHint(null,"x\nExpert=bad",new[]{"x\nExpert=bad"}).Contains("\n"),"startup hints reject config injection");
    string dir=Dir("publication-fallback");string primary=Path.Combine(dir,"snapshot.txt"),fallback=primary+".fallback";
    DateTime now=new DateTime(2026,11,23,18,0,0,DateTimeKind.Utc);FeedWrite(Path.Combine(dir,"history-0.txt"),FeedHistory(now));FeedWrite(primary,FeedFrame(now));
    var reader=new LiveFeedReader(Kind.MT5,"123","Broker-Demo",FeedToken,dir);
    Equal(LiveFeedStatus.Live,reader.Poll(now).Status,"normal primary transport remains compatible");
    using(var locked=new FileStream(primary,FileMode.Open,FileAccess.Read,FileShare.Read))
    {
        FeedWrite(fallback,FeedFrame(now.AddSeconds(1),2));var frame=reader.Poll(now.AddSeconds(1));
        Equal(LiveFeedStatus.Live,frame.Status,"complete alternate publication works while primary cannot be replaced");Equal(2L,frame.Sequence,"alternate sequence is observed");
        Equal(900.0,frame.Balance,"alternate transport retains financial proof");
    }
    FeedWrite(primary,FeedFrame(now.AddSeconds(2),3,state:"stopped"));
    Equal(LiveFeedStatus.Stopped,reader.Poll(now.AddSeconds(2)).Status,"recovered primary stopped state wins over older live alternate");
    FeedWrite(fallback,FeedFrame(now.AddSeconds(3),4).Replace("A\t123","A\t456"));
    Equal(LiveFeedStatus.IdentityMismatch,reader.Poll(now.AddSeconds(3)).Status,"new alternate identity mismatch cannot fall back to older live primary");
    FeedWrite(fallback,"truncated");Equal(LiveFeedStatus.Invalid,reader.Poll(now.AddSeconds(4)).Status,"invalid latest alternate fails closed");
    FeedWrite(primary,FeedFrame(now.AddSeconds(5),5));FeedWrite(fallback,FeedFrame(now.AddSeconds(5),6,state:"disconnected",connected:false));
    File.SetLastWriteTimeUtc(fallback,File.GetLastWriteTimeUtc(primary));
    Equal(LiveFeedStatus.Disconnected,reader.Poll(now.AddSeconds(5)).Status,"equal file timestamp uses sequence without hiding disconnection");
    FeedWrite(fallback,FeedFrame(now.AddSeconds(-30),7));Equal(LiveFeedStatus.Stale,reader.Poll(now.AddSeconds(6)).Status,"newly published old heartbeat is not made live by fallback transport");
    File.Delete(primary);FeedWrite(fallback,FeedFrame(now.AddSeconds(7),8,state:"history-pending"));
    Equal(LiveFeedStatus.HistoryPending,new LiveFeedReader(Kind.MT5,"123","Broker-Demo",FeedToken,dir).Poll(now.AddSeconds(7)).Status,"fallback alone is supported but missing ready proof stays pending");
}
}}
