using System;using System.IO;using System.Linq;using System.Collections;using System.Diagnostics;using System.Reflection;using System.Windows.Forms;
namespace MTManager {static class StartupQueueUiSmoke {
const BindingFlags F=BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public;static int n;
static object Get(object o,string name){return o.GetType().GetField(name,F).GetValue(o);}static void Set(object o,string name,object value){o.GetType().GetField(name,F).SetValue(o,value);}static object Call(object o,string name,params object[] values){return o.GetType().GetMethod(name,F).Invoke(o,values);}static void Check(bool yes,string text){if(!yes)throw new Exception(text);n++;Console.WriteLine("PASS "+text);}
[STAThread]static int Main(){Application.EnableVisualStyles();Theme.Init();Lang.En=true;string root=Path.Combine(Path.GetTempPath(),"startup-ui-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);AppPaths.DataDirOverride=root;Process a=null,b=null;
try{var settings=new Settings{BaseDir=Path.Combine(root,"copies"),AutoStart=false};Directory.CreateDirectory(settings.BaseDir);using(var main=new MainForm(settings,new AccountStore())){
foreach(var field in main.GetType().GetFields(F))if(field.FieldType==typeof(System.Windows.Forms.Timer))((System.Windows.Forms.Timer)field.GetValue(main)).Stop();
Set(main,"launchFreeRam",(Func<ulong>)(()=>4096));a=Process.Start(new ProcessStartInfo("/bin/sleep","120"){UseShellExecute=false});b=Process.Start(new ProcessStartInfo("/bin/sleep","120"){UseShellExecute=false});
var one=new Instance{Name="MT5-01",Kind=Kind.MT5,Dir=root};var two=new Instance{Name="MT5-02",Kind=Kind.MT5,Dir=root};var next=new Instance{Name="MT5-03",Kind=Kind.MT5,Dir=root};
Call(main,"TrackMt5Startup",one,new StartResult{Process=a});Call(main,"TrackMt5Startup",two,new StartResult{Process=b});
Check((bool)Call(main,"WaitForStartupSlot",next),"two headless initializers hold next MT5");Check(!(bool)Call(main,"WaitForStartupSlot",new Instance{Name="MT4-01",Kind=Kind.MT4,Dir=root}),"MT4 launch path unaffected");
var list=(IList)Get(main,"startingMt5");Set(list[0],"Began",DateTime.UtcNow.AddSeconds(-91));Check(!(bool)Call(main,"WaitForStartupSlot",next)&&list.Count==1,"deadline frees only observation slot");Check(!a.HasExited&&!b.HasExited,"deadline never kills slow terminals");
Set(main,"launchFreeRam",(Func<ulong>)(()=>700));Check((bool)Call(main,"WaitForStartupSlot",next),"low RAM permits one initializer");Set(list[0],"Began",DateTime.UtcNow.AddSeconds(-91));Check(!(bool)Call(main,"WaitForStartupSlot",next)&&list.Count==0,"deadline preserves queue progress with low RAM");
Call(main,"TrackMt5Startup",one,new StartResult{Process=a});a.Kill();a.WaitForExit();Check((bool)Call(main,"WaitForStartupSlot",next),"exit handoff retains brief updater grace");Set(list[0],"Began",DateTime.UtcNow.AddSeconds(-16));Check(!(bool)Call(main,"WaitForStartupSlot",next),"confirmed exit without update frees startup slot");
}
Console.WriteLine("STARTUP QUEUE UI PASS "+n);return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}finally{foreach(var process in new[]{a,b})if(process!=null){try{if(!process.HasExited){process.Kill();process.WaitForExit();}process.Dispose();}catch{}}try{Directory.Delete(root,true);}catch{}}}
}}
